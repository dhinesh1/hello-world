const rewire = require('rewire');
const defaults = rewire('react-scripts/scripts/build.js');

let config = defaults.__get__('config');

config.optimization.splitChunks = {
  name: true,
  chunks: 'initial',
  cacheGroups:
    {
      default: false
    },
  };
config.optimization.runtimeChunk = false;
