import express from 'express';
import Loadable from 'react-loadable';
import indexController from './controllers/index';
import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import compression from 'compression';
import axios from 'axios';
import fs from 'fs';
import uuidv1 from 'uuid/v1';
import httpContext from 'express-http-context';
import initLogger from './accessLogger';
import helmet from 'helmet';
import { AppConfig } from '../src/app-config';
require('dotenv').config({ path: __dirname+'/../.env' });

// Creating logger for common logging - initLogger without any param will create access log
const logger = initLogger();
const API_URL = AppConfig.api_url;

const PORT = 5001;

// initialize the application and create the routes
const app = express();
app.disable('x-powered-by'); //disabling 'X-Powered-By' for Security to Save Bandwidth in ExpressJS

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(compression());

// Only be framed by people of the same origin.
// default "X-Frame-Options: SAMEORIGIN".
app.use(helmet.frameguard());
app.use(helmet.noSniff()); // Sets "X-Content-Type-Options: nosniff".
app.use(helmet.xssFilter()); // Sets "X-XSS-Protection: 1; mode=block".

/**
 * "Strict-Transport-Security: max-age=10368000" - 120 days in seconds
 * It protects users against passive eavesdropper and active man-in-the-middle (MITM) attacks.
 * It also enforces strict security like preventing mixed content and click-through certificate overrides,
 * and it protects against web server mistakes like loading JavaScript over an insecure connection
 * For more info check below link:
 * https://blog.qualys.com/securitylabs/2016/03/28/the-importance-of-a-proper-http-strict-transport-security-implementation-on-your-web-server
 */
// app.use(helmet.hsts({
//   maxAge: 10368000,
//   includeSubdomains: true,
//   preload: true
// }));

// Sets Content-Security-Policy “default-src ‘self’“;
/*
app.use(
  helmet.contentSecurityPolicy({
    directives: {
      defaultSrc: ["'self'", 'vars.hotjar.com'],
      connectSrc: [
        "'self'",
        's3.ap-south-1.amazonaws.com',
        'www.google-analytics.com',
        'in.hotjar.com',
        'api.mixpanel.com'
      ],
      imgSrc: [
        "'self'",
        "'data:'",
        "'mediastream:'",
        "'blob:'",
        'pyt-images.imgix.net',
        's3.ap-south-1.amazonaws.com',
        'www.google-analytics.com',
        'stats.g.doubleclick.net',
        'static.hotjar.com',
        'bat.bing.com',
        'www.google.com',
        'www.google.co.in',
        'www.facebook.com'
      ],
      styleSrc: [
        "'self'",
        "'unsafe-inline'",
        's3.ap-south-1.amazonaws.com',
        'client.crisp.chat'
      ],
      scriptSrc: [
        "'self'",
        "'unsafe-inline'", // `nonce-` attribute need to be added to all inline scripts to avoid using this 'unsafe-inline'
        's3.ap-south-1.amazonaws.com',
        //  www.google-analytics.com, www.googletagmanager.com, www.googleadservices.com
        // "'sha256-o3hwlGfJ0+pXwweAo56+8JzTGmXuK3HkH8h17AyPtBg='",
        // "'sha256-OWSz7SVGvImXdFJt/5JUMFIr99RJwauQNU6nYQNV0f8='",
        // client.crisp.chat
        // "'sha256-WEkhVjwAVW3JjXWfqSWPHoPjwWK4TCCyzcRQN2+kNOE='",
        // "'sha256-t6oewASd7J1vBg5mQtX4hl8bg8FeegYFM3scKLIhYUc='",
        // "'sha256-JdZq6TXQGmb+El5lYIk7O1WxLHYAIBDL630kx2YXsJY='",
        // "'sha256-dExCuunTvvmGGDk1Z6xIuTUVnMD/qNF2l2YOiQVWxsU='",
        // "'sha256-aLEeDXib223EZDNqEbq9oXxRgQO5oHXTbZUWUiCreZs='",
        // "'sha256-KzaJGza4ttl1EU+7uF8STKEYMoWxp9QZyR14rt9DYZk='",
        // "'sha256-O4+DpIS95tu3DlM3Xjm6hh+R7t3nLJGTpfii7KOHMy4='",
        // "'sha256-2/1i5pElJViPlr8oEQbt51H2sEzCMkReiulCSY3aowA='",
        // "'sha256-OQNl8JS7QeKRFk3N3hxLEjJaGBzXR73duOslDH7jXNk='",
        // "'sha256-wblQwpKYH+6VIBdxw66YhHxT210Uk7kS1AVPK8YAaZI='",
        // "'sha256-TqSuBqpp0HJ5d5eHgd4lYgxdva7kvM3HkUletSa9W/U='",

        'www.google-analytics.com',
        'www.googletagmanager.com',
        'www.googleadservices.com',
        'googleads.g.doubleclick.net',
        'stats.g.doubleclick.net',
        'cdn4.mxpnl.com',
        'static.hotjar.com',
        'script.hotjar.com',
        'bat.bing.com',
        'connect.facebook.net',
        'client.crisp.chat',
        'settings.crisp.chat'
      ],
      fontSrc: ["'self'", 'pyt-images.imgix.net', 'fonts.gstatic.com']
    }
  })
);
*/

/**
 * httpContext middleware works like sessionStorage.
 * The values stored to this context will remain until next request comes in.
 * NOTE 1: this storage will behave weird if we use '.set()' inside async/await
 * NOTE 2: Node 10.0.x - 10.3.x are not supported. >> Node 10.4.x uses V8 v6.7 in which the bug is fixed.
 * Repo: https://www.npmjs.com/package/express-http-context
 */
app.use(httpContext.middleware);

/**
 * Middleware to set unique_id to each requests in httpContext, it will be used to track the control(access) flow
 */
app.use((req, res, next) => {
  httpContext.set('req_id', uuidv1());
  const queryStr = req.query ? JSON.stringify(req.query) : '';
  const reqBody = req.body ? JSON.stringify(req.body) : '';
  const msg = `HTTP: ${res.statusCode} - REQ_METHOD: ${req.method} - REQ_URL: ${
    req.url
  } - QUERY_PARAMS: ${queryStr} - REQ_BODY: ${reqBody} - REQ_IP: ${
    req.ip
  } - USER_AGENT: ${req.get('User-Agent')}`;
  logger.info(msg);
  next();
});

// tell the app to use the above rules
app.use(indexController);

// start the app
Loadable.preloadAll().then(() => {
  app.listen(PORT, error => {
    if (error) {
      return logger.info('something bad happened: ' + JSON.stringify(error));
    }

    logger.info('listening on ' + PORT + '...');

    getXMLData(`${API_URL}misc/generateSitemap`, 'sitemap.xml');
    getXMLData(
      `${API_URL}misc/generateSitemapItineraries`,
      'sitemap-itineraries.xml'
    );
  });
});

export const getXMLData = (url, fileName) => {
  return new Promise((resolve, rej) => {
    axios
      .get(url)
      .then(res => {
        if (res.status === 200 && res.data.status === 'SUCCESS') {
          const sitemap = fs.createWriteStream(
            `${__dirname}/../build/${fileName}`
          );
          sitemap.write(res.data.data);
          sitemap.end();
          console.log('>> Created ' + fileName);

          resolve('>> Created ' + fileName);
        }
      })
      .catch(err => {
        console.log('====>>> XML PARSE ERROR', err);

        rej('====>>> XML PARSE ERROR');
      });
  });
};
