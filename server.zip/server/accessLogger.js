/**
 * Custom Access Logger using winston & winston-daily-rotate-file
 * Note: express-http-context package is to maintain request-level scope storing unique_id for each requests
 * adding unique request id improves tracking control/access flow for individual requests
 *
 * Created by: Sriram
 * Created on: Feb 5, 2019
 * Modified by: Jothisankar
 * Modified on: Feb 19, 2019
 */
import { createLogger, format, transports } from 'winston';
import winstonDailyLogRotate from 'winston-daily-rotate-file';
import httpContext from 'express-http-context';

/**
 * This will init and return the logger with the required configuration.
 * While you need to segregate logs into multiple files based on its usage you can new one just by passing different type value
 *
 * e.g: we wanted to split redux store object logs to identify a use-case where circular objects are created
 * so calling const reduxLogger = initLogger('redux') will create veho_react_redux_logs_DATE.log
 * and using reduxLogger.info("some content") will log into the redux file not on default access log file.
 *
 * @param type - default is 'access'
 * @returns {{warn: warn, debug: debug, log: log, silly: silly, error: error, verbose: verbose, info: info}}
 */
const initLogger = (type = 'access') => {
  const { timestamp, combine, printf } = format;

  const LOGFILE_NAME = `veho_react_${type}_logs_%DATE%.log`;

  // get log file config from environment variables, replace with default values if env is not set
  const {
    LOGFILE_PATH = __dirname + '/../logs',
    LOGFILE_MAX_SIZE = '20m',
    LOGFILE_LIFE = '45d',
    NODE_ENV
  } = process.env;

  /**
   *  Logger configuration
   * %DATE% in 'filename' will be replaced with 'YYYY-MM-DD' by default
   * %DATE% format can be changed using 'datePattern' option
   * more info: https://github.com/winstonjs/winston-daily-rotate-file#readme
   */
  const loggerFileConf = {
    dirname: LOGFILE_PATH,
    filename: LOGFILE_NAME,
    maxSize: LOGFILE_MAX_SIZE, // create a new log file if the current file size exceeds 20MB
    maxFiles: LOGFILE_LIFE // delete all log files older than 45days
  };

  const myFormat = printf(({ level, message, timestamp }) => {
    return `${timestamp} ${message}`;
  });

  const customLogFormat = combine(
    timestamp(), // timestamp the message was received
    myFormat // formats the logging message
  );

  const winstonTranports = [new winstonDailyLogRotate(loggerFileConf)];

  // Add a console logging if it is a development environment
  NODE_ENV === 'development' &&
    winstonTranports.push(
      new transports.Console({
        level: 'debug',
        handleExceptions: true,
        json: false,
        colorize: true
      })
    );

  /**
   * Creating custom logger to print logs in a file (& console if NODE_ENV==='development')
   */
  const winstonLogger = new createLogger({
    format: customLogFormat,
    transports: winstonTranports,
    exitOnError: false
  });

  // logger write function to pass the message to file stream.
  winstonLogger.stream = {
    write: function(message) {
      // use the 'info'/'error' log level so the output will be picked up by file transport
      winstonLogger.info(message);
      winstonLogger.error(message);
    }
  };

  // Add req_id to log messages
  // req_id is set in httpContext inside app.use() while initializing express app
  const formatMessage = function(message) {
    const req_id = httpContext.get('req_id')
      ? `REQ_ID: ${httpContext.get('req_id')} - `
      : '';
    return req_id + message;
  };

  /**
   * This logger object creates a wrapper for winston_logger methods to overwrite each log_msg with req_id
   *  req_id is used to track control(access) flow of each request's start -> end
   */
  return {
    log: function(level, msg) {
      winstonLogger.log(level, formatMessage(msg));
    },
    error: function(msg) {
      winstonLogger.error(formatMessage(msg));
    },
    warn: function(msg) {
      winstonLogger.warn(formatMessage(msg));
    },
    verbose: function(msg) {
      winstonLogger.verbose(formatMessage(msg));
    },
    info: function(msg) {
      winstonLogger.info(formatMessage(msg));
    },
    debug: function(msg) {
      winstonLogger.debug(formatMessage(msg));
    },
    silly: function(msg) {
      winstonLogger.silly(formatMessage(msg));
    }
  };
};

export default initLogger;
