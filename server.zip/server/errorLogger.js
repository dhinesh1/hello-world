const Sentry = require('@sentry/node');
Sentry.init({
  dsn: 'https://b0135048b5f54f998bb37c61deec4ede@sentry.io/1285610'
});

const logError = (error, extraInfo) => {
  if (!extraInfo) extraInfo = {};

  Sentry.captureException(error, { extra: extraInfo });
};

export default logError;
