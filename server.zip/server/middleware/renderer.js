import React from 'react';
import ReactDOMServer from 'react-dom/server';
import StaticRouter from 'react-router-dom/StaticRouter';
import Loadable from 'react-loadable';
import manifest from '../../build/asset-manifest.json';
import Helmet from 'react-helmet';
import logError from '../errorLogger';

import initLogger from '../accessLogger';

import { Provider as ReduxProvider } from 'react-redux';

// import our main App component
import App from '../../src/App';
import { decycle } from '../../src/helpers/jsonHelper';
import { checkIndexOf } from '../../src/helpers/utilsHelper.js';

// Creating reduxLogger which will have only initial redux objects returned from SSR actions
const reduxLogger = initLogger('redux');

const extractAssets = (assets, chunks) =>
  Object.keys(assets)
    .filter(asset => chunks.indexOf(asset.replace('.js', '')) > -1)
    .map(k => assets[k]);

const path = require('path');
const fs = require('fs');
const util = require('util');
const NODE_ENV = process.env.REACT_APP_NODE_ENV;
const ENABLE_CONTACT = process.env.REACT_APP_ENABLE_CONTACT;
const modules = [];

/**
 * Blacklist internal IP address
 * This function will return true if the req IP is in blacklistIPs array
 * @param {object} req - server request object has to be passed
 */
const isBlacklisted = (req = {}) => {
  if(typeof req.header === 'function') {
    const ipAddress = req.header('x-forwarded-for') || req.connection.remoteAddress;
    const blacklistIPs = ['49.207.181.39', '106.51.2.252', '::1']; // internal ip address and ::1 is for req from localhost 
  
    if(ipAddress && blacklistIPs.includes(ipAddress)) {
      return true;
    }
  }
  return false;
}

export default (store, pdfPageVersion, notFound) => (req, res, next) => {
  // point to the html file created by CRA's build tool
  let filePath = path.resolve(__dirname, '..', '..', 'build', 'index.html');

  // Point to PDF file if the target link is for to createPdf
  if (pdfPageVersion === 2) {
    filePath = path.resolve(__dirname, '..', '..', 'build', 'pdf.html');
  } else if (pdfPageVersion === 1) {
    filePath = path.resolve(__dirname, '..', '..', 'build', 'pdfv1.html');
  }

  fs.readFile(filePath, 'utf8', (err, htmlData) => {
    let context = {};

    if (err) {
      logError(err);
      console.error('err', err);
      return res.status(404).end();
    }

    // render the app as a string
    const html = ReactDOMServer.renderToString(
      <ReduxProvider store={store}>
        <StaticRouter location={req.url} context={context}>
          <Loadable.Capture report={m => modules.push(m)}>
            <App />
          </Loadable.Capture>
        </StaticRouter>
      </ReduxProvider>
    );
    const helmet = Helmet.renderStatic();

    // Retrieve the main.*.js chunk file from assest-manifest.json.
    const mainScript = `<script src="${manifest['main.js']}"><\/script>`;
    const vendorMainScript = `<script src="${
      manifest['vendors~main.js']
    }"><\/script>`;

    /**
     * Add segment script only if the request comes from external IPs.
     * Avoid adding segment script when req IP is internal.
     * replace the segmentsPlaceholder with the segmentsScript string.
     */
    let segmentsScript = '';
    if(!isBlacklisted(req)) {
      segmentsScript = `<script type="text/javascript">
        !function(){var analytics=window.analytics=window.analytics||[];if(!analytics.initialize)if(analytics.invoked)window.console&&console.error&&console.error("Segment snippet included twice.");else{analytics.invoked=!0;analytics.methods=["trackSubmit","trackClick","trackLink","trackForm","pageview","identify","reset","group","track","ready","alias","debug","page","once","off","on"];analytics.factory=function(t){return function(){var e=Array.prototype.slice.call(arguments);e.unshift(t);analytics.push(e);return analytics}};for(var t=0;t<analytics.methods.length;t++){var e=analytics.methods[t];analytics[e]=analytics.factory(e)}analytics.load=function(t,e){var n=document.createElement("script");n.type="text/javascript";n.async=!0;n.src="https://cdn.segment.com/analytics.js/v1/"+t+"/analytics.min.js";var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(n,a);analytics._loadOptions=e};analytics.SNIPPET_VERSION="4.1.0";
          analytics.load('${process.env.REACT_APP_SEGMENTS_KEY}');
        }}();
      </script>`;
    }
    /**
     * ! DO NOT CHANGE THIS PLACEHOLDER TEXT
     * ! Same text is added in index.html - both needs to be updated on the same time
     */
    const segmentsPlaceholder = `<script type="text/javascript">window.analytics=null</script>`;

    // ** DO NOT REMOVE - SSR Will not work properly **
    // Redux state placeholder
    const ReduxPlaceholder =
      '<script type=\'text/javascript\'>window.REDUX_STATE = "__SERVER_REDUX_STATE__";</script>';
    // ** DO NOT REMOVE - SSR Will not work properly **

    // Replace the main.*.chunk.js & vendor.main.*.chunk.js file from the last position and adding it to the first position.
    let finalHtml = htmlData
      .replace(mainScript, '')
      .replace(vendorMainScript, '')
      .replace(segmentsPlaceholder, segmentsScript)
      .replace(
        '<div id="root"></div>',
        `<div id="root">${html}</div>${ReduxPlaceholder}<script src="${
          manifest['vendors~main.js']
        }" rel="preload"></script><script src="${
          manifest['main.js']
        }" rel="preload"></script>`
      );

    // Title and meta
    let titleEle = helmet.title.toString();

    if (notFound || (context.url && context.url === '/404')) {
      titleEle = '<title>404 Page not found</title>';
    } else if (
      !pdfPageVersion &&
      (!titleEle.length ||
        titleEle === '<title data-react-helmet="true"></title>')
    ) {
      titleEle = '<title>pickyourtrail</title>';
    }

    let metaDescEle = helmet.meta.toString();
    let linkEle = helmet.link.toString();

    let canonicalLinkForPackages = '';

    if (
      req.route.path === '/packages' ||
      req.route.path === '/packages/:destination' ||
      req.route.path === '/:theme-packages' ||
      req.route.path === '/:theme-packages/:destination'
    ) {
      let cURL =
        NODE_ENV === 'production'
          ? `https://pickyourtrail.com`
          : NODE_ENV === 'staging'
            ? 'https://staging.pickyourtrail.com'
            : 'https://dev.pickyourtrail.com';

      switch (req.route.path) {
        case '/packages/:destination':
          cURL += `/packages/${req.params.destination}`;
          break;
        case '/:theme-packages':
          cURL += `/${req.params.theme}-packages`;
          break;
        case '/:theme-packages/:destination':
          cURL += `/${req.params.theme}-packages/${req.params.destination}`;
          break;
        default:
          cURL += '/packages';
          break;
      }

      canonicalLinkForPackages = '<link href="' + cURL + '" rel="canonical" />';
    }

    finalHtml = finalHtml.replace(
      '</head>',
      titleEle + metaDescEle + linkEle + canonicalLinkForPackages + '</head>'
    );

    const extraChunks = extractAssets(manifest, modules).map(
      c => `<script type="text/javascript" src="/${c}"></script>`
    );

    finalHtml = finalHtml.replace('</body>', extraChunks.join('') + '</body>');

    // console.log(store.getState());
    // console.log(util.inspect(store.getState(), { showHidden: true, depth: null, compact: true, breakLength: 100 } ));
    const appObj = store.getState().app;
    appObj.showContactNumber = ENABLE_CONTACT;
    const _initialReduxState = Object.assign(store.getState(), { app: appObj });

    // Decylcing JSON to handle circular JSON issue
    const reduxState = JSON.stringify(decycle(_initialReduxState));

    // Recording redux logger only for packages, vacations or payment urls
    if(NODE_ENV === "production" && checkIndexOf(req.path, ['packages','vacations','payment'])){      
      // Adding the entire Redux store to figure out the circular JSON issue
      reduxLogger.info('INITIAL REDUX STORE: ' + reduxState);
    }

    finalHtml = finalHtml.replace('"__SERVER_REDUX_STATE__"', reduxState);

    // console.log('Context: ', context);
    // console.log('**** req req.query: ', req.query);
    // console.log('**** req req.headers.host: ', req.headers);

    let status = context.status || 200;
    // TO handle redirection from Client side router
    if ((context.url && context.url === '/404') || notFound) {
      status = 404;
    }

    // inject the rendered app into our html and send it
    return res
      .status(status)
      .send(finalHtml)
      .end();
  });
};
