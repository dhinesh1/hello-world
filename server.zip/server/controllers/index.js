import express from 'express';
import device from 'express-device';

import serverRenderer from '../middleware/renderer';
import configureStore from '../../src/store/configureStore';
import {
  fetchTestimonials,
  paymentFailure,
  fetchDataForPDF,
  getPackages,
  processPaymentSuccess,
  fetchSEOMetaInfo,
  fetchJobDetail,
  fetchBannerImage,
  getPreferencesContent,
  fetchFooterData
} from '../../src/actions/actions_app';
import logError from '../errorLogger';
import initLogger from '../accessLogger';
import { getSitemapData } from '../../src/actions/actions_sitemap_app';
import { getPackageKeyFromPathname } from '../../src/helpers/utilsHelper';

import { getXMLData } from '../index';

import { AppConfig } from '../../src/app-config';
import { ServerConfig } from '../server-config';
import { getCareersContent } from '../../src/actions/actions_static_pages';
const API_URL = AppConfig.api_url;

// Creating logger for common logging - initLogger without any param will create access log
const logger = initLogger();
const router = express.Router();
const path = require('path');
const redis = require('redis');

router.use(device.capture());

// Redis connect arguments from config
const RedisHost = ServerConfig.redis_host;
const RedisPort = ServerConfig.redis_port;
const RedisPass = ServerConfig.redis_pass;

export const getLandingData = reqObj => dispatch => {
  //passing the multiple actions for the SEO and banner image details.
  return Promise.all([
    dispatch(fetchSEOMetaInfo(reqObj)),
    dispatch(fetchBannerImage()),
    dispatch(fetchFooterData())
  ]);
};

const actionIndex = (req, res, next) => {
  if (req.url === '/?source=user_profile---------------------------') {
    res.redirect(301, req.path).end();
  } else {
    const { store } = configureStore(req.url);
    let reqData = {
      seoId: 'INDEX',
      term: '',
      device: req.device.type
    };

    store
      .dispatch(getLandingData(reqData))
      .then(result => {
        serverRenderer(store)(req, res, next);
      })
      .catch(error => {
        logError(error);
        serverRenderer(store)(req, res, next);
      });
  }
};
// TODO: Should capture footer data in redis
const actionFooter = (req, res, next) => {
  const { store } = configureStore(req.url);
  store
    .dispatch(fetchFooterData())
    .then(() => {
      serverRenderer(store)(req, res, next);
    })
    .catch(error => {
      logError(error);
      serverRenderer(store)(req, res, next);
    });
};
const actionIndiaTravelTrends = (req, res, next) => {
  const { store } = configureStore(req.url);
  let reqData = {
    seoId: '2018_TRAVEL_TRENDS',
    term: ''
  };

  store
    .dispatch(fetchSEOMetaInfo(reqData))
    .then(result => {
      serverRenderer(store)(req, res, next);
    })
    .catch(error => {
      logError(error);

      serverRenderer(store)(req, res, next);
    });
};

export const getTestimonialsData = reqObj => dispatch => {
  return Promise.all([
    dispatch(fetchTestimonials(reqObj)),
    dispatch(fetchFooterData())
  ]);
};

export const getPDFData = reqObj => dispatch => {
  return dispatch(fetchDataForPDF(reqObj));
};

export const getPaymentFailureData = reqObj => dispatch => {
  return dispatch(paymentFailure(reqObj));
};

const actionTestimonials = (req, res, next) => {
  const { store } = configureStore(req.url);
  let reqObj = {
    triptypes: [],
    regions: []
  };

  store.dispatch(getTestimonialsData(reqObj)).then(result => {
    serverRenderer(store)(req, res, next);
  });
};

const actionCreatePDF = (req, res, next) => {
  const { store } = configureStore(req.url);

  store.dispatch(getPDFData(req.params.itineraryId)).then(result => {
    serverRenderer(store, 2)(req, res, next);
  });
};

const actionCreatePDFv1 = (req, res, next) => {
  const { store } = configureStore(req.url);

  store.dispatch(getPDFData(req.params.itineraryId)).then(result => {
    serverRenderer(store, 1)(req, res, next);
  });
};

const actionPaymentProcessing = (req, res, next) => {
  const {store} = configureStore(req.url);
  // Instead of just load the response to Redux store - we will trigger the verify API call
  // with the received data to ensure it got reached our backend server / DB.
  // Also payment response will be loaded into store for further references.
  store
    .dispatch(processPaymentSuccess(req.body || {}, req.params))
    .then(() => {
      serverRenderer(store)(req, res, next);
    })
    .catch(err => {
      logger.error(`Payment Response Error: ${err && JSON.stringify(err)}`);
      serverRenderer(store)(req, res, next);
    });
};

const actionPaymentFailure = (req, res, next) => {
  const { store } = configureStore(req.url);
  let reqObj = req.body;

  logger.info('Inside actionPaymentFailure: ' + JSON.stringify(reqObj));
  // store.dispatch(setMessage(req.body.message));
  // serverRenderer(store)(req, res, next);

  store.dispatch(getPaymentFailureData(reqObj)).then(result => {
    logger.info(
      'Result as received in getPaymentFailureData, Params: ' +
        JSON.stringify(result)
    );
    serverRenderer(store)(req, res, next);
  });
};

const getPackageRequestObject = (req, key) => {
  let reqObj = {
    key: key,
    testimonials: 10,
    limit: 50,
    journalTestimonials: true
  };

  if (req.query.durations) {
    if (typeof req.query.durations === 'string') {
      reqObj.durations = [req.query.durations];
    } else {
      reqObj.durations = req.query.durations;
    }
  }

  if (req.query.budgets) {
    if (typeof req.query.budgets === 'string') {
      reqObj.budgets = [req.query.budgets];
    } else {
      reqObj.budgets = req.query.budgets;
    }
  }

  if (req.query.hotel_ratings) {
    if (typeof req.query.hotel_ratings === 'string') {
      reqObj.hotelRatings = [req.query.hotel_ratings];
    } else {
      reqObj.hotelRatings = req.query.hotel_ratings;
    }
  }

  return reqObj;
};

// Packages actions
export const getPackagesData = reqObj => dispatch => {
  return dispatch(getPackages(reqObj));
};

/**
 * @author Jothisankar
 * @type method
 * @description "Will be used as fall-back action for all other routes pre-defined for SSR
 * Also it will check the Redis for valid URL pattern - if matches then proceed with SSR process otherwise pass the request to CSR"
 */
const actionFallback = (req, res, next) => {
  const { store } = configureStore(req.url);
  const key = getPackageKeyFromPathname(req.url);

  // Init redis connection
  /**
   * Moving redis init config here to avoid open un-wanted connection for other pages
   */
  const redisClient = redis.createClient({
    host: RedisHost,
    port: RedisPort,
    password: RedisPass
  });

  redisClient.HEXISTS('campaign_urls', key, (err, exists) => {
    if (exists) {
      const reqObj = getPackageRequestObject(req, key);

      store
        .dispatch(getPackagesData(reqObj))
        .then(() => {
          serverRenderer(store)(req, res, next);
        })
        .catch(error => {
          if (error.response && error.response.status === 404) {
            serverRenderer(store, false, true)(req, res, next);
          } else {
            serverRenderer(store)(req, res, next);
          }
        });
    } else {
      console.log('URL not found in Redis: ');

      // If the requested pathname is not found in Redis cache we will render
      // the empty the application to validate the req in CSR routes at the client end.
      serverRenderer(store)(req, res, next);
    }
  });

  // Closing opened connection
  redisClient.quit();
};

const actionGetPackages = (req, res, next) => {
  const { store } = configureStore(req.url);
  const key = getPackageKeyFromPathname(req.url);

  const reqObj = getPackageRequestObject(req, key);

  store
    .dispatch(getPackagesData(reqObj))
    .then(() => {
      serverRenderer(store)(req, res, next);
    })
    .catch(error => {
      if (error.response && error.response.status=== 404) {
        serverRenderer(store, false, true)(req, res, next);
      } else {
        serverRenderer(store)(req, res, next);
      }
    });
};

export const getGetPackingData = reqObj => dispatch => {
  return dispatch(fetchSEOMetaInfo(reqObj));
};

const actionGetPacking = (req, res, next) => {
  const { store } = configureStore(req.url);
  let reqData = {
    seoId: 'GET_PACKING',
    term: req.params.destination
  };

  store.dispatch(getGetPackingData(reqData)).then(() => {
    serverRenderer(store)(req, res, next);
  });
};

// Site-map actions
export const getSitemapDataRequest = reqObj => dispatch => {
  return dispatch(getSitemapData(reqObj));
};

const actionSitemap = (req, res, next) => {
  const { store } = configureStore(req.url);
  store
    .dispatch(getSitemapDataRequest({}))
    .then(result => {
      serverRenderer(store)(req, res, next);
    })
    .catch(error => {
      serverRenderer(store, false, true)(req, res, next);
    });
};

const actionSem = (req, res, next) => {
  const { store } = configureStore(req.url);
  serverRenderer(store)(req, res, next);
};

// Careers page actions
export const getGetCareersPageData = reqObj => dispatch => {
  let carreersDispatches = [
    dispatch(getCareersContent()),
    dispatch(fetchFooterData())
  ];
  if (reqObj && reqObj !== '') {
    carreersDispatches.push(dispatch(fetchJobDetail(reqObj)));
  }
  return Promise.all(carreersDispatches);
};

const actionCareers = (req, res, next) => {
  const { store } = configureStore(req.url);

  store
    .dispatch(getGetCareersPageData(req.params.currentOpeningKey))
    .then(result => {
      serverRenderer(store)(req, res, next);
    });
};

// Careers page actions
export const getGetPreferencesPageData = reqObj => dispatch => {
  let prefDispatches = [
    dispatch(getPreferencesContent(reqObj)),
    dispatch(fetchFooterData())
  ];
  return Promise.all(prefDispatches);
};

const actionGetPreferences = (req, res, next) => {
  const { store } = configureStore(req.url);

  store
    .dispatch(getGetPreferencesPageData(req.params.code))
    .then(result => {
      serverRenderer(store)(req, res, next);
    });
};

// To remove trailing slashes from URL
router.use(function(req, res, next) {
  if (
    req.path.length > 1 &&
    /\/$/.test(req.path) &&
    !/^\/static*/.test(req.path)
  ) {
    let query = req.url.slice(req.path.length);

    res.redirect(301, req.path.slice(0, -1) + query);
  } else {
    next();
  }
});

// To Redirect to all lowercase URLs
router.use(function(req, res, next) {
  if (
    req.path.length > 1 &&
    !/^\/static*/.test(req.path) &&
    !/\/view*/.test(req.path) &&
    !/\/inclusion*/.test(req.path) &&
    !/\/payment*/.test(req.path)
  ) {
    if (/[A-Z]/.test(req.path)) {
      let query = req.url.slice(req.path.length);
      res.redirect(301, req.path.toLowerCase() + query);
    } else {
      next();
    }
  } else {
    next();
  }
});

// root (/) should always serve our server rendered page

/**
 * URL: `/payment/processing/:type?/:itineraryid?/:transid?`
 * @param {string} type - payment type
 * @param {string} itineraryid - itinerary id to which the payment is made
 * @param {string} transid - transaction id of the current payment
 * Description: This is a post payment processing urls for success/failure/cancel cases.
 * There are two Req methods for payment/processing URL.
 * Users will be redirected to this page from the Payment Gateway(PG) once payment is done(success/failure/canceled).
 * We are using same url for face all scenarios.
 * In few PGs, cancel url will be triggered as GET request (Eg., Razorpay)
 * 1. GET method - this url is triggered when user's cancel their payment on our PG page.(not for all PGs)
 * 2. POST method - this url is trigged with post data from PG once the payment is done/failure.
 *
 * For payU, success/failure/cancel will hit this url by POST method
 * For Razorpay success will hit this url by POST method and other types will be GET req
 *
 * To handle this different scenarios, we are using .get & .post with same actionCallback methods
 * This will help us to maintain different scenarios even for PGs that are yet to come.
 */
router.get(
  '/payment/processing/:type?/:itineraryid?/:transid?',
  actionPaymentProcessing
);
router.post(
  '/payment/processing/:type?/:itineraryid?/:transid?',
  actionPaymentProcessing
);

router.post('/payment/failure', actionPaymentFailure);
router.get('/testimonials', actionTestimonials);

// Careers page
router.get('/careers/:currentOpeningKey?', actionCareers);

// About us
router.get('/about-us', actionFooter);

// Unsubscribe
router.get('/unsubscribe/:code', actionGetPreferences);

// Guides
router.get('/guides', actionFooter);

// Contact us
router.get('/contact-us', actionFooter);

// cancellation policy
router.get('/cancellation-policy', actionFooter);

// Privacy policy
router.get('/privacy-policy', actionFooter);

// FAQ
router.get('/faq', actionFooter);

// Terms and conditions
router.get('/terms-and-conditions', actionFooter);

router.get(
  '/2018-travel-trends-international-vacations-ideas',
  actionIndiaTravelTrends
);

/**
 * Redirecting old view/:itineraryId to /customize/region/view/:itineraryId
 */
router.get('/view/:itineraryId', (req, res, next) => {
  res.redirect(301, "/customize/region"+req.url);
});

router.get('/404', (req, res, next) => {
  const { store } = configureStore(req.url);
  serverRenderer(store, false, true)(req, res, next);
});

// End point to create sitemap
router
  .route('/sitemap/generate')
  .post(async function(req, res, next) {
    if (req.body.auth !== 'wwmib3112#') {
      return res.sendStatus(403).end();
    }

    return await Promise.all([
      getXMLData(`${API_URL}misc/generateSitemap`, 'sitemap.xml'),
      getXMLData(
        `${API_URL}misc/generateSitemapItineraries`,
        'sitemap-itineraries.xml'
      )
    ]).then(values => {
      return res
        .status(200)
        .send(values)
        .end();
    });
  })
  .all(function(req, res, next) {
    return res.sendStatus(400).end();
  });

// Site-map Route
router.get('/all', actionSitemap);

// Packages Routes - This config will help us reduce the round trip ( Redis check -> call the API ) for such know routes
router.get('/packages', actionGetPackages);
router.get('/packages/:destination', actionGetPackages);
router.get('/:theme-packages', actionGetPackages);
router.get('/:theme-packages/:destination', actionGetPackages);

// Vacations Routes - This config will help us reduce the round trip ( Redis check -> call the API ) for such know routes
router.get('/vacations/:destination', actionGetPackages);
router.get('/vacations/:destination/:city', actionGetPackages);
router.get('/:theme-vacations/:destination', actionGetPackages);
router.get('/:theme-vacations/:destination/:city', actionGetPackages);

// New paid campaign page Route - SEM
router.get('/holidays/:destination', actionSem);

// PDF Routes
router.get('^/cost/:itineraryId/createPdf$', actionCreatePDFv1);
router.get('^/cost/:itineraryId/createPdf/v2$', actionCreatePDF);

// Post-card page Route
router.get('^/get-packing/:destination', actionGetPacking);

// Landing page Route
router.get('/', actionIndex);

// other static resources should just be served as they are
router.use(
  express.static(path.resolve(__dirname, '..', '..', 'build'), {
    maxAge: '30d' // Static resources expiration will be set as 30 days
  })
);

// Fallback Route to handle any other requests
router.get(/^\/(.*)/, actionFallback);

export default router;
