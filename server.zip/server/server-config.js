const NODE_ENV = process.env.REACT_APP_NODE_ENV;

let REDIS_HOST = '127.0.0.1';
let REDIS_PORT = 6379;
let REDIS_PASS = 'wWm!b3112#';

if (NODE_ENV === 'production') {
  REDIS_HOST = '172.31.2.27';
}

export const ServerConfig = {
  redis_host: REDIS_HOST,
  redis_pass: REDIS_PASS,
  redis_port: REDIS_PORT
};
