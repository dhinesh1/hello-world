/**
 * WebEngage script for Push notifications
 */

importScripts('https://ssl.widgets.webengage.com/js/service-worker.js');