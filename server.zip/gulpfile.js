'use strict';

const fs = global.fs = global.fs || require('fs');
const gulp = global.gulp = global.gulp || require('gulp');
const shelljs = require('shelljs');

const regexp = {
  COMMIT_TYPES: /^(([A-Za-z0-9]+[-][0-9]*))?\ :(.*)$/
};

const purgecss = require('gulp-purgecss');

/**
 * Git commit message validator
 */
gulp.task('commit-message', function (done) {
    // Get commit message from git commit edit message file   
  let msg = fs.readFileSync('.git/COMMIT_EDITMSG', 'utf8');
    msg = msg.split('\n').join(' ');
    if (!RegExp(regexp.COMMIT_TYPES).test(msg)) {
      const error = '\n The template: \n <jira-id>{spac}: <summary> \n\n Example: \n PWA-01 : Fixed bug \n\n';
      // console.log(error);
        process.exitCode = 1;
    }
    else {
        // Allow git commit
        process.exitCode = 0;
    }
    done();
});

/**
 * detect duplicate codes
 */
gulp.task('duplicate', function () {
    const jscpd = require('jscpd-html-reporter');
    const source = './src/**/*.js';
    const dir = './reports/dedupe';
    if (!fs.existsSync(dir)) {
        shelljs.mkdir('-p', dir);
    }
    return gulp.pipe(jscpd({
        outDir: './reports/dedupe',
        outFileName: 'jscpd-report.html',
        files: source,
        exclude: ['./src/__actions__/*.js', './src/__fixtures__/*.js', './src/__tests__/*.js']
    }));
});

/**
 * remove unused css 
 */
gulp.task('purgecss', () => {
    return gulp
      .src('build/static/css/*.css')
      .pipe(
        purgecss({
          content: ['build/static/js/*.js']
        })
      )
      .pipe(gulp.dest('build/static/'))
  });


