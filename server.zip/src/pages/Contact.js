import React, { Component } from 'react';
import { openChatWidget } from '../helpers/utilsHelper';
import { Helmet } from 'react-helmet';
import { connect } from 'react-redux';
import { AppConfig } from '../app-config';
import { trackEvent, EVENT_CHAT_REQUESTED } from '../helpers/ML/EventsTracker';
const CONTACT_NUMBER = AppConfig.website_contact_number;

class Contact extends Component {
  render() {
    const ENABLE_CONTACT_NUMBER =
      this.props.showContactNumber || AppConfig.enable_Contact_Number;
    return (
      <div className="clearfix contact-us">
        <Helmet>
          <title>Contact Us | Pickyourtrail</title>
          <meta
            name={'description'}
            content={`Planning a Trip? Unhappy experience? Partner with us! Work with us! Give us a call at +91 ${CONTACT_NUMBER} or reach out to us: vacations@pickyourtrail.com`}
          />
        </Helmet>

        <section className="map">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.867896963804!2d80.2396404145083!3d13.044079590808325!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5267f92beff22d%3A0xa589bcbc58df5b50!2sPickyourtrail+(Rocketship)!5e0!3m2!1sen!2sin!4v1548059474963"
            frameBorder="0"
            width="100%"
          />
        </section>
        <section className="container">
          <h1 className="large-heading bold color-primary">Talk to us</h1>
          <div className="row">
            <div className="col-sm-4">
              <h4 className="subheading">PLANNING A TRIP?</h4>
              <ul className="list-unstyled">
                {ENABLE_CONTACT_NUMBER ? (
                  <li>
                    <a href={`tel:+91${CONTACT_NUMBER}`}>
                      <i className="vehoicon-phone_iphone" />+91{' '}
                      {CONTACT_NUMBER}
                    </a>
                  </li>
                ) : null}
                <li>
                  <a href="mailto:planners@pickyourtrail.com">
                    <i className="vehoicon-envelope" />planners@pickyourtrail.com
                  </a>
                </li>
                <li>
                  <a href="#" onClick={() => {
                      trackEvent(EVENT_CHAT_REQUESTED, {
                        element_type: 'button',
                        element_name: 'btn_chat_requested_contact_us'
                      });
                      openChatWidget();
                    }
                  }>
                    <i className="vehoicon-chat_bubble" />Chat with our travel
                    consultant
                  </a>
                </li>
              </ul>
            </div>
            <div className="col-sm-4">
              <ul className="list-unstyled secondary-list">
                <li>
                  <span className="subheading">UNHAPPY EXPERIENCE?</span>
                  <a href="mailto:happiness@pickyourtrail.com">
                    <i className="vehoicon-envelope" />happiness@pickyourtrail.com
                  </a>
                </li>
                <li>
                  <span className="subheading">PARTNER WITH US</span>
                  <a href="mailto:partners@pickyourtrail.com">
                    <i className="vehoicon-envelope" />partners@pickyourtrail.com
                  </a>
                </li>
                <li>
                  <span className="subheading">WORK WITH US</span>
                  <a href="mailto:careers@pickyourtrail.com">
                    <i className="vehoicon-envelope" />careers@pickyourtrail.com
                  </a>
                </li>
                <li>
                  <span className="subheading">WRITE TO US</span>
                  <a href="mailto:editors@pickyourtrail.com">
                    <i className="vehoicon-envelope" />editors@pickyourtrail.com
                  </a>
                </li>
              </ul>
            </div>
            <div className="col-sm-4">
              <h4 className="subheading">ADDRESS</h4>

              <p className="dim">
                <strong>Pickyourtrail (Base)</strong>
                <br />No:59, Ground Floor,<br />Vijayaraghava Road, T.Nagar,<br />(Near
                Andhra Club, Parthasarathi Puram)<br />Chennai 600017,
                Tamilnadu, India.
              </p>

              <p className="dim">
                <strong>Pickyourtrail (Rocketship)</strong>
                <br />No:36, Sudhama Commercial Building,<br />3rd Floor,
                Vijayaraghava Road,<br />Parthasarathi Puram, T.Nagar,<br />Chennai
                600017, Tamilnadu, India.<br />
                <a
                  target="_blank"
                  href="https://goo.gl/maps/pQMTnQhU71D2"
                  rel="noopener noreferrer"
                >
                  <span className="color-primary-dark">Get directions</span>
                </a>
              </p>
            </div>
          </div>
        </section>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    showContactNumber: parseInt(state.app.showContactNumber)
  };
}

function mapDispatchToProps() {
  return {
    actions: {}
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Contact);
