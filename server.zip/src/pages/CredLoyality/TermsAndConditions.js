import React, { Component } from 'react';
import { Helmet } from 'react-helmet';

export default class CredTermsAndConditions extends Component {
  render() {
    return (
      <section className="static-pages">
        <Helmet>
          <title>Terms & Conditions | Pickyourtrail - Cred</title>
        </Helmet>

        <div className="static-header">
          <h1>Terms &amp; Conditions for Cred</h1>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-md-10 col-md-offset-1">
              <div className="static-content">
                <ul>
                  <li>Coupons are valid for a limited time only. Pickyourtrail reserves the right to modify or cancel coupons at any time.</li>
                  <li>Coupon will not be applicable if any inclusion is removed from the itinerary.</li>
                  <li>The coupon offer will not be valid until it is applied to the qualifying itinerary</li>
                  <li>The coupon may only be used on <a href="https://pickyourtrail.com/cred-bali?cpid=cred-terms-and-conditions">cred link</a></li>
                  <li>The promotion is limited to two PAX per trail.</li>
                  <li>The coupon may not be combinable with any other coupon programmes.</li>
                  <li>The coupon can only be used once and will be treated as fully redeemed once a qualifying itinerary has been booked.</li>
                  <li>The coupon code has no cash value and no refunds or cash alternative will be offered.</li>
                  <li>The coupon code may not be re-used, even in the event that you change or cancel the booking.</li>
                  <li>Flights are not included in the itinerary.</li>
                  <li>Pickyourtrail has no obligation for payment of any tax in conjunction with the distribution or use of any coupon.</li>
                  <li>Consumer is required to pay any applicable GST related to the use of the coupon.</li>
                  <li>Coupons are void if restricted or prohibited by law.</li>
                  <li>The coupon is not necessarily valid for all periods of the year. There may be periods, particularly during the seasons, for which the coupon may not be usable.</li>
                  <li>For the coupon to be applicable, the trail should be booked at least 15 days in advance to departure.The coupon is only available on the hotels selected by Pickyourtrail.</li>
                  <li>The coupon may be applicable only to regions selected by Pickyourtrail.</li>
                  <li>The booking is subject to the availability of hotel selected provided in the itinerary.</li>
                  <li>Voucher may be applicable only if Pickyourtrail’s payment policy is followed.</li>
                  <li>The coupon code is void where prohibited by law. Improper use of the coupon code by you including but not limited to publication or selling of the coupon code is prohibited, will result in the voiding of the coupon codes use, and may constitute fraud.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
}
