import React, { Component } from "react";
import Slider from "react-slick";
import LazyLoad from "react-lazyload";
import { filter } from "lodash";
import { Link } from "react-scroll";
import { CredCard, CarouselImage } from "./components";
import { getImgIXUrl, isFaqMobile } from "../../helpers/utilsHelper";
import SmartImage from "../../common_components/Image/smart_image";
import { Link as RouterLink } from 'react-router-dom';

class CredLoyality extends Component {
  constructor(props) {
    super(props);
    this.state = {
      itineraries: [],
      allItineraries: [],
      filterValues: [],
      imgUrls: [],
      locationVideoUrl: '',
      dropDownClass: 'dropdown',
      appliedfilter: {
        from: 0,
        to: null,
        label: 'All Options'
      }
    };
    this.fetchCredData = this.fetchCredData.bind(this);
  }

  componentDidMount() {
    document.body.className = document.body.className + ' cred-bg';
    this.fetchCredData();
  }

  componentWillUnmount() {
    let currentClass = document.body.className;
    document.body.className = currentClass.replace('hide', '');
  }

  async fetchCredData() {
    const headers = new Headers({
      'Content-Type': 'application/json'
    });
    const requestDetails = {
      method: 'GET',
      headers
    };
    await fetch(
      'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/web_app/cred/json/credData.json',
      requestDetails
    )
      .then(response => {
        if (!response.ok) {
          throw new Error('---HTTP error---' + response.status);
        }
        return response.json();
      })
      .then(json => {
        const credData = json.credData;

        this.setState({
          itineraries: credData.itineraryData,
          allItineraries: credData.itineraryData,
          filterValues: credData.filterValues,
          imgUrls: credData.imgUrls,
          locationVideoUrl: credData.locationVideoUrl
        });
      })
      .catch(error => {
        console.log('----error-----', error);
        return error;
      });
  }

  updateDropDownClass = () => {
    if (this.state.dropDownClass.indexOf('open') > -1) {
      this.setState({
        dropDownClass: 'dropdown'
      });
    } else {
      this.setState({
        dropDownClass: 'dropdown open'
      });
    }
  };

  updateFilter = values => {
    const newData = filter(this.state.allItineraries, itinerary => {
      const price = parseInt(itinerary.finalPrice.split(',').join(''));
      if (values.to) {
        return price >= values.from && price <= values.to;
      }
      return price >= values.from;
    });
    this.updateDropDownClass();
    this.setState({
      itineraries: newData,
      appliedfilter: values
    });
  };

  render() {
    const {
      filterValues,
      itineraries,
      imgUrls,
      locationVideoUrl,
      dropDownClass,
      appliedfilter
    } = this.state;
    const filterOptions = filterValues.map(filter => {
      return (
        <li key={filter.label}>
          <label className="custom-options">
            <input
              name="priceRange"
              type="radio"
              defaultValue={filter.label}
              onClick={() =>
                this.updateFilter({
                  from: filter.from,
                  to: filter.to,
                  label: filter.label
                })
              }
              defaultChecked={filter.label === appliedfilter.label}
            />
            <span>{filter.label}</span>
            <i />
          </label>
        </li>
      );
    });

    const cards = itineraries.map((obj, index) => {
      return (
        <CredCard
          backgroundImage={obj.backgroundImage}
          categoryName={obj.categoryName}
          originalPrice={obj.originalPrice}
          title={obj.title}
          locations={obj.locations}
          inclusions={obj.inclusions}
          finalPrice={obj.finalPrice}
          itinerarySlug={obj.itinerarySlug}
          key={index}
        />
      );
    });

    const itemsToSlide = imgUrls.map((url, index) => {
      return <CarouselImage url={url} key={index} />;
    });

    return (
      <div className="cred-page">
        <div className="container xs-full-width">
          <section className="row">
            <div className="col-md-12">
              <div className="hero-unit">
                <a href="#">
                  <img
                    src={getImgIXUrl(
                      'https://pyt-images.imgix.net/images/web_app/logo/pickyourtrail-logo-white.svg'
                    )}
                    alt="PickYourTrail.com - Build, Customize and Book personalized vacations!"
                    width={180}
                  />
                </a>
                <div className="mid-content">
                  <h1>We’ve come together to double your happiness.</h1>
                  <Link
                    activeClass="active"
                    className="cursor-pointer"
                    to="filter"
                    spy={true}
                    smooth={true}
                    offset={10}
                    duration={800}
                  >
                    VIEW BALI DEALS
                  </Link>
                  <img
                    height={16}
                    src="https://d3lf10b5gahyby.cloudfront.net/web_app/cred/partership-text.png"
                    alt="IN PARTNERSHIP WITH CRED"
                  />
                </div>
                <Link
                  activeClass="active"
                  className="scroll-down cursor-pointer"
                  to="section-1"
                  spy={true}
                  smooth={true}
                  offset={-50}
                  duration={800}
                >
                  <i className="vehoicon-keyboard_arrow_down" />
                </Link>
              </div>
            </div>
          </section>
          <section id="section-1" className="row grid-content">
            <div className="col-xs-12 col-sm-6 col-md-6 xs-col-padding">
              <h3>
                For starters, we’re sharing costs. 3 nights in Ubud, on us.
              </h3>
              <p>
                You know what’s better than a free t-shirt, some random gift
                coupons or a free pizza even? 3 nights paid for in Ubud. We’re
                upping the ante on these rewards, and there’s absolutely no
                reason why you shouldn’t take advantage of this deal.
              </p>
              <a className="explore-link" href="/guides/bali" target="_blank">
                <SmartImage
                  src={
                    'https://pyt-images.imgix.net/images/web_app/cred/compass.png'
                  }
                  defaultImage={
                    'https://pyt-images.imgix.net/images/web_app/cred/compass.png'
                  }
                  alt={'Compass'}
                  height={isFaqMobile() ? 280 : 100}
                />EXPLORE UBUD, BALI
              </a>
            </div>
            <div className="col-xs-12 col-sm-6 col-md-6">
              <div className="media-container">
                <div className="embed-responsive embed-responsive-4by3">
                  <LazyLoad offset={100} once={true} height={isFaqMobile() ? 280 : 100}>
                    <iframe
                      className="embed-responsive-item"
                      src={locationVideoUrl}
                      frameBorder={0}
                    />
                  </LazyLoad>
                </div>
              </div>
            </div>
          </section>
          <div>
            <section className="row grid-content">
              <div className="col-xs-12 col-sm-6 col-sm-push-6 col-md-6 xs-col-padding">
                <h3>
                  You and your +1 get to stay at the beautiful Alam Puisi Villa.
                </h3>
                <p>
                  Located in the community of Banjar Sembuwuk in the Village of
                  Pejeng in Ubud, the property is comprised of 27 separate
                  villas, each with its own separate pool and a bale bengong
                  (meditation pavilion).
                </p>
                <a className="explore-link hide" href="#">
                  <img
                    src={getImgIXUrl(
                      'https://pyt-images.imgix.net/images/web_app/cred/villa.png'
                    )}
                    alt="Villa"
                  />
                  EXPLORE ALAM PUISI
                </a>
              </div>
              <div className="col-xs-12 col-sm-6 col-sm-pull-6 col-md-6">
                <div className="media-container">
                  <div className="picture-slider slick-initialized slick-slider">
                    <Slider>{itemsToSlide}</Slider>
                  </div>
                </div>
              </div>
            </section>
          </div>
          <section className="row grid-content v-center">
            <div className="col-xs-12 col-sm-6 col-sm-push-6 col-md-6 text-center">
              <SmartImage
                className={'red-logo'}
                src={
                  'https://pyt-images.imgix.net/images/web_app/cred/red-circle.png'
                }
                defaultImage={
                  'https://pyt-images.imgix.net/images/web_app/cred/red-circle.png'
                }
                alt={'Welcome to Bali'}
                height={isFaqMobile() ? 280 : 100}
              />
            </div>
            <div className="col-xs-12 col-sm-6 col-sm-pull-6 col-md-6 xs-col-padding">
              <h2 className="mbottom-large">
                We’ve curated trips for all your preferences.
              </h2>
              <p>
                Be it a getaway from the monotony of daily work, a scuba trip or
                a cultural extravaganza, we’ve got packages that have been
                specially curated to tend to all your tastes.
              </p>
              <div className="clearfix fw logo-marks">
                <img
                  width={48}
                  src={getImgIXUrl(
                    'https://pyt-images.imgix.net/images/web_app/logo/logo-mark-white.svg'
                  )}
                  alt="pickyourtrail"
                />
                <span>+</span>
                <img
                  src={getImgIXUrl(
                    'https://pyt-images.imgix.net/images/web_app/cred/cred-logo-mark.png'
                  )}
                  alt="Cred"
                />
              </div>
              <div id="filter" className={dropDownClass}>
                <div
                  className="dropdown-toggle"
                  data-toggle="dropdown"
                  onClick={this.updateDropDownClass}
                >
                  Budget<span className="dd-val">{appliedfilter.label}</span>
                </div>
                <ul className="dropdown-menu">{filterOptions}</ul>
              </div>
              <p className="note-text">
                *Itineraries available to CRED users do not include flights.
              </p>
            </div>
          </section>
          {cards.length > 0 ? (
            <section className="row row-eq-hgt padding-12">{cards}</section>
          ) : (
            <section className="row padding-12">
              <div className="col-md-12 text-center">
                <p className="meta-text color-grey mbottom-large">
                  Sorry! No itineraries are available for the selected range
                </p>
              </div>
            </section>
          )}
          <section className="row">
            <div className="col-md-12">
              <p className="small-text mb-0 text-center">
                © Copyright 2019 Travel Troops Pvt. Ltd | <RouterLink target="_blank" to={"/cred-bali/terms-and-conditions"}>Terms & Conditions</RouterLink>
              </p>
            </div>
          </section>
        </div>
      </div>
    );
  }
}

export default CredLoyality;
