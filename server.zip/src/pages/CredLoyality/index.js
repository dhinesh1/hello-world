export { default } from './CredLoyality';
