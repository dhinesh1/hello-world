import React from 'react';
import LazyLoad from 'react-lazyload';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export const CredCard = ({
  backgroundImage,
  itinerarySlug,
  categoryName,
  originalPrice,
  title,
  locations = [],
  inclusions = [],
  exclusions = [],
  finalPrice
}) => {
  const imgxUrl = getImgIXUrl(backgroundImage);
  return (
    <div className="col-xs-12 col-sm-4 col-md-4">
      <div className="cred-card">
        <a href={itinerarySlug}>
          <LazyLoad offset={100} once={true}>
            <figure style={{ backgroundImage: `url(${imgxUrl})` }}>
              <figcaption>
                <span>{categoryName}</span>
              </figcaption>
            </figure>
          </LazyLoad>
          <div className="card-text">
            <h4>{title}</h4>
            <ul className="breadcrumb">
              {locations.map((placeName, index) => {
                return <li key={index}>{placeName}</li>;
              })}
            </ul>
            <div className="pills">
              {inclusions.map((option, index) => {
                return <span key={index}>{option}</span>;
              })}
              {exclusions.map((option, index) => {
                return (
                  <span key={index} className="exclusion">
                    {option}
                  </span>
                );
              })}
            </div>
          </div>
          <div className="btn-row">
            <div className="pull-left">
              <div className="price-cell off-price">
                <span>List Price</span>
                <strong className="strike-line">
                  <i className="fs-normal regular">₹</i>
                  {originalPrice}
                </strong>
              </div>

              <div className="price-cell">
                <span>
                  <img
                    src={
                      'https://d3lf10b5gahyby.cloudfront.net/web_app/cred/price-tag.png'
                    }
                    alt="price for 2"
                  />
                </span>
                <strong>
                  <i className="fs-normal regular">₹</i>
                  {finalPrice}
                </strong>
              </div>
            </div>
            <button type="button" className="pull-right btn btn-sm btn-light">
              Book Trip
            </button>
          </div>
        </a>
      </div>
    </div>
  );
};
