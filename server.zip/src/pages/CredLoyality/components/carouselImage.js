import React from 'react';
import LazyLoad from 'react-lazyload';
import {getImgIXUrl} from '../../../helpers/utilsHelper';

export const CarouselImage = ({ url }) => {
  return (
    <div role="option" style={{ width: '464px' }}>
    <LazyLoad offset={100} once>
      <figure
        style={{
          backgroundImage: `url(${getImgIXUrl(url)})`
        }}
      />
      </LazyLoad>
    </div>
  );
};
