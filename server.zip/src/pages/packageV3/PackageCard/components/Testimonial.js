import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import LazyLoadComponent from '../../../../common_components/LazyLoadComponent';

const Testimonial = ({
  testimonialsDescription,
  isPackagePage,
  isTestCase
}) => {
  if (testimonialsDescription) {
    let imgFactor = '';
    let testiProfileImage = testimonialsDescription.profileImage;

    if (
      testiProfileImage.indexOf(
        'pyt-testimonialimages.s3.ap-south-1.amazonaws.com'
      ) > 0
    ) {
      testiProfileImage = testiProfileImage.replace(
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com',
        'https://pyt-testimonial.imgix.net' + imgFactor
      );
    } else {
      testiProfileImage = testiProfileImage.replace(
        'https://d3lf10b5gahyby.cloudfront.net',
        'https://pyt-images.imgix.net/images' + imgFactor
      );
    }
    testiProfileImage = testiProfileImage + '?w=96&h=96';

    return (
      <div className="clearfix fw btm-info fb hidden-xs">
        {isPackagePage ? (
          <a
            href={testimonialsDescription.fbLink}
            className="pull-left fw tracker-pkg-fbreview"
            target="_blank"
            rel="nofollow"
          >
            <LazyLoadComponent isTestCase={isTestCase}>
              <img
                src={testiProfileImage}
                alt={testimonialsDescription.fName}
              />
            </LazyLoadComponent>
            <span className="pull-left truncate">
              <b>“{testimonialsDescription.shortestReview}”</b> —{' '}
              {testimonialsDescription.fName} from{' '}
              {testimonialsDescription.cityOfDeparture}
            </span>
            <span className="pull-right text-right fine-text">
              <i className="vehoicon-facebook-square" />
              Read full review
            </span>
          </a>
        ) : (
          <Link to={`#`} className="pull-left fw">
            <img src={testiProfileImage} alt={testimonialsDescription.fName} />
            <span className="pull-left truncate">
              <b>“{testimonialsDescription.shortestReview}”</b> —{' '}
              {testimonialsDescription.fName} from{' '}
              {testimonialsDescription.cityOfDeparture}
            </span>
          </Link>
        )}
      </div>
    );
  }

  return null;
};

Testimonial.propTypes = {
  testimonialsDescription: PropTypes.shape({
    profileImage: PropTypes.string.isRequired,
    fName: PropTypes.string.isRequired,
    shortestReview: PropTypes.string,
    cityOfDeparture: PropTypes.string
  }),
  isTestCase: PropTypes.bool,
  isPackagePage: PropTypes.bool
};

export default Testimonial;
