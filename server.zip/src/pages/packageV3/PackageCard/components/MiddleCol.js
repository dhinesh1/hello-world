import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { getImgIXUrl } from '../../../../helpers/utilsHelper';
import LazyLoadComponent from '../../../../common_components/LazyLoadComponent';

export default class MiddleCol extends Component {
  state = {
    showMore: false
  };

  moreActivities = () => {
    this.setState(prevState => ({
      showMore: !prevState.showMore
    }));
  };

  visitingPlaces = (hotelStay = []) => {
    return hotelStay.map(({ cityName, nights }, index, hotelStayArr) => {
      return `${cityName} (${nights}N)${
        index !== hotelStayArr.length - 1 ? ' → ' : ''
      }`;
    });
  };

  render() {
    let {
      vacations,
      history,
      isPackagePage,
      isTestCase,
      hideTheme = false
    } = this.props;
    return (
      <div className="middle-col">
        <ContentBanner
          {...vacations}
          history={history}
          hideTheme={hideTheme}
          isPackagePage={isPackagePage}
          visitingPlaces={this.visitingPlaces}
          isTestCase={isTestCase}
        />

        <Row
          {...vacations}
          // isTransferIncluded={null}
          // isFlightsIncluded={false}
          // isVisaIncluded={false}
          // isHotelsIncluded={true}
          visitingPlaces={this.visitingPlaces}
          moreActivities={this.moreActivities}
          showMore={this.state.showMore}
        />
      </div>
    );
  }
}

export const ContentBanner = p => {
  return (
    <div
      className="xs-banner-holder"
      style={{
        backgroundImage: `url(${getImgIXUrl(p.image)})`
      }}
    >
      <p itemScope="" itemType="http://schema.org/Product">
        {p.isPackagePage ? (
          <span itemProp="name" className="bold">
            <Link to={`/packages/${p.slug}`} target={'_self'}>
              {p.title}
            </Link>
          </span>
        ) : (
          <span itemProp="name" className="bold">
            {p.title}
          </span>
        )}

        <span className="fine-text hidden-xs">
          <i>{p.nights} NIGHTS:</i>{' '}
          {p.cityHotelStay &&
            p.cityHotelStay.length &&
            p.visitingPlaces(p.cityHotelStay)}
        </span>
      </p>
      {!p.hideTheme && p.themes && p.themes.length ? (
        <ul className="clearfix label-list">
          <li>
            <span className="tag-tertiary grey-secondary">Theme</span>
          </li>
          <li>
            <span className="tag-tertiary upside-down">
              {p.themes[0].charAt(0).toUpperCase() +
                p.themes[0]
                  .replace(/_/g, ' ')
                  .substr(1)
                  .toLowerCase()}
            </span>
          </li>
          {p.themes && p.themes.length > 1
            ? p.themes.map((element, index) => {
                return index > 0 ? (
                  <li>
                    {' '}
                    {element.charAt(0).toUpperCase() +
                      element
                        .replace(/_/g, ' ')
                        .substr(1)
                        .toLowerCase()}{' '}
                  </li>
                ) : null;
              })
            : null}
        </ul>
      ) : null}
    </div>
  );
};

export const Row = p => {
  let activitiesList = p.activities;
  return (
    <div className="row no-margin list-row">
      <p className="fine-text color-grey visible-xs">
        <span className="text-uppercase color-accent-8">
          {p.nights} NIGHTS:{' '}
        </span>
        {p.cityHotelStay &&
          p.cityHotelStay.length &&
          p.visitingPlaces(p.cityHotelStay)}
      </p>
      <div className="hidden-xs col-sm-12 col-md-8 no-padding">
        <ul className="pull-left fw dot-list meta-text color-grey-secondary fade">
          {activitiesList && activitiesList.length
            ? activitiesList.map((activity, index) => {
                if (index <= 2) {
                  return <li key={activity}>{activity}</li>;
                } else if (index === 3) {
                  return (
                    <li key={activity}>
                      {activity}{' '}
                      {!p.showMore && activitiesList.length > 4 ? (
                        <a
                          href="javascript:void(0);"
                          onClick={e => p.moreActivities(e)}
                        >
                          &amp;{' '}
                          {activitiesList.length - 4 === 1
                            ? '1 more activity'
                            : activitiesList.length -
                              4 +
                              ' ' +
                              'more activities'}
                        </a>
                      ) : null}
                    </li>
                  );
                } else if (p.showMore) {
                  return (
                    <li key={activity}>
                      {activity}
                      {p.showMore && activitiesList.length - 1 === index ? (
                        <a
                          href="javascript:void(0);"
                          onClick={e => p.moreActivities(e)}
                        >
                          {' '}
                          View less
                        </a>
                      ) : null}
                    </li>
                  );
                }
              })
            : null}
        </ul>
      </div>

      <div className="col-xs-12 col-sm-12 col-md-4 no-padding">
        <div className="clearfix fw pill-outer">
          <span className="pill gold color-white text-uppercase hidden-xs hidden-sm">
            Inclusions
          </span>
          {/* Flights */}
          {p.flightsIncluded ? (
            <span className="pill-outline bg grey-light">
              <i className="vehoicon-ion-checkmark color-primary" /> Flights
            </span>
          ) : null}

          {/* Hotel */}
          {p.hotelsIncluded ? (
            <span className="pill-outline bg grey-light">
              <i className="vehoicon-ion-checkmark color-primary" />{' '}
              {p.hotelStarRating}
              <i className="vehoicon-star fade" /> Hotels
            </span>
          ) : null}

          {/* Activites */}
          {activitiesList && activitiesList.length > 0 ? (
            <span className="pill-outline bg grey-light">
              <i className="vehoicon-ion-checkmark color-primary" /> Activities
            </span>
          ) : null}

          {/* Transfer */}
          {p.transferIncluded === null ? null : p.transferIncluded ? (
            <span className="pill-outline bg grey-light">
              <i className="vehoicon-ion-checkmark color-primary" /> Private
              transfer
            </span>
          ) : (
            <span className="pill-outline bg grey-light">
              <i className="vehoicon-ion-checkmark color-primary" /> Shared
              transfer
            </span>
          )}

          {/* Visa */}
          {p.visaType === 'ON_ARRIVAL' ? (
            <span className="pill-outline bg grey-light">
              <i className="vehoicon-ion-checkmark color-primary" /> Visa on
              arrival
            </span>
          ) : p.visaIncluded ? (
            <span className="pill-outline bg grey-light">
              <i className="vehoicon-ion-checkmark color-primary" /> Visa fees
            </span>
          ) : null}

          {p.flightsIncluded && p.transferIncluded !== null ? null : (
            <strong className="hidden-xs hidden-sm">Exclusions</strong>
          )}
          {/* Flights */}
          {p.flightsIncluded ? null : (
            <span className="pill-outline bg accent-9">
              <span className="color-accent-9 fade">
                <i className="vehoicon-close" /> Flights
              </span>
            </span>
          )}

          {/* Transfer */}
          {p.transferIncluded === null ? (
            <span className="pill-outline bg accent-9">
              <span className="color-accent-9 fade">
                <i className="vehoicon-close" /> Transfers
              </span>
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
};

MiddleCol.propTypes = {
  vacations: PropTypes.object,
  history: PropTypes.shape({
    location: PropTypes.shape({
      pathname: PropTypes.string,
      search: PropTypes.string
    }),
    push: PropTypes.func
  }),
  hideTheme: PropTypes.bool,
  isTestCase: PropTypes.bool,
  isPackagePage: PropTypes.bool
};

ContentBanner.propTypes = {
  image: PropTypes.string,
  title: PropTypes.string,
  nights: PropTypes.number,
  cityNightsMap: PropTypes.object,
  visitingPlaces: PropTypes.func,
  hideTheme: PropTypes.bool,
  themes: PropTypes.arrayOf(PropTypes.string)
};

Row.propTypes = {
  activities: PropTypes.arrayOf(PropTypes.string),
  nights: PropTypes.number,
  cityNightsMap: PropTypes.object,
  visitingPlaces: PropTypes.func,
  showMore: PropTypes.bool
};
