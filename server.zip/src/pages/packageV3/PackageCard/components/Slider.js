import React from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';
import LazyLoadComponent from '../../../../common_components/LazyLoadComponent';

const Slider = ({ imageUrl, isTestCase }) => {
  return (
    <div
      className="pkg-slider slick-initialized slick-slider slick-dotted"
      role="toolbar"
    >
      <div className="slick-list draggable" aria-live="polite">
        <div
          className="slick-track"
          style={{
            opacity: 1,
            width: 1686,
            transform: `translate3d(-281, 0, 0)`
          }}
        >
          <div
            className="slick-slide slick-cloned"
            aria-hidden="true"
            tabIndex="-1"
            data-slick-index="-1"
            style={{ width: 281 }}
          >
            <LazyLoadComponent isTestCase={isTestCase}>
              <div
                className="item"
                style={{
                  backgroundImage: `url(${imageUrl})`
                }}
              />
            </LazyLoadComponent>
          </div>
        </div>
      </div>
    </div>
  );
};

Slider.propTypes = {
  imageUrl: PropTypes.string.isRequired,
  isTestCase: PropTypes.bool
};

export default Slider;
