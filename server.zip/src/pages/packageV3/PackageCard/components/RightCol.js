import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import CostFormat from '../../../../common_components/CostFormatter';

const RightCol = ({ vacations = {}, history }) => {
  return (
    <div className="right-col vertical-center">
      <aside>
        <div
          className="actual-price"
          itemProp="offers"
          itemType="http://schema.org/Offer"
        >
          <span itemProp="priceCurrency" content="INR">
            ₹{' '}
          </span>
          <span itemProp="price" content={vacations.itineraryCostDisplay || ''}>
            <CostFormat cost={vacations.itineraryCostDisplay || ''} />
          </span>
          <p className="color-grey-secondary light">
            Starting price per person
          </p>
        </div>
      </aside>
      <Link
        to={
          `${history.location.pathname}/get-cost/${
            vacations.campaignItineraryId
          }` + `${history.location.search ? history.location.search + '' : ''}`
        }
        className="btn btn-primary tracker-campaign-custombtn"
        onClick={e => e.preventDefault()}
      >
        Customize
      </Link>
    </div>
  );
};

RightCol.propTypes = {
  vacations: PropTypes.shape({
    campaignItineraryId: PropTypes.string,
    itineraryCostDisplay: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.number
    ])
  }),
  history: PropTypes.object
};

export default RightCol;
