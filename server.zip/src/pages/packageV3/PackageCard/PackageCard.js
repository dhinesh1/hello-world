import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { AppConfig } from '../../../app-config';
import TestiMonial from './components/Testimonial';
import RightCol from './components/RightCol';
import MiddleCol from './components/MiddleCol';
import Slider from './components/Slider';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

class PackageCard extends Component {
  showGetCostModal = e => {
    if (
      (e.target &&
        e.target.tagName.toLowerCase() !== 'a' &&
        !e.target.parentElement.closest('.tracker-pkg-fbreview')) ||
      e.target.classList.contains('btn')
    ) {
      e.preventDefault();
      if (this.props.history.location.pathname.indexOf('get-cost') === -1) {
        this.props.history.push(
          `${this.props.history.location.pathname}/get-cost/${this.props
            .itinerary.campaignItineraryId || ''}` +
            `${
              this.props.history.location.search
                ? this.props.history.location.search + ''
                : ''
            }`
        );
      }
    }
  };

  render() {
    const {
      itinerary,
      testimonialsDescription,
      specialDealsText,
      history,
      hideTheme = false,
      testimonialsIndex,
      cardCaption
    } = this.props;

    let imageUrl = getImgIXUrl(itinerary.image, 'auto=compress&w=640&h=640');

    return (
      <section
        className="clearfix package-card tracker-pkg-card"
        onClick={this.showGetCostModal}
      >
        {cardCaption ? (
          <figcaption className="fig-title">
            <span
              className="tag-tertiary white truncate medium"
              dangerouslySetInnerHTML={{ __html: cardCaption }}
            />
          </figcaption>
        ) : null}
        {/* packages left card starts*/}
        <div className="left-col hidden-xs">
          <Slider imageUrl={imageUrl} />
        </div>
        {/* packages left card ends*/}

        <MiddleCol
          vacations={itinerary}
          isPackagePage={true}
          hideTheme={hideTheme}
        />

        <RightCol vacations={itinerary} history={history} />

        {testimonialsIndex === null ? null : testimonialsIndex ? (
          <TestiMonial
            testimonialsDescription={testimonialsDescription}
            isPackagePage={true}
          />
        ) : (
          <SpecialTag specialDealsText={specialDealsText} />
        )}
      </section>
    );
  }
}

const SpecialTag = ({ specialDealsText }) => {
  if (specialDealsText) {
    let splitedText = specialDealsText.split(':');
    return (
      <div className="clearfix fw btm-info hidden-xs">
        <span className="pull-left fw truncate">
          <b className="color-accent-1">{splitedText[0]}:</b>
          {splitedText[1]}
        </span>
      </div>
    );
  }
  return null;
};

PackageCard.propTypes = {
  itinerary: PropTypes.object.isRequired,
  testimonialsDescription: PropTypes.object,
  specialDealsText: PropTypes.string,
  history: PropTypes.object.isRequired,
  testimonialsIndex: PropTypes.oneOfType([PropTypes.bool, PropTypes.number]),
  cardCaption: PropTypes.string,
  hideTheme: PropTypes.bool
};

export default PackageCard;
