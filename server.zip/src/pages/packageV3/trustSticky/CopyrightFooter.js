import React from 'react';
import { Link } from 'react-router-dom';

const CopyrightFooter = () => {
  return (
    <section className="copyright">
      <div className="container sm-full-width lg-container">
        <div className="row">
          <div className="col-md-12">
            <p className="fine-text color-grey mb-0 text-center">
              Reserved by Travel Troops Global Private Ltd. |{' '}
              <Link
                to={{
                  pathname: `/privacy-policy`
                }}
              >
                Privacy Policy
              </Link>{' '}
              | For more details contact: +91 9952016704
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CopyrightFooter;
