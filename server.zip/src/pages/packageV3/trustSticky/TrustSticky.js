import React, { Component, Fragment } from 'react';
import classNames from 'classnames';
import { getImgIXUrl } from '../../../helpers/utilsHelper';
import { is_server, isFaqMobile } from '../../../helpers/utilsHelper';

const PWBIcon = (<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                     viewBox="0 0 24 24" xmlSpace="preserve">
  <g>
	<path fill='#EFEFEF' d="M11.4,3.1L6.3,8.3c-0.7,0.8-0.6,2,0.1,2.7l0,0c0.7,0.7,1.9,0.6,2.5-0.1l2.9-2.8c0.2-0.2,0.6-0.2,0.8,0l7,7
		c0.4,0.4,0.4,1,0,1.4l0,0c-0.4,0.4-1,0.4-1.4,0l-4.4-4.3l-0.4,0.5l4.5,4.4c0.4,0.4,0.4,1.1,0,1.5h0c-0.4,0.4-1.1,0.4-1.5,0
		l-4.5-4.4l-0.4,0.5l4.5,4.7c0.4,0.4,0.4,1,0,1.4l0,0c-0.4,0.4-1,0.4-1.4,0l-0.3-0.3c0,0,0.5-1.1-0.3-1.8c-0.6-0.5-1.2-0.3-1.2-0.3
		s0.6-1.4-0.2-2.1c-0.6-0.6-1.3-0.5-1.3-0.5s0.3-1.1-0.6-1.8c-0.8-0.6-1.9-0.2-1.9-0.2s0-0.9-0.9-1.3c-0.5-0.3-1.1-0.2-1.5,0.1
		c-0.4,0.3-1.2,1-1.7,1.5c-0.2,0.2-0.5,0.2-0.7,0l-1.8-1.9C-0.1,9.7,0,5.8,2.4,3.4l0.1-0.1C5,0.9,8.8,0.8,11.4,3.1L11.4,3.1z"/>
    <path fill='#EFEFEF' d="M12.2,3.2L6.8,8.7c-0.5,0.5-0.5,1.2,0,1.7l0,0c0.4,0.4,1.2,0.5,1.6,0l3.5-3.2c0.2-0.2,0.5-0.2,0.7,0l7.4,7.2
		l1.9-2.1c2.3-2.6,2.2-6.6-0.3-9l0,0C19,0.6,14.8,0.6,12.2,3.2z"/>
    <path fill='#EFEFEF' d="M6.3,13.5l-1.8,1.7c-0.4,0.3-0.4,0.9-0.1,1.3h0c0.3,0.4,1,0.5,1.4,0.1l1.8-1.7c0.4-0.4,0.4-1,0-1.3l0,0
		C7.3,13.1,6.7,13.1,6.3,13.5z"/>
    <path fill='#EFEFEF' d="M10.6,16.8l-2.1,2C8,19.3,8,19.9,8.4,20.4l0,0c0.4,0.5,1.2,0.5,1.6,0.1l2.1-2c0.5-0.4,0.5-1.1,0.1-1.6l0,0
		C11.7,16.4,11,16.4,10.6,16.8z"/>
    <path fill='#EFEFEF' d="M12.2,19.3L10.4,21C10,21.4,10,22,10.3,22.4l0,0c0.4,0.4,1,0.5,1.4,0.1l1.9-1.8c0.4-0.4,0.4-1,0.1-1.4l0,0
		C13.3,18.9,12.6,18.9,12.2,19.3z"/>
    <path fill='#EFEFEF' d="M8.7,14.7l-2.2,2c-0.4,0.4-0.5,1.1-0.1,1.6l0,0c0.4,0.5,1.2,0.5,1.6,0.1l2.2-2c0.5-0.4,0.5-1.1,0.1-1.6l0,0
		C9.9,14.3,9.1,14.3,8.7,14.7z"/>
    <path fill='#EFEFEF'
          d="M13.8,21.4l-1.2,1.2c0,0,0.6,0.4,1.1-0.2C14.2,21.8,13.8,21.4,13.8,21.4z"/>
</g>
</svg>);

export default class TrustSticky extends Component {
  state = {
    showTrustBlock: false
  };

  componentDidMount() {
    if (!is_server()) {
      window.addEventListener('scroll', this.onScrollCB);
    }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScrollCB);
  }

  onScrollCB = () => {
    let t = this;
    let hb = document.getElementById('banner');
    let cE = document.querySelector('#packagesContent');
    let seo = document.querySelector('.seo-text');
    let scroll = window.scrollY;

    if (!isFaqMobile()) {
      if (
        hb &&
        scroll > hb.offsetHeight - 100 &&
        cE &&
        scroll < cE.offsetHeight + (seo ? seo.offsetHeight : 0)
      ) {
        t.setState({ showTrustBlock: true });
      } else {
        t.setState({ showTrustBlock: false });
      }
    } else {
      if (cE && seo && scroll < cE.offsetHeight + seo.offsetHeight) {
        t.setState({ showTrustBlock: true });
      } else {
        t.setState({ showTrustBlock: false });
      }
    }
  };

  showCBR = () => {
    const { pathname } = this.props.history.location;
    if (pathname.indexOf('/request-callback') === -1) {
      this.props.history.push(
        `${pathname}/request-callback` +
          `${
            this.props.history.location.search
              ? this.props.history.location.search + ''
              : ''
          }`
      );
    }
  };

  render() {
    let {
      openMobileFilterStatus,
      toggleTrustModuleStatus,
      campaignDetails
    } = this.props;
    let { showTrustBlock } = this.state;

    return (
      <section
        className={classNames('trust-sticky', {
          'pull-up': showTrustBlock
        })}
      >
        <div className="container sm-full-width lg-container">
        {this.state.showTrustBlock ? 
          <div className="row md-list hidden-xs hidden-sm">
            <div className="col-md-12">
              <ul className="list-unstyled mb-0">
                <li>
                  {campaignDetails && campaignDetails.paid ? (
                    <p>
                      <img
                        src="https://pyt-images.imgix.net/images/campaign_paid/certifiedstamp_icons.png"
                        alt="Australia Tourism"
                      />&nbsp; Certified by the best
                    </p>
                  ) : (
                    <p>
                      {PWBIcon}
                      Partnered with the best
                    </p>
                  )}
                </li>
                <li>
                  <p>
                    <i className="ico_1" />Instant Personalisation
                  </p>
                </li>
                <li>
                  <p>
                    <i className="ico_2" />Best Price Guarantee
                    <span className="color-accent-2">
                      Yes, we can price match!
                    </span>
                  </p>
                </li>
                <li>
                  <p>
                    <i className="ico_3" />
                    Best in-class live concierge
                  </p>
                </li>
              </ul>
            </div>
          </div>
        : null }
          <div className="row sm-list hidden-md hidden-lg">
            {this.props.noFilter || (campaignDetails && campaignDetails.paid) ? (
              <div className="col-xs-12 col-sm-12">
                <button
                  type="button"
                  className="btn btn-primary btn-block truncate tracker-campaign-planbtn"
                  onClick={this.showCBR}
                >
                  Questions? Talk to our travel consultants
                </button>
              </div>
            ) : (
              <Fragment>
                <div className="col-xs-8 col-sm-9">
                  <button
                    type="button"
                    onClick={e => toggleTrustModuleStatus(e)}
                    className="btn btn-link btn-block truncate trust-btn"
                  >
                    What makes us special ?
                  </button>
                </div>

                <div className="col-xs-4 col-sm-3">
                  <button
                    type="button"
                    className="btn btn-light btn-block truncate filter-btn"
                    onClick={e => openMobileFilterStatus(e)}
                  >
                    <i className="vehoicon-tune" />
                    <span>Filters</span>
                  </button>
                </div>
              </Fragment>
            )}
          </div>
        </div>
      </section>
    );
  }
}
