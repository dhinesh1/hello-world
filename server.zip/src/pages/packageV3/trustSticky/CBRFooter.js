import React, { Component } from 'react';
import classNames from 'classnames';
import { isFaqMobile, is_server } from '../../../helpers/utilsHelper';

/**
 * This component will render only for vacations pages
 */
export default class CBRFooter extends Component {
  state = {
    showSlideup: false
  };
  componentDidMount() {
    if (!is_server()) {
      window.addEventListener('scroll', this.onScrollCB);
    }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScrollCB);
  }

  onScrollCB = () => {
    let t = this;
    let hb = document.getElementById('banner');
    let cE = document.querySelector('#packagesContent');
    let seo = document.querySelector('.seo-text');
    let scroll = window.scrollY;

    if (!isFaqMobile()) {
      if (
        hb &&
        scroll > hb.offsetHeight - 100 &&
        cE &&
        scroll < cE.offsetHeight + (seo ? seo.offsetHeight : 0)
      ) {
        t.setState({ showSlideup: true });
      } else {
        t.setState({ showSlideup: false });
      }
    } else {
      if (cE && seo && scroll < cE.offsetHeight + seo.offsetHeight) {
        t.setState({ showSlideup: true });
      } else {
        t.setState({ showSlideup: false });
      }
    }
  };

  openCBR = e => {
    const { history } = this.props;
    let location =
      history.location.pathname.indexOf('request-callback') > 0
        ? history.location.pathname.split('request-callback')[0]
        : history.location.pathname + '/request-callback';
    history.push(location);
  };

  render() {
    const { showSlideup } = this.state;
    return (
      <div
        className={classNames('bottom-options-bar yellow-bar text-center', {
          'slide-up': showSlideup
        })}
      >
        <section className="bottom-options-content">
          <div className="clearfix hidden-xs sm-text vertical-center">
            <p className="pull-left meta-text semi-bold">
              Confused? Need inspiration? Schedule a call with our consultants
            </p>
            <button className="pull-right btn" onClick={e => this.openCBR(e)}>
              Reserve a slot
            </button>
          </div>
          <div className="clearfix visible-xs xs-btns">
            <button className="btn btn-block" onClick={e => this.openCBR(e)}>
              Questions? Talk to our travel consultants
            </button>
          </div>
        </section>
      </div>
    );
  }
}
