import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import _ from 'lodash';
import { is_server, sort, getImgIXUrl } from '../../../helpers/utilsHelper';
import Slider from '../../PVCommonComponents/ImageSlider';
import CBRSuccessAlert from '../../PVCommonComponents/CBRalert.js';
import MiddleCol from '../../PVCommonComponents/MiddleCol';
import TestiMonial from '../../PVCommonComponents/TestiMonial';
import AdSection from '../../PVCommonComponents/Adsection';
import PropTypes from 'prop-types';
import CostFormat from '../../../common_components/CostFormatter';
import { trackPage, PAGE_PACKAGES, trackEvent, EVENT_PACKAGE_SELECTED } from '../../../helpers/ML/EventsTracker';

export default class PackagesContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mobileInclusionsExpandedFor: 9999,
      noOfCardToShow: 10,
      loading: false
    };
    this.onScroll = this.onScroll.bind(this);
    this.randomNo = this.randomNo.bind(this);
    this.showGetCostModal = this.showGetCostModal.bind(this);
    this.loadNextPage = this.loadNextPage.bind(this);
    this.handleoverOutside = this.handleoverOutside.bind(this);
  }

  componentDidMount() {
    window.addEventListener('mouseout', this.handleoverOutside);
    window.addEventListener('scroll', this.onScroll);
  }
  componentWillUnmount() {
    window.removeEventListener('mouseout', this.handleoverOutside);
  }

  handleoverOutside(event) {
    let value = this.props;
    event = event ? event : window.event;
    let CBRrequest = JSON.parse(sessionStorage.getItem('CBRrequest'));
    var from = event.relatedTarget || event.toElement;
    let storage = JSON.parse(sessionStorage.getItem('CBRPackExitpopup'));
    if (
      (!from || from.nodeName == 'HTML') &&
      event.clientY <= 0 &&
      !CBRrequest &&
      value.history.location.pathname.indexOf('request-callback') === -1 &&
      value.history.location.pathname.indexOf('get-cost') === -1 &&
      storage
    ) {
      value.history.push(
        `${value.history.location.pathname}/request-callback` +
          `${
            value.history.location.search
              ? value.history.location.search + ''
              : '?'
          }` +
          `&autocbr`
      );
      sessionStorage.setItem('CBRPackExitpopup', false);
    }
  }

  loadNextPage() {
    let t = this.state;
    t.noOfCardToShow = t.noOfCardToShow + 10;
    this.setState(t);
  }

  onScroll() {
    let value = this.props;
    setTimeout(t => {
      let isOpend = JSON.parse(sessionStorage.getItem('packagesv3'));
      let CBRrequest = JSON.parse(sessionStorage.getItem('CBRrequest'));
      if (
        isOpend &&
        !CBRrequest &&
        value.history.location.pathname.indexOf('get-cost') === -1 &&
        value.history.location.pathname.indexOf('request-callback') === -1 &&
        value.mobile
      ) {
        value.history.push(
          `${value.history.location.pathname}/request-callback` +
            `${
              value.history.location.search
                ? value.history.location.search + ''
                : ''
            }`
        );
        sessionStorage.setItem('packagesv3', false);
      }
    }, 5000);
    window.removeEventListener('scroll', this.onScroll);
  }

  showGetCostModal(e, itineraries) {
    if (
      ((e.target && e.target.tagName.toLowerCase() !== 'a') ||
        e.target.classList.contains('btn')) &&
      (e.target && !e.target.closest('.tracker-pkg-fbreview'))
    ) {
      e.preventDefault();
      let itineraryId = itineraries.campaignItineraryId;
      if (this.props.history.location.pathname.indexOf('get-cost') === -1) {
        trackEvent(EVENT_PACKAGE_SELECTED, {
          title: itineraries.title,
          cost: itineraries.itineraryCost,
          is_card_clicked: true
        });
        trackPage(PAGE_PACKAGES, {
          itinerary_title: itineraries.title,
          itinerary_price: itineraries.itineraryCost
        });
        this.props.history.push(
          `${this.props.history.location.pathname}/get-cost/${itineraryId}` +
            `${
              this.props.history.location.search
                ? this.props.history.location.search + ''
                : ''
            }`
        );
      }
    }
  }

  randomNo(val, testimonials, used_testimonial) {
    let testimonials_length = val;
    used_testimonial.push(testimonials);
    if (testimonials_length > 1) {
      let rNo = Math.floor(Math.random() * testimonials_length);
      used_testimonial.splice(rNo, 1);

      return rNo;
    }
  }

  render() {
    let {
      packages,
      selectedDurations,
      selectedBudgets,
      selectedStarRatings,
      selectedDepcity,
      history,
      actions,
      isTestCase
    } = this.props;
    let isPaid = packages.campaignDetails && packages.campaignDetails.paid;
    let filtered = packages.filteredItineraries;

    return (
      <div className="col-md-12">
        <CBRSuccessAlert
          history={history}
          regionCode={packages.campaignDetails.regionCode}
        />
        {packages && packages.filteredItineraries ? (
          <PackageCardList
            history={history}
            randomNo={this.randomNo}
            campaignDetails={packages.campaignDetails}
            showGetCostModal={this.showGetCostModal}
            n={this.state.noOfCardToShow}
            testimonials={packages.testimonials}
            packages={filtered}
            itineraryAssignUser={actions.itineraryAssignUser}
            selectedDurations={selectedDurations}
            selectedBudgets={selectedBudgets}
            selectedStarRatings={selectedStarRatings}
            selectedDepcity={selectedDepcity}
            isTestCase={isTestCase}
            isPaid={isPaid}
          />
        ) : null}

        {isPaid ? (
          <div className="row desc-txt">
            <div className="col-md-12 text-center">
              <p className="color-grey mb-0">
                {packages && packages.campaignDetails && !packages.themeDetails
                  ? packages.campaignDetails.headerSubText
                  : packages.themeDetails
                    ? packages.themeDetails.headerSubText !== undefined
                      ? packages.themeDetails.headerSubText
                      : packages.campaignDetails.headerSubText
                    : ''}
              </p>
            </div>
          </div>
        ) : (
          [
            (filtered && filtered.length) === 0 ? (
              <NoItinerariesFoundMessage />
            ) : null,
            packages &&
            filtered &&
            filtered.length > this.state.noOfCardToShow ? (
              <LoadMoreComponent
                loadNextPage={this.loadNextPage}
                loading={this.state.loading}
              />
            ) : null
          ]
        )}
      </div>
    );
  }
}

export function PackageCardList({
  packages,
  testimonials,
  randomNo,
  showGetCostModal,
  n,
  campaignDetails,
  loadNextPage,
  history,
  isTestCase
}) {
  let specialDeals = [
    'Special Offer: Guaranteed 3+ star hotels with the best price',
    'Grand Deals: All inclusive package with seamless concierge services',
    'Prime offer: Top rated activities at unbeatable prices'
  ];
  let initial = true;
  let fbIndex,
    index = 0,
    testimonialsDescription,
    specialDealsText;
  let used_testimonial = [];
  let val, specialTextIndex;

  let paginatedItineraries = campaignDetails.paid
    ? packages
    : _.take(packages, n);

  let itineraries = paginatedItineraries.map((pack, i) => {
    if (testimonials && testimonials.length) {
      val = randomNo(testimonials.length, testimonials, used_testimonial);
    }
    specialTextIndex = randomNo(
      specialDeals.length,
      specialDeals,
      used_testimonial
    );
    if ((index % 2 === 1 && initial) || (index % 3 === 1 && !initial)) {
      fbIndex = true;
      initial = false;
      testimonialsDescription = testimonials[val];
    } else if (index % 3 === 2) {
      fbIndex = false;
      specialDealsText = specialDeals[specialTextIndex];
    } else fbIndex = null;
    index++;
    return (
      <SinglePackageCard
        key={'package_card_list_' + campaignDetails.paid + '_' + i}
        p={pack}
        packages={packages}
        i={i}
        testimonialsDescription={testimonialsDescription}
        showGetCostModal={showGetCostModal}
        specialDealsText={specialDealsText}
        history={history}
        testimonials={testimonials}
        testimonialsIndex={fbIndex}
        isPaid={campaignDetails.paid}
        isTestCase={isTestCase}
      />
    );
  });

  for (let k = 0; k < itineraries.length; k++) {
    if (k % 6 === 3) {
      itineraries.splice(
        k,
        0,
        <AdSection
          regionCode={packages && packages.length && packages[0].regionCode}
          history={history}
          isPackagePage={true}
          campaignDetails={campaignDetails}
        />
      );
    }
  }
  return itineraries;
}

export function SinglePackageCard({
  p,
  testimonialsDescription,
  testimonials,
  specialDealsText,
  showGetCostModal,
  i,
  history,
  testimonialsIndex,
  isPaid,
  isTestCase
}) {
  let imageUrl = getImgIXUrl(p.image, 'auto=compress&w=640&h=640');

  return (
    <section
      className="clearfix package-card tracker-pkg-card"
      key={'single_page_card_' + i}
      onClick={e => showGetCostModal(e, p)}
    >
      {/* packages left card starts*/}
      <div className="left-col hidden-xs">
        <Slider imageUrl={imageUrl} isTestCase={isTestCase} />
      </div>
      {/* packages left card ends*/}

      <MiddleCol
        vacations={p}
        isPackagePage={true}
        isTestCase={isTestCase}
        isPaid={isPaid}
      />

      <PackageRightCol singlePackage={p} history={history} />

      {testimonialsIndex === null ? null : testimonialsIndex ? (
        <TestiMonial
          vacations={p}
          testimonialsDescription={testimonialsDescription}
          isPackagePage={!isPaid}
          testimonials={testimonials}
        />
      ) : (
        <PackageSpecialTag specialDealsText={specialDealsText} />
      )}
    </section>
  );
}

// Remove While Integrating react- only for known purpose
/**
 * @return {null}
 */
function PackageSpecialTag(specialDealsText) {
  if (specialDealsText.specialDealsText) {
    let splitedText =
      specialDealsText && specialDealsText.specialDealsText.split(':');
    return (
      <div className="clearfix fw btm-info hidden-xs">
        <span className="pull-left fw truncate">
          <b className="color-accent-1">{splitedText[0]}:</b>
          {splitedText[1]}
        </span>
      </div>
    );
  } else {
    return null;
  }
}

function LoadMoreComponent({ loadNextPage }) {
  return (
    <section className="clearfix text-center">
      <button
        type="button"
        id="load-more-itineraries"
        onClick={loadNextPage}
        className="btn btn-primary btn-outline vmargin-medium tracker-loadmore-itineraries"
      >
        Load more itineraries
      </button>
    </section>
  );
}

function PackageRightCol({ singlePackage, history }) {
  return (
    <div className="right-col vertical-center">
      <aside>
        <div
          className="actual-price"
          itemProp="offers"
          itemType="http://schema.org/Offer"
        >
          <span itemProp="priceCurrency" content="INR">
            ₹{' '}
          </span>
          <span
            itemProp="price"
            content={Math.ceil(singlePackage.itineraryCost)}
          >
            <CostFormat cost={singlePackage.itineraryCost} />
          </span>
          <p className="color-grey-secondary light">
            Starting price per person
          </p>
        </div>
      </aside>
      <Link
        to={
          history.location.pathname &&
          history.location.pathname.indexOf('get-cost') !== -1
            ? history.location.pathname
            : `${history.location.pathname}/get-cost/${
                singlePackage.campaignItineraryId
              }` + `${history.location.search ? history.location.search : ''}`
        }
        className="btn btn-primary tracker-campaign-custombtn"
        onClick={e => e.preventDefault()}
      >
        Customize
      </Link>
    </div>
  );
}

function NoItinerariesFoundMessage({}) {
  return (
    <div className="clearfix">
      <div className="clearfix vmargin-large color-grey text-center">
        <p className="small-heading">
          Hey, we can't seem to find any itineraries matching your interests.
        </p>
        <span className="meta-text">
          Please{' '}
          <Link className="underline" to={`/packages`} target={'_self'}>
            click here
          </Link>{' '}
          to show all itineraries
        </span>
      </div>
    </div>
  );
}

PackagesContent.propTypes = {
  history: PropTypes.shape({
    location: PropTypes.shape({
      pathname: PropTypes.string.isRequired,
      search: PropTypes.string
    }),
    push: PropTypes.func.isRequired
  }),
  packages: PropTypes.shape({
    filteredItineraries: PropTypes.arrayOf(PropTypes.object),
    testimonials: PropTypes.arrayOf(PropTypes.object),
    campaignDetails: PropTypes.object
  }),
  actions: PropTypes.shape({
    changeDevicetype: PropTypes.func,
    getUserDetails: PropTypes.func,
    getVacations: PropTypes.func
  })
};

PackageCardList.propTypes = {
  testimonials: PropTypes.arrayOf(PropTypes.object),
  randomNo: PropTypes.func,
  history: PropTypes.shape({
    location: PropTypes.shape({
      pathname: PropTypes.string.isRequired,
      search: PropTypes.string
    }),
    push: PropTypes.func.isRequired
  }).isRequired,
  packages: PropTypes.arrayOf(PropTypes.object)
};

SinglePackageCard.propTypes = {
  p: PropTypes.shape({
    inclusions: PropTypes.arrayOf(PropTypes.object),
    image: PropTypes.string
  }),
  testimonialsDescription: PropTypes.object,
  testimonials: PropTypes.arrayOf(PropTypes.object),
  specialDealsText: PropTypes.string,
  showGetCostModal: PropTypes.func,
  history: PropTypes.shape({
    location: PropTypes.shape({
      pathname: PropTypes.string.isRequired,
      search: PropTypes.string
    }),
    push: PropTypes.func.isRequired
  }),
  testimonialsIndex: PropTypes.bool
};

PackageSpecialTag.propTypes = {
  specialDealsText: PropTypes.string
};

PackageRightCol.propTypes = {
  history: PropTypes.shape({
    location: PropTypes.shape({
      pathname: PropTypes.string.isRequired,
      search: PropTypes.string
    }),
    push: PropTypes.func.isRequired
  }),
  packages: PropTypes.shape({
    itineraryCost: PropTypes.string,
    campaignItineraryId: PropTypes.string
  })
};
