import React, { Component } from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';

export default class PackagesBreadcrumbSection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mobileInclusionsExpandedFor: 9999,
      noOfCardToShow: 10
    };
  }

  render() {
    let {
      region,
      getThemeByUrl
    } = this.props;

    let theme = getThemeByUrl();
    let themeUrl = theme === 'packages' ? theme : `${theme}-packages`;

    return (
      <section className="container lg-container sm-full-width" id="breadcrumb">
        <div className="row">
          <div className="col-md-12">
            <ol
              vocab={'http://schema.org/'}
              typeof={'BreadcrumbList'}
              className="breadcrumb meta-text"
            >
              <li
                property={'itemListElement'}
                typeof={'ListItem'}
                className="tracker-pkg-homeicon"
              >
                <a
                  href="https://pickyourtrail.com"
                  property={'item'}
                  typeof={'WebPage'}
                >
                  <i className="vehoicon-home" />
                  <span property={'name'} className={'sr-only'}>
                    Home
                  </span>
                </a>
                <meta property={'position'} content={'1'} />
              </li>
              {region || theme ? (
                <li property={'itemListElement'} typeof={'ListItem'}>
                  <a
                    href={`https://pickyourtrail.com/packages`}
                    target={'_self'}
                    property={'item'}
                    typeof={'WebPage'}
                  >
                    <span property={'name'}>Packages</span>
                  </a>
                  <meta property={'position'} content={'2'} />
                </li>
              ) : (
                <li>Packages</li>
              )}
              {theme ? (
                region ? (
                  <li property={'itemListElement'} typeof={'ListItem'}>
                    <a
                      href={`https://pickyourtrail.com/${themeUrl}`}
                      target={'_self'}
                      property={'item'}
                      typeof={'WebPage'}
                    >
                      <span property={'name'}>{_.startCase(theme)}</span>
                    </a>
                    <meta property={'position'} content={'3'} />
                  </li>
                ) : (
                  <li>{_.startCase(theme)}</li>
                )
              ) : null}
              {region ? (
                theme !== 'packages' ? (
                  <li>{_.startCase(_.replace(region, '-', ' '))}</li>
                ) : (
                  <li property={'itemListElement'} typeof={'ListItem'}>
                    <a
                      href={`https://pickyourtrail.com/packages/${region}`}
                      target={'_self'}
                      property={'item'}
                      typeof={'WebPage'}
                    >
                      <span property={'name'}>
                        {_.startCase(_.replace(region, '-', ' '))}
                      </span>
                    </a>
                    <meta property={'position'} content={'4'} />
                  </li>
                )
              ) : null}
            </ol>
          </div>
        </div>
      </section>
    );
  }
}
PackagesBreadcrumbSection.propTypes = {
  packages: PropTypes.object
};
