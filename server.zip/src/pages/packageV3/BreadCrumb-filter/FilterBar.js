import React, { Component, Fragment } from 'react';
import classNames from 'classnames';
import { scrollToDown } from '../../../helpers/utilsHelper';
import _ from 'lodash';
import PropTypes from 'prop-types';
import queryString from 'query-string';

import {
  CitiesFilter,
  ThemeFilter,
  DurationFilter,
  AccomodationFilter,
  BudgetFilter
} from './filter';

export default class PackagesFilterBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ui: {
        CitiesFilter: {
          expanded: false,
          currentValue: 'CitiesFilter'
        },
        ThemeFilter: {
          expanded: false,
          currentValue: 'ThemeFilter'
        },
        DurationFilter: {
          expanded: false,
          currentValue: 'DurationFilter'
        },
        AccomodationFilter: {
          currentValue: 'AccomodationFilter',
          expanded: false
        },
        BudgetFilter: {
          currentValue: 'BudgetFilter',
          expanded: false
        }
      },
      testimonials: [],
      itemsToShow: 10,
      affixTop: false,
      storeCityFilter: '',
      storeThemeFilter: '',
      storeDurationFilter: '',
      storeBudgetFilter: '',
      storeAccomdationFilter: '',

      clearedMobileFilter: false,
      mobileOpenTestimonialId: 0
    };
    this.toggleFilterOpen = this.toggleFilterOpen.bind(this);
    this.closeAllFilters = this.closeAllFilters.bind(this);
    this.applyMobileFilters = this.applyMobileFilters.bind(this);
    this.resetMobileFilters = this.resetMobileFilters.bind(this);
    this.storeFilterValueforMobile = this.storeFilterValueforMobile.bind(this);
    this.scrollListener = this.scrollListener.bind(this);
    this.setAffixTop = this.setAffixTop.bind(this);
  }

  componentDidMount() {
    window.addEventListener('scroll', this.scrollListener);

    let selectedBudgets = this.props.getBudgetByUrl() || [];
    let selectedHotelStarRatings = this.props.getStarRatingByUrl() || [];
    let selectedDuration = this.props.getDurationByUrl() || [];
    if (selectedBudgets || selectedDuration || selectedHotelStarRatings) {
      this.setState({
        storeDurationFilter: selectedDuration,
        storeAccomdationFilter: selectedHotelStarRatings,
        storeBudgetFilter: selectedBudgets
      });
    }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.scrollListener);
  }

  scrollListener() {
    let scroll = window.pageYOffset;
    let TitleSection = document.getElementById('breadcrumb');
    let BannerSection = document.getElementById('banner');
    let scrollable =
      TitleSection &&
      BannerSection &&
      scroll >= TitleSection.clientHeight + BannerSection.clientHeight;
    if (scrollable && !this.state.affixTop) {
      this.setState({ affixTop: true });
    } else if (!scrollable && this.state.affixTop) {
      this.setState({ affixTop: false });
    }
  }

  setAffixTop(isExpanded) {
    if (isExpanded) {
      let element = document.getElementById('banner');
      let scrollToPos = element ? element.clientHeight - 100 : 0;
      scrollToDown(scrollToPos, 500);
    }
  }

  closeAllFilters() {
    let t = this.state;
    t.ui.CitiesFilter.expanded = false;
    t.ui.ThemeFilter.expanded = false;
    t.ui.DurationFilter.expanded = false;
    t.ui.AccomodationFilter.expanded = false;
    t.ui.BudgetFilter.expanded = false;
    this.setState(t);
  }

  findParentClass(el, cls) {
    if (el.classList.contains('filter-bar')) {
      return true;
    } else {
      while ((el = el.parentElement)) {
        if (el.classList.contains('filter-bar')) {
          return true;
        }
      }
    }
  }

  toggleFilterOpen(e, value) {
    let ele = this.findParentClass(e.target, 'filter-bar');
    let dropdown = document.querySelector('.dropdown.open');
    let tempState = this.state;
    if (!e.target.closest('.dropdown.open')) {
      this.closeAllFilters();
    }
    if (!e.target.closest('.dropdown-menu')) {
      tempState.ui[value].expanded = !tempState.ui[value].expanded;
      this.props.filterBarClickable(e);
      this.setState(tempState);
    }
  }

  storeFilterValueforMobile(value, stateFilter, cb = null) {
    let exState = this.state;
    if (stateFilter === 'citiesFilter') {
      exState.storeCityFilter = value;
    } else if (stateFilter === 'themeFilter') {
      exState.storeThemeFilter = value;
    } else if (stateFilter === 'durationFilter') {
      exState.storeDurationFilter = value;
    } else if (stateFilter === 'accoFilter') {
      exState.storeAccomdationFilter = value;
    } else if (stateFilter === 'budgetFilter') {
      exState.storeBudgetFilter = value;
    }
    this.setState(exState, () => {
      cb && cb();
    });
  }

  applyMobileFilters(e, selectedDestination, selectedTheme) {
    if (selectedTheme === 'packages') {
      selectedTheme = '';
    }

    let searchQuery = this.props.getSearchQuery();
    let qs = queryString.parse(searchQuery);
    let new_url = '';
    selectedTheme = selectedTheme && selectedTheme.replace('-packages', '');

    let destinationValue = this.state.storeCityFilter || selectedDestination;
    let themevalue = this.state.storeThemeFilter || selectedTheme;
    destinationValue = destinationValue === 'all' ? `` : destinationValue;
    themevalue = themevalue === 'all' ? '' : themevalue;
    let durationFilter = this.state.storeDurationFilter;
    let accoFilter = this.state.storeAccomdationFilter || [];
    let budgetFilter = this.state.storeBudgetFilter;
    if (durationFilter.length === 0 && !qs.durations) {
      delete qs.durations;
    } else {
      qs.durations = durationFilter;
    }
    if (accoFilter.length === 0 && !qs.hotel_ratings) {
      delete qs.hotel_ratings;
    } else {
      qs.hotel_ratings = accoFilter;
    }
    if (budgetFilter.length === 0 && !qs.budgets) {
      delete qs.budgets;
    } else {
      qs.budgets = budgetFilter;
    }
    if (
      destinationValue === selectedDestination &&
      selectedTheme === themevalue
    ) {
      window.location.href =
        window.location.pathname +
        (!_.isEmpty(qs) ? '?' + queryString.stringify(qs) : '');

      this.props.closeMobileFilterStatus(e);
    } else {
      new_url =
        (themevalue ? '/' + themevalue + '-' : '/') +
        'packages' +
        (destinationValue ? '/' + destinationValue : '') +
        (!_.isEmpty(qs) ? '?' + queryString.stringify(qs) : '');
      window.location.href = new_url;
    }
  }

  resetMobileFilters = () => {
    const { campaignDetails } = this.props;

    /**
     * Resetting to the actual path for dynamic URLs - otherwise it will redirect to packages page
     * Identifying the dynamic page vs actual page using the filter settings // noRegionThemeFilter
     */
    if (campaignDetails && campaignDetails.noRegionThemeFilter) {
      window.location.href = window.location.pathname;
    } else {
      window.location.href = '/packages';
    }
  };

  render() {
    let {
      filterClicked,
      needMobileFilter,
      getDestinationByUrl,
      getThemeByUrl,
      getBudgetByUrl,
      getDurationByUrl,
      getStarRatingByUrl,
      checkBoxDremove,
      checkBoxSremove,
      checkBoxBremove,
      campaignDetails
    } = this.props;

    let selectedDestination = getDestinationByUrl() || '';
    let selectedTheme = getThemeByUrl() || '';
    let selectedBudgets = getBudgetByUrl() || [];
    let selectedHotelStarRatings = getStarRatingByUrl();
    let selectedDuration = getDurationByUrl();

    let count = needMobileFilter !== '' ? 1032 : filterClicked ? 3 : null;

    return (
      <section
        className={classNames(`filter-bar ${needMobileFilter}`, {
          'affix-top': this.state.affixTop
        })}
        // className={`filter-bar ${needMobileFilter}`}
        style={{ zIndex: count }}
      >
        <div className="filter-header hidden-md hidden-lg">
          <span className="medium-heading bold">Filters</span>
          <button
            type="button"
            className="btn btn-link-grey close-filter"
            onClick={this.props.closeMobileFilterStatus}
          >
            <i className="vehoicon-close" />
          </button>
        </div>
        {/* hiding destination and theme filter based on noRegionThemeFilter value from API.
             if it is false we will show the filter else not needed */}
        <div className="filter-tabs">
          {campaignDetails && !campaignDetails.noRegionThemeFilter ? (
            <Fragment>
              <CitiesFilter
                storeFilterValueforMobile={this.storeFilterValueforMobile}
                history={this.props.history}
                toggleFilterOpen={this.toggleFilterOpen}
                expand={this.state.ui.CitiesFilter.expanded}
                selectedDestination={selectedDestination}
                getDestinationByUrl={this.props.getDestinationByUrl}
                getThemeByUrl={getThemeByUrl}
                getSearchQuery={this.props.getSearchQuery}
                currentValue={this.state.ui.CitiesFilter.currentValue}
                setAffixTop={this.setAffixTop}
                applyMobileFilters={this.applyMobileFilters}
              />

              <ThemeFilter
                storeFilterValueforMobile={this.storeFilterValueforMobile}
                history={this.props.history}
                toggleFilterOpen={this.toggleFilterOpen}
                expand={this.state.ui.ThemeFilter.expanded}
                getSearchQuery={this.props.getSearchQuery}
                selectedTheme={selectedTheme}
                currentValue={this.state.ui.ThemeFilter.currentValue}
                setAffixTop={this.setAffixTop}
              />
            </Fragment>
          ) : null}

          <DurationFilter
            history={this.props.history}
            toggleFilterOpen={this.toggleFilterOpen}
            storeFilterValueforMobile={this.storeFilterValueforMobile}
            checkBoxremove={checkBoxDremove}
            checkBoxValueRemoved={this.props.checkBoxValueRemoved}
            expand={this.state.ui.DurationFilter.expanded}
            getDurationByUrl={this.props.getDurationByUrl}
            getSearchQuery={this.props.getSearchQuery}
            removeFilterOverlay={this.props.removeFitlerOverlay}
            currentValue={this.state.ui.DurationFilter.currentValue}
            setAffixTop={this.setAffixTop}
          />

          <AccomodationFilter
            history={this.props.history}
            toggleFilterOpen={this.toggleFilterOpen}
            storeFilterValueforMobile={this.storeFilterValueforMobile}
            checkBoxremove={checkBoxSremove}
            checkBoxValueRemoved={this.props.checkBoxValueRemoved}
            getSearchQuery={this.props.getSearchQuery}
            getStarRatingByUrl={this.props.getStarRatingByUrl}
            isMobileFilterCleared={this.state.clearedMobileFilter}
            expand={this.state.ui.AccomodationFilter.expanded}
            removeFilterOverlay={this.props.removeFitlerOverlay}
            currentValue={this.state.ui.AccomodationFilter.currentValue}
            setAffixTop={this.setAffixTop}
          />

          <BudgetFilter
            history={this.props.history}
            toggleFilterOpen={this.toggleFilterOpen}
            storeFilterValueforMobile={this.storeFilterValueforMobile}
            expand={this.state.ui.BudgetFilter.expanded}
            checkBoxremove={checkBoxBremove}
            checkBoxValueRemoved={this.props.checkBoxValueRemoved}
            currentValue={this.state.ui.BudgetFilter.currentValue}
            getSearchQuery={this.props.getSearchQuery}
            getBudgetByUrl={this.props.getBudgetByUrl}
            removeFilterOverlay={this.props.removeFitlerOverlay}
            isMobileFilterCleared={this.state.clearedMobileFilter}
            setAffixTop={this.setAffixTop}
          />
        </div>

        <div className="filter-footer hidden-md hidden-lg">
          <button
            type="button"
            className="btn btn-default btn-outline"
            onClick={e => this.resetMobileFilters(e)}
          >
            Clear all
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={e =>
              this.applyMobileFilters(
                e,
                selectedDestination,
                selectedTheme,
                selectedDuration,
                selectedHotelStarRatings,
                selectedBudgets
              )
            }
          >
            Apply
          </button>
        </div>
      </section>
    );
  }
}

PackagesFilterBar.propTypes = {
  packages: PropTypes.object,
  getDestinationByUrl: PropTypes.func,
  getBudgetByUrl: PropTypes.func,
  getDurationByUrl: PropTypes.func,
  getStarRatingByUrl: PropTypes.func,
  filterBarClickable: PropTypes.func,
  history: PropTypes.shape({
    location: PropTypes.shape({
      pathname: PropTypes.string.isRequired,
      search: PropTypes.string
    }),
    push: PropTypes.func.isRequired
  }),
  removeFitlerOverlay: PropTypes.func,
  getSearchQuery: PropTypes.func,
  selectedTheme: PropTypes.string
};
