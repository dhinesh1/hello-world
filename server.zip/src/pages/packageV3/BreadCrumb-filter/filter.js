import React, { Component } from 'react';
import _ from 'lodash';
import { getRegionByCode } from '../../../helpers/regionHelpers';
import DropDownMenu from '../../../common_components/DropDownMenu';
import classNames from 'classnames';
import queryString from 'query-string';
import { isFaqMobile } from '../../../helpers/utilsHelper';
import { Popover, Overlay } from 'react-bootstrap';

export class CitiesFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false,
      disabled: true,
      radioButton: true,
      setValue: '',
      setText: '',
      selectedDurations: [],
      setDataText: '',
      showPopOver: false,
      target: ''
    };
    this.stateClickable = this.stateClickable.bind(this);
    this.setTextValue = this.setTextValue.bind(this);
    this.mobileClickable = this.mobileClickable.bind(this);
  }

  stateClickable(e) {
    let target = e.target.parentElement.querySelector('input');
    let destinationValue = target.value;
    let text = target.getAttribute('data-text');
    if (!isFaqMobile()) {
      this.props.storeFilterValueforMobile(
        destinationValue,
        'citiesFilter',
        () => {
          let destination = this.props.getDestinationByUrl() || '';
          let theme = this.props.getThemeByUrl() || '';

          this.props.applyMobileFilters({}, destination, theme);
        }
      );
    } else {
      this.mobileClickable(destinationValue, text);
    }
  }

  setTextValue(cityData, cityValue, selectedDestination) {
    if (selectedDestination === '') {
      return 'All Destination';
    }
    let themeIndex = cityValue.indexOf(selectedDestination);
    let displayText = cityData[themeIndex];
    return displayText;
  }

  mobileClickable(value, text) {
    this.props.storeFilterValueforMobile(value, 'citiesFilter');
    this.setState({
      radioButton: true,
      setDataText: text,
      setValue: value
    });
  }

  render() {
    let {
      expand,
      toggleFilterOpen,
      currentValue,
      history,
      getSearchQuery,
      selectedDestination,
      getDestinationByUrl,
      storeFilterValueforMobile
    } = this.props;
    let {
      expanded,
      disabled,
      setValue,
      setText,
      setDataText,
      showPopOver,
      target
    } = this.state;
    let cityData = [
      'All Destination',
      'Australia',
      'New Zealand',
      'Bali',
      'Europe',
      'France',
      'Italy',
      'Austria',
      'Switzerland',
      'Germany',
      'Greece',
      'Spain',
      'United Kingdom',
      'Thailand',
      'Dubai',
      'Singapore',
      'Maldives',
      'Seychelles',
      'Malaysia',
      'South Africa',
      'Cambodia',
      'Mauritius'
    ];
    let cityValue = [
      'all',
      'australia',
      'new-zealand',
      'bali',
      'europe',
      'france',
      'italy',
      'austria',
      'switzerland',
      'germany',
      'greece',
      'spain',
      'united-kingdom',
      'thailand',
      'dubai',
      'singapore',
      'maldives',
      'seychelles',
      'malaysia',
      'south-africa',
      'cambodia',
      'mauritius'
    ];

    let caseChange =
      selectedDestination.charAt(0).toUpperCase() +
      selectedDestination.substr(1).toLowerCase();
    let ele = cityData.map((p, i) => {
      return (
        <li className="tracker-pkg-destination">
          <label
            className="custom-options"
            onClick={e => this.stateClickable(e)}
          >
            <input
              type="radio"
              defaultValue={cityValue[i]}
              data-text={p}
              name="destination"
              checked={
                (selectedDestination !== '' && setValue === ''
                  ? cityValue[i] === selectedDestination
                  : setDataText === p) || p === 'All Destination'
              }
            />
            <span>{p}</span>
            <i />
          </label>
        </li>
      );
    });
    return (
      <DropDownMenu
        trigger={'click'}
        isCampaignPage={true}
        onClick={this.props.setAffixTop(this.props.expand)}
        history={this.props.history}
        expand={this.props.expand}
        wrapperClassName={'dropdown'}
        currentValue={'CitiesFilter'}
        ref={instance => {
          this.drowDownLoggedInMenu = instance;
        }}
        toggleFilterOpen={this.props.toggleFilterOpen}
        triggerElement={
          <a
            className="dropdown-toggle tracker-pkg-cities"
            href=""
            data-toggle="dropdown"
            aria-expanded={expand}
          >
            Destination
            <span
              className={classNames({
                'dd-val': selectedDestination !== ''
              })}
            >
              {setText === ''
                ? this.setTextValue(cityData, cityValue, selectedDestination)
                : setText}
            </span>
          </a>
        }
        wrapperElement={'div'}
      >
        <li>
          <ul className="list-unstyled mb-0 list-items">{ele}</ul>
        </li>
      </DropDownMenu>
    );
  }
}

export class ThemeFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false,
      setText: '',
      disabled: true,
      radioButton: false,
      setValue: '',
      setDataText: '',
      showPopOver: false,
      target: ''
    };
    this.setTextValue = this.setTextValue.bind(this);
    this.stateClickable = this.stateClickable.bind(this);
    this.mobileClickable = this.mobileClickable.bind(this);
  }

  mobileClickable(value, text) {
    let storeThemeFilter;
    if (value && value === 'visa-on-arrival-packages') {
      storeThemeFilter = 'visa-on-arrival';
    } else {
      storeThemeFilter = value && value.split('-')[0];
    }
    this.props.storeFilterValueforMobile(storeThemeFilter, 'themeFilter');
    this.setState({
      radioButton: true,
      setDataText: text,
      setValue: value
    });
  }

  stateClickable(e) {
    let target = e.target.parentElement.querySelector('input');
    let themeValue = target.value;
    let text = target.getAttribute('data-text');
    if (!isFaqMobile()) {
      this.setState({
        radioButton: true,
        setDataText: text,
        setValue: themeValue
      });
      let new_url;
      themeValue = themeValue === 'all' ? `packages` : themeValue;
      let pathname = window.location.pathname;

      let selectedTheme = this.props.selectedTheme;
      const theme =
        selectedTheme === ''
          ? pathname.split('/')[1]
          : selectedTheme + '-packages';

      let queryString = this.props.getSearchQuery();
      if (themeValue === '' && theme !== '') {
        themeValue = theme;
      }
      new_url = _.replace(pathname, theme, themeValue);
      window.location.href = new_url + queryString;
      this.setState({
        disabled: false,
        setText: this.state.setDataText,
        showPopOver: false,
        target: ''
      });
    } else {
      this.mobileClickable(themeValue, text);
    }
  }

  setTextValue(themeData, themeValue, selectedTheme) {
    let themeIndex = themeValue.indexOf(selectedTheme);
    if (themeIndex > 0) {
      return themeData[themeIndex];
    }
    return 'All interests';
  }

  render() {
    let { expand, selectedTheme } = this.props;
    const themeVal =
      selectedTheme === 'packages' ? 'all' : selectedTheme + '-packages';

    let { setValue, setText, setDataText } = this.state;

    let themeData = [
      'All interests',
      'For the Newly weds',
      'Family Specials',
      'Beach Lovers',
      'Adrenaline Junkies',
      'Visa on arrival'
    ];

    let themeValue = [
      'all',
      'honeymoon-packages',
      'family-packages',
      'beach-packages',
      'adventure-packages',
      'visa-on-arrival-packages'
    ];

    let ele = themeData.map((p, i) => {
      return (
        <li className="tracker-pkg-themes">
          <label
            className="custom-options"
            onClick={e => this.stateClickable(e)}
          >
            <input
              type="radio"
              defaultValue={themeValue[i]}
              data-text={p}
              name="interests"
              checked={
                (selectedTheme !== '' && setValue === ''
                  ? themeValue[i] === themeVal
                  : setDataText === p) || p === 'All interests'
              }
            />
            <span>{p}</span>
            <i />
          </label>
        </li>
      );
    });

    return (
      <DropDownMenu
        trigger={'click'}
        isCampaignPage={true}
        onClick={this.props.setAffixTop(this.props.expand)}
        history={this.props.history}
        expand={this.props.expand}
        toggleFilterOpen={this.props.toggleFilterOpen}
        currentValue={'ThemeFilter'}
        wrapperClassName={'dropdown'}
        ref={instance => {
          this.drowDownLoggedInMenu = instance;
        }}
        triggerElement={
          <a
            className="dropdown-toggle tracker-pkg-themes"
            data-toggle="dropdown"
            aria-expanded={expand}
          >
            Themes
            <span
              className={classNames({
                'dd-val':
                  this.setTextValue(themeData, themeValue, themeVal) !==
                  'All interests'
              })}
            >
              {setText === ''
                ? this.setTextValue(themeData, themeValue, themeVal)
                : setText}
            </span>
          </a>
        }
        wrapperElement={'div'}
      >
        <li>
          <ul className="list-unstyled mb-0 list-items">{ele}</ul>
        </li>
      </DropDownMenu>
    );
  }
}

export class DurationFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false,
      reDisabled: true,
      apDisabled: true,
      showPopOver: false,
      target: '',
      setText: '',
      setValue: '',
      checkBox: false,
      selecteddataText: [],
      selectedDurations: [],
      setDataText: '',
      durationData: ['4-8 days', '9-12 days', '13-16 days', 'Above 16 days'],
      durationvalue: ['4_8', '9_12', '13_16', '16_99']
    };
    this.applyFilter = this.applyFilter.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.stateClickable = this.stateClickable.bind(this);
    this.setTextValue = this.setTextValue.bind(this);
    this.findDataText = this.findDataText.bind(this);
  }

  findDataText(value, text, urlvalue) {
    let index = value.indexOf(urlvalue);
    return text[index];
  }

  setTextValue(value, selecteddataText) {
    let stateDuration = this.state.selectedDurations;
    if (
      stateDuration.includes('all') ||
      stateDuration.length === 0 ||
      stateDuration.length === 4
    ) {
      this.setState({ setDataText: 'All Durations', setValue: 'all' });
    } else {
      this.setState({ setDataText: selecteddataText, setValue: value });
    }
  }

  stateClickable(e, p) {
    let ele = e.target.parentElement.querySelector('input');
    let value = ele.value;
    let text = ele.getAttribute('data-text');
    let tempValue;
    let stateSelectedDuration = this.state.selectedDurations;
    tempValue = this.state.selecteddataText.slice();
    if (ele.checked) {
      stateSelectedDuration = _.pull(stateSelectedDuration, value);
      tempValue = _.pull(tempValue, text);
      this.setState({
        selecteddataText: tempValue
      });
    } else {
      if (stateSelectedDuration.includes(value) === false) {
        tempValue.push(text);
        this.setState({
          selecteddataText: tempValue
        });
        stateSelectedDuration.push(value);
      }
    }
    if (isFaqMobile()) {
      this.props.storeFilterValueforMobile(
        this.state.selectedDurations,
        'durationFilter'
      );
    }
    this.setTextValue(stateSelectedDuration, tempValue);
    this.setState({
      checkBox: stateSelectedDuration.length > 0,
      selectedDurations: stateSelectedDuration,
      reDisabled: !stateSelectedDuration.length,
      apDisabled: false
    });
    let isShown = JSON.parse(window.localStorage.getItem('popover'));
    if (isShown) {
      this.setState({
        showPopOver: true,
        target: e.target.closest('.dropdown-menu').querySelector('.pull-right')
      });
      window.localStorage.setItem('popover', false);
    }
    setTimeout(() => {
      this.setState({
        showPopOver: false,
        target: ''
      });
    }, 2000);
  }

  componentWillMount() {
    let remainDuration = this.props.getDurationByUrl() || [];
    let multipleItems = false;
    let tempValue;
    if (remainDuration.length > 0) {
      if (typeof remainDuration !== 'string') {
        if (remainDuration.length === 4) {
          multipleItems = true;
        }
        remainDuration.map((p, i) => {
          tempValue = this.state.selectedDurations;
          tempValue.push(p);
          this.setState({
            selectedDurations: tempValue
          });
          let value = this.findDataText(
            this.state.durationvalue,
            this.state.durationData,
            p
          );
          tempValue = this.state.selecteddataText;
          tempValue.push(value);
          this.setState({
            selecteddataText: tempValue
          });
        });
      } else if (remainDuration !== '') {
        tempValue = this.state.selectedDurations;
        tempValue.push(remainDuration);
        this.setState({
          selectedDurations: tempValue
        });
        let value = this.findDataText(
          this.state.durationvalue,
          this.state.durationData,
          remainDuration
        );
        tempValue = this.state.selecteddataText;
        tempValue.push(value);
        this.setState({
          selecteddataText: tempValue
        });
      }
      this.setState({
        setText: multipleItems ? 'All Durations' : this.state.selecteddataText,
        reDisabled: false,
        apDisabled: false
      });
    }
  }

  componentDidUpdate() {
    if (
      this.props.checkBoxremove !== '' &&
      this.state.selectedDurations.includes(this.props.checkBoxremove)
    ) {
      this.setState({
        selectedDurations: _.pull(
          this.state.selectedDurations,
          this.props.checkBoxremove
        )
      });
      let value = this.findDataText(
        this.state.durationvalue,
        this.state.durationData,
        this.props.checkBoxremove
      );
      this.setState({
        selecteddataText: _.pull(this.state.selecteddataText, value)
      });
      this.setState({
        setText:
          this.state.selecteddataText.length === 0
            ? 'All Durations'
            : this.state.selecteddataText
      });
      this.props.checkBoxValueRemoved(this.props.checkBoxremove);
    }
  }

  applyFilter(e) {
    let qs = queryString.parse(this.props.getSearchQuery());
    qs.durations = this.state.selectedDurations;
    window.location.href =
      window.location.pathname +
      (Object.values(qs).join('') ? '?' : '') +
      queryString.stringify(qs);
    this.setState({
      apDisabled: this.state.selectedDurations === 0,
      setText: this.state.setDataText,
      showPopOver: false,
      target: ''
    });
    if (
      this.state.selectedDurations.length === 4 ||
      this.state.selectedDurations.length === 0
    ) {
      this.setState({ setText: 'All Durations', setValue: 'all' });
    }
    let target = e.target.closest('.packages').querySelector('.filter-overlay');
    this.props.removeFilterOverlay(target, true);
  }

  resetFilter(e) {
    if (this.state.checkBox) {
      let lichecked = e.target.parentElement.previousSibling.querySelector(
        '.list-items'
      ).children;
      [].forEach.call(lichecked, function(el) {
        el.querySelector('input').checked = false;
      });
    }
    this.setState({
      reDisabled: true,
      apDisabled: false,
      setDataText: '',
      selectedDurations: [],
      selecteddataText: []
    });
  }

  render() {
    let { expand } = this.props;
    let { selectedDurations } = this.state;

    return (
      <DropDownMenu
        onClick={this.props.setAffixTop(this.props.expand)}
        trigger={'click'}
        isCampaignPage={true}
        history={this.props.history}
        expand={this.props.expand}
        currentValue={'DurationFilter'}
        toggleFilterOpen={this.props.toggleFilterOpen}
        wrapperClassName={'dropdown'}
        ref={instance => {
          this.drowDownLoggedInMenu = instance;
        }}
        triggerElement={
          <a
            className="dropdown-toggle tracker-pkg-duration"
            data-toggle="dropdown"
            aria-expanded={expand}
          >
            Durations
            <span
              className={classNames({
                'dd-val':
                  (this.state.setText !== '' &&
                    this.state.setText !== 'All Durations') ||
                  selectedDurations.length === 4
              })}
            >
              {this.state.setText === ''
                ? 'All Durations'
                : this.state.setText === 'All Durations'
                  ? 'All Durations'
                  : (this.state.setText || []).join(', ')}
            </span>
          </a>
        }
        wrapperElement={'div'}
      >
        <li className="tracker-pkg-duration-list">
          <ul className="list-unstyled mb-0 list-items">
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  type="checkbox"
                  name="duration"
                  onClick={e => this.handleChange(e)}
                  checked={selectedDurations.includes('4_8')}
                  defaultValue="4_8"
                  data-text="4-8 days"
                />
                <span>4-8 days</span>
                <i />
              </label>
            </li>

            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  onClick={e => this.handleChange(e)}
                  type="checkbox"
                  name="duration"
                  checked={selectedDurations.includes('9_12')}
                  defaultValue="9_12"
                  data-text="9-12 days"
                />
                <span>9-12 days</span>
                <i />
              </label>
            </li>

            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  onClick={e => this.handleChange(e)}
                  type="checkbox"
                  name="duration"
                  defaultValue="13_16"
                  data-text="13-16 days"
                  checked={selectedDurations.includes('13_16')}
                />
                <span>13-16 days</span>
                <i />
              </label>
            </li>

            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  onClick={e => this.handleChange(e)}
                  type="checkbox"
                  name="duration"
                  defaultValue="16_99"
                  data-text="Above 16 days"
                  checked={selectedDurations.includes('16_99')}
                />
                <span>Above 16 days</span>
                <i />
              </label>
            </li>
          </ul>
        </li>

        <ResetCheckApplyButton
          reDisabled={this && this.state.reDisabled}
          apDisabled={this && this.state.apDisabled}
          resetFilter={this && this.resetFilter}
          applyFilter={this && this.applyFilter}
          showPopOver={this && this.state.showPopOver}
          targetPopOver={this && this.state.target}
        />
      </DropDownMenu>
    );
  }
}

export class AccomodationFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false,
      reDisabled: true,
      apDisabled: true,
      checkBox: false,
      setText: '',
      selectedAccomdation: [],
      selecteddataText: [],
      accoData: ['3 Star & Below', '4 Star', '5 Star'],
      accoValue: ['3_3', '4_4', '5_5'],
      setDataText: '',
      showPopOver: false,
      target: ''
    };
    this.applyFilter = this.applyFilter.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.stateClickable = this.stateClickable.bind(this);
    this.setTextValue = this.setTextValue.bind(this);
    this.findDataText = this.findDataText.bind(this);
  }

  findDataText(value, text, urlvalue) {
    let index = value.indexOf(urlvalue);
    return text[index];
  }

  setTextValue(value, selecteddataText) {
    let stateAcco = this.state.selectedAccomdation;
    if (
      stateAcco.includes('all') ||
      stateAcco.length === 0 ||
      stateAcco.length === 3
    ) {
      this.setState({ setDataText: 'All Types', setValue: 'all' });
    } else {
      this.setState({ setDataText: selecteddataText, setValue: value });
    }
  }

  componentDidUpdate() {
    if (
      this.props.checkBoxremove !== '' &&
      this.state.selectedAccomdation.includes(this.props.checkBoxremove)
    ) {
      this.setState({
        selectedAccomdation: _.pull(
          this.state.selectedAccomdation,
          this.props.checkBoxremove
        )
      });
      let value = this.findDataText(
        this.state.accoValue,
        this.state.accoData,
        this.props.checkBoxremove
      );
      this.setState({
        selecteddataText: _.pull(this.state.selecteddataText, value)
      });
      this.setState({
        setText:
          this.state.selecteddataText.length === 0
            ? 'All Types'
            : this.state.selecteddataText
      });
      this.props.checkBoxValueRemoved(this.props.checkBoxremove);
    }
  }

  componentWillMount() {
    let remainAcco = this.props.getStarRatingByUrl() || [];
    let multipleItems = false;
    let tempValue;
    if (remainAcco.length > 0) {
      if (typeof remainAcco !== 'string') {
        if (remainAcco.length === 3) {
          multipleItems = true;
        }
        remainAcco.map((p, i) => {
          tempValue = this.state.selectedAccomdation;
          tempValue.push(p);
          this.setState({
            selectedAccomdation: tempValue
          });
          tempValue = this.state.selecteddataText;
          let value = this.findDataText(
            this.state.accoValue,
            this.state.accoData,
            p
          );
          tempValue.push(value);
          this.setState({
            selecteddataText: tempValue
          });
        });
      } else if (remainAcco !== '') {
        tempValue = this.state.selectedAccomdation;
        tempValue.push(remainAcco);
        this.setState({ selectedAccomdation: tempValue });
        let value = this.findDataText(
          this.state.accoValue,
          this.state.accoData,
          remainAcco
        );
        tempValue = this.state.selecteddataText;
        tempValue.push(value);
        this.setState({ selecteddataText: tempValue });
      }
      this.setState({
        selectedAccomdation: this.state.selectedAccomdation,
        selecteddataText: this.state.selecteddataText,
        setText: multipleItems ? 'All Types' : this.state.selecteddataText,
        reDisabled: false,
        apDisabled: false
      });
    }
  }

  stateClickable(e, p) {
    let ele = e.target.parentElement.querySelector('input');
    let value = ele.value;
    let text = ele.getAttribute('data-text');
    let stateSelectedAcco = this.state.selectedAccomdation;
    let tempValue = this.state.selecteddataText.slice();
    if (ele.checked) {
      stateSelectedAcco = _.pull(stateSelectedAcco, value);
      tempValue = _.pull(tempValue, text);
      this.setState({
        selecteddataText: tempValue
      });
    } else {
      if (stateSelectedAcco.includes(value) === false) {
        tempValue.push(text);
        stateSelectedAcco.push(value);
        this.setState({
          selecteddataText: tempValue
        });
      }
    }
    if (isFaqMobile()) {
      this.props.storeFilterValueforMobile(
        this.state.selectedAccomdation,
        'accoFilter'
      );
    }
    this.setTextValue(stateSelectedAcco, tempValue);
    this.setState({
      checkBox: stateSelectedAcco.length > 0,
      selectedAccomdation: stateSelectedAcco,
      reDisabled: !stateSelectedAcco.length,
      apDisabled: false
    });
    let isShown = JSON.parse(window.localStorage.getItem('popover'));
    if (isShown) {
      this.setState({
        showPopOver: true,
        target: e.target.closest('.dropdown-menu').querySelector('.pull-right')
      });
      window.localStorage.setItem('popover', false);
    }
    setTimeout(() => {
      this.setState({
        showPopOver: false,
        target: ''
      });
    }, 2000);
  }

  applyFilter(e) {
    let qs = queryString.parse(this.props.getSearchQuery());
    qs.hotel_ratings = this.state.selectedAccomdation;
    window.location.href =
      window.location.pathname +
      (Object.values(qs).join('') ? '?' : '') +
      queryString.stringify(qs);
    this.setState({
      apDisabled: this.state.selectedAccomdation === 0,
      setText: this.state.setDataText,
      showPopOver: false,
      target: ''
    });
    if (
      this.state.selectedAccomdation.length === 3 ||
      this.state.selectedAccomdation.length === 0
    ) {
      this.setState({ setText: 'All Types' });
    }
    let target = e.target.closest('.packages').querySelector('.filter-overlay');
    this.props.removeFilterOverlay(target, true);
  }

  resetFilter(e) {
    if (this.state.checkBox) {
      let lichecked = e.target.parentElement.previousSibling.querySelector(
        '.list-items'
      ).children;
      [].forEach.call(lichecked, function(el) {
        el.querySelector('input').checked = false;
      });
    }
    this.setState({
      reDisabled: true,
      apDisabled: false,
      setDataText: '',
      selectedAccomdation: [],
      selecteddataText: []
    });
  }

  render() {
    let { expand } = this.props;
    let { selectedAccomdation } = this.state;
    return (
      <DropDownMenu
        trigger={'click'}
        onClick={this.props.setAffixTop(this.props.expand)}
        expand={this.props.expand}
        isCampaignPage={true}
        history={this.props.history}
        currentValue={'AccomodationFilter'}
        wrapperClassName={'dropdown'}
        toggleFilterOpen={this.props.toggleFilterOpen}
        ref={instance => {
          this.drowDownLoggedInMenu = instance;
        }}
        triggerElement={
          <a
            className="dropdown-toggle tracker-pkg-accomodation"
            data-toggle="dropdown"
            aria-expanded={expand}
          >
            Accomodation
            <span
              className={classNames({
                'dd-val':
                  (this.state.setText !== '' &&
                    this.state.setText !== 'All Types') ||
                  selectedAccomdation.length === 3
              })}
            >
              {this.state.setText === ''
                ? 'All Types'
                : this.state.setText === 'All Types'
                  ? 'All Types'
                  : (this.state.setText || []).join(', ')}
            </span>
          </a>
        }
        wrapperElement={'div'}
      >
        <li className="tracker-pkg-accomodation-list">
          <ul className="list-unstyled mb-0 list-items">
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  type="checkbox"
                  name="hotel_rating"
                  data-text="3 Star & Below"
                  defaultValue={'3_3'}
                  checked={selectedAccomdation.includes('3_3')}
                />
                <span>3 Star &amp; Below</span>
                <i />
              </label>
            </li>
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  type="checkbox"
                  name="hotel_rating"
                  data-text="4 Star"
                  defaultValue={'4_4'}
                  checked={selectedAccomdation.includes('4_4')}
                />
                <span>4 Star</span>
                <i />
              </label>
            </li>
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  type="checkbox"
                  name="hotel_rating"
                  data-text="5 Star"
                  defaultValue={'5_5'}
                  checked={selectedAccomdation.includes('5_5')}
                />
                <span>5 Star</span>
                <i />
              </label>
            </li>
          </ul>
        </li>

        <ResetCheckApplyButton
          reDisabled={this && this.state.reDisabled}
          apDisabled={this && this.state.apDisabled}
          resetFilter={this && this.resetFilter}
          applyFilter={this && this.applyFilter}
          showPopOver={this && this.state.showPopOver}
          targetPopOver={this && this.state.target}
        />
      </DropDownMenu>
    );
  }
}

export class BudgetFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false,
      reDisabled: true,
      apDisabled: true,
      setText: '',
      checkBox: false,
      selectedBudgets: [],
      selecteddataText: [],
      setDataText: '',
      budgetData: [
        'Below ₹50k',
        '₹50k - ₹75k',
        '₹75k - ₹1L',
        '₹1L - ₹1.5L',
        '₹1.5L - ₹2L',
        'Above ₹2L'
      ],
      budgetValue: [
        '0_50000',
        '50000_75000',
        '75000_100000',
        '100000_150000',
        '150000_200000',
        '200000_9999999'
      ],
      showPopOver: false,
      target: ''
    };
    this.applyFilter = this.applyFilter.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.stateClickable = this.stateClickable.bind(this);
    this.setTextValue = this.setTextValue.bind(this);
    this.findDataText = this.findDataText.bind(this);
  }

  findDataText(value, text, urlvalue) {
    let index = value.indexOf(urlvalue);
    let displayText = text[index];
    return displayText;
  }

  setTextValue(value, selecteddataText) {
    let stateBudget = this.state.selectedBudgets;
    if (
      stateBudget.includes('all') ||
      stateBudget.length === 0 ||
      stateBudget.length === 6
    ) {
      this.setState({ setDataText: 'All Budgets', setValue: 'all' });
    } else {
      this.setState({ setDataText: selecteddataText, setValue: value });
    }
  }

  componentWillMount() {
    let remainBudget = this.props.getBudgetByUrl() || [];
    let multipleItems = false;
    let tempValue;
    if (remainBudget.length > 0) {
      if (typeof remainBudget !== 'string') {
        if (remainBudget.length === 6) {
          multipleItems = true;
        }
        remainBudget.map((p, i) => {
          tempValue = this.state.selectedBudgets;
          tempValue.push(p);
          this.setState({
            selectedBudget: tempValue
          });
          let value = this.findDataText(
            this.state.budgetValue,
            this.state.budgetData,
            p
          );
          tempValue = this.state.selecteddataText;
          tempValue.push(value);
          this.setState({ selecteddataText: tempValue });
        });
      } else if (remainBudget !== '') {
        tempValue = this.state.selectedBudgets;
        tempValue.push(remainBudget);
        this.setState({
          selectedBudget: tempValue
        });
        let value = this.findDataText(
          this.state.budgetValue,
          this.state.budgetData,
          remainBudget
        );
        tempValue = this.state.selecteddataText;
        tempValue.push(value);
        this.setState({
          selecteddataText: tempValue
        });
      }
      this.setState({
        selectedBudget: this.state.selectedBudgets,
        selecteddataText: this.state.selecteddataText,
        setText: multipleItems ? 'All Budgets' : this.state.selecteddataText,
        reDisabled: false,
        apDisabled: false
      });
    }
  }
  componentDidUpdate() {
    if (
      this.props.checkBoxremove !== '' &&
      this.state.selectedBudgets.includes(this.props.checkBoxremove)
    ) {
      this.setState({
        selectedBudgets: _.pull(
          this.state.selectedBudgets,
          this.props.checkBoxremove
        )
      });
      let value = this.findDataText(
        this.state.budgetValue,
        this.state.budgetData,
        this.props.checkBoxremove
      );
      this.setState({
        selecteddataText: _.pull(this.state.selecteddataText, value)
      });
      this.setState({
        setText:
          this.state.selecteddataText.length === 0
            ? 'All Budgets'
            : this.state.selecteddataText
      });
      this.props.checkBoxValueRemoved(this.props.checkBoxremove);
    }
  }

  stateClickable(e, p) {
    let ele = e.target.parentElement.querySelector('input');
    let value = ele.value;
    let text = ele.getAttribute('data-text');
    let stateSelectedBudget = this.state.selectedBudgets;
    let tempValue = this.state.selecteddataText.slice();
    if (ele.checked) {
      stateSelectedBudget = _.pull(stateSelectedBudget, value);
      tempValue = _.pull(tempValue, text);
      this.setState({
        selecteddataText: _.pull(tempValue, text)
      });
    } else {
      if (stateSelectedBudget.includes(value) === false) {
        tempValue.push(text);
        stateSelectedBudget.push(value);
        this.setState({
          selecteddataText: tempValue
        });
      }
    }
    if (isFaqMobile()) {
      this.props.storeFilterValueforMobile(stateSelectedBudget, 'budgetFilter');
    }
    this.setTextValue(stateSelectedBudget, tempValue);
    this.setState({
      checkBox: stateSelectedBudget.length > 0,
      selectedBudgets: stateSelectedBudget,
      reDisabled: !stateSelectedBudget.length,
      apDisabled: false
    });
    let isShown = JSON.parse(window.localStorage.getItem('popover'));
    if (isShown) {
      this.setState({
        showPopOver: true,
        target: e.target.closest('.dropdown-menu').querySelector('.pull-right')
      });
      window.localStorage.setItem('popover', false);
    }
    setTimeout(() => {
      this.setState({
        showPopOver: false,
        target: ''
      });
    }, 2000);
  }

  applyFilter(e) {
    let qs = queryString.parse(this.props.getSearchQuery());
    qs.budgets = this.state.selectedBudgets;
    window.location.href =
      window.location.pathname +
      (Object.values(qs).join('') ? '?' : '') +
      queryString.stringify(qs);
    this.setState({
      apDisabled: this.state.selectedBudgets === 0,
      setText: this.state.setDataText,
      showPopOver: false,
      target: ''
    });
    if (
      this.state.selectedBudgets.length === 6 ||
      this.state.selectedBudgets.length === 0
    ) {
      this.setState({ setText: 'All Budgets' });
    }
    let target = e.target.closest('.packages').querySelector('.filter-overlay');
    this.props.removeFilterOverlay(target, true);
  }

  resetFilter(e) {
    if (this.state.checkBox) {
      let lichecked = e.target.parentElement.previousSibling.querySelector(
        '.list-items'
      ).children;
      [].forEach.call(lichecked, function(el) {
        el.querySelector('input').checked = false;
      });
    }
    this.setState({
      reDisabled: true,
      apDisabled: false,
      setDataText: '',
      selectedBudgets: [],
      selecteddataText: []
    });
  }
  render() {
    let {
      expand,
      toggleFilterOpen,
      currentValue,
      history,
      getBudgetByUrl,
      removeFitlerOverlay,
      getSearchQuery,
      checkBoxremove,
      checkBoxValueRemoved,
      storeFilterValueforMobile
    } = this.props;
    let { expanded, selectedBudgets } = this.state;
    return (
      <DropDownMenu
        trigger={'click'}
        onClick={this.props.setAffixTop(this.props.expand)}
        expand={this.props.expand}
        isCampaignPage={true}
        history={this.props.history}
        currentValue={'BudgetFilter'}
        wrapperClassName={'dropdown'}
        toggleFilterOpen={this.props.toggleFilterOpen}
        ref={instance => {
          this.drowDownLoggedInMenu = instance;
        }}
        triggerElement={
          <a
            className="dropdown-toggle tracker-pkg-budget"
            data-toggle="dropdown"
            aria-expanded={expand}
          >
            Budget
            <span
              className={classNames({
                'dd-val':
                  (this.state.setText !== '' &&
                    this.state.setText !== 'All Budgets') ||
                  selectedBudgets.length === 6
              })}
            >
              {this.state.setText === ''
                ? 'All Budgets'
                : this.state.setText === 'All Budgets'
                  ? 'All Budgets'
                  : (this.state.setText || []).join(', ')}
            </span>
          </a>
        }
        wrapperElement={'div'}
      >
        <li className="tracker-pkg-budget-list">
          <ul className="list-unstyled mb-0 list-items">
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  checked={selectedBudgets.includes('0_50000')}
                  type="checkbox"
                  name="budget"
                  data-text="Below ₹50k"
                  defaultValue="0_50000"
                />
                <span>Below ₹50,000</span>
                <i />
              </label>
            </li>
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  checked={selectedBudgets.includes('50000_75000')}
                  type="checkbox"
                  name="budget"
                  data-text="₹50k - ₹75k"
                  defaultValue="50000_75000"
                />
                <span>₹50,000 - ₹75,000</span>
                <i />
              </label>
            </li>
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  checked={selectedBudgets.includes('75000_100000')}
                  type="checkbox"
                  name="budget"
                  data-text="₹75k - ₹1L"
                  defaultValue="75000_100000"
                />
                <span>₹75,000 - ₹1,00,000</span>
                <i />
              </label>
            </li>
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  checked={selectedBudgets.includes('100000_150000')}
                  type="checkbox"
                  name="budget"
                  data-text="₹1L - ₹1.5L"
                  defaultValue="100000_150000"
                />
                <span>₹1,00,000 - ₹1,50,000</span>
                <i />
              </label>
            </li>
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  checked={selectedBudgets.includes('150000_200000')}
                  type="checkbox"
                  name="budget"
                  data-text="₹1.5L - ₹2L"
                  defaultValue="150000_200000"
                />
                <span>₹1,50,000 - ₹2,00,000</span>
                <i />
              </label>
            </li>
            <li>
              <label
                className="custom-options"
                onClick={e => this.stateClickable(e)}
              >
                <input
                  checked={selectedBudgets.includes('200000_9999999')}
                  type="checkbox"
                  name="budget"
                  data-text="Above ₹2L"
                  defaultValue="200000_9999999"
                />
                <span>Above ₹2,00,000</span>
                <i />
              </label>
            </li>
          </ul>
        </li>

        <ResetCheckApplyButton
          reDisabled={this && this.state.reDisabled}
          apDisabled={this && this.state.apDisabled}
          resetFilter={this && this.resetFilter}
          applyFilter={this && this.applyFilter}
          showPopOver={this && this.state.showPopOver}
          targetPopOver={this && this.state.target}
        />
      </DropDownMenu>
    );
  }
}

function RadioResetApplyButton({
  disabled,
  resetFilter,
  applyFilter,
  showPopOver,
  targetPopOver
}) {
  return (
    <li className="clearfix fw actions">
      <button
        type="button"
        disabled={disabled}
        className={classNames('btn btn-link-grey pull-left tracker-pkg-reset', {
          disabled: disabled
        })}
        onClick={e => resetFilter(e)}
      >
        Reset
      </button>
      <button
        type="button"
        disabled={disabled}
        className={classNames('btn btn-link pull-right tracker-pkg-apply', {
          disabled: disabled
        })}
        onClick={e => applyFilter(e)}
      >
        Apply
      </button>
      {!isFaqMobile() && (
        <Overlay
          show={showPopOver}
          target={targetPopOver}
          placement="bottom"
          container={this}
        >
          <Popover id="popover-contained popover-content fine-text color-grey bold">
            <span className="fine-text color-grey bold">
              Please click on Apply button
            </span>
          </Popover>
        </Overlay>
      )}
    </li>
  );
}

function ResetCheckApplyButton({
  reDisabled,
  apDisabled,
  resetFilter,
  applyFilter,
  showPopOver,
  targetPopOver
}) {
  return (
    <li className="clearfix fw actions">
      <button
        type="button"
        disabled={reDisabled}
        className={classNames('btn btn-link-grey pull-left', {
          disabled: reDisabled
        })}
        onClick={e => resetFilter(e)}
      >
        Reset
      </button>
      <button
        type="button"
        disabled={apDisabled}
        className={classNames('btn btn-link pull-right', {
          disabled: apDisabled
        })}
        onClick={e => applyFilter(e)}
      >
        Apply
      </button>
      {!isFaqMobile() && (
        <Overlay
          show={showPopOver}
          target={targetPopOver}
          placement="bottom"
          container={this}
          containerPadding={20}
        >
          <Popover id="popover-contained">
            <span className="fine-text color-grey bold">
              Please click Apply button to filter
            </span>
          </Popover>
        </Overlay>
      )}
    </li>
  );
}
