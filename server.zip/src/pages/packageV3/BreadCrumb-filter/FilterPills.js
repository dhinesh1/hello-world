import React, { Component } from 'react';
import _ from 'lodash';
import { Link } from 'react-router-dom';

export default class PackagesFilterPills extends Component {
  constructor(props) {
    super(props);
    this.state = {};

    this.resetFilter = this.resetFilter.bind(this);
  }

  resetFilter(e) {
    e && e.preventDefault();
    const {campaignDetails} = this.props;

    /**
     * Resetting to the actual path for dynamic URLs - otherwise it will redirect to packages page
     * Identifying the dynamic page vs actual page using the filter settings // noRegionThemeFilter
     */
    if(campaignDetails && campaignDetails.noRegionThemeFilter){
      window.location.href = window.location.pathname;
    }else {
      window.location.href = '/packages';
    }
  }

  render() {
    let {
      region,
      history,
      getThemeByUrl,
      selectedDurations,
      selectedBudgets,
      selectedStarRatings,
      selectedDepcity,
      removeRegion,
      removeTheme,
      removeDuration,
      removeBudget,
      removeDepcity,
      removeHotelStarRating,
      campaignDetails
    } = this.props;
    let selectedDurationsArray = _.isArray(selectedDurations)
      ? selectedDurations
      : [selectedDurations];
    let selectedBudgetsArray = _.isArray(selectedBudgets)
      ? selectedBudgets
      : [selectedBudgets];
    let selectedStarRatingsArray = _.isArray(selectedStarRatings)
      ? selectedStarRatings
      : [selectedStarRatings];

    let theme = getThemeByUrl();
    {
      /* hiding destination and theme filter pills based on noRegionThemeFilter value from API. 
    For duration, budgets and ratings we are showing the filter by default.*/
    }
    if (
      ((!campaignDetails.noRegionThemeFilter && (region || theme)) ||
        selectedDurations ||
        selectedBudgets ||
        selectedStarRatings ||
        selectedDepcity) &&
      region !== 'get-cost'
    ) {
      return (
        <section className="filter-pills hidden-xs hidden-sm">
          <div className="container sm-full-width lg-container">
            <div className="row">
              <ul className="col-md-12 list-unstyled">
                {/* condition used here is for when we filter only budget, duration or rating it should not show
                  destination or theme filter.*/}
                {!campaignDetails.noRegionThemeFilter &&
                region &&
                region !== 'all' ? (
                  <li>
                    {_.startCase(_.replace(region, '-', ' '))}
                    <i
                      className="vehoicon-close"
                      onClick={() => removeRegion(region, history)}
                    />
                  </li>
                ) : null}
                {!campaignDetails.noRegionThemeFilter &&
                theme &&
                theme !== 'packages' ? (
                  <li>
                    {_.startCase(_.replace(theme, '-packages', ''))}
                    <i
                      className="vehoicon-close"
                      onClick={() => removeTheme(theme, history)}
                    />
                  </li>
                ) : null}
                {selectedDurations && selectedDurationsArray.length > 0
                  ? renderDurationPills(selectedDurationsArray, removeDuration)
                  : null}
                {selectedBudgets && selectedBudgetsArray.length > 0
                  ? renderBudgetPills(selectedBudgetsArray, removeBudget)
                  : null}
                {selectedDepcity
                  ? renderDepcityPill(selectedDepcity, removeDepcity)
                  : null}
                {selectedStarRatings && selectedStarRatingsArray.length > 0
                  ? renderHotelStarRatingPills(
                      selectedStarRatingsArray,
                      removeHotelStarRating
                    )
                  : null}
                <li>
                  <a
                    href="/packages"
                    className="caps-text-small"
                    target={'_self'}
                    onClick={this.resetFilter}
                  >
                    CLEAR ALL
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </section>
      );
    } else {
      return null;
    }
  }
}

function renderDurationPills(duration, removeDuration) {
  let textMap = {
    '4_8': '4-8 days',
    '9_12': '9-12 days',
    '13_16': '13-16 days',
    '16_99': '16 days and above'
  };
  return duration.map(d => {
    return (
      <li>
        {textMap[d]}
        <i
          className="vehoicon-close uncheck-active-filter"
          onClick={() => removeDuration(d)}
        />
      </li>
    );
  });
}

function renderBudgetPills(budgets, removeBudget) {
  let textMap = {
    '0_50000': 'Below ₹50,000',
    '50000_75000': '₹50,000 - ₹75,000',
    '75000_100000': '₹70,000 - ₹1,00,000',
    '100000_150000': '₹10,0000 - ₹1,50,000',
    '150000_200000': '₹1,50,000 - ₹2,00,000',
    '200000_9999999': 'Above ₹2,00,000'
  };
  return budgets.map(b => {
    return (
      <li>
        {textMap[b]}
        <i
          onClick={() => removeBudget(b)}
          className="vehoicon-close uncheck-active-filter"
        />
      </li>
    );
  });
}

function renderDepcityPill(depcity, removeDepcity) {
  let textMap = {
    DEL: 'Delhi',
    BOM: 'Mumbai',
    MAA: 'Chennai',
    CCU: 'Kolkata',
    BLR: 'Bengalore',
    HYD: 'Hyderabad',
    COK: 'Kochi',
    TRZ: 'Trichy',
    NAG: 'Nagpur',
    $$$: 'Outside India'
  };
  return (
    <li>
      {textMap[depcity]}
      <i
        className="vehoicon-close uncheck-active-filter"
        onClick={removeDepcity}
      />
    </li>
  );
}

function renderHotelStarRatingPills(hotelStarRatings, removeHotelStarRating) {
  let textMap = {
    '3_3': '3 Star',
    '4_4': '4 Star',
    '5_5': '5 Star'
  };
  return hotelStarRatings.map(r => {
    return (
      <li>
        {textMap[r]}
        <i
          className="vehoicon-close uncheck-active-filter"
          onClick={() => removeHotelStarRating(r)}
        />
      </li>
    );
  });
}
