import React, { Component } from 'react';
import classNames from 'classnames';
import FeaturedBanner from './banner/FeaturedBanner';
import PackagesContent from './PackagesContent/PackagesContent';
import {
  PackagesTrustBlock,
  PackagesFAQBlock
} from '../../common_components/packages/PackagesComponents';
import Itinerary from '../itinerary/Itinerary';

import _ from 'lodash';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {
  getPackages,
  itineraryAssignUser,
  changeDeviceType,
  resetItineraryDetails,
  getUserDetails
} from '../../actions/actions_app';
import queryString from 'query-string';
import { Helmet } from 'react-helmet';
import {
  hideChatHead,
  hideChatDesktop,
  onceModalClosed,
  getQueryStringValue
} from '../../helpers/utilsHelper';
import { isFaqMobile } from '../../helpers/utilsHelper';
import { Route, Switch } from 'react-router-dom';
import {
  GetCostModalLoadable,
  RequestCallbackModalLoadable,
  CostingDelayScreenLoadable
} from '../../helpers/loadbleComponentsHelper';
import Login from '../Login';
import Page404 from '../Page404';

import PackagesBreadcrumbSection from './BreadCrumb-filter/BreadCrumb';
import PackagesFilterBar from './BreadCrumb-filter/FilterBar';
import PackagesFilterPills from './BreadCrumb-filter/FilterPills';
import CampaignLogo from '../PVCommonComponents/CampaignLogo';
import CampaignCopyRightFooter from '../PVCommonComponents/CampaignCopyrightFooter';
import TrustSticky from './trustSticky/TrustSticky';
import CBRFooter from './trustSticky/CBRFooter';

class PackagesV3 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showFilterOverlay: false,
      clicked: false,
      mobileFilterClass: '',
      trustModuleClass: false,
      mobileFilterOpen: false,
      activeRegion: 'hello',
      removedBudgetState: '',
      removedDurationState: '',
      removedStarState: '',
      requestObj: {
        key: '',
        durations: [],
        hotelRatings: [],
        budgets: [],
        testimonials: 10,
        limit: 50,
        journalTestimonials: false
      },
      otherFilters: {
        durations: [],
        budgets: [],
        departure: '$$$',
        hotel_ratings: []
      }
    };
    this.openMobileFilterStatus = this.openMobileFilterStatus.bind(this);
    this.toggleTrustModuleStatus = this.toggleTrustModuleStatus.bind(this);
    this.getThemeByUrl = this.getThemeByUrl.bind(this);
    this.getDestinationByUrl = this.getDestinationByUrl.bind(this);
    this.getDurationByUrl = this.getDurationByUrl.bind(this);
    this.getDurationByUrl = this.getDurationByUrl.bind(this);
    this.getBudgetByUrl = this.getBudgetByUrl.bind(this);
    this.getStarRatingByUrl = this.getStarRatingByUrl.bind(this);
    this.getDepcityByUrl = this.getDepcityByUrl.bind(this);
    this.getSearchQuery = this.getSearchQuery.bind(this);
    this.closeMobileFilterStatus = this.closeMobileFilterStatus.bind(this);
    this.openCBR = this.openCBR.bind(this);

    this.removeFitlerOverlay = this.removeFitlerOverlay.bind(this);
    this.filterBarClickable = this.filterBarClickable.bind(this);

    this.removeRegion = this.removeRegion.bind(this);
    this.removeBudget = this.removeBudget.bind(this);
    this.removeDepcity = this.removeDepcity.bind(this);
    this.removeDuration = this.removeDuration.bind(this);
    this.removeHotelStarRating = this.removeHotelStarRating.bind(this);
    this.checkBoxValueRemoved = this.checkBoxValueRemoved.bind(this);
    PackagesV3.setArrayforFilter = PackagesV3.setArrayforFilter.bind(this);
  }

  componentDidMount() {
    let t = { ...this.state };
    let props = this.props;

    window.addEventListener('mouseout', this.handleoverOutside);

    hideChatHead();
    hideChatDesktop();

    GetCostModalLoadable.preload();

    // The following details are picked up from get<Value>ByUrl not from state as the page reloads for every filter click
    t.otherFilters.durations = this.getDurationByUrl();
    t.otherFilters.theme = this.getThemeByUrl();
    t.otherFilters.budgets = this.getBudgetByUrl();
    t.otherFilters.departure = this.getDepcityByUrl();
    t.otherFilters.hotel_ratings = this.getStarRatingByUrl();

    // this.setState(t, () => {
    //   // Commented out as this will break the SSR pages. - Josan - enable it only when test in local
    //   let key = '';
    //   if(this.props.match.url.charAt(0) === '/'){
    //     key = this.props.match.url.substr(1);
    //   }
    //   key =key.replace('/get-cost','').replace('/request-callback','');
    //   t.requestObj.key = key.toLowerCase();
    //   t.requestObj.durations= PackagesV3.setArrayforFilter(this.state.otherFilters.durations);
    //   t.requestObj.hotelRatings= PackagesV3.setArrayforFilter(this.state.otherFilters.hotel_ratings);
    //   t.requestObj.budgets = PackagesV3.setArrayforFilter(this.state.otherFilters.budgets);
    //   if (!this.props.packages && !this.props.itineraryInfo) {
    //     this.props.actions.getPackages(this.state.requestObj);
    //   }
    // });

    if (
      props.packages &&
      props.packages.campaignDetails &&
      props.packages.campaignDetails.paid
    ) {
      if (props && props.location && props.location.search) {
        let campaignId = unescape(
          getQueryStringValue(this.props.location.search, 'cpid')
        )
          .replace('+', ' ')
          .trim();
        if (campaignId.length) {
          sessionStorage.setItem('campaignId', campaignId);
        }

        let source = unescape(
          getQueryStringValue(this.props.location.search, 'source')
        )
          .replace('+', ' ')
          .trim();

        let campaignKeyword = unescape(
          getQueryStringValue(this.props.location.search, 'keyword')
        )
          .replace('+', ' ')
          .trim();

        let campaign = unescape(
          getQueryStringValue(this.props.location.search, 'campaign')
        )
          .replace('+', ' ')
          .trim();

        let feedItemId = unescape(
          getQueryStringValue(this.props.location.search, 'feedItemId')
        )
          .replace('+', ' ')
          .trim();

        let targetId = unescape(
          getQueryStringValue(this.props.location.search, 'targetId')
        )
          .replace('+', ' ')
          .trim();

        let creative = unescape(
          getQueryStringValue(this.props.location.search, 'creative')
        )
          .replace('+', ' ')
          .trim();

        let adPosition = unescape(
          getQueryStringValue(this.props.location.search, 'adPosition')
        )
          .replace('+', ' ')
          .trim();

        let leadSourceData = JSON.parse(localStorage.getItem('leadSource'));
        leadSourceData.searchKeyWords = campaignKeyword;
        leadSourceData.source = source;
        leadSourceData.type = 'Paid';
        leadSourceData.campaign = campaign;
        leadSourceData.feedItemId = feedItemId;
        leadSourceData.targetId = targetId;
        leadSourceData.creative = creative;
        leadSourceData.adPosition = adPosition;
        localStorage.setItem('leadSource', JSON.stringify(leadSourceData));
      }

      // Trigger user details if its not there - it will run for the pages which doesn't have the header
      if (this.props.user_details == null) {
        this.props.actions.getUserDetails();
      }
    }

    if (props.packages && !props.itineraryInfo) {
      props.actions.resetItineraryDetails();
    }
  }

  componentDidUpdate() {
    // check for modal-backdrop
    if (
      this.props.match &&
      this.props.location.pathname === this.props.match.url &&
      this.props.location.pathname.indexOf('request-callback') === -1 &&
      this.props.location.pathname.indexOf('get-cost') === -1
    ) {
      console.log('cleaning opened modal back drop - did mount');
      onceModalClosed();
    }
  }

  componentWillUnmount() {
    window.removeEventListener('mouseout', this.handleoverOutside);
  }

  getCanonicalThemeUrl(theme) {
    switch (theme) {
      case 'adventure':
      case 'art_culture':
        return (
          <link
            rel="canonical"
            href="https://pickyourtrail.com/guides/australia"
          />
        );
      case 'family':
        return (
          <link
            rel="canonical"
            href="https://pickyourtrail.com/family-packages/australia"
          />
        );
      case 'honeymoon':
        return (
          <link
            rel="canonical"
            href="https://pickyourtrail.com/honeymoon-packages/australia"
          />
        );
      default:
        return (
          <link
            rel="canonical"
            href="https://pickyourtrail.com/guides/australia"
          />
        );
    }
  }

  removeFitlerOverlay(e, removeoverlay) {
    if (
      (removeoverlay && e.classList.contains('show')) ||
      e.target.classList.contains('show')
    ) {
      this.setState({ showFilterOverlay: false, clicked: false });
      this.refs.fitlerbar.closeAllFilters(e);
    }
  }

  checkBoxValueRemoved(value) {
    if (value !== '') {
      this.setState({
        removedDurationState: '',
        removedStarState: '',
        removedBudgetState: ''
      });
    }
  }

  filterBarClickable(e) {
    if (
      e.target.closest('.dropdown').classList.contains('open') &&
      document.querySelectorAll('.dropdown.open').length == 1
    ) {
      this.setState({ showFilterOverlay: false, clicked: false });
    } else {
      this.setState({ showFilterOverlay: true, clicked: true });
    }
  }
  static setArrayforFilter(obj) {
    if (obj) {
      if (typeof obj === 'string') {
        return [obj];
      } else {
        return obj;
      }
    }
  }

  handleoverOutside = event => {
    let value = this.props;
    event = event ? event : window.event;
    let CBRrequest = JSON.parse(sessionStorage.getItem('CBRrequest'));
    var from = event.relatedTarget || event.toElement;
    let storage = JSON.parse(sessionStorage.getItem('CBRExitpopup'));
    if (
      (!from || from.nodeName == 'HTML') &&
      event.clientY <= 0 &&
      !CBRrequest &&
      value.history.location.pathname.indexOf('request-callback') === -1 &&
      value.history.location.pathname.indexOf('get-cost') === -1 &&
      storage
    ) {
      value.history.push(
        `${value.history.location.pathname}/request-callback` +
          `${
            value.history.location.search
              ? value.history.location.search + ''
              : '?'
          }` +
          `&autocbr`
      );
      sessionStorage.setItem('CBRExitpopup', false);
    }
  };

  getSearchQuery(np = this.props) {
    return np.location.search;
  }

  removeRegion(region, history) {
    let theme = this.getThemeByUrl();
    let pathname = theme.length ? `/${theme}-packages` : '/packages';
    let queryString = history.location.search;

    window.location.href = pathname + queryString;
  }

  removeTheme(theme, history) {
    let pathname = window.location.pathname;
    pathname = _.replace(pathname, `${theme}-packages`, 'packages');
    let queryString = history.location.search;

    // this.props.history.push(pathname + queryString);
    window.location.href = pathname + queryString;
  }

  removeDuration(duration) {
    let pathname = window.location.pathname;
    let queryStr = this.getSearchQuery();
    let qs = queryString.parse(queryStr);
    qs.durations = _.isArray(qs.durations)
      ? _.pull(qs.durations, duration)
      : null;
    if (!qs.durations) {
      delete qs.durations;
    }
    queryStr = queryString.stringify(qs);

    window.location.href = pathname + (queryStr ? '?' : '') + queryStr;
    //   this.props.history.push(pathname + '?' + queryStr);
    this.setState({ removedDurationState: duration });
  }

  removeBudget(budget) {
    let pathname = window.location.pathname;
    let queryStr = this.getSearchQuery();
    let qs = queryString.parse(queryStr);
    qs.budgets = _.isArray(qs.budgets) ? _.pull(qs.budgets, budget) : null;
    if (!qs.budgets) {
      delete qs.budgets;
    }
    queryStr = queryString.stringify(qs);
    window.location.href = pathname + (queryStr ? '?' : '') + queryStr;
    //this.props.history.push(pathname + '?' + queryStr);
    this.setState({ removedBudgetState: budget });
  }

  removeDepcity(depcity) {
    let pathname = window.location.pathname;
    let queryStr = this.getSearchQuery();
    let qs = queryString.parse(queryStr);
    delete qs.depcity;
    queryStr = queryString.stringify(qs);
    this.props.history.push(pathname + '?' + queryStr);
  }

  removeHotelStarRating(hotelStarRating) {
    let pathname = window.location.pathname;
    let queryStr = this.getSearchQuery();
    let qs = queryString.parse(queryStr);
    qs.hotel_ratings = _.isArray(qs.hotel_ratings)
      ? _.pull(qs.hotel_ratings, hotelStarRating)
      : null;
    if (!qs.hotel_ratings) {
      delete qs.hotel_ratings;
    }
    queryStr = queryString.stringify(qs);
    window.location.href = pathname + (queryStr ? '?' : '') + queryStr;
    // this.props.history.push(pathname + '?' + queryStr);
    this.setState({ removedStarState: hotelStarRating });
  }

  getThemeByUrl(np = this.props) {
    let { match } = np;

    // Current Available themes for package page
    let themeValue = [
      'honeymoon',
      'family',
      'beach',
      'adventure',
      'visa-on-arrival'
    ];

    /**
     * Getting the theme value from the given URL as we are using Dynamic Routing
     * Here we have splited and retireved the theme value alone
     * 1) Retrieved the whole URL, splitted and retrieved the 0th value i.e. (honeymoon-packages)
     * 2) Again splitted and retrieved the theme value i.e(honeymoon)
     */
    let theme = match.params[0] && match.params[0].split('/')[0].split('-')[0];

    /**
     * Getting the theme value form the given URL.
     * for visa-on-arrival while splitting with '-' we get visa. so based on that provided the text manually
     */
    theme = theme === 'visa' ? 'visa-on-arrival' : theme;

    /**
     * setting empty value if there is no theme value.
     */
    if (!themeValue.includes(theme)) {
      theme = '';
    }

    return theme;
  }

  getDestinationByUrl(np = this.props) {
    // let url = new URL(window.location.href);
    let path = _.trim(np.location.pathname, '/');
    return _.split(path, '/')[1];
  }

  getDurationByUrl(np = this.props) {
    let qs = this.getSearchQuery(np);
    let parsed = queryString.parse(qs);

    if (parsed.durations) {
      return parsed.durations;
    } else {
      return null;
    }
  }

  getBudgetByUrl(np = this.props) {
    let qs = this.getSearchQuery(np);
    let parsed = queryString.parse(qs);

    if (parsed.budgets) {
      return parsed.budgets;
    } else {
      return null;
    }
  }

  getStarRatingByUrl(np = this.props) {
    let qs = this.getSearchQuery(np);
    let parsed = queryString.parse(qs);

    if (parsed.hotel_ratings) {
      return parsed.hotel_ratings;
    } else {
      return null;
    }
  }

  getDepcityByUrl(np = this.props) {
    let qs = this.getSearchQuery(np);
    let parsed = queryString.parse(qs);

    if (parsed.depcity) {
      return parsed.depcity;
    } else {
      return null;
    }
  }

  openMobileFilterStatus(e) {
    let t = this.state;
    t.mobileFilterClass = 'xs-slide-up';
    this.setState(t);
  }

  toggleTrustModuleStatus(e) {
    e.preventDefault();
    e.stopPropagation();
    let t = this.state;
    t.trustModuleClass = !t.trustModuleClass;
    this.setState(t);
  }

  closeMobileFilterStatus(e) {
    e.preventDefault();
    e.stopPropagation();
    this.setState({ mobileFilterClass: '' });
  }

  openCBR(e) {
    e.preventDefault();
    e.stopPropagation();

    let { history } = this.props;
    history.push(
      history.location.pathname +
        '/request-callback' +
        (history.location.search ? history.location.search : '')
    );
  }

  render() {
    let { packages, match, hasError, itineraryInfo } = this.props;
    let {
      requestObj,
      otherFilters,
      showFilterOverlay,
      removedDurationState,
      removedStarState,
      removedBudgetState
    } = this.state;
    let theme = this.getThemeByUrl();

    if (hasError || (!itineraryInfo && !packages)) {
      return <Page404 />;
    } else if (itineraryInfo && !packages) {
      return (
        <div>
          <Itinerary isFromPackages={true} />

          {/* Routes */}
          <PackagesRoutes match={match} />
        </div>
      );
    } else {
      let isPaid =
        packages && packages.campaignDetails && packages.campaignDetails.paid;

      return (
        <div
          className={classNames('packages bg-grey-lighter', {
            'campaign-page': isPaid
          })}
        >
          {isPaid ? (
            <Helmet>
              {theme ? (
                this.getCanonicalThemeUrl(theme)
              ) : (
                <link
                  rel="canonical"
                  href="https://pickyourtrail.com/packages/australia"
                />
              )}
              <title>
                Customized Holiday Packages, Honeymoon & Vacation Packages
              </title>
            </Helmet>
          ) : (
            <Helmet>
              <title>
                {packages &&
                packages.campaignDetails &&
                packages.campaignDetails.seoDetails
                  ? packages.campaignDetails.seoDetails.metaTitle
                  : 'pickyourtrail.com'}
              </title>
              <meta
                name="description"
                content={
                  packages &&
                  packages.campaignDetails &&
                  packages.campaignDetails.seoDetails
                    ? packages.campaignDetails.seoDetails.metaDescription
                    : 'Pickyourtrail is the right platform to plan your vacation'
                }
              />
            </Helmet>
          )}

          {/* Banner starts */}
          {packages ? (
            <FeaturedBanner
              mobile={isFaqMobile()}
              {...packages}
              location={this.props.location}
            />
          ) : null}
          {/* Banner Ends */}

          {packages && isPaid ? (
            <CampaignLogo
              logoUrl={packages.campaignDetails.logoUrl}
              regionName={packages.campaignDetails.regionName}
            />
          ) : null}

          {/* BreadCrumb starts */}
          {packages && !isPaid
            ? [
                <PackagesBreadcrumbSection
                  region={packages.campaignDetails.region}
                  getThemeByUrl={this.getThemeByUrl}
                  packages={packages}
                />,
                <PackagesFilterBar
                  packages={packages}
                  ref="fitlerbar"
                  match={this.props.match}
                  history={this.props.history}
                  checkBoxDremove={removedDurationState}
                  checkBoxSremove={removedStarState}
                  checkBoxBremove={removedBudgetState}
                  checkBoxValueRemoved={this.checkBoxValueRemoved}
                  removeFitlerOverlay={this.removeFitlerOverlay}
                  needMobileFilter={this.state.mobileFilterClass}
                  filterClicked={this.state.clicked}
                  filterBarClickable={this.filterBarClickable}
                  selectedTheme={otherFilters.theme}
                  getThemeByUrl={this.getThemeByUrl}
                  getDestinationByUrl={this.getDestinationByUrl}
                  getDurationByUrl={this.getDurationByUrl}
                  getBudgetByUrl={this.getBudgetByUrl}
                  getStarRatingByUrl={this.getStarRatingByUrl}
                  getDepcityByUrl={this.getDepcityByUrl}
                  closeMobileFilterStatus={this.closeMobileFilterStatus}
                  setActiveRegion={this.setActiveRegion}
                  getSearchQuery={this.getSearchQuery}
                  campaignDetails={packages.campaignDetails}
                />,
                <PackagesFilterPills
                  history={this.props.history}
                  removeRegion={this.removeRegion}
                  removeTheme={this.removeTheme}
                  removeDuration={this.removeDuration}
                  removeBudget={this.removeBudget}
                  removeDepcity={this.removeDepcity}
                  removeHotelStarRating={this.removeHotelStarRating}
                  region={packages.campaignDetails.region}
                  theme={otherFilters.theme}
                  getThemeByUrl={this.getThemeByUrl}
                  selectedDurations={otherFilters.durations}
                  selectedBudgets={otherFilters.budgets}
                  selectedStarRatings={otherFilters.hotel_ratings}
                  campaignDetails={packages.campaignDetails}
                />
              ]
            : null}
          {/* TBreadCrumb starts Ends */}

          {/* Packages content starts */}
          {packages ? (
            <div className="container sm-full-width lg-container">
              {isPaid ? null : (
                <div className="row">
                  <div className="col-md-12">
                    <h1 className="fine-text color-grey">
                      {packages && packages.campaignDetails.seoDetails
                        ? packages.campaignDetails.seoDetails.h1TitleDisplay
                        : null}
                    </h1>
                  </div>
                </div>
              )}

              <div className="row" id="packagesContent">
                {packages ? (
                  <PackagesContent
                    getSearchQuery={this.getSearchQuery}
                    region={requestObj.region}
                    theme={requestObj.theme}
                    mobile={isFaqMobile()}
                    selectedDurations={otherFilters.durations}
                    selectedBudgets={otherFilters.budgets}
                    selectedStarRatings={otherFilters.hotel_ratings}
                    selectedDepcity={otherFilters.departure}
                    {...this.props}
                  />
                ) : null}
              </div>

              {/* FAQ starts */}
              {packages &&
              packages.campaignDetails &&
              packages.campaignDetails.faqDetails &&
              packages.campaignDetails.faqDetails.length ? (
                <div className="row">
                  <PackagesFAQBlock
                    history={this.props.history}
                    faqDetails={packages.campaignDetails.faqDetails}
                  />
                </div>
              ) : null}
              {/* FAQ Ends */}

              {packages.campaignDetails.seoDetails ? (
                <div className="row">
                  <div className={'col-md-12 col-xs-12'}>
                    <div
                      className={'clearfix fw seo-text'}
                      dangerouslySetInnerHTML={{
                        __html:
                          packages.campaignDetails.seoDetails &&
                          packages.campaignDetails.seoDetails.seoContent
                      }}
                    />
                  </div>
                </div>
              ) : null}
            </div>
          ) : null}
          {/* Packages content Ends */}

          {!packages ? (
            <div className="hero-banner vertical-center bg-grey-lighter">
              <div className="center-block text-center loading-bars">
                <span className="bar1" />
                <span className="bar2" />
                <span className="bar3" />
                <span className="bar4" />
              </div>
            </div>
          ) : null}

          {packages ? (
            <PackagesTrustBlock
              trustModuleClass={this.state.trustModuleClass}
              history={this.props.history}
              openCBR={this.openCBR}
              newpackages={packages}
              toggleTrustModuleStatus={this.toggleTrustModuleStatus}
              isPaid={isPaid}
            />
          ) : null}

          {packages && isPaid ? (
            <CampaignCopyRightFooter history={this.props.history} />
          ) : null}

          {packages && (isPaid || !isFaqMobile()) ? (
            <CBRFooter history={this.props.history} />
          ) : packages ? (
            <TrustSticky
              openMobileFilterStatus={this.openMobileFilterStatus}
              toggleTrustModuleStatus={this.toggleTrustModuleStatus}
              history={this.props.history}
              {...packages}
            />
          ) : null}

          <div
            className={classNames('filter-overlay', {
              show: showFilterOverlay
            })}
            //  onClick={e => this.removeFitlerOverlay(e)}
          />

          {/* Routes */}
          <PackagesRoutes match={match} />
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (!_.isEmpty(app.itineraryInfo)) {
    return {
      packages: state.packages.content,
      itineraryInfo: app.itineraryInfo,
      hasError: state.packages.hasError,
      error: state.packages.error
    };
  } else {
    return {
      packages: state.packages.content,
      hasError: state.packages.hasError,
      error: state.packages.error,
      user_details: state.app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getPackages: bindActionCreators(getPackages, dispatch),
      itineraryAssignUser: bindActionCreators(itineraryAssignUser, dispatch),
      changeDeviceType: bindActionCreators(changeDeviceType, dispatch),
      resetItineraryDetails: bindActionCreators(
        resetItineraryDetails,
        dispatch
      ),
      getUserDetails: bindActionCreators(getUserDetails, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(PackagesV3);

const PackagesRoutes = ({ match }) => (
  <Switch>
    <Route
      path={`${match.path}/request-callback`}
      exact={true}
      component={RequestCallbackModalLoadable}
    />

    <Route
      path={`${match.path}/get-cost/:itineraryId`}
      exact={true}
      component={GetCostModalLoadable}
    />

    <Route
      path={`${match.path}/get-cost/:itineraryId/login`}
      component={Login}
    />

    <Route
      path={`${match.path}/get-cost/:itineraryId/signup`}
      component={props => (
        <Login
          {...props}
          actionType="SIGNUP"
          headerText="Join the travel tribe!"
          subText="Save your itineraries and make unlimited edits. Create an account to get started right-away!"
        />
      )}
    />

    <Route
      path={`${match.path}/get-cost/:itineraryId/costing-delay`}
      component={CostingDelayScreenLoadable}
    />
  </Switch>
);
