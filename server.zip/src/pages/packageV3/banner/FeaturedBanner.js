import React from 'react';
import PropTypes from 'prop-types';
import {
  getImgIXUrl,
  getQueryStringValue,
  checkIndexOf
} from '../../../helpers/utilsHelper';

import { AppConfig } from '../../../app-config';
const ICON_CDN = AppConfig.images_cdn_icons_url;

/**
 * @return {null}
 */
export default function FeaturedBanner(packages) {
  let { campaignDetails, mobile, location } = packages;
  if (campaignDetails && campaignDetails.paid) {
    let { bannerText, image, mobileImage } = campaignDetails;
    if (checkIndexOf(location.pathname, ['undiscover/australia'])) {
      const bannerKey = unescape(getQueryStringValue(location.search, 'banner'))
        .replace('+', ' ')
        .trim();
      switch (bannerKey) {
        case 'greatbarrierreef':
          bannerText =
            'Get upclose to the great barrier reef like never before. Speak to our expert.';
          mobileImage = image =
            'https://pyt-images.imgix.net/images/campaign_paid/banner/aussie-bg-2.jpg';
          break;
        case 'kangarooisland':
          bannerText =
            'Discover the thrills of kangaroo island. Speak to our travel expert now.';
          mobileImage = image =
            'https://pyt-images.imgix.net/images/campaign_paid/banner/aussie-bg-1.jpg';
          break;
        case 'portlincoln':
          bannerText =
            'Want to cage dive with the sharks? Speak to our travel expert now.';
          mobileImage = image =
            'https://pyt-images.imgix.net/images/campaign_paid/banner/aussie-bg-3.jpg';
          break;
        case 'hotairballoon':
          bannerText =
            `Embark on a hot air balloon ride in Canberra. Speak to our travel expert now.`;
          mobileImage = image =
            'https://pyt-images.imgix.net/images/campaign_paid/banner/aussie-bg-4.jpg';
          break;
        case 'greatoceanroad':
          bannerText =
            `Get exposed to Australia's most brilliant coastal views. Speak to our expert.`;
          mobileImage = image =
            'https://pyt-images.imgix.net/images/campaign_paid/banner/aussie-bg-5.jpg';
          break;
      }
    }

    return (
      <section className="banner-row" id="banner">
        {!mobile ? (
          <div
            className="bg"
            style={{
              backgroundImage: `url(${image})`
            }}
          />
        ) : (
          <div
            className="bg"
            style={{
              backgroundImage: `url(${mobileImage})`
            }}
          />
        )}
        <div className="container sm-full-width lg-container">
          <div className="row">
            <div className="col-md-12 logo-img">
              <span>
                <img
                  src="https://pyt-images.imgix.net/images/campaign_landing/logo_hdr.png"
                  alt="PickYourTrail.com - Build, Customize and Book personalized vacations!"
                />
              </span>
            </div>
            {campaignDetails.key &&
            campaignDetails.key.indexOf('vacations/australia') >= 0 ? (
              <div className="col-md-12 hashtag">
                <p className="mb-0 color-white bold">
                  <span className="color-accent-2">Un</span>Discover Australia
                </p>
              </div>
            ) : null}

            <div className="col-xs-12 col-sm-12 col-md-5 col-md-push-7 col-lg-4 col-lg-push-8">
              <div className="boxed-meta">
                <p>{bannerText}</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } else if (campaignDetails) {
    return (
      <section className="banner-row" id="banner">
        {!mobile ? (
          <div
            className="bg"
            style={{
              backgroundImage: `url(${getImgIXUrl(campaignDetails.image)})`
            }}
          />
        ) : (
          <div
            className="bg"
            style={{
              backgroundImage: `url(${getImgIXUrl(
                campaignDetails.mobileImage
              )})`
            }}
          />
        )}
        <div className="container sm-full-width lg-container">
          <div className="row">
            <div className="col-xs-12 col-sm-12 col-md-5 col-md-push-7 col-lg-4 col-lg-push-8">
              <div className="boxed-meta">
                <p>{campaignDetails.bannerText}</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } else return null;
}

FeaturedBanner.propTypes = {
  packages: PropTypes.object
};
