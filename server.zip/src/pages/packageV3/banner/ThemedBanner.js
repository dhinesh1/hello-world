import React, { Component } from 'react';
import classNames from 'classnames';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function ThemedBanner(packages) {
  let { campaignDetails, mobile, theme } = packages;
  if (campaignDetails && theme) {
    return (
      <section
        className={classNames('clearfix fade-slide-down themed-banner', {
          hide: false
        })}
        id="banner"
      >
        {/* mobile banner */}
        <div className="visible-xs">
          <img
            className="img-responsive"
            src={getImgIXUrl(campaignDetails.mobileImage)}
            alt="Banner"
          />
        </div>

        {/* Desktop banner */}
        <div className="hidden-xs">
          <img
            className="img-responsive"
            src={getImgIXUrl(campaignDetails.image)}
            alt="Banner"
          />
        </div>
      </section>
    );
  }
  return null;
}
