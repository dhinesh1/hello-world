import React from 'react';

const Investors = ({ title = 'Our Investors', data = [] }) => {
  if (!data.length) return null;

  return (
    <section className="investors">
      <div className="container">
        <h4 className="bold mbottom-medium">{title}</h4>
        <div className="row row-eq-hgt">
          {data.map((investor, i) => {
            const { name, image, link, role } = investor;
            return (
              <div key={i} className="col-xs-6 col-sm-3">
                <a className="investor-card" href={link} target="_blank">
                  <img src={image} alt={name} />
                  <p>{name}</p>
                  <span className="role">{role}</span>
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Investors;
