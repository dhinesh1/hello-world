import React, { Component, PureComponent, Fragment } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { AppConfig } from '../../../app-config';
import { getImgIXUrl } from '../../../helpers/utilsHelper';
import { trackPage, PAGE_ABOUT } from '../../../helpers/ML/EventsTracker';
const API_URL = AppConfig.api_url;

const JoinUsCard = () => (
  <div className="col-sm-3 col-md-2">
    <div className="joinus-card">
      <span>THIS COULD BE YOU!</span>
      <Link
        to="/careers"
        className="btn btn-primary btn-sm btn-outline btn-outline-bg"
      >
        Join Us
      </Link>
    </div>
  </div>
);

class TeamMemberCard extends PureComponent {
  // track page call on employee card click
  teamMemberClick = () => {
    trackPage(PAGE_ABOUT, {
      employee_name: this.props.name,
      employee_position: this.props.position,
      employee_pic: this.props.imageUrl
    });
  }

  render() {
    return (
      <div className="col-sm-3 col-md-2">
        <div className="team-member-card" onClick={this.teamMemberClick}>
          <figure
            style={{
              backgroundImage: `url('${getImgIXUrl(
                this.props.imageUrl,
                'isTeamSlide'
              )}')`
            }}
          />
          <p>
            <span>
              <b>{this.props.name}</b> / {this.props.superHeroName || ''}
            </span>
            {this.props.position || ''}
          </p>
        </div>
      </div>
    );
  }
}

class TeamSlider extends Component {
  // teamMembers detail will be updated using API call after mounting this component.
  state = {
    teamMembers: [],
    page: 0,
    isLast: false,
    renderSlider: false
  };

  _sliderContent = null;

  /**
   * Fetch team member data from BE api and store the data in state.teamMembers Array
   * This lifecycle method will be triggered once on DOM mounting
   */
  componentDidMount() {
    axios
      .get(`${API_URL}misc/aboutUs/teamInfo`)
      .then(({ data = {} }) => {
        if (data.status == 'SUCCESS' && data.data) {
          this.setState(
            {
              teamMembers: data.data.length ? data.data : []
            },
            this.renderTeamMembers
          );
        }
      })
      .catch(err => {
        // console.log('Unable to get /aboutUs/teamInfo', err);
      });
  }

  // recursive method to render team member details
  renderTeamMembers() {
    const { page = 0, teamMembers = [] } = this.state;
    const pageContent = teamMembers.slice(11 * page, 11 + 11 * page);
    // random position between 3 - 10 to place joinUs Card. The card will not come in first/last position
    let joinusPosition = Math.floor(Math.random() * 8) + 3;

    joinusPosition = (pageContent.length < 11) ? pageContent.length-1 : joinusPosition;
    this._sliderContent = pageContent.map((member, i) => {
      return (
        <Fragment key={member.id}>
          {i === joinusPosition ||
          (pageContent.length < 11 && i === pageContent.length - 1) ? (
            <JoinUsCard />
          ) : null}
          <TeamMemberCard {...member} />
        </Fragment>
      );
    });

    this.setState({
      renderSlider: true,
      isLast: (page + 1) * 11 >= teamMembers.length
    });
  }

  prevSlide = () => {
    if (!this.state.page) return;

    this.setState(state => {
      return {
        page: state.page - 1,
        renderSlider: false
      };
    }, this.renderTeamMembers);
  };

  nextSlide = () => {
    if (this.state.isLast) return;

    this.setState(state => {
      return {
        page: state.page + 1,
        renderSlider: false
      };
    }, this.renderTeamMembers);
  };

  render() {
    if (!this.state.teamMembers.length) return null;

    return (
      <section className="team hidden-xs">
        <div className="container">
          <div className="clearfix">
            <h4 className="bold pull-left">Meet the team</h4>
            <ul className="list-unstyled mb-0 pull-right">
              <li>
                <button
                  onClick={this.prevSlide}
                  type="button"
                  className={`btn btn-default btn-outline btn-outline-bg btn-sm ${
                    !this.state.page ? 'disabled' : ''
                  }`}
                >
                  <i className="vehoicon-arrow-left" />
                </button>
              </li>
              <li>
                <button
                  onClick={this.nextSlide}
                  type="button"
                  className={`btn btn-default btn-outline btn-outline-bg btn-sm ${
                    this.state.isLast ? 'disabled' : ''
                  }`}
                >
                  <i className="vehoicon-arrow-left rotate-180" />
                </button>
              </li>
            </ul>
          </div>

          <div className="row row-eq-hgt">{this._sliderContent}</div>
        </div>
      </section>
    );
  }
}

export default TeamSlider;
