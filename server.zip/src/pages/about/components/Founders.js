import React from 'react';

const Founders = () => {
  return (
    <section className="founders">
      <div className="container">
        <div className="row row-eq-hgt">
          <div className="col-xs-6 col-sm-6 col-md-7">
            <figure className="fw">
              <figcaption className="hidden-xs">
                <div>
                  <h1>
                    Hari Ganapathy /{' '}
                    <i className="color-grey-light">Morpheus</i>
                  </h1>
                  <p>
                    Co-Founder, Magic
                    <span>
                      <a
                        target="_blank"
                        href="https://in.linkedin.com/in/hariganapathy"
                      >
                        <i className="vehoicon-linkedin" />
                      </a>
                      <a
                        target="_blank"
                        href="https://www.facebook.com/hari.ganapathy"
                      >
                        <i className="vehoicon-facebook-square" />
                      </a>
                      <a target="_blank" href="https://twitter.com/haripyt">
                        <i className="vehoicon-twitter" />
                      </a>
                    </span>
                  </p>
                </div>
                <div>
                  <h1>
                    Srinath Shankar /{' '}
                    <i className="color-grey-light">Ironman</i>
                  </h1>
                  <p>
                    Co-Founder, Logic
                    <span>
                      <a
                        target="_blank"
                        href="https://www.linkedin.com/pub/srinath-shankarnarayanan/13/262/b45"
                      >
                        <i className="vehoicon-linkedin" />
                      </a>
                      <a
                        target="_blank"
                        href="https://www.facebook.com/srinath.shankar.92"
                      >
                        <i className="vehoicon-facebook-square" />
                      </a>
                      <a
                        target="_blank"
                        href="https://twitter.com/shankar_srinath"
                      >
                        <i className="vehoicon-twitter" />
                      </a>
                    </span>
                  </p>
                </div>
              </figcaption>
            </figure>
          </div>
          <div className="col-xs-6 col-sm-6 col-md-5 vertical-center quote-block">
            <p className="hidden-xs">
            Pickyourtrail was born out of our desire to spread the magic of travel through the logic of tech. When you use Pickyourtrail to create, customize and book trips, great care goes into replicating the adrenaline rush and sense of control of self-planning. At the same time, we also ensure that technology does all the heavy lifting - personalization, curation, booking, reminders, on trip recommendations, etc. All of this to give you that hassle-free trip that you worked so hard year long. Go ahead, unwrap the world.
            </p>
            <p className="visible-xs">Pickyourtrail was born out of our desire to spread the magic of travel through the logic of tech.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Founders;
