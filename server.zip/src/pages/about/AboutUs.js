import React, { Component } from "react";
import Helmet from "react-helmet";
import Founders from "./components/Founders";
import Investors from "./components/Investors";
import TeamSlider from "./components/TeamSlider";
import { Link } from 'react-router-dom';
import BannerSVG from "../../common_components/static/BannerSVG";
import LifeAt from "../../common_components/static/LifeAt";
import MileStoneModal from "../../common_components/static/MileStoneModal";
const mileStoneData = require("../../common_components/static/milestone_data.json") || {};
const investorsData = [
  {
    name: 'Girish Mathrubootham',
    image:
      'https://pyt-images.imgix.net/images/web_app/about/investors/girish-mathrubootham.jpg',
    link: 'https://in.linkedin.com/in/girish1',
    role: 'Founder, CEO Freshworks'
  },
  {
    name: 'Kumar Vembu',
    image:
      'https://pyt-images.imgix.net/images/web_app/about/investors/kumar-vembu.jpg',
    link: 'https://in.linkedin.com/in/kumar-vembu-a0a45710',
    role: 'Founder, CEO Go Frugal'
  },
  {
    name: 'Rajagopal Subramanian',
    image:
      'https://pyt-images.imgix.net/images/web_app/about/investors/rajagopal-subramanian.jpg',
    link: 'https://www.linkedin.com/in/rajagopal-s-5b8809/',
    role: 'CIO, Entrust Family Office'
  },
  {
    name: 'Shyam Sekhar',
    image:
      'https://pyt-images.imgix.net/images/web_app/about/investors/shyam-shekhar.jpg',
    link: 'https://in.linkedin.com/in/shyam-sekhar-8654364',
    role: 'Founder, CEO Ithought'
  }
];
class AboutUs extends Component {
  state = {
    isOpen: false,
    index: 0,
    showHiring: true
  }
  
  /**
   * This lifecycle method will be triggered once on DOM mounting
   */
  componentDidMount() {
    document
      .querySelectorAll(".milestone")
      .forEach(ele => ele.addEventListener("click", this.onClick));
  }

  /**
   * This lifecycle method will be triggered once on Component Unmounting
   */
  componentWillUnmount() {
    document
      .querySelectorAll(".milestone")
      .forEach(ele => ele.removeEventListener("click", this.onClick));
  }

  /**
   * This method will be triggered when clicking view our story button on mobile
   */
  openMobileModal = () => {
    this.setState({ isOpen: true, index: 0 });
  };

  /**
   * This method will be triggered when Join us button on mobile to navigate to careers.
   */
  navigateToCarrers = () => {
    this.props.history.push("/careers");
  }

  /**
   * Event triggered when closing the milestone modal
   */
  closeModal = event => {
    this.setState({ isOpen: false });
  };

  /**
   * Click event used when clicking the items in SVG
   * Using the common class called 'milestone' retrieved the element and used the unique class to get the clickable index
   * Example: milestone-01,etc..,
   */
  onClick = event => {
    if (event.target.closest(".milestone")) {
      let indexVal = parseInt(
        event.target
          .closest(".milestone")
          .firstChild.className.baseVal.split("-")[1]
      );
      this.setState({ isOpen: !this.state.isOpen, index: indexVal - 1 });
    }
  };

  render() {
    return (
      <section className="aboutus-page">
        <Helmet>
          <title>About the Team | Pickyourtrail</title>
          <meta
            name={"description"}
            content={
              "We want to make every vacation a memorable experience! Come, discover a new way of travel - The Pickyourtrail way!"
            }
          />
        </Helmet>

        <div className="hero-banner">
          <div className="container hidden-xs">
            <div className="row">
              <div className="col-xs-6">
                <ul className="clearfix list-unstyled tab-links">
                  <li className="active">
                    <Link to='/about-us'>About</Link>
                  </li>
                  <li>
                    <Link to="/careers">Careers</Link>
                    {
                      this.state.showHiring ? 
                        <div className="inline-tooltip">We are hiring!</div>
                        : null
                    }
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <BannerSVG />
        </div>

        <section className="hero-content">
          <div className="container">
            <div className="row">
              <div className="col-sm-6 col-md-7">
                <h1 className="bold">
                  Disrupting travel industry since 2013. Step by step.
                </h1>
              </div>
              <div className="col-sm-6 col-md-5">
                <div className="hero-mobile-buttons visible-xs">
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={this.openMobileModal}
                  >
                    View our story
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm btn-outline btn-outline-bg"
                    onClick={this.navigateToCarrers}
                  >
                    Join us
                  </button>
                  {
                    this.state.showHiring ? 
                      <div className="inline-tooltip">We are hiring!</div>
                      : null
                  }
                </div>
                <p>
                  We are a travel company that delivers tailor-made
                  international holidays. Our unique matching algorithm and
                  price comparison engine gives you the freedom to create your
                  own customized tour packages suited to your tastes at the best
                  online prices. Over the years, we've helped more than 10000+
                  travelers from across 14 countries. We also have the highest
                  5-star rating on Facebook, making us one of the top-ranked
                  trip planners in India. We are an Amadeus Next incubated
                  start-up and one of the top 6 finalists of the prestigious
                  APAC Travel Innovation Summit award.
                </p>
              </div>
            </div>
          </div>
        </section>

        <Founders />

        <Investors data={investorsData} />

        <TeamSlider />

        <LifeAt showHiring={this.state.showHiring} />

        {this.state.isOpen ? (
          <MileStoneModal
            isOpen={this.state.isOpen}
            index={this.state.index}
            dataSource={mileStoneData.data}
            closeModal={this.closeModal}
          />
        ) : null}
      </section>
    );
  }
}

export default AboutUs;