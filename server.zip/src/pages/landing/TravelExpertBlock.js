import React from 'react';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';
import { Link } from 'react-router-dom';
import { getImgIXUrl } from '../../helpers/utilsHelper';

export default function TravelExpertBlock() {
  return (
    <section className="travel-expert">
      <div className="container">
        <div className="row vertical-center">
          <div className="col-sm-6 text-left">
            <h2 className="subheading">
              Questions?
              <br />Our travel consultants are here to help.
            </h2>
            <p>Let's unwrap the world now!</p>
            <Link
              to={{
                pathname: `/request-callback`
              }}
              className="btn btn-primary btn-xl"
            >
              Talk to us!
            </Link>
          </div>
          <div className="col-sm-6">
            <LazyLoadComponent>
              <img
                src={getImgIXUrl(
                  'https://d3lf10b5gahyby.cloudfront.net/misc/landing_new/talktous-v2.png'
                )}
                alt="travel expert"
              />
            </LazyLoadComponent>
          </div>
        </div>
      </div>
    </section>
  );
}
