import React from 'react';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';

export default function TravelExpertBlock() {
  return (
    <section className="press">
      <div className="container">
        <div className="row">
          <div className="col-xs-12">
            <h5>
              <span>AS FEATURED ON</span>
            </h5>
            <LazyLoadComponent>
              <ul className="list-unstyled mb-0">
                <li>
                  <a
                    href="https://community.nasscom.in/communities/product-startups/how-pickyourtrail-uses-machine-learning-to-craft-international-vacations.html"
                    rel="nofollow"
                    target="_blank"
                  >
                    <span className="feautred-ico1" />
                  </a>
                </li>
                <li>
                  <a
                    href="https://bit.ly/1XtMQtf"
                    rel="nofollow"
                    target="_blank"
                  >
                    <span className="feautred-ico2" />
                  </a>
                </li>
                <li>
                  <a
                    href="https://bit.ly/2uk3oJT"
                    rel="nofollow"
                    target="_blank"
                  >
                    <span className="feautred-ico3" />
                  </a>
                </li>
                <li>
                  <a
                    href="http://bit.ly/2woPckl"
                    rel="nofollow"
                    target="_blank"
                  >
                    <span className="feautred-ico4" />
                  </a>
                </li>
                <li>
                  <a
                    href="https://bit.ly/2wpAXf5"
                    rel="nofollow"
                    target="_blank"
                  >
                    <span className="feautred-ico5" />
                  </a>
                </li>
              </ul>
            </LazyLoadComponent>
          </div>
        </div>
      </div>
    </section>
  );
}
