import React, { Component } from 'react';
import { Helmet } from 'react-helmet';

import HeroBannerMobile from './mobile_components/HeroBannerMobile';
import RecentlyBookedMobile from './mobile_components/RecentlyBookedMobile';
import PackageGridsMobile from './mobile_components/PackageGridsMobile';
import PartnersMobile from './mobile_components/PartnersMobile';
import TravelExpertMobile from './mobile_components/TravelExpertMobile';
import StickyFooterMobile from './mobile_components/StickyFooterMobile';
import SEOText from './SEOText';
import { openChatWidget } from '../../helpers/utilsHelper';
import { SearchModalLoadable } from '../../helpers/loadbleComponentsHelper';

export default class LandingMobile extends Component {
  componentDidMount() {
    SearchModalLoadable.preload();
  }

  render() {
    let {
      recently_booked,
      itineraryAssignUser,
      showMobileFloatCTA,
      seoMetaData,
      mobileBannerImage,
      mobileBannerTitle,
      SEOData
    } = this.props;
    return (
      <div className="clearfix home-mobile">
        {SEOData}

        <HeroBannerMobile
          bannerImage={mobileBannerImage}
          title={mobileBannerTitle}
        />
        <RecentlyBookedMobile
          itineraryAssignUser={itineraryAssignUser}
          rb={recently_booked}
          ready={!!recently_booked}
        />
        <PackageGridsMobile />
        <PartnersMobile />
        <TravelExpertMobile openChatWidget={openChatWidget} />
        <SEOText seoMetaData={seoMetaData} />
        <StickyFooterMobile
          openChatWidget={openChatWidget}
          showMobileFloatCTA={showMobileFloatCTA}
        />
      </div>
    );
  }
}
