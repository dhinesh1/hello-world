import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import classNames from 'classnames';
import { trackEvent, EVENT_PDG_DESTINATION_SELECTED } from '../../../../helpers/ML/EventsTracker';

class TopDestinations extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isKilled: false
    };

    this.onClickHandler = this.onClickHandler.bind(this);
  }

  onClickHandler(item) {
    const {
      region: destination,
      regionCode: destination_code,
      campaign: is_campain_destination
    } = item;
    const is_pdg_region = !item.offline && !item.campaign;
    trackEvent(EVENT_PDG_DESTINATION_SELECTED, {
      destination,
      destination_code,
      is_pdg_region,
      is_campain_destination,
      is_top_destination: true
    });

    if (!item.offline && !item.campaign) {
      this.props.handlePdgRegion(item);
    } else if (item.campaign) {
      if (
        item.regionCode === 'sez' ||
        item.regionCode === 'mle' ||
        item.regionCode === 'mus'
      ) {
        this.props.history.push(`/customize/${item.regionCode}`);
      } else {
        window.location.href = `/packages/${item.region.toLowerCase()}`;
      }
    } else {
      window.location.href = `/get-packing/${item.region}`;
    }
  }

  render() {
    let {
      activeTabIndex,
      activeList,
      active_search_result,
      tabLabels
    } = this.props;

    return (
      <section className="clearfix search-tabs search-options-wrapper">
        {/* <ul className="clearfix list-unstyled tab-links hidden-xs">
          {tabLabels.map((item, Inx) => (
            <li
              key={'tab_items_' + Inx}
              className={classNames(item.tracker, {
                active: activeTabIndex === Inx
              })}
              onClick={() => this.props.changeTab(Inx, item.list)}
            >
              {item.label}
            </li>
          ))}
        </ul> */}

        <p className={'medium-heading color-grey vmargin-small'}>
          Trending Destinations
        </p>

        <div className="clearfix">
          <ul className="clearfix list-unstyled mb-0 tab-list n-tracker-searchsingleitem">
            {this.props[activeList] &&
              this.props[activeList].map((item, inx) => (
                <SearchSingleItem
                  key={'search_item_' + activeList + '_' + inx}
                  isActive={item.id === active_search_result}
                  item={item}
                  onFocusSearchItem={this.props.onFocusSearchItem}
                  onClickHandler={this.onClickHandler}
                />
              ))}
          </ul>
        </div>
      </section>
    );
  }
}

function SearchSingleItem(props) {
  return (
    <li
      onMouseEnter={e => props.onFocusSearchItem(props.item, e)}
      onMouseLeave={e => props.onFocusSearchItem(null, e)}
      className={classNames({ active: props.isActive })}
    >
      <a
        key={'searchCloseBtn'}
        href={`/customize/${props.item.regionCode}`}
        onClick={e => {
          e.preventDefault();

          props.onClickHandler(props.item);
        }}
      >
        <span className="lft-txt">
          <h5>
            <b>{props.item.search}</b>
            {/*, {props.item.region}*/}
          </h5>
          {props.item.topCities ? (
            <p className="meta-text light">
              {props.item.topCities.join(', ')}{' '}
              {props.item.topCities.length > 3 ? ' and more...' : null}
            </p>
          ) : null}
        </span>
        <span className="rgt-txt">
          <p>{props.item.numOfBookings}</p>
          <span className="fine-text light">Bookings</span>
        </span>
      </a>
    </li>
  );
}

export default withRouter(TopDestinations);
