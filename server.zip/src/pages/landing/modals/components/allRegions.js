import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import classNames from 'classnames';
import { trackEvent, EVENT_PDG_DESTINATION_SELECTED } from '../../../../helpers/ML/EventsTracker';

class AllRegions extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isKilled: false
    };

    this.onClickHandler = this.onClickHandler.bind(this);
  }

  onClickHandler(item) {
    const {
      region: destination,
      regionCode: destination_code,
      campaign: is_campain_destination
    } = item;
    const search_text = document.getElementById('landing-search-input').value;
    const is_pdg_region = !item.offline && !item.campaign;
    trackEvent(EVENT_PDG_DESTINATION_SELECTED, {
      destination,
      destination_code,
      is_pdg_region,
      is_campain_destination,
      search_text
    })

    if (is_pdg_region) {
      this.props.handlePdgRegion(item);
    } else if (item.campaign) {
      if (
        item.regionCode === 'sez' ||
        item.regionCode === 'mle' ||
        item.regionCode === 'mus'
      ) {
        this.props.history.push(`/customize/${item.regionCode}`);
      } else {
        window.location.href = `/packages/${item.region.toLowerCase()}`;
      }
    } else {
      window.location.href = `/get-packing/${item.region}`;
    }
  }

  render() {
    return (
      <section className="clearfix search-suggestions search-options-wrapper">
        <ul className="mb-0 list-unstyled n-tracker-searchsingleitem">
          {this.props.regions.map((item, inx) => (
            <SearchSingleItem
              key={'all_regions_item_' + inx}
              item={item}
              isActive={item.id === this.props.active_search_result}
              onFocusSearchItem={this.props.onFocusSearchItem}
              onClickHandler={this.onClickHandler}
            />
          ))}
        </ul>
      </section>
    );
  }
}

function SearchSingleItem({
  item,
  isActive,
  onFocusSearchItem,
  onClickHandler
}) {
  return (
    <li
      onMouseEnter={e => onFocusSearchItem(item, e)}
      onMouseLeave={e => onFocusSearchItem(null, e)}
      className={classNames({ active: isActive })}
    >
      <a
        key={'searchCloseBtn'}
        href={`/customize/${item.regionCode}`}
        onClick={e => {
          e.preventDefault();

          onClickHandler(item);
        }}
      >
        <b>{item.search}</b>
      </a>
    </li>
  );
}

export default withRouter(AllRegions);
