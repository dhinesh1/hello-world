import React, { Component } from 'react';
import classNames from 'classnames';
import _ from 'lodash';
import { Link } from 'react-router-dom';
import { emailValidation } from '../../validations';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import {
  fetchSearchRegions,
  clearPDGSelections,
  submitDomesticSubscriber
} from '../../../actions/actions_app';
import {
  fixPDGHeader,
  isElementInViewport
} from '../../../helpers/utilsHelper';

import TopDestinations from './components/topDestinations';
import AllRegions from './components/allRegions';

class SearchModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isKilled: true,
      showModal: false,
      searchTerm: '',
      search_state: 0,
      visible_regions_set: [],
      activeTabIndex: 0,
      activeList: 'trending_regions',
      tabLabels: [
        {
          label: 'Trending',
          list: 'trending_regions',
          tracker: 'n-tracker-customize-trending'
        }
        // {
        //   label: 'For couples',
        //   list: 'couple_regions',
        //   tracker: 'n-tracker-customize-forcouples'
        // },
        // {
        //   label: 'Family',
        //   list: 'family_regions',
        //   tracker: 'n-tracker-customize-family'
        //   // },
        //   // {
        //   //   label: 'Europe',
        //   //   list: 'europe_regions',
        //   //   tracker: 'n-tracker-customize-europe'
        // }
      ],
      domesticSubscriber: {
        name: '',
        email: ''
      },
      domesticSubscriberError: {
        name: '',
        email: ''
      }
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.regionSearch = this.regionSearch.bind(this);
    this.clearSearchText = this.clearSearchText.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.handleSubscriberInput = this.handleSubscriberInput.bind(this);
    this.submitSubscriberForm = this.submitSubscriberForm.bind(this);
    this.validateSubscriberForm = this.validateSubscriberForm.bind(this);

    this.changeTab = this.changeTab.bind(this);
    this.handleKeyPress = this.handleKeyPress.bind(this);
    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.onFocusSearchItem = this.onFocusSearchItem.bind(this);
    this.scrollToViewport = this.scrollToViewport.bind(this);
    this.handlePdgRegion = this.handlePdgRegion.bind(this);
    this.setPageNavigation = this.setPageNavigation.bind(this);
  }

  componentWillUnmount() {
    document.body.className = document.body.className.replace(
      'scroll-locked',
      ''
    );

    document.removeEventListener('keyup', this.handleKeyUp);
    document
      .querySelector('.search-container')
      .removeEventListener('scroll', fixPDGHeader);
  }

  setPageNavigation(item) {
    if (
      item.regionCode === 'sez' ||
      item.regionCode === 'mle' ||
      item.regionCode === 'mus'
    ) {
      this.props.history.push(`/customize/${item.regionCode}`);
    } else {
      window.location.href = `/packages/${item.region.toLowerCase()}`;
    }
  }

  componentDidMount() {
    // Fetching Search API
    localStorage.setItem('selected_city', null);
    this.props.actions.fetchSearchRegions();
    this.handleSearchDebounced = _.debounce(() => {
      this.filterRegion(this.state.searchTerm);
    }, 10);

    // Open modal with animation
    this.openModal();

    document.addEventListener('keyup', this.handleKeyUp);
  }

  openModal() {
    this.setState({ isKilled: false }, () => {
      setTimeout(() => {
        this.setState({ showModal: true }, () => {
          let slClass = 'scroll-locked';
          if (document.body.className.indexOf(slClass) === -1)
            document.body.className += ' ' + slClass;
        });
      }, 10);

      let dW = window.innerWidth;
      if (dW > 767) {
        document
          .querySelector('.search-container')
          .addEventListener('scroll', fixPDGHeader);
      }
    });
  }

  closeModal() {
    this.setState({ showModal: false }, () => {
      document.body.className = document.body.className.replace(
        'scroll-locked',
        ''
      );
    });
    this.props.history.push('/');
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  handleSubscriberInput(e) {
    let t = this.state;
    t.domesticSubscriber[e.target.name] = e.target.value;
    this.setState(t);
  }

  validateSubscriberForm() {
    let t = this.state;
    if (t.domesticSubscriber.name.length < 3) {
      t.domesticSubscriberError.name =
        'Name must be at least 3 characters in length';
    } else {
      t.domesticSubscriberError.name = '';
    }
    if (
      t.domesticSubscriber.email &&
      t.domesticSubscriber.email.length > 0 &&
      emailValidation(t.domesticSubscriber.email)
    ) {
      t.domesticSubscriberError.email = '';
    } else {
      t.domesticSubscriberError.email = 'Enter a valid email address';
    }

    if (
      t.domesticSubscriber.name.length > 2 &&
      emailValidation(t.domesticSubscriber.email)
    ) {
      return true;
    } else {
      this.setState(t);
      return false;
    }
  }

  submitSubscriberForm() {
    if (this.validateSubscriberForm()) {
      let subscriberObj = this.state.domesticSubscriber;
      subscriberObj.searchText = this.state.searchTerm;
      this.props.actions.submitDomesticSubscriber(subscriberObj);
    }
  }

  regionSearch(term) {
    this.setState({ searchTerm: term, active_search_result: '' });

    if (term.trim().length) {
      this.handleSearchDebounced();
    }
  }

  filterRegion(term) {
    const inputValue = term.trim().toLowerCase();

    let term_filter_arr = [];
    if (inputValue.indexOf('+') === -1) {
      term_filter_arr = _.filter(this.props.search_regions.allRegions, obj =>
        new RegExp('^' + inputValue, 'i').test(obj.search)
      );
    } else {
      let inputArr = inputValue.split('+');
      inputArr = inputArr.filter(e => e);
      let allRegions = this.props.search_regions.allRegions;

      inputArr.map(ele => {
        allRegions = _.filter(allRegions, obj =>
          new RegExp(ele.trim(), 'i').test(obj.search)
        );

        return false;
      });

      term_filter_arr = allRegions;
    }

    if (term_filter_arr.length) {
      let active_search_result = this.state.active_search_result;
      let activeResIn = _.findIndex(term_filter_arr, function(o) {
        return o.id === active_search_result;
      });
      if (activeResIn === -1) {
        active_search_result = '';
      }

      let sorted_region_arr = term_filter_arr.sort(
        (a, b) => a.search.length - b.search.length
      );
      this.setState({
        search_state: 0,
        visible_regions_set: sorted_region_arr,
        active_search_result: active_search_result
      });
    } else {
      this.setState({ search_state: 1, visible_regions_set: {} });
    }
  }

  clearSearchText() {
    let t = this.state;
    t.searchTerm = '';
    t.active_search_result = '';
    this.setState(t);
  }

  changeTab(index, listName) {
    if (index !== this.state.activeTabIndex) {
      this.setState({
        activeTabIndex: index,
        activeList: listName,
        active_search_result: ''
      });

      document.getElementById('landing-search-input').focus();
    }
  }

  onFocusSearchItem(option = null) {
    this.setState({ active_search_result: option ? option.id : '' });
  }

  handlePdgRegion(activeRegion) {
    // console.log(activeRegion);
    if (activeRegion.cityId) {
      localStorage.setItem('selected_city', JSON.stringify(activeRegion));

      // localStorage.setItem('selected_region_code', activeRegion.regionCode);
      // localStorage.setItem('selected_city_name', activeRegion.search);
    }
    if (activeRegion.regionCode !== this.props.pdgSelections.region) {
      this.props.actions.clearPDGSelections();
    }
    this.props.history.push(`/customize/${activeRegion.regionCode}`);
  }

  handleKeyPress(event) {
    let { history, top_regions } = this.props;
    let {
      search_state,
      searchTerm,
      active_search_result,
      activeList,
      visible_regions_set
    } = this.state;

    if (event.charCode === 13) {
      if (search_state === 1) {
        this.setState({ highlightSearch: false });

        history.push(`/get-packing/${searchTerm}`);
      } else {
        if (active_search_result === '') {
          this.setState({ highlightSearch: true });
          setTimeout(() => {
            this.setState({ highlightSearch: false });
          }, 800);
        } else {
          let activeRegion = null;
          if (searchTerm.trim().length) {
            activeRegion = _.find(visible_regions_set, o => {
              return o.id === active_search_result;
            });
          } else {
            activeRegion = _.find(top_regions[activeList], o => {
              return o.id === active_search_result;
            });
          }

          if (activeRegion) {
            // console.log(activeRegion);
            !activeRegion.offline && !activeRegion.campaign
              ? this.handlePdgRegion(activeRegion)
              : activeRegion.campaign
                ? this.setPageNavigation(activeRegion)
                : //(window.location.href = `/packages/${activeRegion.region.toLowerCase()}`)
                  history.push(`/get-packing/${activeRegion.region}`);
          } else {
            // console.log('activeRegion not found');
          }
        }
      }
    }
  }

  handleKeyDown(event) {
    let {
      activeList,
      searchTerm,
      activeTabIndex,
      tabLabels,
      active_search_result,
      visible_regions_set
    } = this.state;
    let temp_visible_regions_set =
      searchTerm.length > 0
        ? visible_regions_set
        : this.props.top_regions[activeList];

    // let scTop = $('.suggestions-list').scrollTop();
    let scTop = 0;
    let activeResIn = _.findIndex(temp_visible_regions_set, o => {
      return o.id === active_search_result;
    });

    switch (event.which) {
      case 37:
        // Left arrow
        if (activeTabIndex > 0 && !searchTerm.trim().length) {
          event.preventDefault();

          let prevIndex = activeTabIndex - 1;
          this.changeTab(prevIndex, tabLabels[prevIndex].list);
        }
        break;
      case 38:
        // Up arrow
        event.preventDefault();

        if (activeResIn > 0) {
          let prevRes = temp_visible_regions_set[activeResIn - 1];
          if (prevRes) {
            this.setState(
              {
                active_search_result: prevRes.id
              },
              () => this.scrollToViewport()
            );
          }
        }
        break;
      case 39:
        // Right arrow
        if (activeTabIndex < 2 && !searchTerm.trim().length) {
          event.preventDefault();

          let nextIndex = activeTabIndex + 1;
          this.changeTab(nextIndex, tabLabels[nextIndex].list);
        }
        break;
      case 40:
        // Up arrow
        event.preventDefault();

        // if (scTop < 50 && activeResIn > 5) {
        //   let nextRes = temp_visible_regions_set[0];
        //   if (nextRes) {
        //     this.setState({
        //       active_search_result: nextRes.id
        //     })
        //   }
        // } else {
        if (activeResIn + 1 < temp_visible_regions_set.length) {
          let nextRes = temp_visible_regions_set[activeResIn + 1];
          if (nextRes) {
            this.setState(
              {
                active_search_result: nextRes.id
              },
              () => this.scrollToViewport()
            );
          }
        }
        // }
        break;
      default:
        break;
    }
  }

  scrollToViewport() {
    // console.log("this.scrollToViewport");
    // let ele = document.querySelector('.search-container');

    setTimeout(() => {
      if (this.state.searchTerm.length) {
        let cA = document.querySelector('.search-suggestions li.active');

        if (!isElementInViewport(cA)) {
          cA.scrollIntoView(false);
        }
      } else {
        let cA = document.querySelector('.tab-list li.active');

        if (!isElementInViewport(cA)) {
          cA.scrollIntoView(false);
        }
      }
    }, 100);
  }

  render() {
    let {
      showModal,
      isKilled,
      searchTerm,
      search_state,
      visible_regions_set,
      domesticSubscriber,
      domesticSubscriberError
    } = this.state;
    if (isKilled) {
      return null;
    }

    let { search_regions, subscriberSubmitStatus } = this.props;
    let { domesticRegions } = search_regions;

    let searchModalClassName = classNames({
      'search-container': true,
      'landing-search': true,
      'show-search': showModal
    });

    let emailFormgroupClassName = classNames('form-group', {
      'has-error': domesticSubscriberError.email.length > 0
    });

    let nameFormgroupClassName = classNames('form-group', {
      'has-error': domesticSubscriberError.name.length > 0
    });

    return (
      <div className={searchModalClassName}>
        <div
          className={classNames('search-content', {
            // 'init-search': searchTerm.length === 0
          })}
        >
          {/* search-field starts */}
          <section className="clearfix search-field">
            <div className="clearfix pos-r">
              <p className="mb-0">
                <i className="vehoicon-navigation" />
                <b>PLAN A VACATION TO</b>
                {/* <span class="hidden-xs main-para">&nbsp;&mdash; A <a href="#">Couples</a> vacation for <a href="#">5-10 nights</a> in <a href="#">January</a> exploring <a href="#">Art, Nightlife</a> to:</span> */}
              </p>
              <Link to={`/`} target="_self">
                <i className="vehoicon-close close-search visible-xs" />
              </Link>
            </div>
            <section className="clearfix search-input-container">
              <div className="clearfix pos-r input-holder">
                <input
                  className="fw"
                  type="text"
                  placeholder="Search from over 3000 cities"
                  value={searchTerm}
                  id={'landing-search-input'}
                  onChange={e => this.regionSearch(e.target.value)}
                  onKeyPress={e => this.handleKeyPress(e)}
                  autoComplete="off"
                  autoFocus
                />
                {searchTerm.length > 0 ? (
                  <i
                    onClick={this.clearSearchText}
                    className="vehoicon-backspace visible-xs input-clear-icon"
                  />
                ) : null}
                <i
                  className="vehoicon-close close-search hidden-xs"
                  onClick={this.closeModal}
                />

                <Link
                  key={'searchCloseBtn'}
                  target="_self"
                  to={{
                    pathname: `/`,
                    state: { modal: false }
                  }}
                >
                  <i className="vehoicon-close close-search hidden-xs" />
                </Link>
                {/* <div class="arrows visible-xs">
                <a class="pull-left" href="#"><i class="vehoicon-arrow_downward rotate-90"></i></a>
                <a class="pull-right" href="#"><i class="vehoicon-arrow_downward rotate-minus-90"></i></a>
              </div> */}
              </div>
              <ul className="clearfix list-unstyled mb-0">
                <li className="active" />
                <li />
                <li />
                <li />
                <li />
              </ul>
            </section>
          </section>
          {/* search-field ends */}

          {/* search-tabs starts */}
          {searchTerm.length === 0 ? (
            <TopDestinations
              handlePdgRegion={this.handlePdgRegion}
              {...this.props.top_regions}
              activeTabIndex={this.state.activeTabIndex}
              activeList={this.state.activeList}
              tabLabels={this.state.tabLabels}
              active_search_result={this.state.active_search_result}
              changeTab={this.changeTab}
              onFocusSearchItem={this.onFocusSearchItem}
            />
          ) : search_state === 0 ? (
            <AllRegions
              handlePdgRegion={this.handlePdgRegion}
              regions={visible_regions_set}
              active_search_result={this.state.active_search_result}
              onFocusSearchItem={this.onFocusSearchItem}
            />
          ) : domesticRegions &&
          domesticRegions.includes(searchTerm.toLowerCase()) ? (
            subscriberSubmitStatus === 'SUCCESS' ? (
              <div className="row vmargin-large">
                <div className="col-sm-12 text-center">
                  <p className="mbottom-large color-grey-secondary medium-heading text-center">
                    Thank you! You will get notified about the updates on{' '}
                    <span className="color-accent-6">{searchTerm}</span>
                  </p>
                  <Link
                    to={{
                      pathname: `/`
                    }}
                    className="btn btn-primary"
                  >
                    Explore other destinations
                  </Link>
                </div>
              </div>
            ) : (
              <div className="col-md-10 col-md-push-1 vmargin-large">
                <p className="mbottom-medium color-grey-secondary medium-heading text-center">
                  Hey, we are not covering{' '}
                  <span className="color-accent-6">{searchTerm}</span>{' '}
                  currently.
                </p>
                <p className="mbottom-large small-heading text-center bold fade">
                  Sign up to stay updated
                </p>
                <p />
                <div className="row">
                  <div className="col-sm-6">
                    <div className={nameFormgroupClassName}>
                      <label className="control-label">Name</label>
                      <input
                        name="name"
                        onChange={this.handleSubscriberInput}
                        type="text"
                        value={domesticSubscriber.name}
                        className="form-control"
                        autoComplete="off"
                      />
                      {domesticSubscriberError.name &&
                        domesticSubscriberError.name.length > 0}
                      <span className="help-block">
                        {domesticSubscriberError.name}
                      </span>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className={emailFormgroupClassName}>
                      <label className="control-label">Email Id</label>
                      <input
                        name="email"
                        onChange={this.handleSubscriberInput}
                        value={domesticSubscriber.email}
                        type="email"
                        className="form-control"
                      />
                      {domesticSubscriberError.email &&
                        domesticSubscriberError.email.length > 0}
                      <span className="help-block">
                        {domesticSubscriberError.email}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="row mbottom-large">
                  <div className="col-sm-12 text-center">
                    <button
                      onClick={this.submitSubscriberForm}
                      type="button"
                      className="btn btn-primary"
                    >
                      Get Notified
                    </button>
                  </div>
                </div>
              </div>
            )
          ) : (
            <section className="clearfix search-error text-center vmargin-large">
              <p className="mbottom-small">
                Oh no 😕 We haven't unwrapped this destination yet!
              </p>
              <span>Drop us a postcard and we'll give you call.</span>
              <Link
                key={'searchCloseBtn'}
                to={{
                  pathname: `/get-packing/${searchTerm}`,
                  state: { modal: false }
                }}
                className="btn btn-primary"
              >
                Yes! I'm game
              </Link>
            </section>
          )}
          {/* search-tabs ends */}
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  let t = {};
  let regions_fetched = false;
  if (state.app.search_regions) {
    regions_fetched = true;
    let sr = state.app.search_regions.topRegions;
    let noOfItems = 6;

    if (sr && sr.length) {
      let family_regions = sr.filter(
        asset => asset.categoryTypes.indexOf('FAMILY') > -1
      );
      let couple_regions = sr.filter(
        asset => asset.categoryTypes.indexOf('COUPLE') > -1
      );
      let trending_regions = sr.filter(
        asset => asset.categoryTypes.indexOf('TRENDING') > -1
      );

      // let europe_regions = sr.filter(
      //   asset => asset.categoryTypes.indexOf('EUROPE') > -1
      // );

      t = {
        trending_regions: _.reverse(
          _.sortBy(trending_regions, ['numOfBookings'])
        ).splice(0, noOfItems),
        couple_regions: _.reverse(
          _.sortBy(couple_regions, ['numOfBookings'])
        ).splice(0, noOfItems),
        family_regions: _.reverse(
          _.sortBy(family_regions, ['numOfBookings'])
          // ).splice(0, noOfItems),
          // europe_regions: _.reverse(
          //   _.sortBy(europe_regions, ['numOfBookings'])
        ).splice(0, noOfItems)
      };
    }
  }

  return {
    top_regions: t,
    regions_fetched: regions_fetched,
    subscriberSubmitStatus: state.app.subscriberSubmitStatus,
    search_regions: state.app.search_regions,
    pdgSelections: state.app.pdgSelections
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      fetchSearchRegions: bindActionCreators(fetchSearchRegions, dispatch),
      clearPDGSelections: bindActionCreators(clearPDGSelections, dispatch),
      submitDomesticSubscriber: bindActionCreators(
        submitDomesticSubscriber,
        dispatch
      )
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(SearchModal);
