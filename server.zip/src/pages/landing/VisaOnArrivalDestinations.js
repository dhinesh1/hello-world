import React from 'react';
import { Link } from 'react-router-dom';
import _ from 'lodash';

import HomePagePackagesItineraryCard from '../../common_components/home/HomePagePackageItineraryCard';
import HomePageTestimonialCard from '../../common_components/home/HomePageTestimonialCard';
import { staticTestimonials } from '../../static-testimonials';

import { ThemedCardLoader } from '../../common_components/LoadingPlaceholders';
import ReactPlaceholder from 'react-placeholder';

export default function VisaOnArrivalDestinations({ packages, ready }) {
  const VOA_Packages = packages ? packages['visa-on-arrival-packages'] : [];
  return (
    <section className="container vpadding-large">
      <div className="clearfix">
        <h3 className="pull-left subheading">
          Visa on arrival 🚀 destinations
        </h3>
        <Link
          to="/visa-on-arrival-packages"
          target="_blank"
          className="pull-right btn btn-default btn-outline btn-sm n-tracker-visaonarrival-exploremore"
        >
          Explore more <i className="vehoicon-arrow_downward rotate-minus-90" />
        </Link>
      </div>

      <ReactPlaceholder
        ready={ready}
        customPlaceholder={<ThemedCardLoader testimonialPosition={2} />}
        type={'media'}
      >
        <div className="row row-eq-hgt">
          {VOA_Packages && VOA_Packages[0] ? (
            <HomePagePackagesItineraryCard
              p={VOA_Packages[0]}
              tracker={'n-tracker-visaonarrival-card'}
            />
          ) : null}

          {VOA_Packages && VOA_Packages[1] ? (
            <HomePagePackagesItineraryCard
              p={VOA_Packages[1]}
              tracker={'n-tracker-visaonarrival-card'}
            />
          ) : null}

          {staticTestimonials[0] ? (
            <HomePageTestimonialCard
              testimonial={staticTestimonials[0]}
              trackertestimonialcard={'n-tracker-visaonarrival-testimonialcard'}
            />
          ) : null}
          {VOA_Packages && VOA_Packages[2] ? (
            <HomePagePackagesItineraryCard
              p={VOA_Packages[2]}
              tracker={'n-tracker-visaonarrival-card'}
            />
          ) : null}
        </div>
      </ReactPlaceholder>
    </section>
  );
}
