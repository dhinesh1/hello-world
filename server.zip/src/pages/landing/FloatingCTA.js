import React from 'react';
import { Link } from 'react-router-dom';
import classNames from 'classnames';
import { trackEvent, EVENT_START_PLANNING } from '../../helpers/ML/EventsTracker';

const onClickCTA = () => {
  trackEvent(EVENT_START_PLANNING, {
    element_type: 'button',
    element_name: 'btn_pdg_start_planning_home_floating'
  });
}

export default function FloatingCTA({ show }) {
  let floatingCtaClass = classNames(
    'bottom-options-bar text-center floating-cta',
    { 'slide-up': show }
  );
  return (
    <div className={floatingCtaClass}>
      <section className="bottom-options-content">
        <div className="clearfix hidden-xs sm-text">
          {
            <p className="pull-left">
              Build an itinerary suited to your taste and budget
            </p>
          }
          <Link
            to={`/customize`}
            onClick={onClickCTA}
            className="pull-right btn btn-primary tracker-floating-cta"
          >
            Start planning now
          </Link>
        </div>
      </section>
    </div>
  );
}
