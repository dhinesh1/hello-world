import React from 'react';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';
import LottieControl from '../../animations/animationWrapper';
export default function LiveTravelConcierge() {
  return (
    <section className="live-travel">
      <div className="container-fluid">
        <div className="row vertical-center">
          <div className="col-sm-4 col-sm-offset-1 text-left">
            <LazyLoadComponent offset={200}>
              <img
                className="img-responsive bg-img hidden-xs"
                src="https://pyt-images.imgix.net/images/landing_image/live-travel-full.png"
                alt="Live travel"
              />
            </LazyLoadComponent>
            <h2 className="subheading" style={{ marginRight: '-15%' }}>
              Live travel concierge <br /> at your fingertips
            </h2>
            <p>
              Enjoy hassle free travel with our support team at every turn
              during your trip.
            </p>
            <ul className="list-unstyled mb-0">
              <li>
                <a
                  href="https://itunes.apple.com/us/app/pickyourtrail/id1400253672?mt=8&ign-mpt=uo%3D4"
                  target="_blank"
                >
                  <img
                    src="https://pyt-images.imgix.net/images/web_app/home/apple_v1.png"
                    alt="App store"
                  />
                </a>
              </li>
              <li>
                <a
                  href="https://play.google.com/store/apps/details?id=com.pickyourtrail&hl=en"
                  target="_blank"
                >
                  <img
                    src="https://pyt-images.imgix.net/images/web_app/home/android_v1.png"
                    alt="Google play"
                  />
                </a>
              </li>
            </ul>
          </div>
          <div className="col-sm-8">
            <LazyLoadComponent offset={400}>
              <LottieControl />
            </LazyLoadComponent>
          </div>
        </div>
      </div>
    </section>
  );
}
