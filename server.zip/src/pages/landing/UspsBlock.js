import React from 'react';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';
export default function UspsBlock() {
  return (
    <section className="our-features text-center vmargin-large">
      <div className="container">
        <div className="row">
          <div className="col-xs-12">
            <LazyLoadComponent>
              <ul className="clearfix list-unstyled mb-0">
                <li>
                  <span className="ico_1" />
                  <h2>100% customizable</h2>
                </li>
                <li>
                  <span className="ico_2" />
                  <h2>On-trip, All round support</h2>
                </li>
                <li>
                  <span className="ico_3" />
                  <h2>Unlimited Choices</h2>
                </li>
                <li>
                  <span className="ico_4" />
                  <h2>Rate Match Guarantee</h2>
                </li>
              </ul>
            </LazyLoadComponent>
          </div>
        </div>
      </div>
    </section>
  );
}
