import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import UspsBlock from './UspsBlock';
import RecentlyBookedItinerariesBlock from './RecentlyBookedItinerariesBlock';
import LiveTravelConcierge from './LiveTravelConcierge';
import TravelExpertBlock from './TravelExpertBlock';
import MediaArticlesBlock from './MediaArticlesBlock';
import { PackagesTrustBlock } from '../../common_components/packages/PackagesComponents';
import VisaOnArrivalDestinations from './VisaOnArrivalDestinations';
import PartnersBlock from './PartnersBlock';
import ThemedPackagesCardsSection from './ThemedPackageCardsSection';
import FloatingCTA from './FloatingCTA';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {
  getRecentlyBooked,
  getPackagesForHomePage,
  itineraryAssignUser,
  changeDeviceType,
  clearPDGSelections,
  fetchBannerImage
} from '../../actions/actions_app';
import LandingMobile from './LandingMobile';

import {
  openChatWidget,
  hideChatIconOnMobile,
  is_server,
  isFaqMobile,
  getImgIXUrl
} from '../../helpers/utilsHelper';
import SEOText from './SEOText';
import Loader from '../../common_components/Loader';
import { Helmet } from 'react-helmet';
import { SearchModalLoadable } from '../../helpers/loadbleComponentsHelper';
import { AppConfig } from '../../app-config';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';
import { trackEvent, EVENT_START_PLANNING } from '../../helpers/ML/EventsTracker';

const S3_baseUrl = AppConfig.images_cdn_url_s3;

class Landing extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isKilled: false,
      showFloatingCTA: false,
      showMobileFloatCTA: false
    };
  }

  componentDidMount() {
    if (!is_server()) {
      if (window.location.port !== '5001') {
        this.props.actions.changeDeviceType(
          isFaqMobile() ? 'phone' : 'desktop'
        );
        //calling action fetchBannerImage() when using on local port: 3000 to render the banner images.
        //using other port we have prevented from accessing it and won't re-render in any case.
        //please uncomment when running this in local.
        //this.props.actions.fetchBannerImage();
      }
    }

    if (!this.props.recently_booked) {
      this.props.actions.getRecentlyBooked();
    }

    if (!this.props.packages) {
      this.props.actions.getPackagesForHomePage({
        limit: 3,
        tags: [
          'visa-on-arrival-packages',
          'family-packages',
          'honeymoon-packages',
          'adventure-packages',
          'beach-packages'
        ]
      });
    }

    if (!is_server()) {
      if (!isFaqMobile()) {
        const _that = this;
        window.addEventListener(
          'scroll',
          function(event) {
            let scroll = this.scrollY;
            if (
              (scroll > 360 && scroll < 520) ||
              (scroll < 5644 && scroll > 5044)
            ) {
              _that.setState({ showFloatingCTA: true });
            }

            if (scroll < 320 || scroll > 5744) {
              _that.setState({ showFloatingCTA: false });
            }
          },
          {
            capture: true,
            passive: true
          }
        );
      } else {
        const _that = this;
        window.addEventListener(
          'scroll',
          function(event) {
            let scroll = this.scrollY;
            if (scroll > 280 && scroll < 350) {
              _that.setState({ showMobileFloatCTA: true });
            }

            if (scroll < 280 && scroll > 100) {
              _that.setState({ showMobileFloatCTA: false });
            }
          },
          {
            capture: true,
            passive: true
          }
        );
      }
    }
    this.props.actions.clearPDGSelections();
    SearchModalLoadable.preload();
  }

  onClickPlanning = () => {
    trackEvent(EVENT_START_PLANNING, {
      element_type: 'button',
      element_name: 'btn_pdg_create_itinerary_home'
    });
  }

  render() {
    let {
      recently_booked,
      packages,
      device,
      seoMetaData,
    } = this.props;
    let { showFloatingCTA, showMobileFloatCTA } = this.state;
    /**
     * setting the default banner details object if API fails.
     */
    let data = {
      imageName: 'Digital Detox',
      oringinalImageLink: 'https://unsplash.com/photos/BsURvd0ktFE',
      title: 'Looking for that perfect adrenaline rush?',
      name: 'Katerina Kerdi',
      link: 'https://unsplash.com/@katekerdi',
      imageLinkDes:
        'https://pyt-images.imgix.net/images/web_app/home/banners/desktop/detox.jpg',
      imageLinkMobile:
        'https://pyt-images.imgix.net/images/web_app/home/banners/mobile/detox.jpg'
    };
    let bannerImage =
      (Object.keys(this.props.randomBannerImage).length &&
        this.props.randomBannerImage) ||
      data;
    if (!device.length) {
      return <Loader showLoading />;
    }

    const SEOData = seoMetaData ? (
      <Helmet>
        <title>{seoMetaData.metaTitle}</title>
        <meta name={'description'} content={seoMetaData.metaDescription} />

        <link rel="alternate" href="android-app://com.pickyourtrail" />
        <link
          rel="canonical"
          href="https://pickyourtrail.com/"
          itemProp="url"
        />
      </Helmet>
    ) : null;

    if (device.toUpperCase() !== 'PHONE') {
      return (
        <div className="clearfix home">
          {SEOData}

          <FloatingCTA show={showFloatingCTA} />

          <section
            className="hero-banner"
            style={{
              backgroundImage: 'url(' + bannerImage.imageLinkDes + ')'
            }}
          >
            <div className="container">
              <div className="row">
                <div className="col-md-12">
                  <div className="banner_content text-center">
                    <div className="banner-title">
                      <p>{bannerImage.title}</p>
                      <h1 title="Customized vacation planning at best online prices!">
                        Create itineraries &amp; book your vacation, completely
                        online.
                      </h1>
                    </div>

                    <Link
                      key={'searchBtn'}
                      to={{
                        pathname: `/customize`,
                        state: { modal: true }
                      }}
                      onClick={this.onClickPlanning}
                      id="create-book-itin-cta-dt"
                      className="textbox-layer n-tracker-createbookyour-itinerary"
                    >
                      <i className="pull-left">
                        Choose your city or country...
                      </i>
                      <span className="pull-right btn btn-primary btn-huge">
                        Create itinerary
                      </span>
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            {/* google badge starts  */}
            <div className="google-badge hidden-sm hidden-xs">
              <div className="gbadge">
                <span className="ribbon">NAMES PICKYOURTRAIL AS</span>
                <div className="clearfix gbadge-inner text-center">
                  <i className="g-logo" />
                  <p>
                    <span>BENCHMARK FOR</span>CUSTOMER <span>DELIGHT</span>
                  </p>
                </div>
              </div>
            </div>
            {/* google badge ends  */}

            <span className="trips_curve" />
          </section>

          <UspsBlock />

          <RecentlyBookedItinerariesBlock
            itineraryAssignUser={this.props.actions.itineraryAssignUser}
            recently_booked={recently_booked}
            ready={!!recently_booked}
          />

          <LiveTravelConcierge />

          <VisaOnArrivalDestinations packages={packages} ready={!!packages} />

          <ThemedPackagesCardsSection
            testimonialPosition={1}
            testimonialIndex={1}
            objectKey={`family-packages`}
            packages={packages}
            type={'Family'}
            link={'family-packages'}
            themeName={'Great family 👪 holidays'}
            trackerexploremore={'n-tracker-familyholidays-exploremore'}
            tracker={'n-tracker-familyholidays-card'}
            trackertestimonialcard={'n-tracker-familyholidays-testimonialcard'}
            ready={!!packages}
          />

          <div className="container mbottom-large">
            <h3 className="text-center subheading">
              Why Choose Pickyourtrail?
            </h3>
            <PackagesTrustBlock />
          </div>

          <ThemedPackagesCardsSection
            packages={packages}
            objectKey={`honeymoon-packages`}
            testimonialPosition={3}
            testimonialIndex={2}
            type={'Honeymoon'} //changed to Family for demo
            link={'honeymoon-packages'}
            themeName={'Romantic 💑 holidays'}
            trackerexploremore={'n-tracker-romanticholidays-exploremore'}
            tracker={'n-tracker-romanticholidays-card'}
            trackertestimonialcard={
              'n-tracker-romanticholidays-testimonialcard'
            }
            ready={!!packages}
          />

          <section className="undiscover-aus live-travel">
            <div className="container">
              <div className="row vertical-center">
                <div className="col-sm-5">
                  <LazyLoadComponent>
                    <img
                      src={getImgIXUrl(
                        S3_baseUrl + 'web_app/home/undiscover-australia.png'
                      )}
                      alt="Undiscover australia"
                    />
                  </LazyLoadComponent>
                </div>
                <div className="col-sm-7">
                  <h2 className="subheading">
                    The many ways to<br /> Undiscover Australia
                  </h2>
                  <p>
                    Look beyond Sydney Opera house &amp; Harbour<br /> bridge,
                    dive into the technicolour Great Barrier Reef.<br /> OZ is
                    calling.
                  </p>
                  <Link
                    to={`/vacations/undiscover/australia?cpid=UnDiscover-Home-Banner`}
                    className="btn btn-primary btn-xl"
                    target="_blank"
                  >
                    Explore Australia{' '}
                    <i className="vehoicon-keyboard_arrow_right" />
                  </Link>
                </div>
              </div>
            </div>
          </section>

          <ThemedPackagesCardsSection
            objectKey={`adventure-packages`}
            packages={packages}
            testimonialPosition={1}
            testimonialIndex={3}
            type={'Family'} //changed to Family for demo
            link={'adventure-packages'}
            themeName={'Adventure 🏄‍ trips'}
            trackerexploremore={'n-tracker-adventuretrip-exploremore'}
            tracker={'n-tracker-adventuretrip-card'}
            trackertestimonialcard={'n-tracker-adventuretrip-testimonialcard'}
            ready={!!packages}
          />

          <ThemedPackagesCardsSection
            packages={packages}
            objectKey={`beach-packages`}
            testimonialPosition={0}
            testimonialIndex={4}
            type={'Family'} //changed to Family for demo
            link={'beach-packages'}
            themeName={'Beach 🏖️ vacations'}
            trackerexploremore={'n-tracker-beachvacations-exploremore'}
            tracker={'n-tracker-beachvacations-card'}
            trackertestimonialcard={'n-tracker-beachvacations-testimonialcard'}
            ready={!!packages}
          />

          <TravelExpertBlock openChatWidget={openChatWidget} />

          <PartnersBlock />

          <MediaArticlesBlock />

          <SEOText seoMetaData={seoMetaData} />
        </div>
      );
    } else {
      hideChatIconOnMobile();
      return (
        <LandingMobile
          SEOData={SEOData}
          seoMetaData={seoMetaData}
          showMobileFloatCTA={showMobileFloatCTA}
          itineraryAssignUser={itineraryAssignUser}
          recently_booked={recently_booked}
          mobileBannerImage={bannerImage.imageLinkMobile}
          mobileBannerTitle={bannerImage.title}
        />
      );
    }
  }
}

function mapStateToProps(state) {
  return {
    recently_booked: state.app.recently_booked,
    packages: state.app.packages,
    device: state.app.device,
    seoMetaData: state.app.seoMetaData,
    randomBannerImage: state.app.randomBannerImage
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getPackagesForHomePage: bindActionCreators(
        getPackagesForHomePage,
        dispatch
      ),
      fetchBannerImage: bindActionCreators(fetchBannerImage, dispatch),
      getRecentlyBooked: bindActionCreators(getRecentlyBooked, dispatch),
      changeDeviceType: bindActionCreators(changeDeviceType, dispatch),
      itineraryAssignUser: bindActionCreators(itineraryAssignUser, dispatch),
      clearPDGSelections: bindActionCreators(clearPDGSelections, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Landing);
