import React from 'react';

export default function SEOText({ seoMetaData }) {
  if (seoMetaData) {
    return (
      <div className="container">
        <div
          className="seo-text"
          dangerouslySetInnerHTML={{ __html: seoMetaData.seoContent }}
        />
      </div>
    );
  }
}
