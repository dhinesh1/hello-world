import React from 'react';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';
import { getImgIXUrl } from '../../helpers/utilsHelper';
export default function LiveTravelConcierge() {
  return (
    <LazyLoadComponent>
      <section className="our-partners text-center">
        <div className="container">
          <div className="row">
            <div className="col-xs-12">
              <img
                src={getImgIXUrl(
                  'https://d3lf10b5gahyby.cloudfront.net/misc/landing_new/partners-logo.png'
                )}
                alt="our partners"
              />
            </div>
          </div>
        </div>
        <div className="box">
          <h4>Partnered with the best</h4>
          <p>
            Backed by the world's leading travel companies to give you a hassle
            free vacation.
          </p>
        </div>
      </section>
    </LazyLoadComponent>
  );
}
