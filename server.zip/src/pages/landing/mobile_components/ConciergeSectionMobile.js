import React from 'react';

export default function ConciergeSectionMobile({ props }) {
  return (
    <section className="container xs-full-width">
      <div className="row">
        <div className="col-xs-12">
          <div className="travel-concierge">
            <p>
              Get
              <i>LIVE</i> travel concierge at your fingertips during your trips
              with our mobile concierge app!
            </p>
            <div className="app-link">
              <a href="#" target="_blank">
                <img
                  src="https://pyt-images.imgix.net/images/misc/landing_new/app-store.png"
                  alt
                />
              </a>
              <a href="#" target="_blank">
                <img src="https://pyt-images.imgix.net/images/misc/landing_new/google-play.png" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
