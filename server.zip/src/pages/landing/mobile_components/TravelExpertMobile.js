import React from 'react';
import { Link } from 'react-router-dom';
import { getImgIXUrl } from '../../../helpers/utilsHelper';
import LazyLoadComponent from '../../../common_components/LazyLoadComponent';

export default function TravelExpertMobile() {
  return (
    <div>
      <section className="travel-expert">
        <div className="container">
          <div className="row">
            <div className="col-xs-12">
              <div className="travel-expert-img">
                <LazyLoadComponent>
                  <img
                    src={getImgIXUrl(
                      'https://d3lf10b5gahyby.cloudfront.net/misc/landing_new/talktous-xs.png'
                    )}
                    alt="travel expert"
                  />
                </LazyLoadComponent>
              </div>
              <p>
                Questions? Our travel consultants are here to help.{' '}
                <Link
                  to={{
                    pathname: `/request-callback`
                  }}
                >
                  Talk to us!
                </Link>
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="container xs-full-width">
        <div className="row">
          <div className="col-xs-12">
            <div className="travel-concierge">
              <p>
                Get <i>LIVE</i> travel concierge at your fingertips during your
                trips with our mobile concierge app!
              </p>
              <div className="app-link">
                <a
                  href="https://itunes.apple.com/us/app/pickyourtrail/id1400253672?mt=8&ign-mpt=uo%3D4"
                  target="_blank"
                >
                  <img
                    src="https://pyt-images.imgix.net/images/web_app/home/apple_v1.png"
                    alt="App store"
                  />
                </a>
                <a
                  href="https://play.google.com/store/apps/details?id=com.pickyourtrail&hl=en"
                  target="_blank"
                >
                  <img
                    src="https://pyt-images.imgix.net/images/web_app/home/android_v1.png"
                    alt="Google play"
                  />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
