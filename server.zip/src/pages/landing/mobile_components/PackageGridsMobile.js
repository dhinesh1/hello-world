import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { getImgIXUrl } from '../../../helpers/utilsHelper';
import { AppConfig } from '../../../app-config';
import LazyLoadComponent from '../../../common_components/LazyLoadComponent';

export default class PackagesGridMobile extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <section className="packages-card-wrapper">
        <div className="container xs-full-width">
          <p className="heading">Explore itineraries</p>
          <p>
            Choose from the itinerary themes to get started. Don’t like them?
            Create your own from scratch.
          </p>
          <div className="row">
            <div className="col-xs-12">
              <div className="absolute-card">
                <div className="packages-card">
                  <Link
                    onClick={() => window.scrollTo(0, 0)}
                    to={`/honeymoon-packages`}
                    target="_self"
                    className="n-tracker-mbl-exploreiti-2"
                  >
                    <LazyLoadComponent>
                      <figure
                        style={{
                          backgroundImage: `url(${getImgIXUrl(
                            'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/sea_couples.jpg',
                            'w=592'
                          )})`
                        }}
                      >
                        <figcaption>
                          <h3>Him & Her ❤️ </h3>
                          <span className="red">from &#8377; 45,122</span>
                        </figcaption>
                      </figure>
                    </LazyLoadComponent>
                  </Link>
                </div>
                <div className="packages-card">
                  <Link
                    onClick={() => window.scrollTo(0, 0)}
                    to={`/packages/europe`}
                    target="_self"
                    className="n-tracker-mbl-exploreiti-1"
                  >
                    <LazyLoadComponent>
                      <figure
                        style={{
                          backgroundImage: `url(${getImgIXUrl(
                            'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/5.png',
                            'w=296'
                          )})`
                        }}
                      >
                        <figcaption>
                          <h3>Discover Europe</h3>
                          <span className="yellow">from &#8377; 75,134</span>
                        </figcaption>
                      </figure>
                    </LazyLoadComponent>
                  </Link>
                </div>
              </div>
              <div className="packages-card">
                <Link
                  onClick={() => window.scrollTo(0, 0)}
                  to={`/family-packages`}
                  target="_self"
                  className="n-tracker-mbl-exploreiti-3"
                >
                  <LazyLoadComponent>
                    <figure
                      style={{
                        backgroundImage: `url(${getImgIXUrl(
                          'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/2.png',
                          'w=296'
                        )})`
                      }}
                    >
                      <figcaption>
                        <h3>Family before All</h3>
                        <span className="white">from &#8377; 52,314</span>
                      </figcaption>
                    </figure>
                  </LazyLoadComponent>
                </Link>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-xs-12">
              <p className="good-news">
                Good news! All our itineraries are completely customisable!
              </p>
            </div>
          </div>

          <div className="row">
            <div className="col-xs-12">
              <div className="double-card clearfix">
                <div className="packages-card">
                  <Link
                    onClick={() => window.scrollTo(0, 0)}
                    to={`/visa-on-arrival-packages`}
                    target="_self"
                    className="n-tracker-mbl-exploreiti-4"
                  >
                    <LazyLoadComponent>
                      <figure
                        style={{
                          backgroundImage: `url(${getImgIXUrl(
                            'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/6.png',
                            'w=296'
                          )})`
                        }}
                      >
                        <figcaption>
                          <h3>
                            Visa Less <br />Vacations
                          </h3>
                          <span className="green">from &#8377; 42,124</span>
                        </figcaption>
                      </figure>
                    </LazyLoadComponent>
                  </Link>
                </div>
                <div className="packages-card">
                  <Link
                    onClick={() => window.scrollTo(0, 0)}
                    to={`/beach-packages`}
                    target="_self"
                    className="n-tracker-mbl-exploreiti-5"
                  >
                    <LazyLoadComponent>
                      <figure
                        style={{
                          backgroundImage: `url(${getImgIXUrl(
                            'https://d3lf10b5gahyby.cloudfront.net/product_blog/seychelles.jpeg',
                            'w=296'
                          )})`
                        }}
                      >
                        <figcaption>
                          <h3>Sandy Tales</h3>
                          <span className="yellow">from &#8377; 62,138</span>
                        </figcaption>
                      </figure>
                    </LazyLoadComponent>
                  </Link>
                </div>
              </div>
              <div className="absolute-card">
                <div className="packages-card">
                  <Link
                    onClick={() => window.scrollTo(0, 0)}
                    to={`/adventure-packages`}
                    target="_self"
                    className="n-tracker-mbl-exploreiti-7"
                  >
                    <LazyLoadComponent>
                      <figure
                        style={{
                          backgroundImage: `url(${getImgIXUrl(
                            'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/b.png',
                            'w=592'
                          )})`
                        }}
                      >
                        <figcaption>
                          <h3>Game of Adventures</h3>
                          <span className="white">from &#8377; 57,453</span>
                        </figcaption>
                      </figure>
                    </LazyLoadComponent>
                  </Link>
                </div>
                <div className="packages-card">
                  <Link
                    onClick={() => window.scrollTo(0, 0)}
                    to={`/packages/bali`}
                    target="_self"
                    className="n-tracker-mbl-exploreiti-6"
                  >
                    <LazyLoadComponent>
                      <figure
                        style={{
                          backgroundImage: `url(${getImgIXUrl(
                            'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/7.png',
                            'w=296'
                          )})`
                        }}
                      >
                        <figcaption>
                          <h3>Beautiful Bali</h3>
                          <span className="red">from &#8377; 36,122</span>
                        </figcaption>
                      </figure>
                    </LazyLoadComponent>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
}
