import React, { Component } from 'react';
import {
  getStringFromArray,
  getPersonalizationMeterClass
} from '../../../helpers/commonHelpers';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';
import { itineraryAssignUser } from '../../../actions/actions_app';
import Slider from 'react-slick';
import moment from 'moment';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getBookedDateString } from '../../../helpers/utilsHelper';
import { RecentlyBookedItinerariesMobile } from '../../../common_components/LoadingPlaceholders';
import ReactPlaceholder from 'react-placeholder';
import { trackEvent, EVENT_RECENTLY_BOOKED } from '../../../helpers/ML/EventsTracker';

class RecentlyBookedMobile extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    let { rb, ready } = this.props;
    let settings = {
      slidesToShow: 3,
      slidesToScroll: 1,
      arrows: false,
      responsive: [
        {
          breakpoint: 992,
          settings: {
            infinite: false,
            centerMode: true,
            centerPadding: '12%',
            dots: true,
            slidesToShow: 1,
            initialSlide: 1
          }
        }
      ]
    };

    let tooltip = [];
    let mobileCards = null;
    if (rb) {
      mobileCards = rb.map((r, i) => {
        tooltip[i] = <Tooltip id={'tooltip' + i}>{r.departueAirport}</Tooltip>;

        return (
          <div key={`booking-card-${i}`}>
            <div className="booking-card n-tracker-mbl-rb-itinerary">
              <a
                href="#"
                onClick={e => {
                  e.preventDefault();
                  e.stopPropagation();
                  trackEvent(EVENT_RECENTLY_BOOKED, {
                    destination: getStringFromArray(r.countriesList, ', '),
                    title: `${r.nights} nights in ${r.bookedOn > 0 ? moment(r.bookedOn).format('MMM') : moment().format('MMM')}`,
                    price: typeof r.cost === 'string' ? parseInt(r.cost.replace(/,/g,'')) : r.cost
                  });
                  this.props.actions.itineraryAssignUser(r.itineraryId);
                }}
              >
                <div className="booking-card-txt">
                  <p>
                    <span>{getStringFromArray(r.countriesList, ', ')}</span>
                    {r.nights} nights in{' '}
                    {r.bookedOn > 0
                      ? moment(r.bookedOn).format('MMM')
                      : moment().format('MMM')}{' '}
                    {r.departueAirport !== '$$$' ? `from ` : null}
                    {r.departueAirport !== '$$$' ? (
                      <OverlayTrigger
                        id={'ot1-' + i}
                        placement="top"
                        overlay={tooltip[i]}
                      >
                        <i data-tip={'React-tooltip'} id={`airport-code-${i}`}>
                          {r.departueAirport}{' '}
                        </i>
                      </OverlayTrigger>
                    ) : null}
                    {r.bookedBy ? `by ${r.bookedBy}` : null}
                  </p>
                  <b>
                    &#8377;{r.cost}
                    <i>/person</i>
                  </b>
                  <div className="meter-txt">
                    <i
                      className={getPersonalizationMeterClass(r.customizations)}
                    />
                    <p>
                      <span>
                        {r.customizations === 0 ? `7` : r.customizations}{' '}
                        PERSONALISATIONS
                      </span>
                      {getBookedDateString(r.bookedOn)}
                    </p>
                  </div>
                </div>
              </a>
            </div>
          </div>
        );
      });
    }

    return (
      <section>
        <div className="packages-card-wrapper container">
          <p className="heading">Recently booked</p>
          <h2>A new booking every 2 hours! Deals updated every day!</h2>
        </div>

        {/* slider starts */}
        <ReactPlaceholder
          ready={ready}
          customPlaceholder={<RecentlyBookedItinerariesMobile />}
          type={'media'}
        >
          <Slider {...settings} className="clearfix bookingcard-slider">
            {mobileCards}
          </Slider>
        </ReactPlaceholder>
        {/* slider starts */}
      </section>
    );
  }
}

function mapStateToProps(state) {
  return {
    recently_booked: state.app.recently_booked
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      itineraryAssignUser: bindActionCreators(itineraryAssignUser, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(RecentlyBookedMobile);
