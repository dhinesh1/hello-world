import React from 'react';
import { Link } from 'react-router-dom';
import classNames from 'classnames';

export default function StickyFooterMobile({
  openChatWidget,
  showMobileFloatCTA
}) {
  let cl = classNames('bottom-options-bar text-center', {
    'slide-up': showMobileFloatCTA
  });

  return (
    <div className={cl}>
      <section className="bottom-options-content">
        <div className="clearfix xs-btns">
          <Link
            to={`/customize`}
            className="btn btn-primary btn-block cta-plantrip mbl-plan-btn n-tracker-mbl-planatripcta"
          >
            Start planning now
          </Link>
        </div>
      </section>
    </div>
  );
}
