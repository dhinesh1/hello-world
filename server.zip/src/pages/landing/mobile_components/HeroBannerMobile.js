import React from 'react';
import { Link } from 'react-router-dom';

export default function HeroBannerMobile({ props, bannerImage, title }) {
  return (
    <section
      className="hero-banner"
      style={{
        backgroundImage: 'url( ' + bannerImage + ')'
      }}
    >
      <div className="banner-title">
        <p>{title}</p>
        <h1 title="Customized vacation planning at best online prices!">
          Create itineraries &amp; book vacation online.
        </h1>
      </div>

      <Link to={`/customize`} className="btn btn-primary tracker-plansearch">
        Start planning now
      </Link>
    </section>
  );
}
