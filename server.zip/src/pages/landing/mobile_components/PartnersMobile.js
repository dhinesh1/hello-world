import React from 'react';

import { AppConfig } from '../../../app-config';
import { Link } from 'react-router-dom';
import LazyLoadComponent from '../../../common_components/LazyLoadComponent';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

const S3_baseUrl = AppConfig.images_cdn_url_s3;

export default function PartnersBlock() {
  return (
    <div>
      <section className="our-partners">
        <div className="container xs-full-width">
          <div className="row">
            <div className="col-xs-12">
              <LazyLoadComponent>
                <ul className="clearfix list-unstyled mb-0">
                  <li>
                    <span className="partner_img_1" />
                  </li>
                  <li>
                    <span className="partner_img_2" />
                  </li>
                  <li>
                    <span className="partner_img_3" />
                  </li>
                  <li>
                    <span className="partner_img_4" />
                  </li>
                </ul>
              </LazyLoadComponent>
              <p>Certified &amp; partnered with the best in the industry. </p>
            </div>
          </div>
        </div>
      </section>

      <div className="undiscover-aus">
        <div className="container xs-full-width">
          <div className="row">
            <div className="col-xs-12 text-center">
              <LazyLoadComponent>
                <img
                  src={getImgIXUrl(
                    S3_baseUrl + 'web_app/home/undiscover-australia.png'
                  )}
                  alt="Undiscover australia"
                />
              </LazyLoadComponent>
              <p className="heading">
                The many ways to<br /> Undiscover Australia
              </p>
              <p>
                Look beyond Sydney Opera house &amp; Harbour bridge, dive into
                the technicolour Great Barrier Reef. OZ is calling.
              </p>
              <Link
                to={`/vacations/undiscover/australia?cpid=UnDiscover-Home-Banner`}
                className="btn btn-primary"
                target="_blank"
              >
                Explore Australia{' '}
                <i className="vehoicon-keyboard_arrow_right" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {
        <section className="packages-card-wrapper mbottom-large">
          <div className="container xs-full-width">
            <div className="row">
              <div className="col-xs-12">
                <div className="absolute-card">
                  <div className="packages-card">
                    <Link
                      onClick={() => window.scrollTo(0, 0)}
                      to={`/packages/maldives`}
                      target="_self"
                      className="n-tracker-mbl-dreamy-island-1"
                    >
                      <LazyLoadComponent>
                        <figure
                          style={{
                            backgroundImage: `url(${getImgIXUrl(
                              'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/dreamy_islands.png',
                              'w=296'
                            )})`
                          }}
                        >
                          <figcaption>
                            <h3>Dreamy Islands</h3>
                            <span className="red">from ₹ 73,225</span>
                          </figcaption>
                        </figure>
                      </LazyLoadComponent>
                    </Link>
                  </div>
                  <div className="packages-card">
                    <Link
                      onClick={() => window.scrollTo(0, 0)}
                      to={`/packages/australia`}
                      target="_self"
                      className="n-tracker-mbl-dreamy-island-2"
                    >
                      <LazyLoadComponent>
                        <figure
                          style={{
                            backgroundImage: `url(${getImgIXUrl(
                              'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/awestriking_australia.png',
                              'w=296'
                            )})`
                          }}
                        >
                          <figcaption>
                            <h3>Awe-striking Australia</h3>
                            <span className="yellow">from ₹ 1,12,060</span>
                          </figcaption>
                        </figure>
                      </LazyLoadComponent>
                    </Link>
                  </div>
                </div>
                <div className="double-card clearfix">
                  <div className="packages-card">
                    <Link
                      onClick={() => window.scrollTo(0, 0)}
                      to={`/packages/thailand`}
                      target="_self"
                      className="n-tracker-mbl-dreamy-island-3"
                    >
                      <LazyLoadComponent>
                        <figure
                          style={{
                            backgroundImage: `url(${getImgIXUrl(
                              'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/gusto_thailand.png',
                              'w=296'
                            )})`
                          }}
                        >
                          <figcaption>
                            <h3>Thai Getaway</h3>
                            <span className="green">from ₹ 46,784</span>
                          </figcaption>
                        </figure>
                      </LazyLoadComponent>
                    </Link>
                  </div>
                  <div className="packages-card">
                    <Link
                      onClick={() => window.scrollTo(0, 0)}
                      to={`/packages/new-zealand`}
                      target="_self"
                      className="n-tracker-mbl-dreamy-island-3"
                    >
                      <LazyLoadComponent>
                        <figure
                          style={{
                            backgroundImage: `url(${getImgIXUrl(
                              'https://d3lf10b5gahyby.cloudfront.net/landing_mobile/new-zealand.jpg',
                              'w=296'
                            )})`
                          }}
                        >
                          <figcaption>
                            <h3>
                              Daring<br />New Zealand
                            </h3>
                            <span className="yellow">from ₹ 93,211</span>
                          </figcaption>
                        </figure>
                      </LazyLoadComponent>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      }
    </div>
  );
}
