import React from 'react';
import {
  getStringFromArray,
  getPersonalizationMeterClass
} from '../../helpers/commonHelpers';
import moment from 'moment';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';
import { PackagesItineraryCardLoader } from '../../common_components/LoadingPlaceholders';
import ReactPlaceholder from 'react-placeholder';
import { getBookedDateString, getImgIXUrl } from '../../helpers/utilsHelper';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';
import { trackEvent, EVENT_RECENTLY_BOOKED } from '../../helpers/ML/EventsTracker';

export default function RecentlyBookedItinerariesBlock({
  recently_booked,
  itineraryAssignUser,
  ready
}) {
  return (
    <section className="container vpadding-large">
      <h3 className="subheading">Recently ⏲ booked</h3>

      <ReactPlaceholder
        ready={ready}
        customPlaceholder={<PackagesItineraryCardLoader />}
        type={'media'}
      >
        <div className="row row-eq-hgt">
          <RecentlyBookedCardList
            recently_booked={recently_booked}
            itineraryAssignUser={itineraryAssignUser}
          />
        </div>
      </ReactPlaceholder>
    </section>
  );
}

function RecentlyBookedCardList(recently_booked) {
  const tooltip = [];

  return recently_booked.recently_booked.map((recent, i) => {
    tooltip[i] = <Tooltip id={'tooltip' + i}>{recent.departureCity}</Tooltip>;
    return (
      <div
        className="col-xs-3"
        key={`recently-booked-${i}`}
        onClick={() => {
          recently_booked.itineraryAssignUser(recent.itineraryId);
          trackEvent(EVENT_RECENTLY_BOOKED, {
            destination: getStringFromArray(recent.countriesList, ', '),
            title: `${recent.nights} nights in ${recent.travellingOn > 0 ? moment(recent.travellingOn).format('MMM') : moment().format('MMM')}`,
            price: typeof recent.cost === 'string' ? parseInt(recent.cost.replace(/,/g,'')) : recent.cost
          });
        }}
      >
        <div className="booking-card n-tracker-rb-itinerary">
          <a href="#">
            <LazyLoadComponent>
              <figure
                style={{
                  backgroundImage: `url(${getImgIXUrl(recent.image, 'w=600')})`
                }}
              >
                {recent.selfBooker ? <p>Self Booker</p> : null}
                <figcaption className="fig-title">
                  <span className="tag-tertiary white truncate medium">
                    {getStringFromArray(recent.countriesList, ', ')}
                  </span>
                </figcaption>
              </figure>
            </LazyLoadComponent>
            <div className="clearfix pos-r">
              {recent.avatar ? (
                <span className="image_curve">
                  <img src={recent.avatar} alt="User_Image" />
                </span>
              ) : null}
              <p>
                {/* <span>{getStringFromArray(recent.countriesList, ', ')}</span> */}
                {recent.nights} nights in{' '}
                {recent.travellingOn > 0
                  ? moment(recent.travellingOn).format('MMM')
                  : moment().format('MMM')}{' '}
                {recent.departueAirport !== '$$$' ? `from ` : null}
                {recent.departueAirport !== '$$$' ? (
                  <OverlayTrigger
                    id={'ot1-' + i}
                    placement="top"
                    overlay={tooltip[i]}
                  >
                    <i data-tip={'React-tooltip'} id={`airport-code-${i}`}>
                      {recent.departueAirport}
                    </i>
                  </OverlayTrigger>
                ) : null}
                {recent.bookedBy ? ` by ${recent.bookedBy}` : null}
              </p>
              <b>
                &#8377;{recent.cost}
                <i>/person</i>
              </b>
              <div className="meter-txt">
                <LazyLoadComponent>
                  <i
                    className={getPersonalizationMeterClass(
                      recent.customizations
                    )}
                  />
                </LazyLoadComponent>
                <p>
                  <span>
                    {recent.customizations === 0 ? `7` : recent.customizations}{' '}
                    PERSONALISATIONS
                  </span>
                  {getBookedDateString(recent.bookedOn)}
                </p>
              </div>
            </div>
          </a>
        </div>
      </div>
    );
  });
}
