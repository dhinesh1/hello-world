import React from 'react';
import { Link } from 'react-router-dom';
export default function PersonalizationBlock() {
  return (
    <section className="maximum-section">
      <div className="container-fluid">
        <div className="row vertical-center">
          <div className="col-sm-6 no-padding">
            <img
              src="https://pyt-images.imgix.net/images/misc/landing_new/dash.jpg"
              alt
            />
          </div>
          <div className="col-sm-5 text-right">
            <h2 className="subheading">
              <i />Maximum personalisations. No more packaged trips!
            </h2>
            <p>
              Personalise everything from hotels, activities, flights and
              insurance yourself.
            </p>
            <a className="btn btn-primary btn-xl">
              Create &amp; book your itinerary
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
