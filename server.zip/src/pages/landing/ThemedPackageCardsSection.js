import React from 'react';
import HomePagePackagesItineraryCard from '../../common_components/home/HomePagePackageItineraryCard';
import HomePageTestimonialCard from '../../common_components/home/HomePageTestimonialCard';
import { staticTestimonials } from '../../static-testimonials';
import { ThemedCardLoader } from '../../common_components/LoadingPlaceholders';
import ReactPlaceholder from 'react-placeholder';

export default function ThemedPackageCardsSection({
  packages,
  type,
  themeName,
  link,
  trackerexploremore,
  tracker,
  trackertestimonialcard,
  testimonialPosition,
  testimonialIndex,
  ready,
  objectKey
}) {
  let themed_packages = packages ? packages[objectKey] : [];

  return (
    <section className="container vpadding-large">
      <div className="clearfix">
        <h3 className="pull-left subheading">{themeName}</h3>
        <a
          href={link}
          target="_blank"
          className={
            'pull-right btn btn-default btn-outline btn-sm ' +
            trackerexploremore
          }
        >
          Explore more <i className="vehoicon-arrow_downward rotate-minus-90" />
        </a>
      </div>
      <ReactPlaceholder
        ready={ready}
        type={'media'}
        customPlaceholder={
          <ThemedCardLoader testimonialPosition={testimonialPosition} />
        }
      >
        <div className="row row-eq-hgt">
          {testimonialPosition === 0 && packages ? (
            <HomePageTestimonialCard
              testimonial={staticTestimonials[testimonialIndex]}
              trackertestimonialcard={trackertestimonialcard}
            />
          ) : null}

          {themed_packages && themed_packages[0] ? (
            <HomePagePackagesItineraryCard
              p={themed_packages[0]}
              tracker={tracker}
            />
          ) : null}

          {testimonialPosition === 1 && packages ? (
            <HomePageTestimonialCard
              testimonial={staticTestimonials[testimonialIndex]}
              trackertestimonialcard={trackertestimonialcard}
            />
          ) : null}

          {themed_packages && themed_packages[1] ? (
            <HomePagePackagesItineraryCard
              p={themed_packages[1]}
              tracker={tracker}
            />
          ) : null}

          {testimonialPosition === 2 && packages ? (
            <HomePageTestimonialCard
              testimonial={staticTestimonials[testimonialIndex]}
              trackertestimonialcard={trackertestimonialcard}
            />
          ) : null}

          {themed_packages && themed_packages[2] ? (
            <HomePagePackagesItineraryCard
              p={themed_packages[2]}
              tracker={tracker}
            />
          ) : null}

          {testimonialPosition === 3 && packages ? (
            <HomePageTestimonialCard
              testimonial={staticTestimonials[testimonialIndex]}
              trackertestimonialcard={trackertestimonialcard}
            />
          ) : null}
        </div>
      </ReactPlaceholder>
    </section>
  );
}
