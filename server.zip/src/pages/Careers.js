import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { fetchCareers } from '../actions/actions_app';
import classNames from 'classnames';
import Scroll from 'react-scroll';
import { Helmet } from 'react-helmet';
import { isFaqMobile } from '../helpers/utilsHelper';

const Element = Scroll.Element;
const Link = Scroll.Link;
const CareersCtaScroll = {
  ViewCurrentOpenings: 'ViewCurrentOpenings'
};
const scroller = Scroll.scroller;

class Careers extends Component {
  constructor(props) {
    super(props);

    this.state = {
      expanded: ''
    };

    this.expandThis = this.expandThis.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }

  expandThis(index) {
    let selectedOpenings = this.props.match.params.currentOpeningKey;
    if (selectedOpenings === index) {
      index = '';
    } else {
      index = '/' + index;
    }

    this.props.history.push('/careers' + index);
  }

  handleKeyUp(e) {
    let selectedOpenings = this.props.match.params.currentOpeningKey;
    if (e.keyCode === 27) this.expandThis(selectedOpenings);
  }

  componentDidMount() {
    // Triggering the api request action to fetch the career openings list
    this.props.actions.fetchCareers();
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentDidUpdate() {
    // Scrolling to the expanded component after component update
    let selectedOpenings = this.props.match.params.currentOpeningKey;
    if (selectedOpenings) {
      if (isFaqMobile()) {
        scroller.scrollTo(selectedOpenings, {
          duration: 500,
          smooth: true,
          offset: -70
        });
      } else {
        scroller.scrollTo(selectedOpenings, {
          duration: 500,
          smooth: true,
          offset: -85
        });
      }
    }
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  render() {
    // let { expanded } = this.state;
    const expanded = this.props.match.params.currentOpeningKey;
    const { openings } = this.props;

    return (
      <section className="careers-page ">
        <Helmet>
          <title>Careers | Pickyourtrail</title>
          <meta
            name={'description'}
            content={
              "Passionate? Hungry for growth? Want to spearhead in life? Here's your chance to work with Pickyourtrail, India's most exciting travel startup!"
            }
          />
          <meta
            property="og:image"
            content="https://pyt-images.imgix.net/images/web_app/careers/og-img/career-og.png"
          />
          <meta
            property="og:image:url"
            content="https://pyt-images.imgix.net/images/web_app/careers/og-img/career-og.png"
          />
          <meta
            property="og:image:secure_url"
            content="https://pyt-images.imgix.net/images/web_app/careers/og-img/career-og.png"
          />
          <meta property="og:image:type" content="image/png" />
          <meta property="og:type" content="website" />
          <meta property="og:title" content="Pickyourtrail - Career Hunt" />
          <meta
            property="og:description"
            content="Join our team at Pickyourtrail and show us what you're made of!"
          />
          <meta property="og:url" content="https://pickyourtrail.com/careers" />
        </Helmet>

        <div className="careers-bg" />
        <section className="title-outer">
          <div className="container xs-full-width">
            <div className="row">
              <div className="col-xs-12">
                <section className="title-sec">
                  <h1 className="journey">Careers</h1>
                  <hr className="divider" />
                  <p className="fade">There is always room for more!</p>
                </section>
                <section className="whatwelook-outer">
                  <div className="whatwelook-inner clearfix">
                    <div className="careers-content">
                      <h3>We are looking for</h3>
                      <p className="base fade normal">
                        Love learning and scaling? Thrive in adversity and
                        chaos? Have nothing short of passion for work? Patch
                        this up with the will to make customer happiness the end
                        goal and you will be right at home in Pickyourtrail.
                      </p>
                    </div>
                    <div className="careers-content">
                      <h3>What you'll get</h3>
                      <p>
                        One part security of working with a big organization two
                        parts the buzzing, exciting start-up work environment.
                        An opportunity to work along with a talented employee
                        pool from the likes of MMT, Western Union, and In Mobi.{' '}
                      </p>
                    </div>
                  </div>
                  <div className="view-current text-center vmargin-large hidden-xs hidden-sm">
                    <Link
                      to={CareersCtaScroll.ViewCurrentOpenings}
                      spy={true}
                      smooth={true}
                      duration={500}
                      offset={-72}
                      className="btn btn-xl btn-primary "
                    >
                      View current openings
                    </Link>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </section>
        <Element name={CareersCtaScroll.ViewCurrentOpenings}>
          <section className="current-openings-outer">
            <div className="container">
              <div className="row">
                <div className="text-center">
                  <h2>Current Openings</h2>
                  <hr className="divider" />
                </div>
                <section className="job-cards-outer">
                  <div className="container job-cards-inner ">
                    <ul id="og-grid" className="og-grid list-unstyled">
                      {/*
                        openings.map((item,inx) => {
                          return <SingleOpeningRow key={"opening_row_"+inx} items={item}
                                                    expanded={expanded}
                                                    expandThis={this.expandThis} />
                        })
                      */}

                      {openings.map((item, inx) => {
                        if (item.status === 1) {
                          return (
                            <SingleTeamMemberInfo
                              key={'opening_row_' + inx}
                              item={item}
                              index={item.openingsKey}
                              isExpanded={expanded === item.openingsKey}
                              expandThis={this.expandThis}
                            />
                          );
                        }
                      })}
                    </ul>
                  </div>
                </section>
                <section className="team-gallery-outer">
                  <div className="text-center">
                    <p>
                      We love travel, we love the world. But we also have fun,
                      share bromance moments and get senti and celebratory on
                      occasions. Here's us - the Pickyourtrail family.
                    </p>
                  </div>
                  <div className="team-inner clearfix">
                    <div className="team">
                      <i className="team-img" />
                    </div>
                    <div className="team">
                      <i className="team-img" />
                    </div>
                    <div className="team">
                      <i className="team-img" />
                    </div>
                    <div className="team">
                      <i className="team-img" />
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </section>
        </Element>
      </section>
    );
  }
}

const SingleTeamMemberInfo = props => (
  <li
    className={classNames('current-open-card', {
      'og-expanded': props.isExpanded
    })}
  >
    <Element
      name={props.item.openingsKey}
      className="job-card"
      onClick={e => props.expandThis(props.index, e)}
    >
      <h4>{props.item.position}</h4>
      <p>{props.item.shortDesc}</p>
    </Element>
    {props.isExpanded ? <ExpandedContainer {...props} /> : null}
  </li>
);

const ExpandedContainer = props => (
  <div
    className="og-expander"
    style={{ transition: 'height 350ms ease', height: 600 }}
  >
    <div className="og-expander-inner">
      <span
        className="og-close"
        onClick={e => props.expandThis(props.index, e)}
      />
      <h4>{props.item.position}</h4>
      <div className="row">
        <div className="col-xs-12 col-sm-6">
          <p
            className="normal"
            dangerouslySetInnerHTML={{ __html: props.item.longDesc }}
          />
          <br />
          <p>
            <span className="bold">Soft skills</span>
          </p>
          <ul className="fade">
            <li>
              Should be able to understand and appreciate that chaos /
              randomisation is the only constant at a startup.
            </li>
            <li>
              Should be a passionate self-starter; ready to get their hands
              dirty
            </li>
            <li>
              Should envision and manage the growth of tech vertical to
              complement business growth
            </li>
            <li>Should have a clarity in thought and articulation.</li>
            <li>
              Prior experience of high energy and intense environments - would
              be a plus
            </li>
          </ul>
        </div>
        <div className="col-xs-12 col-sm-6">
          {props.item.rolesDesc === '' ? null : (
            <div>
              <p className="bold">Roles and responsibilities</p>
              <ul
                className="fade"
                dangerouslySetInnerHTML={{ __html: props.item.rolesDesc }}
              />
            </div>
          )}
          <p className="bold">Technical skills</p>
          <ul
            className="fade"
            dangerouslySetInnerHTML={{ __html: props.item.points }}
          />
          {props.item.url === '' ? (
            <div>
              <span className="bold">How to apply?</span>
              <p>
                Send your resume to{' '}
                <a href={'mailto:' + props.item.email}>{props.item.email}</a> to
                apply. Mention the job code{' '}
                <span className="bold">{props.item.code}</span> on the subject.
              </p>
            </div>
          ) : (
            <a
              href={props.item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary cta-careers"
            >
              Apply
            </a>
          )}
        </div>
      </div>
    </div>
  </div>
);

function mapStateToProps(state) {
  return {
    // if careers is undefined the assining an empty array to avoid the exception
    openings: state.app.careers ? state.app.careers : []
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      fetchCareers: bindActionCreators(fetchCareers, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Careers);
