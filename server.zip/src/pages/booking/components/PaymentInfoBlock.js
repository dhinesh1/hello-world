import React from 'react';
import { Link } from 'react-router-dom';
import {
  getAllCities,
  adultsChildrenString
} from '../../../helpers/utilsHelper';
import classNames from 'classnames';
export default function PaymentInfoBlock({
  itineraryDetail,
  itinerary,
  adultCount,
  childCount,
  highlightTerms,
  handleTncChange
}) {
  let formGroupClass = classNames('form-group form-group-lg terms-checkbox', {
    'has-error shake-effect': highlightTerms
  });
  return (
    <section className="clearfix total-card-outer">
      <div className="total-card-box">
        <div className="grey-box">
          <p className="meta-text text-center color-grey mbottom-medium fade">
            <span className="bold color-base">
              {itinerary.special ? (
                <span>
                  {itinerary.nights} {itinerary.nights > 1 ? 'nights' : 'night'}{' '}
                  {itinerary.specialTitle} Trail across {itinerary.regionName}
                </span>
              ) : (
                <span>
                  {itinerary.nights} {itinerary.nights > 1 ? 'nights' : 'night'}{' '}
                  in {itinerary.regionName}
                </span>
              )}
            </span>
            {adultsChildrenString(adultCount, childCount)} departing from{' '}
            {itineraryDetail.costingConfiguration.departureCity} on{' '}
            {itineraryDetail.costingConfiguration.departureDate}.
          </p>
          <div className="clearfix fw xs-text-center">
            <p className="fl meta-text bold color-grey mb-0 fade">
              TOTAL COST<span className="fine-text regular">
                Inclusive of all taxes and fees.
              </span>
            </p>
            <strong className="fr regular medium-heading">
              &#8377;{' '}
              {itineraryDetail.paymentSchedule.itineraryTotalCost
                ? itineraryDetail.paymentSchedule.itineraryTotalCost
                : 0}
            </strong>
          </div>
        </div>
        <div className={formGroupClass}>
          <label className="custom-options">
            <input
              onChange={handleTncChange}
              type="checkbox"
              defaultValue="option1"
            />
            <span>
              I have read and understood the{' '}
              <Link to={`/terms-and-conditions`} target="_blank">
                Terms &amp; Conditions
              </Link>
            </span>
            <i />
          </label>
        </div>
      </div>
    </section>
  );
}
