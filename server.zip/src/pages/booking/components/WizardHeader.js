import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import _ from 'lodash';

import {itineraryModalsRouteHelper, routingPageType} from '../../../helpers/routesHelper';

const WizardHeader = ({
  stepTitle,
  countdownTime,
  itineraryId,
  prevStepUrl,
  nextStepUrl,
  nextStepFunc,
  activeTab,
  livePrice,
  itineraryDetails
}) => {
  const disableClick = e => e.preventDefault();

  const inclusionsPagePath = itineraryModalsRouteHelper({
    itineraryId: itineraryDetails.itinerary.itineraryId,
    regionCode: itineraryDetails.itinerary.regionCode,
    parentPage: routingPageType.inclusion
  })

  return (
    <section className="clearfix">
      <div className="mobile-wizard-header with-timer visible-xs">
        {/* countdown timer starts */}
        {activeTab === 2 || activeTab === 3 ? (
          <span className="countdown-timer hide" id={'mobile-timer'}>
            <i className="vehoicon-ion-android-time color-accent-1" />
            <span id={'countdown-timer-span'}>--:--</span>
          </span>
        ) : null}
        {/* countdown timer ends */}
        <p>BOOK YOUR VACATION</p>
        <div className="clearfix pos-r">
          <h4 className="input-text-style">{stepTitle}</h4>
          <div className="arrows">
            <Link className="pull-left" to={prevStepUrl}>
              <i className="vehoicon-arrow_downward rotate-90" />
            </Link>
            {nextStepUrl ? (
              <Link className="pull-right" to={nextStepUrl}>
                <i className="vehoicon-arrow_downward rotate-minus-90" />
              </Link>
            ) : nextStepFunc ? (
              <a className="pull-right" onClick={nextStepFunc}>
                <i className="vehoicon-arrow_downward rotate-minus-90" />
              </a>
            ) : (
              <a className="pull-right disabled">
                <i className="vehoicon-arrow_downward rotate-minus-90" />
              </a>
            )}
          </div>
        </div>
        <ul className="step-lines clearfix list-unstyled mb-0">
          <li className="active">
            <Link to={`/booking-travellers/${itineraryId}`} />
          </li>
          <li className="active">
            <Link to={`/booking-review/${itineraryId}`} />
          </li>
          <li className="active">
            <Link to={`/make-payment/${itineraryId}`} />
          </li>
        </ul>
      </div>
      <div className="clearfix tab-links-secondary bg-grey-secondary hidden-xs">
        <ul className="container list-unstyled mb-0">
          <li className="back-link">
            <Link to={inclusionsPagePath}>Back to itinerary</Link>
          </li>
          <li className={activeTab === 1 ? 'active' : ''}>
            <Link to={`/booking-travellers/${itineraryId}`}>
              1. Passenger Details
            </Link>
          </li>
          <li className={activeTab === 2 ? 'active' : ''}>
            {activeTab === 1 ? (
              <a onClick={disableClick}>2. Review Costs</a>
            ) : (
              <Link to={`/booking-review/${itineraryId}`}>2. Review Costs</Link>
            )}
          </li>
          <li className={activeTab === 3 ? 'active' : ''}>
            {activeTab === 1 || livePrice ? (
              <a onClick={disableClick}>3. Make Payment</a>
            ) : (
              <Link to={`/make-payment/${itineraryId}`}>3. Make Payment</Link>
            )}
          </li>
        </ul>
      </div>
    </section>
  );
};

WizardHeader.propTypes = {
  stepTitle: PropTypes.string.isRequired,
  countdownTime: PropTypes.string,
  itineraryId: PropTypes.string.isRequired,
  prevStepUrl: PropTypes.string.isRequired,
  nextStepUrl: PropTypes.string,
  activeTab: PropTypes.number.isRequired,
  livePrice: PropTypes.bool.isRequired,
  nextStepFunc: PropTypes.func,
  itineraryDetails: PropTypes.object
};

const mapStateToProps = state => {
  if (_.isEmpty(state.app.itineraryInfo)) return {};

  return {
    itineraryDetails: state.app.itineraryInfo.itineraryDetails
  };
};

export default connect(mapStateToProps)(WizardHeader);
