import React, { Component } from 'react';
import classNames from 'classnames';
import Select from 'react-select';
import Cleave from 'cleave.js/react';
import { isEmptyObject, isAlphabetsOnly, isFaqMobile, getImgIXUrl } from '../../../helpers/utilsHelper';
import { AppConfig } from '../../../../src/app-config';
import {
  expiryDateValidation,
  passportValidation,
  childAgeValidation
} from '../../validations';
import moment from 'moment';
import DropDownMenu from '../../../common_components/DropDownMenu';
const { images_cdn_url_s3 } = AppConfig;
class Person extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedPassenger: {},
      showPopover: {},
      noSurname: false,
      showSurnamePopover: false,
      prevName: this.props.surname !== '' ? this.props.surname.prevName : '',
      surname: this.props.surname !== '' ? this.props.surname.surName : '',
      firstFocus: true,
      expiryEleFocused: false
    };
    this.handleFirstFocus = this.handleFirstFocus.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleDropdownSelect = this.handleDropdownSelect.bind(this);
    this.handleSurname = this.handleSurname.bind(this);
    this.handleSurnameData = this.handleSurnameData.bind(this);
    this.setPersonData = this.setPersonData.bind(this);
  }

  componentWillReceiveProps(props) {
    if (
      props.surname.mainKey === this.props.mainKey &&
      props.surname.subKey === this.props.subKey
    ) {
      this.setState({
        surname: props.surname.surName,
        prevName: props.surname.prevName
      });
    }
  }

  setSurName = (e) => {
    e.preventDefault();
    this.setState({
      showSurnamePopover: true
    })
  }

  onCloseSurName = (e) => {
    e.preventDefault(); 
    this.setState({
      showSurnamePopover: false
    })
  }

  confirmSurName = (e) => {
    e.preventDefault(); 
    this.setState({
      showSurnamePopover: false
    })
    this.handleSurname();
  }

  handleBlur = (inputType) => {
    if(['FIRSTNAME','LASTNAME'].includes(inputType))
    this.setState({
      showPopover: {
        [inputType]: false
      }
    })
  }

  handleFirstFocus = (inputType) => {
    if(['FIRSTNAME','LASTNAME'].includes(inputType)) {
      this.setState({
        showPopover: {
          [inputType]: true
        }
      })
    }
    this.setState({ showSurnamePopover: false });
    if (!this.state.firstFocus) {
      if (!(this.props.mainKey === 0 && this.props.subKey === 0)) {
        this.setState({ firstFocus: true });
        let error = this.props.error;
        this.props.dataCatch.map((item, main) => {
          let childcount = 0;
          item.map((data, sub) => {
            error[main][sub]['error'] = [];
            if (!(main === this.props.mainKey && sub >= this.props.subKey)) {
              if (data['firstName'] === '') {
                error[main][sub]['firstName'] = 'error';
                error[main][sub]['error'].push('Please enter your name');
              } else {
                error[main][sub]['firstName'] = '';
                //error[main][sub]['error'].pop('Please enter your name');
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  'Please enter your name'
                );
              }
              if (!this.props.error[main][sub]['noSurname']) {
                if (data['lastName'] === '') {
                  error[main][sub]['lastName'] = 'error';
                  error[main][sub]['error'].push('Please enter your surname ');
                } else {
                  error[main][sub]['lastName'] = '';
                  //error[main][sub]['error'].pop('Please enter your surname');
                  error = this.removeElement(
                    error,
                    main,
                    sub,
                    'Please enter your surname'
                  );
                }
              }

              if (
                data['passportNumber'] === '' ||
                !passportValidation(data['passportNumber'])
              ) {
                error[main][sub]['passportNumber'] = 'error';
                error[main][sub]['error'].push(
                  'Please enter valid Passport Number'
                );
              } else {
                error[main][sub]['passportNumber'] = '';
                //error[main][sub]['error'].pop('Please enter valid Passport Number');
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  'Please enter valid Passport Number'
                );
              }

              if (
                data['passportExpirationDate'] === '' ||
                !expiryDateValidation(
                  data['passportExpirationDate'],
                  this.props.lastDate
                )
              ) {
                error[main][sub]['passportExpirationDate'] = 'error';
                error[main][sub]['error'].push(
                  'Passport expires 6 months before your returning date'
                );
              } else {
                error[main][sub]['passportExpirationDate'] = '';
                //error[main][sub]['error'].pop('Passport expires 6 months before your returning date');
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  'Passport expires 6 months before your returning date'
                );
              }

              if (data['birthDay'] === '') {
                error[main][sub]['birthDay'] = 'error';
                error[main][sub]['error'].push('Date of birth is a mandatory!');
              } else if (moment().diff(data.birthDay, 'years', false) < 14) {
                if (
                  !childAgeValidation(
                    this.props.childAge[childcount],
                    data.birthDay,
                    this.props.lastDate
                  )
                ) {
                  error[main][sub]['birthDay'] = 'error';
                  error[main][sub]['error'].push(
                    "Date of birth doesn't match with the entered child age"
                  );
                } else {
                  error[main][sub]['birthDay'] = '';
                  //error[main][sub]['error'].pop("Date of birth doesn't match with the entered child age");
                  error = this.removeElement(
                    error,
                    main,
                    sub,
                    "Date of birth doesn't match with the entered child age"
                  );
                }
              }
            }
          });
        });
        this.props.validation(error);
      }
    }
  }

  handleDropdownSelect(data, e) {
    e && e.preventDefault();
    let updatedData = this.props.dataCatch;
    (this.props.passengerData || []).map((data, key) => {
      if (data['firstName'] === this.drowDownMenu.props.dropdownText) {
        data['selected'] = false;
      }
    });
    data['selected'] && data['selected'] === true
      ? (data['selected'] = false)
      : (data['selected'] = true);
    this.setState({
      selectedPassenger: data.firstName,
      noSurname: data.lastName.length ? false : true
    });
    
    if (data.firstName === this.state.selectedPassenger) {
      let initialJson = {
        passengerId: '',
        salutation: '',
        firstName: '',
        lastName: '',
        passportNumber: '',
        birthDay: '',
        passportExpirationDate: '',
        passportIssueDate: '',
        passportIssueCity: '',
        passportIssueCountry: ''
      };
      updatedData[this.props.mainKey][this.props.subKey] = Object.assign(
        updatedData[this.props.mainKey][this.props.subKey],
        initialJson
      );
      data['selected'] = false;
      this.setState({ selectedPassenger: {} });
    } else {
      let target = updatedData[this.props.mainKey][this.props.subKey];
      if (target.type === 'child') {
        data.salutation =
          data.salutation.toLowerCase() === 'ms' ? 'Ms' : 'Master';
      }

      // date formats
      data.birthDay = moment(data.birthDay, 'DD/MMM/YYYY').format('DD/MM/YYYY');
      data.passportExpirationDate = moment(
        data.passportExpirationDate,
        'DD/MMM/YYYY'
      ).format('DD/MM/YYYY');

      data.passportIssueDate = moment(
        data.passportIssueDate,
        'DD/MMM/YYYY'
      ).format('DD/MM/YYYY');
      
      
      if(data.lastName.length === 0) {
        const { error } = this.props;
        error[this.props.mainKey][this.props.subKey]['noSurname'] = true;
        updatedData[this.props.mainKey][this.props.subKey]['firstName'] = this.props.surname.prevName;
        data.lastName = '';
        data.lastNameAvailable = false;
        this.props.validation( error );
      }

      updatedData[this.props.mainKey][this.props.subKey] = Object.assign(
        updatedData[this.props.mainKey][this.props.subKey],
        data
      );
    }

    // this.props.handleToggleDropdown(this.props.mainKey, this.props.type);
    this.drowDownMenu && this.drowDownMenu.closeDropDown();
    this.props.handleSelection(updatedData, data.firstName);
  }

  setPersonData = () => {
    let { mainKey, subKey, surname } = this.props;
    let updatedData = this.props.dataCatch;
    updatedData[mainKey][subKey]['lastNameAvailable'] = false;
    if(surname.prevName) updatedData[mainKey][subKey]['firstName'] = surname.prevName;
    updatedData[mainKey][subKey]['lastName'] = '';
    this.props.handleSelection(updatedData);
  }

  handleChange(event) {
    let { mainKey, subKey } = this.props;

    if(['firstName', 'lastName', 'passportIssueCity'].includes(event.name) && event.value.length && !isAlphabetsOnly(event.value)) {
      return false;
    }
    let updatedData = {
      mainKey: mainKey,
      subKey: subKey,
      name: event.name,
      value: event.value
    };
    this.props.handleInput(updatedData);
  }

  handleSurname() {
    let error = this.props.error;
    if (this.state.noSurname) {
      this.setState({ noSurname: false }, () => {
        error[this.props.mainKey][this.props.subKey]['noSurname'] = false;
        this.handleSurnameData();
      });
    } else {
      this.setState({ noSurname: true }, () => {
        error[this.props.mainKey][this.props.subKey]['noSurname'] = true;
        this.setPersonData();
      });
    }
    this.props.validation(error);
  }

  handleSurnameData() {
    let { mainKey, subKey, surname } = this.props;
    let updatedData = this.props.dataCatch;
    updatedData[mainKey][subKey]['lastNameAvailable'] = true;
    if(surname.prevName) updatedData[mainKey][subKey]['firstName'] = surname.prevName;
    updatedData[mainKey][subKey]['lastName'] = '';

    this.props.handleSelection(updatedData);

    // let updatedData = {
    //   mainKey: mainKey,
    //   subKey: subKey,
    //   name: 'firstName',
    //   value: this.state.noSurname
    //     ? this.state.surname
    //     : surname.prevName
    // };
    // this.props.handleInput(updatedData);
  }

  render() {
    // console.log(this.props.passengerData);

    let hasError =
      this.props.error[this.props.mainKey][this.props.subKey]['error'] &&
      this.props.error[this.props.mainKey][this.props.subKey]['error']
        .length !== 0;

    return (
      <div className="clearfix passenger-form-row">
        <section>
          <div className="row name-selection">
            <div className="col-md-10 col-md-push-2 text-center">
              <p className="bold color-grey-secondary mb-0">
                {this.props.type}
              </p>

              <DropDownMenu
                trigger={'click'}
                wrapperClassName={'dropdown'}
                wrapperElement={'div'}
                ref={instance => {
                  this.drowDownMenu = instance;
                }}
                showBackDrop={true}
                dropdownText={
                  !isEmptyObject(this.state.selectedPassenger)
                    ? this.state.selectedPassenger
                    : 'Select'
                }
                triggerElement={
                  <span>
                    <span>
                      {!isEmptyObject(this.state.selectedPassenger)
                        ? this.state.selectedPassenger
                        : 'Select'}
                    </span>{' '}
                    <i className="caret hidden-xs" />
                  </span>
                }
              >
                {this.props.passengerData && this.props.passengerData.length ? (
                  this.props.passengerData &&
                  this.props.passengerData.map((data, key) => {
                    return (
                      <li
                        key={`${data.firstName}_${this.props.mainKey}_${
                          this.props.type
                        }_${key}`}
                        className={
                          data.firstName === this.state.selectedPassenger
                            ? 'active'
                            : data.selected
                              ? 'disabled'
                              : ''
                        }
                      >
                        <a
                          name={data.firstName}
                          onClick={e => {
                            if (
                              data.selected &&
                              data.firstName !== this.state.selectedPassenger
                            ) {
                              e && e.preventDefault();
                            } else this.handleDropdownSelect(data, e);
                          }}
                        >
                          {data.firstName}
                        </a>
                      </li>
                    );
                  })
                ) : (
                  <li>
                    <span className="col-xs-12">
                      You havent added any contacts yet.
                    </span>
                  </li>
                )}
              </DropDownMenu>
              <div
                className={classNames('validation-info', {
                  'show-error-info': hasError
                })}
              >
                <i className="vehoicon-exclamation-circle vinfo-icon" />
                <ul
                  className={classNames('list-unstyled text-left', {
                    'show-error-message': hasError
                  })}
                >
                  <h6>Please fix the following</h6>
                  {hasError
                    ? this.props.error[this.props.mainKey][this.props.subKey][
                        'error'
                      ].map((item, key) => {
                        return (
                          <li>
                            <i className="color-accent-7">&#10008;</i>
                            {item}
                          </li>
                        );
                      })
                    : null}
                </ul>
              </div>
            </div>
          </div>
        </section>
        <div className="row">
          {this.props.type.includes('Adult') ? (
            <div className="col-md-10 col-md-push-2 left-options">
              <span
                className={classNames('form-group', {
                  'has-error':
                    this.props.error[this.props.mainKey][this.props.subKey][
                      'salutation'
                    ] === 'error'
                })}
              >
                <label className="custom-options">
                  <input
                    type="radio"
                    value="Mr"
                    name={`salutation_${this.props.mainKey}_${
                      this.props.subKey
                    }`}
                    onChange={e =>
                      this.handleChange({
                        name: 'salutation',
                        value: e.target.value
                      })
                    }
                    required={true}
                    checked={
                      this.props.info && this.props.info.salutation === 'Mr'
                    }
                    onFocus={this.handleFirstFocus}
                  />
                  <span>Mr.</span>
                  <i />
                </label>
              </span>
              <span
                className={classNames('form-group', {
                  'has-error':
                    this.props.error[this.props.mainKey][this.props.subKey][
                      'salutation'
                    ] === 'error'
                })}
              >
                <label className="custom-options">
                  <input
                    type="radio"
                    value="Ms"
                    name={`salutation_${this.props.mainKey}_${
                      this.props.subKey
                    }`}
                    required={true}
                    checked={
                      this.props.info && this.props.info.salutation === 'Ms'
                    }
                    onChange={e =>
                      this.handleChange({
                        name: 'salutation',
                        value: e.target.value
                      })
                    }
                    onFocus={this.handleFirstFocus}
                  />
                  <span>Ms.</span>
                  <i />
                </label>
              </span>
            </div>
          ) : (
            <div className="col-md-10 col-md-push-2 left-options">
              <span
                className={classNames('form-group', {
                  'has-error':
                    this.props.error[this.props.mainKey][this.props.subKey][
                      'salutation'
                    ] === 'error'
                })}
              >
                <label className="custom-options">
                  <input
                    type="radio"
                    value="Master"
                    name={`salutation_${this.props.mainKey}_${
                      this.props.subKey
                    }`}
                    required={true}
                    checked={
                      this.props.info && this.props.info.salutation === 'Master'
                    }
                    onChange={e =>
                      this.handleChange({
                        name: 'salutation',
                        value: e.target.value
                      })
                    }
                    onFocus={this.handleFirstFocus}
                  />
                  <span>Master.</span>
                  <i />
                </label>
              </span>
              <span
                className={classNames('form-group', {
                  'has-error':
                    this.props.error[this.props.mainKey][this.props.subKey][
                      'salutation'
                    ] === 'error'
                })}
              >
                <label className="custom-options">
                  <input
                    type="radio"
                    value="Ms"
                    name={`salutation_${this.props.mainKey}_${
                      this.props.subKey
                    }`}
                    required={true}
                    checked={
                      this.props.info &&
                      (this.props.info.salutation === 'Miss' ||
                        this.props.info.salutation === 'Ms')
                    }
                    onChange={e =>
                      this.handleChange({
                        name: 'salutation',
                        value: e.target.value
                      })
                    }
                    onFocus={this.handleFirstFocus}
                  />
                  <span>Miss.</span>
                  <i />
                </label>
              </span>
            </div>
          )}
          <div className="col-md-10 col-md-push-2 right-frm">
            <div className="row">
              <div className="col-sm-6">
                <div
                  className={
                    'form-group form-group-lg ' +
                    (this.props.error[this.props.mainKey][this.props.subKey][
                      'firstName'
                    ] === 'error'
                      ? 'has-error'
                      : ' ')
                  }
                >
                  <div className="label-animative">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Give Name"
                      name={`firstName_${this.props.mainKey}_${
                        this.props.subKey
                      }`}
                      autoComplete={'nope'}
                      required={true}
                      value={this.props.info['firstName']}
                      onChange={e =>
                        this.handleChange({
                          name: 'firstName',
                          value: e.target.value
                        })
                      }
                      onFocus={() => this.handleFirstFocus('FIRSTNAME')}
                      onBlur={() => this.handleBlur('FIRSTNAME')}
                    />
                    <label className="control-label">Given Name</label>
                    <i className="label-bg" />

                    <div 
                      className= {classNames('popover', isFaqMobile() ? 'top' : 'bottom')} 
                      style={{ display: this.state.showPopover.FIRSTNAME ? 'block' : 'none' }} 
                    >
                      <div className="arrow" />
                      <div className="popover-content">
                        <img 
                          src={getImgIXUrl(`${images_cdn_url_s3}passenger_details/given-name.png`)}
                          alt="given name" 
                        />
                      </div>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="col-sm-6">
                <div
                  className={
                    'form-group form-group-lg ' +
                    (this.state.noSurname ? 'hide ' : ' ') +
                    (this.props.error[this.props.mainKey][this.props.subKey][
                      'lastName'
                    ] === 'error'
                      ? 'has-error'
                      : ' ')
                  }
                >
                  <div className="clearfix label-animative input-link">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Surname"
                      autoComplete={'nope'}
                      name={`lastName_${this.props.mainKey}_${
                        this.props.subKey
                      }`}
                      required={true}
                      value={
                        this.props.dataCatch.length !== 0 &&
                        this.props.info['lastName']
                      }
                      onChange={e =>
                        this.handleChange({
                          name: 'lastName',
                          value: e.target.value
                        })
                      }
                      onBlur={event => {
                        this.handleBlur('LASTNAME');
                        if (event.target.value.length === 1) {
                          event.preventDefault();
                          this.props.history.push(
                            `${this.props.history.location.pathname}/${this
                              .props.mainKey /
                              this.props.subKey /
                              this.props.info['firstanme']}`
                          );
                        }
                      }}
                      onFocus={() => this.handleFirstFocus('LASTNAME')}
                    />
                    <label className="control-label">Surname</label>
                    <i className="label-bg" />
                    <span
                      className="cursor-pointer btn btn-link-grey"
                      onClick={e => this.setSurName(e)}
                    >
                      No Surname?
                    </span>
                    <div 
                      className= {classNames('popover', isFaqMobile() ? 'top' : 'bottom')}
                      style={{ display: this.state.showPopover.LASTNAME ? 'block' : 'none' }}
                    >
                      <div className="arrow" />
                      <div className="popover-content">
                        <img  
                          src={getImgIXUrl(`${images_cdn_url_s3}passenger_details/surname.png`)}
                          alt="surname" 
                        />
                      </div>
                    </div>

                    <div 
                      className= {classNames('popover no-surname', isFaqMobile() ? 'top' : 'right')} 
                      style={{ display: this.state.showSurnamePopover ? 'block' : 'none' }}
                    >
                      <div className="arrow" />
                      <div className="popover-content">
                        <p className="meta-text mbottom-small color-black">
                          <span>Confirm 'No Surname'</span>
                          There’s no standard method airlines follow for ‘No Surname’ cases. All you need to do is confirm the fact and we’ll handle it for you.
                        </p>
                        <div className="text-right">
                          <a 
                            class="cursor-pointer meta-text semi-bold cancel-link"
                            onClick={e => this.onCloseSurName(e)} 
                          >Cancel</a>
                          &nbsp;&nbsp;&nbsp;
                          <a 
                            class="cursor-pointer meta-text semi-bold"
                            onClick={e => this.confirmSurName(e)} 
                          >Confirm</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {this.state.noSurname ? (
                  <div className="form-group form-group-lg">
                    <div className="auto-filled with-icon-secondary">
                      <span>Surname</span>
                      <p>Auto Filled</p>
                      <i
                        className="vehoicon-close"
                        onClick={this.handleSurname}
                      />
                    </div>
                  </div>
                ) : (
                  ' '
                )}
              </div>
            </div>

            <div className="row">
              <div className="col-xs-6 col-sm-4">
                <div
                  className={
                    'form-group form-group-lg ' +
                    (this.props.error[this.props.mainKey][this.props.subKey][
                      'passportNumber'
                    ] === 'error'
                      ? 'has-error'
                      : ' ')
                  }
                >
                  <div className="label-animative">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Passport Number"
                      name={`passportNumber_${this.props.mainKey}_${
                        this.props.subKey
                      }`}
                      autoComplete={'passportNumber'}
                      required={true}
                      value={
                        this.props.dataCatch.length !== 0 &&
                        this.props.info['passportNumber']
                      }
                      onChange={e =>
                        this.handleChange({
                          name: 'passportNumber',
                          value: e.target.value
                        })
                      }
                      onFocus={this.handleFirstFocus}
                    />
                    <label className="control-label">Passport Number</label>
                    <i className="label-bg" />
                  </div>
                </div>
              </div>
              <div className="col-xs-6 col-sm-4">
                <div
                  className={
                    'form-group form-group-lg ' +
                    (this.props.error[this.props.mainKey][this.props.subKey][
                      'passportExpirationDate'
                    ] === 'error'
                      ? 'has-error'
                      : ' ')
                  }
                >
                  <div className="label-animative">
                    <Cleave
                      className="form-control"
                      placeholder="dd/mm/yyyy"
                      required={true}
                      inputMode="numeric"
                      options={{
                        date: true,
                        datePattern: ['d', 'm', 'Y']
                      }}
                      name={`passportExpirationDate_${this.props.mainKey}_${
                        this.props.subKey
                      }`}
                      autoComplete={'passportExpirationDate'}
                      value={
                        this.props.dataCatch.length !== 0 &&
                        this.props.info['passportExpirationDate']
                      }
                      onChange={e =>
                        this.handleChange({
                          name: 'passportExpirationDate',
                          value: e.target.value
                        })
                      }
                      onFocus={e =>
                        setTimeout(
                          () => this.setState({ expiryEleFocused: true, showSurnamePopover: false }),
                          200
                        )
                      }
                      onBlur={e => this.setState({ expiryEleFocused: false })}
                    />
                    <label className="control-label">
                      Passport Expires{' '}
                      {this.state.expiryEleFocused ? '(DD/MM/YYYY)' : null}
                    </label>
                    <i className="label-bg" />
                  </div>
                </div>
              </div>
              <div className="col-xs-12 col-sm-4">
                <div
                  className={
                    'form-group form-group-lg ' +
                    (this.props.error[this.props.mainKey][this.props.subKey][
                      'birthDay'
                    ] === 'error'
                      ? 'has-error'
                      : ' ')
                  }
                >
                  <div className="label-animative">
                    <Cleave
                      className="form-control"
                      placeholder="dd/mm/yyyy"
                      required={true}
                      inputMode="numeric"
                      options={{
                        date: true,
                        datePattern: ['d', 'm', 'Y']
                      }}
                      name={`birthDay_${this.props.mainKey}_${
                        this.props.subKey
                      }`}
                      autoComplete={'birthDay'}
                      value={
                        this.props.dataCatch.length !== 0 &&
                        this.props.info['birthDay']
                      }
                      onChange={e =>
                        this.handleChange({
                          name: 'birthDay',
                          value: e.target.value
                        })
                      }
                      // onBlur={e => {
                      //   if (this.props.type.includes('Child')) {
                      //     let age = Number(
                      //       this.props.type.replace('Child', '')
                      //     );
                      //     console.log("child age ",this.props.type.replace("Child",""))
                      //     childAgeValidation(
                      //       this.props.childAge[age - 1],
                      //       e.target.value,
                      //       this.props.lastDate
                      //     );
                      //   }
                      // }}
                      // onFocus={this.handleFirstFocus}
                      onFocus={e =>
                        setTimeout(
                          () => this.setState({ dobEleFocused: true, showSurnamePopover: false }),
                          200
                        )
                      }
                      onBlur={e => this.setState({ dobEleFocused: false })}
                    />
                    <label className="control-label">
                      Date of birth{' '}
                      {this.state.dobEleFocused ? '(DD/MM/YYYY)' : null}
                    </label>
                    <i className="label-bg" />
                  </div>
                </div>
              </div>
            </div>
            {this.props.isPytonIncluded ? (
              <div className="row">
                <div className="col-xs-6 col-sm-4">
                  <div
                    className={
                      'form-group form-group-lg ' +
                      (this.props.error[this.props.mainKey][this.props.subKey][
                        'passportIssueDate'
                      ] === 'error'
                        ? 'has-error'
                        : ' ')
                    }
                  >
                    <div className="label-animative">
                      <Cleave
                        className="form-control"
                        placeholder="dd/mm/yyyy"
                        required={true}
                        options={{
                          date: true,
                          datePattern: ['d', 'm', 'Y']
                        }}
                        name={`passportIssueDate_${this.props.mainKey}_${
                          this.props.subKey
                        }`}
                        autoComplete={'passportIssueDate'}
                        value={
                          this.props.dataCatch.length !== 0 &&
                          (this.props.info['passportIssueDate'] || '')
                        }
                        onChange={e =>
                          this.handleChange({
                            name: 'passportIssueDate',
                            value: e.target.value
                          })
                        }
                        onFocus={e =>
                          setTimeout(
                            () =>
                              this.setState({ passportIssueDateFocused: true }),
                            200
                          )
                        }
                        onBlur={e =>
                          this.setState({ passportIssueDateFocused: false })
                        }
                      />
                      <label className="control-label">
                        Passport Issue Date{' '}
                        {this.state.passportIssueDateFocused
                          ? '(DD/MM/YYYY)'
                          : null}
                      </label>
                      <i className="label-bg" />
                    </div>
                  </div>
                </div>

                <div className="col-xs-6 col-sm-4">
                  <div
                    className={
                      'form-group form-group-lg ' +
                      (this.props.error[this.props.mainKey][this.props.subKey][
                        'passportIssueCity'
                      ] === 'error'
                        ? 'has-error'
                        : ' ')
                    }
                  >
                    <div className="label-animative">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Passport Issue City"
                        name={`passportIssueCity_${this.props.mainKey}_${
                          this.props.subKey
                        }`}
                        autoComplete={'passportIssueCity'}
                        required={true}
                        value={this.props.info['passportIssueCity'] || ''}
                        onChange={e =>
                          this.handleChange({
                            name: 'passportIssueCity',
                            value: e.target.value
                          })
                        }
                        onFocus={this.handleFirstFocus}
                      />
                      <label className="control-label">
                        Passport Issue City
                      </label>
                      <i className="label-bg" />
                    </div>
                  </div>
                </div>

                <div className="col-xs-12 col-sm-4">
                  <div
                    className={
                      'select-form-group form-group form-group-lg ' +
                      (this.props.error[this.props.mainKey][this.props.subKey][
                        'passportIssueCountry'
                      ] === 'error'
                        ? 'has-error'
                        : ' ')
                    }
                  >
                    <Select
                      className={'form-control no-padding'}
                      name={`passportIssueCountry_${this.props.mainKey}_${
                        this.props.subKey
                      }`}
                      clearable={false}
                      placeholder={'Passport Issue Country'}
                      value={this.props.info['passportIssueCountry'] || ''}
                      options={this.props.allSuggestions}
                      labelKey={'countryName'}
                      valueKey={'countryCode'}
                      onChange={e =>
                        this.handleChange({
                          name: 'passportIssueCountry',
                          value: e.countryCode
                        })
                      }
                      menuShouldScrollIntoView={false}
                    />
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    );
  }
}

export default Person;
