import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { setSurnameDetails } from '../../../actions/actions_app';
import {
  decodeActivityKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../../helpers/utilsHelper';

class SurnameModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      surname: ''
    };
    this.openModal = this.openModal.bind(this);
    this.onFillSurname = this.onFillSurname.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  componentDidMount() {
    this.openModal();

    this.setState(
      {
        mainKey: this.props.match.params.mainKey,
        subKey: this.props.match.params.subKey,
        prevName: this.props.match.params.prevName,
        surname: this.props.match.params.prevName,
        noSurname: true
      },
      () => {
        // console.log('person props', this.state);
      }
    );

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    // this.setState(
    //   {
    //     mainKey: props.surname.mainKey,
    //     subKey: props.surname.subKey,
    //     prevName: this.props.match.params.prevName,
    //     surname: this.props.match.params.prevName,
    //     noSurname: true
    //   },
    //   () => {
    //     console.log('person props', this.state);
    //   }
    // );
  }

  openModal() {
    this.setState({ showModal: true, deleteActivity: false }, () => {
      onceModalOpened();
    });
  }

  closeModal() {
    let { history } = this.props;

    // let { activeActivity } = this.props;
    // let ele = this.refs.modal;
    // $(ele).addClass('out');

    setTimeout(() => {
      this.setState({ showModal: false, deleteActivity: false }, () => {
        onceModalClosed();

        history.goBack();
      });
    }, 400);
  }

  onFillSurname(event) {
    this.setState({ surname: event.target.value });
  }

  handleClick(e) {
    e && e.preventDefault();
    let { mainKey } = this.props.match.params;
    let { subKey } = this.props.match.params;
    let { prevName } = this.props.match.params;

    this.props.actions.setSurnameDetails({
      mainKey,
      subKey,
      prevName,
      surName: this.state.surname
    });
    this.closeModal();
  }

  render() {
    let { match } = this.props;
    let { prevName } = match;
    return (
      <div className="modal-open">
        <div
          className={
            'modal fade mini-modal ' + (this.state.showModal ? 'in' : '')
          }
          tabIndex="-1"
        >
          <div className="modal-dialog">
            <div className="modal-content with-header">
              <div className="modal-header">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  onClick={this.closeModal}
                >
                  <i className="vehoicon-close" />
                </button>
              </div>

              <div className="modal-body">
                <div className="row">
                  <div className="col-md-12">
                    <h5 className="large-heading bold no-margin">
                      No surname?
                    </h5>
                    <p className="main-para color-grey-secondary vmargin-medium">
                      Airlines require an appropriate input even if the
                      traveller does not have a surname on the passport records.
                      Since different airlines have different policies, let us
                      handle this for you!{' '}
                    </p>
                    <form action="#">
                      <div className="form-group form-group-lg">
                        <input
                          type="text"
                          className="form-control"
                          placeholder="Confirm your given name"
                          onChange={this.onFillSurname}
                          value={this.state.surname}
                        />
                      </div>
                      <div className="form-group">
                        <button
                          type="submit"
                          className="btn btn-primary btn-block btn-lg"
                          onClick={this.handleClick}
                        >
                          Auto-fill my surname!
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="modal-backdrop fade in" />
      </div>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (app.surname && Object.keys(app.surname).length) {
    return {
      surname: app.surname
    };
  } else {
    return {
      surname: {}
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      setSurnameDetails: bindActionCreators(setSurnameDetails, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(SurnameModal);
