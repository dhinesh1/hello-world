import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Sticky from 'react-stickynode';
import classNames from 'classnames';

import {
  expiryDateValidation,
  issueDateValidation,
  passportValidation,
  childAgeValidation,
  adultAgeValidation,
  dateValidation
} from '../validations';
import moment from 'moment';
import SweetAlert from 'sweetalert-react';
import _ from 'lodash';

import {
  getItinerary,
  getUserProfileDetails,
  savePassengers,
  dissolvePassengersSaved,
  resetFetchedPassengersList
} from '../../actions/actions_app';
import {
  isEmptyObject,
  isMobile,
  hideChatIconOnMobile,
  getExactDate,
  isValidName
} from '../../helpers/utilsHelper';
import {itineraryModalsRouteHelper, routingPageType} from '../../helpers/routesHelper';

import Person from './components/person';
import WizardHeader from './components/WizardHeader';
import { Link, Route, Switch } from 'react-router-dom';
import { SurnameModalLoadable } from '../../helpers/loadbleComponentsHelper';
import { trackEvent, EVENT_PAX_FILLED } from '../../helpers/ML/EventsTracker';

const allSuggestions = [
  { countryCode: 'AD', countryName: 'Andorra' },
  { countryCode: 'AE', countryName: 'United Arab Emirates' },
  { countryCode: 'AF', countryName: 'Afghanistan' },
  { countryCode: 'AG', countryName: 'Antigua and Barbuda' },
  { countryCode: 'AI', countryName: 'Anguilla' },
  { countryCode: 'AL', countryName: 'Albania' },
  { countryCode: 'AM', countryName: 'Armenia' },
  { countryCode: 'AN', countryName: 'Netherlands Antilles' },
  { countryCode: 'AO', countryName: 'Angola' },
  { countryCode: 'AQ', countryName: 'Antarctica' },
  { countryCode: 'AR', countryName: 'Argentina' },
  { countryCode: 'AS', countryName: 'American Samoa' },
  { countryCode: 'AT', countryName: 'Austria' },
  { countryCode: 'AU', countryName: 'Australia' },
  { countryCode: 'AW', countryName: 'Aruba' },
  { countryCode: 'AX', countryName: 'Åland Islands' },
  { countryCode: 'AZ', countryName: 'Azerbaijan' },
  { countryCode: 'BA', countryName: 'Bosnia and Herzegovina' },
  { countryCode: 'BB', countryName: 'Barbados' },
  { countryCode: 'BD', countryName: 'Bangladesh' },
  { countryCode: 'BE', countryName: 'Belgium' },
  { countryCode: 'BF', countryName: 'Burkina Faso' },
  { countryCode: 'BG', countryName: 'Bulgaria' },
  { countryCode: 'BH', countryName: 'Bahrain' },
  { countryCode: 'BI', countryName: 'Burundi' },
  { countryCode: 'BJ', countryName: 'Benin' },
  { countryCode: 'BL', countryName: 'Saint Barthélemy' },
  { countryCode: 'BM', countryName: 'Bermuda' },
  { countryCode: 'BN', countryName: 'Brunei' },
  { countryCode: 'BO', countryName: 'Bolivia' },
  { countryCode: 'BQ', countryName: 'Bonaire, Sint Eustatius and Saba' },
  { countryCode: 'BR', countryName: 'Brazil' },
  { countryCode: 'BS', countryName: 'Bahamas' },
  { countryCode: 'BT', countryName: 'Bhutan' },
  { countryCode: 'BV', countryName: 'Bouvet Island' },
  { countryCode: 'BW', countryName: 'Botswana' },
  { countryCode: 'BY', countryName: 'Belarus' },
  { countryCode: 'BZ', countryName: 'Belize' },
  { countryCode: 'CA', countryName: 'Canada' },
  { countryCode: 'CC', countryName: 'Cocos Islands' },
  { countryCode: 'CD', countryName: 'The Democratic Republic Of Congo' },
  { countryCode: 'CF', countryName: 'Central African Republic' },
  { countryCode: 'CG', countryName: 'Congo' },
  { countryCode: 'CH', countryName: 'Switzerland' },
  { countryCode: 'CI', countryName: "Côte d'Ivoire" },
  { countryCode: 'CK', countryName: 'Cook Islands' },
  { countryCode: 'CL', countryName: 'Chile' },
  { countryCode: 'CM', countryName: 'Cameroon' },
  { countryCode: 'CN', countryName: 'China' },
  { countryCode: 'CO', countryName: 'Colombia' },
  { countryCode: 'CR', countryName: 'Costa Rica' },
  { countryCode: 'CU', countryName: 'Cuba' },
  { countryCode: 'CV', countryName: 'Cape Verde' },
  { countryCode: 'CW', countryName: 'Curaçao' },
  { countryCode: 'CX', countryName: 'Christmas Island' },
  { countryCode: 'CY', countryName: 'Cyprus' },
  { countryCode: 'CZ', countryName: 'Czech Republic' },
  { countryCode: 'DE', countryName: 'Germany' },
  { countryCode: 'DJ', countryName: 'Djibouti' },
  { countryCode: 'DK', countryName: 'Denmark' },
  { countryCode: 'DM', countryName: 'Dominica' },
  { countryCode: 'DO', countryName: 'Dominican Republic' },
  { countryCode: 'DZ', countryName: 'Algeria' },
  { countryCode: 'EC', countryName: 'Ecuador' },
  { countryCode: 'EE', countryName: 'Estonia' },
  { countryCode: 'EG', countryName: 'Egypt' },
  { countryCode: 'EH', countryName: 'Western Sahara' },
  { countryCode: 'ER', countryName: 'Eritrea' },
  { countryCode: 'ES', countryName: 'Spain' },
  { countryCode: 'ET', countryName: 'Ethiopia' },
  { countryCode: 'FI', countryName: 'Finland' },
  { countryCode: 'FJ', countryName: 'Fiji' },
  { countryCode: 'FK', countryName: 'Falkland Islands' },
  { countryCode: 'FM', countryName: 'Micronesia' },
  { countryCode: 'FO', countryName: 'Faroe Islands' },
  { countryCode: 'FR', countryName: 'France' },
  { countryCode: 'GA', countryName: 'Gabon' },
  { countryCode: 'GB', countryName: 'United Kingdom' },
  { countryCode: 'GD', countryName: 'Grenada' },
  { countryCode: 'GE', countryName: 'Georgia' },
  { countryCode: 'GF', countryName: 'French Guiana' },
  { countryCode: 'GG', countryName: 'Guernsey' },
  { countryCode: 'GH', countryName: 'Ghana' },
  { countryCode: 'GI', countryName: 'Gibraltar' },
  { countryCode: 'GL', countryName: 'Greenland' },
  { countryCode: 'GM', countryName: 'Gambia' },
  { countryCode: 'GN', countryName: 'Guinea' },
  { countryCode: 'GP', countryName: 'Guadeloupe' },
  { countryCode: 'GQ', countryName: 'Equatorial Guinea' },
  { countryCode: 'GR', countryName: 'Greece' },
  {
    countryCode: 'GS',
    countryName: 'South Georgia And The South Sandwich Islands'
  },
  { countryCode: 'GT', countryName: 'Guatemala' },
  { countryCode: 'GU', countryName: 'Guam' },
  { countryCode: 'GW', countryName: 'Guinea-Bissau' },
  { countryCode: 'GY', countryName: 'Guyana' },
  { countryCode: 'HK', countryName: 'Hong Kong' },
  { countryCode: 'HM', countryName: 'Heard Island And McDonald Islands' },
  { countryCode: 'HN', countryName: 'Honduras' },
  { countryCode: 'HR', countryName: 'Croatia' },
  { countryCode: 'HT', countryName: 'Haiti' },
  { countryCode: 'HU', countryName: 'Hungary' },
  { countryCode: 'ID', countryName: 'Indonesia' },
  { countryCode: 'IE', countryName: 'Ireland' },
  { countryCode: 'IL', countryName: 'Israel' },
  { countryCode: 'IM', countryName: 'Isle Of Man' },
  { countryCode: 'IN', countryName: 'India' },
  { countryCode: 'IO', countryName: 'British Indian Ocean Territory' },
  { countryCode: 'IQ', countryName: 'Iraq' },
  { countryCode: 'IR', countryName: 'Iran' },
  { countryCode: 'IS', countryName: 'Iceland' },
  { countryCode: 'IT', countryName: 'Italy' },
  { countryCode: 'JE', countryName: 'Jersey' },
  { countryCode: 'JM', countryName: 'Jamaica' },
  { countryCode: 'JO', countryName: 'Jordan' },
  { countryCode: 'JP', countryName: 'Japan' },
  { countryCode: 'KE', countryName: 'Kenya' },
  { countryCode: 'KG', countryName: 'Kyrgyzstan' },
  { countryCode: 'KH', countryName: 'Cambodia' },
  { countryCode: 'KI', countryName: 'Kiribati' },
  { countryCode: 'KM', countryName: 'Comoros' },
  { countryCode: 'KN', countryName: 'Saint Kitts And Nevis' },
  { countryCode: 'KP', countryName: 'North Korea' },
  { countryCode: 'KR', countryName: 'South Korea' },
  { countryCode: 'KW', countryName: 'Kuwait' },
  { countryCode: 'KY', countryName: 'Cayman Islands' },
  { countryCode: 'KZ', countryName: 'Kazakhstan' },
  { countryCode: 'LA', countryName: 'Laos' },
  { countryCode: 'LB', countryName: 'Lebanon' },
  { countryCode: 'LC', countryName: 'Saint Lucia' },
  { countryCode: 'LI', countryName: 'Liechtenstein' },
  { countryCode: 'LK', countryName: 'Sri Lanka' },
  { countryCode: 'LR', countryName: 'Liberia' },
  { countryCode: 'LS', countryName: 'Lesotho' },
  { countryCode: 'LT', countryName: 'Lithuania' },
  { countryCode: 'LU', countryName: 'Luxembourg' },
  { countryCode: 'LV', countryName: 'Latvia' },
  { countryCode: 'LY', countryName: 'Libya' },
  { countryCode: 'MA', countryName: 'Morocco' },
  { countryCode: 'MC', countryName: 'Monaco' },
  { countryCode: 'MD', countryName: 'Moldova' },
  { countryCode: 'ME', countryName: 'Montenegro' },
  { countryCode: 'MF', countryName: 'Saint Martin' },
  { countryCode: 'MG', countryName: 'Madagascar' },
  { countryCode: 'MH', countryName: 'Marshall Islands' },
  { countryCode: 'MK', countryName: 'Macedonia' },
  { countryCode: 'ML', countryName: 'Mali' },
  { countryCode: 'MM', countryName: 'Myanmar' },
  { countryCode: 'MN', countryName: 'Mongolia' },
  { countryCode: 'MO', countryName: 'Macao' },
  { countryCode: 'MP', countryName: 'Northern Mariana Islands' },
  { countryCode: 'MQ', countryName: 'Martinique' },
  { countryCode: 'MR', countryName: 'Mauritania' },
  { countryCode: 'MS', countryName: 'Montserrat' },
  { countryCode: 'MT', countryName: 'Malta' },
  { countryCode: 'MU', countryName: 'Mauritius' },
  { countryCode: 'MV', countryName: 'Maldives' },
  { countryCode: 'MW', countryName: 'Malawi' },
  { countryCode: 'MX', countryName: 'Mexico' },
  { countryCode: 'MY', countryName: 'Malaysia' },
  { countryCode: 'MZ', countryName: 'Mozambique' },
  { countryCode: 'NA', countryName: 'Namibia' },
  { countryCode: 'NC', countryName: 'New Caledonia' },
  { countryCode: 'NE', countryName: 'Niger' },
  { countryCode: 'NF', countryName: 'Norfolk Island' },
  { countryCode: 'NG', countryName: 'Nigeria' },
  { countryCode: 'NI', countryName: 'Nicaragua' },
  { countryCode: 'NL', countryName: 'Netherlands' },
  { countryCode: 'NO', countryName: 'Norway' },
  { countryCode: 'NP', countryName: 'Nepal' },
  { countryCode: 'NR', countryName: 'Nauru' },
  { countryCode: 'NU', countryName: 'Niue' },
  { countryCode: 'NZ', countryName: 'New Zealand' },
  { countryCode: 'OM', countryName: 'Oman' },
  { countryCode: 'PA', countryName: 'Panama' },
  { countryCode: 'PE', countryName: 'Peru' },
  { countryCode: 'PF', countryName: 'French Polynesia' },
  { countryCode: 'PG', countryName: 'Papua New Guinea' },
  { countryCode: 'PH', countryName: 'Philippines' },
  { countryCode: 'PK', countryName: 'Pakistan' },
  { countryCode: 'PL', countryName: 'Poland' },
  { countryCode: 'PM', countryName: 'Saint Pierre And Miquelon' },
  { countryCode: 'PN', countryName: 'Pitcairn' },
  { countryCode: 'PR', countryName: 'Puerto Rico' },
  { countryCode: 'PS', countryName: 'Palestine' },
  { countryCode: 'PT', countryName: 'Portugal' },
  { countryCode: 'PW', countryName: 'Palau' },
  { countryCode: 'PY', countryName: 'Paraguay' },
  { countryCode: 'QA', countryName: 'Qatar' },
  { countryCode: 'RE', countryName: 'Reunion' },
  { countryCode: 'RO', countryName: 'Romania' },
  { countryCode: 'RS', countryName: 'Serbia' },
  { countryCode: 'RU', countryName: 'Russia' },
  { countryCode: 'RW', countryName: 'Rwanda' },
  { countryCode: 'SA', countryName: 'Saudi Arabia' },
  { countryCode: 'SB', countryName: 'Solomon Islands' },
  { countryCode: 'SC', countryName: 'Seychelles' },
  { countryCode: 'SD', countryName: 'Sudan' },
  { countryCode: 'SE', countryName: 'Sweden' },
  { countryCode: 'SG', countryName: 'Singapore' },
  { countryCode: 'SH', countryName: 'Saint Helena' },
  { countryCode: 'SI', countryName: 'Slovenia' },
  { countryCode: 'SJ', countryName: 'Svalbard And Jan Mayen' },
  { countryCode: 'SK', countryName: 'Slovakia' },
  { countryCode: 'SL', countryName: 'Sierra Leone' },
  { countryCode: 'SM', countryName: 'San Marino' },
  { countryCode: 'SN', countryName: 'Senegal' },
  { countryCode: 'SO', countryName: 'Somalia' },
  { countryCode: 'SR', countryName: 'Suriname' },
  { countryCode: 'SS', countryName: 'South Sudan' },
  { countryCode: 'ST', countryName: 'Sao Tome And Principe' },
  { countryCode: 'SV', countryName: 'El Salvador' },
  { countryCode: 'SX', countryName: 'Sint Maarten (Dutch part)' },
  { countryCode: 'SY', countryName: 'Syria' },
  { countryCode: 'SZ', countryName: 'Swaziland' },
  { countryCode: 'TC', countryName: 'Turks And Caicos Islands' },
  { countryCode: 'TD', countryName: 'Chad' },
  { countryCode: 'TF', countryName: 'French Southern Territories' },
  { countryCode: 'TG', countryName: 'Togo' },
  { countryCode: 'TH', countryName: 'Thailand' },
  { countryCode: 'TJ', countryName: 'Tajikistan' },
  { countryCode: 'TK', countryName: 'Tokelau' },
  { countryCode: 'TL', countryName: 'Timor-Leste' },
  { countryCode: 'TM', countryName: 'Turkmenistan' },
  { countryCode: 'TN', countryName: 'Tunisia' },
  { countryCode: 'TO', countryName: 'Tonga' },
  { countryCode: 'TR', countryName: 'Turkey' },
  { countryCode: 'TT', countryName: 'Trinidad and Tobago' },
  { countryCode: 'TV', countryName: 'Tuvalu' },
  { countryCode: 'TW', countryName: 'Taiwan' },
  { countryCode: 'TZ', countryName: 'Tanzania' },
  { countryCode: 'UA', countryName: 'Ukraine' },
  { countryCode: 'UG', countryName: 'Uganda' },
  { countryCode: 'UM', countryName: 'United States Minor Outlying Islands' },
  { countryCode: 'US', countryName: 'United States' },
  { countryCode: 'UY', countryName: 'Uruguay' },
  { countryCode: 'UZ', countryName: 'Uzbekistan' },
  { countryCode: 'VA', countryName: 'Vatican' },
  { countryCode: 'VC', countryName: 'Saint Vincent And The Grenadines' },
  { countryCode: 'VE', countryName: 'Venezuela' },
  { countryCode: 'VG', countryName: 'British Virgin Islands' },
  { countryCode: 'VI', countryName: 'U.S. Virgin Islands' },
  { countryCode: 'VN', countryName: 'Vietnam' },
  { countryCode: 'VU', countryName: 'Vanuatu' },
  { countryCode: 'WF', countryName: 'Wallis And Futuna' },
  { countryCode: 'WS', countryName: 'Samoa' },
  { countryCode: 'YE', countryName: 'Yemen' },
  { countryCode: 'YT', countryName: 'Mayotte' },
  { countryCode: 'ZA', countryName: 'South Africa' },
  { countryCode: 'ZM', countryName: 'Zambia' },
  { countryCode: 'ZW', countryName: 'Zimbabwe' }
];
class BookingPassengers extends Component {
  constructor(props) {
    super(props);

    this.state = {
      sample: [
        { adultCount: 2, childAges: [1, 2] },
        { adultCount: 1, childAges: [2] }
      ],
      data: [],
      profileDetails: [],
      selectedDropdown: '',
      selectedList: [],
      hotelConfiguration: [],
      surname: {},
      error: [],
      showAlert: false,
      formSubmitted: false,
      isLoading: false,
      adults: null,
      userProfileFetched: false
    };

    this.handleInput = this.handleInput.bind(this);
    this.handleSelection = this.handleSelection.bind(this);
    this.segregatePassengers = this.segregatePassengers.bind(this);
    this.setPassengerDetails = this.setPassengerDetails.bind(this);
    this.handleToggleDropdown = this.handleToggleDropdown.bind(this);
    this.validation = this.validation.bind(this);
    this.handleValidation = this.handleValidation.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);    
    this.getDatesFormatted = this.getDatesFormatted.bind(this);
  }

  componentDidMount() {
    hideChatIconOnMobile();
    let { itineraryId } = this.props.match.params;

    if (isEmptyObject(this.props.itineraryInfo)) {
      this.props.actions.getItinerary(itineraryId);
    } else this.setPassengerDetails(this.props.itineraryInfo);
  }

  componentDidUpdate() {
    let props = this.props;

    if (props.user_details && props.user_details.loggedIn) {
      // console.log('Logged in user block');
      if (isEmptyObject(props.user_profile_details)) {
        // console.log('User profile details is empty');
        if (!this.state.userProfileFetched) {
          // console.log('User profile not fetched');
          this.setState({ userProfileFetched: true }, () => {
            this.props.actions.getUserProfileDetails({
              itineraryId: props.match.params.itineraryId,
              userType: props.user_details.userType
            });
          });
        }
      } else if (!this.state.adults) {
        // console.log('User profile details is not empty');
        if (props.user_details.userType === 'ADMIN') {
          this.props.actions
            .getUserProfileDetails({
              itineraryId: props.match.params.itineraryId,
              userType: props.user_details.userType
            })
            .then(() => {
              this.segregatePassengers(props.user_profile_details);
            });
        } else {
          this.segregatePassengers(props.user_profile_details.passengers);
        }
      }
    }
  }

  componentWillReceiveProps(props) {
    if (props.user_details && !isEmptyObject(props.user_details)) {
      if (!props.user_details.loggedIn) {
        this.props.history.push('/login');
      }
    }

    if (!isEmptyObject(props.surname)) {
      let { surname } = props;
      let t = this.state;
      t.data[surname.mainKey][surname.subKey]['firstName'] = surname.surName;
      t.surname = surname;
      this.setState(t);
    }

    if (!this.state.hotelConfiguration.length) {
      
      this.setPassengerDetails(props.itineraryInfo);
    }

    if (props.passengersSaved) {
      this.props.actions.dissolvePassengersSaved();
      this.setState({ showAlert: props.passengersSaved === 'FAILURE' });
    }
  }

  componentWillUnmount() {
    this.props.actions.resetFetchedPassengersList();
  }

  setPassengerDetails(props) {
    if (!isEmptyObject(props) && !this.state.hotelConfiguration.length) {
      //------------initializing passenger details to be captured--------------//
      let data = [];
      let error = [];
      let initialJson = {
        passengerId: '',
        salutation: '',
        firstName: '',
        lastName: '',
        passportNumber: '',
        birthDay: '',
        passportExpirationDate: '',
        lastNameAvailable: true
      };
      props.costingConfiguration.hotelGuestRoomConfigurations.map(
        (row, key) => {
          data[key] = [];
          error[key] = [];

          for (let i = 0; i < row.adultCount; i++) {
            data[key][i] = Object.assign({ type: 'adult' }, initialJson);
            error[key][i] = Object.assign({}, initialJson);
          }

          if (row.childAges.length) {
            row.childAges.map((item, index) => {
              data[key].push(
                Object.assign({ type: 'child', childAge: item }, initialJson)
              );
              error[key].push(Object.assign({}, initialJson));
            });
          }
        }
      );
      //-------------------ends initialization---------------------------------//

      //Calculate lastDate
      // let date = moment(
      //   props.costingConfiguration.departureDate,
      //   'DD/MMM/YYYY'
      // ).format('DD/MM/YYYY');
      let cityOb =
        props.iterCityByKey[
          props.itinerary.allCityKeys[props.itinerary.allCityKeys.length - 1]
        ];
      let ls_day = cityOb.allDayKeys[cityOb.allDayKeys.length - 1];
      let date = new Date(props.iterDayByKey[ls_day].dayTs);
      let lastDate = moment(date, 'DD/MM/YYYY').format('DD/MM/YYYY'); // Date(date.setDate(date.getDate() + nights)); //last date + 6months

      this.setState({
        data,
        error,
        lastDate: lastDate,
        hotelConfiguration:
          props.costingConfiguration.hotelGuestRoomConfigurations
      });
    }
  }

  segregatePassengers(passengerDetails) {
    let adults = [],
      child = [];
    passengerDetails = passengerDetails || [];
    passengerDetails.map((data, key) => {
      data.selected = false;
      if (moment().diff(getExactDate(data.birthDay), 'years', false) > 14)
        adults.push(data);
      else child.push(data);
    });

    this.setState({ adults, child });
  }

  handleToggleDropdown(mainKey, type) {
    // console.log('mainKey', mainKey);
    // console.log('type', type);
    if (this.state.selectedDropdown === mainKey + type) {
      this.setState({ selectedDropdown: '' });
    } else {
      let key = mainKey + type;
      this.setState({ selectedDropdown: key });
    }
  }

  handleSelection(data, selectedName) {
    let selectedList = this.state.selectedList;
    if (selectedName) {
      selectedList.push(selectedName);
    }
    this.setState({ data, selectedList }, () => {
      if (this.state.formSubmitted) {
        this.validation();
      }
    });
  }

  handleInput(updatedData) {
    let value = updatedData.value;
    if (
      updatedData.name.indexOf('Name') > 0 ||
      updatedData.name.indexOf('passportIssueCity') >= 0
    ) {
      value = value.trimLeft();
      value = value.replace(/\s\s+/g, ' ');
    } else {
      value = value.replace(/ /g, '');
    }
    updatedData.value = value;
    let { data, formSubmitted } = this.state;

    data[updatedData.mainKey][updatedData.subKey][updatedData.name] =
      updatedData.value;
    this.setState({ data }, () => {
      if (formSubmitted) {
        this.validation();
      }
    });
  }

  removeElement(arr, main, sub, ele) {
    let targetIndex = arr[main][sub]['error'].indexOf(ele);
    if (arr.length && targetIndex !== -1) {
      arr[main][sub]['error'].splice(targetIndex, 1);
    }

    return arr;
  }

  validation() {
    let error = this.state.error;

    let salutationError = 'Please choose valid salutation';
    let firstNameError = 'Please enter first name';
    let cityNameError = 'Please enter city name';
    let surNameError = 'Please enter surname';
    let surNameLengthError =
      "Surname must contains atleast 2 characters. Please click on 'Need help'";
    let firstNameLengthError = 'First name must contains atleast 2 characters';
    let cityNameLengthError = 'City name must contains atleast 2 characters';
    let surNameMaxLengthError = 'Surname should not be more than 50 characters';
    let firstNameMaxLengthError =
      'First name should not be more than 50 characters';
    let cityNameMaxLengthError =
      'City name should not be more than 50 characters';
    let specialCharacterFirstNameError =
      'Special characters not allowed in first name';
    let specialCharacterCityNameError =
      'Special characters not allowed in city name';
    let specialCharacterLastNameError =
      'Special characters not allowed in surname';
    let passportError = 'Please enter valid Passport No.';
    let passportExpiryEmptyError = 'Please enter Passport Expiry Date';
    let passportExpiryInvalidError =
      'Passport validity needs to be at least 6 months more than the trip end date';
    let DOBEmptyError = 'Date of birth is a mandatory!';
    let DOBInvalidError =
      "Date of birth doesn't match with the entered child age";
    let DOBInvalidAdultError = 'Age must be above 14 years';
    let DOBCaluclationError = 'Age entered is invalid';
    let passportNumberValidation = 'Passport number should not be same';
    let mandatoryFields = 'Please enter mandatory fields';
    let passportIssueEmptyError = 'Please enter Passport Issue Date';
    let passportIssueValudationError =
      'Please enter the valid Passport Issue Date';
    let passportCountryEmptyError = 'Please choose Passport Issue Country';
    let expireDateValidationError =
      'Please enter valid date format in expire date';
    let birthDateValidationError = 'Please enter valid date format in DOB';
    let issueDateValidationError =
      'Please enter valid date format in issue date';

    let checkForPyton = this.checkPytonIncuded();
    this.state.data.map((item, main) => {
      let childcount = 0;
      let childAges = [];
      let passportNumbers = [];
      item.map(data => {
        if (data.type === 'child') {
          childAges.push(data.childAge);
        }
        passportNumbers.push(data['passportNumber']);
      });
      item.map((data, sub) => {
        error[main][sub]['error'] = [];
        if (data['salutation'] === '') {
          error[main][sub]['salutation'] = 'error';
          error[main][sub]['error'].push(salutationError);
        } else {
          error[main][sub]['salutation'] = '';
          error = this.removeElement(error, main, sub, salutationError);
        }

        if (!data['firstName']) {
          error[main][sub]['firstName'] = 'error';
          error[main][sub]['error'].push(firstNameError);
        } else {
          error = this.removeElement(error, main, sub, firstNameError);
          if (!isValidName(data['firstName'])) {
            error[main][sub]['firstName'] = 'error';
            error[main][sub]['error'].push(specialCharacterFirstNameError);
          } else {
            error = this.removeElement(
              error,
              main,
              sub,
              specialCharacterFirstNameError
            );
            if (data['firstName'].replace(/ /g, '').length < 2) {
              error[main][sub]['firstName'] = 'error';
              error[main][sub]['error'].push(firstNameLengthError);
            } else if (data['firstName'].length > 50) {
              error[main][sub]['firstName'] = 'error';
              error[main][sub]['error'].push(firstNameMaxLengthError);
            } else {
              error[main][sub]['firstName'] = '';
              error = this.removeElement(
                error,
                main,
                sub,
                firstNameLengthError
              );
              error = this.removeElement(
                error,
                main,
                sub,
                firstNameMaxLengthError
              );
            }
          }
        }

        if (!this.state.error[main][sub]['noSurname']) {
          if (!data['lastName']) {
            error[main][sub]['lastName'] = 'error';
            error[main][sub]['error'].push(surNameError);
          } else {
            error = this.removeElement(error, main, sub, surNameError);
            if (!isValidName(data['lastName'])) {
              error[main][sub]['lastName'] = 'error';
              error[main][sub]['error'].push(specialCharacterLastNameError);
            } else {
              error = this.removeElement(
                error,
                main,
                sub,
                specialCharacterLastNameError
              );
              if (data['lastName'].replace(/ /g, '').length < 2) {
                error[main][sub]['lastName'] = 'error';
                error[main][sub]['error'].push(surNameLengthError);
              } else if (data['lastName'].length > 50) {
                error[main][sub]['lastName'] = 'error';
                error[main][sub]['error'].push(surNameMaxLengthError);
              } else {
                error[main][sub]['lastName'] = '';
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  surNameLengthError
                );
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  surNameMaxLengthError
                );
              }
            }
          }
        }
        /** Passport number repeatation validation */
        let isRepeated = passportNumbers.some((passNo, index) => {
          return passNo === data['passportNumber'] && index !== sub;
        });
        if (
          !data['passportNumber'] ||
          !passportValidation(data['passportNumber'])
        ) {
          error[main][sub]['passportNumber'] = 'error';
          error[main][sub]['error'].push(passportError);
        } else {
          if (isRepeated) {
            error[main][sub]['passportNumber'] = 'error';
            error[main][sub]['error'].push(passportNumberValidation);
          } else {
            error[main][sub]['passportNumber'] = '';
            error = this.removeElement(
              error,
              main,
              sub,
              passportNumberValidation
            );
            error = this.removeElement(error, main, sub, passportError);
          }
        }

        if (!data['passportExpirationDate']) {
          error[main][sub]['passportExpirationDate'] = 'error';
          error[main][sub]['error'].push(passportExpiryEmptyError);
        } else {
          if (
            error[main][sub]['error'].indexOf(passportExpiryEmptyError) !== -1
          ) {
            error = this.removeElement(
              error,
              main,
              sub,
              passportExpiryEmptyError
            );
          }
          if (!dateValidation(data['passportExpirationDate'])) {
            error[main][sub]['passportExpirationDate'] = 'error';
            error[main][sub]['error'].push(expireDateValidationError);
          } else {
            error = this.removeElement(
              error,
              main,
              sub,
              expireDateValidationError
            );
            if (
              !expiryDateValidation(
                data['passportExpirationDate'],
                this.state.lastDate
              )
            ) {
              error[main][sub]['passportExpirationDate'] = 'error';
              error[main][sub]['error'].push(passportExpiryInvalidError);
            } else {
              error[main][sub]['passportExpirationDate'] = '';
              error = this.removeElement(
                error,
                main,
                sub,
                passportExpiryInvalidError
              );
            }
          }
        }

        if (checkForPyton) {
          if (!data['passportIssueDate']) {
            error[main][sub]['passportIssueDate'] = 'error';
            error[main][sub]['error'].push(passportIssueEmptyError);
          } else {
            if (
              error[main][sub]['error'].indexOf(passportIssueEmptyError) !== -1
            ) {
              error = this.removeElement(
                error,
                main,
                sub,
                passportIssueEmptyError
              );
            }
            if (!dateValidation(data['passportIssueDate'])) {
              error[main][sub]['passportIssueDate'] = 'error';
              error[main][sub]['error'].push(issueDateValidationError);
            } else {
              error = this.removeElement(
                error,
                main,
                sub,
                issueDateValidationError
              );
              if (
                !issueDateValidation(
                  data['passportIssueDate'],
                  data['birthDay']
                )
              ) {
                error[main][sub]['passportIssueDate'] = 'error';
                error[main][sub]['error'].push(passportIssueValudationError);
              } else {
                error[main][sub]['passportIssueDate'] = '';
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  passportIssueValudationError
                );
              }
            }
          }

          if (!data['passportIssueCity']) {
            error[main][sub]['passportIssueCity'] = 'error';
            error[main][sub]['error'].push(cityNameError);
          } else {
            error = this.removeElement(error, main, sub, cityNameError);
            if (!isValidName(data['passportIssueCity'])) {
              error[main][sub]['passportIssueCity'] = 'error';
              error[main][sub]['error'].push(specialCharacterCityNameError);
            } else {
              error = this.removeElement(
                error,
                main,
                sub,
                specialCharacterCityNameError
              );
              if (data['passportIssueCity'].replace(/ /g, '').length < 2) {
                error[main][sub]['passportIssueCity'] = 'error';
                error[main][sub]['error'].push(cityNameLengthError);
              } else if (data['passportIssueCity'].length > 50) {
                error[main][sub]['passportIssueCity'] = 'error';
                error[main][sub]['error'].push(cityNameMaxLengthError);
              } else {
                error[main][sub]['passportIssueCity'] = '';
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  cityNameLengthError
                );
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  cityNameMaxLengthError
                );
              }
            }
          }
        }

        // DOB
        if (!data['birthDay']) {
          error[main][sub]['birthDay'] = 'error';
          error[main][sub]['error'].push(DOBEmptyError);
        } else {
          error[main][sub]['birthDay'] = '';
          error = this.removeElement(error, main, sub, DOBEmptyError);

          if (!dateValidation(data['birthDay'])) {
            error[main][sub]['birthDay'] = 'error';
            error[main][sub]['error'].push(birthDateValidationError);
          } else {
            error = this.removeElement(
              error,
              main,
              sub,
              birthDateValidationError
            );

            if (data['type'] === 'child') {
              let ageValidation = childAgeValidation(
                childAges,
                data.birthDay,
                this.state.lastDate
              );
              if (!ageValidation.isValid) {
                error[main][sub]['birthDay'] = 'error';
                error[main][sub]['error'].push(DOBInvalidError);
              } else {
                let ageIndex = childAges.indexOf(ageValidation.currentAge);
                childAges.splice(ageIndex, 1);
                error[main][sub]['birthDay'] = '';
                error = this.removeElement(error, main, sub, DOBInvalidError);
              }
            } else {
              let ageValidation = adultAgeValidation(
                14,
                data.birthDay,
                this.state.lastDate
              );
              if (!ageValidation.isValidAge) {
                error[main][sub]['birthDay'] = 'error';
                error[main][sub]['error'].push(
                  ageValidation.invalidCalculation
                    ? DOBCaluclationError
                    : DOBInvalidAdultError
                );
              } else {
                error[main][sub]['birthDay'] = '';
                error = this.removeElement(
                  error,
                  main,
                  sub,
                  DOBInvalidAdultError
                );
              }
            }
          }
        }
        if (checkForPyton) {
          if (!data['passportIssueCountry']) {
            error[main][sub]['passportIssueCountry'] = 'error';
            error[main][sub]['error'].push(passportCountryEmptyError);
          } else {
            error = this.removeElement(
              error,
              main,
              sub,
              passportCountryEmptyError
            );
            error[main][sub]['passportIssueCountry'] = '';
          }
        }
        if (error[main][sub]['error'].length > 7) {
          error[main][sub]['error'] = [];
          error[main][sub]['error'].push(mandatoryFields);
        }
      });

      // errorBoolean = !(error[main][sub]['error'].length === 0);
    });
    this.handleValidation(error);

    let errorsDeep = _.flatMap(_.flattenDeep(error), 'error').filter(el => el);
    // console.log('Gotten errors ', errorsDeep);

    return !(errorsDeep && errorsDeep.length > 0);
  }

  handleValidation(error) {
    this.setState({ error });
  }

  getDatesFormatted(items) {
    return items.map(item => {
      let newItem = Object.assign({}, item);

      let ppExp = item.passportExpirationDate.toString();
      newItem.passportExpirationDate = moment(ppExp, 'DD/MM/YYYY').format(
        'DD/MMM/YYYY'
      );

      newItem.birthDay = moment(item.birthDay, 'DD/MM/YYYY').format(
        'DD/MMM/YYYY'
      );

      newItem.passportIssueDate = moment(
        item.passportIssueDate,
        'DD/MM/YYYY'
      ).format('DD/MMM/YYYY');

      return newItem;
    });
  }

  handleSubmit(e) {
    // validateForm('#booking-travellers', this.formValidator, () => {
    //   // callback when form isValid
    // });
    
    this.setState({ formSubmitted: true }, () => {
      if (this.validation()) {
        this.setState({ isLoading: true }, () => {
          let reqData = {};
          reqData['itineraryId'] = this.props.match.params.itineraryId;
          reqData['roomPassengersDetailsList'] = [];
          let data = [...this.state.data];
          data.map((item, key) => {
            let itemObject = this.getDatesFormatted(item);

            reqData['roomPassengersDetailsList'][key] = {};
            reqData['roomPassengersDetailsList'][key][
              'otherPassengerDetailList'
            ] = itemObject.splice(1);
            reqData['roomPassengersDetailsList'][key]['leadPassengerDetail'] =
              itemObject[0];
          });

          trackEvent(EVENT_PAX_FILLED, {
            itinerary_id: reqData['itineraryId'],
            pax_details: data
          });

          this.props.actions
            .savePassengers(reqData, this.props.history)
            .then(() => {
              this.setState({ isLoading: false });
            })
            .catch(() => {
              this.setState({ isLoading: false });
            });
        });
      }
    });
  }

  checkPytonIncuded() {
    let isPytonIncluded = false;
    let { itineraryInfo } = this.props;
    if (
      itineraryInfo &&
      itineraryInfo.flightCostings &&
      itineraryInfo.flightCostings.flightCostingById
    ) {
      let flightKeys = Object.values(
        itineraryInfo.flightCostings.flightCostingById
      );
      let value = _.find(flightKeys, (key, index) => {
        return key.ourSourceProvider === 'PYTON' && key.status === 'SUCCESS';
      });
      isPytonIncluded = !_.isEmpty(value);
    }
    return isPytonIncluded;
  }

  render() {
    // if (this.props.passengersSaved && this.props.passengersSaved === 'SUCCESS') {
    //   this.props.actions.dissolvePassengersSaved();
    // } else if (this.props.passengersSaved && this.props.passengersSaved === 'FAILURE') {
    //   this.props.actions.dissolvePassengersSaved();
    //
    //   this.setState({ showAlert: true });
    // }

    const { itineraryInfo } = this.props;
    let { isLoading } = this.state;

    if (_.isEmpty(itineraryInfo.itinerary)) return null;

    let isPytonIncluded = this.checkPytonIncuded();
    const inclusionsPagePath = itineraryModalsRouteHelper({
      itineraryId: itineraryInfo.itinerary.itineraryId,
      regionCode: itineraryInfo.itinerary.regionCode,
      parentPage: routingPageType.inclusion
    })

    return (
      <div className="clearfix booking-pages">
        <WizardHeader
          stepTitle={'Passenger Details'}
          itineraryId={itineraryInfo.itinerary.itineraryId}
          prevStepUrl={inclusionsPagePath}
          nextStepFunc={this.handleSubmit}
          activeTab={1}
          livePrice={true}
        />

        <section className="booking-pages-content">
          <div className="container xs-full-width">
            <div className="row">
              <div className="col-md-push-9 col-md-3" />

              <div
                className="col-md-pull-3 col-md-9"
                id="bookingPassengerDetail"
              >
                <section className="row">
                  <div className="col-md-10 col-md-push-2">
                    <h4 className="mt-0 text-center bold large-heading hidden-xs mbottom-medium">
                      Enter passenger details
                    </h4>
                  </div>
                </section>

                <form id={'booking-travellers'} autoComplete={'off'}>
                  <input type="hidden" value="prayer" />

                  {this.state.hotelConfiguration &&
                    this.state.hotelConfiguration.map((row, key) => {
                      let adultRows = Array.from(Array(row.adultCount).keys());

                      return (
                        <div
                          className="clearfix mbottom-medium"
                          key={`room_${key}`}
                        >
                          <section className="row">
                            <div className="col-md-10 col-md-push-2">
                              <div className="clearfix room-config-text">
                                <b className="pull-left color-accent-6">
                                  <i className="vehoicon-room color-accent-6" />{' '}
                                  ROOM #{key + 1}
                                </b>
                                <span className="pull-right color-grey fade">
                                  Enter details for {row.adultCount} adults
                                  {row.childAges.length > 0
                                    ? ` & ${row.childAges.length} child`
                                    : null}
                                </span>
                              </div>
                            </div>
                          </section>

                          {adultRows.map((item, inx) => {
                            return (
                              <Person
                                key={`bp-person-${inx}`}
                                {...this.props}
                                mainKey={key}
                                isPytonIncluded={isPytonIncluded}
                                type={'Adult 0' + (inx + 1)}
                                subKey={inx}
                                info={this.state.data[key][inx]}
                                dataCatch={this.state.data}
                                passengerData={this.state.adults}
                                selectedDropdown={this.state.selectedDropdown}
                                activeDropdownList={this.state.selectedList}
                                handleInput={this.handleInput}
                                handleSelection={this.handleSelection}
                                allSuggestions={allSuggestions}
                                handleToggleDropdown={this.handleToggleDropdown}
                                surname={
                                  parseInt(this.props.surname.mainKey, 10) ===
                                    key &&
                                  parseInt(this.props.surname.subKey, 10) ===
                                    inx
                                    ? this.props.surname
                                    : ''
                                }
                                error={this.state.error}
                                validation={this.handleValidation}
                                childAge={row.childAges}
                                lastDate={this.state.lastDate}
                              />
                            );
                          })}

                          {row.childAges &&
                            row.childAges.map((data, value) => {
                              return (
                                <Person
                                  {...this.props}
                                  key={"child_"+key}
                                  mainKey={key}
                                  isPytonIncluded={isPytonIncluded}
                                  type={'Child 0' + (value + 1)}
                                  subKey={row.adultCount + value}
                                  info={
                                    this.state.data[key][row.adultCount + value]
                                  }
                                  allSuggestions={allSuggestions}
                                  dataCatch={this.state.data}
                                  passengerData={this.state.child}
                                  selectedDropdown={this.state.selectedDropdown}
                                  handleInput={this.handleInput}
                                  handleSelection={this.handleSelection}
                                  handleToggleDropdown={
                                    this.handleToggleDropdown
                                  }
                                  surname={
                                    this.state.surname.mainKey === key &&
                                    this.state.surname.subKey ===
                                      row.adultCount + value
                                      ? this.state.surname.surName
                                      : ''
                                  }
                                  error={this.state.error}
                                  validation={this.handleValidation}
                                  childAge={row.childAges}
                                  lastDate={this.state.lastDate}
                                />
                              );
                            })}
                        </div>
                      );
                    })}
                  <section className="row btn-row hidden-xs">
                    <div className="col-sm-12 col-md-10 col-md-push-2">
                      <div className="pull-left btn-lft">
                        <Link
                          key={'backToItineraryBtn'}
                          to={{pathname: inclusionsPagePath}}
                          className="btn btn-xl btn-default btn-outline btn-block"
                        >
                          Back to itinerary
                        </Link>
                      </div>
                      <div className="pull-right btn-rgt">
                        <button
                          type="button"
                          className={classNames(
                            'btn btn-xl btn-primary btn-block',
                            {
                              'progress-btn': isLoading
                            }
                          )}
                          onClick={this.handleSubmit}
                        >
                          {isLoading ? (
                            <span className={'progress-bg'} />
                          ) : null}
                          <span className={'btn-txt'}>
                            Next, review costs{' '}
                            <i className="vehoicon-arrow_downward rotate-minus-90" />
                          </span>
                        </button>
                      </div>
                    </div>
                  </section>
                </form>
              </div>
            </div>
          </div>
          <SweetAlert
            show={this.state.showAlert}
            title="Sorry, unable to save passenger details"
            text={`Apologies, seems like a network issue in Pickyourtrail. Could you please try once again.`}
            // onConfirm={() => this.deleteCity(this.state.cityToDelete)}
            // showCancelButton
            animation="pop"
            // onEscapeKey={() =>
            // this.setState({ isRemoveConfirmationVisible: false })
            // }
            onConfirm={() => this.setState({ showAlert: false })}
            // onOutsideClick={() =>
            // this.setState({ isRemoveConfirmationVisible: false })
            // }
          />
        </section>

        <div className="bottom-options-bar text-center visible-xs slide-up">
          <section className="bottom-options-content">
            <div className="clearfix visible-xs xs-btns">
              <div className="col-xs-4 pull-left">
                <Link
                  key={'backToItineraryBtnMbl'}
                  to={{pathname: inclusionsPagePath}}
                  className="btn btn-light btn-block"
                >
                  Cancel
                </Link>
              </div>
              <div className="col-xs-8 pull-right">
                <button
                  className="btn btn-primary btn-block"
                  onClick={this.handleSubmit}
                >
                  Next, Review costs{' '}
                  <i className="vehoicon-arrow_downward rotate-minus-90" />
                </button>
              </div>
            </div>
          </section>
        </div>

        {/* Routes */}
        <Switch>
          <Route
            exact={true}
            path="/booking-travellers/:itinerary/surname-modal/:mainKey/:subKey/"
            component={SurnameModalLoadable}
          />
          <Route
            exact={true}
            path="/booking-travellers/:itinerary/surname-modal/:mainKey/:subKey/:prevName"
            component={SurnameModalLoadable}
          />
        </Switch>
      </div>
    );
  }
}
function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      user_profile_details: app.user_profile_details
        ? app.user_profile_details
        : {},
      surname: app.surname ? app.surname : {},
      passengersSaved: app.passengersSaved
    };
  } else {
    return {
      itineraryDetail: {},
      itineraryInfo: {},
      user_profile_details: {},
      user_details: app.user_details,
      surname: {}
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getItinerary: bindActionCreators(getItinerary, dispatch),
      getUserProfileDetails: bindActionCreators(
        getUserProfileDetails,
        dispatch
      ),
      savePassengers: bindActionCreators(savePassengers, dispatch),
      dissolvePassengersSaved: bindActionCreators(
        dissolvePassengersSaved,
        dispatch
      ),
      resetFetchedPassengersList: bindActionCreators(
        resetFetchedPassengersList,
        dispatch
      )
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(BookingPassengers);
