import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link, Route, Switch } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import {
  getLivePrice,
  loadAllModalLinks,
  blockFlight,
  updateExceesBaggageInfo,
  setCounterAlert,
  resetLivePriceFlag,
  getUserDetails,
  fetchItinerary,
  manageUnAuthAlert
} from '../../../actions/actions_app';
import {
  countdown,
  isEmptyObject,
  isFaqMobile 
} from '../../../helpers/utilsHelper';
import _, { sumBy } from 'lodash';
import SweetAlert from 'sweetalert-react';

import AddExcessBaggage from './components/add_excees_baggage';
/* global swal */
import {
  encodeActivityKeyForURL,
  encodeCostingKeyForURL,
  hideChatIconOnMobile
} from '../../../helpers/utilsHelper';
import BookingSoldOut from './components/booking_sold_out';
import TotalPrice from './components/total_price';
import BookingReviewLoading from './components/booking_review_loading';
import WizardHeader from '../components/WizardHeader';
import ChangedItemsAccordion from './components/changed_items_accordion';
import UnchangedItemsAccordion from './components/unchanged_items_accordion';
import {
  ActivityInfoModalLoadable,
  FerryInfoModalLoadable,
  FlightInfoModalLoadable,
  HotelInfoModalLoadable,
  InsuranceInfoModalLoadable,
  PassInfoModalLoadable,
  TrainInfoModalLoadable,
  TransferInfoModalLoadable,
  VisaInfoModalLoadable,
  ApplyPromoModalLoadable
} from '../../../helpers/loadbleComponentsHelper';
import { itineraryModalsRouteHelper, routingPageType } from '../../../helpers/routesHelper';
import {
  trackEvent,
  EVENT_COST_REVIEWED,
  EVENT_BOOKING_TIMED_OUT,
  EVENT_COUPON_REMOVED
} from '../../../helpers/ML/EventsTracker';
import { AppConfig } from "../../../app-config";
import { triggerSimpleAjax } from '../../../helpers/httpHelper';

class BookingReview extends Component {
  constructor(props) {
    super(props);

    this.state = {
      itineraryId: '',
      active_panel: '',
      isFetching: false,
      showLoading: false,
      showOkButton: false,
      loadingDesc: 'Please wait...',
      loadingTitle: 'Blocking flight',
      loadingImage: '',
      packageRate: false,
      diffCostFound: false,
      diffPanelOpen: false,
      itineraryDetail: '',
      paymentScheduleDetail: '',
      showAEBModal: false,
      AEBModalProps: {
        flightCostingRef: null
      },
      allPaidActivities: [],
      allFreeActivities: [],
      flightsArray: [],
      soldOutFlights: [],
      unChangedFlights: [],
      changedFlights: [],
      hotelsArray: [],
      soldOutHotels: [],
      unChangedHotels: [],
      changedHotels: [],
      activitiesArray: [],
      changedActivities: [],
      unChangedActivities: [],
      soldOutActivities: [],
      visaArray: [],
      unchangedVisaArray: [],
      changedVisaArray: [],
      transfersArray: [],
      unchangedTransfers: [],
      changedTransfers: [],
      insuranceDetail: {},
      unchangedInsuranceDetail: {},
      changedInsuranceDetail: {},
      passArray: [],
      changedPassArray: [],
      unchangedPassArray: [],
      isUnchangedSectionVisible: false,
      showExcessBaggageModal: false,
      excessBaggages: [],
      isLoading: true,
      showLoadingIndicator: true,
      isCountDownIdle: true,
      blockFlightSweetAlertConfig: {
        title: '',
        text: '',
        type: '',
        animation: 'pop'
      },
      showBlockFlightSweetAlert: false,
      blockFlightLoading: false
    };
    this.generateUrls = this.generateUrls.bind(this);
    this.toggleUnchangedSection = this.toggleUnchangedSection.bind(this);

    this.blockFlight = this.blockFlight.bind(this);
    this.updateBaggage = this.updateBaggage.bind(this);
    this.toggleAEBModal = this.toggleAEBModal.bind(this);
    this.removePromo = this.removePromo.bind(this);
  }

  toggleUnchangedSection() {
    this.setState({
      isUnchangedSectionVisible: !this.state.isUnchangedSectionVisible
    });
  }

  componentDidMount() {
    hideChatIconOnMobile();
    this.props.getLivePrice(this.props.match.params.itineraryId);
    if (!this.props.userDetails && isFaqMobile()) {
      this.props.getUserDetails();
    }
  }

  componentWillReceiveProps(nextProps) {
    let livePriceError = nextProps.livePriceError;
    if (!this.props.livePriceError.hasError && livePriceError.hasError) {
      if (
        livePriceError.error.response &&
        livePriceError.error.response.status === 401
      ) {
        this.props.history.push('/login');
      } else if (
        // If the agent crosed the limit and not allowed to cost
        livePriceError.error.response &&
        livePriceError.error.response.status === 403
      ) {
        let { data } = livePriceError.error.response;
        swal(
          {
            title: 'Oops sorry!',
            type: 'warning',
            text: data.message ? data.message : 'Forbidden',
            animation: true,
            showCancelButton: false,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Ok, Got It',
            closeOnConfirm: true,
            closeOnCancel: true
          },
          function (isConfirm) {
            // Redirecting to agent dashboard if the user type is agent
            if (
              nextProps.userDetails.userType && // If the userType available
              nextProps.userDetails.userType === 'AGENT' // And the usertype is agent)
            ) {
              nextProps.history.push(`/agent/dashboard`);
            } else {
              nextProps.history.push(`/your-vacations`);
            }
          }
        );
      } else {
        swal(
          {
            title: 'Oops!',
            type: 'warning',
            text:
              'Oh no! Our server has gone for a vacation. Please go back to the previous page and try again later',
            // imageUrl: '/images/cost_error.png',
            animation: true,
            showCancelButton: false,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Ok, Got It',
            closeOnConfirm: true,
            closeOnCancel: true
          },
          function(isConfirm) {
            const itineraryPagePath = itineraryModalsRouteHelper({
              itineraryId: nextProps.itineraryDetails && nextProps.itineraryDetails.itinerary.itineraryId,
              regionCode: nextProps.itineraryDetails && nextProps.itineraryDetails.itinerary.regionCode,
              parentPage: routingPageType.itinerary
            });

            nextProps.history.push(itineraryPagePath);
          }
        );
      }
    }

    if (nextProps.user_details && !isEmptyObject(nextProps.user_details)) {
      if (!nextProps.user_details.loggedIn) {
        this.props.history.push('/login');
      }
    }

    if (
      nextProps.itineraryDetails &&
      nextProps.itineraryDetails.livePriceUpdated
    ) {
      let allActivities = [];
      if (nextProps.itineraryDetails.activityById) {
        allActivities = Object.values(nextProps.itineraryDetails.activityById);
      }
      let allPaidActivities = [];
      let allFreeActivities = [];

      if (allActivities && allActivities.length > 0) {
        allPaidActivities = allActivities.filter(activity => !activity.free);
        allFreeActivities = allActivities.filter(activity => activity.free);
      }

      this.setState(
        {
          itineraryDetail: nextProps.itineraryDetails,
          allPaidActivities: allPaidActivities,
          allFreeActivities: allFreeActivities,
          packageRate:
            nextProps.itineraryDetails.costingConfiguration.packageRate,
          hideSplitPricing:
            nextProps.itineraryDetails.itinerary.hideSplitPricing,
          paymentScheduleDetail: nextProps.itineraryDetails.paymentSchedule,
          isFetching: false,
          diffCostFound:
            nextProps.itineraryDetails.totalDiff.changeType !== 'NONE',
          diffPanelOpen:
            nextProps.itineraryDetails.totalDiff.changeType !== 'NONE'
        },
        () => {
          // Reset livePrice flag in Redux
          this.props.resetLivePriceFlag();

          this.setState(
            {
              isLoading: false
            },
            () => {
              setTimeout(() => {
                this.setState(
                  {
                    showLoadingIndicator: false
                  },
                  () => {
                    if (this.state.isCountDownIdle) {
                      this.setState({
                        isCountDownIdle: false
                      });
                      let isMobile = isFaqMobile();
                      let counterElement = document.querySelector(
                        isMobile ? '#mobile-timer' : '#desktop-timer'
                      );
                      counterElement.classList.remove('hide');
                      countdown(
                        'countdown-timer' + (isMobile ? '-span' : '-desktop'),
                        10,
                        () => {
                          trackEvent(EVENT_BOOKING_TIMED_OUT, {
                            pageURL: document.location.href
                          });
                          counterElement.classList.add('hide');
                          this.props.setCounterAlert(true);
                        }
                      );
                    }
                  }
                );
              }, 2000);
            }
          );
          this.generateUrls();
        }
      );
    }
  }

  onMakePaymentClick = () => {
    trackEvent(EVENT_COST_REVIEWED);
  };

  toggleAEBModal(flight = null) {
    this.setState({
      excessBaggages: flight,
      showExcessBaggageModal: !!flight
    });
  }

  updateBaggage(payload) {
    payload['dbFlightId'] = this.state.excessBaggages.dbFlightId;
    this.props.updateExceesBaggageInfo(payload);

    this.toggleAEBModal();
  }

  blockFlight(flightKey) {
    let { itineraryId } = this.props.itineraryDetails.itinerary;
    this.setState({ blockFlightLoading: flightKey }, () => {
      let req_config = { itineraryId: itineraryId, flightKey: flightKey };
      this.props
        .blockFlight(req_config)
        .then(() => {
          this.setState({
            blockFlightSweetAlertConfig: {
              title: 'Flight blocked successfully',
              text:
                "We have placed a rock stone in front of the flight's tyres. It's blocked and can't move now. Get your customer to pay quick. Real quick.",
              type: 'success',
              animation: 'pop'
            },
            showBlockFlightSweetAlert: true,
            blockFlightLoading: false
          });
        })
        .catch(() => {
          this.setState({
            blockFlightSweetAlertConfig: {
              title: 'Unable to block flights',
              text:
                "Something went wrong and we weren't able to block flights. Please try again.",
              type: 'warning',
              animation: 'pop'
            },
            showBlockFlightSweetAlert: true,
            blockFlightLoading: false
          });
        });
    });
  }

  generateUrls() {
    const { itineraryDetail } = this.state;
    const itineraryId = this.state.itineraryDetail.itinerary.itineraryId;
    const { allSlot } = this.props;
    const { totalDiff } = itineraryDetail;

    const changedFlights = [],
      unChangedFlights = [],
      soldOutFlights = [];
    const flightsArray = !itineraryDetail.allFlightCostingRefs
      ? []
      : itineraryDetail.allFlightCostingRefs.map((flightId, inx) => {
        const flightCostingObj = itineraryDetail.flightCostings;
        let flight =
          flightCostingObj.flightCostingById &&
          flightCostingObj.flightCostingById[flightId];

        if (!flight) {
          return null;
        }

        const requiredFlight = {
          url: `/booking-review/${itineraryId}/flight-details/${encodeCostingKeyForURL(
            flight.key
          )}`,
          key: encodeCostingKeyForURL(flight.key),
          flightDetails: flight
        };

        if (requiredFlight.flightDetails.status === 'SOLD_OUT') {
          soldOutFlights.push(requiredFlight);
        } else if (requiredFlight.flightDetails.status === 'SUCCESS') {
          if (
            !requiredFlight.flightDetails.diff ||
            requiredFlight.flightDetails.diff.diffChangeType === 'NONE'
          ) {
            unChangedFlights.push(requiredFlight);
          } else {
            changedFlights.push(requiredFlight);
          }
        }

        return requiredFlight;
      });

    this.setState({
      flightsArray,
      soldOutFlights,
      unChangedFlights,
      changedFlights
    });

    const changedHotels = [],
      unChangedHotels = [],
      soldOutHotels = [];
    const hotelsArray = !itineraryDetail.allHotelCostingRefs
      ? []
      : itineraryDetail.allHotelCostingRefs.map((hotelId, inx) => {
        const hotelCostings = itineraryDetail.hotelCostings;
        let hotelDetails = hotelCostings.hotelCostingById[hotelId];

        if (!hotelDetails) {
          return null;
        }

        const requiredHotel = {
          key: encodeCostingKeyForURL(hotelId),
          url: `/booking-review/${itineraryId}/hotel-details/${encodeCostingKeyForURL(
            hotelId
          )}`,
          hotelDetails
        };

        if (requiredHotel.hotelDetails.status === 'SOLD_OUT') {
          soldOutHotels.push(requiredHotel);
        } else if (requiredHotel.hotelDetails.status === 'SUCCESS') {
          if (
            !requiredHotel.hotelDetails.diffDetail ||
            requiredHotel.hotelDetails.diffDetail.diffChangeType === 'NONE'
          ) {
            unChangedHotels.push(requiredHotel);
          } else {
            changedHotels.push(requiredHotel);
          }
        }

        return requiredHotel;
      });

    this.setState({
      hotelsArray,
      soldOutHotels,
      unChangedHotels,
      changedHotels
    });

    const changedActivities = [],
      unChangedActivities = [],
      soldOutActivities = [];
    const activitiesArray = !itineraryDetail.allActivityCostingRefs
      ? []
      : itineraryDetail.allActivityCostingRefs.map((activityId, inx) => {
        let inxPaidCount = 0;
        let inxFreeCount = 0;
        /**
         * TODO: Unresolved Variable!
         */
        let isFree = itineraryDetail.selfExploration;

        const activityCostingDetails =
          itineraryDetail.activityCostings.activityCostingById[activityId];
        const activityDetailId = activityCostingDetails.activityId;
        let activityDetails = itineraryDetail.activityById[activityDetailId];

        if (
          activityDetails &&
          ((isFree && activityDetails.free) ||
            (!isFree && !activityDetails.free))
        ) {
          let activityDetailId = activityDetails.planningToolId;
          let slot = _.find(allSlot, slots => {
            return (
              slots.activitySlotDetail &&
              slots.activitySlotDetail.activityId === activityDetailId
            );
          });

          let slotIdentifier;
          if (slot) {
            slotIdentifier = _.findKey(allSlot, slot);
            slotIdentifier = encodeActivityKeyForURL(slotIdentifier);
          }

          activityDetails = {
            ...activityDetails,
            ...activityCostingDetails,
            activityId
          };

          const requiredActivity = {
            key: encodeCostingKeyForURL(slotIdentifier),
            url: `/booking-review/${itineraryId}/activity-details/${encodeCostingKeyForURL(
              slotIdentifier
            )}`,
            activityDetails
          };

          if (requiredActivity.activityDetails.status === 'SOLD_OUT') {
            soldOutActivities.push(requiredActivity);
          } else {
            if (
              !requiredActivity.activityDetails.diff ||
              requiredActivity.activityDetails.diff.diffChangeType === 'NONE'
            ) {
              unChangedActivities.push(requiredActivity);
            } else {
              changedActivities.push(requiredActivity);
            }
          }

          return requiredActivity;
        } else {
          return null;
        }
      });

    this.setState({
      activitiesArray,
      changedActivities,
      unChangedActivities,
      soldOutActivities
    });

    const changedPassArray = [],
      unchangedPassArray = [];
    const passArray = !itineraryDetail.allPassCostingRefs
      ? []
      : itineraryDetail.allPassCostingRefs.map((passId, passIndex) => {
        const passCostings = itineraryDetail.passCostings;
        let passDetails = passCostings.passCostingById[passId];

        if (!passDetails) return null;

        const requiredPass = {
          key: passId,
          url: `/booking-review/${itineraryId}/pass-details/${passId}`,
          passDetails
        };
        if (
          !requiredPass.passDetails.diff ||
          requiredPass.passDetails.diff.diffChangeType === 'NONE'
        ) {
          unchangedPassArray.push(requiredPass);
        } else {
          changedPassArray.push(requiredPass);
        }

        return requiredPass;
      });

    this.setState({
      changedPassArray,
      unchangedPassArray,
      passArray
    });

    const unchangedVisaArray = [],
      changedVisaArray = [];
    const visaArray = !itineraryDetail.allVisaCostingRefs
      ? []
      : itineraryDetail.allVisaCostingRefs.map((visaId, inx) => {
        let visaCostingById =
          itineraryDetail.visaCostings.visaCostingById[visaId];

        const requiredVisa = {
          key: encodeCostingKeyForURL(visaId),
          url: `/booking-review/${itineraryId}/visa-details/${encodeCostingKeyForURL(
            visaId
          )}`,
          visaDetails: visaCostingById
        };

        if (requiredVisa.visaDetails.status === 'SUCCESS') {
          if (
            !requiredVisa.visaDetails.diff ||
            requiredVisa.visaDetails.diff.diffChangeType === 'NONE'
          ) {
            unchangedVisaArray.push(requiredVisa);
          } else {
            changedVisaArray.push(requiredVisa);
          }
        }

        return requiredVisa;
      });

    this.setState({ visaArray, unchangedVisaArray, changedVisaArray });

    const unchangedTransfers = [],
      changedTransfers = [];
    const transfersArray = !itineraryDetail.allTransferCostingRefs
      ? []
      : itineraryDetail.allTransferCostingRefs.map(
        (transferId, transferIndex) => {
          const transfer =
            itineraryDetail.transferCostings.transferCostingById[transferId];
          if (!transfer) {
            return null;
          }
          const requiredTransfer = {
            key: encodeCostingKeyForURL(transfer.key),
            url: `/booking-review/${itineraryId}/transfer/${encodeCostingKeyForURL(
              transfer.key
            )}`,
            transferDetails: transfer
          };

          if (
            !requiredTransfer.transferDetails.diff ||
            requiredTransfer.transferDetails.diff.diffChangeType === 'NONE'
          ) {
            unchangedTransfers.push(requiredTransfer);
          } else {
            changedTransfers.push(requiredTransfer);
          }

          return requiredTransfer;
        }
      );

    const trainTransfersArray = !itineraryDetail.allTrainCostingRefs
      ? []
      : itineraryDetail.allTrainCostingRefs.map((transferId, transferIndex) => {
        const transfer =
          itineraryDetail.trainCostings.trainCostingById[transferId];
        if (!transfer) {
          return null;
        }
        const requiredTransfer = {
          key: encodeCostingKeyForURL(transfer.key),
          url: `/booking-review/${itineraryId}/train/${encodeCostingKeyForURL(
            transfer.key
          )}`,
          transferDetails: { ...transfer, vehicle: 'Train' }
        };

        if (
          !requiredTransfer.transferDetails.diff ||
          requiredTransfer.transferDetails.diff.diffChangeType === 'NONE'
        ) {
          unchangedTransfers.push(requiredTransfer);
        } else {
          changedTransfers.push(requiredTransfer);
        }

        return requiredTransfer;
      });

    const ferryCostingsArray = !itineraryDetail.allFerryCostingRefs
      ? []
      : itineraryDetail.allFerryCostingRefs.map((transferId, transferIndex) => {
        const transfer =
          itineraryDetail.ferryCostings.ferryCostingById[transferId];
        if (!transfer) {
          return null;
        }
        const requiredTransfer = {
          key: encodeCostingKeyForURL(transfer.key),
          url: `/booking-review/${itineraryId}/ferry/${encodeCostingKeyForURL(
            transfer.key
          )}`,
          transferDetails: { ...transfer, vehicle: 'Ferry' }
        };

        if (
          !requiredTransfer.transferDetails.diff ||
          requiredTransfer.transferDetails.diff.diffChangeType === 'NONE'
        ) {
          unchangedTransfers.push(requiredTransfer);
        } else {
          changedTransfers.push(requiredTransfer);
        }

        return requiredTransfer;
      });

    this.setState({
      transfersArray: [
        ...transfersArray,
        ...trainTransfersArray,
        ...ferryCostingsArray
      ],
      unchangedTransfers,
      changedTransfers
    });

    let unchangedInsuranceLink = null;
    let changedInsuranceLink = null;

    if (
      itineraryDetail.insuranceCosting &&
      !_.isEmpty(itineraryDetail.insuranceCosting.insuranceCostingById) &&
      itineraryDetail.insuranceCosting.insuranceCostingById.plan
    ) {
      let insuranceLink = {
        key: 'insurance-details',
        url: `/booking-review/${itineraryId}/insurance-details`
      };

      this.setState({
        insuranceDetail: {
          ...itineraryDetail.insuranceCosting,
          ...insuranceLink
        }
      });

      if (
        !itineraryDetail.insuranceCosting.insuranceCostingById.diff ||
        itineraryDetail.insuranceCosting.insuranceCostingById.diff
          .diffChangeType === 'NONE'
      ) {
        unchangedInsuranceLink = insuranceLink;
        this.setState({
          unchangedInsuranceDetail: {
            ...itineraryDetail.insuranceCosting,
            ...insuranceLink
          }
        });
      } else {
        changedInsuranceLink = insuranceLink;
        this.setState({
          changedInsuranceDetail: {
            ...itineraryDetail.insuranceCosting,
            ...insuranceLink
          }
        });
      }
    }

    const modalLinks = [
      ...soldOutFlights,
      ...soldOutHotels,
      ...soldOutActivities,
      ...changedFlights,
      ...changedHotels,
      ...changedActivities,
      ...changedTransfers,
      ...changedPassArray,
      ...changedVisaArray,
      ...unChangedFlights,
      changedInsuranceLink,
      ...unChangedHotels,
      ...unChangedActivities,
      ...unchangedTransfers,
      ...unchangedPassArray,
      ...unchangedVisaArray,
      unchangedInsuranceLink
    ];

    this.props.loadAllModalLinks(_.compact(modalLinks));
  }

  handleError = (error) => {
    if (error.response && error.response.status === 401) {
      this.props.callManageUnAuthAlert();
    }
  }

  removePromoSuccessCallback = (res) => {
    trackEvent(EVENT_COUPON_REMOVED);
    this.props.fetchItinerary(res);
  }

   async removePromo() {
    const { itineraryDetails = {} } = this.props;
    const itineraryId = itineraryDetails.itinerary ? itineraryDetails.itinerary.itineraryId : this.props.match.params.itineraryId;
    const url = `${AppConfig.api_url}coupon/remove/${itineraryId}`;

     await triggerSimpleAjax(
      url,
      "DELETE",
      {},
      this.removePromoSuccessCallback,
      this.handleError
    );
  }

  render() {
    if (this.state.showLoadingIndicator)
      return <BookingReviewLoading isLoading={this.state.isLoading} />;
    let {
      isUnchangedSectionVisible,
      unchangedTransfers,
      changedTransfers,
      changedHotels,
      unChangedHotels,
      soldOutHotels,
      changedFlights,
      unChangedFlights,
      soldOutFlights,
      changedVisaArray,
      unchangedVisaArray,
      changedActivities,
      unChangedActivities,
      soldOutActivities,
      unchangedInsuranceDetail,
      changedInsuranceDetail,
      changedPassArray,
      unchangedPassArray,
      blockFlightSweetAlertConfig,
      showBlockFlightSweetAlert,
      blockFlightLoading
    } = this.state;

    const { itineraryDetails, userDetails, isCred } = this.props;
    const couponVO = itineraryDetails.couponVO;

    const changedItemsLength =
      soldOutHotels.length +
      soldOutFlights.length +
      soldOutActivities.length +
      changedHotels.length +
      changedFlights.length +
      changedActivities.length +
      changedTransfers.length +
      changedPassArray.length +
      changedVisaArray.length +
      (_.isEmpty(changedInsuranceDetail) ? 0 : 1);

    const unChangedItemsLength =
      unChangedHotels.length +
      unChangedFlights.length +
      unChangedActivities.length +
      unchangedTransfers.length +
      unchangedPassArray.length +
      unchangedVisaArray.length +
      (_.isEmpty(unchangedInsuranceDetail) ? 0 : 1);

    const isSoldOut = !!(
      soldOutHotels.length +
      soldOutFlights.length +
      soldOutActivities.length
    );

    const inclusionsPagePath = itineraryModalsRouteHelper({
      itineraryId: itineraryDetails.itinerary.itineraryId,
      regionCode: itineraryDetails.itinerary.regionCode,
      parentPage: routingPageType.inclusion
    })

    return (
      <div className="clearfix booking-pages">
        <WizardHeader
          stepTitle={'Review Costs'}
          itineraryId={itineraryDetails.itinerary.itineraryId}
          prevStepUrl={`/booking-travellers/${
            itineraryDetails.itinerary.itineraryId
            }`}
          nextStepUrl={`/make-payment/${
            itineraryDetails.itinerary.itineraryId
            }`}
          activeTab={2}
        />

        <section className="booking-pages-content">
          <div className="clearfix review-container">
            {isSoldOut ? (
              <BookingSoldOut />
            ) : (
                <TotalPrice
                  totalCost={isCred && couponVO.couponApplied ? itineraryDetails.itinerary.discountedPrice :
                    itineraryDetails.itinerary.agent
                      ? itineraryDetails.itinerary.netCost
                      : itineraryDetails.itinerary.totalCost
                  }
                  changedAmount={parseFloat(
                    itineraryDetails.totalDiff.totalDiff
                  ).toFixed(0)}
                  changeType={itineraryDetails.totalDiff.changeType}
                  cutPrice={isCred && couponVO.couponApplied ? itineraryDetails.itinerary.totalCost : null}
                />
              )}

            {changedItemsLength ? (
              <ChangedItemsAccordion
                soldOutHotels={soldOutHotels}
                soldOutFlights={soldOutFlights}
                soldOutActivities={soldOutActivities}
                changedItemsLength={changedItemsLength}
                changedFlights={changedFlights}
                changedHotels={changedHotels}
                changedActivities={changedActivities}
                changedPassArray={changedPassArray}
                changedTransfers={changedTransfers}
                unchangedPassArray={unchangedPassArray}
                isUnchangedSectionVisible={isUnchangedSectionVisible}
                unChangedItemsLength={unChangedItemsLength}
                unChangedFlights={unChangedFlights}
                unChangedHotels={unChangedHotels}
                unChangedActivities={unChangedActivities}
                unchangedTransfers={unchangedTransfers}
                changedVisaArray={changedVisaArray}
                unchangedVisaArray={unchangedVisaArray}
                unchangedInsuranceDetail={unchangedInsuranceDetail}
                changedInsuranceDetail={changedInsuranceDetail}
                toggleUnchangedSection={this.toggleUnchangedSection}
                blockFlight={this.blockFlight}
                blockFlightLoading={blockFlightLoading}
                toggleAEBModal={this.toggleAEBModal}
                userDetails={userDetails}
                isCred={isCred}
              />
            ) : (
                <UnchangedItemsAccordion
                  isUnchangedSectionVisible={isUnchangedSectionVisible}
                  unChangedItemsLength={unChangedItemsLength}
                  unChangedFlights={unChangedFlights}
                  unChangedHotels={unChangedHotels}
                  unChangedActivities={unChangedActivities}
                  unchangedTransfers={unchangedTransfers}
                  unchangedPassArray={unchangedPassArray}
                  unchangedVisaArray={unchangedVisaArray}
                  unchangedInsuranceDetail={unchangedInsuranceDetail}
                  toggleUnchangedSection={this.toggleUnchangedSection}
                  blockFlight={this.blockFlight}
                  blockFlightLoading={blockFlightLoading}
                  toggleAEBModal={this.toggleAEBModal}
                  userDetails={userDetails}
                  isCred={isCred}
                />
              )}
            {isCred ? (
              <div className="clearfix promo-info">
                {!couponVO.couponApplied ? <p> <span>Do you have a promotional code?</span>
                  <Link
                    className="btn btn-primary btn-outline btn-outline-bg"
                    to={`${itineraryDetails.itinerary.itineraryId}/apply-promo`}
                  >
                    Apply
                  </Link></p>
                  : null}
                {couponVO.couponApplied ? (
                  <p className="error">
                    <i className="vehoicon-cancel cursor-pointer" onClick={this.removePromo} />The Cred Promo Code{' '}
                    <b>{couponVO.couponCode}</b> is applied
                  </p>
                ) : null}
              </div>
            ) : null}
            <section className="row btn-row hidden-xs">
              {isSoldOut ? (
                <div className="col-sm-12 col-md-10 col-md-push-1 text-center">
                  <Link
                    to={inclusionsPagePath}
                    type="button"
                    className="btn btn-xl btn-primary"
                  >
                    <i className="vehoicon-arrow_downward rotate-90" /> Change
                    your bookings
                  </Link>
                </div>
              ) : (
                <div className="col-sm-12 col-md-10 col-md-push-1 text-center">
                  <div className="pull-left btn-lft">
                    <Link
                      to={inclusionsPagePath}
                      type="button"
                      className="btn btn-xl btn-default btn-outline btn-block"
                    >
                      Back to itinerary
                    </Link>
                    </div>
                    <div className="pull-right btn-rgt">
                      <Link
                        to={`/make-payment/${
                          itineraryDetails.itinerary.itineraryId
                          }`}
                        type="button"
                        className="btn btn-xl btn-primary btn-block"
                        onClick={this.onMakePaymentClick}
                      >
                        Next, make payment{' '}
                        <i className="vehoicon-arrow_downward rotate-minus-90" />
                      </Link>
                    </div>
                  </div>
                )}
            </section>
          </div>
        </section>
        <div className="bottom-options-bar text-center visible-xs slide-up">
          <section className="bottom-options-content">
            {isSoldOut ? (
              <div className="clearfix visible-xs xs-btns">
                <div className="col-xs-12 pull-left">
                  <Link
                    to={inclusionsPagePath}
                    type="button"
                    className="btn btn-primary btn-block"
                  >
                    <i className="vehoicon-arrow_downward rotate-90" /> Change
                    your bookings
                  </Link>
                </div>
              </div>
            ) : (
                <div className="clearfix visible-xs xs-btns">
                  <div className="col-xs-4 pull-left">
                    <Link
                      to={inclusionsPagePath}
                      type="button"
                      className={`btn btn-light btn-block ${
                        blockFlightLoading ? 'disabled' : ''
                        }`}
                    >
                      Cancel
                  </Link>
                  </div>
                  <div className="col-xs-8 pull-right">
                    <Link
                      to={`/make-payment/${
                        itineraryDetails.itinerary.itineraryId
                        }`}
                      type="button"
                      className={`btn btn-xl btn-primary btn-block ${
                        blockFlightLoading ? 'disabled' : ''
                        }`}
                      onClick={this.onMakePaymentClick}
                    >
                      Next, make payment{' '}
                      <i className="vehoicon-arrow_downward rotate-minus-90" />
                    </Link>
                  </div>
                </div>
              )}
          </section>
        </div>

        <SweetAlert
          show={this.props.showAlert}
          title="Oh-oh"
          text={`Your 10 minutes are up! The current trip cost would have changed by now. Go back and finish the entire booking process immediately to ensure your total costs remain intact.`}
          animation="pop"
          confirmButtonText={'Go back to itinerary'}
          confirmButtonColor={'#26CF96'}
          onConfirm={() => {
            this.props.setCounterAlert(false);
            this.props.history.push(inclusionsPagePath);
          }}
        />

        <SweetAlert
          show={showBlockFlightSweetAlert}
          title={blockFlightSweetAlertConfig.title}
          text={blockFlightSweetAlertConfig.text}
          animation={blockFlightSweetAlertConfig.animation}
          confirmButtonText={'Okay'}
          onConfirm={() => {
            this.setState({ showBlockFlightSweetAlert: false });
          }}
        />

        {this.state.showExcessBaggageModal ? (
          <AddExcessBaggage
            toggleAEBModal={this.toggleAEBModal}
            updateBaggage={this.updateBaggage}
            showModal={this.state.showExcessBaggageModal}
            itineraryId={this.props.itineraryDetails.itinerary.itineraryId}
            ourSourceProvider={this.state.excessBaggages.ourSourceProvider}
            {...this.state.excessBaggages.excessBaggageInfo}
          />
        ) : null}

        {/* Routes */}
        <Switch>
          <Route
            path="/booking-review/:itineraryId/flight-details/:flightKey"
            component={FlightInfoModalLoadable}
          />
          <Route
            path="/booking-review/:itineraryId/hotel-details/:hotelKey"
            component={HotelInfoModalLoadable}
          />
          <Route
            path="/booking-review/:itineraryId/activity-details/:activityKey"
            component={ActivityInfoModalLoadable}
          />
          <Route
            path="/booking-review/:itineraryId/transfer/:transferKey"
            component={TransferInfoModalLoadable}
          />
          <Route
            path="/booking-review/:itineraryId/train/:transferKey"
            component={TrainInfoModalLoadable}
          />
          <Route
            path={'/booking-review/:itineraryId/ferry/:transferKey'}
            component={FerryInfoModalLoadable}
          />
          <Route
            path="/booking-review/:itineraryId/visa-details/:visaId"
            component={VisaInfoModalLoadable}
          />
          <Route
            path={`/booking-review/:itineraryId/pass-details/:passId`}
            component={PassInfoModalLoadable}
          />
          <Route
            path="/booking-review/:itineraryId/insurance-details"
            component={InsuranceInfoModalLoadable}
          />
          <Route
            path="/booking-review/:itineraryId/apply-promo"
            component={ApplyPromoModalLoadable}
          />
        </Switch>
      </div>
    );
  }
}

const mapStateToProps = state => {
  const itineraryDetails = state.app.itineraryInfo.itineraryDetails;

  return {
    itineraryDetails,
    userDetails: state.app.user_details,
    allSlot: itineraryDetails ? itineraryDetails.iterSlotByKey : {},
    livePriceError: state.app.livePriceError,
    showAlert: state.app.showAlert,
    isCred: state.app.isReadOnly
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getLivePrice: bindActionCreators(getLivePrice, dispatch),
    loadAllModalLinks: bindActionCreators(loadAllModalLinks, dispatch),
    blockFlight: bindActionCreators(blockFlight, dispatch),
    updateExceesBaggageInfo: bindActionCreators(
      updateExceesBaggageInfo,
      dispatch
    ),
    setCounterAlert: bindActionCreators(setCounterAlert, dispatch),
    resetLivePriceFlag: bindActionCreators(resetLivePriceFlag, dispatch),
    getUserDetails: bindActionCreators(getUserDetails, dispatch),
    fetchItinerary: bindActionCreators(fetchItinerary, dispatch),
    callManageUnAuthAlert: bindActionCreators(manageUnAuthAlert, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(BookingReview);
