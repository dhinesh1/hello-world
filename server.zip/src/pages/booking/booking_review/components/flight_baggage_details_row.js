import React, { Component } from 'react';
import { getAirlineLogo } from '../../../../helpers/utilsHelper';
import SmartImage from '../../../../common_components/Image/smart_image';

export default class FlightBaggageDetailsRow extends Component {
  
  renderFlightBaggageDetailsRow(trip, airlineCode) {
    const airlineImg = getAirlineLogo(airlineCode);
    return trip.routes.map((route, loopInx) => {
      return (
        <div
          className={'row ' + (loopInx !== 0 ? 'margin-top-10' : '')}
          key={Math.random()}
        >
          <div className="col-xs-12">
            <div className="col-xs-12 col-sm-6">
              <span
                className={
                  'txt-size-xxs oj-text-grey block v-spaced-5 text-uppercase no-top-margin ' +
                  (loopInx !== 0 ? 'visible-xs' : '')
                }
              >
                FLIGHT
              </span>
              <div className="col-xs-6 no-padding">
                <SmartImage
                  src={airlineImg.url}
                  alt={airlineImg.name}
                  defaultImage={airlineImg.default}
                  width="80px"
                />
              </div>
              <div className="col-xs-6">
                <span className="txt-size-xxs oj-text-black block">
                  {route.carrierName}
                </span>
                <span className="txt-size-xxs oj-text-black block">
                  Economy
                </span>
              </div>
            </div>
            <div className="col-xs-12 col-sm-6">
              <span
                className={
                  'txt-size-xxs oj-text-grey block v-spaced-5 text-uppercase no-top-margin ' +
                  (loopInx !== 0 ? 'visible-xs' : '')
                }
              >
                Baggage
              </span>
              <div className="col-xs-12 no-padding">
                <span className="txt-size-xxs oj-text-grey block">
                  <span className="oj-text-black">FREE Check-in baggage: </span>{' '}
                  {route.freeCheckInBaggage}
                </span>
                <span className="txt-size-xxs oj-text-grey block">
                  <span className="oj-text-black">FREE Cabin baggage: </span>{' '}
                  {route.freeCabinBaggage}
                </span>
              </div>
            </div>
          </div>
        </div>
      );
    });
  }

  render() {
    let { trip, airlineCode, islastRoute } = this.props;

    if (trip.routes.length > 0) {
      return (
        <div
          className={
            'col-xs-12 all-15-padding ' +
            (!islastRoute ? 'border-bottom border-dark-grey border-dashed' : '')
          }
        >
          {this.renderFlightBaggageDetailsRow(trip, airlineCode)}
        </div>
      );
    } else {
      return <div> No content </div>;
    }
  }
}
