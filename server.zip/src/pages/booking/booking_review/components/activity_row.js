import React from 'react';
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';
import PriceButton from './price_button';

const ActivityRow = ({ activitiesArray, isSoldOut }) => {
  if (!activitiesArray.length) return null;

  return (
    <section className="clearfix review-row">
      <div className="left-icon">
        <i className="vehoicon-local_play" />
      </div>
      {activitiesArray.map((activity, activityIndex) => {
        const {
          title,
          diff,
          totalCost,
          cityText,
          status
        } = activity.activityDetails;
        // if the costing status is error we are not showing the activity in the booking review row
        if (status === 'ERROR') {
          return null;
        }
        /**
         * TODO: Need to check sold out status
         */
        let priceChangeType,
          diffCost = 0;
        if (diff) {
          priceChangeType = diff.diffChangeType;
          diffCost = diff.diffCost;
        }

        return (
          <NavLink key={activityIndex} to={activity.url}>
            <p className="lft-col">
              <i>{cityText}</i>
              <span>{title}</span>
            </p>
            <div className="rgt-col">
              <p className="pull-left">
                <span />
              </p>
              <PriceButton
                price={diffCost.toFixed(0)}
                priceChangeType={priceChangeType}
                isSoldOut={isSoldOut}
              />
            </div>
          </NavLink>
        );
      })}
    </section>
  );
};

ActivityRow.propTypes = {
  activitiesArray: PropTypes.array.isRequired,
  isSoldOut: PropTypes.bool
};

export default ActivityRow;
