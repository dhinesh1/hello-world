import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import FlightRow from './flight_row';
import HotelRow from './hotel_row';
import ActivityRow from './activity_row';
import TransferRow from './transfer_row';
import PassRow from './pass_row';
import VisaRow from './visa_row';
import InsuranceRow from './insurance_row';

const ChangedItemsAccordion = ({
  soldOutHotels,
  soldOutFlights,
  soldOutActivities,
  changedItemsLength,
  changedFlights,
  changedHotels,
  changedActivities,
  changedTransfers,
  isUnchangedSectionVisible,
  unChangedItemsLength,
  unChangedFlights,
  unChangedHotels,
  unChangedActivities,
  unchangedTransfers,
  changedVisaArray,
  unchangedVisaArray,
  unchangedInsuranceDetail,
  changedInsuranceDetail,
  toggleUnchangedSection,
  blockFlight,
  toggleAEBModal,
  userDetails,
  changedPassArray,
  unchangedPassArray,
  blockFlightLoading,
  isCred
}) => {
  return (
    <div className="clearfix review-table">
      <div className="clearfix fw">
        {changedItemsLength ? (
          <p className="divider-text">Price changed for these bookings</p>
        ) : null}

        <FlightRow
          flightsArray={soldOutFlights}
          blockFlight={blockFlight}
          toggleAEBModal={toggleAEBModal}
          userDetails={userDetails}
          isSoldOut={true}
          blockFlightLoading={blockFlightLoading}
          makeReadOnly={isCred}
        />

        <HotelRow hotelsArray={soldOutHotels} isSoldOut={true} />

        <ActivityRow activitiesArray={soldOutActivities} isSoldOut={true} />

        <FlightRow
          flightsArray={changedFlights}
          blockFlight={blockFlight}
          toggleAEBModal={toggleAEBModal}
          userDetails={userDetails}
          blockFlightLoading={blockFlightLoading}
          makeReadOnly={isCred}
        />

        <HotelRow hotelsArray={changedHotels} />

        <ActivityRow activitiesArray={changedActivities} />

        <TransferRow transfersArray={changedTransfers} />

        <PassRow passArray={changedPassArray} />

        <VisaRow visaArray={changedVisaArray} />

        {!_.isEmpty(changedInsuranceDetail) ? (
          <InsuranceRow insuranceDetail={changedInsuranceDetail} />
        ) : null}
      </div>

      <div className="clearfix fw">
        <button
          type="button"
          className={`btn accord-btn ${
            isUnchangedSectionVisible ? '' : 'collapsed'
          }`}
          onClick={toggleUnchangedSection}
        >
          <span>
            {isUnchangedSectionVisible
              ? 'Unchanged Bookings'
              : 'Review other unchanged bookings'}
          </span>
          {isUnchangedSectionVisible ? null : <i>{unChangedItemsLength}</i>}
        </button>
        <div
          id="unchanged"
          className={`collapse ${isUnchangedSectionVisible ? 'in' : ''}`}
        >
          <FlightRow
            flightsArray={unChangedFlights}
            blockFlight={blockFlight}
            toggleAEBModal={toggleAEBModal}
            userDetails={userDetails}
            blockFlightLoading={blockFlightLoading}
            makeReadOnly={isCred}
          />

          <HotelRow hotelsArray={unChangedHotels} />

          <ActivityRow activitiesArray={unChangedActivities} />

          <TransferRow transfersArray={unchangedTransfers} />

          <PassRow passArray={unchangedPassArray} />

          <VisaRow visaArray={unchangedVisaArray} />

          {!_.isEmpty(unchangedInsuranceDetail) ? (
            <InsuranceRow insuranceDetail={unchangedInsuranceDetail} />
          ) : null}
        </div>
      </div>
    </div>
  );
};

ChangedItemsAccordion.propTypes = {
  changedItemsLength: PropTypes.number.isRequired,
  soldOutHotels: PropTypes.array.isRequired,
  soldOutFlights: PropTypes.array.isRequired,
  soldOutActivities: PropTypes.array.isRequired,
  changedFlights: PropTypes.array.isRequired,
  changedHotels: PropTypes.array.isRequired,
  changedActivities: PropTypes.array.isRequired,
  changedTransfers: PropTypes.array.isRequired,
  isUnchangedSectionVisible: PropTypes.bool.isRequired,
  unChangedItemsLength: PropTypes.number.isRequired,
  unChangedFlights: PropTypes.array.isRequired,
  unChangedHotels: PropTypes.array.isRequired,
  unChangedActivities: PropTypes.array.isRequired,
  unchangedTransfers: PropTypes.array.isRequired,
  changedVisaArray: PropTypes.array.isRequired,
  unchangedVisaArray: PropTypes.array.isRequired,
  unchangedInsuranceDetail: PropTypes.object.isRequired,
  changedInsuranceDetail: PropTypes.object.isRequired,
  toggleUnchangedSection: PropTypes.func.isRequired,
  blockFlight: PropTypes.func.isRequired,
  toggleAEBModal: PropTypes.func.isRequired,
  userDetails: PropTypes.object.isRequired,
  changedPassArray: PropTypes.array.isRequired,
  unchangedPassArray: PropTypes.array.isRequired
};

export default ChangedItemsAccordion;
