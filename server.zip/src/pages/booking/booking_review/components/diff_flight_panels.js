import React, { Component } from 'react';
import _ from 'lodash';
import { getAirlineLogo } from '../../../../helpers/utilsHelper';
import SmartImage from '../../../../common_components/Image/smart_image';

export default class DiffFlightPanels extends Component {
  constructor(props) {
    super(props);

    this.onViewDetailsClick = this.onViewDetailsClick.bind(this);
  }

  onViewDetailsClick(flight) {
    this.props.showThisModal('flight_details_modal', flight);
  }

  onChangeClick(flight, scenerio) {
    flight.scenerio = scenerio;
    this.props.showThisModal('alternate_flights_modal', flight);
  }

  renderRefundabilityUI(refundability) {
    if (refundability) {
      return (
        <p className="v-spaced-5">
          <span className="margin-right-5px text-green vehoicon-refundable" />Refundable
        </p>
      );
    } else {
      return (
        <p className="v-spaced-5">
          <span className="margin-right-5px text-red vehoicon-non-refundable" />{' '}
          Non Refundable
        </p>
      );
    }
  }

  populateAirportCodes(tripDetails) {
    let i = -1;
    return tripDetails.routes.map(route => {
      ++i;
      if (i === 0)
        return (
          <span key={Math.random()}>
            {' '}
            <span>{route.departureAirportCode}</span> <span>⟶</span>{' '}
            <span>{route.arrivalAirportCode}</span>
          </span>
        );
      else
        return (
          <span key={Math.random()}>
            {' '}
            <span>⟶</span> <span>{route.arrivalAirportCode}</span>
          </span>
        );
    });
  }

  getConnectionDurationAndStopsCount(duration, r) {
    let stops = '';
    if (r.length - 1 === 0) stops = 'Direct';
    else if (r.length - 1 === 0) stops = `${r.length - 1} stop`;
    else stops = `${r.length - 1} stops`;

    let durHours = Math.floor(duration / 60);
    let durMinutes = duration % 60;

    if (durHours !== 0)
      return { stops: stops, duration: `${durHours}h ${durMinutes}m` };
    else return { stops: stops, duration: `${durMinutes}m` };
  }

  renderTripList(flight) {
    return flight.allTrips.map(tripId => {
      let trip = flight.trips[tripId];
      let lastRoute = trip.routes.length - 1;
      let divider_line = '';
      if (flight.allTrips.indexOf(tripId) + 1 !== flight.allTrips.length) {
        divider_line = (
          <div className="v-spaced col-xs-12">
            <div
              className="col-xs-12"
              style={{ borderTop: '1px dashed #ddd' }}
            />
          </div>
        );
      }

      const airlineImg = getAirlineLogo(flight.airlineCode);

      return (
        <div className="row" key={tripId}>
          <div className="col-xs-12 col-md-8">
            <p className="medium-bold txt-size-sm no-v-margin">
              {' '}
              {trip.routes[0].departureCity}
              to {trip.routes[lastRoute].arrivalCity}{' '}
            </p>
            <p className="text-grey medium-bold airline-codes">
              <span>{this.populateAirportCodes(trip)}</span>
            </p>
          </div>
          <div className="col-xs-4 col-xs-offset-4 col-md-offset-1 col-md-3">
            <SmartImage
              width="100px"
              defaultImage={airlineImg.default}
              src={airlineImg.url}
              alt={airlineImg.name}
            />
          </div>

          <div className="col-xs-12">
            <div className="row">
              <div className="col-xs-3 col-md-4">
                <p className="regular text-grey">
                  {trip.mon} {trip.day},{' '}
                  {trip.routes[0].departureTime.substring(0, 5)}
                </p>
                <p className="small text-grey margin-top-5">
                  {trip.routes[0].departureAirportCode}
                </p>
              </div>
              <div className="col-xs-3 col-md-3">
                <div className="row text-center">
                  {/* <span className="spaced-span txt-size-md text-grey vehoicon-ion-android-time" /> */}
                  <p className="regular text-grey">
                    {
                      this.getConnectionDurationAndStopsCount(
                        trip.duration,
                        trip.routes
                      ).stops
                    }
                  </p>
                  <p className="small text-grey margin-top-5">
                    {
                      this.getConnectionDurationAndStopsCount(
                        trip.duration,
                        trip.routes
                      ).duration
                    }
                  </p>
                </div>
              </div>
              <div className="col-xs-3 col-md-3 col-md-offset-2 col-xs-offset-0">
                <p className="regular text-grey">
                  {trip.routes[lastRoute].arrivalTime.substring(0, 5)}
                </p>
                <p className="small text-grey margin-top-5">
                  {trip.routes[lastRoute].arrivalAirportCode}
                </p>
                <p>
                  {/*<span className="label label-default">NEXT DAY</span> */}
                </p>
              </div>
              {divider_line}
            </div>
          </div>
        </div>
      );
    });
  }

  render() {
    let { packageRate, flight, flightId, diffObj } = this.props;

    let firstTripKey = flight.allTrips[0];
    let baggage_line = null;
    if (
      flight.trips[firstTripKey].routes[0].freeCheckInBaggage.toString()
        .length > 0
    ) {
      baggage_line = (
        <p className="clear-margin">
          <span className="margin-right-5px vehoicon-suitcase" />
          {flight.trips[firstTripKey].routes[0].freeCheckInBaggage}
        </p>
      );
    }

    return (
      <div key={flightId} className="row">
        <div
          className={
            'col-xs-12 text-left ' +
            (packageRate
              ? 'border-bottom no-border-radius border-light-grey'
              : '')
          }
        >
          <div className="row messaging-container">
            {/*<div className="col-xs-12"><p><span className="tag">RARE FIND</span> <span className="message">Flights in this route could go upto 3% expensive in the coming months. Book this flight now!</span></p></div> */}
          </div>
          <div className={'row v-spaced ' + (packageRate ? 'spaced-5' : '')}>
            <div className="col-md-9 col-xs-12">
              {diffObj.elementChangeType !== 'NONE' ? (
                <p className="clear-margin">
                  <span className="block oj-text-grey txt-size-xs margin-bottom-10 ">
                    Previously on {diffObj.oldFlightName}
                  </span>
                  <span className="btn btn-border-only change-to-btn txt-size-8 v-spaced-5">
                    Change to
                  </span>
                </p>
              ) : null}
              {this.renderTripList(flight)}
            </div>
            <div className="col-sm-12 col-md-3 no-padding">
              <div className="row">
                <div className="col-xs-12 hidden-xs hidden-sm">
                  <div className="row">
                    {!this.props.hidePrice ? (
                      <div
                        className={
                          'col-xs-5 col-md-12 ' + (packageRate ? 'hidden' : '')
                        }
                      >
                        {diffObj.priceChangeType !== 'NONE' ? (
                          <span className="block oj-text-grey txt-size-xs text-strickthough">
                            <span className="WebRupee">Rs.</span>{' '}
                            {diffObj.oldFlightCost}
                          </span>
                        ) : null}
                        <h3 className="no-v-margin oj-text-black bottom-margin-10">
                          <span className="WebRupee">Rs.</span> {flight.price}{' '}
                        </h3>
                      </div>
                    ) : null}
                    <div className="col-md-12">
                      <p className="clear-margin">
                        <span className="margin-right-5px vehoicon-airline_seat_recline_extra" />
                        {_.capitalize(flight.flightClass)}
                      </p>
                      {this.renderRefundabilityUI(flight.refundable)}
                      {baggage_line}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
