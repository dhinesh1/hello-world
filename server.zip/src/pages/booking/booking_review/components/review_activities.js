import React, { Component } from 'react';
import ActivitiesRow from './review_activities_row';
import { isEmpty } from 'lodash';

export default class ReviewActivities extends Component {
  renderActivitiesPanels() {
    let activityDiffCostingObj = this.props.itineraryDetail.totalDiff
      .activityDiffContainer.activityDiffCostingById;

    let inxPaidCount = 0;
    let inxFreeCount = 0;
    let isFree = this.props.selfExploration;

    return this.props.itineraryDetail.allActivityCostingRefs.map(
      (activityId, inx) => {
        let activityCostingDetails = this.props.itineraryDetail.activityCostings
          .activityCostingById[activityId];
        let activityDetailId = activityCostingDetails.activityId;
        let activityDiff =
          activityDiffCostingObj && activityDiffCostingObj[activityId];
        let activityDetails = this.props.itineraryDetail.activityById[
          activityDetailId
        ];
        // if the costing status is not success or costing not available
        // we are not showing the activity in the booking review
        if (
          !activityCostingDetails ||
          activityCostingDetails.status !== 'SUCCESS'
        ) {
          return null;
        }
        if (
          (isFree && activityDetails.free) ||
          (!isFree && !activityDetails.free)
        ) {
          inxFreeCount =
            isFree && activityDetails.free ? inxFreeCount + 1 : inxFreeCount;
          inxPaidCount =
            !isFree && !activityDetails.free ? inxPaidCount + 1 : inxPaidCount;

          return (
            <ActivitiesRow
              allSlot={this.props.allSlot}
              inx={isFree ? inxFreeCount : inxPaidCount}
              key={'review_' + activityCostingDetails.activityId}
              {...this.props}
              activityDetails={activityDetails}
              activityDiff={activityDiff}
              activityCostingDetails={activityCostingDetails}
              activityId={activityId}
            />
          );
        }
      }
    );
  }

  render() {
    if (!isEmpty(this.props.itineraryDetail)) {
      let totalDiff = this.props.itineraryDetail.totalDiff;

      return (
        <div className="col-xs-12 no-padding">
          {this.renderActivitiesPanels()}

          {!this.props.hidePrice && !this.props.selfExploration ? (
            <div className="row">
              <div className="col-xs-12 no-padding v-spaced-5">
                <div className="col-sm-7 col-xs-7">
                  <div className="pull-left margin-left-40 margin-left-20-mobile">
                    <span className="title oj-text-black txt-size-sm">
                      Total cost of Activities
                    </span>
                  </div>
                </div>
                <div className="col-xs-5 col-sm-5 text-right">
                  <p className="txt-size-md clear-margin inline-block oj-text-black font-rounded-variant">
                    <span className="WebRupee">Rs.</span>{' '}
                    {
                      this.props.itineraryDetail.activityCostings
                        .totalPublishedCost
                    }
                  </p>
                  <span
                    className={
                      'txt-size-xs block oj-text-grey ' +
                      (totalDiff &&
                      totalDiff.activityDiffContainer &&
                      totalDiff.activityDiffContainer.priceChangeType !== 'NONE'
                        ? ''
                        : 'no-visibility')
                    }
                  >
                    <span
                      className={
                        'txt-size-sm ' +
                        (totalDiff.activityDiffContainer.priceChangeType ===
                        'PRICEINCREASE'
                          ? 'text-red vehoicon-arrow-up'
                          : 'vehoicon-arrow-down text-green')
                      }
                    />
                    <span className="WebRupee">Rs.</span>{' '}
                    {totalDiff.activityDiffContainer.priceChangeType ===
                    'PRICEINCREASE'
                      ? '+'
                      : '-'}{' '}
                    {totalDiff.activityDiffContainer.totalActivityCostChange}
                  </span>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      );
    } else {
      return <div> No content </div>;
    }
  }
}
