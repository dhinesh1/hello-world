import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import FlightRow from './flight_row';
import HotelRow from './hotel_row';
import ActivityRow from './activity_row';
import TransferRow from './transfer_row';
import PassRow from './pass_row';
import VisaRow from './visa_row';
import InsuranceRow from './insurance_row';

const UnchangedItemsAccordion = ({
  isUnchangedSectionVisible,
  unChangedItemsLength,
  unChangedFlights,
  unChangedHotels,
  unChangedActivities,
  unchangedTransfers,
  unchangedVisaArray,
  unchangedInsuranceDetail,
  toggleUnchangedSection,
  blockFlight,
  toggleAEBModal,
  userDetails,
  unchangedPassArray,
  blockFlightLoading,
  isCred
}) => {
  let visibleItems = [];
  const visibleElement = [];
  unChangedFlights = [...unChangedFlights];
  unChangedHotels = [...unChangedHotels];
  unChangedActivities = [...unChangedActivities];
  unchangedPassArray = [...unchangedPassArray];

  if (visibleItems.length < 2) {
    const flights = unChangedFlights.splice(0, 2 - visibleItems.length);
    visibleItems = visibleItems.concat(flights);
    visibleElement.push(
      <FlightRow
        key={0}
        flightsArray={flights}
        userDetails={userDetails}
        toggleAEBModal={toggleAEBModal}
        blockFlight={blockFlight}
        blockFlightLoading={blockFlightLoading}
        makeReadOnly={isCred}
      />
    );
  }

  if (visibleItems.length < 2) {
    const hotels = unChangedHotels.splice(0, 2 - visibleItems.length);
    visibleItems = visibleItems.concat(hotels);
    visibleElement.push(<HotelRow key={1} hotelsArray={hotels} />);
  }

  if (visibleItems.length < 2) {
    const activities = unChangedActivities.splice(0, 2 - visibleItems.length);
    visibleElement.push(<ActivityRow key={2} activitiesArray={activities} />);
  }

  if (visibleItems.length < 2) {
    const passes = unchangedPassArray.splice(0, 2 - visibleItems.length);
    visibleElement.push(<PassRow key={3} passArray={passes} />);
  }

  if (visibleItems.length < 2) {
    const visas = unchangedVisaArray.splice(0, 2 - visibleItems.length);
    visibleElement.push(<VisaRow key={4} visaArray={visas} />);
  }

  return (
    <div className="clearfix review-table">
      <div className="clearfix fw">{visibleElement}</div>

      {unChangedItemsLength - visibleItems.length > 0 ? (
        <div className="clearfix fw">
          <button
            type="button"
            className={`btn accord-btn ${
              isUnchangedSectionVisible ? '' : 'collapsed'
            }`}
            onClick={toggleUnchangedSection}
          >
            <span>{isUnchangedSectionVisible ? 'Show less' : 'Show more'}</span>
            {isUnchangedSectionVisible ? null : (
              <i>{unChangedItemsLength - visibleItems.length}</i>
            )}
          </button>
          <div
            id="unchanged"
            className={`collapse ${isUnchangedSectionVisible ? 'in' : ''}`}
          >
            <FlightRow
              flightsArray={unChangedFlights}
              blockFlight={blockFlight}
              toggleAEBModal={toggleAEBModal}
              userDetails={userDetails}
              blockFlightLoading={blockFlightLoading}
              makeReadOnly={isCred}
            />

            <HotelRow hotelsArray={unChangedHotels} />

            <ActivityRow activitiesArray={unChangedActivities} />

            <TransferRow transfersArray={unchangedTransfers} />

            <PassRow passArray={unchangedPassArray} />

            <VisaRow visaArray={unchangedVisaArray} />

            {!_.isEmpty(unchangedInsuranceDetail) ? (
              <InsuranceRow insuranceDetail={unchangedInsuranceDetail} />
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  );
};

UnchangedItemsAccordion.propTypes = {
  isUnchangedSectionVisible: PropTypes.bool.isRequired,
  unChangedItemsLength: PropTypes.number.isRequired,
  unChangedFlights: PropTypes.array.isRequired,
  unChangedHotels: PropTypes.array.isRequired,
  unChangedActivities: PropTypes.array.isRequired,
  unchangedTransfers: PropTypes.array.isRequired,
  unchangedVisaArray: PropTypes.array.isRequired,
  unchangedInsuranceDetail: PropTypes.object.isRequired,
  toggleUnchangedSection: PropTypes.func.isRequired,
  blockFlight: PropTypes.func.isRequired,
  toggleAEBModal: PropTypes.func.isRequired,
  userDetails: PropTypes.object.isRequired,
  unchangedPassArray: PropTypes.array.isRequired
};

export default UnchangedItemsAccordion;
