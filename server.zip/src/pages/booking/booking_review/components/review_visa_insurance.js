import React, { Component } from 'react';
import { sumBy, isEmpty } from 'lodash';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import { loadModalLinks } from '../../../../actions/actions_app';
import { bindActionCreators } from 'redux';
import { encodeCostingKeyForURL } from '../../../../helpers/utilsHelper';

class ReviewVisaInsurance extends Component {
  constructor(props) {
    super(props);

    this.renderVisa.bind(this);
    this.renderInsurance.bind(this);
    this.renderVisaText.bind(this);
    this.renderTotalVisaInsuranceCostSection.bind(this);
  }

  getPaxConfig(itineraryCostingConfiguration) {
    let hotel_conf = itineraryCostingConfiguration.hotelGuestRoomConfigurations;
    let adult_count = sumBy(hotel_conf, 'adultCount') || 0;
    let child_count =
      sumBy(hotel_conf, function(ch) {
        return ch.childAges && ch.childAges.length;
      }) || 0;
    return { adultCount: adult_count, childCount: child_count };
  }

  renderVisaText(option, inx) {
    let { adultCount, childCount } = this.getPaxConfig(
      this.props.itineraryDetail.costingConfiguration
    );
    let totalPax = adultCount + childCount;

    if (option.required) {
      if (option.onArrival) {
        return (
          <div className="col-xs-12 no-padding v-spaced-5">
            <div className="col-sm-9 col-xs-8">
              <div className="col-xs-1 no-padding width-40 width-20-mobile">
                <span className="spaced-span txt-size-xs">{inx + 1}.</span>
              </div>
              <div className="col-xs-10 col-sm-11 no-padding">
                <span className="title oj-text-black txt-size-xs">
                  Visa fees for {option.country}
                </span>
                <span className="txt-size-xs block oj-text-black">
                  Purchase Visa on arrival.
                </span>
              </div>
            </div>
            {!this.props.hidePrice ? (
              <div className="col-xs-4 col-sm-3 text-right">
                <p className="txt-size-sm clear-margin inline-block oj-text-black font-default no-visibility">
                  <span className="WebRupee">Rs.</span>
                </p>
              </div>
            ) : null}
          </div>
        );
      } else if (option.schengen) {
        return (
          <div className="col-xs-12 no-padding v-spaced-5">
            <div className="col-sm-9 col-xs-8">
              <div className="col-xs-1 no-padding width-40 width-20-mobile">
                <span className="spaced-span txt-size-xs">{inx + 1}.</span>
              </div>
              <div className="col-xs-10 col-sm-11 no-padding">
                <span className="title oj-text-black txt-size-xs">
                  Guidance fees for {option.country} visa
                </span>
              </div>
            </div>
            {!this.props.hidePrice ? (
              <div className="col-xs-4 col-sm-3 text-right">
                <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
                  <span className="WebRupee">Rs.</span> {option.totalCost}
                </p>
              </div>
            ) : null}
          </div>
        );
      } else {
        return (
          <div className="col-xs-12 no-padding v-spaced-5">
            <div className="col-sm-9 col-xs-8">
              <div className="col-xs-1 no-padding width-40 width-20-mobile">
                <span className="spaced-span txt-size-xs">{inx + 1}.</span>
              </div>
              <div className="col-xs-10 col-sm-11 no-padding">
                <span className="title oj-text-black txt-size-xs">
                  Visa fees for {option.country}
                </span>
                <span className="txt-size-xs block oj-text-black">
                  Visa for{' '}
                  {totalPax + (totalPax > 1 ? ' travellers' : ' traveller')}
                </span>
              </div>
            </div>
            {!this.props.hidePrice ? (
              <div className="col-xs-4 col-sm-3 text-right">
                <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
                  <span className="WebRupee">Rs.</span> {option.totalCost}
                </p>
              </div>
            ) : null}
          </div>
        );
      }
    } else {
      return (
        <div className="col-xs-12 no-padding v-spaced-5">
          <div className="col-sm-9 col-xs-8">
            <div className="col-xs-1 no-padding width-40 width-20-mobile">
              <span className="spaced-span txt-size-xs no-visibility">
                {inx + 1}.
              </span>
            </div>
            <div className="col-xs-10 col-sm-11 no-padding">
              <span className="title oj-text-black txt-size-xs">
                Visa not included
              </span>
            </div>
          </div>
          {!this.props.hidePrice ? (
            <div className="col-xs-4 col-sm-3 text-right">
              <p className="txt-size-sm clear-margin inline-block oj-text-black font-default no-visibility">
                <span className="WebRupee">Rs.</span>
              </p>
            </div>
          ) : null}
        </div>
      );
    }
  }

  renderVisa() {
    let { allVisaCostingRefs } = this.props.itineraryDetail;
    return allVisaCostingRefs.map((option, inx) => {
      let visaCostingById = this.props.itineraryDetail.visaCostings
        .visaCostingById[option];

      return (
        <NavLink to={`/${this.props.itineraryId}/bookingReview/visa-details`}>
          <div className="row" key={'visa_block_' + inx}>
            {this.renderVisaText(visaCostingById, inx)}
            <div className="col-xs-12">
              <div className="margin-left-40 margin-left-20-mobile">
                <hr className="v-spaced" />
              </div>
            </div>
          </div>
        </NavLink>
      );
    });
  }

  renderTotalVisaInsuranceCostSection(visaCostings) {
    return (
      <div className="row">
        <div className="col-xs-12 no-padding v-spaced-5">
          <div className="col-sm-7 col-xs-7">
            <div className="pull-left margin-left-40 margin-left-20-mobile">
              <span className="title oj-text-black txt-size-sm">
                Total cost of Visa and Insurance
              </span>
            </div>
          </div>
          {!this.props.hidePrice ? (
            <div className="col-xs-5 col-sm-5 text-right">
              <p className="txt-size-md clear-margin inline-block oj-text-black font-rounded-variant">
                <span className="WebRupee">Rs.</span>{' '}
                {visaCostings.totalVisaInsuranceCost}
              </p>
              <span className="txt-size-xs block oj-text-grey no-visibility">
                <span className="vehoicon-arrow_downward text-danger" />{' '}
                <span className="WebRupee">Rs.</span> + 1000
              </span>
            </div>
          ) : null}
        </div>
      </div>
    );
  }

  renderInsurance(insuranceCosting) {
    let { insuranceCostingById } = insuranceCosting;
    let count = this.props.itineraryDetail.allVisaCostingRefs.length + 1;
    let { adultCount, childCount } = this.getPaxConfig(
      this.props.itineraryDetail.costingConfiguration
    );

    this.props.loadModalLinks({
      key: 'insurance-details',
      url: `/${this.props.itineraryId}/bookingReview/insurance-details`
    });

    if (insuranceCostingById.required) {
      return (
        <NavLink
          to={`/${this.props.itineraryId}/bookingReview/insurance-details`}
        >
          <div className="row">
            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-9 col-xs-8">
                <div className="col-xs-1 no-padding width-40 width-20-mobile">
                  <span className="spaced-span txt-size-xs">{count}.</span>
                </div>
                <div className="col-xs-10 col-sm-11 no-padding">
                  <span className="title oj-text-black txt-size-xs">
                    Traveller Insurance for{' '}
                    {insuranceCostingById.countries.join(', ')}
                    ({insuranceCostingById.plan})
                  </span>
                  <span className="txt-size-xs block oj-text-black">
                    Traveller Insurance for{' '}
                    {adultCount + (adultCount > 1 ? ' adults' : ' adult')}{' '}
                    {childCount > 0
                      ? ', ' + childCount + (childCount > 1 ? ' kids' : ' kid')
                      : null},{' '}
                    {!this.props.hidePrice
                      ? 'Inclusive of all taxes and fees.'
                      : ''}
                  </span>
                </div>
              </div>
              {!this.props.hidePrice ? (
                <div className="col-xs-4 col-sm-3 text-right">
                  <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
                    <span className="WebRupee">Rs.</span>{' '}
                    {insuranceCosting && insuranceCosting.totalInsuranceCost}
                  </p>
                </div>
              ) : null}
            </div>
            <div className="col-xs-12">
              <div className="margin-left-40 margin-left-20-mobile">
                <hr className="v-spaced" />
              </div>
            </div>
          </div>
        </NavLink>
      );
    } else {
      return (
        <NavLink
          to={`/${this.props.itineraryId}/bookingReview/insurance-details`}
        >
          <div className="row">
            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-9 col-xs-8">
                <div className="col-xs-1 no-padding width-40 width-20-mobile">
                  <span className="spaced-span txt-size-xs no-visibility">
                    {count}.
                  </span>
                </div>
                <div className="col-xs-10 col-sm-11 no-padding">
                  <span className="title oj-text-black txt-size-xs">
                    Traveller Insurance not included
                  </span>
                </div>
              </div>
              {!this.props.hidePrice ? (
                <div className="col-xs-4 col-sm-3 text-right">
                  <p className="txt-size-sm clear-margin inline-block oj-text-black font-default no-visibility">
                    <span className="WebRupee">Rs.</span>{' '}
                    {insuranceCosting.totalInsuranceCost}
                  </p>
                </div>
              ) : null}
            </div>
            <div className="col-xs-12">
              <div className="margin-left-40 margin-left-20-mobile">
                <hr className="v-spaced" />
              </div>
            </div>
          </div>
        </NavLink>
      );
    }
  }

  render() {
    if (!isEmpty(this.props.itineraryDetail)) {
      let { insuranceCosting, visaCostings } = this.props.itineraryDetail;
      return (
        <div className="col-xs-12 no-padding">
          {this.renderVisa()}
          {this.renderInsurance(insuranceCosting)}
          {!this.props.hidePrice && visaCostings.totalVisaInsuranceCost > 0
            ? this.renderTotalVisaInsuranceCostSection(visaCostings)
            : null}
        </div>
      );
    } else {
      return <div> No content </div>;
    }
  }
}

const mapStateToProps = state => {
  const itineraryDetails = state.app.itineraryInfo.itineraryDetails;
  const itineraryId = itineraryDetails
    ? itineraryDetails.itinerary.itineraryId
    : '';
  return {
    itineraryId
  };
};

const mapDispatchToProps = dispatch => {
  return {
    loadModalLinks: bindActionCreators(loadModalLinks, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(
  ReviewVisaInsurance
);
