import React, { Component } from 'react';
import { Tabs, Tab } from 'react-bootstrap';

import { map, values, isEmpty } from 'lodash';

export default class HotelSingleRoom extends Component {
  constructor(props) {
    super(props);

    this.state = { activeKey: -1 };

    this.handleTabSelect = this.handleTabSelect.bind(this);
    this.renderRoomCosts = this.renderRoomCosts.bind(this);
  }

  handleTabSelect(index) {
    if (this.state.activeKey === index) {
      index = -1;
    }

    this.setState({
      activeKey: index
    });
  }

  showInclusions(values) {
    let inclusions = values.map(option => {
      return (
        <span key={'inclusions_' + option} className="block">
          {' '}
          - {option}
        </span>
      );
    });

    return <div className="v-spaced-5">{inclusions}</div>;
  }

  renderRoomCosts() {
    let { roomDetails } = this.props;

    if (roomDetails.rateForDifferentDays) {
      return roomDetails.rateForDifferentDays.map((option, r_inx) => {
        return (
          <div key={option + '_' + r_inx} className="col-xs-12 no-padding">
            <div className="col-xs-8 no-padding margin-top-5">
              <span className="txt-size-xxs block oj-text-grey">
                Night {r_inx + 1}
              </span>
            </div>
            <div className="col-xs-4 no-padding margin-top-5 text-right">
              <span className="txt-size-xxs block oj-text-grey">
                <span className="WebRupee">Rs.</span> {option}
              </span>
            </div>
          </div>
        );
      });
    }
  }

  renderSurCharges() {
    let { roomDetails } = this.props;

    let allSurcharges = roomDetails.surcharges.map((option, r_inx) => {
      return (
        <div key={option.price + '_' + r_inx} className="col-xs-12 no-padding">
          <div className="col-xs-8 no-padding">
            <span className="txt-size-xxs block oj-text-grey">
              {option.type}
            </span>
          </div>
          <div className="col-xs-4 no-padding text-right">
            <span className="txt-size-xxs block oj-text-grey">
              <span className="WebRupee">Rs.</span> {option.price}
            </span>
          </div>
        </div>
      );
    });

    return (
      <div>
        {allSurcharges}
        <div className="col-xs-12 no-padding">
          <hr className="v-spaced-5 border-bottom border-light-grey border-dotted" />
        </div>
      </div>
    );
  }

  createMarkup(data) {
    return { __html: data };
  }

  render() {
    let { roomDetails, inx, isLast, packageRate, hidePrice } = this.props;

    let roomConfiguration = roomDetails.roomConfiguration;
    let adults = roomConfiguration.adultCount;
    let childs =
      (roomConfiguration.childAges && roomConfiguration.childAges.length) || 0;
    let childAges = '';

    roomConfiguration = ' ' + adults + (adults > 1 ? ' Adults ' : ' Adult ');
    if (childs > 0) {
      roomConfiguration +=
        ', ' + childs + (childs === 1 ? ' child' : ' children');

      childAges = map(roomDetails.roomConfiguration.childAges, function(o) {
        return o + ' Years';
      });
      childAges = childAges.join(' and ');

      roomConfiguration += ' (' + childAges + ')';
    }

    let valueAddsMap = values(roomDetails.valueAddsMap);

    return (
      <div className="col-xs-12">
        <div className="col-xs-12 col-sm-6 margin-top-10 margin-bottom">
          <div className="col-xs-12 v-spaced-5 no-padding">
            <span className="txt-size-xxs block oj-text-grey">
              ROOM - {inx + 1}
            </span>
            <span className="txt-size-xxs block oj-text-black">
              {roomDetails.name}
            </span>
          </div>
          <div className="col-xs-12 v-spaced-5 no-padding">
            <span className="txt-size-xxs block oj-text-grey">
              BED TYPE
              <span
                className="veho-info-icon font-rounded-variant spaced-span"
                data-title="Bed type choice is request only and depends on availability at hotel"
                data-toggle="tooltip"
              >
                i
              </span>
            </span>
            <span className="txt-size-xxs block oj-text-black">
              {roomDetails.bedTypes.join(' & ')}
            </span>
          </div>
          <div className="col-xs-12 v-spaced-5 no-padding">
            <span className="txt-size-xxs block oj-text-grey">
              GUEST DETAILS
            </span>
            <span className="txt-size-xxs block oj-text-black">
              {roomConfiguration}
            </span>
          </div>
          <div
            className={
              'col-xs-12 v-spaced-5 no-padding ' +
              (valueAddsMap.length === 0 ? 'hidden' : '')
            }
          >
            <span className="txt-size-xxs block oj-text-grey">INCLUSIONS</span>
            <span className="txt-size-xxs block oj-text-black">
              {this.showInclusions(valueAddsMap)}
            </span>
          </div>
          {roomDetails.mandatoryTax && roomDetails.mandatoryTax !== '' ? (
            <div className="col-xs-12 v-spaced-5 no-padding ">
              <span className="txt-size-xxs block oj-text-grey">
                Mandatory Tax (To be paid at Hotel)
              </span>
              <span className="txt-size-xxs block oj-text-black">
                <span className="WebRupee">Rs.</span> {roomDetails.mandatoryTax}
              </span>
            </div>
          ) : null}
        </div>

        {!packageRate && !hidePrice ? (
          <div className="col-xs-12 col-sm-6 margin-top-10">
            <div className="col-xs-12 no-padding">
              <span>COST BREAK UP</span>
            </div>
            <div className="col-xs-12 no-padding">
              <hr className="v-spaced-5 border-bottom border-light-grey" />
            </div>

            <div className="col-xs-12 no-padding">
              <div className="col-xs-8 no-padding">
                <span className="txt-size-xxs block oj-text-grey">
                  Average/night for{' '}
                  {roomDetails.rateForDifferentDays
                    ? roomDetails.rateForDifferentDays.length
                    : 0}{' '}
                  Nights
                </span>
              </div>
              <div className="col-xs-4 no-padding text-right">
                <span className="txt-size-xxs block oj-text-grey">
                  <span className="WebRupee">Rs.</span>{' '}
                  {roomDetails.averageRoomPrice}
                </span>
              </div>

              {this.renderRoomCosts()}
            </div>

            <div className="col-xs-12 no-padding hidden">
              <div className="col-xs-8 no-padding">
                <span className="txt-size-xxs block oj-text-grey">
                  Extra Person Fee (Per night)
                </span>
              </div>
              <div className="col-xs-4 no-padding text-right">
                <span className="txt-size-xxs block oj-text-grey">
                  <span className="WebRupee">Rs.</span> 4310.98
                </span>
              </div>
            </div>

            <div className="col-xs-12 no-padding">
              <hr className="v-spaced-5 border-bottom border-light-grey border-dotted" />
            </div>

            {this.renderSurCharges()}

            <div className="col-xs-12 no-padding">
              <div className="col-xs-8 no-padding">
                <span className="txt-size-xxs block oj-text-grey">
                  Total cost
                </span>
              </div>
              <div className="col-xs-4 no-padding text-right">
                <span className="txt-size-xxs block oj-text-grey">
                  <span className="WebRupee">Rs.</span>{' '}
                  {roomDetails.originalPrice}
                </span>
              </div>
            </div>

            <div className="col-xs-12 no-padding">
              <hr className="v-spaced-5 border-bottom border-light-grey border-dotted" />
            </div>

            <div className="col-xs-12 no-padding">
              <div className="col-xs-12 no-padding v-spaced-5 no-top-margin">
                <span
                  className={
                    'margin-right-5px ' +
                    (roomDetails.refundable
                      ? 'vehoicon-refundable text-green'
                      : 'vehoicon-non-refundable text-red')
                  }
                />
                <span className="txt-size-xxs oj-text-grey">
                  {roomDetails.refundable ? '' : 'Non'}Refundable
                </span>
                {roomDetails.refundable ? (
                  <span className="txt-size-xxs block oj-text-grey">
                    ({roomDetails.shortCancellationPolicy})
                  </span>
                ) : null}
              </div>
            </div>
          </div>
        ) : null}

        <div className="col-xs-12 col-sm-12 margin-top-10">
          <Tabs
            onSelect={this.handleTabSelect}
            activeKey={this.state.activeKey}
            className="oj-small-tabs transport-bg no-border-tabs"
            id="hotel-details-tab"
          >
            {/*
            <Tab eventKey={1} title={<span className="blue-text">Cancellation Policy</span>}>
              <div className="row">
                <div className="col-xs-12 txt-size-xs">
                  {!isEmpty(roomDetails.cancellationPolicy) ?
                    <span className="line-height-1-5 oj-text-grey block v-spaced-5">{roomDetails.cancellationPolicy}</span>
                    :<span className="line-height-1-5 oj-text-grey block v-spaced-5">
                      Please get in touch with us for any cancellation.
                    </span>
                  }
                </div>
              </div>
            </Tab> */}

            <Tab
              eventKey={1}
              title={<span className="blue-text">Check In Policy</span>}
            >
              <div className="row">
                <div className="col-xs-12 txt-size-xs">
                  {!isEmpty(roomDetails.checkInInstructions) ? (
                    <span
                      className="line-height-1-5 oj-text-grey block v-spaced-5"
                      dangerouslySetInnerHTML={this.createMarkup(
                        roomDetails.checkInInstructions
                      )}
                    />
                  ) : (
                    <span className="line-height-1-5 oj-text-grey block v-spaced-5">
                      No Check In Policy
                    </span>
                  )}
                </div>
              </div>
            </Tab>

            <Tab
              eventKey={2}
              title={<span className="blue-text">Special Check In Policy</span>}
            >
              <div className="row">
                <div className="col-xs-12 txt-size-xs">
                  {!isEmpty(roomDetails.specialCheckInInstructions) ? (
                    <span
                      className="line-height-1-5 oj-text-grey block v-spaced-5"
                      dangerouslySetInnerHTML={this.createMarkup(
                        roomDetails.specialCheckInInstructions
                      )}
                    />
                  ) : (
                    <span className="line-height-1-5 oj-text-grey block v-spaced-5">
                      No Special Check In Policy
                    </span>
                  )}
                </div>
              </div>
            </Tab>
          </Tabs>
        </div>

        <div className="col-xs-12 no-padding">
          {isLast ? (
            <span className="v-spaced block" />
          ) : (
            <hr className="v-spaced border-bottom border-light-grey" />
          )}
        </div>
      </div>
    );
  }
}
