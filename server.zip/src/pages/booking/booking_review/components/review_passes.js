import React, { Component } from 'react';
import _ from 'lodash';
import { Tabs, Tab } from 'react-bootstrap';

export default class ReviewPasses extends Component {
  constructor(props) {
    super(props);

    this.state = { activeKey: -1 };

    this.renderActivityInclusions = this.renderActivityInclusions.bind(this);
    this.renderSinglePass = this.renderSinglePass.bind(this);
    this.renderAllPasses = this.renderAllPasses.bind(this);
    this.renderSingleActivityInclusion = this.renderSingleActivityInclusion.bind(
      this
    );
    this.getActivityCostingObject = this.getActivityCostingObject.bind(this);
    this.getActivityObject = this.getActivityObject.bind(this);
    this.handleDetailsClick = this.handleDetailsClick.bind(this);
    this.renderSingleTransferInclusion = this.renderSingleTransferInclusion.bind(
      this
    );
    this.getTransferObject = this.getTransferObject.bind(this);
    this.renderSingleOtherInclusion = this.renderSingleOtherInclusion.bind(
      this
    );
    this.renderTrainInclusions = this.renderTrainInclusions.bind(this);
    this.renderSingleTrainInclusion = this.renderSingleTrainInclusion.bind(
      this
    );
    this.renderOtherInclusions = this.renderOtherInclusions.bind(this);
    this.getFerryObject = this.getFerryObject.bind(this);
    this.renderTransferInclusions = this.renderTransferInclusions.bind(this);
    this.renderFerryInclusions = this.renderFerryInclusions.bind(this);
    this.renderSingleFerryInclusion = this.renderSingleFerryInclusion.bind(
      this
    );
    this.handleTabSelect = this.handleTabSelect.bind(this);
  }

  handleTabSelect(index) {
    if (this.state.activeKey === index) {
      index = -1;
    }

    this.setState({
      activeKey: index
    });
  }

  handleDetailsClick(activityDetails, action, evt) {
    evt.preventDefault();
    evt.stopPropagation();
    evt.nativeEvent.stopImmediatePropagation();

    let activityDetailId = activityDetails.planningToolId;

    let slot = _.find(this.props.allSlot, function(slots) {
      return (
        slots.activitySlotDetail &&
        slots.activitySlotDetail.activityId === activityDetailId
      );
    });

    if (typeof slot !== 'undefined') {
      slot.slotIdentifier = _.findKey(this.props.allSlot, slot);
      _.assign(slot.activitySlotDetail, activityDetails);

      // identified slot - get days which has the slot
      let day_ref = _.findKey(this.props.allDays, function(days) {
        return (
          days.allSlotKeys &&
          _.indexOf(days.allSlotKeys, slot.slotIdentifier) !== -1
        );
      });

      if (typeof day_ref !== 'undefined') {
        let day_obj = this.props.allDays[day_ref];
        day_obj.month = day_obj.mon;
        day_obj.dayIdentifier = day_ref;
        _.assign(slot, _.omit(day_obj, ['mon']));

        // identified slot - get days which has the slot
        let city_info = _.find(this.props.allCities, function(city) {
          return (
            city.allDayKeys &&
            _.indexOf(city.allDayKeys, slot.dayIdentifier) !== -1
          );
        });

        if (typeof city_info !== 'undefined') {
          slot.cityId = city_info.cityId;
        }
      }
    }

    switch (action) {
      case 'VIEW':
        this.props.showThisModal('activity_details_modal', slot);
        break;
      case 'CHANGE':
        this.props.getAlternateActivites(slot);
        break;
      default:
        break;
    }
  }

  getActivityCostingObject(costedItinerary, activityCostingRef) {
    return costedItinerary.activityCostings.activityCostingById[
      activityCostingRef
    ];
  }

  getActivityObject(costedItinerary, activityId) {
    return costedItinerary.activityById[activityId];
  }

  getTransferObject(costedItinerary, transferId) {
    return costedItinerary.transferCostings.transferCostingById[transferId];
  }

  getFerryObject(costedItinerary, ferryId) {
    return costedItinerary.ferryCostings.ferryCostingById[ferryId];
  }

  getTrainObject(costedItinerary, trainId) {
    return costedItinerary.trainCostings.trainCostingById[trainId];
  }

  renderSingleActivityInclusion(activity) {
    let costedItinerary = this.props.costedItinerary;
    let ac = this.getActivityCostingObject(costedItinerary, activity);
    let a = this.getActivityObject(costedItinerary, ac.activityId);
    return <li>{a.title}</li>;
  }

  renderTransferInclusions(transfers) {
    return transfers.map(transfer => {
      return this.renderSingleTransferInclusion(transfer.transferKey);
    });
  }

  renderFerryInclusions(ferries) {
    return ferries.map(ferry => {
      return this.renderSingleFerryInclusion(ferry.transferKey);
    });
  }

  renderSingleFerryInclusion(ferry) {
    let costedItinerary = this.props.costedItinerary;
    let f = this.getFerryObject(costedItinerary, ferry);

    return <li>Ferry - {f.text}</li>;
  }

  renderSingleTransferInclusion(transferId) {
    let costedItinerary = this.props.costedItinerary;
    let t = this.getTransferObject(costedItinerary, transferId);
    return <li>{t.text}</li>;
  }

  renderOtherInclusions(otherInclusions) {
    return otherInclusions.map(other => {
      return this.renderSingleOtherInclusion(other);
    });
  }

  renderSingleOtherInclusion(other) {
    return <li>{other}</li>;
  }

  renderActivityInclusions(activities) {
    return activities.map(activity => {
      return this.renderSingleActivityInclusion(activity.activityKey);
    });
  }

  renderTrainInclusions(trains) {
    return trains.map(train => {
      return this.renderSingleTrainInclusion(train.transferKey);
    });
  }

  renderSingleTrainInclusion(trainId) {
    let costedItinerary = this.props.costedItinerary;
    let tr = this.getTrainObject(costedItinerary, trainId);
    return <li>Train - {tr.text}</li>;
  }

  renderSinglePass(pass, counter) {
    return (
      <div className="row">
        <div className="col-xs-12 no-padding v-spaced-5">
          <div className="col-sm-9 col-xs-12">
            <div className="col-xs-1 no-padding width-40 width-20-mobile">
              <span className="spaced-span txt-size-xs">{counter}.</span>
            </div>
            <div className="col-xs-11 no-padding">
              <span className="title oj-text-black font-rounded-variant txt-size-sm">
                {pass.name}
              </span>
              <span className="txt-size-xs block oj-text-grey">
                {pass.description}
              </span>
            </div>
          </div>
          <div className="col-xs-4 col-sm-3 text-right hidden-xs">
            <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
              <span className="vehoicon-rupee" /> {pass.totalCost}
            </p>
          </div>
        </div>
        <div className="col-xs-12 no-padding v-spaced-5">
          <div className="col-sm-12 col-xs-8">
            <div className="pull-left margin-left-40 margin-left-20-mobile">
              <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                Incudes
              </span>
              {/* <span className="txt-size-xs block oj-text-grey">Pickup at pickup point</span> */}
            </div>
          </div>
          <div className="col-xs-4 col-sm-3 text-right visible-xs">
            <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
              cost
            </span>
            <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
              <span className="vehoicon-rupee" /> {pass.totalCost}
            </p>
          </div>
        </div>

        <div className="col-xs-12 v-spaced-5">
          <div className="margin-left-40 margin-left-20-mobile">
            <div className="col-xs-12 no-padding">
              <Tabs
                onSelect={this.handleTabSelect}
                activeKey={this.state.activeKey}
                className="oj-small-tabs"
              >
                <Tab eventKey={1} title="INCLUSIONS">
                  <div className="row">
                    <div className="col-xs-12 txt-size-xs">
                      <div className="dashed col-xs-12 v-spaced">
                        <ul>
                          {pass.inclusions.activities
                            ? this.renderActivityInclusions(
                                pass.inclusions.activities
                              )
                            : null}
                          {pass.inclusions.transfers
                            ? this.renderTransferInclusions(
                                pass.inclusions.transfers
                              )
                            : null}
                          {pass.inclusions.ferries
                            ? this.renderFerryInclusions(
                                pass.inclusions.ferries
                              )
                            : null}
                          {pass.inclusions.trains
                            ? this.renderTrainInclusions(pass.inclusions.trains)
                            : null}
                          {pass.inclusions.otherInclusions
                            ? this.renderOtherInclusions(
                                pass.inclusions.otherInclusions
                              )
                            : null}
                        </ul>
                      </div>
                    </div>
                  </div>
                </Tab>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    );
  }

  renderAllPasses(passCostings) {
    let _this = this;
    let passes = [];
    let i = 0;
    let isLast = false;
    let noOfPasses = _.size(passCostings);
    _.forOwn(passCostings, function(pass, key) {
      if (i === noOfPasses - 1) {
        isLast = true;
      }
      passes.push(_this.renderSinglePass(pass, key, isLast, i + 1));
      i++;
    });

    return passes;
  }

  render() {
    let passCostings = this.props.costedItinerary.passCostings;
    if (passCostings) {
      if (_.size(passCostings.passCostingById) > 0) {
        return <div>{this.renderAllPasses(passCostings.passCostingById)}</div>;
      }
    }

    return null;
  }
}
