import React, { Component } from 'react';
import FlightSingleRow from './flight_single_row';

import _ from 'lodash';

export default class ReviewFlights extends Component {
  constructor(props) {
    super(props);

    this.renderFlightPanels = this.renderFlightPanels.bind(this);
  }

  renderFlightPanels() {
    let flightCostingObj = this.props.itineraryDetail.flightCostings;
    let flightDiffCostingObj = this.props.itineraryDetail.totalDiff
      .flightDiffContainer.flightDiffCostingById;

    return this.props.itineraryDetail.allFlightCostingRefs.map(
      (flightId, inx) => {
        let flight =
          flightCostingObj.flightCostingById &&
          flightCostingObj.flightCostingById[flightId];
        let flightDiff = flightDiffCostingObj && flightDiffCostingObj[flightId];
        let flightStatus = flight ? flight.status : '';

        if (!flight) {
          return null;
        }

        if (flightStatus === 'SUCCESS' || flightStatus === 'BLOCKED') {
          return (
            <FlightSingleRow
              key={'review_' + flightId}
              flightDiff={flightDiff}
              {...this.props}
              flight={flight}
              inx={inx}
            />
          );
        } else {
          return null;
        }
      }
    );
  }

  render() {
    if (!_.isEmpty(this.props.itineraryDetail)) {
      let totalDiff = this.props.itineraryDetail.totalDiff;

      return (
        <div className="col-xs-12 no-padding">
          {this.renderFlightPanels()}

          {!this.props.hidePrice ? (
            <div className={'row ' + (this.props.packageRate ? 'hidden' : '')}>
              <div className="col-xs-12 no-padding v-spaced-5">
                <div className="col-sm-7 col-xs-7">
                  <div className="pull-left margin-left-40 margin-left-20-mobile">
                    <span className="title oj-text-black txt-size-sm">
                      Total cost of flights
                    </span>
                  </div>
                </div>
                <div className="col-xs-5 col-sm-5 text-right">
                  {!this.props.hidePrice ? (
                    <p className="txt-size-md clear-margin inline-block oj-text-black font-rounded-variant">
                      <span className="vehoicon-rupee" />{' '}
                      {
                        this.props.itineraryDetail.flightCostings
                          .totalFlightCost
                      }
                    </p>
                  ) : null}
                  <span
                    className={
                      'txt-size-xs block oj-text-grey ' +
                      (totalDiff &&
                      totalDiff.flightDiffContainer.priceChangeType !== 'NONE'
                        ? ''
                        : 'no-visibility')
                    }
                  >
                    <span
                      className={
                        'txt-size-sm ' +
                        (totalDiff.flightDiffContainer.priceChangeType ===
                        'PRICEINCREASE'
                          ? 'text-red vehoicon-arrow-up'
                          : 'vehoicon-arrow-down text-green')
                      }
                    />
                    <span className="WebRupee">Rs.</span>{' '}
                    {totalDiff.flightDiffContainer.priceChangeType ===
                    'PRICEINCREASE'
                      ? '+'
                      : '-'}{' '}
                    {totalDiff.flightDiffContainer.totalFlightCostChange}
                  </span>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      );
    } else {
      return <div> No content </div>;
    }
  }
}
