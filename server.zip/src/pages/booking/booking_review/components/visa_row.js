import React from 'react';
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';
import PriceButton from './price_button';

const VisaRow = ({ visaArray }) => {
  if (!visaArray.length) return null;

  return (
    <section className="clearfix review-row">
      <div className="left-icon">
        <i className="vehoicon-ticket" />
      </div>
      {visaArray.map((visa, visaIndex) => {
        const { diff } = visa.visaDetails;
        let priceChangeType,
          diffCost = 0;
        if (diff) {
          priceChangeType = diff.diffChangeType;
          diffCost = diff.diffCost;
        }

        return (
          <NavLink key={visaIndex} to={visa.url}>
            <p className="lft-col">
              <i>Visa</i>
              <span>{visa.visaDetails.country}</span>
            </p>
            <div className="rgt-col">
              <PriceButton
                price={diffCost.toFixed(0)}
                priceChangeType={priceChangeType}
              />
            </div>
          </NavLink>
        );
      })}
    </section>
  );
};

VisaRow.propTypes = {
  visaArray: PropTypes.array.isRequired
};

export default VisaRow;
