import React from 'react';
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';
import _ from 'lodash';
import PriceButton from './price_button';

const PassRow = ({ passArray }) => {
  if (
    _.isEmpty(passArray)
    // ||
    // _.isEmpty(passDetails.passCostingInfo.passCostingById)
  )
    return null;

  return (
    <section className="clearfix review-row">
      <div className="left-icon">
        <i className="vehoicon-local_play" />
      </div>
      {passArray.map((pass, passIndex) => {
        const passInfo = pass.passDetails;
        const { diff } = pass.passDetails;
        let priceChangeType,
          diffCost = 0;
        if (diff) {
          priceChangeType = diff.diffChangeType;
          diffCost = diff.diffCost;
        }
        return (
          <NavLink key={passIndex} to={pass.url}>
            <p className="lft-col">
              <i>{'Pass'}</i>
              <span>{passInfo.name}</span>
            </p>
            <div className="rgt-col">
              <p className="pull-left">
                <span />
              </p>
              <PriceButton
                price={diffCost.toFixed(0)}
                priceChangeType={priceChangeType}
              />
            </div>
          </NavLink>
        );
      })}
    </section>
  );
};

PassRow.propTypes = {
  passArray: PropTypes.array.isRequired
};

export default PassRow;
