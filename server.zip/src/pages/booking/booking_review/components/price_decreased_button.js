import React from 'react';
import PropTypes from 'prop-types';

const PriceDecreasedButton = ({ price, isTitle }) => {
  return (
    <span
      className={`${!isTitle ? 'pull-right' : ''} tag-secondary bg secondary`}
    >
      <i className="vehoicon-arrow_downward" /> {`₹${price}`}
    </span>
  );
};

PriceDecreasedButton.propTypes = {
  price: PropTypes.string.isRequired,
  isTitle: PropTypes.bool
};

export default PriceDecreasedButton;
