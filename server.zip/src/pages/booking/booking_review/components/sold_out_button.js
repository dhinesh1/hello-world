import React from 'react';

const SoldOutButton = () => {
  return <span className="pull-right tag-secondary accent-7">SOLD OUT</span>;
};

export default SoldOutButton;
