import React, { Component } from 'react';
import { minutesToStr, getAirlineLogo } from '../../../../helpers/utilsHelper';
import SmartImage from '../../../../common_components/Image/smart_image';

export default class FlightRouteDetailsRow extends Component {
  renderFlightDetailsRow(trip, airlineCode) {
    const airlineImg = getAirlineLogo(airlineCode);
    return trip.routes.map((route, loopInx) => {
      let layover_row =
        route.connectionDuration > 0 ? this.LayoverRow(route) : null;

      return (
        <div className="row" key={Math.random()}>
          <div className="col-xs-12">
            <div className="col-xs-12 col-sm-6">
              <span
                className={
                  'txt-size-xxs oj-text-grey block text-uppercase v-spaced-5 no-top-margin ' +
                  (loopInx !== 0 ? 'visible-xs' : '')
                }
              >
                FLIGHT
              </span>
              <div className="col-xs-6 no-padding">
                <SmartImage
                  src={airlineImg.url}
                  alt={airlineImg.name}
                  defaultImage={airlineImg.default}
                  width="80px"
                />
              </div>
              <div className="col-xs-6">
                <span className="txt-size-xxs oj-text-black block">
                  {route.carrierName}
                </span>
                <span className="txt-size-xxs oj-text-black block">
                  Economy
                </span>
              </div>
            </div>
            <div className="col-xs-6 col-sm-3">
              <span
                className={
                  'txt-size-xxs oj-text-grey block text-uppercase v-spaced-5 no-top-margin ' +
                  (loopInx !== 0 ? 'visible-xs' : '')
                }
              >
                DEPARTURE
              </span>
              <div className="col-xs-12 no-padding">
                <span className="txt-size-xxs oj-text-black block">
                  {route.departureCity}
                  ({route.departureAirportCode})
                </span>
                <span className="txt-size-xxs oj-text-black block">
                  {route.depMonth} {route.depDateOfMonth}{' '}
                  {route.departureTime.substring(0, 5)}
                </span>
              </div>
            </div>
            <div className="col-xs-6 col-sm-3">
              <span
                className={
                  'txt-size-xxs oj-text-grey block text-uppercase v-spaced-5 no-top-margin ' +
                  (loopInx !== 0 ? 'visible-xs' : '')
                }
              >
                ARRIVAL
              </span>
              <div className="col-xs-12 no-padding">
                <span className="txt-size-xxs oj-text-black block">
                  {route.arrivalCity}
                  ({route.arrivalAirportCode})
                </span>
                <span className="txt-size-xxs oj-text-black block">
                  {route.arrMonth} {route.arrDateOfMonth}{' '}
                  {route.arrivalTime.substring(0, 5)}
                </span>
              </div>
            </div>
          </div>
          {layover_row}
        </div>
      );
    });
  }

  LayoverRow(route) {
    return (
      <div className="col-xs-10 col-xs-offset-1 col-sm-9 col-sm-offset-3">
        <div className="col-xs-12">
          <span className="txt-size-xxs block v-spaced">
            Layover in {route.arrivalCity}
            for {minutesToStr(route.connectionDuration)}
          </span>
        </div>
      </div>
    );
  }

  render() {
    let { trip, airlineCode, islastRoute } = this.props;

    if (trip.routes.length > 0) {
      return (
        <div
          className={
            'col-xs-12 all-15-padding ' +
            (!islastRoute ? 'border-bottom border-dark-grey border-dashed' : '')
          }
        >
          {this.renderFlightDetailsRow(trip, airlineCode)}
        </div>
      );
    } else {
      return <div> No content </div>;
    }
  }
}
