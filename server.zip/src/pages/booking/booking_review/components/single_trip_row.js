import React, { Component } from 'react';
import { minutesToStr } from '../../../../helpers/utilsHelper';

export default class SingleTripRow extends Component {
  populateAirportCodes(tripDetails) {
    let i = -1;
    return tripDetails.routes.map(route => {
      ++i;
      if (i === 0)
        return (
          <span key={Math.random()}>
            {' '}
            <span>{route.departureAirportCode}</span> <span>⟶</span>{' '}
            <span>{route.arrivalAirportCode}</span>
          </span>
        );
      else
        return (
          <span key={Math.random()}>
            {' '}
            <span>⟶</span> <span>{route.arrivalAirportCode}</span>
          </span>
        );
    });
  }

  render() {
    let { tripInfo, lastRoute, r_inx, packageRate } = this.props;

    let noOfStops = tripInfo.routes.length - 1;
    let noOfStopsUI = '';
    if (noOfStops === 0) {
      noOfStopsUI = 'Direct';
    } else if (noOfStops === 1) {
      noOfStopsUI = '1 Stop';
    } else if (noOfStops > 1) {
      noOfStopsUI = noOfStops + ' Stops';
    }

    return (
      <div className="row">
        <div className="col-xs-12">
          <div className="col-xs-1 no-padding width-40 width-20-mobile">
            <span className="spaced-span txt-size-xs">
              {r_inx === lastRoute ? '' : r_inx + 1 + '.'}
            </span>
          </div>
          <div className="col-xs-10 no-padding">
            <span
              className={
                'list-numbering-round animated ' +
                (!packageRate ? 'hidden' : '')
              }
            >
              <span className="vehoicon-flight" />
            </span>
            <span className="title oj-text-black txt-size-sm font-rounded-variant">
              {tripInfo.routes[0].departureCity} to{' '}
              {tripInfo.routes[lastRoute].arrivalCity}
            </span>
            <span className="txt-size-xs block oj-text-grey truncate">
              {this.populateAirportCodes(tripInfo)} .{' '}
              {minutesToStr(tripInfo.duration)} . {noOfStopsUI}
            </span>
          </div>
        </div>
        <div className="col-xs-12 v-spaced-5">
          <div className="col-sm-6 col-xs-6 no-padding">
            <div className="pull-left margin-left-40 margin-left-20-mobile">
              <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                Departure
              </span>
              <span className="title oj-text-black txt-size-sm">
                {tripInfo.routes[0].depMonth}{' '}
                {tripInfo.routes[0].depDateOfMonth}
              </span>
              <span className="txt-size-xs block oj-text-grey">
                {tripInfo.routes[0].departureTime.substring(0, 5)}
              </span>
            </div>
          </div>
          <div className="col-sm-6 col-xs-6">
            <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
              arrival
            </span>
            <span className="title oj-text-black txt-size-sm">
              {tripInfo.routes[lastRoute].depMonth}{' '}
              {tripInfo.routes[lastRoute].depDateOfMonth}
            </span>
            <span className="txt-size-xs block oj-text-grey">
              {tripInfo.routes[lastRoute].arrivalTime.substring(0, 5)}
            </span>
          </div>
        </div>
      </div>
    );
  }
}
