import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { NavLink } from 'react-router-dom';
import PriceButton from './price_button';

const InsuranceRow = ({ insuranceDetail }) => {
  if (_.isEmpty(insuranceDetail) || !insuranceDetail.insuranceCostingById.plan)
    return null;

  const diffDetail = insuranceDetail.insuranceCostingById.diff;

  let priceChangeType,
    diffCost = 0;
  if (diffDetail) {
    priceChangeType = diffDetail.diffChangeType;
    diffCost = diffDetail.diffCost;
  }

  return (
    <section className="clearfix review-row">
      <div className="left-icon">
        <i className="vehoicon-transfer" />
      </div>
      <NavLink to={insuranceDetail.url}>
        <p className="lft-col">
          <i>{`Insurance ${
            insuranceDetail.insuranceCostingById.countries ? '-' : ''
          } ${
            insuranceDetail.insuranceCostingById.countries
              ? insuranceDetail.insuranceCostingById.countries.map(
                  (country, index) => {
                    return `${index ? ', ' : ''}${country}`;
                  }
                )
              : ''
          }`}</i>
          <span>{insuranceDetail.insuranceCostingById.plan}</span>
        </p>
        <div className="rgt-col">
          <PriceButton price={diffCost} priceChangeType={priceChangeType} />
        </div>
      </NavLink>
    </section>
  );
};

export default InsuranceRow;
