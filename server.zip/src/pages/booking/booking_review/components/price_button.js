import React from 'react';
import PropTypes from 'prop-types';
import PriceDecreasedButton from './price_decreased_button';
import PriceIncreasedButton from './price_increased_button';

const PriceButton = ({ price, priceChangeType, isTitle, isSoldOut }) => {
  if (isSoldOut)
    return <span className="pull-right tag-secondary accent-7">SOLD OUT</span>;
  return priceChangeType === 'PRICEDECREASE' ? (
    <PriceDecreasedButton price={price} isTitle={isTitle} />
  ) : priceChangeType === 'PRICEINCREASE' ? (
    <PriceIncreasedButton price={price} isTitle={isTitle} />
  ) : null;
};

PriceButton.propTypes = {
  price: PropTypes.string.isRequired,
  priceChangeType: PropTypes.string.isRequired,
  isTitle: PropTypes.bool,
  isSoldOut: PropTypes.bool
};

export default PriceButton;
