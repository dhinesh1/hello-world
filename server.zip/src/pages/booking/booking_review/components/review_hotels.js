import React, { Component } from 'react';
import { isEmpty } from 'lodash';
import HotelSingleRow from './hotel_single_row';
import { NavLink } from 'react-router-dom';
import { encodeCostingKeyForURL } from '../../../../helpers/utilsHelper';
import { connect } from 'react-redux';
import { loadModalLinks } from '../../../../actions/actions_app';
import { bindActionCreators } from 'redux';

class ReviewHotels extends Component {
  renderHotelPanels() {
    let hotelCostings = this.props.itineraryDetail.hotelCostings;
    let hotelDiffCostingById = this.props.itineraryDetail.totalDiff
      .hotelDiffContainer.hotelDiffCostingById;

    return this.props.itineraryDetail.allHotelCostingRefs.map(
      (hotelId, inx) => {
        let hotelDetails = hotelCostings.hotelCostingById[hotelId];
        let hotelDiff = hotelDiffCostingById && hotelDiffCostingById[hotelId];

        if (
          !hotelDetails ||
          (hotelDetails && hotelDetails.status !== 'SUCCESS')
        ) {
          return null;
        }

        this.props.loadModalLinks({
          key: encodeCostingKeyForURL(hotelId),
          url: `/${
            this.props.itineraryId
          }/bookingReview/hotel-details/${encodeCostingKeyForURL(hotelId)}`
        });

        return (
          <NavLink
            to={`/${
              this.props.itineraryId
            }/bookingReview/hotel-details/${encodeCostingKeyForURL(hotelId)}`}
          >
            <HotelSingleRow
              packageRate={this.props.packageRate}
              hotelDiff={hotelDiff}
              hidePrice={this.props.hidePrice}
              key={'review_' + hotelDetails.costingKey}
              inx={inx}
              isForPackage={false}
              hotelDetails={hotelDetails}
            />
          </NavLink>
        );
      }
    );
  }

  render() {
    if (!isEmpty(this.props.itineraryDetail)) {
      let totalDiff = this.props.itineraryDetail.totalDiff;

      return (
        <div className="col-xs-12 no-padding">
          {this.renderHotelPanels()}

          <div className={'row ' + (this.props.packageRate ? 'hidden' : '')}>
            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-7 col-xs-7">
                <div className="pull-left margin-left-40 margin-left-20-mobile">
                  <span className="title oj-text-black txt-size-sm">
                    Total cost of hotels
                  </span>
                </div>
              </div>
              <div className="col-xs-5 col-sm-5 text-right">
                {!this.props.hidePrice ? (
                  <p className="txt-size-md clear-margin inline-block oj-text-black font-rounded-variant">
                    <span className="WebRupee">Rs.</span>{' '}
                    {this.props.itineraryDetail.hotelCostings.totalHotelCost}
                  </p>
                ) : null}
                <span
                  className={
                    'txt-size-xs block oj-text-grey ' +
                    (totalDiff &&
                    totalDiff.hotelDiffContainer.priceChangeType !== 'NONE'
                      ? ''
                      : 'no-visibility')
                  }
                >
                  <span
                    className={
                      'txt-size-sm ' +
                      (totalDiff.hotelDiffContainer.priceChangeType ===
                      'PRICEINCREASE'
                        ? 'text-red vehoicon-arrow-up'
                        : 'vehoicon-arrow-down text-green')
                    }
                  />{' '}
                  <span className="WebRupee">Rs.</span>{' '}
                  {totalDiff.hotelDiffContainer.priceChangeType ===
                  'PRICEINCREASE'
                    ? '+'
                    : '-'}{' '}
                  {totalDiff.hotelDiffContainer.totelHotelCostChange}
                </span>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      return <div>No content</div>;
    }
  }
}

const mapStateToProps = state => {
  const itineraryDetails = state.app.itineraryInfo.itineraryDetails;
  const itineraryId = itineraryDetails
    ? itineraryDetails.itinerary.itineraryId
    : '';
  return {
    itineraryId
  };
};

const mapDispatchToProps = dispatch => {
  return {
    loadModalLinks: bindActionCreators(loadModalLinks, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ReviewHotels);
