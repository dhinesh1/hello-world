import React, { Component } from 'react';
import { ButtonGroup } from 'react-bootstrap';
import _ from 'lodash';
import {
  onceModalClosed,
  onceModalOpened
} from '../../../../helpers/utilsHelper';

export default class AddExcessBaggage extends Component {
  constructor(props) {
    super(props);

    const state = {
      showModal: false,
      isLoading: false,
      errorMessage: '',
      totalCost: _.toNumber(this.props.cost)
    };

    state.routes = [];
    this.props.excessBaggages.forEach(eb => {
      state[eb.originDestinationKey] = eb.baggageOptions.map(bo => {
        return {
          code: bo.code,
          selectedQuantity: _.toNumber(bo.selectedQuantity),
          price: _.toNumber(bo.price)
        };
      });
      state.routes.push(eb.originDestinationKey);
    });

    this.state = state;

    this.changeExcessBaggage = this.changeExcessBaggage.bind(this);
    this.totalBaggageCount = this.totalBaggageCount.bind(this);
    this.handleUpdateClick = this.handleUpdateClick.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }

  componentDidMount() {
    onceModalOpened();
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    onceModalClosed();
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.props.toggleAEBModal();
  }

  totalBaggageCount(originDestinationKey) {
    return this.state[originDestinationKey].reduce(
      (acc, ele) => acc + ele.selectedQuantity,
      0
    );
  }

  totalCost() {
    return this.state.routes.reduce(
      (acc, ele) =>
        acc +
        this.state[ele].reduce((a, e) => a + e.selectedQuantity * e.price, 0),
      0
    );
  }

  changeExcessBaggage(type, originDestinationKey, code) {
    const boArray = [...this.state[originDestinationKey]];
    const boItem = boArray.find(bo => bo.code === code);
    if (boItem === undefined) return;

    const delta = type === 'add' ? 1 : type === 'reduce' ? -1 : 0;

    boItem.selectedQuantity += delta;

    this.setState({
      ...this.state,
      [originDestinationKey]: boArray,
      totalCost: this.state.totalCost + delta * boItem.price
    });
  }

  handleUpdateClick() {
    this.props.updateBaggage({
      itineraryId: this.props.itineraryId,
      excessBaggageInfo: {
        allowedExcessBaggageCount: this.props.allowedExcessBaggageCount,
        excessBaggages: this.state.routes.map(r => {
          return {
            originDestinationKey: r,
            baggageOptions: this.state[r].map(bo => {
              return {
                code: bo.code,
                selectedQuantity: bo.selectedQuantity
              };
            })
          };
        })
      }
    });
  }

  render() {
    const travellersCount =
      _.toNumber(this.props.adult_count || 0) +
      _.toNumber(this.props.child_count || 0);

    return (
      <div
        tabIndex="0"
        ref="modal"
        className={
          'modal fade modal-sticky-header alternate-modal ' +
          (this.props.showModal ? 'in' : '')
        }
      >
        <div className={`modal-dialog`}>
          <div className={'modal-content with-header'}>
            <div className={'modal-header with-bg'}>
              <button
                type="button"
                className="pull-left close"
                data-dismiss="modal"
                aria-label="Close"
                onClick={() => this.props.toggleAEBModal()}
              >
                <i className="vehoicon-close" />
              </button>
              <span className="mini semi-bold kern-more fade text-uppercase">
                Add Baggage
              </span>
              <div className={'modal-actions'}>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={this.handleUpdateClick}
                >
                  Update
                </button>
              </div>
            </div>

            <div className={'modal-body'}>
              {travellersCount ? (
                <div className="current-pick-panel">
                  <div className="current-pick-content hotel">
                    <div className="col-xs-9 col-md-10">
                      <a href="javascript:void(0);" className=" color-black">
                        {`Total additional baggage cost for ${travellersCount} travellers`}
                      </a>
                    </div>
                    <div className="col-xs-3 col-md-2 text-right">
                      <span className="total-price meta-text bold">
                        ₹{this.state.totalCost}
                      </span>
                    </div>
                  </div>
                </div>
              ) : null}

              <div className="modal-row pl-0 pr-0">
                <div className="column-pad">
                  {this.props.excessBaggages.map(flightBaggageOptions => (
                    <FlightBaggageOptions
                      key={flightBaggageOptions.originDestinationKey}
                      {...flightBaggageOptions}
                      {...this.props}
                      changeExcessBaggage={this.changeExcessBaggage}
                      totalBaggageCount={this.totalBaggageCount}
                      selectedQuantities={
                        this.state[flightBaggageOptions.originDestinationKey]
                      }
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const FlightBaggageOptions = props => {
  const totalBaggageCount = props.totalBaggageCount(props.originDestinationKey);
  return (
    <div>
      <div className="row flex vertical-center hidden-xs spacer-top">
        <div className="col-md-7 col-xs-12">
          <span className="main-text fade semi-bold">
            {props.origin} <i className={'vehoicon-left rotate-180'} />{' '}
            {props.destination}
          </span>
          <span className="fine-text fade">{props.carrierName}</span>
        </div>
        <div className="col-md-5 col-xs-12">
          <span className="meta-text fade pull-right">
            Max. {props.allowedExcessBaggageCount} additional bags
          </span>
        </div>
      </div>
      <hr className="mute spacer hidden-xs" />

      <div className="padding-left-20 padding-right">
        <div className="border-dark-grey border-bottom v-spaced" />
        <div className="list oj-list line-height-30 border-bottom border-dark-grey">
          {props.baggageOptions.map(baggageOption => (
            <BaggageOption
              key={baggageOption.code}
              {...baggageOption}
              {...props}
              selectedQuantity={props.selectedQuantities.reduce(
                (acc, ele) =>
                  ele.code === baggageOption.code ? ele.selectedQuantity : acc,
                0
              )}
              totalBaggageCount={totalBaggageCount}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

const BaggageOption = props => {
  return (
    <div className="row spacer">
      <div className="col-sm-6 col-xs-12">
        <span className="meta-text fade">
          {props.weight === '0'
            ? 'No baggage'
            : 'Check in baggage upto ' + props.weight + ' kg'}

          {props.ourSourceProvider === 'PYTON' && props.code
            ? ` (${props.code.split('/')[0]} Pcs)`
            : null}
        </span>
      </div>
      <div className="col-xs-7 col-sm-3">
        <span className="meta-text fade">
          <span className="WebRupee">Rs.</span> {props.price}
        </span>
      </div>
      <CallToAction {...props} />
    </div>
  );
};

const CallToAction = props => {
  const buttonAdd = (
    <div className="col-sm-3 col-xs-5 actions text-right">
      <div className="visa-btn-grp btn-group" role="group" aria-label="true">
        <button
          type="button"
          className="btn btn-xs btn-primary-dark btn-outline"
          disabled={props.totalBaggageCount >= props.allowedExcessBaggageCount}
          onClick={() => {
            props.changeExcessBaggage(
              'add',
              props.originDestinationKey,
              props.code
            );
          }}
        >
          Add
        </button>
      </div>
    </div>
  );

  const buttonGroup = (
    <div className="col-sm-3 col-xs-5 actions text-right">
      <div className="visa-btn-grp btn-group" role="group" aria-label="true">
        <button
          type="button"
          className="btn btn-xs btn-primary"
          disabled={props.totalBaggageCount <= 0}
          onClick={() =>
            props.changeExcessBaggage(
              'reduce',
              props.originDestinationKey,
              props.code
            )
          }
        >
          <span className="vehoicon-remove_circle small" />
        </button>
        <button
          type="button"
          className="btn btn-xs btn-primary btn-outline btn-outline-bg"
        >
          <span className="inline-block">{props.selectedQuantity}</span>
        </button>
        <button
          type="button"
          className="btn btn-xs btn-primary"
          disabled={
            props.disabled ||
            props.totalBaggageCount >= props.allowedExcessBaggageCount
          }
          onClick={() =>
            props.changeExcessBaggage(
              'add',
              props.originDestinationKey,
              props.code
            )
          }
        >
          <span className="vehoicon-add_circle small" />
        </button>
      </div>
    </div>
  );

  return props.selectedQuantity > 0 ? buttonGroup : buttonAdd;
};
