import React, { Component } from 'react';

import { capitalize, isEmpty } from 'lodash';

let count = 0;
let finalCount1 = 0;
let finalCount2 = 0;
let finalCount3 = 0;

export default class ReviewTransfers extends Component {
  constructor(props) {
    super(props);
  }

  getTransferElement = transfer => {
    if (!this.props.hidePrice) {
      return (
        <div className="col-xs-4 col-sm-3 text-right visible-xs">
          <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
            cost
          </span>
          {transfer.inCombo ? (
            <span className="in-combo">IN COMBO</span>
          ) : transfer.inSwissPass ? (
            <span className="in-combo">IN SWISS PASS</span>
          ) : (
            <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
              <span className="WebRupee">Rs.</span> {transfer.totalCost}
            </p>
          )}
        </div>
      );
    } else {
      return null;
    }
  };

  renderRentalCarsTransfers() {
    let itineraryDetail = this.props.itineraryDetail;

    if (itineraryDetail.allRentalCostingRefs !== undefined) {
      return itineraryDetail.allRentalCostingRefs.map((transferId, inx) => {
        let transfer =
          itineraryDetail.rentalCarCostings.rentalCostingById[transferId];
        count = inx + 1;
        finalCount1 = count;

        return (
          <div key={'review_' + transferId} className="row">
            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-9 col-xs-12">
                <div className="col-xs-1 no-padding width-40 width-20-mobile">
                  <span className="spaced-span txt-size-xs">{count}.</span>
                </div>
                <div className="col-xs-11 no-padding">
                  <span className="title oj-text-black font-rounded-variant txt-size-sm">
                    Car Rental - {transfer.pickup}
                    to {transfer.drop}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.carTitle}
                    . Self Drive . GPS {transfer.gpsIncluded ? '' : 'Not'}
                    included .{' '}
                    {transfer.showInsuranceData
                      ? transfer.selectedInsurance.insuranceName + ' Insurance'
                      : ''}
                  </span>
                </div>
              </div>
              <div className="col-xs-4 col-sm-3 text-right hidden-xs">
                {!this.props.hidePrice ? (
                  <p className="txt-size-sm clear-margin inline-block oj-text-grey font-default">
                    <span className="WebRupee">Rs.</span> {transfer.totalCost}
                  </p>
                ) : null}
              </div>
            </div>

            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-4 col-xs-4">
                <div className="pull-left margin-left-40 margin-left-20-mobile">
                  <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                    pick up
                  </span>
                  <span className="title oj-text-black txt-size-sm">
                    {transfer.pickupMonth} {transfer.pickupDate}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.pickupTime}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.pickup}
                  </span>
                </div>
              </div>
              <div className="col-sm-4 col-xs-4">
                <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                  drop
                </span>
                <span className="title oj-text-black txt-size-sm">
                  {transfer.dropMonth} {transfer.dropDate}
                </span>
                <span className="txt-size-xs block oj-text-grey">
                  {transfer.dropTime}
                </span>
                <span className="txt-size-xs block oj-text-grey">
                  {transfer.drop}
                </span>
              </div>
              {!this.props.hidePrice ? (
                <div className="col-xs-4 col-sm-3 text-right visible-xs">
                  <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                    cost
                  </span>
                  <p className="txt-size-sm clear-margin inline-block oj-text-grey font-default">
                    <span className="WebRupee">Rs.</span> {transfer.totalCost}
                  </p>
                </div>
              ) : null}
            </div>

            <div className="col-xs-12">
              <div className="margin-left-40 margin-left-20-mobile">
                <hr className="v-spaced" />
              </div>
            </div>
          </div>
        );
      });
    }
  }

  renderTrainTransfers() {
    let itineraryDetail = this.props.itineraryDetail;

    if (itineraryDetail.allTrainCostingRefs !== undefined) {
      return itineraryDetail.allTrainCostingRefs.map((transferId, inx) => {
        let transfer =
          itineraryDetail.trainCostings.trainCostingById[transferId];
        // if the costing status is not success or costing not available
        // we are not showing the train details in the booking review
        if (!transfer || transfer.status !== 'SUCCESS') {
          return null;
        }
        count = finalCount1 + inx + 1;
        finalCount2 = count;

        return (
          <div className="row">
            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-9 col-xs-12">
                <div className="col-xs-1 no-padding width-40 width-20-mobile">
                  <span className="spaced-span txt-size-xs">{count}.</span>
                </div>
                <div className="col-xs-11 no-padding">
                  <span className="title oj-text-black font-rounded-variant txt-size-sm">
                    Train - {transfer.text}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.duration}, {transfer.stops}
                    stops . {transfer.ticketType} ticket
                  </span>
                </div>
              </div>
              {!this.props.hidePrice ? (
                <div className="col-xs-4 col-sm-3 text-right hidden-xs">
                  {transfer.inCombo ? (
                    <span className="in-combo">IN COMBO</span>
                  ) : transfer.inSwissPass ? (
                    <span className="in-combo">IN SWISS PASS</span>
                  ) : (
                    <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
                      <span className="WebRupee">Rs.</span> {transfer.totalCost}
                    </p>
                  )}
                </div>
              ) : null}
            </div>

            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-4 col-xs-4">
                <div className="pull-left margin-left-40 margin-left-20-mobile">
                  <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                    departure
                  </span>
                  <span className="title oj-text-black txt-size-sm">
                    {transfer.mon} {transfer.day}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.departureTime}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.pickup}
                  </span>
                </div>
              </div>
              <div className="col-sm-4 col-xs-4">
                <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                  arrival
                </span>
                <span className="title oj-text-black txt-size-sm">
                  {transfer.mon} {transfer.day}
                </span>
                <span className="txt-size-xs block oj-text-grey">
                  {transfer.arrivalTime}
                </span>
                <span className="txt-size-xs block oj-text-grey">
                  {transfer.drop}
                </span>
              </div>
              {this.getTransferElement(transfer)}
            </div>

            <div className="col-xs-12">
              <div className="margin-left-40 margin-left-20-mobile">
                <hr className="v-spaced" />
              </div>
            </div>
          </div>
        );
      });
    }
  }

  renderTransferPanels() {
    let itineraryDetail = this.props.itineraryDetail;

    if (itineraryDetail.allTransferCostingRefs !== undefined) {
      return itineraryDetail.allTransferCostingRefs.map((transferId, inx) => {
        let transfer =
          itineraryDetail.transferCostings.transferCostingById[transferId];
        count = finalCount2 + inx + 1;
        finalCount3 = count;

        if (transfer.status === 'SUCCESS') {
          return (
            <div key={'review_' + transferId} className="row">
              <div className="col-xs-12 no-padding v-spaced-5">
                <div className="col-sm-9 col-xs-12">
                  <div className="col-xs-1 no-padding width-40 width-20-mobile">
                    <span className="spaced-span txt-size-xs">{count}.</span>
                  </div>
                  <div className="col-xs-11 no-padding">
                    <span className="title oj-text-black font-rounded-variant txt-size-sm">
                      Transfer - {transfer.text}
                    </span>
                    <span className="txt-size-xs block oj-text-grey">
                      {capitalize(transfer.type)}
                      transfer . {transfer.duration} .{' '}
                      {capitalize(transfer.vehicle)}
                    </span>
                  </div>
                </div>
                {!this.props.hidePrice ? (
                  <div className="col-xs-4 col-sm-3 text-right hidden-xs">
                    {transfer.inCombo ? (
                      <span className="in-combo">IN COMBO</span>
                    ) : transfer.inSwissPass ? (
                      <span className="in-combo">IN SWISS PASS</span>
                    ) : (
                      <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
                        <span className="WebRupee">Rs.</span>{' '}
                        {transfer.totalCost}
                      </p>
                    )}
                  </div>
                ) : null}
              </div>

              <div className="col-xs-12 no-padding v-spaced-5">
                <div className="col-sm-4 col-xs-8">
                  <div className="pull-left margin-left-40 margin-left-20-mobile">
                    <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                      pick up
                    </span>
                    <span className="title oj-text-black txt-size-sm">
                      {transfer.mon} {transfer.day}
                    </span>
                    <span className="txt-size-xs block oj-text-grey">
                      {transfer.fromCity} {transfer.pickup}
                    </span>
                  </div>
                </div>
                {this.getTransferElement(transfer)}
              </div>

              <div className="col-xs-12">
                <div className="margin-left-40 margin-left-20-mobile">
                  <hr className="v-spaced" />
                </div>
              </div>
            </div>
          );
        }
      });
    }
  }

  renderFerryTransfers() {
    let itineraryDetail = this.props.itineraryDetail;

    if (itineraryDetail.allFerryCostingRefs !== undefined) {
      return itineraryDetail.allFerryCostingRefs.map((transferId, inx) => {
        let transfer =
          itineraryDetail.ferryCostings.ferryCostingById[transferId];
        // if the costing status is nots success of costing not available
        // we are not showing the ferry details in the booking review
        if (!transfer || transfer.status !== 'SUCCESS') {
          return null;
        }
        count = finalCount3 + inx + 1;
        return (
          <div className="row">
            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-9 col-xs-12">
                <div className="col-xs-1 no-padding width-40 width-20-mobile">
                  <span className="spaced-span txt-size-xs">{count}.</span>
                </div>
                <div className="col-xs-11 no-padding">
                  <span className="title oj-text-black font-rounded-variant txt-size-sm">
                    Ferry - {transfer.text}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.duration}, Shared transfer
                  </span>
                </div>
              </div>
              {!this.props.hidePrice ? (
                <div className="col-xs-4 col-sm-3 text-right hidden-xs">
                  {transfer.inCombo ? (
                    <span className="in-combo">IN COMBO</span>
                  ) : transfer.inSwissPass ? (
                    <span className="in-combo">IN SWISS PASS</span>
                  ) : (
                    <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
                      <span className="WebRupee">Rs.</span> {transfer.totalCost}
                    </p>
                  )}
                </div>
              ) : null}
            </div>

            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-4 col-xs-4">
                <div className="pull-left margin-left-40 margin-left-20-mobile">
                  <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                    departure
                  </span>
                  <span className="title oj-text-black txt-size-sm">
                    {transfer.mon} {transfer.day}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.departureTime}
                  </span>
                  <span className="txt-size-xs block oj-text-grey">
                    {transfer.fromCity} {transfer.pickup}
                  </span>
                </div>
              </div>
              <div className="col-sm-4 col-xs-4">
                <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                  arrival
                </span>
                <span className="title oj-text-black txt-size-sm">
                  {transfer.mon} {transfer.day}
                </span>
                <span className="txt-size-xs block oj-text-grey">
                  {transfer.arrivalTime}
                </span>
                <span className="txt-size-xs block oj-text-grey">
                  {transfer.toCity} {transfer.drop}
                </span>
              </div>

              {this.getTransferElement(transfer)}
            </div>

            <div className="col-xs-12">
              <div className="margin-left-40 margin-left-20-mobile">
                <hr className="v-spaced" />
              </div>
            </div>
          </div>
        );
      });
    }
  }

  render() {
    if (!isEmpty(this.props.itineraryDetail)) {
      return (
        <div className="col-xs-12 no-padding">
          {this.renderRentalCarsTransfers()}
          {this.renderTrainTransfers()}
          {this.renderTransferPanels()}
          {this.renderFerryTransfers()}

          {!this.props.hidePrice ? (
            <div className="row">
              <div className="col-xs-12 no-padding v-spaced-5">
                <div className="col-sm-7 col-xs-7">
                  <div className="pull-left margin-left-40 margin-left-20-mobile">
                    <span className="title oj-text-black txt-size-sm">
                      Total cost of Transfers
                    </span>
                  </div>
                </div>
                <div className="col-xs-5 col-sm-5 text-right">
                  <p className="txt-size-md clear-margin inline-block oj-text-black font-rounded-variant">
                    <span className="WebRupee">Rs.</span>{' '}
                    {
                      this.props.itineraryDetail.transferCostings
                        .totalPublishedCost
                    }
                  </p>
                  <span className="txt-size-xs block oj-text-grey no-visibility">
                    <span className="vehoicon-arrow_downward text-danger" />{' '}
                    <span className="WebRupee">Rs.</span> + 1000
                  </span>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      );
    } else {
      return <div> No content </div>;
    }
  }
}
