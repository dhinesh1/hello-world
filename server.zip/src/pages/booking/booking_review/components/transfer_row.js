import React from 'react';
import { NavLink } from 'react-router-dom';
import PropTypes from 'prop-types';
import PriceButton from './price_button';

const TransferRow = ({ transfersArray, isSoldOut }) => {
  if (!transfersArray.length) {
    return null;
  }

  return (
    <section className="clearfix review-row">
      <div className="left-icon">
        <i className="vehoicon-transfer" />
      </div>
      {transfersArray.map((transfer, transferIndex) => {
        const { diff: diffDetail, status } = transfer.transferDetails;
        // If the costing status is error we are not showing any kind of transfers
        // in the booking review row
        if (status === 'ERROR') {
          return null;
        }
        let priceChangeType,
          diffCost = 0;
        if (!isSoldOut && diffDetail) {
          priceChangeType = diffDetail.diffChangeType;
          diffCost = diffDetail.diffCost;
        }
        return (
          <NavLink to={transfer.url} key={transferIndex}>
            <p className="lft-col">
              <i>{transfer.transferDetails.vehicle}</i>
              <span>{transfer.transferDetails.text}</span>
            </p>
            <div className="rgt-col">
              {/*<p className="pull-left">*/}
              {/*Apr 31 - May 02 <span>2 adults, 1 child one room</span>*/}
              {/*</p>*/}
              {/*<i className="pull-right vehoicon-warning" />*/}
              <PriceButton
                priceChangeType={priceChangeType}
                price={diffCost.toFixed(0)}
                isSoldOut={isSoldOut}
              />
            </div>
          </NavLink>
        );
      })}
    </section>
  );
};

TransferRow.propTypes = {
  transfersArray: PropTypes.array.isRequired
};

export default TransferRow;
