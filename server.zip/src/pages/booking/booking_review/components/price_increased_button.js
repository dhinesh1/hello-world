import React from 'react';
import PropTypes from 'prop-types';

const PriceIncreasedButton = ({ price, isTitle }) => {
  return (
    <span
      className={`${
        !isTitle ? 'pull-right' : ''
      } tag-secondary bg primary-dark`}
    >
      <i className="vehoicon-arrow_downward rotate-minus-180" />
      {`₹${price}`}
    </span>
  );
};

PriceIncreasedButton.propTypes = {
  price: PropTypes.string.isRequired,
  isTitle: PropTypes.bool
};

export default PriceIncreasedButton;
