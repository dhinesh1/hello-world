import React from 'react';

const BookingSoldOut = () => {
  return (
    <section className="clearfix text-header text-center">
      <i className="frown vehoicon-sad2" />
      <h4 className="large-heading bold">Oops! some bookings are sold out!</h4>
      <p className="color-grey-secondary">
        You need to change them before proceeding.<br />Don’t worry, all the
        traveller info you have entered is saved.
      </p>
    </section>
  );
};

export default BookingSoldOut;
