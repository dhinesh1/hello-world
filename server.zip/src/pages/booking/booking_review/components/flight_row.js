import React, { Component } from 'react';
//import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';
import PriceButton from './price_button';

class FlightRow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeKey: -1,
      sweetAlertConfig: {
        title: '',
        text: '',
        type: '',
        animation: 'pop'
      }
    };
  }

  render() {
    let {
      flightsArray,
      isSoldOut,
      userDetails,
      toggleAEBModal,
      blockFlight,
      blockFlightLoading,
      makeReadOnly
    } = this.props;
    if (!flightsArray.length) return null;
    let isAdmin = userDetails && userDetails.userType === 'ADMIN';

    return (
      <section className="clearfix review-row">
        <div className="left-icon">
          <i className="vehoicon-flight" />
        </div>
        {flightsArray.map((flight, flightIndex) => {
          const flightDetails = flight.flightDetails.allTrips.map(trip => {
            return {
              route: flight.flightDetails.trips[trip].routes.map(route => {
                return `${route.departureAirportCode} - ${
                  route.arrivalAirportCode
                }`;
              }),
              carrierName: flight.flightDetails.trips[trip].routes.map(
                route => {
                  return route.carrierName;
                }
              ),
              departure: flight.flightDetails.trips[trip].routes.map(route => {
                return `${route.depMonth} ${
                  route.depDateOfMonth
                }, ${route.departureTime.substring(0, 5)}`;
              }),
              arrival: flight.flightDetails.trips[trip].routes.map(route => {
                return `${route.arrMonth} ${
                  route.arrDateOfMonth
                }, ${route.arrivalTime.substring(0, 5)}`;
              })
            };
          });

          let priceChangeType,
            diffCost = 0;
          if (!isSoldOut && flight.flightDetails.diff) {
            priceChangeType = flight.flightDetails.diff.diffChangeType;
            diffCost = flight.flightDetails.diff.diffCost;
          }

          return (
            <NavLink key={flightIndex} to={flight.url}>
              {flightDetails.map((detail, detailIndex) => {
                if (detailIndex === 0) {
                  return (
                    <p key={detailIndex} className="lft-col">
                      <i>{detail.route.join(', ')}</i>
                      <span>{detail.carrierName[0]}</span>
                    </p>
                  );
                } else {
                  return null;
                }
              })}
              <div className="rgt-col">
                <p className="pull-left">
                  {flightDetails.map((detail, detailIndex) => {
                    return detail.departure.map((depart, departIndex) => {
                      if (departIndex === 0) {
                        return (
                          <span key={departIndex}>
                            {`${detail.departure[0]} - ${
                              detail.arrival[detail.arrival.length - 1]
                            }`}
                          </span>
                        );
                      } else {
                        return null;
                      }
                    });
                  })}
                </p>
                <PriceButton
                  price={diffCost.toFixed(0)}
                  priceChangeType={priceChangeType}
                  isSoldOut={isSoldOut}
                />
              </div>
              {(flight.flightDetails &&
                flight.flightDetails.excessBaggageInfo &&
                flight.flightDetails.excessBaggageInfo.available) ||
                isAdmin && !makeReadOnly? (
                <div className="pull-left fw vmargin-small">
                  {flight.flightDetails.excessBaggageInfo &&
                  flight.flightDetails.excessBaggageInfo.available ? (
                    <button
                      className="btn btn-xs btn-primary-dark btn-outline"
                      onClick={e => {
                        e.preventDefault();
                        e.stopPropagation();

                        toggleAEBModal(flight.flightDetails);
                      }}
                    >
                      Add baggage
                    </button>
                  ) : null}

                  {/* SPACE WORKAROUND */}
                  {flight.flightDetails.excessBaggageInfo &&
                  (flight.flightDetails.excessBaggageInfo.available && isAdmin)
                    ? ' '
                    : null}

                  {blockFlightLoading === false ? (
                    isAdmin &&
                    !makeReadOnly &&
                    !isSoldOut &&
                    flight.flightDetails.status !== 'BLOCKED' &&
                    flight.flightDetails.ourSourceProvider === 'TBO' &&
                    !flight.flightDetails.lcc ? (
                      <button
                        className="btn btn-xs btn-primary btn-outline"
                        onClick={e => {
                          e.preventDefault();
                          e.stopPropagation();

                          blockFlight(flight.flightDetails.key);
                        }}
                      >
                        Block flight
                      </button>
                    ) : null
                  ) : flight.flightDetails.key === blockFlightLoading ? (
                    <button
                      type="button"
                      className="btn btn-xs btn-primary btn-outline progress-btn infinite"
                      onClick={e => {
                        e.preventDefault();
                        e.stopPropagation();
                      }}
                    >
                      <span className="progress-bg" />
                      <span className="btn-txt">
                        Blocking flight. Please wait...
                      </span>
                    </button>
                  ) : null}

                  {flight.flightDetails.status === 'BLOCKED' ? (
                    <span className={'meta-text'}>
                      PNR:{' '}
                      <span className="bold color-grey">
                        {flight.flightDetails.pnr}
                      </span>
                    </span>
                  ) : null}
                </div>
              ) : null}
            </NavLink>
          );
        })}
      </section>
    );
  }
}

/*
FlightRow.propTypes = {
  flightsArray: PropTypes.array.isRequired,
  isSoldOut: PropTypes.bool,
  userDetails: PropTypes.object.isRequired,
  toggleAEBModal: PropTypes.func.isRequired,
  blockFlight: PropTypes.func.isRequired
};
*/

export default FlightRow;
