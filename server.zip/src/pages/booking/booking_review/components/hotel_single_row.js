import React, { Component } from 'react';
import { Tabs, Tab } from 'react-bootstrap';
import HotelSingleRoom from './hotel_single_room';

export default class HotelSingleRow extends Component {
  constructor(props) {
    super(props);

    this.state = { activeKey: -1 };

    this.handleTabSelect = this.handleTabSelect.bind(this);
    this.renderRooms = this.renderRooms.bind(this);
  }

  handleTabSelect(index) {
    if (this.state.activeKey === index) {
      index = -1;
    }

    this.setState({
      activeKey: index
    });
  }

  renderRooms() {
    let { hotelDetails } = this.props;

    return hotelDetails.roomsInHotel.map((room, inx) => {
      let isLast = hotelDetails.roomsInHotel.length - 1 === inx;
      return (
        <HotelSingleRoom
          packageRate={this.props.packageRate}
          hidePrice={this.props.hidePrice}
          key={'review_' + inx + '_' + room.roomTypeId}
          inx={inx}
          isLast={isLast}
          roomDetails={room}
        />
      );
    });
  }

  render() {
    let { hotelDetails, inx, packageRate, hotelDiff } = this.props;

    return (
      <div className="row">
        <div className="col-xs-12 no-padding v-spaced-5">
          <div className="col-sm-9 col-xs-12">
            <div className="col-xs-1 no-padding width-40 width-20-mobile">
              <span className="spaced-span txt-size-xs">{inx + 1}.</span>
            </div>
            <div className="col-xs-11 no-padding">
              <span className="title oj-text-black font-rounded-variant txt-size-sm">
                {hotelDetails.name}
              </span>
              <span className="txt-size-xs block oj-text-grey">
                {hotelDetails.cityName}
                - {hotelDetails.roomsInHotel.length} room{' '}
              </span>
            </div>
          </div>
          <div
            className={
              'col-xs-4 col-sm-3 text-right hidden-xs ' +
              (packageRate ? 'no-visibility' : '')
            }
          >
            {!this.props.hidePrice ? (
              <p className="txt-size-sm clear-margin inline-block oj-text-grey font-default">
                <span className="WebRupee">Rs.</span> {hotelDetails.finalPrice}
              </p>
            ) : null}
            {hotelDiff ? (
              <span
                className={
                  'txt-size-xs block oj-text-grey ' +
                  (hotelDiff.priceChangeType !== 'NONE' ? '' : 'no-visibility')
                }
              >
                <span
                  className={
                    'txt-size-sm ' +
                    (hotelDiff.priceChangeType === 'PRICEINCREASE'
                      ? 'text-red vehoicon-arrow-up'
                      : 'vehoicon-arrow-down text-green')
                  }
                />{' '}
                <span className="WebRupee">Rs.</span>{' '}
                {hotelDiff.priceChangeType === 'PRICEINCREASE' ? '+' : '-'}{' '}
                {hotelDiff.diffCost}
              </span>
            ) : null}
          </div>
        </div>

        <div className="col-xs-12 no-padding v-spaced-5">
          <div className="col-sm-4 col-xs-4">
            <div className="pull-left margin-left-40 margin-left-20-mobile">
              <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                Check in
              </span>
              <span className="title oj-text-black txt-size-sm">
                {hotelDetails.checkInMonthDisplay}{' '}
                {hotelDetails.checkInDateDisplay}
              </span>
              {/* <span className="txt-size-xs block oj-text-grey">09:55</span> */}
            </div>
          </div>
          <div className="col-sm-4 col-xs-4">
            <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
              Check out
            </span>
            <span className="title oj-text-black txt-size-sm">
              {hotelDetails.checkOutMonthDisplay}{' '}
              {hotelDetails.checkOutDateDisplay}{' '}
            </span>
            {/* <span className="txt-size-xs block oj-text-grey">09:55</span> */}
          </div>
          <div
            className={
              'col-xs-4 col-sm-3 text-right visible-xs ' +
              (packageRate ? 'no-visibility' : '')
            }
          >
            <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
              cost
            </span>
            {!this.props.hidePrice ? (
              <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
                <span className="WebRupee">Rs.</span> {hotelDetails.finalPrice}
              </p>
            ) : null}
            {hotelDiff ? (
              <span
                className={
                  'txt-size-xs block oj-text-grey ' +
                  (hotelDiff.priceChangeType !== 'NONE' ? '' : 'no-visibility')
                }
              >
                <span
                  className={
                    'txt-size-sm ' +
                    (hotelDiff.priceChangeType === 'PRICEINCREASE'
                      ? 'text-red vehoicon-arrow-up'
                      : 'vehoicon-arrow-down text-green')
                  }
                />{' '}
                <span className="WebRupee">Rs.</span>{' '}
                {hotelDiff.priceChangeType === 'PRICEINCREASE' ? '+' : '-'}{' '}
                {hotelDiff.diffCost}
              </span>
            ) : null}
          </div>
        </div>

        <div className="col-xs-12 v-spaced-5">
          <div className="margin-left-40 margin-left-20-mobile">
            <div className="col-xs-12 no-padding">
              <Tabs
                onSelect={this.handleTabSelect}
                activeKey={this.state.activeKey}
                className="oj-small-tabs"
                id="hotel-tab"
              >
                <Tab
                  eventKey={1}
                  title={
                    packageRate || this.props.hidePrice
                      ? 'Room details'
                      : 'Room details & cost break up'
                  }
                >
                  <div className="row">
                    <div className="col-xs-12 txt-size-xs">
                      {this.renderRooms()}
                    </div>
                  </div>
                </Tab>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
