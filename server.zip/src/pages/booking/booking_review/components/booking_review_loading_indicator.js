import React, { Component } from 'react';
import PropTypes from 'prop-types';

class BookingReviewLoadingIndicator extends Component {
  render() {
    const { isLoading } = this.props;
    return (
      <section className="booking-pages-content">
        <div className="clearfix review-container">
          <section className="clearfix text-center live-price">
            <h4 className="large-heading bold">
              Checking live prices &amp; availability
            </h4>
            <span className="info-txt">{`( Please don't refresh or leave this page )`}</span>
            <div className={`progress-pill ${isLoading ? '' : 'complete'}`} />
            <span className="price-clock" />
            <p className="vmargin-small">
              Hold on while we re-check availability and price for your
              vacation. Kindly note that the pricing on the next page{' '}
              <b>will expire in 10 minutes.</b>
            </p>
          </section>
        </div>
      </section>
    );
  }
}

export default BookingReviewLoadingIndicator;
