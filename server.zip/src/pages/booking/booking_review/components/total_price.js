import React from 'react';
import PropTypes from 'prop-types';
import PriceButton from './price_button';

const TotalPrice = ({ totalCost, changedAmount, changeType, cutPrice }) => {
  const finalTotalCost = isNaN(totalCost)? totalCost : Math.round(totalCost).toLocaleString();
  return (
    <section className="clearfix text-header text-center">
      <span className="caps-text-tiny bold color-grey">Total Cost</span>
      <strong className="color-grey-secondary mbottom-medium">
        <i>&#8377;</i>
        {finalTotalCost}
      </strong>
      {cutPrice ? <span className="strike-line">{cutPrice}</span> : null }
      {changeType === 'PRICEINCREASE' || changeType === 'PRICEDECREASE' ? (
        <p className="color-grey-secondary">
          {`There's a change in your total cost after our final check with our partners. `}
          <br />
          Your total price is{' '}
          <PriceButton
            price={changedAmount}
            priceChangeType={changeType}
            isTitle={true}
          />. Review the new prices and proceed.
        </p>
      ) : null}
    </section>
  );
};

TotalPrice.propTypes = {
  totalCost: PropTypes.string.isRequired,
  changedAmount: PropTypes.string.isRequired,
  changeType: PropTypes.string.isRequired
};

export default TotalPrice;
