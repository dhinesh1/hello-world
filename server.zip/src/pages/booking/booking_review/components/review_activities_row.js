import React, { Component } from 'react';
import { Tabs, Tab } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';
import {
  encodeActivityKeyForURL,
  encodeCostingKeyForURL
} from '../../../../helpers/utilsHelper';
import _ from 'lodash';
import { connect } from 'react-redux';
import { loadModalLinks } from '../../../../actions/actions_app';
import { bindActionCreators } from 'redux';

class ActivitiesRow extends Component {
  constructor(props) {
    super(props);

    this.state = { activeKey: -1 };

    this.handleTabSelect = this.handleTabSelect.bind(this);
  }

  handleTabSelect(index) {
    if (this.state.activeKey === index) {
      index = -1;
    }

    this.setState({
      activeKey: index
    });
  }

  getTransferTypeString(transferType) {
    if (transferType === 'PRIVATE') return 'Private transfer';
    else if (transferType === 'SHARED') return 'Shared transfer';
    else if (transferType === 'NOTRANSFER') return 'No transfer';
    else return 'Transfer';
  }

  render() {
    let {
      activityCostingDetails,
      activityDetails,
      inx,
      activityDiff,
      activityId
    } = this.props;
    let inclusion = { __html: activityDetails.selectedTourGrade.inclusion };

    let activityDetailId = activityDetails.planningToolId;
    let slot = _.find(this.props.allSlot, function(slots) {
      return (
        slots.activitySlotDetail &&
        slots.activitySlotDetail.activityId === activityDetailId
      );
    });

    let slotIdentifier;
    if (slot) {
      slotIdentifier = _.findKey(this.props.allSlot, slot);
      slotIdentifier = encodeActivityKeyForURL(slotIdentifier);
    }

    this.props.loadModalLinks({
      key: encodeCostingKeyForURL(slotIdentifier),
      url: `/${
        this.props.itineraryId
      }/bookingReview/activity-details/${encodeCostingKeyForURL(
        slotIdentifier
      )}`
    });

    return (
      <NavLink
        to={`/${
          this.props.itineraryId
        }/bookingReview/activity-details/${encodeCostingKeyForURL(
          slotIdentifier
        )}`}
      >
        <div className="row">
          <div className="col-xs-12 no-padding v-spaced-5">
            <div className="col-sm-9 col-xs-12">
              <div className="col-xs-1 no-padding width-40 width-20-mobile">
                <span className="spaced-span txt-size-xs">{inx}.</span>
              </div>
              <div className="col-xs-11 no-padding">
                <span className="title oj-text-black font-rounded-variant txt-size-sm">
                  {activityDetails.title}
                </span>
                <span className="txt-size-xs block oj-text-grey">
                  {activityCostingDetails.cityText}
                  . {activityDetails.selectedTourGrade.duration}
                  .{' '}
                  {this.getTransferTypeString(
                    activityDetails.selectedTourGrade.transferType
                  )}
                </span>
              </div>
            </div>
            {activityDetails.free ? (
              <div className="col-xs-4 col-sm-3 text-right hidden-xs">
                <span className="in-combo">SELF EXPLORATION</span>
              </div>
            ) : !this.props.hidePrice ? (
              <div className="col-xs-4 col-sm-3 text-right hidden-xs">
                {activityCostingDetails.inCombo ? (
                  <span className="in-combo">IN COMBO</span>
                ) : activityCostingDetails.inSwissPass ? (
                  <span className="in-combo">IN SWISS PASS</span>
                ) : (
                  <p className="txt-size-sm clear-margin inline-block oj-text-black font-default">
                    <span className="WebRupee">Rs.</span>{' '}
                    {activityCostingDetails.totalCost}
                    {activityDiff ? (
                      <span
                        className={
                          'txt-size-xs block oj-text-grey ' +
                          (activityDiff.priceChangeType !== 'NONE'
                            ? ''
                            : 'no-visibility')
                        }
                      >
                        <span
                          className={
                            'txt-size-sm ' +
                            (activityDiff.priceChangeType === 'PRICEINCREASE'
                              ? 'text-red vehoicon-arrow-up'
                              : 'vehoicon-arrow-down text-green')
                          }
                        />{' '}
                        <span className="WebRupee">Rs.</span>{' '}
                        {activityDiff.priceChangeType === 'PRICEINCREASE'
                          ? '+'
                          : '-'}{' '}
                        {activityDiff.diffCost}
                      </span>
                    ) : null}
                  </p>
                )}
              </div>
            ) : null}
          </div>
          <div className="col-xs-12 no-padding v-spaced-5">
            <div className="col-sm-12 col-xs-8">
              <div className="pull-left margin-left-40 margin-left-20-mobile">
                <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                  schedule
                </span>
                <span className="title oj-text-black txt-size-sm">
                  {activityCostingDetails.mon} {activityCostingDetails.day}
                </span>
                {/* <span className="txt-size-xs block oj-text-grey">Pickup at pickup point</span> */}
              </div>
            </div>
            {activityDetails.free ? (
              <div className="col-xs-4 col-sm-3 text-right visible-xs">
                <span className="in-combo">SELF EXPLORATION</span>
              </div>
            ) : !this.props.hidePrice ? (
              <div className="col-xs-4 col-sm-3 text-right visible-xs">
                <span className="txt-size-xxs block oj-text-light-grey text-uppercase">
                  cost
                </span>
                {activityCostingDetails.inCombo ? (
                  <span className="in-combo">IN COMBO</span>
                ) : activityCostingDetails.inSwissPass ? (
                  <span className="in-combo">IN SWISS PASS</span>
                ) : (
                  <p className="txt-size-sm clear-marg in inline-block oj-text-black font-default">
                    <span className="WebRupee">Rs.</span>{' '}
                    {activityCostingDetails.totalCost}
                    {activityDiff ? (
                      <span
                        className={
                          'txt-size-xs block oj-text-grey ' +
                          (activityDiff.priceChangeType !== 'NONE'
                            ? ''
                            : 'no-visibility')
                        }
                      >
                        <span
                          className={
                            'txt-size-sm ' +
                            (activityDiff.priceChangeType === 'PRICEINCREASE'
                              ? 'text-red vehoicon-arrow-up'
                              : 'vehoicon-arrow-down text-green')
                          }
                        />{' '}
                        <span className="WebRupee">Rs.</span>{' '}
                        {activityDiff.priceChangeType === 'PRICEINCREASE'
                          ? '+'
                          : '-'}{' '}
                        {activityDiff.diffCost}
                      </span>
                    ) : null}
                  </p>
                )}
              </div>
            ) : null}
          </div>

          <div className="col-xs-12 v-spaced-5">
            <div className="margin-left-40 margin-left-20-mobile">
              {activityDetails.free ? null : (
                <div className="col-xs-12 no-padding">
                  <Tabs
                    onSelect={this.handleTabSelect}
                    activeKey={this.state.activeKey}
                    className="oj-small-tabs"
                    id={'activity-tab_' + inx}
                  >
                    <Tab eventKey={1} title="INCLUSIONS">
                      <div className="row">
                        <div className="col-xs-12 txt-size-xs">
                          <div
                            className="dashed col-xs-12 v-spaced"
                            dangerouslySetInnerHTML={inclusion}
                          />
                        </div>
                      </div>
                    </Tab>
                  </Tabs>
                </div>
              )}
            </div>
          </div>
        </div>
      </NavLink>
    );
  }
}

const mapStateToProps = state => {
  const itineraryDetails = state.app.itineraryInfo.itineraryDetails;
  const itineraryId = itineraryDetails
    ? itineraryDetails.itinerary.itineraryId
    : '';
  return {
    itineraryId
  };
};

const mapDispatchToProps = dispatch => {
  return {
    loadModalLinks: bindActionCreators(loadModalLinks, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ActivitiesRow);
