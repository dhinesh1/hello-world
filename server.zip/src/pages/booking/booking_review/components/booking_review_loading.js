import React from 'react';
import BookingReviewLoadingIndicator from './booking_review_loading_indicator';

const BookingReviewLoading = ({ isLoading }) => {
  return (
    <div className={`clearfix booking-pages`}>
      <BookingReviewLoadingIndicator isLoading={isLoading} />
    </div>
  );
};

export default BookingReviewLoading;
