import React, { Component } from 'react';
import { Tabs, Tab } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';

import FlightTripRow from './single_trip_row';
import FlightRouteDetailsRow from './flight_route_details_row';
import FlightBaggageDetailsRow from './flight_baggage_details_row';
import { encodeCostingKeyForURL } from '../../../../helpers/utilsHelper';
import { connect } from 'react-redux';
import { loadModalLinks } from '../../../../actions/actions_app';
import { bindActionCreators } from 'redux';

class FlightSingleRow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeKey: -1,
      sweetAlertConfig: {
        title: '',
        text: '',
        type: '',
        animation: 'pop'
      }
    };

    this.handleTabSelect = this.handleTabSelect.bind(this);
    this.renderFlightTrips = this.renderFlightTrips.bind(this);
  }

  handleTabSelect(index) {
    if (this.state.activeKey === index) {
      index = -1;
    }

    this.setState({
      activeKey: index
    });
  }

  renderFlightTrips() {
    let { flight, inx, packageRate, userDetails } = this.props;

    if (flight.allTrips.length > 0) {
      return flight.allTrips.map((tripId, r_inx) => {
        let tripInfo = flight.trips[tripId];
        let lastRoute = tripInfo.routes.length - 1;

        return (
          <FlightTripRow
            packageRate={packageRate}
            userDetails={userDetails}
            key={tripId}
            tripInfo={tripInfo}
            lastRoute={lastRoute}
            r_inx={r_inx}
          />
        );
      });
    }
  }

  renderFlightDetails() {
    let { flight, inx } = this.props;

    return flight.allTrips.map((tripId, r_inx) => {
      let tripInfo = flight.trips[tripId];
      let airlineCode = flight.airlineCode;
      let lastRoute = r_inx === tripInfo.routes.length - 1;

      return (
        <FlightRouteDetailsRow
          key={'f_details_' + tripId}
          trip={tripInfo}
          islastRoute={lastRoute}
          airlineCode={airlineCode}
        />
      );
    });
  }

  renderFlightBaggageDetails() {
    let { flight } = this.props;

    return flight.allTrips.map((tripId, r_inx) => {
      let tripInfo = flight.trips[tripId];
      let airlineCode = flight.airlineCode;
      let lastRoute = r_inx === tripInfo.routes.length - 1;

      return (
        <FlightBaggageDetailsRow
          key={'f_details_' + tripId}
          trip={tripInfo}
          islastRoute={lastRoute}
          airlineCode={airlineCode}
        />
      );
    });
  }

  componentDidMount() {
    let { flight, itineraryId } = this.props;
    this.props.loadModalLinks({
      key: encodeCostingKeyForURL(flight.key),
      url: `/${itineraryId}/bookingReview/flight-details/${encodeCostingKeyForURL(
        flight.key
      )}`
    });
  }

  render() {
    let {
      flight,
      packageRate,
      flightDiff,
      userDetails,
      itineraryId
    } = this.props;
    return (
      <div className="col-xs-12 no-padding">
        <NavLink
          to={`/${itineraryId}/bookingReview/flight-details/${encodeCostingKeyForURL(
            flight.key
          )}`}
        >
          <div className="row">
            <div className="col-xs-12 no-padding v-spaced-5">
              <div className="col-sm-9 col-xs-9">
                {this.renderFlightTrips()}
              </div>
              <div className={'col-xs-3 no-padding-left col-sm-3 text-right '}>
                <div className={packageRate ? 'no-visibility' : ''}>
                  {!this.props.hidePrice ? (
                    <p className="txt-size-sm clear-margin inline-block oj-text-grey font-default">
                      <span className="WebRupee">Rs.</span> {flight.price}
                    </p>
                  ) : null}
                  {flightDiff ? (
                    <span
                      className={
                        'txt-size-xs block oj-text-grey ' +
                        (flightDiff.priceChangeType !== 'NONE'
                          ? ''
                          : 'no-visibility')
                      }
                    >
                      <span
                        className={
                          'txt-size-sm ' +
                          (flightDiff.priceChangeType === 'PRICEINCREASE'
                            ? 'text-red vehoicon-arrow-up'
                            : 'vehoicon-arrow-down text-green')
                        }
                      />{' '}
                      <span className="WebRupee">Rs.</span>{' '}
                      {flightDiff.priceChangeType === 'PRICEINCREASE'
                        ? '+'
                        : '-'}{' '}
                      {flightDiff.diffCost}
                    </span>
                  ) : null}
                </div>
                {userDetails &&
                userDetails.loggedIn &&
                (userDetails.userType === 'ADMIN' ||
                  userDetails.userType === 'AGENT') &&
                flight.status !== 'BLOCKED' &&
                flight.ourSourceProvider === 'TBO' &&
                !flight.lcc ? (
                  <button
                    onClick={() => this.props.blockFlight(flight.key)}
                    className="btn btn-xs btn-danger"
                    style={{ paddingTop: '1px' }}
                  >
                    Block flight
                  </button>
                ) : null}
                {flight.status === 'BLOCKED' ? (
                  <span className="txt-size-xs oj-text-light-grey">
                    PNR: <span className="bold oj-text-grey">{flight.pnr}</span>{' '}
                  </span>
                ) : null}
              </div>
            </div>

            <div className="col-xs-12 v-spaced-5">
              <div className="margin-left-40 margin-left-20-mobile">
                <div className="col-xs-12 no-padding">
                  {flight.excessBaggageInfo &&
                  flight.excessBaggageInfo.available ? (
                    <span
                      className="add-baggage-btn text-uppercase blue-text txt-size-xxs"
                      onClick={() => this.props.toggleAEBModal(flight.key)}
                    >
                      <span className="vehoicon-luggage spaced-5 oj-text-black txt-size-xs" />
                      <span className="hidden-xs">add extra baggage</span>
                      <span className="visible-xs inline-block-xs">add</span>
                    </span>
                  ) : (
                    ''
                  )}
                  <Tabs
                    className="oj-small-tabs"
                    onSelect={this.handleTabSelect}
                    activeKey={this.state.activeKey}
                    id="flights-tab"
                  >
                    <Tab eventKey={1} title="Flight details">
                      <div className="row">
                        <div className="col-xs-12 txt-size-xs">
                          <div className="col-xs-12 v-spaced">
                            {this.renderFlightDetails()}
                          </div>
                        </div>
                      </div>
                    </Tab>
                    <Tab eventKey={2} title="Baggage info">
                      <div className="row">
                        <div className="col-xs-12 txt-size-xs">
                          <div className="col-xs-12 v-spaced">
                            {this.renderFlightBaggageDetails()}
                          </div>
                        </div>
                      </div>
                    </Tab>
                  </Tabs>
                </div>
              </div>
            </div>
          </div>
        </NavLink>
      </div>
    );
  }
}

const mapStateToProps = state => {
  const itineraryDetails = state.app.itineraryInfo.itineraryDetails;
  const itineraryId = itineraryDetails
    ? itineraryDetails.itinerary.itineraryId
    : '';
  return {
    itineraryId
  };
};

const mapDispatchToProps = dispatch => {
  return {
    loadModalLinks: bindActionCreators(loadModalLinks, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(FlightSingleRow);
