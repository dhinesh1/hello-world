import React from 'react';
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';
import PriceIncreasedButton from './price_increased_button';
import PriceButton from './price_button';

const HotelRow = ({ hotelsArray, isSoldOut }) => {
  if (!hotelsArray.length) return null;

  return (
    <section className="clearfix review-row">
      <div className="left-icon">
        <i className="vehoicon-local_hotel" />
      </div>
      {hotelsArray.map((hotel, hotelIndex) => {
        const {
          name,
          roomsInHotel = [],
          cityName,
          finalPrice,
          diffDetail,
          checkInDateDisplay,
          checkInMonthDisplay,
          checkOutDateDisplay,
          checkOutMonthDisplay
        } = hotel.hotelDetails;

        let priceChangeType,
          diffCost = 0;
        if (diffDetail && !isSoldOut) {
          priceChangeType = diffDetail.diffChangeType;
          diffCost = diffDetail.diffCost;
        }
        return (
          <NavLink key={hotelIndex} to={hotel.url}>
            <p className="lft-col">
              <i>{cityName}</i>
              <span>{name}</span>
            </p>
            <div className="rgt-col">
              <p className="pull-left">
                {`${checkInMonthDisplay} ${checkInDateDisplay} - ${checkOutMonthDisplay} ${checkOutDateDisplay}`}
                {roomsInHotel.map((room, roomIndex) => {
                  const adultCount = room.roomConfiguration.adultCount;
                  const childCount = room.roomConfiguration.childAges.length;
                  return (
                    <span key={roomIndex}>{`${adultCount} adults${
                      childCount ? `, ${childCount} child` : ' one room'
                    }`}</span>
                  );
                })}
              </p>
              <PriceButton
                priceChangeType={priceChangeType}
                price={diffCost.toFixed(0)}
                isSoldOut={isSoldOut}
              />
            </div>
          </NavLink>
        );
      })}
    </section>
  );
};

HotelRow.propTypes = {
  hotelsArray: PropTypes.array.isRequired,
  isSoldOut: PropTypes.bool
};

export default HotelRow;
