import React, { Component } from 'react';
import BookingReviewModalWrapper from './booking_review_modal_wrapper';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';
import _ from 'lodash';
import {
  decodeActivityKeyFromURL,
  encodeActivityKeyForURL
} from '../../../../helpers/utilsHelper';
import ActivityContainer from '../../../../common_components/activity_container';
import ModalLoadingIndicator from '../../../../common_components/modal_loading_indicator';

class ActivityInfoModal extends Component {
  constructor() {
    super();

    this.state = {
      activeActivity: {}
    };
    this.closeModal = this.closeModal.bind(this);
  }

  closeModal() {
    this.props.history.push(
      `/booking-review/${this.props.itineraryInfo.itinerary.itineraryId}`
    );
  }

  componentDidMount() {
    this.getCurrentDetails(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.getCurrentDetails(nextProps);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.iterSlotByKey
    ) {
      let currentSlotKey = props.match.params.activityKey;
      currentSlotKey = decodeActivityKeyFromURL(currentSlotKey);

      let currentDetail = props.itineraryInfo.iterSlotByKey[currentSlotKey];

      let activityDetails =
        props.itineraryInfo.activityById[
          currentDetail.activitySlotDetail.activityId
        ];
      const activityCostingDetails =
        props.itineraryInfo.activityCostings.activityCostingById[
          currentDetail.activitySlotDetail.activityCostingIdentifier
        ];
      _.assign(currentDetail.activitySlotDetail, activityDetails);
      currentDetail.slotIdentifier = currentSlotKey;
      currentDetail = { ...currentDetail, ...activityCostingDetails };

      this.setState({ activeActivity: currentDetail });
    }
  }

  render() {
    if (_.isEmpty(this.state.activeActivity)) return <ModalLoadingIndicator />;

    /**
     * TODO: Unresolved variable hideprice!!
     */
    return (
      <BookingReviewModalWrapper onClose={this.closeModal}>
        <ActivityContainer
          showImages={false}
          activeActivity={this.state.activeActivity}
          splitPricing={this.props.itineraryDetail.splitPricing}
          allowEditOptions={false}
        />
      </BookingReviewModalWrapper>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

export default withRouter(
  connect(mapStateToProps)(ActivityInfoModal)
);
