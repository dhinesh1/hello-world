import React, { Component } from 'react';
import { Modal, ButtonGroup } from 'react-bootstrap';
import _ from 'lodash';

export default class AddExcessBaggage extends Component {
  constructor(props) {
    super(props);

    const state = {
      showModal: false,
      isLoading: false,
      errorMessage: '',
      totalCost: _.toNumber(this.props.cost)
    };

    state.routes = [];
    this.props.excessBaggages.forEach(eb => {
      state[eb.originDestinationKey] = eb.baggageOptions.map(bo => {
        return {
          code: bo.code,
          selectedQuantity: _.toNumber(bo.selectedQuantity),
          price: _.toNumber(bo.price)
        };
      });
      state.routes.push(eb.originDestinationKey);
    });

    this.state = state;

    this.changeExcessBaggage = this.changeExcessBaggage.bind(this);
    this.totalBaggageCount = this.totalBaggageCount.bind(this);
    this.handleUpdateClick = this.handleUpdateClick.bind(this);
  }

  totalBaggageCount(originDestinationKey) {
    return this.state[originDestinationKey].reduce(
      (acc, ele) => acc + ele.selectedQuantity,
      0
    );
  }

  totalCost() {
    return this.state.routes.reduce(
      (acc, ele) =>
        acc +
        this.state[ele].reduce((a, e) => a + e.selectedQuantity * e.price, 0),
      0
    );
  }

  changeExcessBaggage(type, originDestinationKey, code) {
    const boArray = [...this.state[originDestinationKey]];
    const boItem = boArray.find(bo => bo.code === code);
    if (boItem === undefined) return;

    const delta = type === 'add' ? 1 : type === 'reduce' ? -1 : 0;

    boItem.selectedQuantity += delta;

    this.setState({
      ...this.state,
      [originDestinationKey]: boArray,
      totalCost: this.state.totalCost + delta * boItem.price
    });
  }

  handleUpdateClick() {
    this.props.updateBaggage({
      itineraryId: this.props.itineraryId,
      excessBaggageInfo: {
        allowedExcessBaggageCount: this.props.allowedExcessBaggageCount,
        excessBaggages: this.state.routes.map(r => {
          return {
            originDestinationKey: r,
            baggageOptions: this.state[r].map(bo => {
              return {
                code: bo.code,
                selectedQuantity: bo.selectedQuantity
              };
            })
          };
        })
      }
    });
  }

  render() {
    return (
      <div className="get-cost-modal-wrapper">
        <Modal
          backdrop="static"
          show={this.props.showModal}
          className="modal oj-modal fade"
          tabIndex="-1"
          role="dialog"
          onHide={this.props.toggleAEBModal}
        >
          <Modal.Body className="add-baggage-modal">
            <div className="row">
              <div className="col-md-12 col-xs-12">
                <div className="activity-info block-shadow col-xs-12 no-padding">
                  <div className="activity-header">
                    <button
                      type="button"
                      className="close white"
                      data-dismiss="modal"
                      aria-label="Close"
                      onClick={() => this.props.toggleAEBModal()}
                    >
                      <span className="vehoicon-close" aria-hidden="true" />
                    </button>
                    <span
                      className="activity-title bold"
                      id="add-baggage-title oj-label"
                    >
                      Add Baggage
                    </span>
                    <div className="actions pull-right">
                      <button
                        type="button"
                        className="btn btn-orange"
                        data-dismiss="modal"
                        onClick={() => this.handleUpdateClick()}
                      >
                        Update
                      </button>
                    </div>
                  </div>
                  <div className="activity-content">
                    <div className="row">
                      <div className="col-xs-12">
                        <div
                          className="alert alert-info box-shadow corner"
                          role="alert"
                        >
                          <div className="row clear-margin">
                            <div className="col-sm-10 col-xs-7">
                              <a
                                href="javascript:void(0);"
                                className=" color-black"
                              >
                                Total additional baggage cost for{' '}
                                {_.toNumber(this.props.adult_count) +
                                  _.toNumber(this.props.child_count)}
                                travellers
                              </a>
                            </div>
                            <div className="col-sm-2 col-xs-5">
                              <span className="pull-right txt-size-sm bold color-black">
                                ₹{this.state.totalCost}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="row clear-margin">
                      <div className="col-xs-12">
                        {this.props.excessBaggages.map(flightBaggageOptions => (
                          <FlightBaggageOptions
                            key={flightBaggageOptions.originDestinationKey}
                            {...flightBaggageOptions}
                            {...this.props}
                            changeExcessBaggage={this.changeExcessBaggage}
                            totalBaggageCount={this.totalBaggageCount}
                            selectedQuantities={
                              this.state[
                                flightBaggageOptions.originDestinationKey
                              ]
                            }
                          />
                        ))}
                        <div className="content-v-pad" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

const FlightBaggageOptions = props => {
  const totalBaggageCount = props.totalBaggageCount(props.originDestinationKey);
  return (
    <div className="padding-left-20 padding-right">
      <div className="row flex vertical-center">
        <div className="col-md-8 col-xs-8 ">
          <span className="text-left">
            <p className="text-black">
              {props.origin} <span className="vehoicon-arrow-right" />{' '}
              {props.destination}
            </p>
            <p className="text-light-grey">{props.carrierName}</p>
          </span>
        </div>
        <div className="col-md-4 col-xs-4 ">
          <span className="text-light-grey">
            Max. {props.allowedExcessBaggageCount} additional bags
          </span>
        </div>
      </div>
      <div className="border-dark-grey border-bottom v-spaced" />
      <div className="list oj-list line-height-30 border-bottom border-dark-grey">
        {props.baggageOptions.map(baggageOption => (
          <BaggageOption
            key={baggageOption.code}
            {...baggageOption}
            {...props}
            selectedQuantity={props.selectedQuantities.reduce(
              (acc, ele) =>
                ele.code === baggageOption.code ? ele.selectedQuantity : acc,
              0
            )}
            totalBaggageCount={totalBaggageCount}
          />
        ))}
      </div>
    </div>
  );
};

const BaggageOption = props => {
  return (
    <div className="list oj-list hover-block line-height-30 border-bottom border-dark-grey">
      <div className="row flex  vertical-center">
        <div className="col-md-5 col-xs-12 ">
          <span className="color-black bold">
            {props.weight === '0'
              ? 'No baggage'
              : 'Check in baggage upto ' + props.weight + ' kg'}
          </span>
        </div>
        <div className="col-md-2 col-xs-12 text-right">
          <span className="color-black">
            <span className="vehoicon-rupee" />
            {props.price}
          </span>
        </div>
        <CallToAction {...props} />
      </div>
    </div>
  );
};

const CallToAction = props => {
  const buttonAdd = (
    <div className="col-md-5 col-xs-12 center">
      <button
        className="btn btn-green pull-right btn-xs btn-border-only show-on-hover"
        disabled={props.totalBaggageCount >= props.allowedExcessBaggageCount}
        onClick={() => {
          props.changeExcessBaggage(
            'add',
            props.originDestinationKey,
            props.code
          );
        }}
      >
        Add
      </button>
    </div>
  );

  const buttonGroup = (
    <div className="col-md-5 col-xs-12 center">
      <ButtonGroup>
        <button
          type="button"
          className="btn btn-xs btn-green"
          disabled={props.totalBaggageCount <= 0}
          onClick={() =>
            props.changeExcessBaggage(
              'reduce',
              props.originDestinationKey,
              props.code
            )
          }
        >
          <span className="vehoicon-remove_circle txt-size-sm" />
        </button>
        <button type="button" className="btn btn-xs btn-green btn-border-only ">
          <span className="color-black bold">{props.selectedQuantity}</span>
        </button>
        <button
          type="button"
          className="btn btn-xs btn-green "
          disabled={
            props.disabled ||
            props.totalBaggageCount >= props.allowedExcessBaggageCount
          }
          onClick={() =>
            props.changeExcessBaggage(
              'add',
              props.originDestinationKey,
              props.code
            )
          }
        >
          <span className="vehoicon-add_circle txt-size-sm" />
        </button>
      </ButtonGroup>
    </div>
  );

  return props.selectedQuantity > 0 ? buttonGroup : buttonAdd;
};
