import React, { Component } from 'react';
import BookingReviewModalWrapper from './booking_review_modal_wrapper';
import { connect } from 'react-redux';
import { decodeCostingKeyFromURL } from '../../../../helpers/utilsHelper';
import HotelContainer from '../../../../common_components/hotel_container';
import _ from 'lodash';
import ModalLoadingIndicator from '../../../../common_components/modal_loading_indicator';

class HotelInfoModal extends Component {
  constructor() {
    super();

    this.state = {
      hotelDetails: {}
    };
    this.closeModal = this.closeModal.bind(this);
    this.getCurrentHotelDetails = this.getCurrentHotelDetails.bind(this);
  }

  closeModal() {
    this.props.history.push(
      `/booking-review/${this.props.itineraryInfo.itinerary.itineraryId}`
    );
  }

  componentDidMount() {
    this.getCurrentHotelDetails(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.getCurrentHotelDetails(nextProps);
  }

  getCurrentHotelDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.hotelCostings
    ) {
      let currentHotelKey = props.match.params.hotelKey;
      currentHotelKey = decodeCostingKeyFromURL(currentHotelKey);

      let currentDetail =
        props.itineraryInfo.hotelCostings.hotelCostingById[currentHotelKey];

      this.setState({ hotelDetails: currentDetail });
    }
  }

  render() {
    if (_.isEmpty(this.props.itineraryDetail)) return <ModalLoadingIndicator />;
    return (
      <BookingReviewModalWrapper onClose={this.closeModal}>
        <HotelContainer
          showImages={false}
          hotel={this.state.hotelDetails}
          itineraryDetail={this.props.itineraryDetail}
          userDetails={this.props.user_details}
          packageRate={this.props.packageRate}
          itineraryId={this.props.itineraryDetail.itineraryId}
          hotelGuestRoomConfigurations={this.props.hotelGuestRoomConfigurations}
          allowChangeRoom={false}
        />
      </BookingReviewModalWrapper>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

export default connect(mapStateToProps)(HotelInfoModal);
