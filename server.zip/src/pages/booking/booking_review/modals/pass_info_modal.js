import React, { Component } from 'react';
import BookingReviewModalWrapper from './booking_review_modal_wrapper';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import ComboPanels from '../../../itinerary/components/costing_screen/panels/combo_panels';
import _ from 'lodash';
import ModalLoadingIndicator from '../../../../common_components/modal_loading_indicator';
import PassContainter from '../../../../common_components/pass_container';

class PassInfoModal extends Component {
  constructor() {
    super();

    this.state = {
      activePass: {}
    };
    this.closeModal = this.closeModal.bind(this);
    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  closeModal() {
    this.props.history.push(
      `/booking-review/${this.props.itineraryInfo.itinerary.itineraryId}`
    );
  }

  componentDidMount() {
    this.getCurrentDetails(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.getCurrentDetails(nextProps);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.allPassCostingRefs
    ) {
      const passId = props.match.params.passId;
      const activePass =
        props.itineraryInfo.passCostings.passCostingById[passId];
      this.setState({ activePass });
    }
  }

  render() {
    if (
      _.isEmpty(this.props.itineraryDetail) ||
      _.isEmpty(this.state.activePass)
    )
      return <ModalLoadingIndicator />;
    return (
      <BookingReviewModalWrapper onClose={this.closeModal}>
        <PassContainter
          pass={this.state.activePass}
          isLast={false}
          costedItinerary={this.props.itineraryInfo}
          splitPricing={this.props.itineraryInfo.itinerary.splitPricing}
          hideDetails={true}
          handleDetailsClick={() => null}
        />
      </BookingReviewModalWrapper>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

export default withRouter(
  connect(mapStateToProps)(PassInfoModal)
);
