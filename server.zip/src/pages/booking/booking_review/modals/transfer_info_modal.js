import React, { Component } from 'react';
import BookingReviewModalWrapper from './booking_review_modal_wrapper';
import _ from 'lodash';
import TransferContainer from '../../../../common_components/transfer_container';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { decodeCostingKeyFromURL } from '../../../../helpers/utilsHelper';
import ModalLoadingIndicator from '../../../../common_components/modal_loading_indicator';

class TransferInfoModal extends Component {
  constructor() {
    super();

    this.state = {
      activeTransfer: {}
    };
    this.closeModal = this.closeModal.bind(this);
    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  closeModal() {
    this.props.history.push(
      `/booking-review/${this.props.itineraryInfo.itinerary.itineraryId}`
    );
  }

  componentDidMount() {
    this.getCurrentDetails(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.getCurrentDetails(nextProps);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.allTransferCostingRefs
    ) {
      let transferId = props.match.params.transferKey;
      transferId = decodeCostingKeyFromURL(transferId);

      const activeTransfer =
        props.itineraryInfo.transferCostings.transferCostingById[transferId];
      this.setState({ activeTransfer });
    }
  }

  render() {
    if (_.isEmpty(this.props.itineraryDetail)) return <ModalLoadingIndicator />;

    const isNonEditable = true;
    const is_hidden = this.state.activeTransfer.alternateAvailable
      ? ''
      : 'hidden';
    return (
      <BookingReviewModalWrapper onClose={this.closeModal}>
        <TransferContainer
          is_hidden={is_hidden}
          isNonEditable={isNonEditable}
          transfer={this.state.activeTransfer}
          userDetails={this.props.userDetails}
          child_count={this.props.child_count}
          adult_count={this.props.adult_count}
          splitPricing={this.props.itineraryDetail.splitPricing}
          itineraryId={this.props.itineraryInfo.itinerary.itineraryId}
          transferTypeChangeText={''}
          insideModal={true}
          regionCode={this.props.itineraryDetail.regionCode}
        />
      </BookingReviewModalWrapper>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

export default withRouter(
  connect(mapStateToProps)(TransferInfoModal)
);
