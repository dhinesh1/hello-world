import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { loadModalLinks } from '../../../../actions/actions_app';
import { bindActionCreators } from 'redux';
import _ from 'lodash';

class BookingReviewModalFooter extends Component {
  static propTypes = {
    onClose: PropTypes.func.isRequired
  };

  goBack = () => {
    const urlIndex = _.findIndex(this.props.modalList, {
      url: this.props.location.pathname
    });
    const nextPage = this.props.modalList[urlIndex - 1];
    this.props.history.push(nextPage.url);
  };

  goNext = () => {
    const urlIndex = _.findIndex(this.props.modalList, {
      url: this.props.location.pathname
    });
    const nextPage = this.props.modalList[urlIndex + 1];
    this.props.history.push(nextPage.url);
  };

  render() {
    const { onClose } = this.props;

    const urlIndex = _.findIndex(this.props.modalList, {
      url: this.props.location.pathname
    });
    const isFirst = urlIndex === 0;
    const isLast = urlIndex === this.props.modalList.length - 1;

    return (
      <div className="modal-footer">
        <button
          onClick={onClose}
          type="button"
          className="pull-left btn close"
          data-dismiss="modal"
        >
          <i className="vehoicon-close" />
        </button>
        {!isLast ? (
          <button
            type="button"
            onClick={this.goNext}
            className="pull-right btn btn-primary-dark btn-outline"
          >
            Next booking <i className="vehoicon-left rotate-minus-90" />
          </button>
        ) : null}
        {!isFirst ? (
          <button
            type="button"
            onClick={this.goBack}
            className="pull-right btn btn-primary-dark btn-outline"
          >
            {isLast ? 'Prev Booking' : null}{' '}
            <i className="vehoicon-left rotate-90" />
          </button>
        ) : null}
      </div>
    );
  }
}

const mapStateToProps = state => {
  const itineraryDetails = state.app.itineraryInfo.itineraryDetails;
  const itineraryId = itineraryDetails
    ? itineraryDetails.itinerary.itineraryId
    : '';
  return {
    itineraryId,
    modalList: state.modalList
  };
};

const mapDispatchToProps = dispatch => {
  return {
    loadModalLinks: bindActionCreators(loadModalLinks, dispatch)
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(BookingReviewModalFooter)
);
