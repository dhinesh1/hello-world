import React, { Component } from 'react';
import PropTypes from 'prop-types';
import BookingReviewModalFooter from './booking_review_modal_footer';

class BookingReviewModalWrapper extends Component {
  static propTypes = {
    children: PropTypes.element.isRequired,
    onClose: PropTypes.func.isRequired
  };

  closeModal = e => {
    if (e.keyCode === 27) this.props.onClose();
  };

  componentDidMount() {
    document.addEventListener('keyup', this.closeModal);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.closeModal);
  }

  render() {
    const { children, onClose } = this.props;
    return (
      <div>
        <div
          className="modal fade in modal-sticky-footer alternate-modal hotel-modal booking-review-modal"
          tabIndex={-1}
        >
          <div className="modal-dialog">
            <div className="modal-content with-footer">
              <div className="modal-body">{children}</div>
              <BookingReviewModalFooter onClose={onClose} />
            </div>
          </div>
        </div>
        <div className="modal-backdrop fade in" />
      </div>
    );
  }
}

export default BookingReviewModalWrapper;
