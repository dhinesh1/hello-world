import React, { Component } from 'react';
import BookingReviewModalWrapper from './booking_review_modal_wrapper';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { decodeCostingKeyFromURL } from '../../../../helpers/utilsHelper';
import FerryContainer from '../../../../common_components/ferry_container';
import _ from 'lodash';
import ModalLoadingIndicator from '../../../../common_components/modal_loading_indicator';

class FerryInfoModal extends Component {
  constructor() {
    super();

    this.state = {
      activeFerry: {}
    };
    this.closeModal = this.closeModal.bind(this);
    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  closeModal() {
    this.props.history.push(
      `/booking-review/${this.props.itineraryInfo.itinerary.itineraryId}`
    );
  }

  componentDidMount() {
    this.getCurrentDetails(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.getCurrentDetails(nextProps);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.allTrainCostingRefs
    ) {
      let transferId = props.match.params.transferKey;
      transferId = decodeCostingKeyFromURL(transferId);

      const activeFerry =
        props.itineraryInfo.ferryCostings.ferryCostingById[transferId];
      this.setState({ activeFerry });
    }
  }

  render() {
    if (_.isEmpty(this.props.itineraryDetail)) return <ModalLoadingIndicator />;

    return (
      <BookingReviewModalWrapper onClose={this.closeModal}>
        <FerryContainer
          ferry={this.state.activeFerry}
          splitPricing={this.props.itineraryDetail.splitPricing}
          disableEditing={true}
        />
      </BookingReviewModalWrapper>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

export default withRouter(
  connect(mapStateToProps)(FerryInfoModal)
);
