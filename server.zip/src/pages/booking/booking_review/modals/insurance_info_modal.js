import React, { Component } from 'react';
import _ from 'lodash';
import BookingReviewModalWrapper from './booking_review_modal_wrapper';
import ModalLoadingIndicator from '../../../../common_components/modal_loading_indicator';
import InsurancePanels from '../../../itinerary/components/costing_screen/panels/insurance_panels';
import { connect } from 'react-redux';

class InsuranceInfoModal extends Component {
  constructor() {
    super();

    this.closeModal = this.closeModal.bind(this);
  }

  closeModal() {
    this.props.history.push(
      `/booking-review/${this.props.itineraryInfo.itinerary.itineraryId}`
    );
  }

  render() {
    const {
      itineraryDetail,
      costedItinerary,
      adult_count,
      child_count,
      userDetails
    } = this.props;
    if (_.isEmpty(itineraryDetail)) return <ModalLoadingIndicator />;
    return (
      <BookingReviewModalWrapper onClose={this.closeModal}>
        <div className={'modal-row pt-0 cost-container'}>
          <InsurancePanels
            allowEditingOptions={false}
            isBooked={
              costedItinerary.itinerary.booking ||
              costedItinerary.itinerary.frozen
            }
            userDetails={userDetails}
            itineraryId={costedItinerary.itinerary.itineraryId}
            regionCode={itineraryDetail.regionCode}
            insuranceCosting={costedItinerary.insuranceCosting}
            adult_count={adult_count}
            child_count={child_count}
            splitPricing={costedItinerary.itinerary.splitPricing}
          />
        </div>
      </BookingReviewModalWrapper>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      costedItinerary: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

export default connect(mapStateToProps)(InsuranceInfoModal);
