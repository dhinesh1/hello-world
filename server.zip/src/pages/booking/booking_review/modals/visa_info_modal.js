import React, { Component } from 'react';
import BookingReviewModalWrapper from './booking_review_modal_wrapper';
import _ from 'lodash';
import { connect } from 'react-redux';
import ModalLoadingIndicator from '../../../../common_components/modal_loading_indicator';
import VisaPanels from '../../../itinerary/components/costing_screen/panels/visa_panels';
import VisaContainer from '../../../../common_components/visa_container';
import { decodeCostingKeyFromURL } from '../../../../helpers/utilsHelper';

class VisaInfoModal extends Component {
  constructor() {
    super();

    this.state = {
      activeVisa: {},
      totalVisaCost: ''
    };
    this.closeModal = this.closeModal.bind(this);
    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  closeModal() {
    this.props.history.push(
      `/booking-review/${this.props.itineraryInfo.itinerary.itineraryId}`
    );
  }

  componentDidMount() {
    this.getCurrentDetails(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.getCurrentDetails(nextProps);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.allPassCostingRefs
    ) {
      const visaId = decodeCostingKeyFromURL(props.match.params.visaId);
      const activeVisa =
        props.itineraryInfo.visaCostings.visaCostingById[visaId];
      const totalVisaCost = props.itineraryInfo.visaCostings.totalVisaCost;
      this.setState({ activeVisa, totalVisaCost });
    }
  }

  render() {
    if (
      _.isEmpty(this.props.itineraryDetail) ||
      _.isEmpty(this.state.activeVisa)
    )
      return <ModalLoadingIndicator />;

    return (
      <BookingReviewModalWrapper onClose={this.closeModal}>
        <div className={'modal-row pt-0 cost-container'}>
          <VisaContainer
            visaDetails={this.state.activeVisa}
            allowEditingOptions={false}
            splitPricing={this.props.itineraryInfo.itinerary.splitPricing}
            handleCallToActionClick={() => null}
            totalVisaCost={this.state.totalVisaCost}
            visaId={decodeCostingKeyFromURL(this.props.match.params.visaId)}
            isNonEditable={true}
          />
        </div>
      </BookingReviewModalWrapper>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      costedItinerary: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count,
      itineraryInfo: app.itineraryInfo.itineraryDetails
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

export default connect(mapStateToProps)(VisaInfoModal);
