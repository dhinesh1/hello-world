import React, { Component } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { triggerSimpleAjax } from "../../../../helpers/httpHelper";
import { AppConfig } from "../../../../app-config";
import { fetchItinerary } from "../../../../actions/actions_app";
import Loader from "../../../../common_components/Loader";
import { compact } from 'lodash';
import { trackEvent, EVENT_COUPON_APPLIED } from "../../../../helpers/ML/EventsTracker";

class ApplyPromoModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      couponCode: ['','','','','','','',''],
      error: null,
      applyingPromo: false
    };
    this.applyPromo = this.applyPromo.bind(this);
    this.myRef = React.createRef();
  }

  updatePromo = (e, position) => {
    let currentCode = Object.assign([], this.state.couponCode);
    currentCode[position] = e.currentTarget.value;
    if (e.currentTarget.value) {
      e.currentTarget.nextElementSibling &&
        e.currentTarget.nextElementSibling.focus();
    }
    this.setState({
      couponCode: currentCode
    });
  };

  onFailure = () => {
    this.setState({
      applyingPromo: false,
      error: true
    });
  };

  onSuccess = response => {
    this.setState({
      applyingPromo: false
    });
    this.props.onPromoCodeSuccess(response);
    trackEvent(EVENT_COUPON_APPLIED);
    this.closeModal();
  };

  async applyPromo() {
    const couponCode = this.state.couponCode.join(""); // created a string for coupon of length 8
    if (compact(couponCode).length < 8) {
      this.setState({ error: true, applyPromo: false });
      return;
    }
    this.setState({
      applyingPromo: true,
      error: null
    });
    const { itineraryId } = this.props;
    const url = `${
      AppConfig.api_url
    }coupon/apply/${couponCode}?itineraryId=${itineraryId}`;

    await triggerSimpleAjax(url, "POST", {}, this.onSuccess, this.onFailure);
  }

  closeModal = () => {
    this.props.history.push(`/booking-review/${this.props.itineraryId}`);
  };

  onFocus = e => {
   e.currentTarget.placeholder = "";
    return;
  };

  onBlur = e => {
    if (e.target.value === "") {
      e.currentTarget.placeholder = "0";
    }
    return;
  };

  handleBackPress = (e, i) => {
   let currentCode = Object.assign([], this.state.couponCode);
   if(e.key.toLowerCase() !== 'backspace'){
     return;
   }
  if(e.currentTarget.value){
    currentCode[i] = '';
    e.currentTarget.focus();
   }else if(i>0){
    if(e.key && e.key.toLowerCase() === 'backspace' && e.currentTarget.previousElementSibling){
      e.currentTarget.previousElementSibling.focus();
      e.currentTarget.placeholder = "0";
     }
     currentCode[i-1] = '';
   }else{
    e.currentTarget.focus();
   }
   this.setState({
     couponCode: currentCode
   })
  }
 
  render() {
    const { couponCode, error, applyingPromo } = this.state;
    const inputBoxes = [];
    for (let i = 0; i < 8; i++) {
      inputBoxes.push(
        <input
          type="text"
          className="form-control"
          placeholder={0}
          maxLength={1}
          value={couponCode[i]}
          onChange={e => {
            this.updatePromo(e, i);
          }}
          onFocus={this.onFocus}
          onBlur={this.onBlur}
          onKeyDown={(e) => this.handleBackPress(e, i)}
          key={i}
        />
      );
    }
    return (
      <div>
        {applyingPromo ? <Loader /> : null}
        <div
          className="modal fade in modal-sticky-header promo-code"
          tabIndex={-1}
        >
          <div className="modal-dialog">
            <div className="modal-content with-header">
              <div className="modal-header vertical-center">
                <p>Promotions</p>
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  onClick={this.closeModal}
                >
                  <i className="vehoicon-close" />
                </button>
              </div>
              <div className="modal-body">
                <div className="form-group form-group-lg text-center">
                  <label className="control-label">
                    Please Enter Your Promotional Code Here
                  </label>
                  <div className="txtboxes-outer">{inputBoxes}</div>
                  {error ? (
                    <p className="msg">
                      <i className="fade color-accent-7 vehoicon-cancel" />Oops!
                      This promo code is invalid. Are you sure it’s the right
                      one?
                    </p>
                  ) : null}
                  <button
                    type="button"
                    className="btn btn-primary-dark btn-lg"
                    onClick={this.applyPromo}
                  >
                    Apply Code
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="modal-backdrop fade in" />
      </div>
    );
  }
}

const mapStateToProps = state => {
  const itineraryDetails = state.app.itineraryInfo && state.app.itineraryInfo.itineraryDetails;

  return {
    itineraryId: itineraryDetails.itinerary.itineraryId
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onPromoCodeSuccess: bindActionCreators(fetchItinerary, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ApplyPromoModal);
