import React, { Component } from 'react';
import { connect } from 'react-redux';
import _ from 'lodash';
import { decodeCostingKeyFromURL } from '../../../../helpers/utilsHelper';
import FlightContainer from '../../../../common_components/flight_container';
import BookingReviewModalWrapper from './booking_review_modal_wrapper';
import ModalLoadingIndicator from '../../../../common_components/modal_loading_indicator';

class FlightInfoModal extends Component {
  constructor() {
    super();

    this.state = {
      flight: {}
    };
    this.closeModal = this.closeModal.bind(this);
    this.getCurrentFlight = this.getCurrentFlight.bind(this);
  }

  closeModal() {
    this.props.history.push(
      `/booking-review/${this.props.itineraryInfo.itinerary.itineraryId}`
    );
  }

  componentDidMount() {
    this.getCurrentFlight(this.props);
  }

  componentWillReceiveProps(props) {
    this.getCurrentFlight(props);
  }

  getCurrentFlight(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.flightCostings
    ) {
      let currentFlightKey = props.match.params.flightKey;
      currentFlightKey = decodeCostingKeyFromURL(currentFlightKey);
      let currentFlight =
        props.itineraryInfo.flightCostings.flightCostingById[currentFlightKey];

      this.setState({ flight: currentFlight });
    }
  }

  render() {
    if (_.isEmpty(this.state.flight)) return <ModalLoadingIndicator />;
    let { child_count, adult_count } = this.props;
    let { flight: flightData } = this.state;
    let roundTripLabel =
      flightData.allTrips.length === 2 ? '(Round trip)' : null;
    let childCountMarkup = '';
    if (child_count > 0) {
      childCountMarkup = ' + ' + child_count;
    }
    return (
      <BookingReviewModalWrapper onClose={this.closeModal}>
        <div className={'modal-row pt-0'}>
          <FlightContainer
            flightData={flightData}
            roundTripLabel={roundTripLabel}
            childCountMarkup={childCountMarkup}
            adult_count={adult_count}
          />
        </div>
      </BookingReviewModalWrapper>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

export default connect(mapStateToProps)(FlightInfoModal);
