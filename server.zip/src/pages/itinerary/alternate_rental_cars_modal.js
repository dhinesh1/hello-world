import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import _ from 'lodash';
import axios from 'axios';

import { Range } from 'rc-slider';
import PriceDiff from '../../common_components/price_diff';
import AlternateFilterLoading from './components/loaders/alternate_filters_loading';
import AlternateHotelsActivitiesLoading from './components/loaders/alternate_hotels_activities_loading';
import { changeRentalCar } from '../../actions/actions_app';
import {
  decodeActivityKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import { itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';
import { AppConfig } from '../../app-config';
import classNames from 'classnames';
const API_URL = AppConfig.api_url;

/*global swal */

const toProperCase = str => {
  if (!isNaN(str)) return str;
  let value = str.toLowerCase();
  return value[0].toUpperCase() + value.slice(1);
};

class AlternateRentalCars extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      showContentPlaceHolders: true,
      carCostFilter: {
        minPrice: null,
        maxPrice: null
      },
      maxSeatsFilter: {},
      carTypeFilter: {},
      gearTypeFilter: {},
      activeRCDetails: {},
      enableFilterOnMobile: false
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.getRentalCarOptions = this.getRentalCarOptions.bind(this);
    this.filterRentalCarOptions = this.filterRentalCarOptions.bind(this);
    this.updateFilter = this.updateFilter.bind(this);
    this.changeRentalCar = this.changeRentalCar.bind(this);
    this.getFilterChoices = this.getFilterChoices.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.getCurrentDetails = this.getCurrentDetails.bind(this);

    this.showRCFilters = this.showRCFilters.bind(this);
    this.hideRCFilters = this.hideRCFilters.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);
    document.addEventListener('keyup', this.handleKeyUp);
  }
  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.rentalCarCostings &&
      !Object.keys(this.state.activeRCDetails).length
    ) {
      let currentKey = this.props.match.params.rcKey;
      currentKey = decodeActivityKeyFromURL(currentKey);
      let currentDetail =
        props.itineraryInfo.rentalCarCostings.rentalCostingById[currentKey];

      if (!currentDetail) {
        this.closeModal();
      }

      this.setState(
        {
          activeRCDetails: currentDetail,
          insuranceType: currentDetail.insuranceType,
          insuranceCost: currentDetail.insuranceCost
        },
        () => {
          this.getRentalCarOptions(
            props.itineraryInfo.itinerary.itineraryId,
            currentKey
          );
        }
      );
    }
  }

  openModal() {
    this.setState({ showModal: true }, () => {
      onceModalOpened();
    });
  }

  closeModal(replace = false) {
    let { history, location, match, itineraryDetail } = this.props;

    // let _this = this;
    // let ele = _this.refs.modal;
    // $(ele).addClass('out');

    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        onceModalClosed();
        const pageUrl = itineraryModalsRouteHelper({
          itineraryId: itineraryDetail.itineraryId,
          regionCode: itineraryDetail.regionCode,
          location
        });

        if (replace) {
          history.replace(pageUrl);
        } else {
          history.push(pageUrl);
        }
      });
    }, 400);
  }

  getRentalCarOptions(itineraryId, rentalCarKey) {
    const url = `${API_URL}itinerary/${itineraryId}/alternateCarOptions`;

    axios
      .post(url, { rentalCarKey: rentalCarKey })
      .then(response => {
        let data = response.data.data;
        const priceArray = data.map(rc =>
          _.toNumber((rc.totalCost || '').replace(',', ''))
        );
        const minPrice = _.min(priceArray),
          maxPrice = _.max(priceArray);

        this.setState({
          rentalCarOptions: data,
          showContentPlaceHolders: false,
          carCostFilter: {
            minPrice: minPrice,
            maxPrice: maxPrice
          },
          minPrice: minPrice,
          maxPrice: maxPrice
        });
      })
      .catch(e => {
        console.warn(e);
        swal('Something went wrong. Please try again.');
      });
  }

  hideRCFilters() {
    this.setState({ enableFilterOnMobile: false });
  }

  showRCFilters() {
    this.setState({ enableFilterOnMobile: true });
  }

  changeRentalCar(selectedCarCode) {
    this.props
      .changeRentalCar({
        carCode: selectedCarCode,
        rentalCarKey: this.state.activeRCDetails.key,
        itineraryId: this.props.itineraryDetail.itineraryId
      })
      .then(() => {
        this.closeModal(true);
      })
      .catch(() => {
        this.closeModal(true);
      });
  }

  updateFilter(filterPrefix, value) {
    const newState = { ...this.state };
    const filter = newState[filterPrefix + 'Filter'];

    if (filterPrefix !== 'carCost') {
      if (value in filter) delete filter[value];
      else filter[value] = true;
    } else if (filterPrefix) {
      filter.minPrice = value[0];
      filter.maxPrice = value[1];
    }

    this.setState(newState);
  }

  filterRentalCarOptions() {
    const rentalCarOptions = this.state.rentalCarOptions || [];
    const carCostFilter = this.state.carCostFilter;
    const carTypeFilter = this.state.carTypeFilter;
    const gearTypeFilter = this.state.gearTypeFilter;
    const maxSeatsFilter = this.state.maxSeatsFilter;

    if (rentalCarOptions.length === 0) return [];

    return rentalCarOptions.filter(rentalCar => {
      const carCost = _.toNumber((rentalCar.totalCost || '').replace(',', ''));
      return (
        (_.isEmpty(carTypeFilter) ||
          rentalCar.carType.toLowerCase() in carTypeFilter) &&
        (_.isEmpty(gearTypeFilter) ||
          rentalCar.gearType.toLowerCase() in gearTypeFilter) &&
        (_.isEmpty(maxSeatsFilter) ||
          rentalCar.maxSeats.toString() in maxSeatsFilter) &&
        carCost <= carCostFilter.maxPrice &&
        carCost >= carCostFilter.minPrice
      );
    });
  }

  getFilterChoices() {
    const rentalCarOptions = this.state.rentalCarOptions;

    const filterChoices = {
      carTypeChoices: [],
      gearTypeChoices: [],
      maxSeatsChoices: []
    };

    if (!rentalCarOptions || rentalCarOptions.length === 0)
      return filterChoices;

    rentalCarOptions.forEach(rentalCar => {
      filterChoices.carTypeChoices.push(rentalCar.carType.toLowerCase());
      filterChoices.gearTypeChoices.push(rentalCar.gearType.toLowerCase());
      filterChoices.maxSeatsChoices.push(rentalCar.maxSeats);
    });

    filterChoices.carTypeChoices = _.uniq(filterChoices.carTypeChoices);
    filterChoices.gearTypeChoices = _.uniq(filterChoices.gearTypeChoices);
    filterChoices.maxSeatsChoices = _.uniq(filterChoices.maxSeatsChoices);

    return filterChoices;
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }

  render() {
    const filteredRentalCarOptions = this.filterRentalCarOptions();
    const filters = Object.assign(
      {},
      { carType: this.state.carTypeFilter },
      { gearType: this.state.gearTypeFilter },
      { maxSeats: this.state.maxSeatsFilter },
      { carCost: this.state.carCostFilter }
    );
    const filterChoices = this.getFilterChoices();
    let { activeRCDetails } = this.state;

    return (
      <div
        tabIndex="0"
        className={
          'modal fade alternate-modal width-auto ' +
          (this.state.showModal ? 'in' : '')
        }
        id="change-rentalcar-modal"
        ref="modal"
      >
        <div
          className={classNames('modal-dialog', {
            'enable-filter': this.state.enableFilterOnMobile
          })}
        >
          <div className="container modal-alternate-wrapper">
            <div className="row">
              <div className="filter-display col-md-3 gutter-less-filter">
                {!this.state.showContentPlaceHolders ? (
                  <RentalCarOptionsFilters
                    splitPricing={this.props.itineraryDetail.splitPricing}
                    {...filterChoices}
                    closeModal={this.closeModal}
                    updateFilter={this.updateFilter}
                    filters={filters}
                    minPrice={this.state.minPrice}
                    maxPrice={this.state.maxPrice}
                    hideRCFilters={this.hideRCFilters}
                  />
                ) : (
                  <AlternateFilterLoading loaderState={false} />
                )}
              </div>
              <div className="col-md-9 mobile-hide-on-filter">
                <div className={'modal-content with-header'}>
                  <div className={'modal-header'}>
                    <div className="header-bar mobile-toggle">
                      <div className="pull-right visible-xs visible-sm">
                        <button
                          className="trans-btn"
                          onClick={this.showRCFilters}
                        >
                          <span className="vehoicon-tune modal-filter" />
                        </button>
                      </div>

                      <span className="text-uppercase kern-more bolder fade">
                        Change Rental car
                      </span>

                      <button
                        type="button"
                        className="close"
                        onClick={this.closeModal}
                      >
                        <i className="vehoicon-close" />
                      </button>
                    </div>
                  </div>

                  <div className={'modal-body'}>
                    {!_.isEmpty(activeRCDetails) ? (
                      <div className="current-pick-panel">
                        <div className="current-pick-content hotel">
                          <div className="col-xs-9 col-md-10">
                            {/* <a className="toggle-panel" href="#"><span className="vehoicon-arrow_downward" /><span className="sr-only">More info</span></a> */}
                            <span className="single-line-text fade small no-margin">
                              Changing: {activeRCDetails.carTitle}
                              - Type: {activeRCDetails.carType}, Gear:{' '}
                              {activeRCDetails.gearType}
                            </span>
                          </div>
                          <div className="col-xs-3 col-md-2 text-right">
                            {activeRCDetails.totalCost ? (
                              <span className="total-price small bold dim">
                                <span className="WebRupee">Rs.</span>{' '}
                                {activeRCDetails.totalCost}
                              </span>
                            ) : null}
                          </div>
                        </div>
                      </div>
                    ) : null}

                    {!this.state.showContentPlaceHolders ? (
                      <RentalCarOptions
                        splitPricing={this.props.itineraryDetail.splitPricing}
                        filteredRentalCarOptions={filteredRentalCarOptions}
                        activeRCDetails={this.props.activeRCDetails}
                        header_text={
                          filteredRentalCarOptions.length > 0
                            ? filteredRentalCarOptions.length +
                              ' available options to choose from'
                            : 'Sorry, no alternate rental car options available.'
                        }
                        closeModal={this.closeModal}
                        changeRentalCar={this.changeRentalCar}
                      />
                    ) : (
                      <AlternateHotelsActivitiesLoading
                        loaderState={false}
                        title={'Change Car'}
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const RentalCarOptions = props => {
  return (
    <div className="modal-row">
      <span className="mini block dim bold text-center spacer">
        {props.header_text}
      </span>
      <section className="change-data grid-list row">
        {props.filteredRentalCarOptions.map(rentalCar => (
          <RentalCarOption
            {...rentalCar}
            key={rentalCar.carCode}
            changeRentalCar={props.changeRentalCar}
            hidePrice={props.hidePrice}
          />
        ))}
      </section>
    </div>
  );
};

const RentalCarOption = props => {
  return (
    <div className="col-xs-12 col-sm-6 col-md-4">
      <article data-key={props.carCode} className="data-option-item">
        <div className="data-option-item-wrapper">
          <div className="media-shell">
            <figure className="hd">
              <img src={props.image} />
            </figure>
          </div>
          <div className="data-option-details">
            <h6 className="title">{props.carTitle}</h6>
            <div className="col-xs-8 col-md-8 meta">
              <span className="dim">
                {props.carType}, {props.gearType}
              </span>
            </div>
            <div className="col-xs-4 col-md-4 price">
              {props.totalCost ? (
                <span className="block">
                  <span className="WebRupee">Rs.</span>
                  {props.totalCost}
                </span>
              ) : null}
              {props.hidePrice && props.diffDetail ? (
                <PriceDiff diff={props.diffDetail} classNames={'block'} />
              ) : null}
            </div>
            <div className="col-xs-8 col-md-8 rating">
              <div className="dim">
                <span className="vehoicon-seat" />&nbsp;{props.maxSeats} seater
              </div>
            </div>
            <div className="col-xs-4 col-md-4 action">
              <a
                className="btn btn-xs btn-primary select-activity-ga hidden-sm hidden-xs"
                onClick={e => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.nativeEvent.stopImmediatePropagation();
                  props.changeRentalCar(props.carCode);
                }}
              >
                Choose
              </a>
              <a
                className="btn btn-sm btn-primary select-activity-ga visible-xs visible-sm"
                onClick={e => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.nativeEvent.stopImmediatePropagation();
                  props.changeRentalCar(props.carCode);
                }}
              >
                Choose
              </a>
            </div>
          </div>
        </div>
      </article>
    </div>
  );
};

const RentalCarOptionsFilters = props => {
  return (
    <div className="modal-alternate-filters full-hgt">
      <div className="modal-filter-header xs-hdr">
        <div className="header-bar">
          <button
            onClick={props.hideRCFilters}
            type="button"
            className={'close filter-toggle clear-box-shadow visible-xs'}
          >
            <span className="vehoicon-previous" aria-hidden="true" />
          </button>
          {/*<span className="text-uppercase kern-more bolder fade">Filters</span>*/}
        </div>
      </div>
      <div className="filter-content tracker-transfers-filter xs-midcontent">
        <form name="form_filters" id="form_filters" action="#">
          <CarTypeChoices
            carTypeChoices={props.carTypeChoices}
            carTypeFilter={props.filters.carType}
            updateFilter={props.updateFilter}
          />
          <hr className="mute" />
          <GearTypeChoices
            gearTypeChoices={props.gearTypeChoices}
            gearTypeFilter={props.filters.gearType}
            updateFilter={props.updateFilter}
          />
          <hr className="mute" />
          <MaxSeatChoices
            maxSeatsChoices={props.maxSeatsChoices}
            maxSeatsFilter={props.filters.maxSeats}
            updateFilter={props.updateFilter}
          />
          {!props.hidePrice ? <hr className="mute" /> : null}
          {!props.hidePrice ? (
            <PriceFilterSlider
              minPrice={props.minPrice}
              maxPrice={props.maxPrice}
              hidePrice={props.hidePrice}
              selectedMinPrice={props.filters.carCost.minPrice}
              selectedMaxPrice={props.filters.carCost.maxPrice}
              updateFilter={props.updateFilter}
            />
          ) : null}
        </form>
      </div>
      <div className="xs-ftr visible-xs">
        <button
          onClick={props.hideRCFilters}
          type="button"
          className="btn btn-primary filter-update-btn btn-block"
        >
          Update
        </button>
      </div>
    </div>
  );
};

const CarTypeChoices = props => {
  return (
    <div className="filter-grp tracker-transfers-type">
      <h6 className="fade">Type</h6>
      {props.carTypeChoices.length === 1 ? (
        <div className="types-input">
          Only {toProperCase(props.carTypeChoices[0])} available
        </div>
      ) : (
        props.carTypeChoices.map(carType => (
          <div className="clearfix">
            <label className="custom-options">
              <input
                type="checkbox"
                name="carType"
                key={'CarType' + carType}
                value={carType}
                onClick={e => props.updateFilter(e.target.name, e.target.value)}
                checked={carType in props.carTypeFilter}
              />
              <span> {toProperCase(carType)} </span>
              <i />
            </label>
          </div>
        ))
      )}
    </div>
  );
};

const GearTypeChoices = props => {
  return (
    <div className="filter-grp tracker-transfers-gear">
      <h6 className="fade">Gear</h6>
      {props.gearTypeChoices.length === 1 ? (
        <div className="types-input">
          Only {toProperCase(props.gearTypeChoices[0])} available
        </div>
      ) : (
        props.gearTypeChoices.map(gearType => (
          <div className="clearfix">
            <label className="custom-options">
              <input
                type="checkbox"
                name="gearType"
                key={'GearType' + gearType}
                value={gearType}
                onClick={e => props.updateFilter(e.target.name, e.target.value)}
                checked={gearType in props.gearTypeFilter}
              />
              <span> {toProperCase(gearType)} </span>
              <i />
            </label>
          </div>
        ))
      )}
    </div>
  );
};

const MaxSeatChoices = props => {
  return (
    <div className="filter-grp tracker-transfers-maxpass">
      <h6 className="fade">Max passengers</h6>
      {props.maxSeatsChoices.length === 1 ? (
        <div className="types-input">
          Only {toProperCase(props.maxSeatsChoices[0])} seaters available
        </div>
      ) : (
        props.maxSeatsChoices.map(maxSeats => (
          <div className="clearfix">
            <label className="custom-options">
              <input
                type="checkbox"
                name="maxSeats"
                key={'maxSeats' + maxSeats}
                value={maxSeats}
                onClick={e => props.updateFilter(e.target.name, e.target.value)}
                checked={maxSeats.toString() in props.maxSeatsFilter}
              />
              <span> {maxSeats} Seater </span>
              <i />
            </label>
          </div>
        ))
      )}
    </div>
  );
};

const PriceFilterSlider = props => {
  const handlePriceRangeSliderChange = value =>
    props.updateFilter('carCost', value);

  if (!(props.minPrice || props.maxPrice)) return <div>&nbsp;</div>;

  return (
    <div className="filter-grp">
      <h6 className="fade">Price / Day</h6>
      <Range
        min={props.minPrice}
        max={props.maxPrice}
        defaultValue={[props.minPrice || 0, props.maxPrice || 100]}
        range={true}
        allowCross={false}
        name="price"
        onChange={handlePriceRangeSliderChange}
      />
      <div>
        <span className="slider-price">
          <span className="WebRupee">Rs.</span> {props.selectedMinPrice}
        </span>
        <span className="pull-right slider-price">
          <span className="WebRupee">Rs.</span> {props.selectedMaxPrice}
        </span>
      </div>
    </div>
  );
};

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    changeRentalCar: bindActionCreators(changeRentalCar, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  AlternateRentalCars
);
