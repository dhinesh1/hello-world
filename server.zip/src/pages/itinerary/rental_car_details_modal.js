import React, { Component } from 'react';
import { connect } from 'react-redux';

import RentalCarDetails from './components/rental_car_details';

import {
  decodeActivityKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import { itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';
class RCDetailsModal extends Component {
  constructor(props) {
    super(props);

    this.state = { showModal: false, activeRCDetails: {} };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.rentalCarCostings &&
      !Object.keys(this.state.activeRCDetails).length
    ) {
      let currentKey = this.props.match.params.rcKey;
      currentKey = decodeActivityKeyFromURL(currentKey);
      // console.log(currentKey);

      let currentDetail =
        props.itineraryInfo.rentalCarCostings.rentalCostingById[currentKey];

      if (!currentDetail) {
        this.closeModal();
      }

      this.setState({ activeRCDetails: currentDetail });
    }
  }

  closeModal() {
    let { history, itineraryDetail } = this.props;

    // let _this = this;
    // let ele = _this.refs.modal;
    // $(ele).addClass('out');

    setTimeout(() => {
      this.setState({ showModal: false, deleteActivity: false }, () => {
        onceModalClosed();

        history.push(
          itineraryModalsRouteHelper({
            itineraryId: itineraryDetail.itineraryId,
            regionCode: itineraryDetail.regionCode,
            parentPage: routingPageType.inclusion
          })
        );
      });
    }, 400);
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }

  openModal() {
    this.setState({ showModal: true, deleteActivity: false }, () => {
      onceModalOpened();
    });
  }

  render() {
    return (
      <div
        tabIndex="0"
        ref="modal"
        className={
          'modal fade modal-sticky-header alternate-modal hotel-modal ' +
          (this.state.showModal ? 'in' : '')
        }
      >
        <RentalCarDetails
          splitPricing={this.props.itineraryDetail.splitPricing}
          onCloseModal={this.closeModal}
          activeRCDetails={this.state.activeRCDetails}
          itineraryDetail={this.props.itineraryDetail}
          userDetails={this.props.user_details}
          {...this.props}
        />
      </div>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {};
}

export default connect(mapStateToProps, mapDispatchToProps)(RCDetailsModal);
