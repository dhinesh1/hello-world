import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import classNames from 'classnames';
import axios from 'axios';
import _ from 'lodash';
import upperFirst from 'lodash/upperFirst';

import {
  onceModalClosed,
  onceModalOpened,
  is_server,
  isValidMobileNumber as isValidNumber,
  getPackageKeyFromPathname,
  isAlphabetsOnly
} from '../../helpers/utilsHelper';
import { manageSoftNotification } from '../../actions/actions_app';

import Phone from 'react-phone-number-input';
import { parseNumber } from 'libphonenumber-js';

import { AppConfig } from '../../app-config';
import { getLeadSource } from '../../helpers/leadSourceHelper';
import { withLastLocation } from 'react-router-last-location';
import { trackEvent, EVENT_CBR, EVENT_GENERATE_LEAD } from '../../helpers/ML/EventsTracker';
import { itineraryModalsRouteHelper } from '../../helpers/routesHelper';
const API_URL = AppConfig.api_url;

export class RequestCallbackModal2 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      stateValue: '',
      showModal: false,
      name: '',
      mobileNumber: '',
      countryPhoneCode: '+91',
      enableCallback: false,
      validationState: {
        mobileNumberInvalid: false,
        nameInvalid: false
      }
    };
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    
    this.handelOnChange = this.handelOnChange.bind(this);
    this.triggerValidation = this.triggerValidation.bind(this);

    this.autoFillDetails = this.autoFillDetails.bind(this);

    this._successMessage = 'Thanks! We will call you within 48 hours.';
  }

  componentWillReceiveProps(nextProps) {
    this.autoFillDetails(nextProps);
  }

  componentDidMount() {
    this.openModal();
    this.autoFillDetails(this.props);
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  autoFillDetails(props) {
    let local_callBack = JSON.parse(localStorage.getItem('callbackDetails'));
    let user_details =
      props.user_details && props.user_details.loggedIn
        ? props.user_details
        : local_callBack && local_callBack.data;
    if (user_details && user_details.name && !this.state.name.length) {
      this.setState(
        {
          name: upperFirst(user_details.name),
          mobileNumber:
            user_details.countryPhoneCode + user_details.mobileNumber
        },
        () => {
          this.handleEnableCallback();
        }
      );
    }
  }

  openModal() {
    this.setState({
      showModal: true
    },() => {
      onceModalOpened();
    });
  }

  closeModal() {
    let { history, location, itineraryDetail, vacations } = this.props;
    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        onceModalClosed();

        /**
         * There are the places where CBR can be accessed in the product right now.
         * 1. Homepage
         * 2. Itinerary & costing screen
         * 3. Packages / vacations pages
         * 4. SEO itinerary details screen
         *
         * 1 & 3 can be determined by checking the object content in `state.app.packages.content` -
         * this will have the list of itineraries which is being used in homepage / packages listing page
         * In case itinerary screen - if the `campaign` flag is true means this is SEO itinerary screen
         * Other use case is the normal itinerary & costing screen
         */
        if (
          (vacations && vacations.content) ||
          (itineraryDetail && itineraryDetail.itinerary && itineraryDetail.itinerary.campaign)
        ) {
          const pageUrl = `/${getPackageKeyFromPathname(location.pathname)}`;
          // Need to retain the URL query parameters on closing the CBR
          const q = (location.search || "").replace('&autocbr','');

          if(history){
            history.push(pageUrl+q);
          }else{
            window.location.href = pageUrl+q;
          }
        } else {
          if(itineraryDetail && itineraryDetail.itinerary) {
            history.push(
              itineraryModalsRouteHelper({
                itineraryId: itineraryDetail.itinerary.itineraryId,
                regionCode: itineraryDetail.itinerary.regionCode,
                location
              })
            );
          } else {
            history.push('/');
          }
        }
      });
    }, 400);
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  handelOnChange(value) {
    let countryCode = '+';
    value = value ? value : '';

    let numberValid = isValidNumber(value);
    if (numberValid) {
      let parsed = parseNumber(value, { extended: true });

      countryCode += parsed.countryCallingCode;
    }
    this.setState(
      {
        mobileNumber: value,
        countryPhoneCode: countryCode
      },
      () => {
        this.handleEnableCallback();
      }
    );
  }

  triggerValidation() {
    let validationState = this.state.validationState;
    let { name, mobileNumber } = this.state;

    validationState.mobileNumberInvalid = !isValidNumber(mobileNumber);
    validationState.nameInvalid = !name.trim().length;
    
    this.setState({ validationState });

    return _.every(_.valuesIn(validationState), e => !e);
  }

  handleSubmit() {
    const _this = this;

    if (this.triggerValidation()) {
      // console.log('form validated');

      let {
        name,
        mobileNumber,
        countryPhoneCode
      } = this.state;
      let {
        vacations,
        itineraryDetail,
        location,
        history,
        lastLocation
      } = this.props;

      trackEvent(EVENT_GENERATE_LEAD);
      trackEvent(EVENT_CBR, {
        name,
        phone: mobileNumber,
        itinerary_id: itineraryId,
        pageURL: document.location.href
      });

      let strippedPhoneNumber = mobileNumber
        .replace(/\D/g, '')
        .substr(countryPhoneCode.replace('+', '').length);

      let itineraryId = itineraryDetail && itineraryDetail.itinerary.itineraryId;

      const data = {
        name: name,
        mobileNumber: strippedPhoneNumber,
        itineraryId: itineraryId,
        pageUrl: location.pathname,
        countryPhoneCode: countryPhoneCode
      };
      data['campaignId'] = sessionStorage.getItem('campaignId');
      data['leadSource'] = getLeadSource({
        history: history,
        lastLocation: lastLocation,
        itineraryId: itineraryId,
        isCBR: true
      });

      if (vacations && vacations.content) {
        data['regionCode'] = vacations.content.campaignDetails
          ? vacations.content.campaignDetails.regionCode
          : '';
      }

      const url = `${API_URL}itinerary/requestcallbackuser`;
      axios
        .post(url, data)
        .then(response => {
          _this.props.actions.manageSoftNotification({
            show_notification: true,
            message: _this._successMessage,
            show_undo: false
          });

          /* Google analytics event triggering starts */
          if (!is_server() && window.gtag) {
            window.gtag('event', 'request_call_back', {
              event_category: 'engagement',
              event_label: 'method',
              value: '0'
            });
          }

          /** Store the current call-back details */
          localStorage.setItem(
            'callbackDetails',
            JSON.stringify({
              data: data
            })
          );
          /* Google analytics event triggering ends */

          _this.closeModal();
        })
        .catch(error => {});
    } else {
      // console.log('form has error');
    }
  }

  handleInputChange(event) {
    const target = event.target;
    let name = target.name;
    if(target.name === 'name' && target.value.length && !isAlphabetsOnly(target.value)) {
      return false;
    }
    this.setState({ [name]: target.value }, () => {
      this.handleEnableCallback();
    });
  }

  handleEnableCallback() {
    let { name, mobileNumber } = this.state;
    let mobileNumberInvalid = !isValidNumber(mobileNumber);
    let nameInvalid = !name.trim().length;
    this.setState({
      enableCallback: !(mobileNumberInvalid || nameInvalid)
    });
  }

  render() {
    let { validationState } = this.state;
    let enableCallback = this.state.enableCallback;

    return (
      <div
        tabIndex="0"
        className={
          'modal mini-modal fade gettrip-and-callback modal-sticky-header ' +
          (this.state.showModal ? 'in' : '')
        }
      >
        <div className="modal-dialog">
          <div className="modal-content with-header">
            <div className="modal-header">
              <button
                type="button"
                onClick={this.closeModal}
                className="btn-modal-close close"
                aria-label="Close"
              >
                <span className="vehoicon-close" aria-hidden="true" />
              </button>
            </div>

            <div className="modal-body">
              <div className="row row-vertical-center">
                <div className="col-sm-12 double-spacer-top-sm">
                  <h5 className='large-heading bold mt-0 mbottom-large'>Get limited access<br />price privileges?</h5>
                  <form id="request-callback-modal" className="fw">
                    <div
                      className={classNames('form-group', {
                        'has-error': validationState.nameInvalid
                      })}
                    >
                      <div className="clearfix label-link">
                        <label className="control-label">Your name</label>
                      </div>
                      <input
                        type="text"
                        className="form-control"
                        required
                        name="name"
                        onBlur={() => {
                          let { validationState, name } = this.state;
                          validationState.nameInvalid = !name.trim().length;
                          this.setState({ validationState });
                        }}
                        value={this.state.name}
                        onChange={e => this.handleInputChange(e)}
                      />
                    </div>
                    <div
                      className={classNames('form-group', {
                        'has-error': validationState.mobileNumberInvalid
                      })}
                    >
                      <div className="clearfix label-link">
                        <label className="control-label">Mobile number</label>
                      </div>

                      <Phone
                        displayInitialValueAsLocalNumber={false}
                        country={'IN'}
                        value={this.state.mobileNumber}
                        name={`request-callback-mobile-number`}
                        error={
                          this.state.mobileNumber
                            ? isValidNumber(this.state.mobileNumber)
                              ? undefined
                              : 'Invalid phone number'
                            : undefined
                        }
                        onBlur={() => {
                          let { validationState, mobileNumber } = this.state;
                          validationState.mobileNumberInvalid = !isValidNumber(
                            mobileNumber
                          );
                          this.setState({ validationState });
                        }}
                        indicateInvalid
                        saveOnIcons={false}
                        smartCaret={false}
                        onChange={this.handelOnChange}
                      />
                    </div>
                    <div className="form-group">
                      <button
                        className={
                          `btn btn-lg btn-primary btn-block n-tracker-rcb-submit` +
                          (enableCallback ? '' : ' disabled')
                        }
                        disabled={!enableCallback}
                        onClick={this.handleSubmit}
                        type="button"
                      >
                        Keep me informed
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  return {
    itineraryDetail: app.itineraryInfo.itineraryDetails,
    vacations: state.packages,
    user_details: app.user_details
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: {
      manageSoftNotification: bindActionCreators(
        manageSoftNotification,
        dispatch
      )
    }
  };
};

export default withLastLocation(
  connect(mapStateToProps, mapDispatchToProps)(RequestCallbackModal2)
);
