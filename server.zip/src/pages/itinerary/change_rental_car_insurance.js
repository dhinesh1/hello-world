import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import axios from 'axios';

import { AppConfig } from '../../app-config';
import {
  decodeActivityKeyFromURL,
  onceModalOpened
} from '../../helpers/utilsHelper';
import { changeRentalCarInsurance } from '../../actions/actions_app';

const API_URL = AppConfig.api_url;
/*global swal */

class ChangeRentalCarInsuranceModal extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      insuranceChoice: '',
      activeRCDetails: {},
      insuranceOptions: []
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.changeRentalCarInsurance = this.changeRentalCarInsurance.bind(this);
    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.rentalCarCostings &&
      !Object.keys(this.state.activeRCDetails).length
    ) {
      let currentKey = this.props.match.params.rcKey;
      currentKey = decodeActivityKeyFromURL(currentKey);
      let currentDetail =
        props.itineraryInfo.rentalCarCostings.rentalCostingById[currentKey];

      if (!currentDetail) {
        this.props.history.goBack();
      }

      this.setState(
        {
          activeRCDetails: currentDetail,
          insuranceType: currentDetail.insuranceType,
          insuranceCost: currentDetail.insuranceCost
        },
        () => {
          this.getInsuranceOptions(
            props.itineraryInfo.itinerary.itineraryId,
            currentKey
          );
        }
      );
    }
  }

  openModal() {
    this.setState(
      {
        showModal: true
      },
      () => {
        onceModalOpened();
      }
    );
  }

  closeModal() {
    let { history } = this.props;

    // let _this = this;
    // let ele = _this.refs.modal;
    // $(ele).addClass('out');

    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        history.goBack();
      });
    }, 400);
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }

  getInsuranceOptions(itineraryId, rentalCarKey) {
    const url = `${API_URL}itinerary/${itineraryId}/rentalcar/insurance`;

    axios
      .post(url, {
        rentalCarKey: rentalCarKey
      })
      .then(response => {
        this.setState({
          insuranceOptions: response.data.data,
          insuranceChoice: this.props.insuranceType
        });
      })
      .catch(e => {
        swal('Something went wrong. Try again.');
      });
  }

  changeRentalCarInsurance(updateStateOnly = true, choice = null) {
    if (updateStateOnly)
      this.setState({
        insuranceChoice: choice
      });
    else {
      this.props.actions
        .changeRentalCarInsurance({
          rentalCarKey: decodeActivityKeyFromURL(this.props.match.params.rcKey),
          type: this.state.insuranceChoice,
          itineraryId: this.props.itineraryDetail.itineraryId
        })
        .then(() => {
          this.closeModal();
        })
        .catch(() => {
          this.closeModal();
        });
    }
  }

  render() {
    return (
      <div
        tabIndex="0"
        ref="modal"
        className={
          'modal fade modal-sticky-header alternate-modal hotel-modal ' +
          (this.state.showModal ? 'in' : '')
        }
      >
        <div className="modal-dialog">
          <div className={'modal-content with-header'}>
            <div className="modal-header">
              <button
                type="button"
                onClick={this.closeModal}
                className="pull-left close"
                data-dismiss="modal"
              >
                <i className="vehoicon-close" />
              </button>
              <span className="meta-text semi-bold kern-more fade text-uppercase">
                CHANGE CAR INSURANCE
              </span>
              <button
                type="button"
                onClick={() => this.changeRentalCarInsurance(false)}
                className="pull-right btn btn-sm btn-primary change-cta"
              >
                Apply
              </button>
            </div>

            <div className="modal-body">
              <ModalSubHeaderAlert
                totalCost={this.state.insuranceOptions.reduce(
                  (acc, ele) =>
                    (acc =
                      ele.type === this.state.insuranceChoice
                        ? ele.totalCost
                        : acc),
                  0
                )}
              />
              <ModalDetails>
                {this.state.insuranceOptions.map(insuranceOption => (
                  <InsuranceOption
                    key={insuranceOption.type}
                    {...insuranceOption}
                    changeRentalCarInsurance={this.changeRentalCarInsurance}
                    checked={
                      insuranceOption.type === this.state.insuranceChoice
                    }
                  />
                ))}
              </ModalDetails>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const ModalSubHeaderAlert = props => {
  return (
    <div className="current-pick-panel">
      <div className="current-pick-content hotel">
        <div className="col-xs-9 col-md-10">
          <span className="single-line-text fade small no-margin">
            Total insurance cost for Rental Car
          </span>
        </div>
        <div className="col-xs-3 col-md-2 text-right">
          <span className="total-price base bold">
            <span className="WebRupee">Rs.</span> {props.totalCost}
          </span>
        </div>
      </div>
    </div>
  );
};

const ModalDetails = props => {
  return (
    <div className="modal-row">
      <h4 className="dim">Insurance Options</h4>
      <div className="planning vmargin-large">
        <ul className="planning-stage insurance-options list-unstyled clearfix">
          {props.children}
        </ul>
      </div>
    </div>
  );
};

const InsuranceOption = props => {
  return (
    <li>
      <div className="clearfix">
        <div className="form-group">
          <label className="custom-options">
            <input
              type="radio"
              name="insuranceOptions"
              value={props.type}
              checked={props.checked}
              onChange={e => props.changeRentalCarInsurance(true, props.type)}
            />
            <span className="block bold main-para fade">
              {props.insuranceName}
            </span>
            <span className="block fine-text">
              Liability on the traveler is <span className="WebRupee">Rs.</span>{' '}
              {props.liability}
            </span>
            <span className="block fine-text">
              Amount to be paid by the user is{' '}
              <span className="WebRupee">Rs.</span> {props.costPerDay} per day
            </span>
            <i />
          </label>
        </div>
      </div>
    </li>
  );
};

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      changeRentalCarInsurance: bindActionCreators(
        changeRentalCarInsurance,
        dispatch
      )
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(ChangeRentalCarInsuranceModal);
