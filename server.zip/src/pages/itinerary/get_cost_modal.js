import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Button from '../../common_components/basic_components/Button';
import _ from 'lodash';
import axios from 'axios';
import classNames from 'classnames';
import moment from 'moment';
import { withLastLocation } from 'react-router-last-location';
import {
  manageSoftNotification,
  getCost,
  getUserDetails,
  showLoginForm,
  showSignUpForm,
  manageRegionStats
} from '../../actions/actions_app';

import { emailValidation } from '../validations';
import {
  onceModalOpened,
  onceModalClosed,
  isFaqMobile,
  checkIndexOf,
  getRandomValue,
  getPackageKeyFromPathname,
  isValidName,
  isValidMobileNumber as isValidNumber
} from '../../helpers/utilsHelper';
import { itineraryModalsRouteHelper } from '../../helpers/routesHelper';

import { AppConfig } from '../../app-config';
import { triggerSimpleAjax } from '../../helpers/httpHelper';
import { getLeadSource } from '../../helpers/leadSourceHelper';
import DepartureCityCosting from './components/get_cost_components/departure_city_costing';
import CostingSelection from './components/get_cost_components/costing_selection';
import DepartureDateDesk from './components/get_cost_components/departure_date_desktop';
import RenderLeftSidePanel from './components/get_cost_components/costing_leftside_panel';
import RenderSignUpComponent from './components/get_cost_components/costing_signup_panel';
import RenderMobileContent from './components/get_cost_components/costing_mobile_panel';
import { RenderFirstFooter } from './components/get_cost_components/costing_mobile_panel';
import { RenderDesktopFooterComponent } from './components/get_cost_components/costing_footer_desktop';
import {
  trackEvent,
  EVENT_ITINERARY_COSTING_SUBMITTED
} from '../../helpers/ML/EventsTracker';

const API_URL = AppConfig.api_url;

class GetCostModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeTab: 'departure_tab',
      tabIndex: 0,
      active_panel: 'departureAirport',
      activeBlock: '',
      showModal: false,
      isLoading: false,
      isTravelDetailsFilled: false,
      isRoomConfigValid: false,
      enableGetCost: false,
      enableMobileGetCost: false,
      mobile_number_empty: false,
      userNameValid: true,
      emailValid: true,
      emailAlreadyExistsError: '',
      itinerary_name: '',
      itinerary_name_placeholder: '',
      isKilled: true,
      regionStatus: {
        flights: '0K',
        activities: '0K',
        hotels: '0K',
        transfers: '0K',
        regionName: '',
        image: ''
      },
      airportFailed: false,
      departureDateFailed: false,
      tripStageFailed: true,
      passengerConfigFailed: false,

      calenderOpened: false,
      showDateExpiredAlert: false,

      user_name: '',
      user_email: '',
      mobile_number: '',
      countryCode: '+91',
      costingConfiguration: {
        passengerConfig: 2,
        bookingPlan_Text: 'YES',
        departureCity: '',
        departureAirport: '',
        departureAirport_Text: '',
        departureDate: '',
        hotelGuestRoomConfigurations: [{ adultCount: 2, childAges: [] }],
        packageRate: false
      },
      costingConfigFilledFromItinerary: false,

      loading: false,
      allSuggestions: [],
      mobileAction: 'STEP1',
      flightsBookedByUserAlready: false
    };
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);

    this.getDepartureAirportName = this.getDepartureAirportName.bind(this);
    this.updateCostingConfiguraion = this.updateCostingConfiguraion.bind(this);
    this.triggerGetCost = this.triggerGetCost.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.getCostingConfiguration = this.getCostingConfiguration.bind(this);
    this.onChangeInput = this.onChangeInput.bind(this);
    this.handleGetCostClick = this.handleGetCostClick.bind(this);
    this.handleHaveAccountLoginClick = this.handleHaveAccountLoginClick.bind(
      this
    );
    this.handleOnMobileNumberChange = this.handleOnMobileNumberChange.bind(
      this
    );

    this.checkAndUpdateCostingConfig = this.checkAndUpdateCostingConfig.bind(
      this
    );
    this.checkValidationAndEnableGetCost = this.checkValidationAndEnableGetCost.bind(
      this
    );

    /**<-------------Internal Component Instance------------------> */
    this.setMobileActions = this.setMobileActions.bind(this);
    this.renderMobileHeaderText = this.renderMobileHeaderText.bind(this);
    this.showSignUp = this.showSignUp.bind(this);
    this.costingMobileReference = React.createRef();
  }

  componentDidMount() {
    this.openModal();
    this.callStats();
    this.checkAndUpdateCostingConfig(this.props);
    document.addEventListener('keyup', this.handleKeyUp);
    const { itineraryInfo={} } = this.props
    const { itinerary={} } = itineraryInfo;
    let flightsBookedByUserAlready = itinerary && itinerary.flightsBookedByUserAlready;
    this.setState({flightsBookedByUserAlready})
    if (this.props.makeReadOnly) {
      this.setState({ mobileAction: 'STEP3' });
    }
  }

  componentWillReceiveProps(props) {
    if (props.regionStatus) {
      this.setState({
        regionStatus: props.regionStatus
      });
    }
    this.checkAndUpdateCostingConfig(props);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  getFinalCosting = (costingConfiguration) => {
    // if(this.props.makeReadOnly){
    //   costingConfiguration.passengerConfig = 2;
    //   costingConfiguration.hotelGuestRoomConfigurations = [{adultCount: 2, childAges: []}];
    // }
    return costingConfiguration;
  }

  /**
   * Used to call the indianCities and regionStats API
   */
  callStats = () => {
    let _this = this;

    let url = `${API_URL}location/indianCities`;
    let itineraryDetail = this.props.itineraryDetail;
    let seoItinerary = this.props.seoItinerary || [];
    /**
     * This condition is applicable only for packages and vacation page
     * Used to SEO Itineraries to get the region code
     */
    if (!Object.keys(itineraryDetail).length && seoItinerary.length) {
      let currentItineraryId = this.props.match.params.itineraryId;
      itineraryDetail = seoItinerary.filter(itinerary => {
        return itinerary.campaignItineraryId === currentItineraryId;
      })[0];
    }
    let regionCode = itineraryDetail.regionCode;
    let regionName = itineraryDetail.regionName;
    // This condtion used to set the region code in SEM page
    if (this.props.location.pathname.split('/')[1] === 'holidays') {
      regionCode = 'aus';
      regionName = 'Australia';
    }
    axios
      .get(url, {
        headers: { 'Content-Type': 'application/json' },
        data: { a: 'b' }
      })
      .then(response => {
        _this.setState({ loading: true, allSuggestions: response.data.data });
      })
      .catch(e => {
        // console.log(e);
      });
    /** this is worked for fetch only */
    let gcmBannerURL =
      'https://s3.ap-south-1.amazonaws.com/oceanjar-new/ui/json_static/gcm.json';
    fetch(gcmBannerURL)
      .then(response => response.json())
      .then(resData => {
        let images = resData.data.images;
        let value = getRandomValue(0, images.length - 1);
        this.setState({
          costImages: images,
          costImage: images[value]
        });
        this.props.actions.manageRegionStats(
          regionCode,
          regionName,
          images[value]
        );
      });
  };

  setMobileActions(value = 'STEP1') {
    this.setState({
      mobileAction: value
    });
  }

  IsUpdateCostFlow = () => {
    const { itineraryDetail, match } = this.props;
    if (
      itineraryDetail.costed &&
      match.params.itineraryId === itineraryDetail.itineraryId
    ) {
      return true;
    }
    return false;
  };

  checkAndUpdateCostingConfig(props) {
    let costingConfigFilledFromItinerary = false;
    let { itineraryDetail, makeReadOnly } = props;
    let userDetails = JSON.parse(localStorage.getItem('costingDetails'));
    let callbackDetails = JSON.parse(localStorage.getItem('callbackDetails'));
    let userCostDetails = JSON.parse(
      localStorage.getItem('userLastCostDetails')
    );
    let isFromLogin = checkIndexOf((props.lastLocation || {}).pathname || '', [
      'login',
      'signup'
    ]);
    if (isFromLogin && userCostDetails) {
      userDetails = userCostDetails;
    }
    if (
      callbackDetails &&
      callbackDetails.data &&
      this.props.user_details &&
      !this.props.user_details.loggedIn
    ) {
      this.setState({
        user_name: callbackDetails.data.name,
        user_email: callbackDetails.data.email,
        mobile_number: callbackDetails.data.mobileNumber,
        countryCode: callbackDetails.data.countryPhoneCode
      });
    }
    let costingConfiguration;
    let isCurrentUser =
      userDetails &&
      props.user_details &&
      userDetails.email === props.user_details.email;

    if (
      !this.state.costingConfigFilledFromItinerary &&
      ((props.itineraryInfo && props.itineraryInfo.costingConfiguration) ||
        (isCurrentUser && (!itineraryDetail.preferredMonth || isFromLogin)))
    ) {
      costingConfiguration =
        isCurrentUser && !makeReadOnly && (!props.itineraryDetail ||
          (props.itineraryDetail && !props.itineraryDetail.costed))
          ? userDetails.costingConfiguration
          : props.itineraryInfo.costingConfiguration && JSON.parse(
              JSON.stringify(props.itineraryInfo.costingConfiguration)
            );

      if (costingConfiguration) {
        costingConfigFilledFromItinerary = true;
        costingConfiguration.departureAirport_Text = this.getDepartureAirportName(
          costingConfiguration.departureAirport
        );

        if (
          moment(
            costingConfiguration.departureDate,
            'DD/MMM/YYYY'
          ).isSameOrBefore(moment())
        ) {
          costingConfiguration.departureDate = moment().format('DD/MMM/YYYY');
          let costElement;
          this.setState(
            { showDateExpiredAlert: true, departureDateFailed: true },
            () => {
              setTimeout(() => {
                costElement = document.getElementById(
                  'departure-date-get-cost'
                );
                if (costElement) {
                  costElement.focus();
                }
              }, 50);
            }
          );
        }
        this.updateCostingConfiguraion(
          costingConfiguration,
          true,
          isFromLogin ? 'STEP4' : null
        );
      }
    } else {
      if (
        !itineraryDetail.costed &&
        !itineraryDetail.staleCost &&
        itineraryDetail.preferredMonth &&
        !isFromLogin &&
        !makeReadOnly
      ) {
        // Booking date
        let selectedMonthNumber = moment()
          .month(itineraryDetail.preferredMonth)
          .format('M');

        let selectedDateBasedOnMonth = moment();
        let selectedDateBasedOnMonthThisYear = moment(
          `${moment().year()}-${selectedMonthNumber}-28`,
          'YYYY-MM-DD'
        );
        let selectedDateBasedOnMonthNextYear = moment(
          `${moment().year() + 1}-${selectedMonthNumber}-28`,
          'YYYY-MM-DD'
        );

        if (
          selectedDateBasedOnMonthNextYear.diff(
            selectedDateBasedOnMonth,
            'months'
          ) > 9
        ) {
          selectedDateBasedOnMonth = selectedDateBasedOnMonthThisYear;
        } else {
          selectedDateBasedOnMonth = selectedDateBasedOnMonthNextYear;
        }

        if (selectedDateBasedOnMonth.isAfter(moment())) {
          // Date pre-select
          costingConfiguration = isCurrentUser
            ? userDetails.costingConfiguration
            : this.state.costingConfiguration;
          costingConfiguration[
            'departureDate'
          ] = selectedDateBasedOnMonth.format('DD/MMM/YYYY');

          this.setState({ costingConfiguration: this.getFinalCosting(costingConfiguration) }, () => {
            if (!this.state.enableGetCost) {
              let { departureAirport, departureDate } = costingConfiguration;
              this.setState({
                enableGetCost:
                  !this.IsUpdateCostFlow() &&
                  departureAirport &&
                  departureDate &&
                  this.props.user_details &&
                  this.props.user_details.loggedIn
              });
            }
          });
        }
      }
    }
    this.setState({
      isRoomConfigValid: itineraryDetail.costed,
      costingConfigFilledFromItinerary,
      itinerary_name: itineraryDetail.title ? itineraryDetail.title : ''
    });

    if (!this.state.enableGetCost) {
      let { departureAirport, departureDate } = this.state.costingConfiguration;
      this.setState({
        enableGetCost:
          !this.IsUpdateCostFlow() &&
          departureAirport &&
          departureDate &&
          ((this.props.user_details && this.props.user_details.loggedIn) ||
            this.validateGetCostSignupForm())
      });
    }
  }

  openModal() {
    this.setState({ isKilled: false }, () => {
      setTimeout(() => {
        this.setState({ showModal: true, isTravelDetailsFilled: false }, () => {
          onceModalOpened();
        });
      }, 200);
    });
  }

  closeModal() {
    const { history, location, itineraryDetail, campaignItineraryId } = this.props;
    const { itineraryId, regionCode } = itineraryDetail;

    this.setState({ showModal: false }, () => {
      setTimeout(() => {
        this.setState({ isKilled: true });
       if(campaignItineraryId || (campaignItineraryId && campaignItineraryId.length) || itineraryDetail.campaign) {
          const loc = getPackageKeyFromPathname(history.location.pathname);
          history.push("/"+loc);
        } else if(itineraryId && regionCode){
          const loc = itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            location
          });

          history.push(loc);
        } else{
          history.goBack();
        }

        onceModalClosed();
      }, 300);
    });
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  getDepartureAirportName(value) {
    let matchingOption = _.find(this.state.allSuggestions, function(o) {
      return o.airportCode === value;
    });

    return matchingOption ? matchingOption.cityName : '';
  }

  updateCostingConfiguraion(newState, on_init = false, mobileAction) {
    let { costingConfiguration } = this.state;
    let { user_details, itineraryDetail, itineraryInfo, match } = this.props;

    let ex_states = { ...costingConfiguration };
    _.assign(ex_states, newState);

    let enableGetCost = this.validateGetCostForm();
    let enableMobileGetCost = enableGetCost;

    if (ex_states.passengerConfig === '') enableGetCost = false;

    if (user_details && !user_details.loggedIn) {
      // check sign-up form field
      enableGetCost = this.validateGetCostSignupForm() && enableGetCost;
    }

    if (enableGetCost && this.IsUpdateCostFlow()) {
      if (on_init) {
        enableGetCost = false;
      } else {
        if (itineraryInfo) {
          let configObj = _.omit(ex_states, [
            'bookingPlan_Text',
            'departureAirport_Text'
          ]);
          enableGetCost = !_.isEqual(
            configObj,
            itineraryInfo.costingConfiguration
          );
        }
      }
    }

    if (this.props.makeReadOnly) {
      ex_states.departureAirport = '$$$';
      ex_states.departureAirport_Text = 'Outside...';
    }
    this.setState(
      {
        costingConfiguration: this.getFinalCosting(ex_states),
        enableMobileGetCost: enableMobileGetCost,
        enableGetCost: enableGetCost,
        passengerConfigChangeUpdated: false
      },
      () => {
        let { costingConfiguration, passengerConfigChangeUpdated } = this.state;
        let ex_states = costingConfiguration;

        // passenger config change
        if (!on_init && !passengerConfigChangeUpdated) {
          let enableGetCost = this.state.enableGetCost;
          if (itineraryDetail.costed) {
            enableGetCost = !_.isEqual(
              ex_states,
              itineraryInfo.costingConfiguration
            );
          }

          if (this.props.makeReadOnly) {
            ex_states.departureAirport = '$$$';
            ex_states.departureAirport_Text = 'Outside...';
          }

          this.setState({
            enableGetCost,
            costingConfiguration: this.getFinalCosting(ex_states),
            passengerConfigChangeUpdated: true
          });
        }

        let enableMobileGetCost = this.validateGetCostForm();
        this.setState({ enableMobileGetCost });

        if (
          !itineraryDetail.costed ||
          (itineraryDetail.costed && this.state.showDateExpiredAlert)
        ) {
          let enableGetCost = enableMobileGetCost;
          if (ex_states.passengerConfig === '') enableGetCost = false;

          if (user_details && !user_details.loggedIn) {
            // check sign-up form field
            enableGetCost = this.validateGetCostSignupForm() && enableGetCost;
          }

          this.setState({ enableGetCost });
        }
        if (mobileAction) {
          this.setState({
            mobileAction: mobileAction
          });
        }
      }
    );
  }

  checkValidationAndEnableGetCost() {
    let { costingConfiguration } = this.state;
    let { user_details, itineraryDetail } = this.props;

    if (user_details && user_details.loggedIn) {
      let enableGetCost = this.validateGetCostForm();

      if (enableGetCost) {
        enableGetCost = !(
          (itineraryDetail.title &&
            this.state.itinerary_name === itineraryDetail.title) ||
          (!itineraryDetail.title && !this.state.itinerary_name.length)
        );
      }

      this.setState({ enableGetCost });
    } else {
      let enableGetCost = this.validateGetCostSignupForm();

      if (enableGetCost) {
        enableGetCost = this.validateGetCostForm();

        if (costingConfiguration.passengerConfig === '') enableGetCost = false;
      }

      this.setState({ enableGetCost });
    }
  }

  onChangeInput(opt) {
    this.setState({ ...opt }, () => {
      this.checkValidationAndEnableGetCost();
    });
  }

  validateGetCostForm(updateState = false) {
    let { costingConfiguration } = this.state;
    let ex_states = costingConfiguration;

    let new_airportFailed = ex_states.departureAirport === '';

    let new_departureDateFailed =
      ex_states.departureDate === null ||
      ex_states.departureDate === '' ||
      moment(ex_states.departureDate, 'DD/MMM/YYYY').isSameOrBefore(moment());
    let new_passengerConfigFailed = ex_states.passengerConfig === '';

    let enableGetCost = !new_airportFailed && !new_departureDateFailed;
    if (updateState) {
      enableGetCost = enableGetCost && !new_passengerConfigFailed;
    }

    if (updateState || this.state.showDateExpiredAlert) {
      this.setState({
        airportFailed: new_airportFailed,
        departureDateFailed: new_departureDateFailed,
        passengerConfigFailed: new_passengerConfigFailed
      });
    }

    return enableGetCost;
  }

  validateGetCostSignupForm() {
    let { user_name='', user_email='', mobile_number='', countryCode } = this.state;
    let enableGetCost = false;

    let isEmailValid = user_email.trim() !== '' && emailValidation(user_email);
    let isUserNameValid = user_name.trim() !== '' && isValidName(user_name);
    // check sign-up form field
    if (
      isUserNameValid &&
      isEmailValid &&
      isValidNumber(countryCode + mobile_number)
    ) {
      enableGetCost = true;
    }

    return enableGetCost;
  }

  getCostingConfiguration() {
    let { user_details } = this.props;
    let costingConfiguration = this.state.costingConfiguration;
    let configObj = _.omit(costingConfiguration, [
      'bookingPlan_Text',
      'departureAirport_Text'
    ]);

    if (
      user_details &&
      user_details.loggedIn &&
      user_details.userType === 'ADMIN' &&
      configObj.tripStage === '2'
    ) {
      configObj.tripStage = '4'; // Booking this month
    }

    return configObj;
  }

  handleFlightsBookedByUserAlready = () => {
    const { flightsBookedByUserAlready } = this.state;
    this.setState({ flightsBookedByUserAlready: !flightsBookedByUserAlready });
  }

  triggerGetCost() {
    const { itineraryDetail, history } = this.props;
    const { itinerary_name, flightsBookedByUserAlready } = this.state;

    const configObj = this.getCostingConfiguration();

    const itineraryId = this.props.itineraryDetail.itineraryId
      ? this.props.itineraryDetail.itineraryId
      : this.props.match.params.itineraryId;
    const regionCode = this.props.itineraryDetail.regionCode
      ? this.props.itineraryDetail.regionCode
      : this.props.match.params.searchRegion;
    const req_data = {
      itineraryId: itineraryId,
      costingType: 'RECOST',
      costingConfig: configObj,
      name: itinerary_name,
      flightsBookedByUserAlready: flightsBookedByUserAlready
    };

    const isItineraryPage = checkIndexOf(
      history.location.pathname,
      ['/view/', '/inclusions/']
    );

    if (!isItineraryPage) {
      let itineraryId =
        itineraryDetail.campaign && this.props.campaignItineraryId
          ? this.props.campaignItineraryId
          : this.props.match.params.itineraryId;
      let url = `${API_URL}itinerary/campaign/${itineraryId}/assignUser`;

      triggerSimpleAjax(
        url,
        'POST',
        {},
        response => {
          if (response.status === 'SUCCESS') {
            itineraryId = response.data;

            this.props.actions.getCost({
              itineraryId,
              regionCode,
              req_data : {
                itineraryId: itineraryId,
                costingType: 'RECOST',
                costingConfig: configObj,
                name: itinerary_name,
                flightsBookedByUserAlready: flightsBookedByUserAlready
              },
              history: this.props.history,
              lastLocation: this.props.lastLocation,
              campaign: true
            });
          } else {
            // this.props.actions.manageSoftNotification({
            //   show_notification: true,
            //   message: 'Something went wrong! please try again',
            //   show_undo: false
            // });
          }
        },
        error => {
          // console.log('Got error: ', error);
        }
      );
    } else {
      this.props.actions.getCost({
        itineraryId,
        regionCode,
        req_data,
        history: this.props.history,
        lastLocation: this.props.lastLocation
      });
    }
    localStorage.setItem(
      'costingDetails',
      JSON.stringify({
        costingConfiguration: configObj,
        email: (this.props.user_details || {}).email
      })
    );
  }

  handleGetCostClick(e) {
    e && e.preventDefault();
    let _this = this;
    let _state = this.state;
    let tripStage =
      _state.costingConfiguration.bookingPlan_Text === 'YES' ? 1 : 2; // Its dummy data

    let isFormValid = true;
    let { user_details, history, match, lastLocation, itineraryDetail, seoItinerary, hotelDetails } = this.props;
    const itineraryId = match.params.itineraryId;

    if (user_details && user_details.loggedIn) {
      const {
        departureAirport,
        departureDate,
        hotelGuestRoomConfigurations
      } = this.state.costingConfiguration;
      trackEvent(EVENT_ITINERARY_COSTING_SUBMITTED, {
        already_loggedin: true,
        departure_city: departureAirport,
        fromURL: document.referrer,
        departure_date: new Date(departureDate),
        room_count: hotelGuestRoomConfigurations.length,
        adult_count: _.sumBy(hotelGuestRoomConfigurations, 'adultCount') || 0,
        child_count: _.sumBy(hotelGuestRoomConfigurations, ch => (ch.childAges && ch.childAges.length)) || 0
      });

      this.triggerGetCost();
    } else {
      isFormValid = this.validateGetCostSignupForm();
      let mobileNumber = _state.mobile_number;

      if (!isFormValid) return false;
      else {
        this.setState({ isLoading: true });
        let url = `${API_URL}user/signup/verifyotp`;

        let post_data = {
          mobileNumber: mobileNumber,
          id: '', //  id from (http://localhost:8080/veho/user/signup - response)
          otp: '', //  user entered OTP
          userName: _state.user_name,
          email: _state.user_email,
          countryPhoneCode: _state.countryCode,
          tripStage: tripStage,
          shouldContact: true,
          cpid: sessionStorage.getItem('campaignId'),
          leadSource: getLeadSource({
            history: history,
            lastLocation: lastLocation,
            itineraryId: itineraryId
          })
        };

        axios
          .post(url, post_data)
          .then(response => {
            if (response.data) {
              if (response.data.status === 'INVALID_EMAIL') {
                let configObj = this.getCostingConfiguration();

                let req_data = {
                  itineraryId: itineraryId,
                  costingType: 'RECOST',
                  costingConfig: configObj,
                  name: this.state.itinerary_name
                };

                // Check if itineraryDetail is there then read the regionCode from there otherwise read it from URL params
                // Even if its not there in URL we will use 'region' as the fallback fro now.
                const regionCode = (!_.isEmpty(itineraryDetail) ? itineraryDetail.regionCode : match.params.searchRegion) || 'region';

                this.props.actions.showLoginForm({
                  requestPayload: req_data, 
                  history, 
                  preState: {
                    mobile_number: _state.countryCode + _state.mobile_number,
                    user_email: response.data.data
                  },
                  regionCode: regionCode,
                  campaign: ((hotelDetails && hotelDetails.content) || (seoItinerary && seoItinerary.length > 0) || itineraryDetail.campaign)
                });

                const {
                  departureAirport,
                  departureDate,
                  hotelGuestRoomConfigurations
                } = configObj;

                trackEvent(EVENT_ITINERARY_COSTING_SUBMITTED, {
                  already_loggedin: false,
                  departure_city: departureAirport,
                  fromURL: document.referrer,
                  departure_date: new Date(departureDate),
                  room_count: hotelGuestRoomConfigurations.length,
                  adult_count: _.sumBy(hotelGuestRoomConfigurations, 'adultCount') || 0,
                  child_count: _.sumBy(hotelGuestRoomConfigurations, ch => (ch.childAges && ch.childAges.length)) || 0
                });
              } else {
                window.sessionStorage.setItem('USER_HASH_DATA', response.data.data);
                _this.setState({ isLoading: false }, () => {
                  _this.props.actions.getUserDetails();

                  const {
                    departureAirport,
                    departureDate,
                    hotelGuestRoomConfigurations = {}
                  } = this.getCostingConfiguration();

                  trackEvent(EVENT_ITINERARY_COSTING_SUBMITTED, {
                    new_user: true,
                    departure_city: departureAirport,
                    fromURL: document.referrer,
                    departure_date: new Date(departureDate),
                    room_count: hotelGuestRoomConfigurations.length,
                    adult_count: _.sumBy(hotelGuestRoomConfigurations, 'adultCount') || 0,
                    child_count: _.sumBy(hotelGuestRoomConfigurations, ch => (ch.childAges && ch.childAges.length)) || 0
                  });

                  _this.triggerGetCost();
                });
              }
            }
          })
          .catch(error => {
            if (error.response && error.response.status === 409) {
              // setCookie('firstTimeUser', false);
              // console.log(error.response);
              _this.setState({
                isLoading: false,
                emailValid: false,
                emailAlreadyExistsError:
                  'This email ID already exists. Try using a different one'
              });

              let configObj = this.getCostingConfiguration();

              let req_data = {
                itineraryId: itineraryId,
                costingType: 'RECOST',
                costingConfig: configObj,
                name: this.state.itinerary_name
              };
              if (error.response.data !== 'Email id already exists') {
                // Check if itineraryDetail is there then read the regionCode from there otherwise read it from URL params
                // Even if its not there in URL we will use 'region' as the fallback fro now.
                const regionCode = (!_.isEmpty(itineraryDetail) ? itineraryDetail.regionCode : match.params.searchRegion) || 'region';

                this.props.actions.showLoginForm({
                  requestPayload: req_data, 
                  history, 
                  preState: {
                   mobile_number: _state.countryCode + _state.mobile_number
                  },
                  regionCode: regionCode,
                  campaign: ((hotelDetails && hotelDetails.content) || (seoItinerary && seoItinerary.length > 0) || itineraryDetail.campaign)
                });
              }
            } else if (error.response && error.response.status === 400) {
              _this.setState({
                isLoading: false,
                mobile_number_empty: true
              });
            }
          });
      }
    }
  }

  handleHaveAccountLoginClick(e) {
    e.preventDefault();
    let { history, match, itineraryDetail, seoItinerary, hotelDetails } = this.props;

    if (this.validateGetCostForm(true)) {
      let configObj = this.getCostingConfiguration();
      localStorage.setItem(
        'userLastCostDetails',
        JSON.stringify({
          costingConfiguration: configObj
        })
      );
      let itineraryId = match.params.itineraryId;

      // Check if itineraryDetail is there then read the regionCode from there otherwise read it from URL params
      // Even if its not there in URL we will use 'region' as the fallback fro now.
      const regionCode = (!_.isEmpty(itineraryDetail) ? itineraryDetail.regionCode : match.params.searchRegion) || 'region';
      
      let req_data = {
        itineraryId: itineraryId,
        costingType: 'RECOST',
        costingConfig: configObj,
        name: this.state.itinerary_name
      };

      this.props.actions.showLoginForm({
        requestPayload: req_data, 
        history,
        regionCode: regionCode,
        campaign: ((hotelDetails && hotelDetails.content) || (seoItinerary && seoItinerary.length > 0) || itineraryDetail.campaign)
      });
    } else {
      return false;
    }
  }

  showSignUp() {
    const { history, actions, match, itineraryDetail, hotelDetails, seoItinerary } = this.props;

    const configObj = this.getCostingConfiguration();
    let {itineraryId, regionCode} = itineraryDetail; // Reading the itineraryI & regionCode from itineraryDetails object

    /**
     * To check is this any campaign itinerary scenario - based on the below criterias
     * hotelDetails.content is to check if its from PDG IH flow
     * seoItinerary.lenght is to check packages/vacations pages
     * In case of campaign details SEO page - itineraryDetail.campaign will be set as true
     */
    const campaign = (
      (hotelDetails && hotelDetails.content) || 
      (seoItinerary && seoItinerary.length > 0) || 
      itineraryDetail.campaign);

    /**
     * If its a campaign itinerary then we won't be having itineraryDetails objects with the required information
     * So we are reading the same from URL params
     */
    if(campaign){
      itineraryId = match.params.itineraryId;
      regionCode = match.params.searchRegion;
    }

    const req_data = {
      itineraryId: itineraryId,
      costingType: 'RECOST',
      costingConfig: configObj,
      name: this.state.itinerary_name
    };

    actions.showSignUpForm({req_data, regionCode, history, campaign});
  }

  handleOnUserNameChanged = opt => {
    this.setState({ ...opt }, () => {
      let { user_name } = this.state;
      let enableGetCost = this.validateGetCostSignupForm();
      this.setState({
        userNameValid: user_name.trim() !== '' && isValidName(user_name),
        enableGetCost: enableGetCost
      });
    });
  };

  handleOnEmailChanged = opt => {
    this.setState({ ...opt }, () => {
      let { user_email } = this.state;
      let enableGetCost = this.validateGetCostSignupForm();
      this.setState({
        emailValid: user_email.trim() !== '' && emailValidation(user_email),
        enableGetCost: enableGetCost
      });
    });
  };

  handleOnMobileNumberChange(no, countryCode, value) {
    let numberValid = isValidNumber(countryCode + value);
    this.setState(
      {
        mobile_number: value,
        mobile_number_invalid: !numberValid,
        countryCode: countryCode
      },
      () => {
        let enableGetCost = this.validateGetCostSignupForm();
        if (enableGetCost) {
          enableGetCost = this.validateGetCostForm();
        }

        this.setState({ enableGetCost: enableGetCost });
      }
    );
  }

  popupOpened = value => {
    if (this.state.popupShown !== value) {
      this.setState({
        popupShown: value
      });
    }
    if (!isFaqMobile()) {
      const body = document.getElementsByTagName('body')[0];
      body.classList[value ? 'remove' : 'add']('scroll-locked');
      if (!body.classList.contains('modal-open')) {
        body.classList.add('modal-open');
      }
    }
  };

  renderMobileHeaderText() {
    const makeReadOnly = this.props.makeReadOnly;
    let config = this.state.costingConfiguration;
    let room = config.hotelGuestRoomConfigurations;
    let airport = config.departureAirport;
    let month = moment(config.departureDate, 'DD/MMM/YYYY').format('MM');
    let date = moment(config.departureDate, 'DD/MMM/YYYY').format('DD');
    let dateEnable =
      month && date && month !== 'Invalid date' && date !== 'Invalid date';
    let adultCount = 0;
    room.map(cost => {
      adultCount += cost.adultCount;
    });
    switch (this.state.mobileAction) {
      case 'STEP1':
      case 'STEP2':
        return (
          <p>
            <i /> Cost &amp; save this itinerary
          </p>
        );
      case 'STEP3':
      case 'STEP4':
        return (
          <p>
            Departing
            <a
              className={`${makeReadOnly ? 'hide' : ''}`}
              onClick={e => {
                e && e.preventDefault();
                if (makeReadOnly) {
                  return;
                }
                if (this.state.mobileAction === 'STEP4') {
                  let reference = this.costingMobileReference;
                  reference.current.costingHandler(e, 'DONE');
                  setTimeout(() => {
                    if (!reference.current.state.isError) {
                      this.setState({
                        mobileAction: airport === '$$$' ? 'STEP2' : 'STEP1'
                      });
                    }
                  }, 100);
                } else {
                  this.setState({
                    mobileAction: airport === '$$$' ? 'STEP2' : 'STEP1'
                  });
                }
              }}
              href=""
            >
              {airport === '$$$' ? ' Outside... ' : ' ' + airport + ' '}
            </a>
            {dateEnable ? ' on ' : ''}
            {dateEnable ? (
              <a
                onClick={e => {
                  e && e.preventDefault();
                  if (this.state.mobileAction === 'STEP4') {
                    let reference = this.costingMobileReference;
                    reference.current.costingHandler(e, 'DONE');
                    setTimeout(() => {
                      if (!reference.current.state.isError) {
                        this.setState({ mobileAction: 'STEP3' });
                      }
                    }, 100);
                  } else {
                    this.setState({ mobileAction: 'STEP3' });
                  }
                }}
                href=""
              >
                {month + '/' + date + ' '}
              </a>
            ) : null}
            {dateEnable && adultCount ? 'with ' : ''}
            {dateEnable && adultCount ? (
              <a
                onClick={e => {
                  e && e.preventDefault();
                  if (this.state.mobileAction === 'STEP4') {
                    let reference = this.costingMobileReference;
                    reference.current.costingHandler(e, 'DONE');
                    setTimeout(() => {
                      if (!reference.current.state.isError) {
                        this.setState({ mobileAction: 'STEP4' });
                      }
                    }, 100);
                  } else {
                    this.setState({ mobileAction: 'STEP4' });
                  }
                }}
                href=""
              >
                {adultCount} adu
              </a>
            ) : (
              ''
            )}
            ...
          </p>
        );
    }
  }

  render() {
    let {
      user_name,
      user_email,
      mobile_number,
      mobileAction,
      isKilled,
      showModal,
      popupShown
    } = this.state;
    if (isKilled && !this.props.isTestKilled) {
      return null;
    }
    const makeReadOnly = this.props.makeReadOnly;
    let props = {
      closeModal: this.closeModal,
      onChangeInput: this.onChangeInput,
      costingHandler: this.updateCostingConfiguraion,
      handleOnMobileNumberChange: this.handleOnMobileNumberChange,
      setMobileActions: this.setMobileActions,
      handleHaveAccountLoginClick: this.handleHaveAccountLoginClick,
      email: user_email,
      userName: user_name,
      popupOpened: this.popupOpened,
      mobileNumber: mobile_number,
      handleGetCostClick: this.handleGetCostClick,
      triggerGetCost: this.triggerGetCost,
      showSignUp: this.showSignUp,
      costingMobileReference: this.costingMobileReference,
      handleOnEmailChanged: this.handleOnEmailChanged,
      handleOnUserNameChanged: this.handleOnUserNameChanged,
      IsUpdateCostFlow: this.IsUpdateCostFlow,
      ...this.state,
      ...this.props,
      makeReadOnly,
      handleFlightsBookedByUserAlready: this.handleFlightsBookedByUserAlready
    };
    return (
      <div
        className={classNames(
          'modal fade modal-sticky-header primary-popups costing-popup',
          {
            in: showModal,
            'show-depart-footer': !isFaqMobile() || mobileAction === 'STEP1',
            'show-footer': isFaqMobile && mobileAction === 'STEP4',
            'dropdown-opened': popupShown
          }
        )}
        tabIndex={-1}
      >
        <div className="modal-dialog">
          <div className="modal-content with-header">
            <div className="modal-header">
              {this.renderMobileHeaderText()}
              <Button
                buttonClass="close"
                clickAction={this.closeModal}
                dataDismiss="modal"
              >
                <i className="vehoicon-close" />
              </Button>
            </div>
            <div className="modal-body">
              <div className="inner-content">
                <RenderLeftSidePanel regionStatus={this.state.regionStatus} />
                <RenderRightSidePanel {...props} />
              </div>
            </div>

            {isFaqMobile() && props.mobileAction === 'STEP1' ? (
              <RenderFirstFooter {...props} />
            ) : null}
          </div>
        </div>
      </div>
    );
  }
}

/**********--Functional Components Starts Here--**********/

/**
 * To get the backdrop screen
 */
export const GetBackDropScreen = () => {
  return <div className="modal-backdrop fade in" />;
};

/**
 * To render the right side panel for the GCM modal
 */
export const RenderRightSidePanel = props => {
  return (
    <div className="right-content">
      {isFaqMobile() ? (
        <RenderMobileContent
          {...props}
          setMobileActions={props.setMobileActions}
          currentAction={props.mobileAction}
          costingDate={props.costingConfiguration.departureDate}
        />
      ) : (
        <RenderDesktopContent {...props} />
      )}
    </div>
  );
};

export const RenderDesktopContent = props => {
  let {
    costingHandler,
    allSuggestions,
    user_details,
    costingConfiguration = {},
    regionStatus,
    makeReadOnly,
    flightsBookedByUserAlready,
    handleFlightsBookedByUserAlready
  } = props;
  let isUserExit = user_details && user_details.loggedIn;
  const isAdminUser = user_details && user_details.loggedIn && user_details.userType === 'ADMIN';
  return <Fragment>
    <RenderDestopCloseModal {...props} />
    <section className="hidden-xs">
      <RenderDesktopHeaderComponent {...props} />
      <form action="#">
        <DepartureCityCosting
          cities={allSuggestions}
          costingHandler={costingHandler}
          currentAirport={costingConfiguration.departureAirport}
          currentCity={costingConfiguration.departureCity}
          hasError={
            props.airportFailed && !costingConfiguration.departureAirport
          }
          popupOpened={props.popupOpened}
          isCred={makeReadOnly}
        />
        <DepartureDateDesk
          costingDate={costingConfiguration.departureDate}
          costingHandler={costingHandler}
          hasError={props.departureDateFailed}
          popupOpened={props.popupOpened}
          isCred={makeReadOnly}
        />
        <CostingSelection
          costingInfo={costingConfiguration.hotelGuestRoomConfigurations}
          costingHandler={costingHandler}
          popupOpened={props.popupOpened}
          makeReadOnly={makeReadOnly}
        />
        {isAdminUser ?
          <div className={'form-group '}>
            <label className="control-label">Intl flights booked?</label>
            <div className={'block'}>
              <label className="custom-options no-padding">
                <input
                  type="checkbox"
                  value="true"
                  name={'flightsBookedByUserAlready'}
                  checked={
                    flightsBookedByUserAlready
                  }
                  onChange={handleFlightsBookedByUserAlready}
                />{' '}
                Yes
                                <i />
              </label>{' '}
            </div>
          </div>
          : null}
        {isUserExit ? null : <RenderSignUpComponent {...props} />}
        <RenderDesktopFooterComponent {...props} />
      </form>
    </section>
  </Fragment>;
};

export const RenderDesktopHeaderComponent = props => {
  let { itineraryDetail, showDateExpiredAlert, history } = props;
  let autoOpenedPopup = history.location.pathname.indexOf('autoopen') > 0;
  let inVacationsPage = checkIndexOf(history.location.pathname, ['vacations']);
  let { costed } = itineraryDetail;
  return (
    <div className="title-txt">
      <h5 className="medium-heading bold">
        {inVacationsPage
          ? autoOpenedPopup
            ? "Give us your requirements & we'll craft your itinerary!"
            : 'Wohoo! You are one step away from an awesome itinerary!'
          : costed
            ? showDateExpiredAlert
              ? 'Pricing expired! Please update your travel details'
              : 'Update your trip details'
            : 'Let’s see your travel plans first!'}
      </h5>
    </div>
  );
};

export const RenderDestopCloseModal = props => {
  return (
    <div className="top-btns hidden-xs">
      <Button
        buttonClass="pull-right btn btn-link"
        clickAction={props.closeModal}
        dataDismiss="modal"
      >
        <i className="vehoicon-close" />
      </Button>
    </div>
  );
};

const mapStateToProps = state => {
  let app = state.app;
  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      campaignItineraryId: app.itineraryInfo.campaignItineraryId,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      regionStatus: app.regionStatus,
      hotelDetails: state.hotelDetails,
      makeReadOnly: app.isReadOnly
    };
  } else {
    let packages =
      ((state.packages || {}).content || {}).filteredItineraries || [];
    let vacations =
      ((state.vacations || {}).content || {}).filteredItineraries || [];
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      campaignItineraryId: '',
      itineraryDetail: {},
      seoItinerary: packages.concat(vacations),
      user_details: app.user_details,
      regionStatus: app.regionStatus,
      hotelDetails: state.hotelDetails,
      makeReadOnly: app.isReadOnly
    };
  }
};

const mapDispatchToProps = dispatch => {
  return {
    actions: {
      manageSoftNotification: bindActionCreators(
        manageSoftNotification,
        dispatch
      ),
      getCost: bindActionCreators(getCost, dispatch),
      getUserDetails: bindActionCreators(getUserDetails, dispatch),
      showLoginForm: bindActionCreators(showLoginForm, dispatch),
      showSignUpForm: bindActionCreators(showSignUpForm, dispatch),
      manageRegionStats: bindActionCreators(manageRegionStats, dispatch)
    }
  };
};

export default withLastLocation(
  connect(mapStateToProps, mapDispatchToProps)(GetCostModal)
);
