import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import classNames from 'classnames';
import { updateHotel } from '../../actions/actions_app';

import HotelDetails from './components/hotel_details';
import {
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  HOTEL_ALTERNATES
} from '../../helpers/routesHelper';

class HotelDetailsModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      hotelDetails: {},
      showGallery: false,
      isKilled: false,
      stickyHeaderClassMobile: '',
      selectedAlternateHotel: null
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.handleSelectedAlternateHotel = this.handleSelectedAlternateHotel.bind(
      this
    );

    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.hotelCostings &&
      !Object.keys(this.state.hotelDetails).length
    ) {
      let currentHotelKey = this.props.match.params.hotelKey;
      let currentHotelCode = this.props.match.params.hotelCode;
      currentHotelKey = decodeCostingKeyFromURL(currentHotelKey);

      let currentDetail =
        props.itineraryInfo.hotelCostings.hotelCostingById[currentHotelKey];

      if (!currentDetail) {
        this.closeModal(true);
      }

      if (currentHotelCode) {
        let selectedAlternateHotel =
          props.hotelDetailsFromAlternates.selectedHotel;

        if (selectedAlternateHotel) {
          selectedAlternateHotel.called_from = 'ALTERNATE_HOTELS';

          this.setState(
            {
              hotelDetails: currentDetail,
              selectedAlternateHotel
            },
            () => {
              // onceModalOverOpened();
            }
          );
        } else {
          let { history, location, match, itineraryDetail } = this.props;
          const hotelKey = match.params.hotelKey;

          history.push(
            itineraryModalsRouteHelper({
              itineraryId: itineraryDetail.itineraryId,
              regionCode: itineraryDetail.regionCode,
              location,
              target: HOTEL_ALTERNATES,
              customParams: { hotelKey }
            })
          );
        }
      } else {
        this.setState({ hotelDetails: currentDetail });
      }
    }
  }

  openModal() {
    this.setState(
      {
        isKilled: false
      },
      () => {
        this.setState({ showModal: true, showGallery: true }, () => {
          onceModalOpened();
        });
      }
    );
  }

  closeModal(backToHome = false) {
    let { history, location, match, itineraryDetail } = this.props;

    setTimeout(() => {
      this.setState({ showGallery: false, showModal: false }, () => {
        if (match.params.hotelCode && !backToHome) {
          // Called from alternates
          history.goBack();

          // onceModalOverClosed();
        } else {
          onceModalClosed();
         
          history.push(
            itineraryModalsRouteHelper({
              itineraryId: itineraryDetail.itineraryId,
              regionCode: itineraryDetail.regionCode,
              location
            })
          );
        }
      });

      // let hotel = _this.props.activeHotelDetails;
      // if (hotel.called_from !== 'ALTERNATE_HOTELS') {
      //   $('body').removeClass('modal-open');
      // }
    }, 400);
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }

  handleSelectedAlternateHotel(selectedAlternateHotel, e) {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();

    let data = {
      itineraryId: this.props.itineraryDetail.itineraryId,
      planningToolId: selectedAlternateHotel.planningToolId,
      cacheKey: this.props.hotelDetailsFromAlternates.cacheKey,
      hotelQuery: selectedAlternateHotel.hotelQuery,
      offline: selectedAlternateHotel.offlineHotels
    };

    this.props.actions
      .updateHotel(data)
      .then(() => {
        this.closeModal(true);
      })
      .catch(() => {
        this.closeModal(true);
      });
  }

  render() {
    if (this.state.isKilled) {
      return null;
    }

    /**
     * TODO: HidePrice Prop unresolved!
     * TODO: Packagerate and handleguesroomconfigurations unresolved!
     */
    return <React.Fragment>
      {this.state.selectedAlternateHotel ? (
        <div className={'modal-backdrop fade in'} key={0} />
      ) : null}
      <div
        tabIndex="0"
        key={1}
        className={classNames(
          'modal fade modal-sticky-header alternate-modal hotel-modal',
          {
            in: this.state.showModal,
            'modal-over-modal': this.state.selectedAlternateHotel
          }
        )}
      >
        <HotelDetails
          stickyHeaderClassMobile={this.state.stickyHeaderClassMobile}
          onCloseModal={this.closeModal}
          splitPricing={this.props.itineraryDetail.splitPricing}
          userDetails={this.props.user_details}
          hotelDetails={
            this.state.selectedAlternateHotel
              ? this.state.selectedAlternateHotel
              : this.state.hotelDetails
          }
          itineraryDetail={this.props.itineraryDetail}
          itineraryId={this.props.itineraryDetail.itineraryId}
          packageRate={this.props.packageRate}
          hotelGuestRoomConfigurations={this.props.hotelGuestRoomConfigurations}
          handleSelectedAlternateHotel={this.handleSelectedAlternateHotel}
          showGallery={this.state.showGallery}
          showModal={this.state.showModal}
          {...this.props}
        />
      </div>
    </React.Fragment>
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      hotelDetailsFromAlternates: app.hotelDetailsFromAlternates
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details,
      hotelDetailsFromAlternates: app.hotelDetailsFromAlternates
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      updateHotel: bindActionCreators(updateHotel, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(HotelDetailsModal);
