import React, { Component } from 'react';
import classNames from 'classnames';
import { connect } from 'react-redux';
import _ from 'lodash';

import ActivityDetails from './components/activity_details';
import {
  decodeActivityKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import {
  ACTIVITY_ALTERNATES,
  itineraryModalsRouteHelper,
  routingPageType
} from '../../helpers/routesHelper';

class ActivityDetailsModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      deleteActivity: false,
      stickyHeaderClassMobile: '',
      activeActivity: {},
      selectedAlternateActivity: null
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.iterSlotByKey &&
      !Object.keys(this.state.activeActivity).length
    ) {
      let currentSlotKey = this.props.match.params.activityKey;
      let currentActivityId = this.props.match.params.activityId;
      currentSlotKey = decodeActivityKeyFromURL(currentSlotKey);

      let currentDetail = props.itineraryInfo.iterSlotByKey[currentSlotKey];
      if (!currentDetail) {
        this.closeModal(true);
      }

      currentDetail.slotIdentifier = currentSlotKey;
      if (
        currentDetail.type !== 'LEISURE' &&
        currentDetail.type !== 'INTERCITY_TRANSFER'
      ) {
        let activityDetails =
          props.itineraryInfo.activityById[
            currentDetail.activitySlotDetail.activityId
          ];
        _.assign(currentDetail.activitySlotDetail, activityDetails);

        let activityCostingDetails = {};
        if (
          props.itineraryInfo.itinerary.costed &&
          !props.itineraryInfo.itinerary.staleCost
        ) {
          activityCostingDetails =
            props.itineraryInfo.activityCostings.activityCostingById[
              currentDetail.activitySlotDetail.activityCostingIdentifier
            ];
        }

        currentDetail = { ...currentDetail, ...activityCostingDetails };
      }

      if (currentActivityId) {
        let selectedAlternateActivity =
          props.activityDetailsFromAlternates.selectedActivity;

        if (selectedAlternateActivity) {
          this.setState(
            {
              activeActivity: currentDetail,
              selectedAlternateActivity
            },
            () => {
              // onceModalOverOpened();
            }
          );
        } else {
          let { history, location, match, itineraryInfo } = this.props;
          const { itineraryId, regionCode } = itineraryInfo.itinerary;

          if (location.pathname.indexOf(routingPageType.itinerary) > 0) {
            history.push(
              itineraryModalsRouteHelper({
                itineraryId,
                regionCode,
                target: ACTIVITY_ALTERNATES,
                customParams: {
                  activityKey: match.params.activityKey
                }
              })
            );
          } else {
            history.push(
              itineraryModalsRouteHelper({
                itineraryId,
                regionCode,
                parentPage: routingPageType.inclusion,
                target: ACTIVITY_ALTERNATES,
                customParams: {
                  activityKey: match.params.activityKey
                }
              })
            );
          }
        }
      } else {
        this.setState({ activeActivity: currentDetail });
      }
    }
  }

  closeModal(backToHome = false, onRemove = false) {
    const { history, location, match, itineraryDetail } = this.props;
    const { itineraryId, regionCode } = itineraryDetail;

    setTimeout(() => {
      this.setState({ showModal: false, deleteActivity: false }, () => {
        if (match.params.activityId && !backToHome) {
          // Called from alternates
          history.goBack();

          // onceModalOverClosed();
        } else {
          const itineraryPath = itineraryModalsRouteHelper({
            itineraryId,
            regionCode
          });
          const inclusionsPath = itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            parentPage: routingPageType.inclusion
          });

          if (onRemove) {
            if (location.pathname.indexOf('view') > 0) {
              history.replace(itineraryPath);
            } else {
              history.replace(inclusionsPath);
            }
          } else {
            if (location.pathname.indexOf('view') > 0) {
              history.push(itineraryPath);
            } else {
              history.push(inclusionsPath);
            }
          }
          
          onceModalClosed();
        }
      });
    }, 400);
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }

  openModal() {
    this.setState({ showModal: true, deleteActivity: false }, () => {
      onceModalOpened();
    });
  }

  render() {
    let { activeActivity, selectedAlternateActivity, showModal } = this.state;

    return (
      <React.Fragment>
        {selectedAlternateActivity ? (
          <div className={'modal-backdrop fade in'} />
        ) : null}
        <div
          tabIndex="0"
          className={classNames(
            'modal fade modal-sticky-header alternate-modal hotel-modal',
            {
              in: showModal,
              'modal-over-modal': selectedAlternateActivity
            }
          )}
        >
          <ActivityDetails
            {...this.props}
            activeActivity={
              selectedAlternateActivity
                ? selectedAlternateActivity
                : activeActivity
            }
            purpose="detailsModal"
            key={'activity-details'}
            onlyActivityDetails={true}
            onCloseModal={this.closeModal}
          />
        </div>
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      activityDetailsFromAlternates: app.activityDetailsFromAlternates,
      makeReadOnly: app.isReadOnly
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details,
      activityDetailsFromAlternates: app.activityDetailsFromAlternates,
      makeReadOnly: app.isReadOnly
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {}
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  ActivityDetailsModal
);
