import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { deleteFlight, manageInterCityTransfer } from '../../actions/actions_app';
import _ from 'lodash';
import { itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';

import FlightDetails from '../../common_components/itinerary/flight_details';
import {
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';

class FlightDetailsModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      flight: {},
      stickyHeaderClassMobile: ''
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.deleteFlight = this.deleteFlight.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.handleCallToActionClick = this.handleCallToActionClick.bind(this);
    this.getCurrentFlight = this.getCurrentFlight.bind(this);
  }

  componentDidMount() {
    this.openModal();
    this.getCurrentFlight(this.props);

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentFlight(props);
  }

  getCurrentFlight(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.flightCostings &&
      !Object.keys(this.state.flight).length
    ) {
      let currentFlightKey = this.props.match.params.flightKey;
      currentFlightKey = decodeCostingKeyFromURL(currentFlightKey);

      let currentFlight =
        props.itineraryInfo.flightCostings.flightCostingById[currentFlightKey];

      this.setState({ flight: currentFlight });
    }
  }

  closeModal() {
    let { history, location, itineraryDetail } = this.props;

    setTimeout(() => {
      this.setState({ showModal: false, flight: {} }, () => {
        onceModalClosed();

        history.push(
          itineraryModalsRouteHelper({
            itineraryId: itineraryDetail.itineraryId,
            regionCode: itineraryDetail.regionCode,
            location
          })
        );
      });
    }, 400);
  }

  deleteFlight(flight) {
    let deleteFlightsRequest = {
      itineraryId: this.props.itineraryDetail.itineraryId,
      flightCostingConfigKey: flight.key
    };

    this.props.actions
      .deleteFlight(deleteFlightsRequest)
      .then(() => {
        this.closeModal();
      })
      .catch(() => {
        this.closeModal();
      });
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }
  /**
   * To handle action for the remove intercity flight 
   */
  handleCallToActionClick(payload, e) {
    e && e.preventDefault();
    this.props.actions
      .manageInterCityTransfer(payload)
      .then()
      .catch();
  }
  openModal() {
    this.setState({ showModal: true });

    onceModalOpened();
  }

  render() {
    if (_.isEmpty(this.state.flight)) {
      return null;
    } else {
      return (
        <div
          tabIndex="-1"
          className={
            'modal fade modal-sticky-header alternate-modal ' +
            (this.state.showModal ? 'in' : '')
          }
          ref="modal"
        >
          <FlightDetails
            stickyHeaderClassMobile={this.state.stickyHeaderClassMobile}
            onCloseModal={this.closeModal}
            flightData={this.state.flight}
            user_details={this.props.user_details}
            itineraryDetail={this.props.itineraryDetail}
            deleteFlight={this.deleteFlight}
            itineraryId={this.props.itineraryId}
            adult_count={this.props.adult_count}
            child_count={this.props.child_count}
            handleCallToActionClick={this.handleCallToActionClick}
          />
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      deleteFlight: bindActionCreators(deleteFlight, dispatch),
      manageInterCityTransfer: bindActionCreators(manageInterCityTransfer, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(FlightDetailsModal);
