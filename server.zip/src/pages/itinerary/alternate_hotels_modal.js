import React, { Component } from 'react';
import _ from 'lodash';
import axios from 'axios';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  updateHotel,
  openHotelsFromAlternates
} from '../../actions/actions_app';

import AlternateHotels from './components/alternate_hotels';
import AlternateHotelsFilter from './components/alternate_hotels_filter';

import AlternateFilterLoading from './components/loaders/alternate_filters_loading';
import AlternateHotelsActivitiesLoading from './components/loaders/alternate_hotels_activities_loading';

import { AppConfig } from '../../app-config';
import {
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import classNames from 'classnames';
import {
  itineraryModalsRouteHelper, ITINERARY_ROUTES, inclusionsRoute
} from '../../helpers/routesHelper';
import { Route, Switch } from 'react-router-dom';
import { HotelDetailsModalLoadable } from '../../helpers/loadbleComponentsHelper';
import {
  trackEvent,
  EVENT_ITINERARY_MODIFIED,
  EVENT_INCLUSIONS_MODIFIED
} from '../../helpers/ML/EventsTracker';

const API_URL = AppConfig.api_url;

/*global swal */

class AlternateHotelsModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      currentPick: {},
      filters: {},
      componentStatus: 'IDLE',
      existingHotelSet: [],
      alternateHotels: { hotelCostingVOList: [] },
      itineraryId: '',
      currentHotelDetails: {},
      currentPageNumber: 0,
      currentFilteredPageNumber: 0,
      lastRequestType: 'WITHOUT_FILTER',
      moreAvailable: false,
      backgroundHeight: '100vh',
      enableFilterOnMobile: false,
      isLoading: false
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.getAlternateHotels = this.getAlternateHotels.bind(this);
    this.handleSelectedAlternateHotel = this.handleSelectedAlternateHotel.bind(
      this
    );

    this.applyFilters = this.applyFilters.bind(this);
    this.showAlternatesLoading = this.showAlternatesLoading.bind(this);
    this.hideAlternatesLoading = this.hideAlternatesLoading.bind(this);
    this.loadMore = this.loadMore.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.getCurrentDetails = this.getCurrentDetails.bind(this);

    this.showHotelFilters = this.showHotelFilters.bind(this);
    this.hideHotelFilters = this.hideHotelFilters.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.hotelCostings &&
      !Object.keys(this.state.currentPick).length
    ) {
      let currentHotelKey = this.props.match.params.hotelKey;
      currentHotelKey = decodeCostingKeyFromURL(currentHotelKey);

      let currentDetail =
        props.itineraryInfo.hotelCostings.hotelCostingById[currentHotelKey];

      if (!currentDetail) {
        this.closeModal();
      }

      const isInclusions =
        window &&
        window.location &&
        (window.location.pathname || '').includes('/inclusions/');
      trackEvent(
        isInclusions ? EVENT_INCLUSIONS_MODIFIED : EVENT_ITINERARY_MODIFIED,
        {	
          hotel_changed: true
        }
      );

      this.setState({ currentPick: currentDetail }, () => {
        let altHotelRequestObject = {
          checkInDate: currentDetail.checkInDate,
          checkOutDate: currentDetail.checkOutDate,
          hotelCostingKey: currentHotelKey,
          cityId: currentDetail.cityId,
          hotelGuestConfiguration: {
            guestRoomConfigurations:
              props.itineraryInfo.costingConfiguration
                .hotelGuestRoomConfigurations
          }
        };

        this.getAlternateHotels(
          altHotelRequestObject,
          currentDetail,
          props.itineraryInfo.itinerary.itineraryId,
          'NONE'
        );
      });
    }
  }

  openModal() {
    this.setState({ showModal: true }, () => {
      onceModalOpened();
    });
  }

  getAlternateHotels(CityHotelConfig, currentHotel, itineraryId, source) {
    CityHotelConfig.itineraryId = itineraryId;

    if (CityHotelConfig.filters === undefined) {
      let oldState = this.state;
      oldState.alternateHotels = {
        hotelCostingVOList: this.state.alternateHotels.hotelCostingVOList
      };
      oldState.showModal = true;
      if (this.state.currentPageNumber === 0) {
        oldState.componentStatus = 'LOADING';
      }
      oldState.lastRequestType = 'WITHOUT_FILTER';
      this.setState(oldState);
      CityHotelConfig.pageNum = this.state.currentPageNumber + 1;
    } else {
      let oldState = this.state;
      oldState.lastRequestType = 'WITH_FILTER';
      oldState.componentStatus = 'FILTERING';
      // this.showAlternatesLoading();

      oldState.filters = CityHotelConfig.filters;
      if (source === 'LOAD_MORE') {
        oldState.alternateHotels = {
          hotelCostingVOList: this.state.alternateHotels.hotelCostingVOList
        };
      } else {
        oldState.alternateHotels = { hotelCostingVOList: [] };
      }
      oldState.currentFilteredPageNumber =
        this.state.currentFilteredPageNumber + 1;
      this.setState(oldState);
      if (source === 'LOAD_MORE') {
        CityHotelConfig.pageNum = this.state.currentFilteredPageNumber;
      } else {
        CityHotelConfig.pageNum = 1;
      }
    }

    let newState = {};
    let url = `${API_URL}hotel/alternates`;
    let _this = this;

    axios
      .post(url, CityHotelConfig)
      .then(response => {
        newState = _this.state;
        newState.existingHotelSet = newState.alternateHotels.hotelCostingVOList;
        newState.itineraryId = itineraryId;
        newState.currentHotelDetails = CityHotelConfig;
        newState.componentStatus = 'IDLE';

        if (response.data) {
          newState.alternateHotels = response.data;
          newState.alternateHotels.hotelCostingVOList = newState.existingHotelSet.concat(
            response.data.hotelCostingVOList
          );

          if (_this.state.lastRequestType === 'WITHOUT_FILTER') {
            newState.currentPageNumber = response.data.currentPageNum;
          } else {
            newState.currentFilteredPageNumber = response.data.currentPageNum;
          }

          _this.state.moreAvailable = response.data.moreResultsAvailable;
        } else {
          newState.alternateHotels = {};
          newState.alternateHotels.hotelCostingVOList =
            newState.existingHotelSet;
        }

        _this.setState(newState);
      })
      .catch(error => {
        // _this.hideAlternatesLoading();
        // console.log(error);
        swal(
          {
            title: 'Oops!',
            text: 'Something went wrong while we were looking for hotels!',
            // imageUrl: '/images/cost_error.png',
            animation: true,
            showCancelButton: false,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Try again!',
            cancelButtonText: 'Cancel',
            closeOnConfirm: true,
            closeOnCancel: true
          },
          function() {
            _this.closeModal();
          }
        );
      });
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }

  hideHotelFilters() {
    this.setState({ enableFilterOnMobile: false });
  }

  showHotelFilters() {
    this.setState({ enableFilterOnMobile: true });
  }

  closeModal(replace = false) {
    let { history, location, itineraryDetail } = this.props;

    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        onceModalClosed();
        const pageUrl = itineraryModalsRouteHelper({
          itineraryId: itineraryDetail.itineraryId,
          regionCode: itineraryDetail.regionCode,
          location
        });

        if (replace) {
          history.replace(pageUrl);
        } else {
          history.push(pageUrl);
        }
      });
    }, 400);
  }

  handleSelectedAlternateHotel(selectedAlternateHotel, e) {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();

    const isInclusions =
      window &&
      window.location &&
      (window.location.pathname || '').includes('/inclusions/');
    trackEvent(
      isInclusions ? EVENT_INCLUSIONS_MODIFIED : EVENT_ITINERARY_MODIFIED,
      {
        hotel_changed: true
      }
    );

    let data = {
      itineraryId: this.state.itineraryId,
      planningToolId: selectedAlternateHotel.planningToolId,
      cacheKey: this.state.alternateHotels.cacheKey,
      hotelQuery: selectedAlternateHotel.hotelQuery,
      offline: selectedAlternateHotel.offlineHotels
    };

    this.setState(
      {
        isLoading: selectedAlternateHotel.hotelCode
      },
      () => {
        this.props.actions
          .updateHotel(data)
          .then(() => {
            this.closeModal(true);
          })
          .catch(() => {
            this.closeModal(true);
          });
      }
    );
  }

  applyFilters(appliedFilters, source) {
    const currentHotelDetails = Object.assign(
      {},
      this.state.currentHotelDetails,
      { filters: appliedFilters }
    );
    this.getAlternateHotels(
      currentHotelDetails,
      this.state.currentPick,
      this.props.itineraryInfo.itinerary.itineraryId,
      source
    );
  }

  showAlternatesLoading() {
    // this.refs.alternates.showLoading();
  }

  hideAlternatesLoading() {
    // if (this.refs.alternates !== undefined) this.refs.alternates.hideLoading();
  }

  loadMore() {
    if (this.state.lastRequestType === 'WITH_FILTER') {
      this.applyFilters(this.state.filters, 'LOAD_MORE');
    } else {
      this.getAlternateHotels(
        this.state.currentHotelDetails,
        this.state.currentPick,
        this.props.itineraryInfo.itinerary.itineraryId,
        'NONE'
      );
    }
  }

  render() {
    let alternateHotels = this.state.alternateHotels;

    if (
      _.isEmpty(alternateHotels && alternateHotels.hotelCostingVOList) &&
      this.state.componentStatus === 'LOADING'
    ) {
      return (
        <div
          tabIndex="0"
          className={
            'modal fade alternate-modal width-auto ' +
            (this.state.showModal ? 'in' : '')
          }
        >
          <div
            className={classNames('modal-dialog', {
              'enable-filter': this.state.enableFilterOnMobile
            })}
          >
            <div className="container modal-alternate-wrapper">
              <div className="row">
                <div className="col-md-3 filter-display">
                  <AlternateFilterLoading loaderState={false} />
                </div>
                <div className="col-md-9 ">
                  <div className={'modal-content with-header'}>
                    <div className="modal-header">
                      <div className="header-bar mobile-toggle">
                        <div className="pull-right visible-xs visible-sm">
                          <button
                            className="trans-btn"
                            onClick={this.showHotelFilters}
                          >
                            <span className="vehoicon-tune modal-filter" />
                          </button>
                        </div>

                        <span className="text-uppercase kern-more bolder fade">
                          Change Hotel
                        </span>

                        <button
                          type="button"
                          className="close"
                          onClick={this.closeModal}
                        >
                          <i className="vehoicon-close" />
                        </button>
                      </div>
                    </div>

                    <div className={'modal-body'}>
                      <AlternateHotelsActivitiesLoading
                        loaderState={false}
                        // w={contentWidth}
                        title={'Change Hotel'}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      let renderHotels = (alternateHotels || {}).hotelCostingVOList || [];
      if (
        this.state.currentPick &&
        this.state.currentPick.planningToolId !== undefined
      ) {
        renderHotels = _.filter(renderHotels, hotel => {
          return this.state.currentPick.planningToolId !== hotel.planningToolId;
        });
      }
      let { currentPick } = this.state;

      let currentPick_location = '';

      const sparkLinesData = alternateHotels.alternateHotelFilters
        ? alternateHotels.alternateHotelFilters.priceRange
        : [];
      return (
        <div
          tabIndex="0"
          className={
            'modal fade alternate-modal width-auto ' +
            (this.state.showModal ? 'in' : '')
          }
          id="change-hotels-modal"
        >
          <div
            className={classNames('modal-dialog', {
              'enable-filter': this.state.enableFilterOnMobile
            })}
          >
            <div
              className="container modal-alternate-wrapper"
            >
              <div className="row">
                <div className="filter-display col-md-3 gutter-less-filter">
                  <AlternateHotelsFilter
                    applyFilters={this.applyFilters}
                    handleFilterCloseIconClick={this.hideHotelFilters}
                    filterOptions={alternateHotels.alternateHotelFilters}
                    minPrice={alternateHotels.minPrice}
                    maxPrice={alternateHotels.maxPrice}
                    onCloseModal={this.closeModal}
                    selectedMinPrice={alternateHotels.minPrice}
                    selectedMaxPrice={alternateHotels.maxPrice}
                    sparkLinesData={sparkLinesData}
                    currentPickHotel={this.state.currentPick}
                    {...this.props}
                    splitPricing={this.props.itineraryDetail.splitPricing}
                  />
                </div>
                <div className="col-md-9 mobile-hide-on-filter">
                  <div className={'modal-content with-header'}>
                    <div className="modal-header">
                      <div className="header-bar mobile-toggle">
                        <div className="pull-right visible-xs visible-sm">
                          <button
                            className="trans-btn"
                            onClick={this.showHotelFilters}
                          >
                            <span className="vehoicon-tune modal-filter" />
                          </button>
                        </div>

                        <span className="text-uppercase kern-more bolder fade">
                          Change Hotel
                        </span>

                        <button
                          type="button"
                          className="close"
                          onClick={this.closeModal}
                        >
                          <i className="vehoicon-close" />
                        </button>
                      </div>
                    </div>

                    <div className={'modal-body'}>
                      {_.isEmpty(currentPick) ||
                      currentPick.status !== 'SUCCESS' ? null : (
                        <div className="current-pick-panel">
                          <div className="current-pick-content hotel">
                            <div className="col-xs-9 col-md-10">
                              {/* <a className="toggle-panel" href="#"><span className="vehoicon-arrow_downward" /><span className="sr-only">More info</span></a> */}
                              <span className="single-line-text fade small no-margin">
                                Changing: {currentPick.name} -{' '}
                                {currentPick_location}
                              </span>
                            </div>
                            <div className="col-xs-3 col-md-2 text-right">
                              {currentPick.finalPrice ? (
                                <span className="total-price small bold dim">
                                  <span className="WebRupee">Rs.</span>{' '}
                                  {currentPick.finalPrice}
                                </span>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      )}

                      <AlternateHotels
                        handleFilterIconClick={this.showHotelFilters}
                        userDetails={this.props.user_details}
                        cacheKey={alternateHotels.cacheKey}
                        offlineHotels={alternateHotels.offlineHotels}
                        hotelCostingKey={
                          (this.state.currentPick || {}).costingKey
                        }
                        loadingStatus={this.state.componentStatus}
                        packageRate={this.props.packageRate}
                        onCloseModal={this.closeModal}
                        handleSelectedAlternateHotel={
                          this.handleSelectedAlternateHotel
                        }
                        hotelList={renderHotels}
                        {...this.state}
                        loadMore={this.loadMore}
                        moreAvailable={this.state.moreAvailable}
                        currentPickHotel={this.state.currentPick}
                        splitPricing={this.props.itineraryDetail.splitPricing}
                        openHotelsFromAlternates={
                          this.props.actions.openHotelsFromAlternates
                        }
                        regionCode={this.props.itineraryDetail.regionCode}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Hotel details from Alternates */}
          <Switch>
            <Route
              path={ITINERARY_ROUTES.HOTEL_ALTERNATES_DETAILS_ROUTE}
              component={HotelDetailsModalLoadable}
            />
            <Route
              path={inclusionsRoute.ALTERNATE_HOTEL_DETAILS}
              component={HotelDetailsModalLoadable}
            />
          </Switch>
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      updateHotel: bindActionCreators(updateHotel, dispatch),
      openHotelsFromAlternates: bindActionCreators(
        openHotelsFromAlternates,
        dispatch
      )
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  AlternateHotelsModal
);
