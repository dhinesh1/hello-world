import React, { Component } from 'react';

import axios from 'axios';
import _ from 'lodash';
import AlternateHotelRooms from './components/alternate_hotel_rooms';

import { AppConfig } from '../../app-config';
import {
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import { connect } from 'react-redux';
import { itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';

const API_URL = AppConfig.api_url;

/*global swal */

class AlternateHotelRoomsModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      roomList: {},
      activeRoom: {},
      hotel: {},
      showLoadMoreLink: true
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.getCurrentDetails = this.getCurrentDetails.bind(this);
    this.buildRequstObjectAndMakeCall = this.buildRequstObjectAndMakeCall.bind(
      this
    );
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);
    document.addEventListener('keyup', this.handleKeyUp);
  }
  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  buildRequstObjectAndMakeCall(state, props, fromCache) {
    if (typeof fromCache === 'undefined') {
      fromCache = null;
    } else {
      this.setState({ showLoadMoreLink: false });
    }

    let { hotel, activeRoom } = state;
    let requestData = {
      planningToolId: hotel.planningToolId,
      roomTypeId: activeRoom.roomTypeId,
      checkInDate: hotel.checkInDate,
      checkOutDate: hotel.checkOutDate,
      itineraryId: props.itineraryInfo.itinerary.itineraryId,
      hotelGuestRoomConfiguration: activeRoom.roomConfiguration,
      hotelCostingKey: hotel.costingKey,
      roomIdentifier: activeRoom.roomIdentifier,
      fromCache: fromCache
    };
    this.getAlternateHotelRooms(requestData);
  }

  getCurrentDetails(props, state) {
    if (!state) {
      state = this.state;
    }

    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.hotelCostings &&
      !Object.keys(state.activeRoom).length
    ) {
      let currentHotelKey = props.match.params.hotelKey;
      currentHotelKey = decodeCostingKeyFromURL(currentHotelKey);
      let hotel = Object.assign(
        {},
        props.itineraryInfo.hotelCostings.hotelCostingById[currentHotelKey]
      );
      let hotelRooms = Object.assign({}, hotel.roomsInHotel);

      let currentHotelRoomKey = props.match.params.hotelRoomKey;
      currentHotelRoomKey = decodeCostingKeyFromURL(currentHotelRoomKey);
      let room = _.find(hotelRooms, e => e.roomTypeId === currentHotelRoomKey);

      this.setState({ hotel: hotel, activeRoom: room }, () => {
        this.buildRequstObjectAndMakeCall(this.state, this.props);
      });
    } else {
      // console.log('');
    }
  }

  openModal() {
    this.setState(
      { showModal: true, roomList: {}, activeRoom: {}, hotel: {} },
      () => {
        onceModalOpened();
      }
    );
  }

  closeModal() {
    let { history, location, itineraryDetail } = this.props;

    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        onceModalClosed();

        history.push(
          itineraryModalsRouteHelper({
            itineraryId: itineraryDetail.itineraryId,
            regionCode: itineraryDetail.regionCode,
            location
          })
        );
        
      });
    }, 400);
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }

  getAlternateHotelRooms(requestData) {
    let url = `${API_URL}hotel/alternaterooms`;
    axios
      .post(url, requestData)
      .then(response => {
        this.setState({ roomList: response.data });
      })
      .catch(error => {
        // console.log(error);
        swal(
          {
            title: 'Oops!',
            text: 'An unexpected error occurred while fetching room.',
            // imageUrl: '/images/cost_error.png',
            animation: true,
            showCancelButton: false,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Try again!',
            cancelButtonText: 'Cancel',
            closeOnConfirm: true,
            closeOnCancel: true
          },
          function(isConfirm) {}
        );
      });
  }

  render() {
    return (
      <div
        tabIndex="0"
        className={
          'modal fade modal-sticky-header alternate-modal ' +
          (this.state.showModal ? 'in' : '')
        }
        ref="modal"
      >
        <AlternateHotelRooms
          onCloseModal={this.closeModal}
          roomList={this.state.roomList}
          showLoadMoreLink={this.state.showLoadMoreLink}
          hotel={this.state.hotel}
          splitPricing={this.props.itineraryDetail.splitPricing}
          userDetails={this.props.user_details}
          currentPick={this.state.activeRoom}
          packageRate={this.props.itineraryDetail.packageRate}
          itineraryId={this.props.itineraryDetail.itineraryId}
          buildRequstObjectAndMakeCall={this.buildRequstObjectAndMakeCall}
          parentProps={this.props}
          parentState={this.state}
        />
      </div>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      // updateHotel: bindActionCreators(updateHotel, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  AlternateHotelRoomsModal
);
