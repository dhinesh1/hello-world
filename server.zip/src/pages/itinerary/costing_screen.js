import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import _ from 'lodash';
import ItineraryHeader from './components/itinerary_header';
import { withLastLocation } from 'react-router-last-location';
import CREDAlert from './components/cred_alert';

import TabNavPanel from './components/costing_screen/tab_nav_panel';
import CostingPanelsContainer from './components/costing_screen/costing_panels_container';
import {
  manageSoftNotification,
  getItinerary,
  manageUnAuthAlert,
  manageCREDAlert
} from '../../actions/actions_app';
import {
  fixItineraryHeader,
  hideChatIconOnMobile,
  onceModalClosed,
  isHotelSoldOutCRED
} from '../../helpers/utilsHelper';
import ItineraryFooter from './components/itinerary_footer';
import AlertNotificationBar from '../../common_components/alert_notification_bar';
import { UnAuthAlert } from '../../common_components/Components';
import { Redirect, Route, Switch } from 'react-router-dom';
import Login from '../Login';
import {
  ActivityDetailsModalLoadable,
  AlternateActivitiesModalLoadable,
  AlternateFlightsModalLoadable,
  AlternateHotelRoomsLoadable,
  AlternateHotelsModalLoadable,
  AlternateRentalCarsLoadable,
  AlternateTrainsModalLoadable,
  ChangeItineraryInsuranceLoadable,
  ChangeRentalCarInsuranceLoadable,
  ChangeVisaModalLoadable,
  CostingDelayScreenLoadable,
  EmailQuoteModalLoadable,
  FlightDetailsModalLoadable,
  GetCostModalLoadable,
  HotelDetailsModalLoadable,
  RateMatchModalLoadable,
  RCDetailsModalLoadable,
  RequestCallbackModalLoadable,
  ShareItineraryModalLoadable,
  TrainDetailsModalLoadable,
  AlternateBusesModalLoadable,
  AlternateFerriesModalLoadable
} from '../../helpers/loadbleComponentsHelper';
import { inclusionsRoute, itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';

class CostingScreen extends Component {
  constructor(props) {
    super(props);

    this.closeAlert = this.closeAlert.bind(this);
  }

  componentDidMount() {
    const { itineraryId } = this.props.match.params;

    if (_.isEmpty(this.props.itineraryInfo)) {
      this.props.actions.getItinerary(itineraryId);
    }
    window.addEventListener('scroll', this.fixItineraryHeaderTab);
    hideChatIconOnMobile();
  }

  fixItineraryHeaderTab = () => {
    fixItineraryHeader('costing');
  }

  componentDidUpdate() {
    this.fixItineraryHeaderTab()
    const { itineraryInfo, location, lastLocation } = this.props;

    if(itineraryInfo){
      const { itineraryId, regionCode } = itineraryInfo.itinerary;

      const inclusionPath = itineraryModalsRouteHelper({
        itineraryId,
        regionCode,
        parentPage: routingPageType.inclusion
      });

      // check for modal-backdrop
      if (
        location &&
        lastLocation &&
        location.pathname !== lastLocation.pathname &&
        location.pathname === inclusionPath
      ) {
        onceModalClosed();
      }
    }
  }

  closeCREDAlert = () => {
    this.props.actions.manageCREDAlert(false).then(() => {
      this.props.history.replace(`/cred-bali`);
      onceModalClosed();
    })
  }

  closeAlert() {
    this.props.actions.manageUnAuthAlert({ show: false }).then(() => {
      // Go to home page on Ok go to Homepage click
      this.props.history.push('/');
      onceModalClosed();
    });
  }

  componentWillUnmount(){
    window.removeEventListener('scroll', this.fixItineraryHeaderTab);
  }

  render() {
    let { itineraryInfo, itineraryDetail, user_details, makeReadOnly } = this.props;
    if (
      this.props.itineraryInfo !== undefined &&
      !_.isEmpty(this.props.itineraryInfo)
    ) {
      // Need to redirected to itinerary page if the itinerary is not even costed OR in case of stale-costed
      // StaleCost flag will have proper values after the itinerary costed atleast once.
      if (
        !itineraryDetail.costed ||
        (itineraryDetail.costed && itineraryDetail.staleCost)
      ) {
        const itineraryPage = itineraryModalsRouteHelper({
          regionCode: itineraryDetail.regionCode,
          itineraryId: itineraryDetail.itineraryId
        });

        return <Redirect to={itineraryPage} />;
      }

      // Check if hotel status is SOLD_OUT for selected CRED itinerary
      const credResponse = isHotelSoldOutCRED(itineraryInfo || {});
      if(credResponse.status) {
        return <CREDAlert credAlertStatus={this.props.credAlertStatus} callback={this.closeCREDAlert} />
      }

      return (
        <div className={'pos-r bg-grey-lighter'}>
          <AlertNotificationBar />
          <UnAuthAlert {...this.props.unAuth} callback={this.closeAlert} />

          <div className={'clearfix'}>
            <ItineraryHeader {...this.props} target={'costing'} />
          </div>
          <div className="container costing-tab xs-full-width">
            <div className="row">
              <TabNavPanel
                costedItinerary={itineraryInfo}
                userDetails={user_details}
                purpose={'desktop'}
                {...this.props}
              />

              <CostingPanelsContainer
                userDetails={user_details}
                costedItinerary={itineraryInfo}
                {...this.props}
                makeReadOnly={makeReadOnly}
              />

              <ItineraryFooter itineraryView={false} />
            </div>
          </div>

          {/* Routes */}
          <Switch>
            <Route
              path={inclusionsRoute.UPDATE_COST}
              exact
              component={GetCostModalLoadable}
            />

            <Route
              path={inclusionsRoute.EMAIL_QUOTE}
              component={EmailQuoteModalLoadable}
            />
            <Route
              path={inclusionsRoute.SHARE_ITINERARY}
              component={ShareItineraryModalLoadable}
            />
            <Route path={inclusionsRoute.LOGIN} component={Login} />
            <Route
              path={inclusionsRoute.REQUEST_CALLBACK}
              component={RequestCallbackModalLoadable}
            />
            <Route
              path={inclusionsRoute.COSTING_DELAY}
              component={CostingDelayScreenLoadable}
            />

            {/* Flight modals */}
            <Route
              path={inclusionsRoute.FLIGHT_DETAILS}
              component={FlightDetailsModalLoadable}
            />
            <Route
              path={inclusionsRoute.ALTERNATE_FLIGHTS}
              component={AlternateFlightsModalLoadable}
            />

            {/* Hotel modals */}
            <Route
              path={inclusionsRoute.HOTEL_DETAILS}
              exact
              component={HotelDetailsModalLoadable}
            />

            {/* Alternate hotels */}
            <Route
              path={inclusionsRoute.ALTERNATE_HOTEL}
              exact
              component={AlternateHotelsModalLoadable}
            />

            {/* Alternate hotel rooms */}
            <Route
              path={inclusionsRoute.ALTERNATE_ROOM}
              exact
              component={AlternateHotelRoomsLoadable}
            />

            {/* Activities modals */}
            <Route
              path={inclusionsRoute.ACTIVITY_DETAILS}
              exact
              component={ActivityDetailsModalLoadable}
            />
            <Route
              path={inclusionsRoute.ALTERNATE_ACTIVITY}
              component={AlternateActivitiesModalLoadable}
            />

            {/* Visa Insurance Modals */}
            <Route
              path={inclusionsRoute.CHANGE_INSURANCE}
              exact
              component={ChangeItineraryInsuranceLoadable}
            />
            <Route
              path={inclusionsRoute.CHANGE_VISA}
              exact
              component={ChangeVisaModalLoadable}
            />

            {/* Rental Car Modals */}
            <Route
              path={inclusionsRoute.RENTAL_CAR_DETAILS}
              exact
              component={RCDetailsModalLoadable}
            />
            <Route
              path={inclusionsRoute.CHANGE_RENTAL_CAR_INSURANCE}
              exact
              component={ChangeRentalCarInsuranceLoadable}
            />
            <Route
              path={inclusionsRoute.ALTERNATE_RENTAL_CAR}
              exact
              component={AlternateRentalCarsLoadable}
            />

            {/* Train Modals */}
            <Route
              path={inclusionsRoute.TRAIN_DETAILS}
              exact
              component={TrainDetailsModalLoadable}
            />
            <Route
              path={inclusionsRoute.TRAIN_ALTERNATE}
              exact
              component={AlternateTrainsModalLoadable}
            />
            {/* Bus alternate modals */}
            <Route
              path={inclusionsRoute.BUS_ALTERNATE}
              component={AlternateBusesModalLoadable}
            />
            {/* Ferry alternate modals */}
            <Route
              path={inclusionsRoute.FERRY_ALTERNATE}
              component={AlternateFerriesModalLoadable}
            />

            {/* Rate Match common screen */}
            <Route
              path={inclusionsRoute.RATE_MATCH_ACTIVITY}
              exact
              component={RateMatchModalLoadable}
            />
            <Route
              path={inclusionsRoute.RATE_MATCH_FLIGHT}
              exact
              component={RateMatchModalLoadable}
            />
            <Route
              path={inclusionsRoute.RATE_MATCH_RENTAL_CAR}
              exact
              component={RateMatchModalLoadable}
            />
            <Route
              path={inclusionsRoute.RATE_MATCH_TRAIN}
              exact
              component={RateMatchModalLoadable}
            />
            <Route
              path={inclusionsRoute.RATE_MATCH_HOTEL_ROOM}
              exact
              component={RateMatchModalLoadable}
            />

            <Route
              path={inclusionsRoute.RATE_MATCH_TOTAL_COST}
              exact
              component={RateMatchModalLoadable}
            />

            <Route
              path={inclusionsRoute.ALTERNATE_HOTEL_DETAILS}
              exact
              component={AlternateHotelsModalLoadable}
            />
          </Switch>
        </div>
      );
    } else {
      return (
        <div className="loader-wrapper bg-white">
          <div className="loading-rounded color-primary lg" />
        </div>
      );
    }
  }
}

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count,
      unAuth: app.unAuth,
      makeReadOnly: app.isReadOnly,
      credAlertStatus: app.credAlertStatus
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details,
      unAuth: false,
      makeReadOnly: app.isReadOnly,
      credAlertStatus: app.credAlertStatus
    };
  }
};

const mapDispatchToProps = dispatch => {
  return {
    actions: {
      manageSoftNotification: bindActionCreators(
        manageSoftNotification,
        dispatch
      ),
      getItinerary: bindActionCreators(getItinerary, dispatch),
      manageUnAuthAlert: bindActionCreators(manageUnAuthAlert, dispatch),
      manageCREDAlert: bindActionCreators(manageCREDAlert, dispatch),
    }
  };
};

export default withLastLocation(connect(mapStateToProps, mapDispatchToProps)(CostingScreen));
