import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { Route, Switch, withRouter } from 'react-router-dom';

import { connect } from 'react-redux';
import classNames from 'classnames';
import AlertNotificationBar from '../../common_components/alert_notification_bar';

import ItineraryCityBlock from './components/itinerary_city_block';
import ItineraryHeader from './components/itinerary_header';
import {
  getItinerary,
  getCost,
  manageUnAuthAlert,
  resetItineraryDetails,
  manageCREDAlert
} from '../../actions/actions_app';
import {
  isEmptyObject,
  fixItineraryHeader,
  hideChatIconOnMobile,
  onceModalClosed,
  isHotelSoldOutCRED
} from '../../helpers/utilsHelper';
import ItineraryFooterTrustCosted from './components/itinerary_footer_trust_costed';
import ItineraryFooterTrust from './components/itinerary_footer_trust';

import ItineraryFooter from './components/itinerary_footer';
import { Helmet } from 'react-helmet';
import {
  BreadcrumbNavBar,
  UnAuthAlert
} from '../../common_components/Components';
import Login from '../Login';
import {
  ActivityDetailsModalLoadable,
  AlternateActivitiesModalLoadable,
  AlternateHotelRoomsLoadable,
  AlternateHotelsModalLoadable,
  CostingDelayScreenLoadable,
  EditTripLoadable,
  GetCostModalLoadable,
  HotelDetailsModalLoadable,
  MultiModeTransferModalLoadable,
  RateMatchModalLoadable,
  RequestCallbackModalLoadable,
  ShareItineraryModalLoadable
} from '../../helpers/loadbleComponentsHelper';
import ErrorPage from '../ErrorPage';
import Page404 from '../Page404';
import _ from 'lodash';
import CREDAlert from './components/cred_alert';
import { withLastLocation } from 'react-router-last-location';
import {
  trackEvent,
  EVENT_ITINERARY_COSTED,
  EVENT_POSITION_FOOTER
} from '../../helpers/ML/EventsTracker';

import { ITINERARY_ROUTES, itineraryModalsRouteHelper } from '../../helpers/routesHelper';
class Itinerary extends Component {
  constructor(props) {
    super(props);

    this.state = {
      totemEnabled: false
    };

    this.renderCities = this.renderCities.bind(this);
    this.toggleTotem = this.toggleTotem.bind(this);
    this.updateCostClickHandler = this.updateCostClickHandler.bind(this);
    this.closeAlert = this.closeAlert.bind(this);
  }

  componentDidMount() {
    window.scrollY = 0;
    hideChatIconOnMobile();
    let { itineraryId } = this.props.match.params;

    let qs = this.props.location.search;
    // Added condition to check the existing itinerary is same as the current one - if it's not then we will update the state with new details
    if (itineraryId && (isEmptyObject(this.props.itineraryInfo) || (this.props.itineraryInfo && this.props.itineraryInfo.itinerary && itineraryId !== this.props.itineraryInfo.itinerary.itineraryId))) {
      this.props.actions
        .getItinerary(itineraryId, qs)
        .then(() => {})
        .catch(() => {});
    }
    window.addEventListener('scroll', this.fixItineraryHeaderTab);

    if(this.props.makeReadOnly && document.getElementsByClassName('site-footer')[0]){
      document.getElementsByClassName('site-footer')[0].className = document.getElementsByClassName('site-footer')[0].className + ' hide';
    }
  }

  fixItineraryHeaderTab = () => {
    fixItineraryHeader('itinerary', this.props.isFromPackages);
  }

  componentDidUpdate(prevProps) {
    this.fixItineraryHeaderTab()

    const { itineraryInfo, location, lastLocation } = this.props;

    if(Object.keys(itineraryInfo).length){
      const { itineraryId, regionCode } = itineraryInfo.itinerary;

      const itineraryPath = itineraryModalsRouteHelper({
        itineraryId,
        regionCode
      });

      // check for modal-backdrop
      if (
        location &&
        lastLocation &&
        location.pathname !== lastLocation.pathname &&
        location.pathname === itineraryPath
      ) {
        onceModalClosed();
      }
    }

  }

  componentWillUnmount(){
    if(this.props.makeReadOnly && document.getElementsByClassName('site-footer')[0]){
      let currentClass = document.getElementsByClassName('site-footer')[0].className;
      document.getElementsByClassName('site-footer')[0].className = currentClass.replace('hide', '');
    }
    window.removeEventListener('scroll', this.fixItineraryHeaderTab);
  }

  closeCREDAlert = () => {
    this.props.actions.manageCREDAlert(false).then(() => {
      this.props.history.replace(`/cred-bali`);
      onceModalClosed();
    })
  }

  updateCostClickHandler(e) {
    e && e.preventDefault();

    let {
      itineraryInfo,
      user_details,
      history,
      lastLocation
    } = this.props;

    trackEvent(EVENT_ITINERARY_COSTED, { button: EVENT_POSITION_FOOTER });
    if (user_details.loggedIn) {
      const {itineraryId, regionCode, campaign} = itineraryInfo.itinerary;
      let configObj = itineraryInfo.costingConfiguration;

      let req_data = {
        itineraryId: itineraryId,
        costingType: 'RECOST',
        costingConfig: configObj
      };

      this.props.actions.getCost({
        itineraryId,
        regionCode,
        req_data,
        history,
        lastLocation,
        campaign
      });
    } else {
      if (history.location.pathname.indexOf('get-cost') === -1) {
        history.push(`${history.location.pathname}/get-cost`);
      }
    }
  }

  renderCities() {
    let itineraryInfo = this.props.itineraryInfo;
    let cities_length = itineraryInfo.iterCities.length;

    return itineraryInfo.iterCities.map((city, c_inx) => {
      return (
        <ItineraryCityBlock
          key={city.cityKey}
          prevCity={c_inx === 0 ? 0 : itineraryInfo.iterCities[c_inx - 1]}
          city={city}
          isFirstCity={c_inx === 0}
          islastCity={c_inx === cities_length - 1}
          {...this.props}
          isCosted={itineraryInfo.itinerary.costed}
          isBooked={
            itineraryInfo.itinerary.booking || itineraryInfo.itinerary.frozen
          }
          flightsBlocked={itineraryInfo.itinerary.flightsBlocked}
          staleCost={itineraryInfo.itinerary.staleCost}
          splitPricing={itineraryInfo.itinerary.splitPricing}
        />
      );
    });
  }

  // shouldComponentUpdate(nextProps, nextState){
  //   return !_.isEqual(nextProps.itineraryInfo,this.props.itineraryInfo);
  // }

  toggleTotem() {
    this.setState({ totemEnabled: !this.state.totemEnabled });
  }

  closeAlert() {
    this.props.actions.manageUnAuthAlert({ show: false }).then(() => {
      // Go to home page on Ok go to Homepage click
      this.props.history.push('/');
      onceModalClosed();
    });
  }

  render() {
    let {
      itineraryInfo,
      user_details,
      isFromPackages,
      metaData,
      campaignDetail,
      itineraryError,
      unAuth,
      makeReadOnly
    } = this.props;
    let canShowErrorPage = unAuth === undefined || unAuth === null;
    if (itineraryError && itineraryError.hasError && canShowErrorPage) {
      if (itineraryError.error.status === 404) {
        return <Page404 />;
      } else {
        return <ErrorPage />;
      }
    } else {
      if (!Object.keys(itineraryInfo).length) {
        return (
          <div className="loader-wrapper bg-white">
            {unAuth ? (
              <UnAuthAlert {...unAuth} callback={this.closeAlert} />
            ) : null}
            <div className="loading-rounded color-primary lg" />
          </div>
        );
      } else {
        // Check if hotel status is SOLD_OUT for selected CRED itinerary
        const credResponse = isHotelSoldOutCRED(itineraryInfo || {});
        if(credResponse.status) {
          return <CREDAlert credAlertStatus={this.props.credAlertStatus} callback={this.closeCREDAlert} />
        }

        return (
          <div className={'pos-r '}>
            <AlertNotificationBar />
            {this.props.unAuth ? (
              <UnAuthAlert {...this.props.unAuth} callback={this.closeAlert} />
            ) : null}

            {isFromPackages && metaData ? (
              <Helmet>
                <title>{metaData.title}</title>
                <meta name={'description'} content={metaData.description} />
              </Helmet>
            ) : null}

            <div className={'clearfix'}>
              {isFromPackages && itineraryInfo && !makeReadOnly? (
                <section className="breadcrumb-container">
                  <div className="container">
                    <div className="row">
                      <div className="col-xs-12 col-md-12">
                        <BreadcrumbNavBar
                          itineraryDetails={itineraryInfo}
                          campaignDetail={campaignDetail}
                        />
                      </div>
                    </div>
                  </div>
                </section>
              ) : null}

              <ItineraryHeader {...this.props} target={'itinerary'} />
            </div>
            <div className={'clearfix'}>
              <section
                className={classNames('itinerary iv', {
                  'enable-all-totem': this.state.totemEnabled
                }, {'padding-for-ro': this.props.makeReadOnly})}
              >
                <div className="container xs-full-width">
                  <div className={'row'}>
                    <div className="col-xs-12 mobile-flush">
                      {this.renderCities()}

                      {makeReadOnly ? null : itineraryInfo.itinerary.costed &&
                      !itineraryInfo.itinerary.staleCost &&
                      ((user_details && !user_details.loggedIn) ||
                        (user_details &&
                          user_details.loggedIn &&
                          user_details.userType !== 'AGENT')) ? (
                        <div className="spacer">
                          {!itineraryInfo.itinerary.booking ? (
                            <ItineraryFooterTrustCosted
                              isBooked={itineraryInfo.itinerary.booking}
                              itineraryId={itineraryInfo.itinerary.itineraryId}
                              summary={itineraryInfo.summary}
                              userDetails={user_details}
                              collapse_prefix=""
                              itinerary={itineraryInfo.itinerary}
                              itineraryMinPayableAmount={
                                itineraryInfo.recommendedAmountToBePaid
                              }
                              costingConfiguration={
                                itineraryInfo.costingConfiguration
                              }
                              {...this.props}
                              updateCostClickHandler={
                                this.updateCostClickHandler
                              }
                            />
                          ) : null}
                        </div>
                      ) : !itineraryInfo.itinerary.booking &&
                      ((user_details && !user_details.loggedIn) ||
                        (user_details &&
                          user_details.loggedIn &&
                          user_details.userType !== 'AGENT')) ? (
                        <div className="spacer">
                          <ItineraryFooterTrust
                            talkToExportTrackerClass={
                              'tracker-talk-to-an-expert-itinerary-screen'
                            }
                            {...this.props}
                            updateCostClickHandler={this.updateCostClickHandler}
                          />
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              </section>
            </div>

            <ItineraryFooter
              itineraryView={true}
              toggleTotem={this.toggleTotem}
              makeReadOnly={makeReadOnly}
            />

            {/* Routes */}
            <Switch>
              <Route
                path={ITINERARY_ROUTES.EDIT_TRIP_ROUTE}
                component={EditTripLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.GET_COST_ROUTE}
                component={GetCostModalLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.UPDATE_COST_ROUTE}
                component={GetCostModalLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.COSTING_IN_PROGRESS_ROUTE}
                component={CostingDelayScreenLoadable}
              />

              <Route
                path={ITINERARY_ROUTES.HOTEL_DETAILS_ROUTE}
                exact
                component={HotelDetailsModalLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.HOTEL_ALTERNATE_ROOMS_ROUTE}
                exact
                component={AlternateHotelRoomsLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.HOTEL_ALTERNATES_ROUTE}
                component={AlternateHotelsModalLoadable}
              />

              <Route
                path={ITINERARY_ROUTES.ACTIVITY_DETAILS_ROUTE}
                exact
                component={ActivityDetailsModalLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.ACTIVITY_ALTERNATES_ROUTE}
                component={AlternateActivitiesModalLoadable}
              />

              <Route
                path={ITINERARY_ROUTES.SHARE_ITINERARY_ROUTE}
                exact
                component={ShareItineraryModalLoadable}
              />

              <Route path={ITINERARY_ROUTES.LOGIN_ROUTE} component={Login} />
              <Route
                path={ITINERARY_ROUTES.CBR_ROUTE}
                component={RequestCallbackModalLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.SIGNUP_ROUTE}
                component={props => (
                  <Login
                    {...props}
                    actionType="SIGNUP"
                    headerText="Join the travel tribe!"
                    subText="Save your itineraries and make unlimited edits. Create an account to get started right-away!"
                  />
                )}
              />

              <Route
                path={ITINERARY_ROUTES.ALTERNATE_TRANSFER_MODE_ROUTE}
                component={MultiModeTransferModalLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.RATE_MATCH_ACTIVITY_ROUTE}
                component={RateMatchModalLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.RATE_MATCH_HOTEL_ROOM_ROUTE}
                component={RateMatchModalLoadable}
              />
              <Route
                path={ITINERARY_ROUTES.RATE_MATCH_TOTAL_ROUTE}
                component={RateMatchModalLoadable}
              />

              {/*<Redirect to={"/no-match"} />*/}
            </Switch>
          </div>
        );
      }
    }
  }
}

function mapStateToProps(state) {
  let app = state.app;
  let itineraryObj = app.itineraryInfo;

  if (!Object.keys(itineraryObj).length) {
    return {
      itineraryInfo: itineraryObj,
      itineraryError: app.itineraryError,
      user_details: app.user_details,
      unAuth: app.unAuth,
      makeReadOnly: app.isReadOnly,
      credAlertStatus: app.credAlertStatus
    };
  } else {
    itineraryObj = itineraryObj.itineraryDetails;

    return {
      itineraryInfo: itineraryObj,
      metaData: app.itineraryInfo.metaData,
      campaignItineraryId: app.itineraryInfo.campaignItineraryId,
      campaignDetail: app.itineraryInfo.campaignDetail,
      user_details: app.user_details,
      unAuth: app.unAuth,
      makeReadOnly: app.isReadOnly,
      credAlertStatus: app.credAlertStatus
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getItinerary: bindActionCreators(getItinerary, dispatch),
      getCost: bindActionCreators(getCost, dispatch),
      manageUnAuthAlert: bindActionCreators(manageUnAuthAlert, dispatch),
      manageCREDAlert: bindActionCreators(manageCREDAlert, dispatch),
      resetItineraryDetails: bindActionCreators(resetItineraryDetails, dispatch)
    }
  };
}

export default withLastLocation(
  withRouter(connect(mapStateToProps, mapDispatchToProps)(Itinerary))
);
