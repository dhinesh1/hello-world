import React, { Component } from 'react';
import _ from 'lodash';
import { AppConfig } from '../../app-config';
import axios from 'axios';
import SweetAlert from 'sweetalert-react';
import EditTripCity from './edit_trip_city';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  editCityModalApplyChanges,
  updateEditableDetails
} from '../../actions/actions_app';
import { onceModalClosed, onceModalOpened } from '../../helpers/utilsHelper';
import classNames from 'classnames';
import {
  trackEvent,
  EVENT_ITINERARY_MODIFIED
} from '../../helpers/ML/EventsTracker';
import { itineraryModalsRouteHelper } from '../../helpers/routesHelper';

class EditTrip extends Component {
  // static propTypes = {
  //   isClosing: PropTypes.bool.isRequired,
  //   replaceCityModal: PropTypes.func.isRequired,
  //   addCityModal: PropTypes.func.isRequired,
  //   updateEditableDetails: PropTypes.func.isRequired,
  //   visibleModals: PropTypes.array.isRequired,
  //   itineraryId: PropTypes.string.isRequired,
  //   itineraryDetail: PropTypes.object.isRequired,
  //   editCityModalApplyChanges: PropTypes.object.isRequired
  // };

  constructor(props) {
    super(props);

    this.state = {
      modalClass: '',
      cities: [],
      isRemoveCityLoading: false,
      isApplyChangesLoading: false,
      isRemoveConfirmationVisible: false,
      isEditCityVisible: false,
      isEditCityClosing: false,
      editCityMode: 'add',
      cityToReplace: 0,
      cityToDelete: -1,
      citySelectedToReplace: {},
      editCityOptions: {},
      isApplyChangesEnabled: false,
      isLoading: false
    };
    this.clickClose = this.clickClose.bind(this);
    this.increaseNight = this.increaseNight.bind(this);
    this.decreaseNight = this.decreaseNight.bind(this);
    this.increaseNight = this.increaseNight.bind(this);
    this.deleteCity = this.deleteCity.bind(this);
    this.addCity = this.addCity.bind(this);
    this.replaceCity = this.replaceCity.bind(this);
    this.openEditCityModalReplace = this.openEditCityModalReplace.bind(this);
    this.openEditCityModalAdd = this.openEditCityModalAdd.bind(this);
    this.closeEditCityModal = this.closeEditCityModal.bind(this);
    this.applyChanges = this.applyChanges.bind(this);
    this.updateRemovableInfo = this.updateRemovableInfo.bind(this);
    this.enableApplyButton = this.enableApplyButton.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.disableApplyButton = this.disableApplyButton.bind(this);
    this.enableApplyButton = this.enableApplyButton.bind(this);
    this.enableApplyButtonByDOM = this.enableApplyButtonByDOM.bind(this);
    this.disableApplyButtonByDOM = this.disableApplyButtonByDOM.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (!this.state.cities && nextProps.itineraryInfo) {
      this.setState({
        cities: nextProps.itineraryInfo.iterCities
      });
    }
  }

  openEditCityModalReplace(cityToReplace, options) {
    this.setState({
      isEditCityVisible: true,
      editCityMode: 'change',
      cityToReplace,
      editCityOptions: options
    });
  }

  openEditCityModalAdd(options) {
    this.setState({
      isEditCityVisible: true,
      editCityMode: 'add',
      editCityOptions: options
    });
  }

  closeEditCityModal() {
    this.setState(
      {
        isEditCityClosing: true
      },
      () => {
        this.setState({
          isEditCityVisible: false,
          isEditCityClosing: false
        });
      }
    );
  }

  addCity(previousIndex, newCity) {
    const newCitiesObject = this.state.cities.map(city => {
      return { ...city };
    });
    newCity.nights = newCity.idealNights;
    newCitiesObject.splice(previousIndex, 0, newCity);

    this.setState(
      {
        cities: newCitiesObject
      },
      () => {
        this.updateRemovableInfo();
        this.enableApplyButton();
      }
    );
  }

  replaceCity(index, newCity) {
    const newCitiesObject = this.state.cities.map(city => {
      return { ...city };
    });
    newCity.nights = newCitiesObject[index].nights;
    newCitiesObject[index] = newCity;
    this.setState(
      {
        cities: newCitiesObject
      },
      () => {
        this.updateRemovableInfo();
        this.enableApplyButton();
      }
    );
  }

  decreaseNight(index) {
    const newCitiesObject = this.state.cities.map(city => {
      return { ...city };
    });
    newCitiesObject[index].nights--;
    this.setState({
      cities: newCitiesObject
    });
    this.enableApplyButton();
  }

  increaseNight(index) {
    const newCitiesObject = this.state.cities.map(city => {
      return { ...city };
    });
    newCitiesObject[index].nights++;
    this.setState({
      cities: newCitiesObject
    });
    this.enableApplyButton();
  }

  deleteCity(index) {
    this.setState({
      isRemoveConfirmationVisible: false
    });

    const newCitiesObject = this.state.cities.map(city => {
      return { ...city };
    });
    newCitiesObject.splice(index, 1);
    const url = `${AppConfig.api_url}city/options/remove`;
    const request = {
      cities: newCitiesObject.map(city => city.cityId)
    };

    this.setState({
      isRemoveCityLoading: true
    });

    axios
      .post(url, request)
      .then(response => {
        this.props.updateEditableDetails(response.data);

        this.setState({
          cities: newCitiesObject,
          isRemoveCityLoading: false
        });
      })
      .catch(err => {
        this.setState({
          isRemoveCityLoading: false
        });
        console.error(err);
      });
    this.enableApplyButton();
  }

  updateRemovableInfo() {
    const url = `${AppConfig.api_url}city/options/remove`;
    const request = {
      cities: this.state.cities.map(city => city.cityId)
    };

    this.setState({
      isRemoveCityLoading: true
    });

    axios
      .post(url, request)
      .then(response => {
        this.props.updateEditableDetails(response.data);

        this.setState({
          isRemoveCityLoading: false
        });
      })
      .catch(err => {
        this.setState({
          isRemoveCityLoading: false
        });
        console.error(err);
      });
  }

  clickClose(isCloseButton) {
    const { history, itineraryInfo } = this.props;
    const { itineraryId, regionCode } = itineraryInfo.itinerary;

    isCloseButton && trackEvent(EVENT_ITINERARY_MODIFIED, {
      trip_edited: false	
    });

    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode
      })
    );
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.clickClose(true);
  }

  enableApplyButton() {
    this.setState({
      isApplyChangesEnabled: true
    });
  }

  enableApplyButtonByDOM() {
    let aplBtn = document.querySelector('.edit-trip-apply-changes-btn');
    aplBtn.classList.remove('disabled');
    aplBtn.disabled = false;
  }

  disableApplyButton() {
    this.setState({
      isApplyChangesEnabled: false
    });
  }

  disableApplyButtonByDOM() {
    let aplBtn = document.querySelector('.edit-trip-apply-changes-btn');
    aplBtn.classList.add('disabled');
    aplBtn.disabled = true;
  }

  componentDidMount() {
    this.setState(
      {
        modalClass: 'in',
        cities: this.props.itineraryInfo && this.props.itineraryInfo.iterCities
      },
      () => {
        this.props.itineraryInfo && this.updateRemovableInfo();
      }
    );

    onceModalOpened();

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    onceModalClosed();

    document.removeEventListener('keyup', this.handleKeyUp);
  }

  applyChanges() {
    this.setState(
      {
        isLoading: true
      },
      () => {
        const requestData = {
          itineraryId: this.props.itineraryInfo.itinerary.itineraryId,
          cities: this.state.cities.map(city => city.cityId),
          nights: this.state.cities.map(city => city.nights)
        };

        trackEvent(EVENT_ITINERARY_MODIFIED, {	
          trip_edited: true
        });

        this.props
          .editCityModalApplyChanges(requestData.itineraryId, requestData)
          .then(() => {
            this.setState({ isLoading: false });
            this.clickClose();
          })
          .catch(() => {
            this.setState({ isLoading: false });
            this.clickClose();
          });
      }
    );
  }

  render() {
    let { itineraryInfo, history } = this.props;
    let itineraryDetail = itineraryInfo && itineraryInfo.itinerary;

    let { isLoading } = this.state;
    let applyChangesBtnClass = classNames(
      'pull-right btn btn-primary tracking-apply-changes edit-trip-apply-changes-btn',
      {
        'progress-btn': isLoading
      }
    );
    const addCityStart = event => {
      event.preventDefault();
      const options = {
        entry: true,
        exit: false,
        previousCityId: 0,
        previousCityIndex: 0,
        nextCityId: this.state.cities[0].cityId,
        region: itineraryDetail.regionCode,
        interests: itineraryDetail.interests,
        citiesInItinerary: this.state.cities.map(city => city.cityId)
      };
      this.openEditCityModalAdd(options);
    };

    const addCityEnd = event => {
      event.preventDefault();
      const options = {
        entry: false,
        exit: true,
        previousCityId: this.state.cities[this.state.cities.length - 1].cityId,
        previousCityIndex: this.state.cities.length,
        nextCityId: 0,
        region: itineraryDetail.regionCode,
        interests: itineraryDetail.interests,
        citiesInItinerary: this.state.cities.map(city => city.cityId)
      };
      this.openEditCityModalAdd(options);
    };

    const removeCityInfo = this.props.removeCityInfo
      ? [...this.props.removeCityInfo]
      : [];

    return (
      <div
        className={`edit-trip modal-sticky-footer modal fade ${
          this.state.modalClass
        }`}
      >
        <div className="modal-dialog">
          {/*<div className="modal-bg" />*/}

          <SweetAlert
            show={this.state.isRemoveConfirmationVisible}
            title="Are you sure you want to remove this city from the Itinerary?"
            text={`You can always add the city later using add city options.`}
            onConfirm={() => this.deleteCity(this.state.cityToDelete)}
            showCancelButton
            animation="pop"
            confirmButtonText="Yup! Remove City from Itinerary."
            onEscapeKey={() =>
              this.setState({ isRemoveConfirmationVisible: false })
            }
            onCancel={() =>
              this.setState({ isRemoveConfirmationVisible: false })
            }
            onOutsideClick={() =>
              this.setState({ isRemoveConfirmationVisible: false })
            }
          />

          <div className="modal-content with-footer">
            <div className="modal-body">
              <div className="modal-body-">
                {this.state.isEditCityVisible ? (
                  <div className={'edit-trip-search'}>
                    <EditTripCity
                      disableApplyButtonByDOM={this.disableApplyButtonByDOM}
                      enableApplyButtonByDOM={this.enableApplyButtonByDOM}
                      isClosing={this.state.isEditCityClosing}
                      closeModal={this.closeEditCityModal}
                      editCityMode={this.state.editCityMode}
                      itineraryId={itineraryDetail.itineraryId}
                      cityToReplace={this.state.cityToReplace}
                      editCityOptions={this.state.editCityOptions}
                      addCity={this.addCity}
                      replaceCity={this.replaceCity}
                      citySelectedToReplace={this.state.citySelectedToReplace}
                    />
                  </div>
                ) : (
                  <div className={'row'}>
                    <div className={'col-xs-12'}>
                      <h4>Edit trip</h4>
                      <section className="clearfix title-hdr">
                        <span className="pull-left col-left">Route</span>
                        <span className="pull-left col-right">#Nights</span>
                        <span className="pull-left col-right">Replace</span>
                        <span className="pull-left col-right">Remove</span>
                      </section>

                      <div className="pull-left fw route-timeline">
                        <section className="clearfix fw">
                          <div className="pull-left fw transfer-txt pt-0 trans-add-first">
                            <a
                              href="#"
                              onClick={addCityStart}
                              className={'tracking-add-new-city'}
                            >
                              Add new city
                            </a>
                          </div>
                        </section>

                        {/* ROUTE INFO STARTS */}
                        {this.state.cities &&
                          this.state.cities.map((city, index) => {
                            const decreaseNight = event => {
                              event.preventDefault();
                              this.decreaseNight(index);
                            };

                            const increaseNight = event => {
                              event.preventDefault();
                              this.increaseNight(index);
                            };

                            const deleteCity = event => {
                              event.preventDefault();
                              this.setState(
                                {
                                  cityToDelete: index
                                  // isRemoveConfirmationVisible: true,  // confirmation not needed
                                },
                                () => {
                                  this.deleteCity(this.state.cityToDelete);
                                }
                              );
                            };

                            const replaceCity = event => {
                              event.preventDefault();
                              this.setState({
                                citySelectedToReplace: city
                              });
                              const options = {
                                entry: index === 0,
                                exit: index === this.state.cities.length - 1,
                                currentCityId: city.cityId,
                                previousCityId:
                                  index > 0
                                    ? this.state.cities[index - 1].cityId
                                    : 0,
                                nextCityId:
                                  index < this.state.cities.length - 1
                                    ? this.state.cities[index + 1].cityId
                                    : 0,
                                replaceIndex: index,
                                region: itineraryDetail.regionCode,
                                interests: itineraryDetail.interests,
                                citiesInItinerary: this.state.cities.map(
                                  city => city.cityId
                                )
                              };
                              this.openEditCityModalReplace(
                                city.cityId,
                                options
                              );
                            };

                            const removableInfo = _.find(removeCityInfo, {
                              cityId: city.cityId
                            });

                            const removableInfoIndex = _.findIndex(
                              removeCityInfo,
                              {
                                cityId: city.cityId
                              }
                            );

                            removeCityInfo.splice(removableInfoIndex, 1);

                            const addCity = event => {
                              event.preventDefault();
                              const options = {
                                entry: false,
                                exit: false,
                                previousCityId: this.state.cities[index].cityId,
                                nextCityId:
                                  index < this.state.cities.length - 1
                                    ? this.state.cities[index + 1].cityId
                                    : 0,
                                previousCityIndex: index + 1,
                                region: itineraryDetail.regionCode,
                                interests: itineraryDetail.interests,
                                citiesInItinerary: this.state.cities.map(
                                  city => city.cityId
                                )
                              };
                              this.openEditCityModalAdd(options);
                            };

                            return (
                              <section className="clearfix fw" key={index}>
                                <div className="pull-left fw bg-content">
                                  <h5 className="pull-left col-left">
                                    {city.cityName}
                                  </h5>
                                  <ul className="pull-left col-right-2">
                                    <li>
                                      <i className="dim">#Nights</i>
                                      <div className="plusminus-width">
                                        {city.nights > 1 ? (
                                          <a
                                            href="#"
                                            onClick={decreaseNight}
                                            className="vehoicon-minus3 tracking-decrease-night"
                                          />
                                        ) : null}
                                      </div>
                                      <span>{city.nights}</span>
                                      <div className="plusminus-width">
                                        <a
                                          href="#"
                                          onClick={increaseNight}
                                          className="vehoicon-plus3 tracking-increase-night"
                                        />
                                      </div>
                                    </li>
                                    <li>
                                      <i className="dim">Replace</i>
                                      <a
                                        href="#"
                                        onClick={replaceCity}
                                        className="fs-20 vehoicon-shuffle tracking-replace-city"
                                      />
                                    </li>
                                    {removableInfo &&
                                    removableInfo.canRemove ? (
                                      <li>
                                        <i className="dim">Remove</i>
                                        <a
                                          href="#"
                                          className="fs-20 vehoicon-delete fade tracking-remove-city"
                                          onClick={deleteCity}
                                        />
                                      </li>
                                    ) : (
                                      <li>
                                        <i className="dim">Remove</i>
                                        <a
                                          href="#"
                                          className="fs-20 vehoicon-delete fade remove-disabled-clr tracking-remove-city-disabled"
                                          onClick={e => e.preventDefault()}
                                        />
                                      </li>
                                    )}
                                  </ul>
                                </div>
                                {index !== this.state.cities.length - 1 ? (
                                  <div className="pull-left fw transfer-txt">
                                    <a
                                      href={'#'}
                                      onClick={addCity}
                                      className={'tracking-add-new-city'}
                                    >
                                      Add new city
                                    </a>
                                  </div>
                                ) : null}
                              </section>
                            );
                          })}
                        {/* ROUTE INFO ENDS */}
                        <section className="clearfix fw">
                          <div className="pull-left fw transfer-txt pb-0">
                            <a
                              href="#"
                              onClick={addCityEnd}
                              className={'tracking-add-new-city'}
                            >
                              Add new city
                            </a>
                          </div>
                        </section>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="modal-footer hidden-xs">
              <button
                className="pull-left btn close tracking-close-edit-trip"
                data-dismiss="modal"
                tabIndex={-1}
                onClick={() => this.clickClose(true)}
              >
                <i className="vehoicon-close" />
              </button>

              {this.state.isApplyChangesEnabled ? (
                <button
                  className={applyChangesBtnClass}
                  onClick={this.applyChanges}
                >
                  {isLoading ? <span className={'progress-bg'} /> : null}
                  <span className={'btn-txt'}>Apply Changes</span>
                </button>
              ) : (
                <button
                  className={applyChangesBtnClass}
                  onClick={this.clickClose}
                >
                  {isLoading ? <span className={'progress-bg'} /> : null}
                  <span className={'btn-txt'}>Apply Changes</span>
                </button>
              )}
            </div>
          </div>

          {/* MOBILE FOOTER STARTS */}
          <div className="modal-footer modal-footer-mobile text-right visible-xs">
            <button
              className="btn pull-left close tracking-close-edit-trip"
              tabIndex={-1}
              onClick={() => this.clickClose(true)}
            >
              <span className="vehoicon-close" />
            </button>
            {this.state.isApplyChangesEnabled ? (
              <button
                className={applyChangesBtnClass}
                onClick={this.applyChanges}
              >
                {isLoading ? <span className={'progress-bg'} /> : null}
                <span className={'btn-txt'}>Apply Changes</span>
              </button>
            ) : (
              <button
                className={applyChangesBtnClass}
                onClick={this.clickClose}
              >
                {isLoading ? <span className={'progress-bg'} /> : null}
                <span className={'btn-txt'}>Apply Changes</span>
              </button>
            )}
          </div>
          {/* MOBILE FOOTER ENDS */}
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  return {
    itineraryInfo: app.itineraryInfo.itineraryDetails,
    user_details: app.user_details,
    removeCityInfo: app.removeCityInfo
  };
};

const mapDispatchToProps = dispatch => {
  return {
    editCityModalApplyChanges: bindActionCreators(
      editCityModalApplyChanges,
      dispatch
    ),
    updateEditableDetails: bindActionCreators(updateEditableDetails, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(EditTrip);
