import React, { Component } from 'react';
import Loader from '../../common_components/Loader';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { triggerSimpleAjax } from '../../helpers/httpHelper';

import { AppConfig } from '../../app-config';
import { bindActionCreators } from 'redux';
import { getUserDetails } from '../../actions/actions_app';
const API_URL = AppConfig.api_url;

class MagicItinerary extends Component {
  componentDidMount() {
    let { history, match } = this.props;

    let url = `${API_URL}itinerary/view/${match.params.hash}`;
    triggerSimpleAjax(
      url,
      'GET',
      {},
      response => {
        // console.log(response);
        this.props.getUserDetails();

        history.replace(`/customize/region/view/${response.data}`);
      },
      error => {
        console.error(error);

        history.replace('/404');
      }
    );
  }

  render() {
    return (
      <div>
        <Loader />
      </div>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  return { ...app };
}

function mapDispatchToProps(dispatch) {
  return {
    getUserDetails: bindActionCreators(getUserDetails, dispatch)
  };
}

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(MagicItinerary)
);
