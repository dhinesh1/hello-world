import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import axios from 'axios';

import PriceDiff from '../../common_components/price_diff';
import { updateFerry } from '../../actions/actions_app';

import { AppConfig } from '../../app-config';
import {
    decodeCostingKeyFromURL,
    onceModalClosed,
    onceModalOpened,
    getImgIXUrl
} from '../../helpers/utilsHelper';
import {itineraryModalsRouteHelper, routingPageType} from '../../helpers/routesHelper';

const API_URL = AppConfig.api_url;
const IMAGE_CDN = AppConfig.images_cdn_misc_url;
/*global swal */

class AlternateFerriesModal extends Component {
    constructor(props) {
        super(props);

        this.state = {
            showModal: false,
            activeFerryDetails: {},
            componentStatus: 'IDLE',
            alternateFerries: []
        };

        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.getAlternateFerries = this.getAlternateFerries.bind(this);
        this.handleReplaceButtonClick = this.handleReplaceButtonClick.bind(this);
        this.renderAlternateLength = this.renderAlternateLength.bind(this);
        this.handleKeyUp = this.handleKeyUp.bind(this);

        this.getCurrentDetails = this.getCurrentDetails.bind(this);
    }

    componentDidMount() {
        this.openModal();

        this.getCurrentDetails(this.props);
        document.addEventListener('keyup', this.handleKeyUp);
    }

    componentWillUnmount() {
        document.removeEventListener('keyup', this.handleKeyUp);
    }
    componentWillReceiveProps(props) {
        this.getCurrentDetails(props);
    }

    getCurrentDetails(props) {
        if (
            props.itineraryInfo &&
            Object.keys(props.itineraryInfo).length &&
            props.itineraryInfo.trainCostings &&
            !Object.keys(this.state.activeFerryDetails).length
        ) {
            let { match } = this.props;
            let { itineraryInfo, itineraryDetail } = props;
            let currentKey = match.params.ferryKey;
            currentKey = decodeCostingKeyFromURL(currentKey);

            let currentDetail = itineraryInfo && itineraryInfo.ferryCostings &&
                itineraryInfo.ferryCostings.ferryCostingById[currentKey];

            if (!currentDetail) {
                this.closeModal();
            }

            this.setState({ activeFerryDetails: currentDetail }, () => {
                let reqData = {
                    itineraryId: itineraryDetail.itineraryId,
                    costingKey: currentKey,
                };

                this.getAlternateFerries(reqData);
            });
        }
    }

    getAlternateFerries(data) {
        const url = `${API_URL}itinerary/alternateFerries`;
        axios
            .post(url, data)
            .then(response => {
                this.setState({
                    alternateFerries: response.data.data,
                    showModal: true
                });
            })
            .catch(e => {
                console.warn(e);

                swal({
                    title: 'Sorry about this!',
                    text:
                        'Sorry about this. But there seems to be an issue with Pickyourtrail.',
                    animation: true,
                    showCancelButton: false,
                    confirmButtonColor: '#DD6B55',
                    confirmButtonText: 'Try again!',
                    cancelButtonText: 'No, cancel!',
                    closeOnConfirm: true,
                    closeOnCancel: true
                });
            });
    }

    handleReplaceButtonClick(newFerry) {
        this.props
            .updateFerry({
                itineraryId: this.props.itineraryDetail.itineraryId,
                costingKey: this.state.activeFerryDetails.key,
                newTransferId: newFerry.transferId,
            })
            .then(() => {
                this.closeModal(true);
            })
            .catch(() => {
                this.closeModal(true);
            });
    }

    handleKeyUp(e) {
        if (e.keyCode === 27) this.closeModal();
    }

    openModal() {
        this.setState({ showModal: true }, () => {
            onceModalOpened();
        });
    }

    closeModal(replace = false) {
        let { history, match, itineraryDetail } = this.props;

        setTimeout(() => {
            this.setState({ showModal: false }, () => {
                onceModalClosed();

                const inclusionsPagePath = itineraryModalsRouteHelper({
                    itineraryId: itineraryDetail.itineraryId,
                    regionCode: itineraryDetail.regionCode,
                    parentPage: routingPageType.inclusion
                })

                if (replace) {
                    history.replace(inclusionsPagePath);
                } else {
                    history.push(inclusionsPagePath);
                }
            });
        }, 400);
    }

    renderAlternateLength() {
        if (this.state.alternateFerries && this.state.alternateFerries.length > 0) {
            return (
                <span className="mini block dim bold text-center spacer">
                    {this.state.alternateFerries.length} available options to choose from
        </span>
            );
        }
    }

    render() {
        let { activeFerryDetails, showModal, alternateFerries } = this.state;

        return (
            <div
                tabIndex="0"
                className={
                    'modal fade alternate-modal auto-width modal-sticky-header ' +
                    (showModal ? 'in' : '')
                }
            >
                <div className={'modal-dialog'}>
                    <div className={'modal-content with-header'}>
                        <ModalHeaderNew
                            splitPricing={this.props.itineraryDetail.splitPricing}
                            {...activeFerryDetails}
                            onClose={this.closeModal}
                        />

                        <div className="modal-body">
                            <div className="current-pick-panel">
                                <div className="current-pick-content hotel">
                                    <div className="col-xs-9 col-md-10">
                                        <span className="single-line-text fade small no-margin">
                                            Changing: {activeFerryDetails.pickup} -{' '}
                                            {activeFerryDetails.drop}
                                        </span>
                                    </div>
                                    {activeFerryDetails.publishedCost ? (
                                        <div className="col-xs-3 col-md-2 text-right">
                                            {!activeFerryDetails.inCombo ? (
                                                <span className="total-price small bold dim">
                                                    <span className="WebRupee">Rs.</span>{' '}
                                                    {activeFerryDetails.publishedCost}
                                                </span>
                                            ) : (
                                                    <span className="in-combo for-current-pick">
                                                        IN COMBO
                        </span>
                                                )}
                                        </div>
                                    ) : null}
                                </div>
                            </div>

                            <div className="modal-row">
                                {alternateFerries && alternateFerries.length > 0
                                    ? this.renderAlternateLength()
                                    : null}
                                <section className="change-data flat-list">
                                    {alternateFerries &&
                                        alternateFerries.length > 0 &&
                                        alternateFerries.map(ferry => (
                                            <FerryOption
                                                key={activeFerryDetails.key + ferry.trainId}
                                                {...ferry}
                                                splitPricing={this.props.itineraryDetail.splitPricing}
                                                handleReplaceButtonClick={this.handleReplaceButtonClick}
                                            />
                                        ))}
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const ModalHeaderNew = props => {
    return (
        <div className="modal-header">
            <button
                type="button"
                onClick={props.onClose}
                className="close"
                aria-label="Close"
            >
                <span className="vehoicon-close" aria-hidden="true" />
            </button>
            <span className="text-uppercase kern-more bolder fade">Change Ferry</span>
        </div>
    );
};

const FerryOption = props => {
    return (
        <article
            className="data-option-item zoomable"
        >
            <div className="data-option-item-wrapper">
                <div className="col-xs-9 col-sm-10 col-md-10 no-padding">
                    <div className="col-xs-12 col-sm-12 col-md-12">
                        <div className="row spacer-both">
                            <div className="col-xs-3 col-sm-3 col-md-3">
                                <div className="media-shell">
                                    <figure className="hd">
                                        <img
                                            src={props.image || getImgIXUrl(`${IMAGE_CDN}ferry.jpg`, 'w=150&h=100')}
                                        />
                                    </figure>
                                </div>
                            </div>
                            <div className="col-xs-9 col-sm-9 col-md-9 flight-cell">
                                <div className="hidden-xs col-sm-6 col-md-5 no-padding">
                                    <time className="block">{props.departureTime}</time>
                                    <span className="mini single-line-text dim">
                                        {props.pickup}
                                    </span>
                                </div>
                                <div className="hidden-xs col-sm-6 col-md-5">
                                    <time className="block">{props.arrivalTime}</time>
                                    <span className="mini single-line-text dim">
                                        {props.drop}
                                    </span>
                                    <span className="mini single-line-text dim">
                                        {props.duration}
                                    </span>
                                </div>
                                <div className="col-xs-12 hidden-sm hidden-md hidden-lg flight-cell">
                                    <time className="block">
                                        {props.departureTime}—{props.arrivalTime}
                                    </time>
                                    <span className="mini single-line-text dim">
                                        {props.pickup} - {props.drop}
                                    </span>
                                    <span className="mini single-line-text dim">
                                        {props.duration}, {props.stops}
                                    </span>
                                </div>
                                <div className="icon-attributes">
                                    <span className="vehoicon-non-refundable" />
                                    {/*<span className="seats">10</span>*/}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-xs-3 col-sm-2 col-md-2 spacer-both no-padding">
                    <div className="action price-info text-center">
                        {props.cost ? (
                            <span className="price block">
                                <span className="WebRupee">Rs.</span>
                                {props.cost}
                            </span>
                        ) : null}
                        {props.diffDetail && props.diffDetail.diffCost >= 0 ? (
                            <PriceDiff diff={props.diffDetail} classNames={'price block'} />
                        ) : null}
                        <a
                            className="btn btn-xs btn-primary hidden-sm hidden-xs"
                            onClick={e => {
                                e.preventDefault();
                                e.stopPropagation();
                                e.nativeEvent.stopImmediatePropagation();
                                props.handleReplaceButtonClick(props);
                            }}
                        >
                            Choose
            </a>
                        <a
                            className="btn btn-sm btn-primary show-xs-sm"
                            onClick={e => {
                                e.preventDefault();
                                e.stopPropagation();
                                e.nativeEvent.stopImmediatePropagation();
                                props.handleReplaceButtonClick(props);
                            }}
                        >
                            Choose
            </a>
                    </div>
                </div>
            </div>
        </article>
    );
};

const mapStateToProps = state => {
    let app = state.app;

    if (
        app.itineraryInfo.itineraryDetails &&
        Object.keys(app.itineraryInfo.itineraryDetails).length
    ) {
        return {
            itineraryInfo: app.itineraryInfo.itineraryDetails,
            itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
            user_details: app.user_details,
            adult_count: app.itineraryInfo.adult_count,
            child_count: app.itineraryInfo.child_count
        };
    } else {
        return {
            itineraryInfo: app.itineraryInfo.itineraryDetails,
            itineraryDetail: {},
            user_details: app.user_details
        };
    }
};

const mapDispatchToProps = dispatch => {
    return {
        updateFerry: bindActionCreators(updateFerry, dispatch)
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(AlternateFerriesModal);
