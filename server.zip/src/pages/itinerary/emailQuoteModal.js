import React, {Component, Fragment} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {sendEmailQuote, dissolveEmailSent} from '../../actions/actions_app';
import {
  EditorState,
  RichUtils,
  convertToRaw,
  convertFromRaw,
  AtomicBlockUtils
} from 'draft-js';
import Editor from 'draft-js-plugins-editor';
import {BQ, Bold, Italic, OL, UL, UnderLine} from './constants/icons';
import {stateToHTML} from 'draft-js-export-html';
import SweetAlert from 'sweetalert-react';
import classNames from 'classnames';
// import RichTextEditor from 'react-rte';
import {onceModalClosed, onceModalOpened} from '../../helpers/utilsHelper';
import createImagePlugin from 'draft-js-image-plugin';
import {
  itineraryModalsRouteHelper,
  routingPageType
} from '../../helpers/routesHelper';

const imagePlugin = createImagePlugin();
const plugins = [imagePlugin];
class EmailQuoteAdmin extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      ccList: '',
      subject: '',
      editorState: EditorState.createEmpty(),
      showAlert: false,
      formSubmitted: false,
      validation: {
        subjectValid: true,
        notesValid: true,
        isFormValid: true
      },
      travelerType: props.travellerInfo.type || '',
      purposeOfTravel: props.travellerInfo.travelPurpose || '',
      purposeOfTravelVisible: props.travellerInfo.type ? true : false,
      mealPreferences: props.travellerInfo.details || ''
      // editorStateNew: RichTextEditor.createEmptyValue(),
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
    this.inputChangeHandler = this.inputChangeHandler.bind(this);

    this.focus = () => this.refs.editor.focus();
    // this.onChangeNew = (editorStateNew) => this.setState({editorStateNew});

    this.handleKeyCommand = command => this._handleKeyCommand(command);
    this.onTab = e => this._onTab(e);
    this.toggleBlockType = type => this._toggleBlockType(type);
    this.toggleInlineStyle = style => this._toggleInlineStyle(style);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.autoFillDetails = this.autoFillDetails.bind(this);

    this.inputTripDetails = this.inputTripDetails.bind(this);
  }

  onChange = editorState => {
    this.setState({editorState}, () => {
      this.validationForm();
    });
  };

  componentDidMount() {
    this.openModal();
    this.autoFillDetails(this.props);
    document.addEventListener('keyup', this.handleKeyUp);
    document.addEventListener('paste', this.pasteAndUploadImage);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
    document.removeEventListener('paste', this.pasteAndUploadImage);
  }

  validationForm = () => {
    if (this.state.formSubmitted) {
      /**
       * if we enable the planner notes is mandatory need to uncomment the below codes
       */
      // let contentState = this.state.editorState.getCurrentContent();
      // let plannerNotes = JSON.parse(JSON.stringify(convertToRaw(contentState)));
      // let notes = '';
      // if (plannerNotes.blocks && plannerNotes.blocks[0]) {
      //   notes = plannerNotes.blocks[0].text;
      // }
      let validation = this.state.validation;
      validation.subjectValid = (this.state.subject || '').trim().length > 0;
      validation.notesValid = true; //(notes || '').trim().length > 0;
      validation.isFormValid = validation.subjectValid && validation.notesValid;
      this.setState(validation);
    }
  };

  insertImage = (editorState, base64) => {
    const contentState = editorState.getCurrentContent();
    const contentStateWithEntity = contentState.createEntity(
      'image',
      'IMMUTABLE',
      {src: base64}
    );
    const entityKey = contentStateWithEntity.getLastCreatedEntityKey();
    const newEditorState = EditorState.set(editorState, {
      currentContent: contentStateWithEntity
    });
    return AtomicBlockUtils.insertAtomicBlock(newEditorState, entityKey, ' ');
  };

  /**
   * Callback function for the image to base 64 convert and clipboard action
   */
  retrieveImageFromClipboardAsBlob = (pasteEvent, callback) => {
    if (pasteEvent.clipboardData == false) {
      if (typeof callback == 'function') {
        callback(undefined);
      }
    }

    let items = pasteEvent.clipboardData.items;

    if (items == undefined) {
      if (typeof callback == 'function') {
        callback(undefined);
      }
    }

    for (let i = 0; i < items.length; i++) {
      // Skip content if not image
      if (items[i].type.indexOf('image') == -1) continue;
      // Retrieve image on clipboard as blob
      let blob = items[i].getAsFile();

      if (typeof callback == 'function') {
        callback(blob);
      }
    }
  };
  /**
   * This function will trigger when pate the elment in document
   */
  pasteAndUploadImage = event => {
    const _this = this;
    if (!this.state.isFocused) {
      return null;
    }
    this.retrieveImageFromClipboardAsBlob(event, imageBlob => {
      // If there's an image, display it in the canvas
      if (imageBlob) {
        const canvas = document.createElement('canvas');
        let ctx = canvas.getContext('2d');

        // Create an image to render the blob on the canvas
        let img = new Image();
        let base64;

        // Once the image loads, render the img on the canvas
        img.onload = function() {
          // Update dimensions of the canvas with the dimensions of the image
          canvas.width = this.width;
          canvas.height = this.height;

          // Draw the image
          ctx.drawImage(img, 0, 0);

          base64 = canvas.toDataURL('image/png');

          const newEditorState = _this.insertImage(
            _this.state.editorState,
            base64
          );
          _this.setState({editorState: newEditorState});
        };

        // Crossbrowser support for URL
        let URLObj = window.URL || window.webkitURL;

        // Creates a DOMString containing a URL representing the object given in the parameter
        // namely the original Blob
        img.src = URLObj.createObjectURL(imageBlob);
      }
    });
  };

  autoFillDetails(props) {
    let local_shareItinerary = JSON.parse(
      localStorage.getItem('shareEmailQuote')
    );
    if (
      local_shareItinerary &&
      local_shareItinerary.data.itineraryId ===
        this.props.match.params.itineraryId
    ) {
      let edit = EditorState.createWithContent(
        convertFromRaw(JSON.parse(local_shareItinerary.data.plannerNotes))
      );
      this.setState({
        ccList: local_shareItinerary.data.ccList,
        subject: local_shareItinerary.data.subject,
        editorState: edit
      });
    } else {
      /** Store the empty share email quote details */
      localStorage.setItem(
        'shareEmailQuote',
        JSON.stringify({
          data: {}
        })
      );
    }
  }

  openModal() {
    this.setState({showModal: true, deleteActivity: false}, () => {
      onceModalOpened();
    });
  }

  closeModal() {
    let {history, location, match} = this.props;

    this.setState({showModal: false, deleteActivity: false}, () => {
      onceModalClosed();

      history.push(
        itineraryModalsRouteHelper({
          itineraryId: match.params.itineraryId,
          regionCode: match.params.searchRegion,
          location
        })
      );
    });
  }

  handleKeyUp(e) {
    let {userDetails} = this.props;
    let _this = this,
      email_value = userDetails.email,
      {ccList, editorState, subject} = this.state;
    let contentState = editorState.getCurrentContent();
    let data = {
      itineraryId: this.props.match.params.itineraryId,
      email: email_value,
      ccList: ccList,
      subject: subject,
      plannerNotes: JSON.stringify(convertToRaw(contentState))
    };
    /** Store the current share email quote details */
    localStorage.setItem(
      'shareEmailQuote',
      JSON.stringify({
        data: data
      })
    );
    if (e.keyCode === 27) this.closeModal();
  }

  _handleKeyCommand(command) {
    const {editorState} = this.state;
    const newState = RichUtils.handleKeyCommand(editorState, command);
    if (newState) {
      this.onChange(newState);
      return true;
    }
    return false;
  }

  _onTab(e) {
    const maxDepth = 4;
    this.onChange(RichUtils.onTab(e, this.state.editorState, maxDepth));
  }

  _toggleBlockType(blockType) {
    this.onChange(
      RichUtils.toggleBlockType(this.state.editorState, blockType)
    );
  }

  _toggleInlineStyle(inlineStyle) {
    this.onChange(
      RichUtils.toggleInlineStyle(this.state.editorState, inlineStyle)
    );
  }

  submitHandler() {
    this.setState(
      {
        formSubmitted: true
      },
      () => {
        this.validationForm();
        if (this.state.validation.isFormValid) {
          let { userDetails, costedItinerary } = this.props;

          let _this = this,
            email_value = userDetails.email,
            // itineraryId = costedItinerary.itinerary.itineraryId,
            {
              ccList,
              editorState,
              subject,
              travelerType,
              purposeOfTravel,
              mealPreferences,
            } = this.state;

          // let url = `${API_URL}cost/${itineraryId}/emailQuote`;
          let post_data = {
            itineraryId: this.props.match.params.itineraryId,
            email: email_value,
            ccList: ccList,
            travellerInfo:{
              type: travelerType,
              travelPurpose: purposeOfTravel,
              details: mealPreferences
            },
            subject: subject,
            plannerNotes: stateToHTML(editorState.getCurrentContent())
            // "plannerNotes": editorStateNew.toString('html')
          };

          this.props.actions
            .sendEmailQuote(post_data)
            .then(() => {
              // this.setState({showEmailQuoteAlert: true});
            })
            .catch(() => {
              // this.setState({showAlert: true})
            });
        }
      }
    );
  }

  inputChangeHandler(event) {
    this.setState(
      {
        [event.target.name]: event.target.value
      },
      () => {
        this.validationForm();
      }
    );
  }
  inputTripDetails (event) {
    if(event.target.name === "travelerType"){
      if(event.target.value === "COUPLES"){
        this.setState({travelerType:event.target.value,purposeOfTravel:'',purposeOfTravelVisible:true})
      }else{
        this.setState({travelerType:event.target.value,purposeOfTravel:event.target.value,purposeOfTravelVisible:false})
      }
    }else{
      this.setState({[event.target.name]:event.target.value})
    }
  }
  updateMealPreference = (preference) => {
    this.setState({
      mealPreferences: preference
    })
  }
  render () {
    if (this.props.emailSent && this.props.emailSent.emailSent !== 'failure') {
      this.props.actions.dissolveEmailSent();
      this.setState({
        showEmailQuoteAlert: true,
        emailQuoteResponse: this.props.emailSent.message
      });
    } else if (
      this.props.emailSent &&
      this.props.emailSent.emailSent === 'failure'
    ) {
      this.props.actions.dissolveEmailSent();

      this.setState({showAlert: true});
    }

    const {editorState} = this.state;
    // If the user changes block type before entering any text, we can
    // either style the placeholder or hide it. Let's just hide it now.
    let className = 'RichEditor-editor';
    let contentState = editorState.getCurrentContent();
    if (!contentState.hasText()) {
      if (contentState.getBlockMap().first().getType() !== 'unstyled') {
        className += ' RichEditor-hidePlaceholder';
      }
    }

    return (
      <div className="modal-open">
        <div
          className={
            'modal fade  modal-sticky-bars ' +
              (this.state.showModal ? 'in' : '')
          }
        >
          <div className="modal-dialog">
            <div className="modal-content with-sticky-bars">
              <div className="modal-header bg-primary vertical-center fade">
                <p className="fw text-center mb-0 caps-text">
                  Share email quote
                </p>
              </div>
              <div className="modal-body">
                <form>
                  <div className={'form-group'}>
                    <input
                      className="form-control"
                      type="text"
                      value={this.state.ccList}
                      onChange={this.inputChangeHandler}
                      name="ccList"
                      ref="ccList"
                      placeholder="CC email IDS (Comma separated)"
                    />
                  </div>
                  <div
                    className={classNames('form-group', {
                      'has-error': !this.state.validation.subjectValid
                    })}
                  >
                    <input
                      type="text"
                      className="form-control"
                      value={this.state.subject}
                      onChange={this.inputChangeHandler}
                      name="subject"
                      ref="subject"
                      placeholder="Please enter your subject"
                    />
                  </div>
                  <div>
                      <div className="row">
                        <div className={'col-sm-6 col-xs-12'}>
                          <div className="form-group">
                            <label className="control-label">
                              Traveler Type
                            </label>
                            <div className="custom-select">
                              <select
                                value={this.state.travelerType}
                                onChange={this.inputTripDetails}
                                className={'form-control '}
                                name="travelerType"
                                aria-hidden="true"
                              >
                                <option value={''}>---</option>
                                <option value={'SOLO'}>Solo</option>
                                <option value={'FRIENDS'}>Friends</option>
                                <option value={'FAMILY'}>Family</option>
                                <option value={'CO_WORKERS'}>Co-workers</option>
                                <option value={'COUPLES'}>Couples</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div className={'col-sm-6 col-xs-12'} style={{display: `${this.state.purposeOfTravelVisible ? 'inline' : 'none'}`}}>
                          <div className="form-group">
                            <label className="control-label">
                              Purpose of Travel
                            </label>
                            <div className="custom-select">
                              <select
                                value={this.state.purposeOfTravel}
                                onChange={this.inputTripDetails}
                                className={'form-control '}
                                name="purposeOfTravel"
                                aria-hidden="true"
                                
                              >
                                <option value={''}>---</option>
                                <option value={'ANNIVERSARY'}>
                                  Anniversary
                                </option>
                                <option value={'HONEYMOON'}>Honeymoon</option>
                                <option value={'BIRTHDAY'}>
                                  Birthday
                                </option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div className={'col-sm-6 col-xs-12'}>
                          <div className="form-group">
                            <p className="control-label">
                              Meal preferences{' '}
                            </p>
                            <div class="btn-group">
                              <button 
                                type="button" 
                                onClick={() => this.updateMealPreference('veg')}
                                class={`btn btn-default btn-outline btn-outline-bg btn-sm mealPreferences ${this.state.mealPreferences === 'veg' ? 'active' : ''}`}>Veg</button>
                              <button 
                                type="button" 
                                onClick={() => this.updateMealPreference('non-veg')}
                                class={`btn btn-default btn-outline btn-outline-bg btn-sm mealPreferences ${this.state.mealPreferences === 'non-veg' ? 'active' : ''}`}>Non-veg</button>
                            </div>

                          </div>
                        </div>
                      </div>

                    </div>
                  <div
                    className="RichEditor-root"
                    style={{
                      'min-height': '330px',
                      'border-color': this.state.validation.notesValid
                        ? '#ddd'
                        : '#f44336'
                    }}
                  >
                    <InlineStyleControls
                      editorState={editorState}
                      onToggle={this.toggleInlineStyle}
                    />
                    <BlockStyleControls
                      editorState={editorState}
                      onToggle={this.toggleBlockType}
                    />
                    <div className={className} onClick={this.focus}>
                      <Editor
                        blockStyleFn={getBlockStyle}
                        customStyleMap={styleMap}
                        editorState={editorState}
                        handleKeyCommand={this.handleKeyCommand}
                        onChange={this.onChange}
                        onTab={this.onTab}
                        placeholder="Planner's notes..."
                        ref="editor"
                        spellCheck={true}
                        plugins={plugins}
                        onFocus={() => {
                          this.setState({isFocused: true});
                        }}
                        onBlur={() => {
                          this.setState({isFocused: false});
                        }}
                      />
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="pull-left btn close"
                data-dismiss="modal"
                onClick={this.closeModal}
              >
                <i className="vehoicon-close" />
              </button>

              <button
                className="btn btn-primary pull-right"
                onClick={this.submitHandler}
              >
                Send email quote
              </button>
              {/* <button type="button" class="pull-right btn btn-primary btn-outline">Button</button> */}
            </div>
          </div>

          <SweetAlert
            show={this.state.showEmailQuoteAlert}
            title="Mail sent!"
            text={this.state.emailQuoteResponse}
            animation="pop"
            onConfirm={() =>
              this.setState({showEmailQuoteAlert: false}, () => {
                this.closeModal();
              })}
          />

          <SweetAlert
            show={this.state.showAlert}
            title="Sorry, unable to deliver the Email"
            text={`Apologies, seems like a network issue in Pickyourtrail. Could you please try once again.`}
            // onConfirm={() => this.deleteCity(this.state.cityToDelete)}
            // showCancelButton
            animation="pop"
            // onEscapeKey={() =>
            // this.setState({ isRemoveConfirmationVisible: false })
            // }
            onConfirm={() => this.setState({ showAlert: false })}
            // onOutsideClick={() =>
            // this.setState({ isRemoveConfirmationVisible: false })
            // }
          />
        </div>
        <div className="modal-backdrop fade in" />
      </div>
    );
  }
}

// Custom overrides for "code" style.
const styleMap = {
  CODE: {
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
    fontFamily: '"Inconsolata", "Menlo", "Consolas", monospace',
    fontSize: 16,
    padding: 2
  }
};

function getBlockStyle(block) {
  switch (block.getType()) {
    case 'blockquote':
      return 'RichEditor-blockquote';
    default:
      return null;
  }
}

class StyleButton extends Component {
  constructor() {
    super();
    this.onToggle = e => {
      e.preventDefault();
      this.props.onToggle(this.props.style);
    };
  }

  render() {
    let className = 'RichEditor-styleButton';
    if (this.props.active) {
      className += ' RichEditor-activeButton';
    }

    return (
      <span className={className} onMouseDown={this.onToggle}>
        {this.props.label}
      </span>
    );
  }
}

const BLOCK_TYPES = [
  {label: BQ, style: 'blockquote'},
  {label: UL, style: 'unordered-list-item'},
  {label: OL, style: 'ordered-list-item'}
];

const BlockStyleControls = props => {
  const {editorState} = props;
  const selection = editorState.getSelection();
  const blockType = editorState
    .getCurrentContent()
    .getBlockForKey(selection.getStartKey())
    .getType();

  return (
    <Fragment>
      {BLOCK_TYPES.map(type => (
        <StyleButton
          key={type.label}
          active={type.style === blockType}
          label={type.label}
          onToggle={props.onToggle}
          style={type.style}
        />
      ))}
    </Fragment>
  );
};

let INLINE_STYLES = [
  {label: Bold, style: 'BOLD'},
  {label: Italic, style: 'ITALIC'},
  {label: UnderLine, style: 'UNDERLINE'}
];

const InlineStyleControls = props => {
  let currentStyle = props.editorState.getCurrentInlineStyle();
  return (
    <Fragment>
      {INLINE_STYLES.map(type => (
        <StyleButton
          key={type.label}
          active={currentStyle.has(type.style)}
          label={type.label}
          onToggle={props.onToggle}
          style={type.style}
        />
      ))}
    </Fragment>
  );
};
function mapStateToProps(state) {
  let app = state.app;
  return {
    userDetails: app.user_details,
    emailSent: app.emailSent,
    travellerInfo: app.itineraryInfo && app.itineraryInfo.itineraryDetails && app.itineraryInfo.itineraryDetails.travellerInfo || {}
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      sendEmailQuote: bindActionCreators(sendEmailQuote, dispatch),
      dissolveEmailSent: bindActionCreators(dissolveEmailSent, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(EmailQuoteAdmin);
