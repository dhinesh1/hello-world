import React, {Component, Fragment} from 'react';
import {
  EditorState,
  RichUtils,
  convertToRaw,
  AtomicBlockUtils,
  convertFromRaw
} from 'draft-js';
import Editor from 'draft-js-plugins-editor';
import {stateToHTML} from 'draft-js-export-html';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import classNames from 'classnames';
import {BQ, Bold, Italic, OL, UL, UnderLine} from './constants/icons';
import {
  shareItinerary,
  dissolveItineraryShared
} from '../../actions/actions_app';
import {
  onceModalClosed,
  onceModalOpened,
  isValidMobileNumber as isValidNumber
} from '../../helpers/utilsHelper';
import SweetAlert from 'sweetalert-react';

import Phone from 'react-phone-number-input';
import {parseNumber} from 'libphonenumber-js';
import {emailValidation} from '../validations';
import {triggerSimpleAjax} from '../../helpers/httpHelper';

import {AppConfig} from '../../app-config';
import {getLeadSource} from '../../helpers/leadSourceHelper';
import {withLastLocation} from 'react-router-last-location';
import createImagePlugin from 'draft-js-image-plugin';
import {itineraryModalsRouteHelper} from '../../helpers/routesHelper';
const API_URL = AppConfig.api_url;

const imagePlugin = createImagePlugin();
const plugins = [imagePlugin];
const {europe_extra_cc_emails = [], aus_nz_extra_cc_emails = []} = AppConfig;
/*global swal */
class ShareItineraryModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      asNewUser: false,
      isLoading: false,
      unauth: false,
      showSuccess: false,
      showFailure: false,
      shareItineraryResponse: '',
      email_value: '',
      user_name: '',
      TTid: '',
      callNotes: '',
      countryCode: '+91',
      mobile_number: '',
      errorMessage: '',
      ccList: [],
      subject: '',
      source: '',
      channelText: '',
      sourceText: '',
      channel: '',
      editorState: EditorState.createEmpty(),
      responseUserEmailList: [],
      leadStatus: '',
      goodLeads: '',
      validation: {
        nameValid: true,
        emailValid: true,
        phoneNumberValid: true,
        isFormValid: true,
        sourceValid: true,
        channelValid: true,
        TTidValid: true,
        // callNotesValid: true,
        leadStatusValid: true
      },
      showAlert: false,
      isFocused: false,
      accountsFetched: false,
      chosenUserAccEmail: '',
      formSubmitted: false,
      lastFormScenario: '',
      extraEmailsToAttach: [],
      travelerType: props.travellerInfo.type || '',
      purposeOfTravel: props.travellerInfo.travelPurpose || '',
      purposeOfTravelVisible: false,
      mealPreferences: props.travellerInfo.details || ''
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.onClickContinue = this.onClickContinue.bind(this);
    this.renderSuccessDiv = this.renderSuccessDiv.bind(this);
    this.renderHelper = this.renderHelper.bind(this);
    this.renderEmailFormDiv = this.renderEmailFormDiv.bind(this);
    this.inputChangeHandler = this.inputChangeHandler.bind(this);
    this.fetchEmailIDs = this.fetchEmailIDs.bind(this);
    this.renderEmailLists = this.renderEmailLists.bind(this);
    this.createNewUser = this.createNewUser.bind(this);
    this.validateForm = this.validateForm.bind(this);
    this.inputTripDetails = this.inputTripDetails.bind(this);

    this.autoFillDetails = this.autoFillDetails.bind(this);

    this.focus = () => this.refs.editor.focus();
    this.onChange = editorState => this.setState({editorState});

    this.handleKeyCommand = command => this._handleKeyCommand(command);
    this.onTab = e => this._onTab(e);
    this.toggleBlockType = type => this._toggleBlockType(type);
    this.toggleInlineStyle = style => this._toggleInlineStyle(style);

    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.handelOnChange = this.handelOnChange.bind(this);

    this.chooseEmail = this.chooseEmail.bind(this);
  }

  componentDidMount() {
    this.openModal();
    document.addEventListener('keyup', this.handleKeyUp);
    document.addEventListener('paste', this.pasteAndUploadImage);
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    let {extraEmailsToAttach} = prevState;
    let {itineraryInfo} = nextProps;
    if (
      extraEmailsToAttach !== europe_extra_cc_emails ||
      extraEmailsToAttach !== aus_nz_extra_cc_emails
    ) {
      if (itineraryInfo && itineraryInfo.itinerary) {
        // Get emails to attach by the region
        if (itineraryInfo.itinerary.region === 'EUROPE') {
          extraEmailsToAttach = europe_extra_cc_emails.slice(0);
        } else if (itineraryInfo.itinerary.region === 'ANZ') {
          extraEmailsToAttach = aus_nz_extra_cc_emails.slice(0);
        }
      }
      return {...prevState, extraEmailsToAttach};
    }
    return null;
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
    document.removeEventListener('paste', this.pasteAndUploadImage);
  }
  autoFillDetails(props) {
    let local_shareItinerary = JSON.parse(
      localStorage.getItem('shareItineraryDetails')
    );
    if (
      local_shareItinerary &&
      local_shareItinerary.data.itineraryId ===
        this.props.match.params.itineraryId &&
      local_shareItinerary.data.countryPhoneCode +
        local_shareItinerary.data.mobileNumber ===
        this.state.mobile_number
    ) {
      let retrieveState = local_shareItinerary.data;
      let edit = EditorState.createWithContent(
        convertFromRaw(JSON.parse(retrieveState.plannerNotes))
      );

      this.setState({
        callNotes: retrieveState.callNotes,
        ccList: retrieveState.ccList ? retrieveState.ccList.split(',') : [], // retrive the cclis from localstorage as array
        subject: retrieveState.subject,
        channel: retrieveState.knownUsFrom &&
          retrieveState.knownUsFrom.toString(),
        editorState: edit,
        countryCode: retrieveState.countryPhoneCode,
        email_value: retrieveState.email,
        goodLeads: retrieveState.goodLeads,
        itineraryId: retrieveState.itineraryId,
        knownUsFrom: retrieveState.knownUsFrom,
        leadStatus: retrieveState.leadStatus,
        source: retrieveState.channel && retrieveState.channel.toString(),
        user_name: retrieveState.name,
        TTid: retrieveState.ttId
      });
    } else {
      /** Store the empty share email quote details */
      localStorage.setItem(
        'shareItineraryDetails',
        JSON.stringify({
          data: {}
        })
      );
    }
  }

  openModal() {
    this.setState({showModal: true, deleteActivity: false}, () => {
      onceModalOpened();
    });
  }

  closeModal() {
    let {history, location, match, itineraryDetail} = this.props;

    setTimeout(() => {
      this.setState({showModal: false, deleteActivity: false}, () => {
        onceModalClosed();

        history.push(
          itineraryModalsRouteHelper({
            itineraryId: itineraryDetail.itineraryId,
            regionCode: itineraryDetail.regionCode,
            location,
          })
        );
      });
    }, 400);
  }

  insertImage = (editorState, base64) => {
    const contentState = editorState.getCurrentContent();
    const contentStateWithEntity = contentState.createEntity(
      'image',
      'IMMUTABLE',
      {src: base64}
    );
    const entityKey = contentStateWithEntity.getLastCreatedEntityKey();
    const newEditorState = EditorState.set(editorState, {
      currentContent: contentStateWithEntity
    });
    return AtomicBlockUtils.insertAtomicBlock(newEditorState, entityKey, ' ');
  };

  /**
   * Callback function for the image to base 64 convert and clipboard action
   */
  retrieveImageFromClipboardAsBlob = (pasteEvent, callback) => {
    if (pasteEvent.clipboardData == false) {
      if (typeof callback == 'function') {
        callback(undefined);
      }
    }

    let items = pasteEvent.clipboardData.items;

    if (items == undefined) {
      if (typeof callback == 'function') {
        callback(undefined);
      }
    }

    for (let i = 0; i < items.length; i++) {
      // Skip content if not image
      if (items[i].type.indexOf('image') == -1) continue;
      // Retrieve image on clipboard as blob
      let blob = items[i].getAsFile();

      if (typeof callback == 'function') {
        callback(blob);
      }
    }
  };
  /**
   * This function will trigger when pate the elment in document
   */
  pasteAndUploadImage = event => {
    const _this = this;
    if (!this.state.isFocused) {
      return null;
    }
    this.retrieveImageFromClipboardAsBlob(event, imageBlob => {
      // If there's an image, display it in the canvas
      if (imageBlob) {
        const canvas = document.createElement('canvas');
        let ctx = canvas.getContext('2d');

        // Create an image to render the blob on the canvas
        let img = new Image();
        let base64;

        // Once the image loads, render the img on the canvas
        img.onload = function() {
          // Update dimensions of the canvas with the dimensions of the image
          canvas.width = this.width;
          canvas.height = this.height;

          // Draw the image
          ctx.drawImage(img, 0, 0);

          base64 = canvas.toDataURL('image/png');

          const newEditorState = _this.insertImage(
            _this.state.editorState,
            base64
          );
          _this.setState({editorState: newEditorState});
        };

        // Crossbrowser support for URL
        let URLObj = window.URL || window.webkitURL;

        // Creates a DOMString containing a URL representing the object given in the parameter
        // namely the original Blob
        img.src = URLObj.createObjectURL(imageBlob);
      }
    });
  };

  validateForm(scenario) {
    // console.log('Validation for: ', scenario);
    let validation = this.state.validation;

    validation.phoneNumberValid = isValidNumber(this.state.mobile_number);
    if (scenario === 'FETCH_ACCOUNTS') {
      validation.nameValid = true;
      validation.emailValid = true;
      validation.emailChoiceValid = true;

      // Source
      validation.sourceValid = true;
      validation.channelValid = true;

      // TT id
      validation.TTidValid = true;

      // validation.callNotesValid = true;
      validation.leadStatusValid = true;
    } else {
      if (this.state.asNewUser) {
        validation.nameValid = !(this.state.user_name.length === 0 ||
          this.state.user_name === ' ');
        validation.emailChoiceValid = true;
        validation.emailValid = emailValidation(this.state.email_value);
      } else {
        validation.nameValid = true;
        validation.emailValid = true;
        validation.emailChoiceValid =
          this.state.chosenUserAccEmail.trim().length > 0;
      }
      /**
       * This validation has been used hidden the lead source and prod type when user is existing
       */
      validation.sourceValid =
        !this.state.asNewUser || (this.state.source || '').trim().length > 0;
      validation.channelValid =
        !this.state.asNewUser || (this.state.channel || '').trim().length > 0;

      validation.leadStatusValid = this.state.leadStatus.trim().length > 0;

      // TT id
      validation.TTidValid = true;
      if (this.state.source === '10') {
        validation.TTidValid = this.state.TTid.trim().length > 0;
      }

      // Call notes
      //validation.callNotesValid = this.state.callNotes.trim().length > 0;
    }

    if (scenario === 'FETCH_ACCOUNTS') {
      validation.isFormValid = validation.phoneNumberValid;
    } else {
      validation.isFormValid =
        validation.nameValid &&
        validation.phoneNumberValid &&
        validation.emailValid &&
        validation.emailChoiceValid &&
        validation.sourceValid &&
        validation.channelValid &&
        validation.TTidValid &&
        //validation.callNotesValid &&
        validation.leadStatusValid;
    }

    this.setState({
      validation: validation,
      formSubmitted: scenario !== 'FETCH_ACCOUNTS',
      lastFormScenario: scenario,
    });
    return validation.isFormValid;
  }

  inputChangeHandler(event) {
    let {extraEmailsToAttach} = this.state;
    // for lead status change we are adding the extra cc emails if available
    if (
      event.target.name === 'source' &&
      extraEmailsToAttach &&
      extraEmailsToAttach.length > 0
    ) {
      let {ccList} = this.state;
      // if lead source value is 10 (Paid_TT) the add the emails
      if (event.target.value === '10') {
        ccList = ccList
          ? [...ccList, ...extraEmailsToAttach]
          : extraEmailsToAttach;
      } else if (ccList && ccList.length > 0) {
        // if lead source value is other then paid TT then remove the emails attached
        ccList = ccList.filter(email => {
          return !extraEmailsToAttach.includes(email);
        });
      }
      this.setState({ccList});
    }
    this.setState(
      {
        [event.target.name]: event.target.name === 'goodLeads'
          ? !this.state[event.target.name] // changing true or false for only checkboxes
          : event.target.value, //Applying direct value for other fields
      },
      () => {
        if (
          this.state.formSubmitted &&
          this.validateForm(this.state.lastFormScenario)
        ) {
          let data = this.getDetails();
          data['goodLeads'] = this.state.goodLeads;
          let contentState = this.state.editorState.getCurrentContent();
          data['plannerNotes'] = JSON.stringify(convertToRaw(contentState));

          /** Store the current shareItinerary details */
          localStorage.setItem(
            'shareItineraryDetails',
            JSON.stringify({
              data: data
            })
          );
        }
      }
    );
  }

  inputTripDetails(event) {
 
    if (event.target.name === 'travelerType') {
      if (event.target.value === 'COUPLES') {
        this.setState({
          travelerType: event.target.value,
          purposeOfTravel: '',
          purposeOfTravelVisible: true,
        });
      } else {
        this.setState({
          travelerType: event.target.value,
          purposeOfTravel: event.target.value,
          purposeOfTravelVisible: false,
        });
      }
    } else {
      this.setState({[event.target.name]: event.target.value});
    }
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
    if (e.keyCode === 13) {
      let numberValid = isValidNumber(this.state.mobile_number);
      numberValid && this.fetchEmailIDs();
    }
  }

  createNewUser(e) {
    e && e.preventDefault();

    this.setState(
      {
        asNewUser: true,
        isLoading: false,
        chosenUserAccEmail: '',
        lastFormScenario: 'CONTINUE'
      },
      () => {
        if (this.state.formSubmitted) {
          this.validateForm(this.state.lastFormScenario);
        }
      }
    );
  }

  fetchEmailIDs(e) {
    e && e.preventDefault();

    this.validateForm('FETCH_ACCOUNTS');
    if (this.state.validation.isFormValid) {
      this.autoFillDetails(this.props);
      this.setState({isLoading: true}, () => {
        let {
          countryCode,
          mobile_number,
          ccList,
          plannerNotes,
          subject
        } = this.state;

        mobile_number = mobile_number
          .replace(/\D/g, '')
          .substr(countryCode.replace('+', '').length);
        let itineraryId = this.props.itineraryDetail.itineraryId;

        let post_data = {
          itineraryId: itineraryId,
          email: '',
          countryPhoneCode: countryCode,
          mobileNumber: mobile_number,
          name: '',
          ccList: ccList.join(','),
          subject: subject,
          plannerNotes: plannerNotes
        };

        let url = `${API_URL}itinerary/${itineraryId}/share`;
        triggerSimpleAjax(
          url,
          'POST',
          post_data,
          response => {
            if (response.data.userPresent) {
              if (!response.data.inBookingStage) {
                this.setState({
                  responseUserEmailList: response.data.users,
                  isLoading: false,
                  accountsFetched: true,
                  userPresent: response.data.userPresent,
                  asNewUser: false
                });
              } else {
                swal(
                  {
                    title: 'Itinerary is in booking stage',
                    text: 'You can not share this itinerary now.',
                    animation: true,
                    showCancelButton: false,
                    confirmButtonColor: '#DD6B55',
                    confirmButtonText: 'Okay',
                    cancelButtonText: 'Cancel',
                    closeOnConfirm: true,
                    closeOnCancel: true
                  },
                  function(isConfirm) {}
                );
              }
            } else {
              this.setState({
                asNewUser: true,
                isLoading: false,
                userPresent: false,
                accountsFetched: true
              });

              // this.user_name.focus();
            }
          },
          error => {
            console.warn(error);
          }
        );
      });
    }
  }

  getDetails() {
    let itineraryId = this.props.itineraryDetail.itineraryId,
      {
        ccList,
        subject,
        editorState,
        email_value,
        mobile_number,
        user_name,
        source,
        channel,
        TTid,
        callNotes,
        countryCode,
        goodLeads,
        leadStatus,
        chosenUserAccEmail,
        asNewUser,
        travelerType,
        purposeOfTravel,
        mealPreferences
      } = this.state;

    let post_data = {
      itineraryId: itineraryId,
      email: asNewUser ? email_value : chosenUserAccEmail,
      countryPhoneCode: countryCode,
      mobileNumber: mobile_number
        .replace(/\D/g, '')
        .substr(countryCode.replace('+', '').length),
      name: user_name,
      ccList: ccList ? ccList.join(',') : '', // saving cclist in localstorage and sending to backend as comma seperated string
      subject: subject,
      ttId: TTid,
      callNotes: callNotes,
      goodLeads: goodLeads,
      leadStatus: leadStatus,
      plannerNotes: stateToHTML(editorState.getCurrentContent()),
      channel: parseInt(source, 10),
      knownUsFrom: parseInt(channel, 10),
      travellerInfo: {
        type: travelerType,
        travelPurpose: purposeOfTravel,
        details: mealPreferences
      },
      leadSource: getLeadSource({
        history: this.props.history,
        lastLocation: this.props.lastLocation,
        itineraryId: itineraryId
      })
    };
    post_data.leadSource.channel = parseInt(channel, 10);
    post_data.leadSource.knownUsFrom = parseInt(source, 10);
    return post_data;
  }

  onClickContinue(e) {
    e && e.preventDefault();

    this.validateForm(this.state.asNewUser ? 'CONTINUE' : 'SHARE');

    if (this.state.validation.isFormValid) {
      this.setState({isLoading: true}, () => {
        let post_data = this.getDetails ();
        let itineraryId = this.props.itineraryDetail.itineraryId;
        let url = `${API_URL}itinerary/${itineraryId}/share`;
        triggerSimpleAjax(
          url,
          'POST',
          post_data,
          response => {
            if (!response.data.errorPreset) {
              this.setState({
                isLoading: false,
                showSuccess: true,
                showFailure: false
              });
            } else {
              this.setState({
                isLoading: false,
                asNewUser: false,
                showFailure: true,
                unauth: false,
                shareItineraryResponse: response.data.statusMessage
              });
            }
          },
          error => {
            if (error.response && error.response.status === 404) {
              this.setState({
                isLoading: false,
                asNewUser: true
              });
            } else if (error.response && error.response.status === 401) {
              this.setState({
                isLoading: false,
                asNewUser: false,
                showFailure: true,
                unauth: true,
                shareItineraryResponse: ''
              });
            } else {
              this.setState({
                isLoading: false,
                asNewUser: false,
                showFailure: true,
                unauth: false,
                shareItineraryResponse: error.response.statusMessage
              });
            }
          }
        );
      });
    }
  }

  renderSuccessDiv() {
    return (
      <div className="col-md-12 text-center">
        <h2 className="bold large">
          Your itinerary is on its way to your inbox.
        </h2>
        <span className="normal dim">
          Please check{' '}
          {this.state.asNewUser
            ? this.state.email_value
            : this.state.chosenUserAccEmail}
          {' '}
          for this itinerary. Note that the costs are subject to change
          continuously. Always check the latest pricing before booking.
        </span>
      </div>
    );
  }

  renderFailureDiv() {
    return (
      <div className="col-md-12 text-center">
        <h2 className="bold large">Whoops!</h2>
        <h4 className={'dim'}>
          {this.state.unauth
            ? "You don't have permission for this!"
            : this.state.shareItineraryResponse}
        </h4>
      </div>
    );
  }

  chooseEmail(event) {
    this.setState({
      chosenUserAccEmail: event.target.value,
      asNewUser: false,
      lastFormScenario: 'SHARE',
      source: '',
      channel: '',
      TTid: ''
    });
  }

  renderEmailLists(users) {
    if (users) {
      return users.map(user => {
        return (
          <div className="form-group" key={`row_${user.email}`}>
            <label className="custom-options">
              <input
                type="radio"
                value={user.email}
                name={'user_email'}
                onChange={this.chooseEmail}
                checked={this.state.chosenUserAccEmail === user.email}
              />
              <span style={{'overflow-wrap': 'break-word'}}>
                {user.email}
              </span>
              <i />
            </label>
          </div>
        );
      });
    } else {
      return null;
    }
  }

  handelOnChange(value, cObj) {
    // let countryCode = '+' + cObj.dialCode;
    let countryCode = '+';
    value = value ? value : '';

    let numberValid = isValidNumber(value);
    // let strippedPhoneNumber = value.replace(/\D/g, '');
    // let countryCodeLen = 0;

    if (numberValid) {
      let parsed = parseNumber(value, {extended: true});
      // console.log("Parsed value: ",parsed);

      countryCode += parsed.countryCallingCode;
      // countryCodeLen = countryCode.length;
    }

    this.setState({
      mobile_number: value,
      countryCode: countryCode
    });
  }

  _handleKeyCommand(command) {
    const {editorState} = this.state;
    const newState = RichUtils.handleKeyCommand(editorState, command);
    if (newState) {
      this.onChange(newState);
      return true;
    }
    return false;
  }

  _onTab(e) {
    const maxDepth = 4;
    this.onChange(RichUtils.onTab(e, this.state.editorState, maxDepth));
  }

  _toggleBlockType(blockType) {
    this.onChange(
      RichUtils.toggleBlockType(this.state.editorState, blockType)
    );
  }

  _toggleInlineStyle(inlineStyle) {
    this.onChange(
      RichUtils.toggleInlineStyle(this.state.editorState, inlineStyle)
    );
  }
  /**
   * save the value in the sample and handles that,
   * add the sample's value only at comma is entered
   * @param event
   */
  handleCCEmailInput = event => {
    let {value} = event.target;
    let {ccList} = this.state;
    let ccEmailSample = '';
    //  If value is not only comma than
    if (value !== ',') {
      ccEmailSample = value;
    }
    // If ccEmailSample ends with "," than we are adding to cclist
    if (ccEmailSample.endsWith(',')) {
      ccList = ccList ? ccList : [];
      // Store all emails seperated with the comma
      let sampleList = ccEmailSample.split(',');
      sampleList.forEach(sampleEmail => {
        if (sampleEmail && !ccList.includes(sampleEmail)) {
          ccList.push(sampleEmail);
        }
      });
      ccEmailSample = '';
    }
    this.setState({ccList, ccEmailSample});
  };
  /**
   * open the tag value in the in put box
   * @param email
   */
  handleClickCCEmailTag = tabEmail => {
    let {ccList, ccEmailSample} = this.state;
    // Set the exsitin value to cc list
    if (ccEmailSample && ccEmailSample.length > 0) {
      ccList = ccList ? ccList : [];
      ccList.push(ccEmailSample);
    }
    // remove the tab from cclist
    if (ccList) {
      ccList = ccList.filter(email => email !== tabEmail);
    }
    this.setState({ccList, ccEmailSample: tabEmail});
  };
  /**
   * Close and delete the email from the cclist
   * @param email
   */
  handleCloseCCEmailTag = tabEmail => {
    let {ccList} = this.state;
    if (ccList) {
      ccList = ccList.filter(email => email !== tabEmail);
    }
    this.setState({ccList});
  };
  /**
   * Add's the remaing mail in the cclist
   * if user not enter the comma and goes out of the in put field
   */
  addRemaingToCCListOnBlur = () => {
    let {ccList, ccEmailSample} = this.state;
    if (
      ccEmailSample &&
      ccEmailSample.length > 0 &&
      !/^\s*/.test(ccEmailSample)
    ) {
      ccList = ccList ? ccList : [];
      ccList.push(ccEmailSample);
      this.setState({ccList, ccEmailSample: ''});
    }
  };

  updateMealPreference = (preference) => {
    this.setState({
      mealPreferences: preference
    })
  }

  renderEmailFormDiv() {
    const {
      editorState,
      accountsFetched,
      responseUserEmailList,
      mobile_number,
      asNewUser,
      user_name,
      validation
    } = this.state;

    // If the user changes block type before entering any text, we can
    // either style the placeholder or hide it. Let's just hide it now.
    let className = 'RichEditor-editor';
    let contentState = editorState.getCurrentContent();
    if (!contentState.hasText()) {
      if (contentState.getBlockMap().first().getType() !== 'unstyled') {
        className += ' RichEditor-hidePlaceholder';
      }
    }

    return (
      <div className="col-xs-12">
        <form
          id="share_itinerary_modal-form"
          noValidate={true}
          action="javascript:void(0);"
        >
          <div className="row">
            <div
              className={
                accountsFetched || asNewUser
                  ? 'col-xs-12 col-sm-6'
                  : 'col-xs-12'
              }
            >
              <div
                className={classNames('form-group', {
                  'has-error': !validation.phoneNumberValid
                })}
              >
                <div className="clearfix label-link">
                  <label className="control-label" htmlFor="uname">
                    Enter mobile number to fetch accounts
                  </label>
                  {accountsFetched
                    ? <button
                        className="btn btn-link"
                        onClick={e =>
                          this.setState({
                            accountsFetched: false,
                            asNewUser: false
                          })}
                      >
                        Change
                      </button>
                    : null}
                </div>

                <Phone
                  displayInitialValueAsLocalNumber={false}
                  country={'IN'}
                  value={mobile_number}
                  error={
                    mobile_number
                      ? isValidNumber(mobile_number)
                          ? undefined
                          : 'Invalid phone number'
                      : undefined
                  }
                  indicateInvalid
                  saveOnIcons={false}
                  smartCaret={false}
                  disabled={accountsFetched}
                  onChange={this.handelOnChange}
                />
              </div>

              <div className="row">
                {accountsFetched
                  ? <div className={'col-xs-12 col-sm-6'}>
                      {responseUserEmailList.length
                        ? <div>
                            {/*<h5>Accounts associated with the given contact</h5>*/}
                            <div
                              className={classNames('form-group', {
                                'has-error': !validation.emailChoiceValid
                              })}
                            >
                              <label className="control-label">
                                Choose any associated account
                              </label>
                              {this.renderEmailLists(responseUserEmailList)}
                            </div>
                          </div>
                        : <div>
                            <span className={'fade small text-danger'}>
                              No accounts found for the given contact. Please create
                              new one
                            </span>
                          </div>}
                    </div>
                  : null}
                {accountsFetched
                  ? <div className={'col-xs-12 col-sm-12 form-group'}>
                      <label className="control-label">CC Email</label>
                      <div className="email-tag-list">
                        {this.state.ccList
                          ? this.state.ccList.map(email => {
                              return (
                                <span
                                  className={'pill color-grey bg-grey-lighter'}
                                  title={email}
                                  key={email}
                                >
                                  <b
                                    className="regular"
                                    onClick={e =>
                                      this.handleClickCCEmailTag(email)}
                                  >
                                    {email}
                                  </b>
                                  <i
                                    className={'vehoicon-close'}
                                    onClick={() =>
                                      this.handleCloseCCEmailTag(email)}
                                  />
                                </span>
                              );
                            })
                          : null}
                        <input
                          type="text"
                          className="form-control"
                          value={this.state.ccEmailSample}
                          onChange={this.handleCCEmailInput}
                          name="ccEmailSample"
                          ref="ccEmailSample"
                          placeholder="IDS(Comma separated)"
                          onBlur={this.addRemaingToCCListOnBlur}
                        />
                      </div>
                    </div>
                  : null}
              </div>

              {accountsFetched ? (
                <div className="row">
                  <div className={'col-xs-12 col-sm-12 form-group'}>
                    <input
                      type="text"
                      className="form-control"
                      value={this.state.subject}
                      onChange={this.inputChangeHandler}
                      name="subject"
                      ref="subject"
                      placeholder="Please enter your subject"
                    />
                  </div>
                </div>
              ) : null}

              {asNewUser
                ? <Fragment>
                    <h5>New user details</h5>
                    <div className={'row'}>
                      <div className="col-xs-12 col-sm-6">
                        <div
                          className={classNames ('form-group', {
                            'has-error': !validation.nameValid
                          })}
                        >
                          <input
                            type="text"
                            value={user_name}
                            ref="user_name"
                            name="user_name"
                            required="required"
                            placeholder="Enter name"
                            onChange={this.inputChangeHandler}
                            className={'form-control animated'}
                          />
                          <span className="error text-danger bold block">
                            {this.state.errorMessage}
                          </span>
                        </div>
                      </div>
                      <div className="col-xs-12 col-sm-6">
                        <div
                          className={
                            'form-group ' +
                              (this.state.validation.emailValid
                                ? ''
                                : 'has-error')
                          }
                        >
                          <input
                            type="text"
                            value={this.state.email_value}
                            ref="email_field"
                            name="email_value"
                            required="required"
                            placeholder="Enter email"
                            onChange={this.inputChangeHandler}
                            className={'form-control animated'}
                          />
                          <span className="error text-danger bold block">
                            {this.state.errorMessage}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h5>Trip details</h5>
                      <div className="row">
                        <div className={'col-sm-6 col-xs-12'}>
                          <div className="form-group">
                            <label className="control-label">
                              Traveler Type
                            </label>
                            <div className="custom-select">
                              <select
                                value={this.state.travelerType}
                                onChange={this.inputTripDetails}
                                className={'form-control '}
                                name="travelerType"
                                aria-hidden="true"
                              >
                                <option value={''}>---</option>
                                <option value={'SOLO'}>Solo</option>
                                <option value={'FRIENDS'}>Friends</option>
                                <option value={'FAMILY'}>Family</option>
                                <option value={'CO_WORKERS'}>Co-workers</option>
                                <option value={'COUPLES'}>Couples</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div
                          className={'col-sm-6 col-xs-12'}
                          style={{
                            display: `${this.state.purposeOfTravelVisible ? 'inline' : 'none'}`,
                          }}
                        >
                          <div className="form-group">
                            <label className="control-label">
                              Purpose of Travel
                            </label>
                            <div className="custom-select">
                              <select
                                value={this.state.purposeOfTravel}
                                onChange={this.inputTripDetails}
                                className={'form-control '}
                                name="purposeOfTravel"
                                aria-hidden="true"
                              >
                                <option value={''}>---</option>
                                <option value={'ANNIVERSARY'}>
                                  Anniversary
                                </option>
                                <option value={'HONEYMOON'}>Honeymoon</option>
                                <option value={'BIRTHDAY'}>
                                  Birthday
                                </option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div className={'col-sm-6 col-xs-12'}>
                          <div className="form-group">
                            <p className="control-label">
                              Meal preferences{' '}
                            </p>
                           <div class="btn-group">
                              <button 
                                type="button" 
                                onClick={() => this.updateMealPreference('veg')}
                                class={`btn btn-default btn-outline btn-outline-bg btn-sm mealPreferences ${this.state.mealPreferences === 'veg' ? 'active' : ''}`}>Veg</button>
                              <button 
                                type="button" 
                                onClick={() => this.updateMealPreference('non-veg')}
                                class={`btn btn-default btn-outline btn-outline-bg btn-sm mealPreferences ${this.state.mealPreferences === 'non-veg' ? 'active' : ''}`}>Non-veg</button>
                            </div>
                            </div>
                            </div>
                      </div>

                    </div>
                  </Fragment>
                : null}

              {accountsFetched
                ? <Fragment>
                    <h5 className={'bold'}>For PLATO</h5>
                    <div className={'row'}>
                      <div className={'col-xs-12'}>
                        <div className="row">
                          {/**
                         * @author: Jothisankar
                         * @email: jothi@pickyourtrail.com
                         * @desc: New lead source mapping (LSM) changes with respect to LSM revamp -
                         * values are updated as stored in PLATO DB
                         * Its hard-corded now - So any changes in value / Label has to be manual and we are reusing the variables here
                         * source - Lead source - will be processed as an integer
                         * channel - Prod type - will be processed as an integer
                         */}
                          {asNewUser
                            ? <Fragment>
                                <div className="col-xs-12 col-sm-6">
                                  <div
                                    className={
                                      'form-group ' +
                                        (this.state.validation.sourceValid
                                          ? ''
                                          : 'has-error')
                                    }
                                  >
                                    <label className="control-label">
                                      Lead source
                                    </label>
                                    <select
                                      ref="leadsource"
                                      value={this.state.source}
                                      name={'source'}
                                      onChange={this.inputChangeHandler}
                                      className={'form-control'}
                                    >
                                      <option value="">---</option>
                                      <option value={9}>Blog</option>
                                      <option value={1}>Direct</option>
                                      <option value={14}>External_sites</option>
                                      <option value={6}>Facebook</option>
                                      <option value={7}>Instagram</option>
                                      <option value={11}>Paid_Affiliate</option>
                                      <option value={12}>Paid_SEM</option>
                                      <option value={13}>Paid_SMM</option>
                                      <option value={10}>Paid_TT</option>
                                      <option value={2}>PR</option>
                                      <option value={5}>Quora</option>
                                      <option value={4}>Referral</option>
                                      <option value={3}>SEO</option>
                                      <option value={8}>Twitter</option>
                                    </select>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                  <div
                                    className={
                                      'form-group ' +
                                        (this.state.validation.channelValid
                                          ? ''
                                          : 'has-error')
                                    }
                                  >
                                    <label className="control-label">
                                      Product Type
                                    </label>
                                    <select
                                      value={this.state.channel}
                                      ref="prodtype"
                                      onChange={this.inputChangeHandler}
                                      className={'form-control '}
                                      name="channel"
                                      aria-hidden="true"
                                    >
                                      <option value="">---</option>
                                      <option value={3}>Called In</option>
                                      <option value={6}>CBR</option>
                                      <option value={4}>Chat</option>
                                      <option value={5}>Packages</option>
                                      <option value={1}>PDG</option>
                                      <option value={2}>Postcard</option>
                                    </select>
                                  </div>
                                </div>
                              </Fragment>
                            : null}
                          {asNewUser && this.state.source === '10'
                            ? <div className="col-xs-6">
                                <div
                                  className={
                                    'form-group ' +
                                      (this.state.validation.TTidValid
                                        ? ''
                                        : 'has-error')
                                  }
                                >
                                  <input
                                    type="text"
                                    value={this.state.TTid}
                                    ref="TTid"
                                    required="required"
                                    title="TTid is required"
                                    placeholder="Enter TT id"
                                    onChange={this.inputChangeHandler}
                                    name={'TTid'}
                                    className={'form-control animated'}
                                  />
                                  <span className="error text-danger bold block">
                                    {this.state.errorMessage}
                                  </span>
                                </div>
                              </div>
                            : null}

                          {/* <div className={'col-sm-6 col-xs-12'}>
                    <div className={'form-group '}>
                      <label className="control-label">Is Good lead?</label>
                      <div className={'block'}>
                        <label className="custom-options no-padding">
                          <input
                            type="checkbox"
                            value="true"
                            name={'goodLeads'}
                            checked={this.state.goodLeads}
                            onChange={this.inputChangeHandler}
                          />{' '}
                          Yes
                          <i />
                        </label>{' '}
                      </div>
                    </div>
                  </div> */}

                          <div className={'col-sm-6 col-xs-12'}>
                            <div
                              className={
                                'form-group ' +
                                  (this.state.validation.leadStatusValid
                                    ? ''
                                    : 'has-error')
                              }
                            >
                              <label className="control-label">
                                Lead status
                              </label>
                              <div className="custom-select">
                                <select
                                  value={this.state.leadStatus}
                                  onChange={this.inputChangeHandler}
                                  className={'form-control '}
                                  name="leadStatus"
                                  aria-hidden="true"
                                >
                                  <option value={''}>---</option>
                                  <option value={'NEW'}>New</option>
                                  <option value={'IN_TALKS'}>In-talks</option>
                                  <option value={'NEGOTIATING'}>
                                    Good Lead
                                  </option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="col-xs-12">
                        <div
                          className={
                            'form-group ' + ''
                            // (this.state.validation.callNotesValid ? '' : 'has-error')
                          }
                        >
                          <textarea
                            value={this.state.callNotes}
                            name={'callNotes'}
                            ref="call_notes"
                            title="Call notes required"
                            rows={4}
                            placeholder="Enter your call notes here..."
                            onChange={this.inputChangeHandler}
                            className={'form-control animated'}
                          />
                          <span className="error text-danger bold block">
                            {this.state.errorMessage}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Fragment>
                : null}
            </div>

            <div
              className={
                accountsFetched || asNewUser
                  ? 'col-xs-12 col-sm-6'
                  : 'col-xs-12'
              }
            >
              {accountsFetched
                ? <div>
                    <div className="form-group">
                      <div
                        className="RichEditor-root"
                        style={{'min-height': '440px'}}
                        onClick={this.focus}
                      >
                        <div className="RichEditor-controls">
                          <InlineStyleControls
                            editorState={editorState}
                            onToggle={this.toggleInlineStyle}
                          />
                          <BlockStyleControls
                            editorState={editorState}
                            onToggle={this.toggleBlockType}
                          />
                        </div>
                        <div className={className}>
                          <Editor
                            blockStyleFn={getBlockStyle}
                            customStyleMap={styleMap}
                            editorState={editorState}
                            handleKeyCommand={this.handleKeyCommand}
                            onChange={this.onChange}
                            onTab={this.onTab}
                            placeholder="Planner's notes..."
                            ref="editor"
                            onFocus={() => {
                              this.setState({isFocused: true});
                            }}
                            onBlur={() => {
                              this.setState({isFocused: false});
                            }}
                            spellCheck={true}
                            plugins={plugins}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                : null}
            </div>
          </div>
        </form>
      </div>
    );
  }

  renderHelper() {
    if (this.state.showSuccess) {
      return <div className="row">{this.renderSuccessDiv()}</div>;
    } else if (this.state.showFailure) {
      return <div className="row">{this.renderFailureDiv()}</div>;
    } else {
      return <div className="row">{this.renderEmailFormDiv()}</div>;
    }
  }

  render() {
    // if (this.props.itineraryShared && this.props.emailSent !== 'failure') {
    //   this.props.actions.dissolveItineraryShared();
    //   this.closeModal();
    // } else if (this.props.itineraryShared === 'failure') {
    //   this.props.actions.dissolveItineraryShared();
    //   this.setState({ showAlert: true });
    // }

    let {
      accountsFetched,
      responseUserEmailList,
      isLoading,
      showSuccess,
      showFailure,
      asNewUser
    } = this.state;

    return (
      <div
        tabIndex="-1"
        className={classNames('modal changes modal-sticky-footer fade', {
          in: this.state.showModal,
          container: accountsFetched || asNewUser,
          'share-modal': accountsFetched || asNewUser
        })}
      >
        <div className="modal-dialog">
          <div className="modal-content with-footer">
            <div className="modal-body">
              <div className="modal-row">
                {!showSuccess && !showFailure
                  ? <div className={'row'}>
                      <div className={'col-md-12'}>
                        <h3 className={'bold'}>Share itinerary</h3>
                      </div>
                    </div>
                  : null}

                {this.renderHelper()}

                <div className="modal-footer">
                  <button
                    type="button"
                    className="pull-left btn close"
                    data-dismiss="modal"
                    onClick={this.closeModal}
                  >
                    <i className="vehoicon-close" />
                  </button>

                  {!showSuccess && !showFailure
                    ? <div className={'actions'}>
                        {accountsFetched && responseUserEmailList.length
                          ? <button
                              className="btn btn-outline btn-primary-dark"
                              onClick={!isLoading ? this.createNewUser : null}
                              disabled={isLoading || asNewUser}
                            >
                              Create new user
                            </button>
                          : null}

                        {accountsFetched
                          ? <button
                              className="btn btn-primary"
                              onClick={!isLoading ? this.onClickContinue : null}
                              disabled={isLoading}
                            >
                              Continue
                            </button>
                          : <button
                              className="btn btn-primary"
                              onClick={!isLoading ? this.fetchEmailIDs : null}
                              disabled={isLoading}
                            >
                              Fetch accounts
                            </button>}
                      </div>
                    : null}
                </div>
              </div>
            </div>
          </div>
        </div>

        <SweetAlert
          show={this.state.showAlert}
          title="Sorry, unable to share the Itinerary"
          text={`Apologies, seems like a network issue in Pickyourtrail. Could you please try once again.`}
          // onConfirm={() => this.deleteCity(this.state.cityToDelete)}
          // showCancelButton
          animation="pop"
          // onEscapeKey={() =>
          // this.setState({ isRemoveConfirmationVisible: false })
          // }
          onConfirm={() => this.setState({showAlert: false})}
          // onOutsideClick={() =>
          // this.setState({ isRemoveConfirmationVisible: false })
          // }
        />
      </div>
    );
  }
}

// Custom overrides for "code" style.
const styleMap = {
  CODE: {
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
    fontFamily: '"Inconsolata", "Menlo", "Consolas", monospace',
    fontSize: 16,
    padding: 2
  },
};

function getBlockStyle(block) {
  switch(block.getType()) {
    case 'blockquote':
      return 'RichEditor-blockquote';
    default:
      return null;
  }
}

class StyleButton extends React.Component {
  constructor() {
    super();
    this.onToggle = e => {
      e.preventDefault();
      this.props.onToggle(this.props.style);
    };
  }

  render() {
    let className = 'RichEditor-styleButton';
    if (this.props.active) {
      className += ' RichEditor-activeButton';
    }

    return (
      <span className={className} onMouseDown={this.onToggle}>
        {this.props.label}
      </span>
    );
  }
}

const BLOCK_TYPES = [
  {label: BQ, style: 'blockquote'},
  {label: UL, style: 'unordered-list-item'},
  {label: OL, style: 'ordered-list-item'}
];

const BlockStyleControls = props => {
  const {editorState} = props;
  const selection = editorState.getSelection();
  const blockType = editorState
    .getCurrentContent()
    .getBlockForKey(selection.getStartKey())
    .getType();

  return (
    <Fragment>
      {BLOCK_TYPES.map(type => (
        <StyleButton
          key={type.label}
          active={type.style === blockType}
          label={type.label}
          onToggle={props.onToggle}
          style={type.style}
        />
      ))}
    </Fragment>
  );
};

let INLINE_STYLES = [
  {label: Bold, style: 'BOLD'},
  {label: Italic, style: 'ITALIC'},
  {label: UnderLine, style: 'UNDERLINE'}
];

const InlineStyleControls = props => {
  let currentStyle = props.editorState.getCurrentInlineStyle();
  return (
    <Fragment>
      {INLINE_STYLES.map(type => (
        <StyleButton
          key={type.label}
          active={currentStyle.has(type.style)}
          label={type.label}
          onToggle={props.onToggle}
          style={type.style}
        />
      ))}
    </Fragment>
  );
};

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count,
      itineraryShared: app.itineraryShared,
      travellerInfo: app.itineraryInfo.travellerInfo || {}
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details,
      itineraryShared: app.itineraryShared,
      travellerInfo: {}
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      shareItinerary: bindActionCreators(shareItinerary, dispatch),
      dissolveItineraryShared: bindActionCreators(
        dissolveItineraryShared,
        dispatch
      )
    }
  };
}

export default withLastLocation(
  connect(mapStateToProps, mapDispatchToProps)(ShareItineraryModal)
);
