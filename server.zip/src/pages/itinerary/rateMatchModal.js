import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import classNames from 'classnames';
import SweetAlert from 'sweetalert-react';
import _ from 'lodash';
import {
  itineraryModalsRouteHelper,
  routingPageType
} from '../../helpers/routesHelper';
import {
  applyHotelDiscount,
  applyRentalCarDiscount,
  applyFlightDiscount,
  updatePnrValidity,
  applyOverallDiscount,
  applyActivityDiscount,
  applyAgentNetCostDiscount,
  applyTrainDiscount,
  dissolveDiscount
} from '../../actions/actions_app';

import {
  decodeActivityKeyFromURL,
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';

class RateMatchModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      newPrice: '',
      source: '',
      otherSource: '',
      reason: '',
      otherReason: '',
      approvedBy: '',
      showAlert: false,
      reasons: {
        TOTAL_COST: [
          'Adding Buffer',
          'Aus Transit Visa',
          'Adding Item/Inclusion in product',
          'Applied Discount for cost cutting',
          'Specific Flight option NA in product',
          'Non Seasonal Rates in AP',
          'Discount Applied to match rate',
          'Adding Transfer Cost',
          'Removing Buffer',
          'Adding Baggage',
          'Adding Cruise',
          'Expensive On Product',
          'Flights Already Booked',
          'Adding Singapore Itinerary',
          'Nullifying Discount',
          'Discount from TT',
          'Business Class Flights',
          'Adding Item/Inclusion in product - Hotel Name Upgrade',
          'Split Stay in Hotels',
          'Including cost for 10th person',
          'Already in Rocket Bird package',
          'Flights Booked Offline',
          'Removing Intercity Transfers',
          'Removing Internal Flights',
          'Different Departure and Arrival cities for Flights',
          'Activity Addition post booking',
          'Need only one way Flights',
          'Others'
        ],
        HOTEL_ROOM_ROW: [
          'Specific Hotel NA in Product',
          'Contract Partnership',
          'Booked On TBO',
          'Want Split stay Hotels in same city',
          'Adding Cruise',
          'Off Season - Alam Puisi',
          'Applied Discount to match rate',
          'Expensive On Product',
          'Peak Season - Alam Puisi',
          'Extra night costed for Early Check in, Late Check out',
          'Different Room configuration in Different Cities',
          'Added Item - Hotel',
          'Discount Applied for cost cutting',
          'Adding an Inclusion in Product',
          'Added Flight Discount',
          'Inclusion of 10th person',
          'Adding Buffer',
          'Others'
        ],
        FLIGHT_PANEL: [
          'Flights booked offline On TBO',
          'Flights booked offline On Malindo Portal',
          'Business class or Premium Economy',
          'Diff Departure and arrival cities',
          'Two one way flights instead of round trip',
          'Flights booked by customer',
          'International flights include internal flights',
          'Cost for 10th adult',
          'Different passengers taking different flight options',
          'Spending extra day in transit',
          'Round trip instead of multi city because it is more economical',
          'Return flights on the same day',
          'Passport issues',
          'Surname NA',
          'Specific Flight Option NA in Product',
          'Flight price expensive on Product',
          'Adding Baggage API failed',
          'TBO API down',
          'Booking review page down',
          'Adding Baggage Offline',
          'Taking Different Flight',
          'Removing the Flight',
          'Others'
        ],
        TRAIN_PANEL: [
          'Expensive On Product',
          'Adding Buffer',
          'Cheaper On product',
          'Removing Train',
          'Giving Swiss Pass',
          'Offline Booking',
          'Upgrade to First class',
          'Different Trains',
          'Others'
        ],
        ACTIVITY_PANEL: [
          'Not available on Viator',
          'Cost varies with no.of pax',
          'Cost varies with duration',
          'Others'
        ],
        RENTAL_CAR_PANEL: [
          'Expensive On Product',
          'Cheaper On product',
          'Removing Car Rentals'
        ]
      },
      sources: {
        HOTEL_ROOM_ROW: [
          'TBO',
          'Expedia',
          'Agoda',
          'Booking.com',
          'Aquasun',
          'Direct Hotel',
          'Others'
        ],
        ACTIVITY_PANEL: [
          'Viator',
          'Expedia',
          'Getyourguide',
          'Experience OZ',
          'Suta',
          'Klook',
          'Jeya (Nanayam Travels)',
          'Threeland Travels',
          'Travinno',
          'Rocketbird',
          'Greyline',
          'Direct Website',
          'Others'
        ],
        TRAIN_PANEL: [
          'SNCF',
          'OEBB',
          'Renfe',
          'Sbb',
          'cd.cz',
          'Trenitalia',
          'Bahn.de',
          'Go Euro',
          'Virgin Trains',
          'Trainline',
          'Others'
        ],
        RENTAL_CAR_PANEL: ['THRIFTY', 'GO RENTAL', 'APEX', 'Others'],
        FLIGHT_PANEL: [
          'TBO',
          'MMT',
          'Malindo Airlines',
          'Direct Airline Website',
          'Others',
          'Mystifly',
          'Ryan Air',
          'Easy Jet',
          'Tiger Aur',
          'Jetstar'
        ]
      },

      validationState: {
        newPriceInvalid: false,
        sourceInvalid: false,
        reasonInvalid: false,
        approvedByInvalid: false,
        otherSourceInvalid: false,
        otherReasonInvalid: false
      }
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.updateRates = this.updateRates.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.triggerValidation = this.triggerValidation.bind(this);
  }

  componentDidMount() {
    this.openModal();
    document.addEventListener('keyup', this.handleKeyUp);
  }
  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  openModal() {
    this.setState({ showModal: true, deleteActivity: false }, () => {
      onceModalOpened();
    });
  }

  closeModal() {
    let { history, location, match } = this.props;

    setTimeout(() => {
      onceModalClosed();

      history.push(
        itineraryModalsRouteHelper({
          itineraryId: match.params.itineraryId,
          regionCode: match.params.searchRegion,
          location
        })
      );

    }, 400);
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  triggerValidation() {
    let validationState = this.state.validationState;
    let {
      newPrice,
      source,
      reason,
      approvedBy,
      otherReason,
      otherSource
    } = this.state;
    let { userDetails } = this.props;
    let { called_from } = this.props.match.params;

    if (called_from !== 'FLIGHT_PNR_VALIDITY') {
      validationState.newPriceInvalid = !newPrice.trim().length;
      validationState.approvedByInvalid = !approvedBy.trim().length;

      if (userDetails.loggedIn && userDetails.userType === 'AGENT') {
        validationState.approvedByInvalid = false;
      }

      if (called_from === 'TOTAL_COST' || called_from === 'TOTAL_NET_COST') {
        validationState.sourceInvalid = false;
      } else {
        validationState.sourceInvalid = !source.trim().length;
      }

      if (
        userDetails.loggedIn &&
        userDetails.userType !== 'AGENT' &&
        called_from !== 'TOTAL_NET_COST'
      ) {
        validationState.reasonInvalid = !reason.trim().length;
      } else {
        validationState.reasonInvalid = false;
      }

      validationState.otherSourceInvalid = false;
      if (source.trim().toLowerCase() === 'others') {
        validationState.otherSourceInvalid = !otherSource.trim().length;
      }

      validationState.otherReasonInvalid = false;
      if (
        reason.trim().toLowerCase() === 'others' ||
        reason
          .trim()
          .toLowerCase()
          .endsWith('na in product')
      ) {
        validationState.otherReasonInvalid = !otherReason.trim().length;
      }

      this.setState({ validationState });
    }

    return _.every(_.valuesIn(validationState), e => !e);
  }

  updateRates() {
    if (this.triggerValidation()) {
      let {
        newPrice,
        source,
        reason,
        approvedBy,
        otherReason,
        otherSource
      } = this.state;

      let { userDetails } = this.props;

      let sourceVal = source;
      if (sourceVal === 'Others') {
        sourceVal = otherSource;
      }

      let reasonVal = reason;
      if (reasonVal === 'Others') {
        reasonVal = otherReason;
      }

      let approvedByVal =
        userDetails && userDetails.loggedIn && userDetails.userType === 'AGENT'
          ? `HARI`
          : approvedBy;

      const payload = {
        itineraryId: this.props.match.params.itineraryId,
        discount: newPrice,
        source: sourceVal,
        called_from: this.props.match.params.called_from,
        reason: reasonVal,
        approvedBy: approvedByVal
      };

      switch (this.props.match.params.called_from) {
        case 'HOTEL_ROOM_ROW':
          payload.hotelKey = decodeCostingKeyFromURL(
            this.props.match.params.hotelKey
          );
          payload.roomTypeId = decodeCostingKeyFromURL(
            this.props.match.params.roomTypeId
          );
          this.props.actions
            .applyHotelDiscount(payload)
            .then(() => {
              this.closeModal();
            })
            .catch(() => {
              this.closeModal();
            });
          break;
        case 'RENTAL_CAR_PANEL':
          payload.rentalCarKey = decodeActivityKeyFromURL(
            this.props.match.params.rentalCarKey
          );
          this.props.actions
            .applyRentalCarDiscount(payload)
            .then(() => {
              this.closeModal();
            })
            .catch(() => {
              this.closeModal();
            });
          break;
        case 'FLIGHT_PANEL':
          payload.flightKey = decodeCostingKeyFromURL(
            this.props.match.params.flightKey
          );
          this.props.actions
            .applyFlightDiscount(payload)
            .then(() => {
              this.closeModal();
            })
            .catch(() => {
              this.closeModal();
            });
          break;
        case 'FLIGHT_PNR_VALIDITY':
          const pnr_payload = {
            itineraryId: this.props.match.params.itineraryId,
            expiryDate:
              this.refs.expiryDate.value +
              ' ' +
              this.refs.expiryTime.value +
              ':00.000',
            flightKey: decodeCostingKeyFromURL(
              this.props.match.params.flightKey
            )
          };

          this.props.actions
            .updatePnrValidity(pnr_payload)
            .then(() => {
              this.closeModal();
            })
            .catch(() => {
              this.closeModal();
            });
          break;
        case 'TOTAL_COST':
          this.props.actions
            .applyOverallDiscount(payload)
            .then(() => {
              this.closeModal();
            })
            .catch(() => {
              this.closeModal();
            });
          break;
        case 'ACTIVITY_PANEL':
          payload.activityKey = decodeCostingKeyFromURL(
            this.props.match.params.activityKey
          );
          this.props.actions
            .applyActivityDiscount(payload)
            .then(() => {
              this.closeModal();
            })
            .catch(() => {
              this.closeModal();
            });
          break;
        case 'TOTAL_NET_COST':
          this.props.actions
            .applyAgentNetCostDiscount(payload)
            .then(() => {
              this.closeModal();
            })
            .catch(() => {
              this.closeModal();
            });
          break;
        case 'TRAIN_PANEL':
          payload.trainKey = decodeCostingKeyFromURL(
            this.props.match.params.trainKey
          );
          this.props.actions
            .applyTrainDiscount(payload)
            .then(() => {
              this.closeModal();
            })
            .catch(() => {
              this.closeModal();
            });
          break;
        default:
          break;
      }
    }
  }

  render() {
    let { userDetails } = this.props;
    let { called_from } = this.props.match.params;

    let {
      newPrice,
      source,
      sources,
      reasons,
      reason,
      otherSource,
      otherReason,
      approvedBy,
      validationState
    } = this.state;

    return (
      <div
        tabIndex="-1"
        className={
          'modal fade modal-sticky-header alternate-modal ' +
          (this.state.showModal ? 'in' : '')
        }
        ref="modal"
      >
        <div className="modal-dialog">
          <div className="modal-content with-header">
            <ModalHeader
              {...this.props}
              closeModal={this.closeModal}
              updateRates={this.updateRates}
            />
            <div className="modal-body">
              {called_from === 'FLIGHT_PNR_VALIDITY' ? (
                <div className="double-spacer-top">
                  <div className="row">
                    <div className="col-xs-12 col-xs-push-0 col-md-8 col-md-push-2">
                      <div className="form-group spacer-both">
                        <span className="dim small">Expiry Date</span>
                        <input
                          className="form-control"
                          type="date"
                          ref="expiryDate"
                        />
                      </div>
                      <div className="form-group spacer-both">
                        <span className="dim small">Expiry Time</span>
                        <input
                          className="form-control"
                          type="time"
                          ref="expiryTime"
                          placeholder="hh:mm"
                        />
                        {/* <span className="mini mute block input-prompt">Enter in 24hrs format. For ex 22:00 </span> */}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="double-spacer-top">
                  <div className="row">
                    <div className="col-xs-12 col-xs-push-0 col-md-8 col-md-push-2">
                      <div
                        className={classNames('form-group spacer-both', {
                          'has-error': validationState.newPriceInvalid
                        })}
                      >
                        <span className="small dim">Price in INR</span>
                        <input
                          className="form-control"
                          type="number"
                          ref="newPrice"
                          value={newPrice}
                          onChange={e =>
                            this.setState({ newPrice: e.target.value })
                          }
                          placeholder={'Discount price in INR'}
                        />
                      </div>
                      {called_from !== 'TOTAL_COST' &&
                      called_from !== 'TOTAL_NET_COST' &&
                      called_from !== 'FLIGHT_PNR_VALIDITY' ? (
                        <div
                          className={classNames('form-group spacer-both', {
                            'has-error': validationState.sourceInvalid
                          })}
                        >
                          <span className="small dim">Source</span>
                          <select
                            className="form-control"
                            ref="source"
                            value={source}
                            onChange={e =>
                              this.setState({ source: e.target.value })
                            }
                            required
                          >
                            <option value="">--</option>
                            {sources[called_from] &&
                              sources[called_from].map((option, inx) => {
                                return (
                                  <option
                                    value={option}
                                    key={'option_' + called_from + '_' + inx}
                                  >
                                    {option}
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                      ) : null}

                      {called_from !== 'TOTAL_COST' &&
                      called_from !== 'TOTAL_NET_COST' &&
                      called_from !== 'FLIGHT_PNR_VALIDITY' &&
                      source === 'Others' ? (
                        <div
                          className={classNames('form-group spacer-both', {
                            'has-error': validationState.otherSourceInvalid
                          })}
                        >
                          <input
                            className="form-control"
                            type="text"
                            ref="otherSource"
                            value={otherSource}
                            onChange={e =>
                              this.setState({ otherSource: e.target.value })
                            }
                            placeholder={'Type your other source'}
                          />
                        </div>
                      ) : null}

                      {userDetails.loggedIn &&
                      userDetails.userType !== 'AGENT' &&
                      called_from !== 'TOTAL_NET_COST' &&
                      called_from !== 'FLIGHT_PNR_VALIDITY' ? (
                        <div
                          className={classNames('form-group spacer-both', {
                            'has-error': validationState.reasonInvalid
                          })}
                        >
                          <span className="small dim">Reason</span>
                          <select
                            className="form-control"
                            ref="reason"
                            value={reason}
                            onChange={e =>
                              this.setState({ reason: e.target.value })
                            }
                            required
                          >
                            <option value="">--</option>
                            {reasons[called_from] &&
                              reasons[called_from].map((option, inx) => {
                                return (
                                  <option
                                    value={option}
                                    key={'option_' + called_from + '_' + inx}
                                  >
                                    {option}
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                      ) : null}

                      {called_from !== 'TOTAL_NET_COST' &&
                      called_from !== 'FLIGHT_PNR_VALIDITY' &&
                      this.state.reason &&
                      (this.state.reason === 'Others' ||
                        this.state.reason
                          .toLowerCase()
                          .endsWith('na in product')) ? (
                        <div
                          className={classNames('form-group spacer-both', {
                            'has-error': validationState.otherReasonInvalid
                          })}
                        >
                          <input
                            className="form-control"
                            type="text"
                            ref="otherReason"
                            value={otherReason}
                            onChange={e =>
                              this.setState({ otherReason: e.target.value })
                            }
                            placeholder={
                              reason === 'Others'
                                ? 'Type your other reason'
                                : 'Type the option that is NA'
                            }
                          />
                        </div>
                      ) : null}

                      {userDetails.loggedIn &&
                      userDetails.userType !== 'AGENT' ? (
                        <div
                          className={classNames('form-group spacer-both', {
                            'has-error': validationState.approvedByInvalid
                          })}
                        >
                          <span className="small dim">Approved By</span>
                          <select
                            className="form-control"
                            ref="approvedBy"
                            value={approvedBy}
                            onChange={e =>
                              this.setState({ approvedBy: e.target.value })
                            }
                            required
                          >
                            <option value="">--</option>
                            <option value="HARI">Hari</option>
                            <option value="SRINATH">Srinath</option>
                            <option value="SANJAY">Sanjay</option>
                            <option value="RAJ">Raj</option>
                            <option value="MANISH">Manish</option>
                            <option value="MAHESH">Mahesh</option>
                          </select>
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <SweetAlert
          show={this.state.showAlert}
          title="Sorry, unable to apply rate match"
          text={`Apologies, seems like a network issue in Pickyourtrail. Could you please try once again.`}
          animation="pop"
          onConfirm={() => this.setState({ showAlert: false })}
        />
      </div>
    );
  }
}

const ModalHeader = props => {
  return (
    <div className="modal-header with-bg">
      <button
        type="button"
        onClick={props.closeModal}
        className="close"
        aria-label="Close"
      >
        <span className="vehoicon-close" aria-hidden="true" />
      </button>
      {props.called_from === 'FLIGHT_PNR_VALIDITY' ? (
        <span className={'caps-text semi-bold kern-more fade'}>
          Enter PNR validity
        </span>
      ) : (
        <span className={'caps-text semi-bold kern-more fade'}>
          Enter {props.called_from !== 'TOTAL_COST' ? 'New' : 'Discount'} Price
        </span>
      )}
      <div className="modal-actions right">
        <button
          type="button"
          className="btn btn-sm btn-primary btn-orange"
          onClick={() => props.updateRates()}
        >
          <span className="hidden-xs hidden-sm">Update</span>
          <span className="visible-xs visible-sm  vehoicon-mode_edit" />
        </button>
      </div>
    </div>
  );
};

function mapStateToProps(state) {
  let app = state.app;
  return {
    discountRequested: app.discountRequested,
    userDetails: app.user_details
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      applyHotelDiscount: bindActionCreators(applyHotelDiscount, dispatch),
      applyRentalCarDiscount: bindActionCreators(
        applyRentalCarDiscount,
        dispatch
      ),
      applyFlightDiscount: bindActionCreators(applyFlightDiscount, dispatch),
      updatePnrValidity: bindActionCreators(updatePnrValidity, dispatch),
      applyOverallDiscount: bindActionCreators(applyOverallDiscount, dispatch),
      applyActivityDiscount: bindActionCreators(
        applyActivityDiscount,
        dispatch
      ),
      applyAgentNetCostDiscount: bindActionCreators(
        applyAgentNetCostDiscount,
        dispatch
      ),
      applyTrainDiscount: bindActionCreators(applyTrainDiscount, dispatch),
      dissolveDiscount: bindActionCreators(dissolveDiscount, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(RateMatchModal);
