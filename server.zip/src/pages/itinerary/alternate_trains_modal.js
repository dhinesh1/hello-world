import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import axios from 'axios';

import PriceDiff from '../../common_components/price_diff';
import { updateTrain } from '../../actions/actions_app';

import { AppConfig } from '../../app-config';
import {
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import { itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';
const API_URL = AppConfig.api_url;
const IMAGE_CDN = AppConfig.images_cdn_misc_url;
/*global swal */

class AlternateTrainsModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      activeTrainDetails: {},
      componentStatus: 'IDLE',
      alternateTrains: []
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.getAlternateTrains = this.getAlternateTrains.bind(this);
    this.handleReplaceButtonClick = this.handleReplaceButtonClick.bind(this);
    this.viewDetails = this.viewDetails.bind(this);
    this.renderAlternateLength = this.renderAlternateLength.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }
  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.trainCostings &&
      !Object.keys(this.state.activeTrainDetails).length
    ) {
      let currentKey = this.props.match.params.trainKey;
      currentKey = decodeCostingKeyFromURL(currentKey);

      let currentDetail =
        props.itineraryInfo.trainCostings.trainCostingById[currentKey];

      if (!currentDetail) {
        this.closeModal();
      }

      this.setState({ activeTrainDetails: currentDetail }, () => {
        let reqData = {
          itineraryId: props.itineraryDetail.itineraryId,
          costingKey: currentKey,
        };

        this.getAlternateTrains(reqData);
      });
    }
  }

  getAlternateTrains(data) {
    const url = `${API_URL}itinerary/alternateTrains`;
    axios
      .post(url, data)
      .then(response => {
        this.setState({
          alternateTrains: response.data.data.alternateTrains,
          showModal: true
        });
      })
      .catch(e => {
        console.warn(e);

        swal({
          title: 'Sorry about this!',
          text:
            'Sorry about this. But there seems to be an issue with Pickyourtrail.',
          animation: true,
          showCancelButton: false,
          confirmButtonColor: '#DD6B55',
          confirmButtonText: 'Try again!',
          cancelButtonText: 'No, cancel!',
          closeOnConfirm: true,
          closeOnCancel: true
        });
      });
  }

  handleReplaceButtonClick(newTrain) {
    this.props
      .updateTrain({
        itineraryId: this.props.itineraryDetail.itineraryId,
        trainCostingKey: this.state.activeTrainDetails.key,
        newTrainId: newTrain.trainId,
        trainCostingId: this.state.activeTrainDetails.trainCostingId
      })
      .then(() => {
        this.closeModal(true);
      })
      .catch(() => {
        this.closeModal(true);
      });
  }

  viewDetails(newTrain) {
    // this.props.showThisModal('trainDetailsModal', {
    //   ...this.state.activeTrainDetails,
    //   ...newTrain,
    //   called_from: 'ALTERNATE_TRAINS',
    //   trainBeingReplaced: this.state.activeTrainDetails
    // });
    // this.closeModal();
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  openModal() {
    this.setState({ showModal: true }, () => {
      onceModalOpened();
    });
  }

  closeModal(replace = false) {
    let { history, match, itineraryDetail } = this.props;

    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        onceModalClosed();

        if (replace) {
          history.replace(
            itineraryModalsRouteHelper({
              itineraryId: itineraryDetail.itineraryId,
              regionCode: itineraryDetail.regionCode,
              parentPage: routingPageType.inclusion
            })
          );
        } else {
          history.push(
            itineraryModalsRouteHelper({
              itineraryId: itineraryDetail.itineraryId,
              regionCode: itineraryDetail.regionCode,
              parentPage: routingPageType.inclusion
            })
          );
        }
      });
    }, 400);
  }

  renderAlternateLength() {
    if (this.state.alternateTrains && this.state.alternateTrains.length > 0) {
      return (
        <span className="mini block dim bold text-center spacer">
          {this.state.alternateTrains.length} available options to choose from
        </span>
      );
    }
  }

  render() {
    let { activeTrainDetails, showModal, alternateTrains } = this.state;

    return (
      <div
        tabIndex="0"
        className={
          'modal fade alternate-modal auto-width modal-sticky-header ' +
          (showModal ? 'in' : '')
        }
        ref="modal"
      >
        <div className={'modal-dialog'}>
          <div className={'modal-content with-header'}>
            <ModalHeaderNew
              splitPricing={this.props.itineraryDetail.splitPricing}
              {...activeTrainDetails}
              onClose={this.closeModal}
            />

            <div className="modal-body">
              <div className="current-pick-panel">
                <div className="current-pick-content hotel">
                  <div className="col-xs-9 col-md-10">
                    {/* <a className="toggle-panel" href="#"><span className="vehoicon-arrow_downward" /><span className="sr-only">More info</span></a> */}
                    <span className="single-line-text fade small no-margin">
                      Changing: {activeTrainDetails.pickup} -{' '}
                      {activeTrainDetails.drop}
                    </span>
                  </div>
                  {activeTrainDetails.publishedCost ? (
                    <div className="col-xs-3 col-md-2 text-right">
                      {!activeTrainDetails.inCombo ? (
                        <span className="total-price small bold dim">
                          <span className="WebRupee">Rs.</span>{' '}
                          {activeTrainDetails.publishedCost}
                        </span>
                      ) : (
                          <span className="in-combo for-current-pick">
                            IN COMBO
                        </span>
                        )}
                    </div>
                  ) : null}
                </div>
              </div>

              <div className="modal-row">
                {alternateTrains && alternateTrains.length > 0
                  ? this.renderAlternateLength()
                  : null}
                <section className="change-data flat-list">
                  {alternateTrains &&
                    alternateTrains.length > 0 &&
                    alternateTrains.map(train => (
                      <TrainOption
                        key={activeTrainDetails.key + train.trainId}
                        {...train}
                        splitPricing={this.props.itineraryDetail.splitPricing}
                        handleReplaceButtonClick={this.handleReplaceButtonClick}
                        viewDetails={this.viewDetails}
                      />
                    ))}
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const ModalHeaderNew = props => {
  return (
    <div className="modal-header">
      <button
        type="button"
        onClick={props.onClose}
        className="close"
        aria-label="Close"
      >
        <span className="vehoicon-close" aria-hidden="true" />
      </button>
      <span className="text-uppercase kern-more bolder fade">Change Train</span>
    </div>
  );
};

const TrainOption = props => {
  return (
    <article
      className="data-option-item zoomable"
      onClick={() => props.viewDetails(props)}
    >
      <div className="data-option-item-wrapper">
        <div className="col-xs-9 col-sm-10 col-md-10 no-padding">
          <div className="col-xs-12 col-sm-12 col-md-12">
            <div className="row spacer-both">
              <div className="col-xs-3 col-sm-3 col-md-3">
                <div className="media-shell">
                  <figure className="hd">
                    <img
                      src={props.image || `${IMAGE_CDN}transfers-train.jpg`}
                    />
                  </figure>
                </div>
              </div>
              <div className="col-xs-9 col-sm-9 col-md-9 flight-cell">
                <div className="hidden-xs col-sm-6 col-md-5 no-padding">
                  <time className="block">{props.departureTime}</time>
                  <span className="mini single-line-text dim">
                    {props.pickup}
                  </span>
                  <span className="mini single-line-text dim">
                    {props.stops}
                  </span>
                </div>
                <div className="hidden-xs col-sm-6 col-md-5">
                  <time className="block">{props.arrivalTime}</time>
                  <span className="mini single-line-text dim">
                    {props.drop}
                  </span>
                  <span className="mini single-line-text dim">
                    {props.duration}
                  </span>
                </div>
                <div className="col-xs-12 hidden-sm hidden-md hidden-lg flight-cell">
                  <time className="block">
                    {props.departureTime}—{props.arrivalTime}
                  </time>
                  <span className="mini single-line-text dim">
                    {props.pickup} - {props.drop}
                  </span>
                  <span className="mini single-line-text dim">
                    {props.duration}, {props.stops}
                  </span>
                </div>
                <div className="icon-attributes">
                  <span className="vehoicon-non-refundable" />
                  {/*<span className="seats">10</span>*/}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xs-3 col-sm-2 col-md-2 spacer-both no-padding">
          <div className="action price-info text-center">
            {props.cost ? (
              <span className="price block">
                <span className="WebRupee">Rs.</span>
                {props.cost}
              </span>
            ) : null}
            {props.diffDetail && props.diffDetail.diffCost >= 0 ? (
              <PriceDiff diff={props.diffDetail} classNames={'price block'} />
            ) : null}
            <a
              className="btn btn-xs btn-primary hidden-sm hidden-xs"
              onClick={e => {
                e.preventDefault();
                e.stopPropagation();
                e.nativeEvent.stopImmediatePropagation();
                props.handleReplaceButtonClick(props);
              }}
            >
              Choose
            </a>
            <a
              className="btn btn-sm btn-primary show-xs-sm"
              onClick={e => {
                e.preventDefault();
                e.stopPropagation();
                e.nativeEvent.stopImmediatePropagation();
                props.handleReplaceButtonClick(props);
              }}
            >
              Choose
            </a>
          </div>
        </div>
      </div>
    </article>
  );
};

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

const mapDispatchToProps = dispatch => {
  return {
    updateTrain: bindActionCreators(updateTrain, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(
  AlternateTrainsModal
);
