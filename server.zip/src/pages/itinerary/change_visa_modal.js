import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { changeVisa } from '../../actions/actions_app';

import PriceDiff from '../../common_components/price_diff';
import {
  decodeActivityKeyFromURL,
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import _ from 'lodash';
import { itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';
class ChangeVisaModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      isLoading: false,
      passwordInvalid: false,
      otp_value: '',
      errorMessage: '',
      familiesForVisa: this.props.membersInFamilies
        ? this.props.membersInFamilies.map(mif => {
            return { memberCount: mif };
          })
        : [],
      families: this.props.familyVisas,
      individualCount: this.props.individualVisas || 0, //this.props.adult_count + this.props.child_count,
      prevTotalCost: this.props.totalCost,
      totalCost: this.props.totalCost,
      currentlySelectedCost: this.props.totalCost,
      currentlySelectedVisa: {},
      updateCost: null
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.changeMemberCount = this.changeMemberCount.bind(this);
    this.addFamilyForVisa = this.addFamilyForVisa.bind(this);
    this.changeIndividualCount = this.changeIndividualCount.bind(this);
    this.renderTotalCost = this.renderTotalCost.bind(this);

    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);
    this.setState({
      updateCost: this.props.itineraryInfo.visaCostings.totalVisaCost
    });

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  componentWillUpdate(nextProps) {
    if (
      this.props.individualVisas !== nextProps.individualVisas ||
      this.props.familyVisas !== nextProps.familyVisas ||
      this.props.totalCost !== nextProps.totalCost
    )
      this.setState({
        totalCost: nextProps.totalCost,
        prevTotalCost: nextProps.totalCost,
        familiesForVisa: nextProps.membersInFamilies
          ? nextProps.membersInFamilies.map(mif => {
              return { memberCount: mif };
            })
          : [],
        families: nextProps.familyVisas,
        individualCount: nextProps.individualVisas || 0 //this.props.adult_count + this.props.child_count,
      });
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.visaCostings &&
      !Object.keys(this.state.currentlySelectedVisa).length
    ) {
      let currentSlotKey = this.props.match.params.visaKey;
      currentSlotKey = decodeCostingKeyFromURL(currentSlotKey);
      // console.log(currentSlotKey);

      let currentDetail =
        props.itineraryInfo.visaCostings.visaCostingById[currentSlotKey];
      // console.log(currentDetail);
      let familiesForVisa = [];
      if (currentDetail.familyVisas) {
        for (let i = 0; i < currentDetail.familyVisas; i++) {
          familiesForVisa.push({
            memberCount: currentDetail.membersInFamilies[i]
          });
        }
      }
      this.setState({
        familiesForVisa: familiesForVisa,
        currentlySelectedVisa: currentDetail,
        individualVisaCost: currentDetail.individualVisaCost,
        familyVisaCost: currentDetail.familyVisaCost,
        totalCost: props.itineraryInfo.visaCostings.totalVisaCost,
        individualVisas: currentDetail.individualVisas,
        individualCount: currentDetail.individualVisas || 0,
        familyVisas: currentDetail.familyVisas,
        membersInFamilies: currentDetail.membersInFamilies
          ? currentDetail.membersInFamilies.map(mif => {
              return { memberCount: mif };
            })
          : []
      });
    }
  }

  totalMemberCount(individualCount, familiesForVisa) {
    if (
      typeof individualCount === 'undefined' &&
      typeof familiesForVisa === 'undefined'
    )
      return 0;
    else
      return (
        individualCount +
        familiesForVisa.reduce((sum, element) => sum + element.memberCount, 0)
      );
  }

  changeMemberCount(type, index) {
    const totalCount = this.totalMemberCount(
      this.state.individualCount,
      this.state.familiesForVisa
    );

    const familiesForVisa = [...this.state.familiesForVisa];
    familiesForVisa[index].memberCount = Math.min(
      Math.max(
        familiesForVisa[index].memberCount + (type === 'reduce' ? -1 : 1),
        0
      ),
      Math.min(4, this.props.adult_count + this.props.child_count)
    ); //- totalCount));

    if (familiesForVisa[index].memberCount === 0)
      familiesForVisa.splice(index, 1);

    const individualCount =
      totalCount === this.props.adult_count + this.props.child_count
        ? Math.min(
            Math.max(
              this.state.individualCount + (type === 'reduce' ? 1 : -1),
              0
            ),
            this.props.adult_count + this.props.child_count
          )
        : this.state.individualCount;

    const individualCost = (
      this.state.currentlySelectedVisa.individualVisaCost || ''
    ).replace(/,/g, '');
    const familyVisaCost = (
      this.state.currentlySelectedVisa.familyVisaCost || ''
    ).replace(/,/g, '');

    this.setState({
      ...this.state,
      individualCount: individualCount,
      familiesForVisa: familiesForVisa,
      prevTotalCost: this.state.totalCost,
      totalCost:
        individualCount * individualCost +
        familiesForVisa.length * familyVisaCost
    });
  }

  addFamilyForVisa() {
    const totalCount = this.totalMemberCount(
      this.state.individualCount,
      this.state.familiesForVisa
    );

    const individualCount =
      totalCount === this.props.adult_count + this.props.child_count
        ? Math.max(this.state.individualCount - 1, 0)
        : this.state.individualCount;
    const familiesForVisa =
      this.state.individualCount === 0 &&
      totalCount === this.props.adult_count + this.props.child_count
        ? [...this.state.familiesForVisa]
        : [...this.state.familiesForVisa, { memberCount: 1 }];

    const individualCost = (
      this.state.currentlySelectedVisa.individualVisaCost || ''
    ).replace(/,/g, '');
    const familyVisaCost = (
      this.state.currentlySelectedVisa.familyVisaCost || ''
    ).replace(/,/g, '');

    this.setState({
      ...this.state,
      familiesForVisa: familiesForVisa,
      individualCount: individualCount,
      prevTotalCost: this.state.totalCost,
      totalCost:
        individualCount * individualCost +
        familiesForVisa.length * familyVisaCost
    });
  }

  changeIndividualCount(type) {
    const totalCount = this.totalMemberCount(
      this.state.individualCount,
      this.state.familiesForVisa
    );
    const individualCount = Math.min(
      Math.max(this.state.individualCount + (type === 'reduce' ? -1 : 1), 0),
      this.props.adult_count + this.props.child_count
    );
    const familiesForVisa = [...this.state.familiesForVisa];
    const familyCount = familiesForVisa.length;

    const individualCost = (
      this.state.currentlySelectedVisa.individualVisaCost || ''
    ).replace(/,/g, '');
    const familyVisaCost = (
      this.state.currentlySelectedVisa.familyVisaCost || ''
    ).replace(/,/g, '');

    if (
      familyCount > 0 &&
      type === 'add' &&
      totalCount >= this.props.adult_count + this.props.child_count
    ) {
      familiesForVisa[familyCount - 1].memberCount = Math.max(
        familiesForVisa[familyCount - 1].memberCount - 1,
        0
      );
      familiesForVisa[familyCount - 1].memberCount === 0 &&
        familiesForVisa.splice(familyCount - 1, 1);
    }

    this.setState({
      ...this.state,
      individualCount: individualCount,
      familiesForVisa: familiesForVisa,
      prevTotalCost: this.state.totalCost,
      totalCost:
        individualCount * individualCost +
        familiesForVisa.length * familyVisaCost
    });
  }

  handleUpdateClick(e) {
    e && e.preventDefault();

    this.props
      .changeVisa({
        itineraryId: this.props.itineraryDetail.itineraryId,
        visaKey: this.state.currentlySelectedVisa.key,
        include: true,
        individuals: this.state.individualCount,
        families: this.state.familiesForVisa.map(
          familyForVisa => familyForVisa.memberCount
        )
      })
      .then(() => {
        this.closeModal();
      })
      .catch(() => {
        this.closeModal();
      });
  }

  openModal() {
    this.setState(
      {
        showModal: true
      },
      () => {
        onceModalOpened();
      }
    );
  }

  closeModal() {
    let { history, itineraryDetail } = this.props;

    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        onceModalClosed();

        history.push(
          itineraryModalsRouteHelper({
            itineraryId: itineraryDetail.itineraryId,
            regionCode: itineraryDetail.regionCode,
            parentPage: routingPageType.inclusion
          })
        );
      });
    }, 400);
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  shouldComponentUpdate(props) {
    if (this.state.updateCost != null) {
      return (
        this.state.updateCost === props.itineraryInfo.visaCostings.totalVisaCost
      );
    }
    return true;
  }

  renderTotalCost() {
    let existingCost = this.props.itineraryInfo.visaCostings.totalVisaCost
      ? parseInt(
          this.props.itineraryInfo.visaCostings.totalVisaCost
            .toString()
            .replace(/,/g, '')
        )
      : 0;
    let newCost = this.state.totalCost
      ? parseInt((this.state.totalCost || '').toString().replace(/,/g, ''))
      : 0;
    let priceDiff = newCost - existingCost;
    let priceDiffDisplay = Math.abs(priceDiff);

    if (priceDiff > 0) {
      return (
        <PriceDiff
          tooltip={false}
          diff={{ diffChangeType: 'PRICEINCREASE', diffCost: priceDiffDisplay }}
          classNames={'total-price base bold'}
        />
      );
    } else if (priceDiff < 0) {
      return (
        <PriceDiff
          tooltip={false}
          diff={{ diffChangeType: 'PRICEDECREASE', diffCost: priceDiffDisplay }}
          classNames={'total-price base bold'}
        />
      );
    } else {
      return this.state.totalCost ? (
        <span className="total-price base bold">
          <span className="WebRupee">Rs.</span> {this.state.totalCost}
        </span>
      ) : null;
    }
  }

  render() {
    let totalCount = this.totalMemberCount(
      this.state.individualCount,
      this.state.familiesForVisa
    );
    let isExist =
      totalCount === this.props.adult_count + this.props.child_count;
    return (
      <div
        tabIndex="0"
        ref="modal"
        className={
          'modal fade modal-sticky-header alternate-modal ' +
          (this.state.showModal ? 'in' : '')
        }
      >
        <div className="modal-dialog">
          <div className={'modal-content with-header'}>
            <div className="modal-header clearfix">
              <div className="pull-right">
                <button
                  type="button"
                  onClick={e => this.handleUpdateClick(e)}
                  className="btn btn-primary btn-sm change-cta"
                  disabled={!isExist}
                >
                  Apply
                </button>
              </div>
              <span className="caps-text semi-bold kern-more fade">
                Change visa type
              </span>
              <button
                type="button"
                onClick={this.closeModal}
                className="close pull-left"
                data-dismiss="modal"
              >
                <i className="vehoicon-close" />
              </button>
            </div>

            <div className="modal-body">
              <div className="current-pick-panel">
                <div className="current-pick-content hotel">
                  <div className="col-xs-9 col-md-10">
                    <span className="single-line-text fade small no-margin">
                      Total cost for{' '}
                      {this.totalMemberCount(
                        this.state.individualCount,
                        this.state.familiesForVisa
                      )}{' '}
                      of {this.props.adult_count + this.props.child_count}{' '}
                      travellers
                    </span>
                  </div>
                  <div className="col-xs-3 col-md-2 text-right">
                    {!this.props.itineraryDetail.splitPricing ? (
                      this.renderTotalCost()
                    ) : (
                      <span className="total-price base bold">
                        <span className="WebRupee">Rs.</span>{' '}
                        {this.state.totalCost}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="modal-row pl-0 pr-0">
                <div className="column-pad">
                  <div className="row flex vertical-center hidden-xs spacer-top">
                    <div className="col-md-3 col-xs-12 ">
                      <span className="base fade">Type</span>
                    </div>
                    <div className="col-md-6 col-xs-12 ">
                      <span className="base fade">
                        {this.props.itineraryDetail.splitPricing
                          ? 'Cost'
                          : 'Inclusion'}
                      </span>
                    </div>
                    <div className="col-md-3 hidden-xs">&nbsp;</div>
                  </div>
                  <hr className="mute spacer hidden-xs" />
                  <div className="row spacer-both">
                    <div className="col-md-3 col-xs-12">
                      <span className="base fade">Individuals</span>
                    </div>
                    <div className="col-xs-7 col-sm-6">
                      {this.props.itineraryDetail.splitPricing ? (
                        <span className="base fade">
                          <span className="WebRupee">Rs.</span>{' '}
                          {this.state.currentlySelectedVisa &&
                            this.state.currentlySelectedVisa.individualVisaCost}
                          <span className="fine-text">
                            {' '}
                            (Per visa, per individual)
                          </span>
                        </span>
                      ) : null}
                      <span className="block fine-text">
                        Visa to be taken separately for each passenger
                        travelling
                      </span>
                    </div>
                    <div className="col-md-3 col-sm-6 col-xs-5 actions text-right">
                      <div
                        className="visa-btn-grp btn-group v-spaced"
                        role="group"
                        aria-label
                      >
                        <button
                          type="button"
                          className="btn btn-sm  btn-primary"
                          disabled={this.state.individualCount <= 0}
                          onClick={() => this.changeIndividualCount('reduce')}
                        >
                          <span className="vehoicon-remove_circle small" />
                        </button>
                        <button
                          type="button"
                          className="btn btn-sm btn-default"
                        >
                          <span className="inline-block">
                            {this.state.individualCount}
                          </span>
                        </button>
                        <button
                          type="button"
                          className="btn btn-sm  btn-primary"
                          disabled={
                            this.state.individualCount >=
                            this.props.adult_count + this.props.child_count
                          }
                          onClick={() => this.changeIndividualCount('add')}
                        >
                          <span className="vehoicon-add_circle small" />
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="row spacer-both">
                    <div className="col-md-3 col-xs-12 ">
                      <span className="base fade">Families</span>
                    </div>
                    <div className="col-xs-9 col-sm-6">
                      {this.props.itineraryDetail.splitPricing ? (
                        <span className="block base fade">
                          <span className="WebRupee">Rs.</span>&nbsp;{this.state
                            .currentlySelectedVisa &&
                            this.state.currentlySelectedVisa.familyVisaCost}
                          <span className="fine-text">
                            * (Per visa, Valid upto 4 members)
                          </span>
                        </span>
                      ) : null}
                      <span className="block fine-text">
                        Single Family Visa covers husband, wife and dependent
                        children traveling together. [Marriage certificate
                        required]
                      </span>
                    </div>
                    <div className="col-md-3 col-xs-3 actions text-right">
                      <button
                        className="btn btn-sm btn-primary-dark btn-outline"
                        disabled={
                          this.totalMemberCount(
                            0,
                            this.state.familiesForVisa
                          ) >=
                          this.props.adult_count + this.props.child_count
                        }
                        onClick={() => {
                          this.addFamilyForVisa();
                        }}
                      >
                        Add
                      </button>
                    </div>
                  </div>
                  {this.state.familiesForVisa.map((familyForVisa, index) => (
                    <FamilyForVisa
                      {...familyForVisa}
                      key={index}
                      index={index}
                      changeMemberCount={this.changeMemberCount}
                      disabled={
                        this.state.individualCount === 0 &&
                        this.props.adult_count + this.props.child_count <=
                          this.totalMemberCount(
                            this.state.individualCount,
                            this.state.familiesForVisa
                          )
                      }
                    />
                  ))}
                  <span className="block mini fade">
                    * Does not include individual VFS fee
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

// ChangeVisaModal.defaultProps = {
//   adult_count: 2,
//   child_count: 1,
//   individualVisaCost: 2000,
//   familyVisaCost: 1500,
//   totalCost: 22000
// };

const FamilyForVisa = props => {
  return (
    <div className="row spacer-both">
      <div className="col-md-3 col-xs-12 hidden-xs">
        <span>&nbsp;</span>
      </div>
      <div className="col-xs-7 col-sm-6">
        <span className="small fade">
          Number of members in family #{props.index + 1}
        </span>
      </div>
      <div className="col-md-3 col-sm-6 col-xs-5 actions text-right">
        <div className="btn-group" role="group" aria-label>
          <button
            type="button"
            className="btn btn-sm  btn-primary"
            disabled={props.memberCount <= 0}
            onClick={() => props.changeMemberCount('reduce', props.index)}
          >
            <span className="vehoicon-remove_circle small" />
          </button>
          <button type="button" className="btn btn-sm btn-default">
            <span className="inline-block">{props.memberCount}</span>
          </button>
          <button
            type="button"
            className="btn btn-sm  btn-primary"
            disabled={props.disabled || props.memberCount === 4}
            onClick={() => props.changeMemberCount('add', props.index)}
          >
            <span className="vehoicon-add_circle small" />
          </button>
        </div>
      </div>
    </div>
  );
};

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    changeVisa: bindActionCreators(changeVisa, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(ChangeVisaModal);
