import React, { Component } from 'react';
import classNames from 'classnames';
import axios from 'axios';

import { AppConfig } from '../../app-config';
import {
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import { changeTransferMode } from '../../actions/actions_app';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { itineraryModalsRouteHelper } from '../../helpers/routesHelper';
const API_URL = AppConfig.api_url;

/*global swal */

class MultiModeTransferModal extends Component {
  constructor(props) {
    super(props);

    this.state = { showModal: false, data: {}, currentPick: {} };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.handleSelect = this.handleSelect.bind(this);
    this.getTransfersOptions = this.getTransfersOptions.bind(this);
    this.getTransferModeIcons = this.getTransferModeIcons.bind(this);

    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      !Object.keys(this.state.currentPick).length
    ) {
      let { currentMode, prevCityKey, nextCityKey } = this.props.match.params;

      let currentDetail = {};
      currentDetail.currentMode = currentMode;
      currentDetail.fromCityId = prevCityKey.split('_')[0];
      currentDetail.toCityId = nextCityKey.split('_')[0];

      this.setState({ currentPick: currentDetail }, () => {
        this.getTransfersOptions(currentDetail);
      });
    }
  }

  openModal() {
    this.setState({ showModal: true, deleteActivity: false }, () => {
      onceModalOpened();
    });
  }

  closeModal(replace = false) {
    let { history, match } = this.props;

    setTimeout(() => {
      this.setState({ showModal: false, deleteActivity: false }, () => {
        onceModalClosed();

        const itineraryPageURL = itineraryModalsRouteHelper({
          itineraryId: match.params.itineraryId,
          regionCode: match.params.searchRegion
        });

        if (replace) {
          history.replace(itineraryPageURL);
        } else {
          history.push(itineraryPageURL);
        }
      });
    }, 400);
  }

  getTransfersOptions(transfer) {
    this.setState({ requestPayload: transfer });
    let currentMode = transfer.currentMode;

    const url = `${API_URL}itinerary/transfer/alternateModes`;
    axios
      .post(url, {
        fromCity: transfer.fromCityId,
        toCity: transfer.toCityId,
        transitCity: 0,
        currentModes: [currentMode]
      })
      .then(response => {
        this.setState({
          data: response.data.data
        });
      })
      .catch(() => {
        swal('Something went wrong. Try again.');
      });
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  getTransferIcon(transferMode, inx) {
    switch (transferMode) {
      case 'RENTALCAR':
      case 'CAR':
        return (
          <span key={'mode_icon_' + inx} className="vehoicon-directions_car" />
        );
      case 'TRAIN': {
        return <span key={'mode_icon_' + inx} className="vehoicon-train" />;
      }
      case 'FERRY': {
        return (
          <span key={'mode_icon_' + inx} className="vehoicon-directions_boat" />
        );
      }
      case 'BUS': {
        return (
          <span key={'mode_icon_' + inx} className="vehoicon-directions_bus" />
        );
      }
      case 'SHUTTLE': {
        return (
          <span key={'mode_icon_' + inx} className="vehoicon-directions_bus" />
        );
      }
      case 'FLIGHT': {
        return <span key={'mode_icon_' + inx} className="vehoicon-flight" />;
      }
      case 'FLIGHT_ARRIVE': {
        return (
          <span key={'mode_icon_' + inx} className="vehoicon-flight_land" />
        );
      }
      case 'FLIGHT_DEPART': {
        return (
          <span key={'mode_icon_' + inx} className="vehoicon-flight_takeoff" />
        );
      }
      case 'HOTEL': {
        return (
          <span
            key={'mode_icon_' + inx}
            className="vehoicon-airline_seat_individual_suite"
          />
        );
      }
      default:
        return;
    }
  }

  getTransferModeIcons(item) {
    return item.modes.map((mode, inx) => {
      return this.getTransferIcon(mode, inx);
    });
  }

  handleSelect(item) {
    let { match, itineraryDetail } = this.props;

    let req_data = {
      itineraryId: itineraryDetail.itineraryId,
      prevCityKey: match.params.prevCityKey,
      nextCityKey: match.params.nextCityKey,
      transitCity: 0,
      newModes: item.modes
    };

    this.props
      .changeTransferMode(req_data)
      .then(() => {
        this.closeModal();
      })
      .catch(() => {
        this.closeModal();
      });
  }

  render() {
    return (
      <div
        tabIndex="0"
        ref="modal"
        className={classNames(
          'modal fade modal-sticky-header alternate-modal',
          { in: this.state.showModal }
        )}
      >
        <div className="modal-dialog">
          <div className="modal-content with-header">
            <ModalHeader {...this.props} onCloseModal={this.closeModal} />
            <div className="modal-body">
              <ModalDetails
                {...this.state}
                getTransferModeIcons={this.getTransferModeIcons}
                handleSelect={this.handleSelect}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const ModalHeader = props => {
  return (
    <div className="modal-header">
      <span className="text-uppercase kern-more bolder fade">
        Change mode of transfer
      </span>
      <button type="button" onClick={props.onCloseModal} className="close">
        <i className="vehoicon-close" aria-hidden="true" />
      </button>
    </div>
  );
};

const ModalDetails = props => {
  return (
    <div className="modal-row pt-0">
      <div className="item-header">
        <p className="spacer-both text-center fade base">
          Choose your preferred mode of transfer from{' '}
          <b>{props.data.fromCity}</b> to <b>{props.data.toCity}</b>
        </p>
      </div>

      <div className="spacer-both">
        <div className="clearfix spacer alternate-transfers-wrapper text-center">
          {Object.keys(props.data).length > 0
            ? props.data.alternateModes.map(function(item, inx) {
                return (
                  <div
                    key={'alternate_modes_' + inx}
                    className="inline-block options-wrapper"
                  >
                    <div
                      onClick={() => props.handleSelect(item)}
                      className={
                        'cursor-pointer alternate-option ' +
                        (item.chosen ? 'active' : '')
                      }
                    >
                      <div className="icons-block">
                        {props.getTransferModeIcons(item)}
                      </div>
                      {item.type}
                    </div>
                    {item.popular ? (
                      <span className="dim meta-text">(Most popular)</span>
                    ) : null}
                  </div>
                );
              })
            : null}
          <hr className="mute" />
          <p className="mini">
            <span className="pill warning">Warning!</span>{' '}
            <span className="dim">
              Activities & bookings linked with transfers may get changed when
              you change the mode.
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = state => {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
};

const mapDispatchToProps = dispatch => {
  return {
    changeTransferMode: bindActionCreators(changeTransferMode, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(MultiModeTransferModal);
