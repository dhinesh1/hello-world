import React, { Component } from 'react';
import { connect } from 'react-redux';

import TrainDetails from './components/train_details';
import {
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  TRAIN_ALTERNATES
} from '../../helpers/routesHelper';
import { bindActionCreators } from 'redux';
import { manageInterCityTransfer } from '../../actions/actions_app';
class TrainDetailsModal extends Component {
  constructor(props) {
    super(props);

    this.state = { showModal: false, activeTrainDetails: {} };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.handleChangeBtnClick = this.handleChangeBtnClick.bind(this);
    this.handleCallToActionClick = this.handleCallToActionClick.bind(this);
    this.getCurrentDetails = this.getCurrentDetails.bind(this);
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.trainCostings &&
      !Object.keys(this.state.activeTrainDetails).length
    ) {
      let currentKey = this.props.match.params.trainKey;
      currentKey = decodeCostingKeyFromURL(currentKey);

      let currentDetail =
        props.itineraryInfo.trainCostings.trainCostingById[currentKey];

      if (!currentDetail) {
        this.closeModal();
      }

      this.setState({ activeTrainDetails: currentDetail });
    }
  }

  closeModal() {
    let { history, itineraryDetail } = this.props;

    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        onceModalClosed();
        history.push(
          itineraryModalsRouteHelper({
            itineraryId: itineraryDetail.itineraryId,
            regionCode: itineraryDetail.regionCode,
            parentPage: routingPageType.inclusion
          })
        );
      });
    }, 400);
  }

  openModal() {
    this.setState({ showModal: true }, () => {
      onceModalOpened();
    });
  }

  handleChangeBtnClick() {
    let { history, match, itineraryDetail } = this.props;
    let currentKey = match.params.trainKey;

    history.push(
      itineraryModalsRouteHelper({
        itineraryId: itineraryDetail.itineraryId,
        regionCode: itineraryDetail.regionCode,
        parentPage: routingPageType.inclusion,
        target: TRAIN_ALTERNATES,
        customParams: { trainKey: currentKey }
      })
    );
  }
  /**
   * To handle action for the remove intercity train 
   */
  handleCallToActionClick(payload, e) {
    e && e.preventDefault();
    this.props
      .manageInterCityTransfer(payload)
      .then()
      .catch();
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  render() {
    const makeReadOnly = this.props.makeReadOnly;
    return (
      <div
        tabIndex="0"
        className={
          'modal fade modal-sticky-header alternate-modal hotel-modal ' +
          (this.state.showModal ? 'in' : '')
        }
        ref="modal"
      >
        <TrainDetails
          onCloseModal={this.closeModal}
          handleChangeBtnClick={this.handleChangeBtnClick}
          user_details={this.props.user_details}
          splitPricing={this.props.itineraryDetail.splitPricing}
          trainDetails={this.state.activeTrainDetails}
          itineraryId={this.props.itineraryDetail.itineraryId}
          itineraryDetail={this.props.itineraryDetail}
          adult_count={this.props.adult_count}
          child_count={this.props.child_count}
          makeReadOnly={makeReadOnly}
          handleCallToActionClick={this.handleCallToActionClick}
        />
      </div>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count,
      makeReadOnly: app.isReadOnly
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details,
      makeReadOnly: app.isReadOnly
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    manageInterCityTransfer: bindActionCreators(manageInterCityTransfer, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(TrainDetailsModal);
