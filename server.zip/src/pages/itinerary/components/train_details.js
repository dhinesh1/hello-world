import React, { Component } from 'react';
import { AppConfig } from '../../../app-config';
const IMAGE_CDN = AppConfig.images_cdn_misc_url;

export default class TrainDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedIndex: -1
    };

    this.changeButtonClickHandler = this.changeButtonClickHandler.bind(this);
    this.backClickHandler = this.backClickHandler.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.HeaderRenderHelper = this.HeaderRenderHelper.bind(this);
  }

  changeButtonClickHandler() {
    this.props.handleChangeBtnClick();
  }

  backClickHandler() {
    // this.props.showThisModal('alternateTrainsModal', {
    //   ...this.props.trainDetails.trainBeingReplaced,
    //   called_from: 'ALTERNATE_TRAIN_DETAILS'
    // });
    this.props.onCloseModal();
  }

  handleSelect(index) {
    this.setState({
      selectedIndex: index
    });
  }

  HeaderRenderHelper(train) {
    let { itineraryDetail, makeReadOnly, user_details, handleCallToActionClick } = this.props;
    const isAdmin = user_details &&
      user_details.loggedIn &&
      user_details.userType === 'ADMIN';
    const isNonEditable = itineraryDetail.booking && user_details && user_details.userType !== 'ADMIN';
    return (
      <div className="modal-header clearfix with-bg">
        <button
          type="button"
          onClick={this.props.onCloseModal}
          className="btn-modal-close close"
          aria-label="Close"
        >
          <span className="vehoicon-close" aria-hidden="true" />
        </button>
        <span className="text-uppercase kern-more bolder fade">Train</span>
        {train.called_from === 'ALTERNATE_TRAINS' ? (
          <div className="modal-actions">
            <a
              onClick={() =>
                itineraryDetail.booking ? null : this.backClickHandler(train)
              }
              className={
                'btn btn-sm btn-primary ' +
                (itineraryDetail.booking ? 'disabled' : '')
              }
            >
              Back
            </a>
          </div>
        ) : (makeReadOnly ? null :
          <div className="modal-actions">
            {
              isAdmin &&
                !isNonEditable
                ? (
                  <button
                    onClick={e => {
                      e && e.stopPropagation();
                      handleCallToActionClick(
                        {
                          itineraryId: itineraryDetail.itineraryId,
                          key: encodeURI(train.key),
                          transfer: 'train',
                          isRemove: true
                        },
                        e
                      )
                    }}
                    className={
                      'btn btn-sm btn-default btn-outline remove-cta' +
                      (isNonEditable ? 'disabled' : '')
                    }
                  >
                    <span className="vehoicon-delete text-xs-only"></span>
                    <span className="text-md-only">Remove</span>
                  </button>
                ) : null}
            <a
              onClick={() =>
                itineraryDetail.booking
                  ? null
                  : this.changeButtonClickHandler(train)
              }
              className={
                `btn btn-sm btn-primary
                ${itineraryDetail.booking ? 'disabled' : ''}
              `}
            >
              Change
            </a>
          </div>
        )}
      </div>
    );
  }

  render() {
    let { adult_count, child_count, trainDetails } = this.props;

    let childCountMarkup = '';
    if (child_count > 0) {
      childCountMarkup = ' + ' + child_count;
    }
    let trainImage = trainDetails.image || `${IMAGE_CDN}transfers-train.jpg`;
    return (
      <div className="modal-dialog" key="train_details_modal">
        <div className="modal-content with-header">
          {this.HeaderRenderHelper(trainDetails)}

          <div className="modal-body">
            <div className="modal-row">
              <div className="item-header">
                <h3>{trainDetails.text}</h3>
                <span className="p block">
                  <span className="bold color-secondary schedule">
                    {trainDetails.mon} {trainDetails.day}
                  </span>{' '}
                  — Starts from{' '}
                  <span className="secondary-link underline">
                    {trainDetails.pickup}
                  </span>
                </span>
              </div>
              <div className="at-a-glance clearfix">
                <div className="col-xs-6 col-md-3">
                  <span className="mini dim block">No. of travellers</span>
                  {adult_count} {adult_count > 1 ? 'Adults' : 'Adult'}{' '}
                  {childCountMarkup}
                </div>
                <div className="col-xs-6 col-md-3">
                  <span className="mini dim block">Duration</span>
                  {trainDetails.duration}
                </div>
                <div className="col-xs-6 col-md-3">
                  <span className="mini dim block">Stops</span>
                  {trainDetails.stops}
                </div>
                {trainDetails.totalCost ? (
                  <div className="col-xs-6 col-md-3">
                    <span className="mini dim block">Total cost</span>
                    <span className="total-price bold opener">
                      <span className="WebRupee">Rs.</span>{' '}
                      {trainDetails.totalCost}
                    </span>
                  </div>
                ) : null}
              </div>
              <hr className="no-height mute" />
              <div className="train-info spacer-both">
                <div className="row">
                  <div className="col-xs-8 col-sm-12">
                    <h5 className="no-margin">
                      {trainDetails.mon} {trainDetails.day}
                    </h5>
                    <span
                      className={
                        trainDetails.refundable
                          ? 'vehoicon-refundable color-success'
                          : 'vehoicon-non-refundable color-danger'
                      }
                    />{' '}
                    {trainDetails.refundable ? 'Refundable' : 'Non refundable'} <br />
                    {trainDetails.stops ? 
                    <span className='block mini dim'> {trainDetails.stops}{' '}
                      {trainDetails.stops > 1 ? 'stops' : 'stop'}{' '}({trainDetails.stopNames}) </span>
                      : null }
                  </div>
                  <div className="col-xs-4 no-padding hidden-sm hidden-md hidden-lg">
                    <div className="media-shell">
                      <figure className="hd">
                        <img src={trainImage} alt={'train'} />
                      </figure>
                    </div>
                  </div>
                </div>
                <div className="row clearfix spacer">
                  <div className="hidden-xs col-sm-3 text-center">
                    <div className="media-shell">
                      <figure className="hd">
                        <img src={trainImage} alt={'train'} />
                      </figure>
                    </div>
                  </div>
                  <div className="col-xs-12 col-sm-9 ">
                    <div className="col-xs-5 no-padding">
                      {trainDetails.departureTime}
                      <span className="block mini dim">
                        {trainDetails.pickup}
                      </span>
                    </div>
                    <div className="col-xs-2 no-padding text-center dim">
                      ⟶
                      <span className="block mini ">
                        {trainDetails.duration}
                      </span>
                    </div>
                    <div className="col-xs-5 no-padding text-right">
                      {trainDetails.arrivalTime}
                      <span className="block mini dim">
                        {trainDetails.drop}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
