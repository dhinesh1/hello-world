import React, { Component } from 'react';
import {
  getImgIXUrl, isMobile
} from '../../../helpers/utilsHelper';
import classNames from 'classnames';
import LazyLoadComponent from '../../../common_components/LazyLoadComponent';
import {
  trackEvent,
  EVENT_ITINERARY_COSTED,
  EVENT_PACKAGES_EDIT
} from '../../../helpers/ML/EventsTracker';
import {
  EDIT_TRIP,
  itineraryModalsRouteHelper
} from '../../../helpers/routesHelper';

export default class ItineraryCityHead extends Component {
  render() {
    let {
      history,
      itineraryInfo,
      isFromPackages,
      campaignItineraryId,
      makeReadOnly
    } = this.props;
    const editClicked = e => {
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation();
      const { itineraryId, regionCode } = itineraryInfo.itinerary;

      if (itineraryInfo.itinerary.campaign && isFromPackages) {
        if (history.location.pathname.indexOf("get-cost") === -1) {
          trackEvent(EVENT_ITINERARY_COSTED, {
            button: EVENT_PACKAGES_EDIT
          });
          history.push(
            history.location.pathname + '/get-cost/' + campaignItineraryId
          );
        }
      } else {
        history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            target: EDIT_TRIP
          })
        );
      }
    };

    const isEditable =
      (this.props.isBooked || this.props.flightsBlocked) && !makeReadOnly;
    let { city } = this.props;

    // Changing the image factor to imgIx for load it properly sized images for mobile and desktop
    // auto=format will load the images in next-gen format if its supported by the browser
    const imgFactor = isMobile() ? `w=500&auto=format` : `w=1000&auto=format`;
    return (
      <div key={city.cityId}>
        <LazyLoadComponent>
          <div
            className={classNames("itin-header city-header", {
              "clickable-div": makeReadOnly ? false: !isEditable
            })}
            onClick={makeReadOnly ? null : (isEditable ? null : editClicked)}
          >
            <img
              src={getImgIXUrl(this.props.city.image,imgFactor)}
              alt={`${city.cityId}_${city.cityName}`}
            />
            <div className="header-text">
              <h3 className="city-title">{city.cityName}</h3>
              <div>
                {isEditable ? (
                  <span className="fade text-uppercase kern-more fine-text bold">
                    {city.nights > 1
                      ? city.nights + " NIGHTS STAY"
                      : city.nights + " NIGHT STAY"}
                  </span>
                ) : makeReadOnly ? (
                  <span className="fine-text">
                    {city.nights > 1
                      ? city.nights + " nights"
                      : city.nights + " night"}
                  </span>
                ) : (
                  <button
                    className="btn btn-xs twin-btn text-center"
                    onClick={editClicked}
                  >
                    <span className="bg-white fine-text">
                      {city.nights > 1
                        ? city.nights + " nights"
                        : city.nights + " night"}
                    </span>
                    <span className="bg-primary color-white fine-text">
                      Edit
                    </span>
                  </button>
                )}
              </div>
            </div>
            <div className="column-meta faux-block" />
          </div>
        </LazyLoadComponent>
      </div>
    );
  }
}
