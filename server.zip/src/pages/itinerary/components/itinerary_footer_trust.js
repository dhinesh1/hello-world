import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Collapsible from 'react-collapsible';
import { AppConfig } from '../../../app-config';
import { connect } from 'react-redux';
import { trackEvent, EVENT_ITINERARY_MODIFIED, EVENT_ITINERARY_COSTED, EVENT_POSITION_FOOTER } from '../../../helpers/ML/EventsTracker';
import { GET_COST, itineraryModalsRouteHelper, CBR } from '../../../helpers/routesHelper';

const CONTACT_NUMBER = AppConfig.website_contact_number;

class ItineraryFooterTrust extends Component {
  constructor(props) {
    super(props);

    this.state = {
      expanded: 0
    };
    this.onTriggerClick = this.onTriggerClick.bind(this);
  }

  onGetTripCost = () => {	
    trackEvent(EVENT_ITINERARY_COSTED, { button: EVENT_POSITION_FOOTER });	
  };

  onTriggerClick(index) {
    if (this.state.expanded === index) {
      index = '';
    }
    this.setState({ expanded: index });
    trackEvent(EVENT_ITINERARY_MODIFIED, { faq_clicked: true });
  }

  render() {
    let { expanded } = this.state;
    let { itineraryInfo, campaignItineraryId, location } = this.props;
    const {campaign, itineraryId, regionCode} = itineraryInfo.itinerary;

    const ENABLE_CONTACT_NUMBER =
      this.props.showContactNumber || AppConfig.enable_Contact_Number;
    const contactText = ENABLE_CONTACT_NUMBER
      ? `We are also available at +91 ${CONTACT_NUMBER}.`
      : '';
    const ItineraryfaqArray = [
      {
        title: 'Can I customize this itinerary?',
        body: `Yes, the itinerary is completely customizable according to your preferences. You can add or remove any number of days, cities, and choose the activities that best suits your interests.`
      },
      {
        title: 'How do I know this itinerary suits my interests?',
        body: `We have a smart algorithm that keeps your interests in mind and suggests the most suitable cities for you with a score on the side. Adding to this, the itineraries also get filled with activities using the same logic, which can always be changed and customized to satisfy you.`
      },
      {
        title:
          'Will anyone be able to help me out in crafting my perfect itinerary?',
        body: `You can craft your own awesome itinerary in just a few
        clicks. We do understand that you may still have
        queries on the itinerary or the destination. Feel free
        to ask us your questions on the chat option visible at
        the right corner of our website. ${contactText}`
      },
      {
        title: 'How much would this trip cost?',
        body: `Liked the itinerary that you just created? Well, to get an estimate of your trip, click the 'Get Trip Cost' button on the top right corner. This will give you an instant costing of the itinerary.`
      },
      {
        title: 'Can I add another city to this plan?',
        body: `Of course! More cities, more fun! Are you able to spot the "edit" icon? Now click on this to add or change the city.`
      },
      {
        title: `Will I be able to save this itinerary?`,
        body: `Yes, it's all yours! Get the cost for this trip by signing up. Once you are done, every itinerary you create will be saved in the "Your Vacations" page. You can get here by clicking on the drop down once you log in. Happy planning :)`
      }
    ];
    return (
      <section className="summary">
        <div className="cost-container">
          <div className="cost-section-head">
            <h3 className="mute">&nbsp;</h3>
          </div>
          <article className="row-costed-item row">
            <div className="col-xs-12 col-sm-6 text-center">
              <img
                className="cost-img"
                src="https://pyt-images.imgix.net/images/misc/cost-cta-min.png"
                alt="cost-cta"
              />
              <p className="footer-happy base dim">
                Happy with this itinerary? Enter your travel details and find
                out how much this costs!
              </p>
              {this.props.history ? (
                itineraryInfo.itinerary.costed &&
                itineraryInfo.itinerary.staleCost ? (
                  <button
                    onClick={this.props.updateCostClickHandler}
                    className={'btn btn-primary tracker-calc-update-cost'}
                  >
                    Update cost
                  </button>
                ) : (
                  <Link
                    key={'itineraryTalkToExpertBtn'}
                    to={
                      {
                        pathname: campaign ? 
                          `${location.pathname}/${GET_COST}/${campaignItineraryId}`
                        : itineraryModalsRouteHelper({
                          itineraryId : itineraryId,
                          regionCode,
                          target: GET_COST,
                          location
                        })
                      }
                    }
                    className="btn btn-primary tracker-calc-tripcost"
                    onClick={this.onGetTripCost}
                  >
                    {'Calculate trip cost'}
                  </Link>
                )
              ) : null}
            </div>
            <div className="col-xs-12 col-sm-6 text-center">
              <img
                className="cost-img"
                src="https://pyt-images.imgix.net/images/misc/agent-cta-min.png"
                alt="agent-cta"
              />
              <p className="footer-question base dim">
                Questions? Talk to our travel consultants to get help with
                planning &amp; pricing
              </p>
              {this.props.history ? (
                <Link
                  key={'itineraryTalkToExpertBtn'}
                  to={{
                    pathname: campaign ? 
                        `${location.pathname}/${CBR}`
                      : itineraryModalsRouteHelper({
                          itineraryId : itineraryId,
                          regionCode,
                          target: CBR,
                          location
                        })
                  }}
                  className="btn btn-primary tracker-talk-expert"
                >
                  Talk to our travel consultants
                </Link>
              ) : null}
            </div>
          </article>
          <div className="block zig-zag">
            <span />
          </div>
          <div className="entice-action double-spacer-both text-center no-padding">
            <div className="fw faq-outer tracker-itineraryfaq">
              <div className="row faq text-left padding-top no-padding no-bg-color">
                <div className="col-md-12">
                  <div className="clearfix panel-group">
                    {ItineraryfaqArray.map((faq, index) => {
                      return (
                        <ItineraryFootertrustAccordion
                          key={index}
                          index={index}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={<h5 className="panel-title">{faq.title}</h5>}
                        >
                          {faq.body}
                        </ItineraryFootertrustAccordion>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
}

const ItineraryFootertrustAccordion = props => (
  <section className="panel panel-default itinerary-panel">
    <Collapsible
      open={props.expanded === props.index}
      triggerTagName={'div'}
      triggerClassName={'panel-heading accordion-toggle'}
      triggerOpenedClassName={'panel-heading accordion-toggle'}
      contentInnerClassName={'panel-body'}
      handleTriggerClick={e => props.onTriggerClick(props.index)}
      trigger={props.trigger}
    >
      {props.children}
    </Collapsible>
  </section>
);

function mapStateToProps(state) {
  return {
    showContactNumber: parseInt(state.app.showContactNumber)
  };
}

function mapDispatchToProps() {
  return {
    actions: {}
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  ItineraryFooterTrust
);
