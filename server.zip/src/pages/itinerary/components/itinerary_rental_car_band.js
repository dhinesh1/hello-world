import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import {itineraryModalsRouteHelper, RENTAL_CAR_DETAILS} from '../../../helpers/routesHelper';
import { encodeActivityKeyForURL } from '../../../helpers/utilsHelper';

class ItineraryrRentalCarBand extends Component {
  constructor(props) {
    super(props);

    this.showRCDetails = this.showRCDetails.bind(this);
  }

  showRCDetails(e) {
    e && e.preventDefault();
    const {itineraryId, regionCode, isCosted, staleCost, rentalCarKey, history} = this.props;

    if (isCosted && !staleCost) {
      history.push(
        itineraryModalsRouteHelper({
          itineraryId,
          regionCode,
          target: RENTAL_CAR_DETAILS,
          commonParams: {
            rcKey: encodeActivityKeyForURL(rentalCarKey)
          }
        })
      );
    }
  }

  render() {
    let { isCosted, staleCost } = this.props;

    return (
      <div
        key={Math.random()}
        className={
          'unit-row rental-car-band ' +
          (isCosted && !staleCost ? 'clickable' : '')
        }
        onClick={e => this.showRCDetails(e)}
      >
        <div className="column-meta" />

        <div className="transfer-wrapper transfer">
          <div className="row row-main">
            <div className="col-xs-12 col-sm-12 event-slot no-hover-color">
              <div className="transfer-image-shell rental-car-shell">
                <span className="vehoicon-directions_car" />
              </div>
              <p className="small normal">{this.props.city.rcText}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(ItineraryrRentalCarBand);