import React, { Component } from 'react';
import { Range } from 'rc-slider';

import _ from 'lodash';
import axios from 'axios';
import { AppConfig } from '../../../app-config';

const API_URL = AppConfig.api_url;

export default class AlternateActivitiesFilter extends Component {
  constructor(props) {
    super(props);

    this.state = {
      types: 'all',
      timeFilter: [],
      sortBy: 'interests',
      searchTerm: '',
      interests: [],
      activityCategory: [],
      otherFilters: {},
      minPrice: this.props.minPrice,
      maxPrice: this.props.maxPrice,
      CategoryInterestMap: []
    };

    this.updateFilters = this.updateFilters.bind(this);
    this.applyFilter = this.applyFilter.bind(this);
  }

  componentWillMount() {
    let url = `${API_URL}misc/getCategoryInterestMapping`;
    axios.get(url).then(response => {
      this.setState({
        CategoryInterestMap: response.data
      });
    });

    this.handleSearchDebounced = _.debounce(() => {
      this.applyFilter();
    }, 200);
  }

  componentDidMount() {
    if (this.props.minPrice && !this.state.minPrice) {
      this.setState({
        minPrice: this.props.minPrice,
        maxPrice: this.props.maxPrice
      });
    }
  }

  componentWillReceiveProps(props) {
    if (props.minPrice && !this.state.minPrice) {
      this.setState({
        minPrice: props.minPrice,
        maxPrice: props.maxPrice
      });
    }
  }

  applyFilter(e) {
    e && e.preventDefault();
    let searchConditions = Object.assign({}, this.state);

    this.props.doSearch(searchConditions);
  }

  updateFilters(filterType = null, name = false, value = null) {
    const newState = { ...this.state };

    if (filterType === null) return;

    // if(filterType === "priceFilters"){
    //   this.setState({priceFiltersApplied: true})
    // }
    // if (!newState.minPrice && !this.state.priceFiltersApplied) {
    //   newState.minPrice = this.props.minPrice;
    //   newState.maxPrice = this.props.maxPrice;
    // }

    switch (filterType) {
      case 'otherFilters':
        if (!name) return;
        if (value) newState.otherFilters[name] = value;
        else delete newState.otherFilters[name];
        break;
      case 'activityCategory':
        if (!name) return;

        if (value && !newState.activityCategory.includes(name)) {
          newState.activityCategory.push(name);
        } else {
          _.remove(newState.activityCategory, function(t) {
            return t === name;
          });
        }

        newState.interests = [];
        newState.activityCategory.forEach(activityCategory => {
          let cur_category = _.find(this.state.CategoryInterestMap, function(
            o
          ) {
            return o.category.id === parseInt(activityCategory, 10);
          });
          cur_category &&
            newState.interests.push(..._.map(cur_category.interests, 'id'));
        });
        break;
      case 'priceFilters':
        newState.minPrice = value[0];
        newState.maxPrice = value[1];
        break;
      case 'types':
        newState.types = value;
        break;
      case 'timeFilter':
        if (!name) return;
        if (value && !newState.timeFilter.includes(name)) {
          newState.timeFilter.push(name);
        } else {
          _.remove(newState.timeFilter, function(t) {
            return t === name;
          });
        }
        break;
      default:
        return;
    }

    this.setState(newState, () => {
      this.props.doSearch(newState);
    });
  }

  render() {
    let {user_details} = this.props;
    const isAdmin = user_details && user_details.loggedIn && user_details.userType === 'ADMIN';

    return (
      <div className="modal-alternate-filters full-hgt">
        <div className="modal-filter-header xs-hdr">
          <div className="header-bar">
            <button
              id="alternate-activities-hide-filter-btn"
              onClick={this.props.handleFilterCloseIconClick}
              type="button"
              className={'close filter-toggle clear-box-shadow visible-xs'}
            >
              <span className="vehoicon-previous" aria-hidden="true" />
            </button>
            {/*<span className="text-uppercase kern-more bolder fade">Filters</span>*/}
          </div>
        </div>
        <div className="filter-content tracker-activity-filter clearfix xs-midcontent">
          <div className="form-group search-filter tracker-act-searchfil">
            <span className="vehoicon-search" />
            <input
              value={this.state.searchTerm}
              onChange={e => {
                this.setState({ searchTerm: e.target.value });
                this.handleSearchDebounced();
              }}
              type="text"
              autoComplete="off"
              name="name"
              placeholder="Search"
              id="formInlineName"
              className="search-icon form-control"
            />
          </div>
          <hr className="mute" />
          <h6 className="fade">Type</h6>
          <div className="filter-grp tracker-act-type">
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="HALF"
                  onClick={e =>
                    this.updateFilters(
                      'timeFilter',
                      e.target.name,
                      !this.state.timeFilter[e.target.name]
                    )
                  }
                />
                <span>Half Day</span>
                <i />
              </label>
            </div>
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="QUARTER"
                  onClick={e =>
                    this.updateFilters(
                      'timeFilter',
                      e.target.name,
                      !this.state.timeFilter[e.target.name]
                    )
                  }
                />
                <span>Quarter Day</span>
                <i />
              </label>
            </div>
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="FULL"
                  onClick={e =>
                    this.updateFilters(
                      'timeFilter',
                      e.target.name,
                      !this.state.timeFilter[e.target.name]
                    )
                  }
                />
                <span>Full Day</span>
                <i />
              </label>
            </div>
          </div>

          <hr className="mute" />
          {!isAdmin && !this.props.splitPricing
            ? null : <React.Fragment>
                <h6 className="fade">Cost per adult</h6>
                <div className="filter-grp">
                  <PriceFilterSlider
                    {...this.state}
                    minPrice={this.props.minPrice}
                    maxPrice={this.props.maxPrice}
                    selectedMinPrice={
                      this.state.minPrice
                        ? this.state.minPrice
                        : this.props.minPrice
                    }
                    selectedMaxPrice={
                      this.state.maxPrice
                        ? this.state.maxPrice
                        : this.props.maxPrice
                    }
                    updateFilters={this.updateFilters}
                  />
                </div>
                <hr className="mute" />
              </React.Fragment>
            }

          <h6 className="fade">Category</h6>
          <div className="filter-grp tracker-act-category">
            {this.state.CategoryInterestMap.length > 0
              ? this.state.CategoryInterestMap.map((option, inx) => {
                  return (
                    <div key={"category_map_"+inx} className="clearfix">
                      <label className="custom-options">
                        <input
                          type="checkbox"
                          key={'category_filter_' + inx}
                          name={option.category.id}
                          onClick={e =>
                            this.updateFilters(
                              'activityCategory',
                              e.target.name,
                              option
                            )
                          }
                        />
                        <span>{option.category.name}</span>
                        <i />
                      </label>
                    </div>
                  );
                })
              : null}
          </div>
          <hr className="mute" />

          {this.props.recommendedActivitiesFound ? (
            <div className="filter-grp tracker-act-otherfilter inline-block">
              <div className="clearfix">
                <label className="custom-options">
                  <input
                    type="checkbox"
                    name="recommended"
                    onClick={e =>
                      this.updateFilters(
                        'otherFilters',
                        e.target.name,
                        !this.state.otherFilters[e.target.name]
                      )
                    }
                  />
                  <span>Pickyourtrail Recommended</span>
                  <i />
                </label>
              </div>
              <label className="no-padding">
                <span>
                  Pickyourtrail has handpicked a list of activities that is
                  value for money and is also best enjoyed by their customers!
                  Click this for our special recommendations.
                </span>
              </label>
            </div>
          ) : null}
          {this.props.recommendedActivitiesFound ? (
            <hr className="mute" />
          ) : null}

          <h6 className="fade"> Other Filters</h6>
          <div className="filter-grp tracker-act-otherfilter">
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="ticket"
                  onClick={e =>
                    this.updateFilters(
                      'otherFilters',
                      e.target.name,
                      !this.state.otherFilters[e.target.name]
                    )
                  }
                />
                <span>Tickets and Passes</span>
                <i />
              </label>
            </div>
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="fastSelling"
                  onClick={e =>
                    this.updateFilters(
                      'otherFilters',
                      e.target.name,
                      !this.state.otherFilters[e.target.name]
                    )
                  }
                />
                <span>Fast selling</span>
                <i />
              </label>
            </div>
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="kidFriendly"
                  onClick={e =>
                    this.updateFilters(
                      'otherFilters',
                      e.target.name,
                      !this.state.otherFilters[e.target.name]
                    )
                  }
                />
                <span>Kid friendly</span>
                <i />
              </label>
            </div>
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="highlight"
                  onClick={e =>
                    this.updateFilters(
                      'otherFilters',
                      e.target.name,
                      !this.state.otherFilters[e.target.name]
                    )
                  }
                />
                <span>Highlight</span>
                <i />
              </label>
            </div>
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="free"
                  onClick={e =>
                    this.updateFilters(
                      'otherFilters',
                      e.target.name,
                      !this.state.otherFilters[e.target.name]
                    )
                  }
                />
                <span>Self exploration</span>
                <i />
              </label>
            </div>
            <div className="clearfix">
              <label className="custom-options">
                <input
                  type="checkbox"
                  name="transferIncluded"
                  onClick={e =>
                    this.updateFilters(
                      'otherFilters',
                      e.target.name,
                      !this.state.otherFilters[e.target.name]
                    )
                  }
                />
                <span>Transfer included</span>
                <i />
              </label>
            </div>
          </div>
          {/*<hr className="mute hidden-xs hidden-sm" />*/}
        </div>
        <div className="xs-ftr visible-xs">
          <button
            onClick={this.props.handleFilterCloseIconClick}
            type="button"
            className="btn btn-primary filter-update-btn btn-block"
          >
            Update
          </button>
        </div>
      </div>
    );
  }
}

const PriceFilterSlider = props => {
  const handlePriceRangeSliderChange = value =>
    props.updateFilters('priceFilters', 'adultCost', value);

  if (props.minPrice === undefined || props.maxPrice === undefined)
    return <div>&nbsp;</div>;

  return (
    <div>
      {props.minPrice !== props.maxPrice ? (
        <Range
          min={props.minPrice}
          max={props.maxPrice}
          defaultValue={[props.minPrice || 0, props.maxPrice || 100]}
          disabled={props.types === 'free'}
          range={true}
          allowCross={false}
          name="price"
          onChange={handlePriceRangeSliderChange}
        />
      ) : (
        <span className="fade">
          All options are at same price of <span className="WebRupee">Rs.</span>{' '}
          {props.minPrice}
        </span>
      )}
      {props.minPrice !== props.maxPrice ? (
        <div>
          <span className="slider-price">
            <span className="WebRupee">Rs.</span> {props.selectedMinPrice}
          </span>
          <span className="pull-right slider-price">
            <span className="WebRupee">Rs.</span> {props.selectedMaxPrice}
          </span>
        </div>
      ) : (
        ''
      )}
    </div>
  );
};
