import React, { Component } from 'react';
import { getImgIXUrl } from '../../../helpers/utilsHelper';
export default class SlotBackgroundImage extends Component {
  constructor(props) {
    super(props);
    this.getAirlineLogoByCode = this.getAirlineLogoByCode.bind(this);
    this.getTransferIcon = this.getTransferIcon.bind(this);
  }

  getTransferMode(slot, called_from) {
    switch (slot.type) {
      case 'INTERNATIONAL_ARRIVE':
        return called_from == 'link_row' ? 'FLIGHT' : 'FLIGHT_ARRIVE';
        break;
      case 'INTERNATIONAL_DEPART':
        return called_from == 'link_row' ? 'FLIGHT' : 'FLIGHT_DEPART';
        break;
      case 'ACTIVITY_WITH_TRANSFER':
        return 'CAR';
        break;
      case 'INTERCITY_TRANSFER':
        if (slot.intercityTransferSlotDetailVO.transferType == 'DIRECT') {
          return slot.intercityTransferSlotDetailVO.directTransferDetail
            .transferMode;
        }
        break;
      default:
        return 'FLIGHT';
    }
  }

  getTransferIcon(transferMode) {
    switch (transferMode) {
      case 'RENTALCAR':
      case 'CAR':
        return <span className="icon-in-circle vehoicon-directions_car" />;
        break;
      case 'TRAIN': {
        return <span className="icon-in-circle vehoicon-train" />;
        break;
      }
      case 'FERRY': {
        return <span className="icon-in-circle vehoicon-directions_boat" />;
        break;
      }
      case 'BUS': {
        return <span className="icon-in-circle vehoicon-directions_bus" />;
        break;
      }
      case 'FLIGHT': {
        if (this.props.slot.costingInfo != undefined) {
          if (this.props.slot.costingInfo.airlineCode != null) {
            return (
              <img
                className="itin-cell-thumb"
                src={
                  this.getAirlineLogoByCode(
                    this.props.slot.costingInfo.airlineCode
                  ).url
                }
              />
            );
          } else {
            return <span className="icon-in-circle vehoicon-flight" />;
          }

          break;
        } else {
          return <span className="icon-in-circle vehoicon-flight" />;
          break;
        }
      }
      case 'FLIGHT_ARRIVE': {
        return <span className="icon-in-circle vehoicon-flight_land" />;
        break;
      }
      case 'FLIGHT_DEPART': {
        return <span className="icon-in-circle vehoicon-flight_takeoff" />;
        break;
      }
      case 'HOTEL': {
        return (
          <span className="icon-in-circle vehoicon-airline_seat_individual_suite" />
        );
        break;
      }
    }
  }

  getAirlineLogoByCode(airlineCode) {
    let path = '../images/airline_logos/';
    let logo_filename = airlineCode.trim();
    return { name: airlineCode, url: `${path}${logo_filename}.png` };
  }

  render() {
    let transferMode = this.getTransferMode(
      this.props.slot,
      this.props.called_from
    );

    if (this.props.slot.type == 'ACTIVITY') {
      return (
        <div>
          <div className="activity-image-shell top-activity">
            {/*(this.props.slot.activitySlotDetail.highlight) ? (<span data-toggle="tooltip" href="#" title="Highlight activity!"><span className="vehoicon-flame highlight-icon"></span></span>) : null*/}
            <img src={this.props.slot.activitySlotDetail.mainPhoto} />
          </div>
        </div>
      );
    } else if (this.props.slot.type == 'HOTEL') {
      let hotel_img = (
        <span className={this.getTransferIcon(this.props.slot.type)} />
      );

      if (this.props.slot.mainPhoto != '') {
        hotel_img = (
          <img
            className="itin-cell-thumb"
            src={getImgIXUrl(this.props.slot.mainPhoto)}
          />
        );
      }

      return <div className="circle">{hotel_img}</div>;
    } else if (this.props.slot.type == 'LEISURE') {
      return (
        <div className="activity-image-shell top-activity">
          <span className="icon-in-circle vehoicon-add" />
        </div>
      );
    } else {
      return (
        <div className="activity-image-shell top-activity">
          {this.getTransferIcon(transferMode)}
        </div>
      );
    }
  }
}
