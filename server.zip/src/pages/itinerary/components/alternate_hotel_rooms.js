import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import _ from 'lodash';
import HotelRoomRow from '../../../common_components/itinerary/hotel_room_row';
import { updateRoom } from '../../../actions/actions_app';

class AlternateHotelRooms extends Component {
  constructor(props) {
    super(props);

    this.state = { selectedRoom: {} };

    this.updateSelectedRoom = this.updateSelectedRoom.bind(this);
  }

  updateSelectedRoom(selectedRoom) {
    let hotel = this.props.hotel;
    let currentPick = this.props.currentPick;
    let data = {
      hotelPlanningToolId: hotel.planningToolId,
      itineraryId: this.props.itineraryId,
      currentRoomTypeId: currentPick.roomTypeId,
      selectedRoomTypeId: selectedRoom.roomTypeId,
      roomQuery: this.props.roomList.roomQuery,
      offline: this.props.roomList.offline,
      selectedRoomIdentifier: selectedRoom.roomIdentifier
    };
    this.props.actions
      .updateRoom(data)
      .then(() => {
        this.props.onCloseModal();
      })
      .catch(() => {
        this.props.onCloseModal();
      });
  }

  renderRoomList(roomList) {
    if (!_.isEmpty(roomList)) {
      if (roomList.roomCostingVOList.length >= 1) {
        return roomList.roomCostingVOList.map(room => {
          return (
            <HotelRoomRow
              splitPricing={this.props.splitPricing}
              hotel={this.props.hotel}
              userDetails={this.props.userDetails}
              onCloseModal={this.props.onCloseModal}
              updateSelectedRoom={this.updateSelectedRoom}
              isCurrentPick={false}
              currentPickPrice={this.props.currentPick.finalPrice}
              packageRate={this.props.packageRate}
              onHotelDetails={false}
              room={room}
              room_no={1}
              key={Math.random()}
            />
          );
        });
      } else {
        return (
          <div className="col-xs-12 text-center">
            <h5 className="text-center">Oops! No other rooms found.</h5>
          </div>
        );
      }
    } else {
      return (
        <div className="col-xs-12 text-center">
          <h5 className="text-center">Loading alternate rooms</h5>
          <div className="inline-block block-center">
            {/*<Loading type="bubbles" color="#436F7C" />*/}
          </div>
        </div>
      );
    }
  }

  render() {
    let {
      currentPick,
      buildRequstObjectAndMakeCall,
      parentProps,
      parentState,
      showLoadMoreLink
    } = this.props;

    return (
      <div className="modal-dialog">
        <div className={'modal-content with-header'}>
          <div className="modal-header">
            <span className="caps-text semi-bold kern-more fade">
              Change Room
            </span>
            <button
              type="button"
              onClick={this.props.onCloseModal}
              className="close pull-left"
              data-dismiss="modal"
            >
              <i className="vehoicon-close" />
            </button>
          </div>

          <div className="modal-body">
            <div className="current-pick-panel">
              <div className="current-pick-content hotel">
                <div className="col-xs-9 col-md-10">
                  {/* <a className="toggle-panel" href="#"><span className="vehoicon-arrow_downward" /><span className="sr-only">More info</span></a> */}
                  <span className="single-line-text fade small no-margin">
                    {currentPick.name}
                  </span>
                </div>
                <div className="col-xs-3 col-md-2 text-right">
                  {currentPick.finalPrice ? (
                    <span className="total-price base bold">
                      <span className="WebRupee">Rs.</span>{' '}
                      {currentPick.finalPrice}
                    </span>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="modal-row change-room-row">
              <ul className="generic-options-list clearfix list-unstyled spacer-bottom">
                {this.renderRoomList(this.props.roomList)}
              </ul>
            </div>
            {showLoadMoreLink ? (
              <div className="text-center">
                <a
                  href="#"
                  onClick={e => {
                    e.preventDefault();
                    e.stopPropagation();
                    buildRequstObjectAndMakeCall(
                      parentState,
                      parentProps,
                      false
                    );
                  }}
                >
                  Show more rooms
                </a>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    alternate_hotel_rooms: state.alternate_hotel_rooms
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      updateRoom: bindActionCreators(updateRoom, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(AlternateHotelRooms);
