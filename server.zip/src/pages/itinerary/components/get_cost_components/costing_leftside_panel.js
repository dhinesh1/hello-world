import React, { Component } from 'react';
import CountUp from 'react-countup';
import { AppConfig } from '../../../../app-config';
import {
  getPathnameFromUrl,
  getFileNameFromUrl
} from '../../../../helpers/utilsHelper';
const { imgix_base } = AppConfig;

export default class RenderLeftSidePanel extends Component {
  constructor(props) {
    super(props);
    let {
      regionStatus: {
        flights,
        transfers,
        hotels,
        activities,
        regionName,
        image
      }
    } = props;
    this.state = {
      flightsCount: flights,
      transfersCount: transfers,
      hotelsCount: hotels,
      activitiesCount: activities,
      regionName: regionName,
      image: image
    };
  }

  componentDidMount() {
    this.setRegionStats(this.props);
  }

  setRegionStats = props => {
    let {
      regionStatus: {
        flights,
        transfers,
        hotels,
        activities,
        regionName,
        image
      }
    } = props;
    this.setState({
      flightsCount: flights,
      transfersCount: transfers,
      hotelsCount: hotels,
      activitiesCount: activities,
      regionName: regionName,
      image: image
    });
  };

  componentWillReceiveProps(props) {
    if (props.regionStatus) {
      this.setRegionStats(props);
    }
  }
  render() {
    let {
      flightsCount,
      transfersCount,
      hotelsCount,
      activitiesCount,
      regionName,
      image
    } = this.state;
    regionName = regionName || '';
    const getNumber = (item = '') => {
      return item.replace(/\'/g, '').split(/(\d+)/);
    };
    let flightsCounts = getNumber(flightsCount);
    let transfersCounts = getNumber(transfersCount);
    let hotelsCounts = getNumber(hotelsCount);
    let activitiesCounts = getNumber(activitiesCount);
    let imageUrl =
      `https:` +
      `${imgix_base}/images/${getPathnameFromUrl(image)}/${getFileNameFromUrl(
        image
      )}`;
    return (
      <aside
        className="hidden-xs"
        style={{
          backgroundImage: `url('${imageUrl}')`
        }}
      >
        <div className="side-content">
          <p className="fine-text light mbottom-medium">
            {`We will get the best prices for your ${regionName} trip from our trusted
            travel partners.`}
          </p>
          <ul className="clearfix">
            {+flightsCounts[1] ? (
              <li>
                <span>
                  <i className="vehoicon-flight" />
                  <CountUp
                    start={0}
                    duration={1}
                    end={+flightsCounts[1]}
                    suffix={flightsCounts[2]}
                  />
                </span>Flights
              </li>
            ) : null}
            {+transfersCounts[1] ? (
              <li>
                <span>
                  <i className="vehoicon-directions_car" />
                  <CountUp
                    start={0}
                    duration={1}
                    end={+transfersCounts[1]}
                    suffix={transfersCounts[2]}
                  />
                </span>Transfers
              </li>
            ) : null}
            {+hotelsCounts[1] ? (
              <li>
                <span>
                  <i className="vehoicon-local_hotel" />
                  <CountUp
                    start={0}
                    duration={1}
                    end={+hotelsCounts[1]}
                    suffix={hotelsCounts[2]}
                  />
                </span>Hotels
              </li>
            ) : null}
            {+activitiesCounts[1] ? (
              <li>
                <span>
                  <i className="vehoicon-confirmation_number" />
                  <CountUp
                    start={0}
                    duration={1}
                    end={+activitiesCounts[1]}
                    suffix={activitiesCounts[2]}
                  />
                </span>Activities
              </li>
            ) : null}
          </ul>
        </div>
      </aside>
    );
  }
}
