import React, { Component } from 'react';
import classNames from 'classnames';
import moment from 'moment';
import { GetDatesBetween } from '../../../../helpers/dateUtils';
const DATE_FORMAT = 'DD/MM/YYYY';

export function isSameDate(firstDate, secondDate) {
  return (
    moment(firstDate, DATE_FORMAT).diff(
      moment(secondDate, DATE_FORMAT),
      'days',
      false
    ) === 0
  );
}

function dateInArray(datesToDisable, queryDate){
  return Boolean(datesToDisable.filter(function(date){
     return date.isSame(queryDate);
  }).length);
}

export function isDisabled(minDate, currentDate, maxDate, datesToDisable) {
  const min = moment(moment(minDate).format(DATE_FORMAT), DATE_FORMAT);
  const max = moment(moment(maxDate).add(1,'days').format(DATE_FORMAT), DATE_FORMAT);
  const current = moment(moment(currentDate).format(DATE_FORMAT), DATE_FORMAT);

  return datesToDisable && dateInArray(datesToDisable, currentDate) || !(current.isBetween(min,max));
}

export default class MobileCalendar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedDate: null,
      localMaxDate: null,
      localMinDate: null
    };

    this.handleSelectedDate = this.handleSelectedDate.bind(this);
    this.setSelectedDate = this.setSelectedDate.bind(this);
  }

  handleSelectedDate(e, value) {
    e && e.preventDefault();
    this.setSelectedDate(value);
    if (this.props.onSelect) {
      this.props.onSelect(value);
    }
  }

  setSelectedDate(date) {
    this.setState({
      selectedDate: date
    });
  }

  componentDidMount() {
    this.setSelectedDate(this.props.selectedDate);
    let element = document.getElementById(
      moment(this.props.selectedDate, 'DD/MMM/YYYY').format('MMMM')
    );
    if (element) {
      element.scrollIntoView();
      document.getElementsByClassName('modal-body')[0].scrollTop -= 60;
    }

    /**
     * TODO: This logic has to be moved to parent component and
     * Dates are now hard-coded will be drive from BE in sometime
     */
    const {makeReadOnly = false} = this.props;
    if(makeReadOnly){
      // Update: Changed the starting date to June 23rd from July 01
      let datesToDisable = GetDatesBetween('06-23-2019','08-31-2019') || [];
      let yearEndDates = GetDatesBetween('12-15-2019','01-05-2020') || [];
      datesToDisable = datesToDisable.concat(yearEndDates);

      // Check maxDate
      const minDisabledDates = yearEndDates[0];
      const maxDisabledDates = yearEndDates[yearEndDates.length-1];
      let tmpMaxDate = this.state.localMaxDate ? moment(this.state.localMaxDate) : this.props.maxDate;

      // Changing maxDate if its false between Dec-15 to Jan-05 to Dec-15
      if(tmpMaxDate.isBetween(minDisabledDates,maxDisabledDates)){
        tmpMaxDate = minDisabledDates;
      } else if (tmpMaxDate.isBefore(maxDisabledDates)){
        tmpMaxDate = maxDisabledDates;
      }

      this.setState({disabledDates: datesToDisable, localMaxDate: tmpMaxDate});
    }
  }

  componentWillReceiveProps(props) {
    if (props.selectedDate) {
      this.setSelectedDate(props.selectedDate);
    }

    if(props.minDate){
      this.setState({localMinDate: props.minDate})
    }

    if(props.maxDate){
      this.setState({localMaxDate: props.maxDate})
    }
  }

  render() {
    const {selectedDate, localMaxDate, localMinDate, disabledDates} = this.state;
    const {minDate, maxDate} = this.props;

    let props = {
      minDate: localMinDate ? localMinDate : minDate,
      maxDate: localMaxDate ? localMaxDate : maxDate,
      selectedDate: selectedDate,
      handleSelect: this.handleSelectedDate,
      datesToDisable: disabledDates
    };
    return (
      <div className="mobile-datepicker">
        <RenderCalendarYear {...props} />
      </div>
    );
  }
}

export const RenderCalendarYear = props => {
  let { minDate, maxDate } = props;
  let totalMonth = Math.round(maxDate.diff(minDate, 'months', true)) + 1;
  let now = moment(minDate, 'DD/MMM/YYYY');
  let elements = [];
  for (let i = 0; i < totalMonth; i++) {
    elements.push(
      <RenderMonthCard key={i} currentMonth={now.clone()} {...props} />
    );
    now = now.add(1, 'M');
  }
  return elements;
};

export const RenderMonthCard = props => {
  let now = props.currentMonth;
  return (
    <section className="month" id={now.format('MMMM')}>
      <RenderMonthHeader date={now} />
      <RenderDayHeader />
      <RenderDays date={now} {...props} />
    </section>
  );
};

export const RenderMonthHeader = props => {
  let month = props.date.format('MMMM');
  let year = props.date.format('YYYY');
  return (
    <p className="month-title">
      <span>{year}</span>
      {month}
    </p>
  );
};

export const RenderDayHeader = () => {
  return (
    <ul className="days">
      <li>Su</li>
      <li>Mo</li>
      <li>Tu</li>
      <li>We</li>
      <li>Th</li>
      <li>Fr</li>
      <li>Sa</li>
    </ul>
  );
};

export const RenderSingleDay = ({
  isActive,
  handleClick,
  currentValue,
  isDisabled
}) => {
  return (
    <li
      className={classNames('', {
        active: isActive,
        disabled: isDisabled
      })}
      onClick={e => handleClick(e, currentValue)}
    >
      <span>{currentValue.date()}</span>
    </li>
  );
};

export const RenderDays = ({
  date,
  selectedDate,
  handleSelect,
  minDate,
  maxDate,
  datesToDisable
}) => {
  let daysInMonth = date.daysInMonth();
  let startDate = date.startOf('month');
  let balanceDayCount = startDate.day();

  let renderDay = () => {
    let elements = [];
    let now = moment(date, 'DD/MMM/YYYY');
    for (let i = 1; i <= daysInMonth; i++) {
      elements.push(
        <RenderSingleDay
          isActive={isSameDate(now.clone(), selectedDate)}
          isDisabled={isDisabled(minDate, now.clone(), maxDate, datesToDisable)}
          handleClick={handleSelect}
          currentValue={now.clone()}
          key={"single-day-"+Math.random()}
        />
      );
      now = now.add(1, 'days');
    }
    return elements;
  };
  let renderUnwantedDay = balanceDayCount => {
    let elements = [];
    for (let i = 0; i < balanceDayCount; i++) {
      elements.push(<li key={"date_"+i} className="visible-hidden" />);
    }
    return elements;
  };
  return (
    <ul className="date">
      {renderUnwantedDay(balanceDayCount)}
      {renderDay(selectedDate, startDate)}
    </ul>
  );
};
