import React, { Component } from 'react';
import Text from '../../../../common_components/basic_components/Text';
import MobileNumber from '../../../../common_components/basic_components/MobileNumber';

export default class RenderSignUpComponent extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    let props = this.props;
    let mobileNumber = props.mobileNumber;
    let extNumber = props.countryCode;
    return [
      <Text
        nameField
        labelText="Your name"
        placeHolder="Your name"
        isError={!props.userNameValid}
        defaultValue={props.userName}
        changeCall={value => {
          props.handleOnUserNameChanged({
            user_name: value
          });
        }}
      />,
      <Text
        // ref={emailInstance}
        isError={!props.emailValid}
        errorResponse={props.emailAlreadyExistsError}
        labelText="Email"
        placeHolder="Email"
        defaultValue={props.email}
        changeCall={value => {
          props.handleOnEmailChanged({
            user_email: value
          });
        }}
      />,
      <MobileNumber
        // ref={mobileInstance}
        isSignUp={true}
        isError={props.mobile_number_invalid}
        mobileNumber={mobileNumber}
        extensionNumber={extNumber}
        changeCall={(value, extNo, mobNo) => {
          props.handleOnMobileNumberChange(value, extNo, mobNo);
        }}
      />
    ];
  }
}
