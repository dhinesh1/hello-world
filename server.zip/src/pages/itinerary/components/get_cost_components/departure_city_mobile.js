import React, { Component, Fragment } from 'react';
import classNames from 'classnames';
import { RenderCity } from './departure_city_costing';

export default class DepartureCityMob extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expand: false
    };
    this.instance = React.createRef();
  }
  render() {
    let {
      popularCities,
      otherCities,
      onInputClickHandler,
      onInputChange,
      value,
      setMobileActions,
      isCred = false
    } = this.props;
    if (isCred) {
      return null;
    }
    return (
      <section id="step-1" className="visible-xs city-grid">
        <div className="xs-subhdr">
          <h5>Departing from</h5>
          <div
            className={classNames('inner-search', {
              expand: this.state.expand
            })}
          >
            <div className="inner-search-input">
              <input
                ref={this.instance}
                type="text"
                placeholder="Find departure city"
                onChange={isCred ? () => {} : onInputChange}
                onBlur={() => {
                  this.setState({ expand: false });
                }}
              />
              <i
                className="vehoicon-search"
                onClick={() => {
                  this.setState({ expand: true });
                  if (!isCred) {
                    this.instance.current.focus();
                  }
                }}
              />
              <i
                className="vehoicon-backspace"
                onClick={() => {
                  this.setState({ expand: false });
                  if (!isCred) {
                    this.instance.current.blur();
                  }
                }}
              />
            </div>
          </div>
        </div>
        {popularCities.length
          ? <Fragment>
              <strong className="meta-text dim-medium text-uppercase">
                Popular Cities
              </strong>
              <ul>
                <RenderCity
                  cities={popularCities}
                  onInputClickHandler={isCred ? () => {} : onInputClickHandler}
                  value={value}
                  setMobileActions={setMobileActions}
                  setActionValue={'STEP3'}
                />
              </ul>
            </Fragment>
          : null}
        {popularCities.length && otherCities.length ? <hr /> : null}
        {otherCities.length
          ? <Fragment>
              <strong className="meta-text dim-medium text-uppercase">
                All Cities
              </strong>
              <ul>
                <RenderCity
                  cities={otherCities}
                  isSort={true}
                  onInputClickHandler={isCred ? () => {} : onInputClickHandler}
                  value={value}
                  setMobileActions={setMobileActions}
                  setActionValue={'STEP3'}
                />
              </ul>
            </Fragment>
          : null}
      </section>
    );
  }
}
