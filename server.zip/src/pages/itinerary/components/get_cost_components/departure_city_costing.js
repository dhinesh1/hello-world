import React, { Component, Fragment } from 'react';
import classNames from 'classnames';
import {
  sort,
  isFaqMobile,
  checkIndexOf
} from '../../../../helpers/utilsHelper';
import DepartureCityMob from './departure_city_mobile';

export default class DepartureCityCosting extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cities: this.props.cities,
      defaultValue: '',
      value: '',
      activeTabIndex: null,
      popularCities: [],
      otherCities: [],
      activeCities: [],
      dropDownShow: false,
      departureCity: null
    };
    this.onInputChange = this.onInputChange.bind(this);
    this.onInputBlur = this.onInputBlur.bind(this);
    this.onInputFocus = this.onInputFocus.bind(this);
    this.onInputClickHandler = this.onInputClickHandler.bind(this);
    this.allCities = [];
    this.popularCities = [];
    this.otherCities = [];
    this.instance = React.createRef();
    this.configureDepartureCities = this.configureDepartureCities.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.handleKeyDown = this.handleKeyDown.bind(this);
  }

  componentDidMount() {
    document.addEventListener('keyup', this.handleKeyUp);
    this.configureDepartureCities(this.props);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  /**
   * Trigger when click the tab button
   * @param {*} e
   */
  handleKeyUp(e) {
    if (e.keyCode === 9) this.onInputBlur();
  }

  componentWillReceiveProps(props) {
    this.configureDepartureCities(props);
  }

  configureDepartureCities(props) {
    if (this.props.isCred) {
      this.setState({
        value: 'Outside India',
        defaultValue: 'Outside India',
        popularCities: [],
        otherCities: [],
        activeCities: []
      });
      return;
    }
    if ((props.cities || []).length && !this.allCities.length) {
      let popularCities = [];
      let otherCities = [];
      let allCities = props.cities;
      let defaultValue;
      allCities.map(city => {
        (city.popular ? popularCities : otherCities).push(city);
        if (city.airportCode === props.currentAirport) {
          defaultValue = city.cityName;
        } else if ('$$$' === props.currentAirport) {
          defaultValue = 'Outside India';
        }
      });
      this.setState({
        value: defaultValue,
        defaultValue: defaultValue,
        popularCities: popularCities,
        otherCities: otherCities,
        activeCities: popularCities.concat(
          sort(otherCities, ['cityName'], false)
        )
      });
      this.allCities = allCities;
      this.popularCities = popularCities;
      this.otherCities = otherCities;
    }
  }

  handleKeyDown(event) {
    if (this.props.isCred) {
      event && event.preventDefault();
      return;
    }
    let { activeTabIndex, activeCities } = this.state;
    let parentElement = document.getElementsByClassName('airport-codes')[0];
    switch (event.which) {
      case 40:
        event && event.preventDefault();
        activeTabIndex = activeTabIndex === null ? -1 : activeTabIndex;
        activeTabIndex =
          activeTabIndex >= activeCities.length - 1
            ? activeTabIndex
            : activeTabIndex + 1;
        this.setState({ activeTabIndex: activeTabIndex }, () => {
          this.onInputClickHandler(
            event,
            activeCities[activeTabIndex],
            null,
            true
          );
        });
        setTimeout(() => {
          if (
            document
              .querySelectorAll('.airport-codes ul li.active')[0]
              .getBoundingClientRect().y > 350
          ) {
            parentElement.scrollTop += 50;
          }
        }, 100);
        break;
      case 38:
        event && event.preventDefault();
        activeTabIndex = activeTabIndex <= 0 ? 0 : activeTabIndex - 1;
        this.setState({ activeTabIndex: activeTabIndex }, () => {
          this.onInputClickHandler(
            event,
            activeCities[activeTabIndex],
            null,
            true
          );
        });
        setTimeout(() => {
          if (
            document
              .querySelectorAll('.airport-codes ul li.active')[0]
              .getBoundingClientRect().y < 200
          ) {
            if (parentElement.scrollTop > 0) {
              parentElement.scrollTop -= 50;
            } else {
              parentElement.scrollTop = 0;
            }
          }
        });
        break;
      case 13:
        if (this.state.dropDownShow) {
          event && event.preventDefault();
          let activeCities = this.popularCities.concat(
            sort(this.otherCities, ['cityName'], false)
          );
          this.setState(
            {
              popularCities: this.popularCities,
              otherCities: this.otherCities,
              activeCities: activeCities,
              activeTabIndex: activeCities.findIndex(
                x => x.cityName == this.state.value
              ),
              dropDownShow: false
            },
            () => {
              this.instance.current && this.instance.current.blur();
              this.props.popupOpened && this.props.popupOpened(false);
            }
          );
        }
        break;
    }
  }

  onInputChange(e) {
    if (this.props.isCred) {
      e && e.preventDefault();
      return;
    }
    e && e.preventDefault();
    this.citySelected = false;
    let popularCities = [];
    let otherCities = [];
    let cityName;
    let airportCode;
    let currentValue = e.target.value.toLowerCase();
    this.allCities.map(city => {
      cityName = city.cityName.toLowerCase();
      airportCode = city.airportCode.toLowerCase();
      if (checkIndexOf(currentValue, [cityName, airportCode], 0, true, true)) {
        (city.popular ? popularCities : otherCities).push(city);
      }
    });
    this.setState({
      value: e.target.value,
      popularCities: popularCities,
      otherCities: otherCities,
      activeTabIndex: null,
      activeCities: popularCities.concat(sort(otherCities, ['cityName'], false))
    });
  }

  onInputBlur(e) {
    this.setState(
      {
        dropDownShow: false,
        popularCities: this.popularCities,
        otherCities: this.otherCities,
        activeCities: this.popularCities.concat(
          sort(this.otherCities, ['cityName'], false)
        ),
        value: this.citySelected ? this.state.value : this.state.defaultValue
      },
      () => {
        this.props.popupOpened && this.props.popupOpened(false);
      }
    );
  }

  onInputFocus(e) {
    if (this.props.isCred) {
      e && e.preventDefault();
      return;
    }
    e && e.preventDefault();
    let parentElement = document.getElementsByClassName('airport-codes')[0];
    this.setState(
      {
        dropDownShow: true
      },
      () => {
        let element = document.querySelectorAll(
          '.airport-codes ul li.active'
        )[0];
        if (element && element.getBoundingClientRect().y > 350) {
          element.scrollIntoView();
          parentElement.scrollTop -= 100;
        }
        this.props.popupOpened && this.props.popupOpened(true);
      }
    );
  }

  onInputClickHandler(e, city, actionValue, dropDownShow = false) {
    e && e.preventDefault();
    this.citySelected = true;
    this.setState(
      {
        value: city.cityName,
        departureCity: city,
        dropDownShow: dropDownShow,
        defaultValue: city.cityName
      },
      () => {
        this.props.costingHandler &&
          this.props.costingHandler({
            departureAirport: city.airportCode
          });
        if (actionValue) {
          this.props.setMobileActions(actionValue);
        }
        if (!dropDownShow) {
          let activeCities = this.popularCities.concat(
            sort(this.otherCities, ['cityName'], false)
          );
          this.setState({
            popularCities: this.popularCities,
            otherCities: this.otherCities,
            activeCities: activeCities,
            activeTabIndex: activeCities.findIndex(
              x => x.cityName == city.cityName
            )
          });
          this.instance.current && this.instance.current.blur();
          this.props.popupOpened && this.props.popupOpened(false);
        }
      }
    );
  }

  render() {
    let {
      dropDownShow,
      defaultValue,
      popularCities,
      otherCities,
      value
    } = this.state;
    const isCred = this.props.isCred;
    if (isCred) {
      return null;
    }
    return !isFaqMobile() ? (
      <Fragment>
        {dropDownShow ? (
          <div
            className={'modal-backdrop fade in'}
            onClick={this.onInputBlur}
            style={{ zIndex: 5, opacity: 0.2 }}
          />
        ) : null}
        <div
          className={classNames('form-group form-group-lg flat has-dropdown', {
            'has-error': this.props.hasError
          })}
          onFocus={this.onInputFocus}
          style={dropDownShow ? { zIndex: 5 } : null}
        >
          <div className="label-animative">
            <input
              type="text"
              ref={this.instance}
              autoComplete="offf"
              onChange={this.onInputChange}
              className="form-control"
              placeHolder="Departing from"
              defaultValue={defaultValue}
              value={value}
              onKeyDown={this.handleKeyDown}
            />
            <label className="control-label">{'Departing from'}</label>
          </div>
          <div
            style={{ zIndex: 5 }}
            className={classNames('dropdown', { hide: !dropDownShow })}
          >
            <div className="airport-codes">
              {popularCities.length
                ? <Fragment>
                    <strong>Popular Cities</strong>
                    <ul>
                      <RenderCity
                        cities={popularCities}
                        onInputClickHandler={this.onInputClickHandler}
                        value={value}
                      />
                    </ul>
                  </Fragment>
                : null}
              {popularCities.length && otherCities.length ? <hr /> : null}
              {otherCities.length
                ? <Fragment>
                    <strong>All Cities</strong>
                    <ul>
                      <RenderCity
                        cities={otherCities}
                        isSort={true}
                        value={value}
                        onInputClickHandler={this.onInputClickHandler}
                      />
                    </ul>
                  </Fragment>
                : null}
              <div
                className="dd-ftr"
                onMouseDown={e => {
                  document.getElementsByClassName(
                    'airport-codes'
                  )[0].scrollTop = 0;
                  this.onInputClickHandler(e, {
                    cityName: 'Outside India',
                    airportCode: '$$$'
                  });
                }}
              >
                <a href="#">
                  Departing from outside of India{' '}
                  <i className="vehoicon-keyboard_arrow_right" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    ) : (
      <DepartureCityMob
        popularCities={popularCities}
        otherCities={otherCities}
        onInputClickHandler={this.onInputClickHandler}
        onInputChange={this.onInputChange}
        onInputBlur={this.onInputBlur}
        value={value}
        setMobileActions={this.props.setMobileActions}
        isCred={this.props.isCred}
      />
    );
  }
}

export const RenderCity = ({
  cities,
  isSort,
  onInputClickHandler,
  value,
  setActionValue
}) => {
  let elements = [];
  if (isSort) {
    sort(cities, ['cityName'], false);
  }
  elements = cities.map((city, index) => {
    return (
      <li
        key={city.airportCode}
        className={classNames({
          active: value === city.cityName
        })}
        data-bind={city}
        onMouseDown={e => {
          onInputClickHandler(e, city, setActionValue);
        }}
      >
        {' '}
        <a>
          <span>{city.airportCode}</span> {city.cityName}
        </a>
      </li>
    );
  });
  return elements;
};
