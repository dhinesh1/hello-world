import React, { Component, Fragment } from 'react';
import classNames from 'classnames';
import { getNumberToWord } from '../../../../helpers/utilsHelper';
import _ from 'lodash';

const isNullChild = childs => {
  return (childs || []).some(child => child === null);
};

export default class CostingSelection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      roomCounts: null,
      adultCounts: null,
      childCounts: null,
      overallCounts: null,
      babyCounts: null,
      costingText: '',
      roomCostings: [],
      currentRoomCosting: [],
      erroChilds: [],
      errorTabs: [],
      selected: 0,
      isError: false,
      errorResponse: '',
      enableFadeIn: false
    };
    this.onInputBlur = this.onInputBlur.bind(this);
    this.onInputFocus = this.onInputFocus.bind(this);
    this.onInputClickHandler = this.onInputClickHandler.bind(this);
    this.instance = React.createRef();
    this.roomHandler = this.roomHandler.bind(this);
    this.paxHandler = this.paxHandler.bind(this);
    this.addChildAgeHandler = this.addChildAgeHandler.bind(this);
    this.validateCostingHandler = this.validateCostingHandler.bind(this);
    this.costingHandler = this.costingHandler.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.validateErrorHandler = this.validateErrorHandler.bind(this);
    this.triggeredSubmit = false;
    this.resetError = this.resetError.bind(this);
  }

  componentDidMount() {
    document.addEventListener('keyup', this.handleKeyUp);
    if (this.props.costingInfo) {
      let costingInfo = _.cloneDeep(this.props.costingInfo);
      this.validateCostingHandler(costingInfo, () => {
        this.setState({
          currentRoomCosting: costingInfo
        });
      });
    }
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  /**
   * Trigger when click the tab button
   * @param {*} e
   */
  handleKeyUp(e) {
    if (e.keyCode === 9) this.onInputBlur();
  }

  componentWillReceiveProps(props) {
    if (props.costingInfo) {
      let costingInfo = _.cloneDeep(props.costingInfo);
      this.validateCostingHandler(costingInfo, () => {
        this.setState({
          currentRoomCosting: costingInfo
        });
      });
    }
  }

  costingHandler(e, type) {
    e && e.preventDefault();
    let roomInfo = _.cloneDeep(this.state.currentRoomCosting);
    this.triggeredSubmit = true;
    if (type !== 'CANCEL' && this.validateErrorHandler()) {
      this.triggeredSubmit = false;
      this.validateCostingHandler(roomInfo, () => {
        this.setState({
          dropDownShow: false,
          selected: 0
        });
        this.props.popupOpened && this.props.popupOpened(false);
        this.props.costingHandler &&
          this.props.costingHandler({
            hotelGuestRoomConfigurations: roomInfo
          });
      });
    } else if (type === 'CANCEL') {
      this.resetError();
      this.triggeredSubmit = false;
      this.validateCostingHandler(roomInfo, () => {
        this.setState({
          dropDownShow: false,
          selected: 0
        });
        this.props.popupOpened && this.props.popupOpened(false);
        this.props.costingHandler &&
          this.props.costingHandler({
            hotelGuestRoomConfigurations: this.props.costingInfo
          });
      });
    }
  }

  validateErrorHandler(selectedIndex) {
    let state = this.state,
      infantCounts,
      childs;
    let rooms = state.currentRoomCosting;
    state.erroChilds = [];
    let checkErrorValidate = (room, index) => {
      childs = room.childAges;
      infantCounts = (childs || []).filter(child => child <= 2).length;
      if (isNullChild((room || {}).childAges)) {
        state.isError = true;
        state.errorResponse = 'Please enter the age details';
        state.selected = index;
        childs.map((age, i) => {
          if (age === null) state.erroChilds.push(i);
        });
      } else if (room.adultCount < infantCounts) {
        state.isError = true;
        state.errorResponse =
          'Infant count should not be greather than adult count';
        state.selected = index;
        childs.map((age, i) => {
          if (age <= 2) state.erroChilds.push(i);
        });
      } else {
        this.resetError();
      }
    };
    if (selectedIndex === undefined) {
      for (let index = 0; index < rooms.length; index++) {
        checkErrorValidate(rooms[index], index);
        if (state.isError) {
          break;
        }
      }
    } else {
      checkErrorValidate(rooms[selectedIndex], selectedIndex);
    }
    this.setState(state);
    return !state.isError;
  }
  validateCostingHandler(info, callBack) {
    let roomCounts,
      adultCounts = 0,
      childCounts = 0,
      babyCounts = 0;
    roomCounts = info.length;
    info.map(cost => {
      adultCounts += cost.adultCount;
      childCounts += cost.childAges.length;
      babyCounts += (cost.childAges || []).filter(baby => baby >= 1).length;
    });
    this.setState(
      {
        adultCounts: adultCounts,
        childCounts: childCounts,
        babyCounts: babyCounts,
        overallCounts: adultCounts + childCounts,
        roomCounts: roomCounts,
        costingText:
          adultCounts +
          ' adult' +
          (adultCounts > 1 ? 's' : '') +
          (childCounts
            ? ' & ' +
              childCounts +
              (childCounts > 1 ? ' children' : ' child') +
              ', '
            : ', ') +
          getNumberToWord(roomCounts) +
          'room' +
          (roomCounts > 1 ? 's' : '')
      },
      () => {
        callBack && callBack();
      }
    );
  }

  paxHandler(e, type, action, canQuit) {
    e && e.preventDefault();
    if (canQuit) {
      return false;
    }
    this.resetError();
    this.triggeredSubmit = false;
    let state = this.state;
    let { isMobile } = this.props;

    let costing = _.cloneDeep(state.currentRoomCosting[state.selected]);
    if (type === 'ADULTS') {
      costing.adultCount =
        action === 'INCREASE' ? costing.adultCount + 1 : costing.adultCount - 1;
    } else {
      if (action === 'INCREASE') {
        costing.childAges.push(null);
      } else {
        costing.childAges.pop();
      }
    }
    state.currentRoomCosting[state.selected] = costing;
    this.validateCostingHandler(state.currentRoomCosting, () => {
      if (isMobile) {
        this.props.costingHandler &&
          this.props.costingHandler({
            hotelGuestRoomConfigurations: state.currentRoomCosting
          });
      }
    });
  }

  addChildAgeHandler(e, childIndex) {
    let state = this.state;
    let { isMobile } = this.props;

    let value = +e.target.value;
    let costing = _.cloneDeep(state.currentRoomCosting);
    let childAges = _.cloneDeep(costing[this.state.selected].childAges);
    childAges[childIndex] = isNaN(value) ? null : value;
    costing[this.state.selected].childAges = childAges;
    this.validateCostingHandler(costing, () => {
      this.setState(
        {
          currentRoomCosting: costing
        },
        () => {
          if (this.triggeredSubmit) {
            this.validateErrorHandler(this.state.selected);
          }
        }
      );

      if (isMobile) {
        this.props.costingHandler &&
          this.props.costingHandler({
            hotelGuestRoomConfigurations: costing
          });
      }
    });
  }

  resetError() {
    let state = this.state;
    state.isError = false;
    state.errorResponse = '';
    state.erroChilds = [];
    this.setState(state);
  }

  roomHandler(e, action, selectedValue) {
    e && e.preventDefault();
    let state = this.state;
    let { isMobile } = this.props;

    switch (action) {
      case 'REMOVE':
        this.resetError();
        if (state.currentRoomCosting.length != 1) {
          state.currentRoomCosting.splice(state.selected, 1);
          state.selected = state.currentRoomCosting.length - 1;
        }
        break;
      case 'SELECT':
        if (this.triggeredSubmit) {
          this.validateErrorHandler(selectedValue);
        }
        state.selected = selectedValue;
        break;
      default:
        this.resetError();
        this.triggeredSubmit = false;
        state.currentRoomCosting.push({
          childAges: [],
          adultCount: 1
        });
        state.selected = state.currentRoomCosting.length - 1;
        if (this.triggeredSubmit) {
          this.validateErrorHandler(state.currentRoomCosting.length - 1);
        }
        break;
    }
    this.validateCostingHandler(this.state.currentRoomCosting, () => {
      if (isMobile) {
        this.props.costingHandler &&
          this.props.costingHandler({
            hotelGuestRoomConfigurations: this.state.currentRoomCosting
          });
      }
      this.setState(
        {
          enableFadeIn: true
        },
        () => {
          setTimeout(() => {
            this.setState({
              enableFadeIn: false
            });
          }, 500);
        }
      );
    });
  }

  onInputBlur(e) {
    e && e.preventDefault();
    this.triggeredSubmit = true;
    if (this.validateErrorHandler()) {
      this.triggeredSubmit = false;
      this.costingHandler(e, 'DONE');
      this.setState(
        {
          dropDownShow: false
        },
        () => {
          this.props.popupOpened && this.props.popupOpened(false);
        }
      );
    }
  }

  onInputFocus(e) {
    e && e.preventDefault();
    this.setState(
      {
        dropDownShow: true
      },
      () => {
        this.props.popupOpened && this.props.popupOpened(true);
      }
    );
  }

  onInputClickHandler(e) {
    e && e.preventDefault();
  }

  render() {
    let { isError, dropDownShow, defaultValue, costingText } = this.state;
    let { isMobile, makeReadOnly = false} = this.props;
    let insideProps = {
      ...this.props,
      ...this.state,
      costingHandler: this.costingHandler,
      roomHandler: this.roomHandler,
      roomAction: this.roomHandler,
      paxAction: this.props.makeReadOnly ? () => {} : this.paxHandler,
      childAgeAction: this.addChildAgeHandler,
    };
    return [
      !isMobile && dropDownShow ? (
        <div
          className={'modal-backdrop fade in'}
          onClick={this.onInputBlur}
          style={{ zIndex: 5, opacity: 0.2 }}
        />
      ) : null,

      isMobile ? (
        <Fragment>
          <div className="xs-subhdr">
            <h5>
              Travellers &amp; room details<span>{costingText}</span>
            </h5>
          </div>
          <RenderInsideComponent {...insideProps} />
        </Fragment>
      ) : (
        <div
          className={classNames('form-group form-group-lg flat has-dropdown', {
            'has-error': isError
          })}
          onFocus={makeReadOnly? () => {} : this.onInputFocus}
          style={dropDownShow ? { zIndex: 5 } : null}
        >
          <div className="label-animative">
            <input
              type="text"
              ref={this.instance}
              autoComplete="offf"
              className="form-control"
              placeHolder="Get costing for"
              defaultValue={defaultValue}
              value={costingText}
            />
            <label className="control-label">{'Get costing for'}</label>
          </div>
          <div
            style={{ zIndex: 5 }}
            className={classNames('dropdown', { hide: !dropDownShow })}
          >
            <RenderInsideComponent {...insideProps} />
          </div>
        </div>
      )
    ];
  }
}

export const RenderInsideComponent = props => {
  let {
    isError,
    erroChilds,
    roomCounts,
    selected,
    currentRoomCosting,
    overallCounts,
    adultCounts,
    childCounts,
    babyCounts,
    roomAction,
    paxAction,
    childAgeAction,
    roomHandler,
    costingHandler,
    errorResponse,
    isMobile,
    enableFadeIn,
    makeReadOnly
  } = props;
  return (
    <Fragment>
      <div className="clearfix fw room-config color-grey-secondary">
        <RenderRoomHeader
          roomCounts={roomCounts}
          activeRoom={selected + 1}
          disableRoomAdition={
            babyCounts >= 4 || roomCounts >= 6 || overallCounts >= 9
          }
          roomHandler={roomHandler}
          roomAction={roomAction}
          makeReadOnly={makeReadOnly}
        />
        <section
          className={classNames('clearfix fw', {
            'fadein-inner-animation': enableFadeIn
          })}
        >
          <RenderPaxModal
            costingInfo={currentRoomCosting[selected]}
            paxAction={paxAction}
            childAgeAction={childAgeAction}
            overallCounts={overallCounts}
            adultCounts={adultCounts}
            childCounts={childCounts}
            isError={isError}
            erroChilds={erroChilds}
            errorResponse={errorResponse}
            makeReadOnly={makeReadOnly}
          />
          <p className={`mini dim ${makeReadOnly ? 'hide' : ''}`}>
            Maximum of 6 people in a room and 9 people in a trip.
          </p>
        </section>
      </div>
      {isMobile ? null : <RenderFooter costingHandler={costingHandler} />}
    </Fragment>
  );
};

export const RenderRoomHeader = props => {
  let GetRooms = (roomCounts, activeRoom) => {
    let rooms = [];
    for (let i = 1; i <= roomCounts; i++) {
      rooms.push(
        <span
          key={i}
          className={classNames('', {
            active: activeRoom === i
          })}
          onClick={e => {
            props.roomAction(e, 'SELECT', i - 1);
          }}
        >
          {roomCounts > 1 && activeRoom === i ? (
            <i
              className="remove-icon vehoicon-remove_circle "
              onClick={e => {
                e && e.stopPropagation();
                props.roomHandler(e, 'REMOVE');
              }}
            />
          ) : null}
          {`Room ${i}`}
        </span>
      );
    }
    return rooms;
  };
  return (
    <div className="clearfix room-pills">
      {GetRooms(props.roomCounts, props.activeRoom, props.roomAction)}
      <span
        className={classNames('add', { hide: props.disableRoomAdition || props.makeReadOnly})}
        onClick={e => {
          props.roomAction(e, 'ADD');
        }}
      >
        <i
          className={classNames('vehoicon-plus3', {
            disabled: props.disableRoomAdition
          })}
        />
        {' Add'}
      </span>
    </div>
  );
};

export const RenderPaxModal = ({
  costingInfo,
  paxAction,
  overallCounts,
  adultCounts,
  childCounts,
  childAgeAction,
  isError,
  erroChilds,
  errorResponse,
  insideProps,
  makeReadOnly
}) => {
  let roomAdultCounts = (costingInfo || {}).adultCount;
  let childs = (costingInfo || {}).childAges;
  let infantCounts = (childs || []).filter(child => child <= 2).length;
  let roomChildCounts = (childs || []).length;
  let roomPaxCounts = roomAdultCounts + roomChildCounts;
  let disableAdultAddition = overallCounts >= 9 || roomPaxCounts >= 6;
  let disableAdultDecrease =
    roomAdultCounts === 1 || infantCounts === roomAdultCounts;

  return <Fragment>
    <div className="no-counter mbottom-medium">
      <i
        className={classNames('vehoicon-minus3', {
          disabled: disableAdultDecrease
        }, {hide: makeReadOnly})}
        onClick={e => {
          paxAction(e, 'ADULTS', 'DECREASE', disableAdultDecrease);
        }}
      />
      <span>
        <b>{roomAdultCounts}</b> {roomAdultCounts > 1 ? 'Adults' : 'Adult'}
      </span>
      <i
        className={classNames('vehoicon-plus3', {
          disabled: disableAdultAddition
        }, {hide: makeReadOnly})}
        onClick={e => {
          paxAction(e, 'ADULTS', 'INCREASE', disableAdultAddition);
        }}
      />
    </div>

    <RenderChildModal
      costingInfo={costingInfo}
      paxAction={paxAction}
      overallCounts={overallCounts}
      adultCounts={adultCounts}
      childCounts={childCounts}
      roomAdultCounts={roomAdultCounts}
      roomPaxCounts={roomPaxCounts}
      roomChildCounts={roomChildCounts}
      childAgeAction={childAgeAction}
      isError={isError}
      erroChilds={erroChilds}
      errorResponse={errorResponse}
      makeReadOnly={makeReadOnly}
    />
  </Fragment>;
};

export const RenderChildModal = ({
  costingInfo,
  paxAction,
  overallCounts,
  childAgeAction,
  childCounts,
  roomPaxCounts,
  roomChildCounts,
  isError,
  erroChilds,
  errorResponse,
  makeReadOnly
}) => {
  let childs = (costingInfo || {}).childAges;
  let disableChildAddition =
    roomPaxCounts >= 6 || roomChildCounts >= 4 || overallCounts >= 9;
  let disableChildDecrease = roomChildCounts === 0;

  let GetChildAges = childs => {
    let ages = [];
    let RenderValues = selectedValue => {
      let options = [<option value>—</option>];
      for (let j = 0; j <= 14; j++) {
        options.push(
          <option value={j} selected={j === selectedValue}>
            {j ? j : '<1'}
          </option>
        );
      }
      return options;
    };
    for (let i = 0; i < (childs || []).length; i++) {
      ages.push(
        <div
          className={classNames('custom-select', {
            'has-error': erroChilds.indexOf(i) > -1 && isError
          })}
        >
          <select className="form-control" onChange={e => childAgeAction(e, i)}>
            {RenderValues(childs[i])}
          </select>
        </div>
      );
    }
    return ages;
  };

  return <Fragment>
    <div className="no-counter mbottom-medium">
      <i
        className={classNames('vehoicon-minus3', {
          disabled: disableChildDecrease
        }, {hide: makeReadOnly})}
        onClick={e => {
          paxAction(e, 'CHILDS', 'DECREASE', disableChildDecrease);
        }}
      />
      <span>
        <b>{roomChildCounts}</b> {roomChildCounts > 1 ? 'Children' : 'Child'}
      </span>
      <i
        className={classNames('vehoicon-plus3', {
          disabled: disableChildAddition
        }, {hide: makeReadOnly})}
        onClick={e => {
          paxAction(e, 'CHILDS', 'INCREASE', disableChildAddition);
        }}
      />
    </div>
    <div className="clearfix fw text-center">
      <p className="light mbottom-small hide">
        Travelling with children? Make sure to enter their details to get the
        best rates and offers!
      </p>
      <div className="form-group form-group-sm">
        {roomChildCounts && !isError ? (
          <p className="light">
            {' '}
            {roomChildCounts > 1
              ? 'Please enter your children’s age'
              : 'Please enter your child’s age'}
          </p>
        ) : null}
        {isError && errorResponse ? (
          <p className="light color-accent-11">{errorResponse}</p>
        ) : null}
        {GetChildAges(childs)}
      </div>
    </div>
  </Fragment>;
};

export const RenderFooter = ({ costingHandler }) => {
  return (
    <div className="dd-ftr">
      <a
        className="pull-left bold anchor-link-grey"
        href=""
        onClick={e => {
          e && e.preventDefault();
          costingHandler(e, 'CANCEL');
        }}
      >
        Cancel
      </a>
      <a
        className="pull-right bold"
        href=""
        onClick={e => {
          e && e.preventDefault();
          costingHandler(e, 'DONE');
        }}
      >
        Done
      </a>
    </div>
  );
};
