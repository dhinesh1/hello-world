import React from 'react';
import classNames from 'classnames';
import { checkIndexOf } from '../../../../helpers/utilsHelper';
import Button from '../../../../common_components/basic_components/Button';
import { trackEvent, EVENT_GENERATE_LEAD } from '../../../../helpers/ML/EventsTracker';

export const RenderDesktopFooterComponent = props => {
  let {
    user_details,
    isLoading,
    history,
    allSuggestions,
    enableGetCost,
    IsUpdateCostFlow,
    makeReadOnly
  } = props;
  let inVacationsPage = checkIndexOf(history.location.pathname, ['vacations']);
  let isUserExit = user_details && user_details.loggedIn;
  return (
    <div className="btns-row">
      <Button
        type="submit"
        buttonClass={classNames('btn btn-primary btn-lg btn-block', {
          'tracker-get-cost-modal-get-cost': !isUserExit,
          'tracker-get-cost-modal-update-cost': isUserExit,
          'sending-btn': isLoading
        })}
        isDisabled={!(allSuggestions.length && enableGetCost && !isLoading)}
        buttonText={
          IsUpdateCostFlow()
            ? 'Update trip cost'
            : inVacationsPage
              ? 'Get my personalized itinerary'
              : makeReadOnly ? 'Check Availability' :'Get Cost'
        }
        clickAction={(e) => {
          !isUserExit && trackEvent(EVENT_GENERATE_LEAD);
          props.handleGetCostClick(e);
        }}
      />
      {isUserExit ? (
        <p className="fine-text color-grey light vmargin-small mb-0">
          Logged in as
          <a
            onClick={e => {
              e && e.preventDefault();
            }}
          >
            {' '}
            {user_details.name}
          </a>. This itinerary will be saved to "Your trips" after costing
        </p>
      ) : (
        <p className="fine-text color-grey light vmargin-small mb-0">
          If you are new here, an account will be created and you can save your
          itineraries using it. Existing users can
          <a href="" onClick={e => props.handleHaveAccountLoginClick(e)}>
            {' '}
            login to continue
          </a>.
        </p>
      )}
    </div>
  );
};
