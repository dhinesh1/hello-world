import React, { Component } from 'react';
import classNames from 'classnames';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import { GetDatesBetween } from '../../../../helpers/dateUtils';

export default class DepartureDateDesk extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dropDownShow: false,
      disabledDates: [],
      maxDate: moment().add(9, 'M').toDate()
    };
    this.onInputBlur = this.onInputBlur.bind(this);
    this.onInputFocus = this.onInputFocus.bind(this);
    this.instance = React.createRef();
  }

  onInputBlur(e) {
    this.setState(
      {
        dropDownShow: false
      },
      () => {
        this.props.popupOpened && this.props.popupOpened(false);
      }
    );
  }

  onInputFocus(e) {
    e && e.preventDefault();
    this.setState({
      dropDownShow: true
    });
    this.instance.input.parentElement.className = 'label-animative';
  }

  componentDidMount() {
    if (this.instance.input) {
      this.instance.input.setAttribute('autocomplete', 'off');
      this.instance.input.parentElement.insertAdjacentHTML(
        'beforeend',
        '<label class="control-label">Departing on</label>'
      );
      this.instance.input.parentElement.className = 'label-animative';
    }

    /**
     * TODO: This logic has to be moved to parent component and
     * Dates are now hard-coded will be drive from BE in sometime
     */
    const {isCred = false} = this.props;
    if(isCred){
      // Only for cred itineraries we need to disable dates between July 01 to Aug 31
      // Update: Changed the starting date to June 23rd from July 01
      let datesToDisable = GetDatesBetween('06-23-2019','08-31-2019') || [];
      let yearEndDates = GetDatesBetween('12-15-2019','01-05-2020') || [];
      datesToDisable = datesToDisable.concat(yearEndDates);

      // Check maxDate
      const minDisabledDates = yearEndDates[0];
      const maxDisabledDates = yearEndDates[yearEndDates.length-1];
      let tmpMaxDate = moment(this.state.maxDate);

      // Changing maxDate if its false between Dec-15 to Jan-05 to Dec-15
      if(tmpMaxDate.isBetween(minDisabledDates,maxDisabledDates)){
        tmpMaxDate = minDisabledDates;
      } else if (tmpMaxDate.isBefore(maxDisabledDates)){
        tmpMaxDate = maxDisabledDates;
      }

      this.setState({disabledDates: datesToDisable, maxDate: tmpMaxDate});
    }
  }

  render() {
    let { dropDownShow } = this.state;
    let { costingHandler, costingDate, hasError, isCred=false } = this.props;
    return (
      <div
        className={classNames('form-group form-group-lg flat has-dropdown', {
          'has-error': hasError
        })}
        onBlur={this.onInputBlur}
        onFocus={this.onInputFocus}
        style={dropDownShow ? { zIndex: 5 } : null}
      >
        <DatePicker
          selected={!costingDate ? null : moment(costingDate, 'DD/MMM/YYYY')}
          ref={c => (this.instance = c)}
          placeholderText="Departing on"
          onChange={e => {
            if (e !== null) {
              costingHandler({
                departureDate: moment(e).format('DD/MMM/YYYY')
              });
            }
          }}
          className="form-control"
          dateFormat={'DD/MMM/YYYY'}
          minDate={isCred ? moment().add(16, 'd'): moment().add(1, 'd')}
          maxDate={this.state.maxDate}
          id={'departure-date-get-cost'}
          fixedHeight={true}
          shouldCloseOnSelect
          excludeDates={this.state.disabledDates}
        />
      </div>
    );
  }
}
