import React, { Component, Fragment } from 'react';
import DepartureCityCosting from './departure_city_costing';
import classNames from 'classnames';
import CostingSelection from './costing_selection';
import moment from 'moment';
import MobileCalendar from './mobile_calendar';

export default class RenderMobileContent extends Component {
  componentDidMount() {
    let element = document.getElementsByClassName('modal-body')[0];
    if (element) {
      element.scrollTop = 0;
    }
  }
  render() {
    let { currentAction } = this.props;
    switch (currentAction) {
      case 'STEP2':
        return <RenderSecondForm {...this.props} />;
      case 'STEP3':
        return <RenderThirdForm {...this.props} />;
      case 'STEP4':
        return <RenderFourthForm {...this.props} />;
      default:
        return <RenderFirstForm {...this.props} />;
    }
  }
}

export const RenderFirstForm = props => {
  let {
    costingHandler,
    allSuggestions,
    costingConfiguration = {},
    setMobileActions
  } = props;
  return (
    <Fragment>
      <DepartureCityCosting
        cities={allSuggestions}
        costingHandler={costingHandler}
        currentAirport={costingConfiguration.departureAirport}
        currentCity={costingConfiguration.departureCity}
        hasError={props.airportFailed}
        value={costingConfiguration.departureCity}
        setMobileActions={setMobileActions}
      />
    </Fragment>
  );
};

export const RenderFirstFooter = props => {
  let { costingHandler } = props;
  return (
    <div className="modal-footer depart-ftr">
      <a
        href=""
        onClick={e => {
          e && e.preventDefault();
          costingHandler(
            {
              cityName: 'Outside India',
              departureAirport: '$$$'
            },
            false,
            'STEP3'
          );
        }}
      >
        I'm departing from outside of India<i className="dim vehoicon-keyboard_arrow_right" />
      </a>
    </div>
  );
};

export const RenderSecondForm = props => {
  if (props.makeReadOnly) {
    return null;
  }
  return (
    <section id="step-2" className="city-grid">
      <div className="xs-subhdr">
        <h5>Departing from</h5>
      </div>
      <ul>
        <li className="active other-link">
          <a
            onClick={e => {
              e && e.preventDefault();
              props.setMobileActions('STEP3');
            }}
          >
            <span>Other</span>I’m departing from outside of India
          </a>
        </li>
      </ul>
      <div className="clearfix fw text-center meta-text vmargin-small mb-0">
        <a
          onClick={e => {
            e && e.preventDefault();
            props.setMobileActions('STEP1');
          }}
        >
          Or choose an Indian Airport
        </a>
      </div>
    </section>
  );
};

export const RenderThirdForm = props => {
  let { costingDate, costingHandler, makeReadOnly } = props;
  return (
    <section id="step-3" className="visible-xs">
      <div className="xs-subhdr">
        <h5>Departing on</h5>
      </div>
      <MobileCalendar
        makeReadOnly={makeReadOnly}
        minDate={makeReadOnly ? moment().add(16, 'd') : moment().add(1, 'd')}
        selectedDate={
          !costingDate ? null : moment(costingDate, 'DD/MMM/YYYY').toDate()
        }
        maxDate={moment().add(9, 'M')}
        onSelect={value => {
          costingHandler(
            {
              departureDate: moment(value).format('DD/MMM/YYYY')
            },
            false,
            'STEP4'
          );
        }}
      />
    </section>
  );
};

export const RenderFourthForm = props => {
  const { user_details, flightsBookedByUserAlready, handleFlightsBookedByUserAlready } = props;
  let userExist = user_details && user_details.loggedIn;
  const isAdminUser = user_details && user_details.loggedIn && user_details.userType === 'ADMIN';
  let reference = props.costingMobileReference;
  return (
    <Fragment>
      <CostingSelection
        ref={reference}
        {...props}
        isMobile={true}
        costingInfo={props.costingConfiguration.hotelGuestRoomConfigurations}
      />
      {isAdminUser ?
        <div className={'form-group '}>
          <label className="control-label">Intl flights booked?</label>
          <div className={'block'}>
            <label className="custom-options no-padding">
              <input
                type="checkbox"
                value="true"
                name={'flightsBookedByUserAlready'}
                checked={
                  flightsBookedByUserAlready
                }
                onChange={handleFlightsBookedByUserAlready}
              />{' '}
              Yes
                            <i />
            </label>{' '}
          </div>
        </div>
        : null}
      <div className="modal-footer btn-ftr">
        <div className="input-group">
          {userExist ? null : (
            <input
              type="text"
              className="form-control"
              placeholder="Enter your name"
              onClick={e => {
                reference.current.costingHandler(e, 'DONE');
                e.preventDefault();
                if (!reference.current.state.isError) {
                  props.showSignUp();
                }
              }}
            />
          )}
          <div className="input-group-btn">
            <button
              disabled={props.enableMobileGetCost ? '' : 'disabled'}
              type="button"
              className={classNames('btn btn-primary', {
                'btn-lg btn-block': userExist
              })}
              onClick={e => {
                reference.current.costingHandler(e, 'DONE');
                e.preventDefault();
                if (!reference.current.state.isError) {
                  if (userExist) {
                    props.triggerGetCost();
                  } else {
                    props.showSignUp();
                  }
                }
              }}
            >
              {props.makeReadOnly ? 'Check Availability' : 'Get cost'}
            </button>
          </div>
        </div>
        {userExist ? (
          <p>
            Logged in as <a className="bold">{props.user_details.name}</a>{' '}
          </p>
        ) : (
          <p>
            Existing users{' '}
            <a
              className="bold"
              onClick={e => {
                reference.current.costingHandler(e, 'DONE');
                e && e.preventDefault();
                setTimeout(() => {
                  if (!reference.current.state.isError) {
                    props.handleHaveAccountLoginClick(e);
                  }
                });
              }}
            >
              please login to view cost
            </a>{' '}
          </p>
        )}
      </div>
    </Fragment>
  );
};
