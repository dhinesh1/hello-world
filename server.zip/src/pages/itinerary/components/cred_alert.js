import React from 'react';
import SweetAlert from 'sweetalert-react';

/**
 * Show Alert modal if any hotel in the CRED itinerary is sold out for the selected date
 * This is used is itinerary and inclusions pages
 */
const CREDAlert = ({ credAlertStatus, callback }) => {
  return (
    <div className="loader-wrapper bg-white">
      <SweetAlert
        show={credAlertStatus}
        title={'Oops!'}
        text={`A hotel in the itinerary is unavailable for the selected dates`}
        onConfirm={callback}
        animation="pop"
        confirmButtonText="Select another itinerary"
      />
    </div>
  )
}

export default CREDAlert;