import React, { Component } from 'react';
import Scroll from 'react-scroll';

import { CostedItineraryScroll } from '../../../helpers/utilsHelper';
const Link = Scroll.Link;

export default class MobileFooterNavTabs extends Component {
  renderFlightsNavItem() {
    let { costedItinerary } = this.props;
    if (costedItinerary !== undefined) {
      if (costedItinerary.allFlightCostingRefs.length > 0) {
        let hidePriceClass = !costedItinerary.itinerary.splitPricing
          ? 'price-hidden'
          : '';
        return (
          <li className="flight-tab">
            <Link
              to={CostedItineraryScroll.Flights}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-110}
              className=""
            >
              <span className="icon">
                <span className="icon-flight" />
              </span>
              <span className="details">
                <span className="tab-name">Flights</span>
                <span className={'tab-total-price ' + hidePriceClass}>
                  {' '}
                  &#8377;{' '}
                  {this.props.costedItinerary.flightCostings.totalFlightCost}
                </span>
              </span>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderPackageNavItem() {
    if (this.props.costedItinerary !== undefined) {
      let { costedItinerary } = this.props;

      if (costedItinerary.allFlightCostingRefs.length > 0) {
        let hidePriceClass = !costedItinerary.itinerary.splitPricing
          ? 'price-hidden'
          : '';
        return (
          <li className="package-tab">
            <Link
              to={CostedItineraryScroll.FlightsandHotels}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-110}
              className=""
            >
              <span className="icon">
                <span className="icon-package" />
              </span>
              <span className="details">
                <span className="tab-name">Flights + Hotels</span>
                <span className={'tab-total-price ' + hidePriceClass}>
                  {' '}
                  &#8377;{' '}
                  {this.props.costedItinerary.flightCostings.totalFlightCost}
                </span>
              </span>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderTransferNavItem() {
    let costedItinerary = this.props.costedItinerary;
    if (this.props.costedItinerary !== undefined) {
      if (
        costedItinerary.allTransferCostingRefs.length > 0 ||
        costedItinerary.allTrainCostingRefs.length > 0 ||
        costedItinerary.allFerryCostingRefs.length > 0 ||
        costedItinerary.allRentalCostingRefs.length > 0
      ) {
        let hidePriceClass = !costedItinerary.itinerary.splitPricing
          ? 'price-hidden'
          : '';
        return (
          <li className="transfer-tab">
            <Link
              to={CostedItineraryScroll.Transfers}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-110}
              className=""
            >
              <span className="icon">
                <span className="icon-transfer" />
              </span>
              <span className="details">
                <span className="tab-name">Transfers</span>
                <span className={'tab-total-price ' + hidePriceClass}>
                  {' '}
                  &#8377;{' '}
                  {
                    this.props.costedItinerary.transferCostings
                      .combinedTransferCost
                  }
                </span>
              </span>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderHotelNavItem() {
    let costedItinerary = this.props.costedItinerary;
    if (this.props.costedItinerary !== undefined) {
      if (this.props.costedItinerary.allHotelCostingRefs.length > 0) {
        let hidePriceClass = !costedItinerary.itinerary.splitPricing
          ? 'price-hidden'
          : '';
        return (
          <li className="hotel-tab">
            <Link
              to={CostedItineraryScroll.Hotels}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-110}
              className=""
            >
              <span className="icon">
                <span className="icon-hotel" />
              </span>
              <span className="details">
                <span className="tab-name">Hotels</span>
                <span className={'tab-total-price ' + hidePriceClass}>
                  {' '}
                  &#8377;{' '}
                  {this.props.costedItinerary.hotelCostings.totalHotelCost}
                </span>
              </span>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderActivityNavItem() {
    let { costedItinerary } = this.props;
    if (this.props.costedItinerary !== undefined) {
      if (this.props.costedItinerary.allActivityCostingRefs.length > 0) {
        let hidePriceClass = !costedItinerary.itinerary.splitPricing
          ? 'price-hidden'
          : '';
        return (
          <li className="activity-tab">
            <Link
              to={CostedItineraryScroll.Activities}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-110}
              className=""
            >
              <span className="icon">
                <span className="icon-activity" />
              </span>
              <span className="details">
                <span className="tab-name">Activities</span>
                <span className={'tab-total-price ' + hidePriceClass}>
                  {' '}
                  &#8377;{' '}
                  {
                    this.props.costedItinerary.activityCostings
                      .totalPublishedCost
                  }
                </span>
              </span>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderComboNavItem() {
    let { costedItinerary } = this.props;
    if (this.props.costedItinerary !== undefined) {
      if (this.props.costedItinerary.allPassCostingRefs) {
        if (this.props.costedItinerary.allPassCostingRefs.length > 0) {
          let hidePriceClass = !costedItinerary.itinerary.splitPricing
            ? 'price-hidden'
            : '';
          return (
            <li className="passes-tab">
              <Link
                to={CostedItineraryScroll.PassPanels}
                activeClass="active"
                spy={true}
                smooth={true}
                duration={500}
                offset={-110}
                className=""
              >
                <span className="icon">
                  <span className="icon-combo" />
                </span>
                <span className="details">
                  <span className="tab-name">Combos</span>
                  <span className={'tab-total-price ' + hidePriceClass}>
                    {' '}
                    &#8377;{' '}
                    {this.props.costedItinerary.passCostings.totalPassCost}
                  </span>
                </span>
              </Link>
            </li>
          );
        }
      }
    }
    return null;
  }

  renderVisaInsuranceNavItem() {
    let { costedItinerary } = this.props;
    if (this.props.costedItinerary !== undefined) {
      if (this.props.costedItinerary.visaCostings !== null) {
        let hidePriceClass = !costedItinerary.itinerary.splitPricing
          ? 'price-hidden'
          : '';
        return (
          <li className="visa-insurance-tab">
            <Link
              to={CostedItineraryScroll.VisaInsurance}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-110}
              className=""
            >
              <span className="icon">
                <span className="icon-visa" />
              </span>
              <span className="details">
                <span className="tab-name">Visa & Insurance</span>
                <span className={'tab-total-price ' + hidePriceClass}>
                  {' '}
                  &#8377;{' '}
                  {this.props.costedItinerary.visaCostings.totalVisaCost}
                </span>
              </span>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  render() {
    if (
      this.props.costedItinerary.itinerary.costed &&
      !this.props.costedItinerary.itinerary.staleCost
    ) {
      let packageRate =
        this.props.costedItinerary.costingConfiguration.packageRate || false;
      return (
        <div
          className={
            'row mobile-costing-nav ' + this.props.mobileCostingFooterClasses
          }
        >
          <ul className="footer-tab-pills">
            {packageRate ? this.renderPackageNavItem() : null}
            {packageRate ? null : this.renderFlightsNavItem()}
            {packageRate ? null : this.renderHotelNavItem()}
            {this.renderActivityNavItem()}
            {this.renderComboNavItem()}
            {this.renderTransferNavItem()}
            {this.props.costedItinerary.costingConfiguration
              .departureAirport !== '$$$'
              ? this.renderVisaInsuranceNavItem()
              : null}
          </ul>
        </div>
      );
    } else {
      return null;
    }
  }
}
