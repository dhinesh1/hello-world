import React, { Component } from 'react';
import ReactPlaceholder from 'react-placeholder';
import { RectShape } from 'react-placeholder/lib/placeholders';

const DummyComponent = () => <div>Dummy</div>;

export default class AlternateFlightsLoadingSingle extends Component {
  render() {
    return (
      <div className="panel panel-secondary alternate-flights-card">
        <div className="panel-body">
          <div className="col-md-6 col-xs-12 alternate-flights-single-block right-border">
            <div className="row v-spaced">
              <div className="col-xs-7">
                <div className="row">
                  <ReactPlaceholder
                    color="transparent"
                    className="animated-background"
                    type="text"
                    rows={1}
                    ready={this.props.loaderState}
                  >
                    <DummyComponent />
                  </ReactPlaceholder>
                  <ReactPlaceholder
                    color="transparent"
                    className="animated-background"
                    type="text"
                    rows={1}
                    ready={this.props.loaderState}
                  >
                    <DummyComponent />
                  </ReactPlaceholder>
                </div>
              </div>
              <div className="col-xs-5">
                <RectShape
                  color="transparent"
                  className="animated-background"
                  style={{ width: 100, height: 50 }}
                  ready={this.props.loaderState}
                >
                  <DummyComponent />
                </RectShape>
              </div>
            </div>
            <div className="row v-spaced default-option-container timing-row-of-3-default">
              <label className="col-xs-12">
                <div className="row">
                  <div className="col-xs-12">
                    <div className="row">
                      <div className="col-xs-11">
                        <div className="row">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                            ready={this.props.loaderState}
                          >
                            <DummyComponent />
                          </ReactPlaceholder>
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                            ready={this.props.loaderState}
                          >
                            <DummyComponent />
                          </ReactPlaceholder>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </label>
            </div>
          </div>
          <div className="col-md-6 col-xs-12 alternate-flights-single-block padding-left-20">
            <div className="row v-spaced">
              <div className="col-xs-7">
                <div className="row">
                  <ReactPlaceholder
                    color="transparent"
                    className="animated-background"
                    type="text"
                    rows={1}
                    ready={this.props.loaderState}
                  >
                    <DummyComponent />
                  </ReactPlaceholder>
                  <ReactPlaceholder
                    color="transparent"
                    className="animated-background"
                    type="text"
                    rows={1}
                    ready={this.props.loaderState}
                  >
                    <DummyComponent />
                  </ReactPlaceholder>
                </div>
              </div>
              <div className="col-xs-5">
                <RectShape
                  color="transparent"
                  className="animated-background"
                  style={{ width: 100, height: 50 }}
                  ready={this.props.loaderState}
                >
                  <DummyComponent />
                </RectShape>
              </div>
            </div>
            <div className="row v-spaced default-option-container timing-row-of-3-default">
              <label className="col-xs-12">
                <div className="row">
                  <div className="col-xs-12">
                    <div className="row">
                      <div className="col-xs-11">
                        <div className="row">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                            ready={this.props.loaderState}
                          >
                            <DummyComponent />
                          </ReactPlaceholder>
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                            ready={this.props.loaderState}
                          >
                            <DummyComponent />
                          </ReactPlaceholder>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </label>
            </div>
          </div>
          <div className="col-xs-12 top-border">
            <div className="row v-spaced no-bottom-margin">
              <div className="col-md-7 hidden-xs hidden-sm">
                <div className="row margin-top-5">
                  <div className="col-md-3 text-center">
                    <div className="row">
                      <ReactPlaceholder
                        color="transparent"
                        className="animated-background"
                        type="text"
                        rows={1}
                        ready={this.props.loaderState}
                      >
                        <DummyComponent />
                      </ReactPlaceholder>
                    </div>
                  </div>
                  <div className="col-md-6 text-center line-height-1-8">
                    <div className="row text-grey">
                      <ReactPlaceholder
                        color="transparent"
                        className="animated-background"
                        type="text"
                        rows={1}
                        ready={this.props.loaderState}
                      >
                        <DummyComponent />
                      </ReactPlaceholder>
                    </div>
                  </div>
                  <div className="col-md-3 line-height-1-8 text-center">
                    <div className="row text-grey" />
                  </div>
                </div>
              </div>
              <div className="col-md-5 col-sm-12 pull-right">
                <div className="col-sm-10 pull-right">
                  <div className="row pull-right">
                    <ReactPlaceholder
                      color="transparent"
                      className="animated-background"
                      type="text"
                      rows={1}
                      ready={this.props.loaderState}
                    >
                      <DummyComponent />
                    </ReactPlaceholder>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
