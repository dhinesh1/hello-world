import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { Collapse } from 'react-bootstrap';
import { AppConfig } from '../../../app-config';
import { encodeActivityKeyForURL } from '../../../helpers/utilsHelper';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  RENTAL_CAR_ALTERNATES,
  CHANGE_RENTAL_CAR_INSURANCE
} from '../../../helpers/routesHelper';
const booking_state_alert = AppConfig.booking_state_alert;

class RentalCarDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedIndex: -1,
      openGps: false,
      openIns: false
    };

    this.changeButtonClickHandler = this.changeButtonClickHandler.bind(this);
    this.removeButtonClickHandler = this.removeButtonClickHandler.bind(this);
    this.changeRentalCarInsurance = this.changeRentalCarInsurance.bind(this);
    this.changeGPS = this.changeGPS.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
  }

  removeButtonClickHandler() {
    // To do: remove rental car code
    this.props.onCloseModal();
  }

  changeRentalCarInsurance(e) {
    e && e.preventDefault();
    let { history, activeRCDetails, itineraryDetail } = this.props;

    let rcEncKey = encodeActivityKeyForURL(activeRCDetails.key);
    history.push(
      itineraryModalsRouteHelper({
        itineraryId: itineraryDetail.itineraryId,
        regionCode: itineraryDetail.regionCode,
        parentPage: routingPageType.inclusion,
        target: CHANGE_RENTAL_CAR_INSURANCE,
        customParams: { rcKey: rcEncKey }
      })
    );
  }

  changeGPS(type, rentalCar) {
    const data = {
      ...rentalCar,
      itineraryId: this.props.itineraryId,
      add: type === 'add'
    };
    this.props.changeGPS(data);
  }

  changeButtonClickHandler(e) {
    let { history, activeRCDetails, itineraryDetail } = this.props;

    let rcEncKey = encodeActivityKeyForURL(activeRCDetails.key);
    history.push(
      itineraryModalsRouteHelper({
        itineraryId: itineraryDetail.itineraryId,
        regionCode: itineraryDetail.regionCode,
        parentPage: routingPageType.inclusion,
        target: RENTAL_CAR_ALTERNATES,
        customParams: { rcKey: rcEncKey }
      })
    );
  }

  handleSelect(target) {
    this.setState({
      openGps: target === 'gps' ? !this.state.openGps : false,
      openIns: target === 'ins' ? !this.state.openIns : false
    });
  }

  render() {
    if (this.props.activeRCDetails !== undefined) {
      const rentalCar = this.props.activeRCDetails;
      const rcKey = rentalCar.rentalCarKey; // this.props.allRentalCostingRefs[0]

      return (
        <div className="modal-dialog" key={rcKey}>
          <div className={'modal-content with-header'}>
            <ModalHeader
              {...rentalCar}
              {...this.props}
              called_from={this.props.called_from}
              changeButtonClickHandler={this.changeButtonClickHandler}
              removeButtonClickHandler={this.removeButtonClickHandler}
              onCloseModal={this.props.onCloseModal}
              rcKey={rcKey}
            />
            <div className="modal-body">
              <ModalDetails
                {...rentalCar}
                {...this.state}
                splitPricing={this.props.splitPricing}
                handleSelect={this.handleSelect}
                changeRentalCarInsurance={this.changeRentalCarInsurance}
                changeGPS={this.changeGPS}
                rcKey={rcKey}
              />
            </div>
          </div>
        </div>
      );
    } else {
      return null;
    }
  }
}

const ModalDetails = props => {
  let image_url =
    props.image ||
    'https://www.thello.com/_meta/pictures/content_thello_rolling_stock/IMG_0360.jpg';

  return (
    <div className="modal-row">
      <div className="item-header">
        <h3>{props.pickup + ' to ' + props.drop}</h3>
        <span className="p block">
          <span className="bold color-secondary schedule">
            {props.numberOfCars || 1} {props.numberOfCars > 1 ? 'Cars' : 'Car'}{' '}
          </span>{' '}
          - By {props.carTitle}
        </span>
      </div>
      <div className="at-a-glance clearfix">
        <div className="col-xs-6 col-md-3">
          <span className="meta-text dim block">Renting From</span>
          {props.pickupDate} {props.pickupMonth} - {props.dropDate}{' '}
          {props.dropMonth}
        </div>
        <div className="col-xs-6 col-md-3">
          <span className="meta-text dim block">Duration</span>
          {props.duration} days
        </div>
        <div className="col-xs-6 col-md-3">
          <span className="meta-text dim block">Type</span>
          {props.carType}
        </div>
        {props.totalCost ? (
          <div className="col-xs-6 col-md-3">
            <span className="meta-text dim block">Total cost</span>
            <span className="WebRupee">Rs.</span> {props.totalCost || '-'}
          </div>
        ) : null}
      </div>
      <hr className="no-height mute" />

      <div className="flight-info spacer-both">
        <div className="row">
          <div className="col-xs-8 col-sm-12">
            <h5 className="no-margin">
              Gear - {props.gearType}, Capacity - {props.maxSeats} seater
            </h5>
            <span className="small">
              Maximum luggage - {props.maxLuggage} bags
            </span>
          </div>
          <div className="col-xs-4 no-padding hidden-sm hidden-md hidden-lg">
            <div className="media-shell">
              <figure
                className="hd"
                style={{ backgroundImage: `url(${image_url})` }}
              />
            </div>
          </div>
        </div>

        <div className="clearfix spacer">
          <div className="hidden-xs col-sm-3 text-center">
            <div className="media-shell">
              <figure
                className="hd"
                style={{ backgroundImage: `url(${image_url})` }}
              />
            </div>
          </div>
          <div className="col-xs-12 col-sm-9">
            <div className="col-xs-4 col-sm-4 no-padding">
              <span className="block meta-text dim">Pickup</span>
              {props.pickupTime}
              <span className="block meta-text dim">{props.pickup}</span>
            </div>
            <div className="col-xs-4 col-sm-4 no-padding text-left">
              <span className="block meta-text dim">Drop</span>
              {props.dropTime}
              <span className="block meta-text dim">{props.drop}</span>
            </div>
            <div className="col-xs-4 col-sm-4 no-padding text-left">
              <span className="block meta-text dim">GPS included?</span>
              Yes
            </div>
          </div>
        </div>
        <p className="meta-text dim">
          <span className="vehoicon-exclamation-circle" /> For self drive
          customers, Indian driving license (in English) and Credit Card is
          mandatory.
        </p>
      </div>

      <RentalCarTabs {...props} />
    </div>
  );
};

const ModalHeader = props => {
  let { itineraryDetail, makeReadOnly } = props;
  let { booking, frozen } = itineraryDetail;
  let isBlocked = booking || frozen || makeReadOnly;

  return (
    <div className="modal-header clearfix with-bg">
      <button
        type="button"
        onClick={props.onCloseModal}
        className="close"
        data-dismiss="modal"
      >
        <i className="vehoicon-close" />
      </button>
      <span className="meta-text semi-bold kern-more fade text-uppercase">
        Rental car info
      </span>

      <div className={'modal-actions'}>
        {isBlocked ? (
          <OverlayTrigger
            id="ot13"
            placement="top"
            overlay={<Tooltip id="cartooltip">{booking_state_alert}</Tooltip>}
          >
            <button
              type="button"
              id="activity-details-change"
              className={'btn btn-sm btn-primary change-cta disabled'}
            >
              Change
            </button>
          </OverlayTrigger>
        ) : (
          <button
            type="button"
            id="activity-details-change"
            onClick={props.changeButtonClickHandler}
            className={
              'btn btn-sm btn-primary change-cta' +
              (isBlocked ? 'disabled' : '')
            }
          >
            Change
          </button>
        )}
      </div>
    </div>
  );
};

const InsuranceTabPanel = props => {
  return (
    <div className="row spacer-both vertical-center">
      {props.showInsuranceData &&
      props.selectedInsurance &&
      props.selectedInsurance.totalCost > 0 ? (
        <div className="col-xs-12 meta-text">
          {props.selectedInsurance.insuranceName} for{' '}
          <span className="WebRupee">Rs.</span>{' '}
          {props.selectedInsurance.totalCost}
        </div>
      ) : null}
      <div className="col-xs-12">
        {props.showInsuranceData ? (
          <button
            className="btn btn-primary btn-sm pull-right"
            onClick={e => props.changeRentalCarInsurance(e)}
          >
            {props.insuranceCost > 0 ? 'Change Insurance' : 'Add Insurance'}
          </button>
        ) : (
          <div className="v-spaced">
            "We'd advice you to buy insurance when you pick up rental car."
          </div>
        )}
      </div>
    </div>
  );
};

const RentalCarTabs = props => {
  return (
    <div className="more-info clearfix" key={Math.random()}>
      <div className="pyt-nav-tab-shell">
        <div className="row">
          <div className="col-xs-12 col-sm-9">
            <ul className="clearfix list-unstyled tab-links meta-text">
              <li className={props.openIns ? 'active' : ''} role="presentation">
                <a
                  href="#"
                  onClick={e => {
                    e.preventDefault();
                    props.handleSelect('ins');
                  }}
                >
                  Change Insurance
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <Collapse in={props.openIns}>
        <div className="info-container">
          <InsuranceTabPanel {...props} />
        </div>
      </Collapse>
    </div>
  );
};

export default withRouter(RentalCarDetails);
