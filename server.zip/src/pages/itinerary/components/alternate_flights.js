import React, { Component, Fragment } from 'react';
import PriceDiff from '../../../common_components/price_diff';
import { getParentsUntil, getParents } from '../../../helpers/DomHelpers';
import classNames from 'classnames';

import {
  isNullorUndefined,
  getAirlineLogo
} from '../../../helpers/utilsHelper';
import SmartImage from '../../../common_components/Image/smart_image';

export default class AlternateFlights extends Component {
  constructor(props) {
    super(props);

    this.state = { element_status: '', defaultSelectedRadio: 0 };

    this.toggleTimingOptions = this.toggleTimingOptions.bind(this);
    this.populateAirportCodes = this.populateAirportCodes.bind(this);
    this.flightCellHelper = this.flightCellHelper.bind(this);
    this.onOptionChange = this.onOptionChange.bind(this);
  }

  onOptionChange() {
    this.setState({ defaultSelectedRadio: 999 });
  }

  toggleTimingOptions(element, e) {
    e.preventDefault(); // Let's stop this event.
    e.stopPropagation(); // Really this time.
    let currentFlightOption = getParents(
      getParentsUntil(
        document.querySelector(element),
        null,
        '.data-option-item'
      )
    );
    let htmlString;
    let linkText = `${element}-link-text`;
    let optionsCount = document
      .querySelector(linkText)
      .getAttribute('data-options-count');
    let cfo_class = currentFlightOption[0][0].className.replace(
      'options-on',
      ''
    );
    let allElements = Array.prototype.slice.call(
      document.querySelectorAll(element)
    );
    if (currentFlightOption[0][0].className.indexOf('options-on') > -1) {
      currentFlightOption[0][0].className = cfo_class;
      htmlString =
        "<span><span class='vehoicon-keyboard_arrow_down'></span> Show " +
        optionsCount +
        ' more timing option';
      if (optionsCount > 1) {
        htmlString += 's</span>';
      } else {
        htmlString += '</span>';
      }
      document.querySelector(linkText).innerHTML = htmlString;
      allElements.map(elem => {
        elem.className += ' hidden';
      });

      //   $(element)
      //     .addClass('animated fadeOut')
      //     .addClass('hidden');
    } else {
      currentFlightOption[0][0].className =
        currentFlightOption[0][0].className + ' options-on';
      let elementClass = '';
      let newElementClass = '';
      allElements.map(elem => {
        elementClass = elem.className;
        newElementClass = elementClass.replace('hidden', '');
        elem.className = newElementClass;
      });

      htmlString =
        "<span><span class='vehoicon-keyboard_arrow_up'></span> Collapse timing option";
      if (optionsCount > 1) {
        htmlString += 's</span>';
      } else {
        htmlString += '</span>';
      }
      document.querySelector(linkText).innerHTML = htmlString;
    }
    //this.props.setBackgroundHeight();
  }

  populateAirportCodes(tripDetails) {
    if (tripDetails.routes !== undefined) {
      let i = -1;
      return tripDetails.routes.map(route => {
        ++i;
        if (i === 0)
          return (
            <span key={Math.random()}>
              {' '}
              {route.departureAirportCode} → {route.arrivalAirportCode}
            </span>
          );
        else
          return (
            <span key={Math.random()}> → {route.arrivalAirportCode} </span>
          );
      });
    } else {
      return null;
    }
  }

  getAirlineLogoDetails(tripDetails) {
    let trip_route = tripDetails[0].routes[0];

    return getAirlineLogo(trip_route.carrierCode || '');
  }

  getConnectionDurationAndStopsCount(duration, r) {
    let stops = '';

    if (r.length - 1 === 0) stops = 'Direct';
    else if (r.length - 1 === 0) stops = `${r.length - 1} stop`;
    else stops = `${r.length - 1} stops`;

    let durHours = Math.floor(duration / 60);
    let durMinutes = duration % 60;

    if (durHours !== 0)
      if (durMinutes > 0) {
        return { stops: stops, duration: `${durHours}h ${durMinutes}m` };
      } else {
        if (durHours > 1)
          return { stops: stops, duration: `${durHours} hours` };
        else return { stops: stops, duration: `${durHours} hour` };
      }
    else return { stops: stops, duration: `${durMinutes}m` };
  }

  flightCellHelper(trip, leg, scenerio, order) {
    let refundability = trip.refundable ? (
      <span className="vehoicon-refundable color-success" />
    ) : (
      <span className="vehoicon-non-refundable color-danger" />
    );
    if (scenerio === 'ROUNDTRIP') {
      let tripDetailsOld = trip.flightTripsList[leg];
      let legId = leg + 1;

      const tripDetails = trip.flightCostingsList.map(costing => {
        const requiredFlight = costing.allTrips[leg];
        return costing.trips[requiredFlight];
      });

      return tripDetails.map((option, i) => {
        let lastIndex = option.routes.length - 1;
        let inputName = 'option-' + order + '-' + legId;
        let timingRowClassName = i > 0 ? `timing-row-of-${order} hidden` : '';

        let defaultCheckedflag = false;
        if (this.state.defaultSelectedRadio === 0) {
          defaultCheckedflag = i === 0;
        } else {
          defaultCheckedflag = false;
        }

        const identifier = trip.flightCostingsList[i]
          ? trip.flightCostingsList[i].identifier
          : '';
        const airlineImg = this.getAirlineLogoDetails(trip.flightTripsList[0]);
        return (
          <div key={i} className={'row spacer-both ' + timingRowClassName}>
            <div className="col-xs-3 col-md-4">
              <div className="airline-logo-fit no-padding">
                <SmartImage
                  disableLazyLoad
                  alt={airlineImg.name}
                  src={airlineImg.url}
                  defaultImage={airlineImg.default}
                />
              </div>
            </div>
            <div className="col-xs-9 col-md-8 flight-cell">
              {leg === 0 ? (
                defaultCheckedflag ? (
                  <input
                    type="radio"
                    name={inputName}
                    value={identifier}
                    onChange={this.onOptionChange}
                    checked="checked"
                    data-changes-stay-start-date={option.changesStayStartDate}
                  />
                ) : (
                  <input
                    type="radio"
                    name={inputName}
                    value={identifier}
                    onChange={this.onOptionChange}
                    data-changes-stay-start-date={option.changesStayStartDate}
                  />
                )
              ) : null}
              <time className="block">
                {option.routes[0].departureTime.substring(
                  0,
                  option.routes[0].departureTime.length - 3
                )}
                —{' '}
                {option.routes[lastIndex].arrivalTime.substring(
                  0,
                  option.routes[lastIndex].arrivalTime.length - 3
                )}
                <span className="mini dim">
                  {' '}
                  {option.routes[0].depDateOfMonth} {option.routes[0].depMonth}
                  <span />
                </span>
              </time>
              <span className="mini single-line-text dim">
                {
                  this.getConnectionDurationAndStopsCount(
                    option.duration,
                    option.routes
                  ).duration
                },{' '}
                {
                  this.getConnectionDurationAndStopsCount(
                    option.duration,
                    option.routes
                  ).stops
                }
              </span>
              <span className="mini single-line-text dim">
                {this.populateAirportCodes(option)}
              </span>
            </div>
            {leg === 1 ? (
              <div className="icon-attributes">
                {refundability}
                {/*<span className="vehoicon-no-luggage"></span>*/}
                {/*<span className="seats">4</span>*/}
              </div>
            ) : null}
          </div>
        );
      });
    } else {
      let tripDetails = trip.flightTripsList[leg];
      let legId = leg + 1;

      return tripDetails.map((option, i) => {
        let lastIndex = option.routes.length - 1;
        let inputName = 'option-' + order + '-' + legId;
        let timingRowClassName = i > 0 ? `timing-row-of-${order} hidden` : '';
        let defaultCheckedflag = false;
        if (this.state.defaultSelectedRadio === 0) {
          defaultCheckedflag = i === 0;
        } else {
          defaultCheckedflag = false;
        }

        const identifier = trip.flightCostingsList[i]
          ? trip.flightCostingsList[i].identifier
          : '';

        const airlineImg = this.getAirlineLogoDetails(trip.flightTripsList[0]);

        return (
          <div key={i} className={'row spacer-both ' + timingRowClassName}>
            <div className="col-xs-3 col-sm-2 col-md-2">
              <div className="airline-logo-fit no-padding">
                <SmartImage
                  disableLazyLoad
                  alt={airlineImg.name}
                  src={airlineImg.url}
                  defaultImage={airlineImg.default}
                />
              </div>
            </div>
            <div className="col-xs-9 col-sm-9 col-md-10 flight-cell">
              {defaultCheckedflag ? (
                <input
                  type="radio"
                  name={inputName}
                  value={identifier}
                  onChange={this.onOptionChange}
                  checked="checked"
                />
              ) : (
                <input
                  type="radio"
                  name={inputName}
                  onChange={this.onOptionChange}
                  value={identifier}
                />
              )}
              <div className="hidden-xs col-sm-6 col-md-5 no-padding">
                <time className="block">
                  {option.routes[0].departureTime.substring(
                    0,
                    option.routes[0].departureTime.length - 3
                  )}
                </time>
                <span className="mini single-line-text dim">
                  {option.routes[0].departureCity}
                </span>
                <span className="mini single-line-text dim">
                  {
                    this.getConnectionDurationAndStopsCount(
                      option.duration,
                      option.routes
                    ).stops
                  }
                </span>
              </div>
              <div className="hidden-xs col-sm-6 col-md-5">
                <time className="block">
                  {option.routes[lastIndex].arrivalTime.substring(
                    0,
                    option.routes[lastIndex].arrivalTime.length - 3
                  )}
                  <span className="mini dim">
                    &nbsp;{option.routes[0].depDateOfMonth}{' '}
                    {option.routes[0].depMonth}
                  </span>
                </time>
                <span className="mini single-line-text dim">
                  {option.routes[lastIndex].arrivalCity}
                </span>
                <span className="mini single-line-text dim">
                  {
                    this.getConnectionDurationAndStopsCount(
                      option.duration,
                      option.routes
                    ).duration
                  }
                </span>
              </div>
              <div className="col-xs-12 hidden-sm hidden-md hidden-lg flight-cell">
                <time className="block">
                  {option.routes[0].departureTime.substring(
                    0,
                    option.routes[0].departureTime.length - 3
                  )}&mdash;{option.routes[lastIndex].arrivalTime.substring(
                    0,
                    option.routes[lastIndex].arrivalTime.length - 3
                  )}
                  <span className="mini dim">
                    &nbsp;{option.routes[0].depDateOfMonth}{' '}
                    {option.routes[0].depMonth}
                  </span>
                </time>
                <span className="mini single-line-text dim">
                  {
                    this.getConnectionDurationAndStopsCount(
                      option.duration,
                      option.routes
                    ).duration
                  },{
                    this.getConnectionDurationAndStopsCount(
                      option.duration,
                      option.routes
                    ).stops
                  }
                </span>
              </div>
            </div>
            <div className="icon-attributes">{refundability}</div>
          </div>
        );
      });
    }
  }

  //New round trip card helper
  newRoundTripCardHelper(trip, i) {
    let timingRowClass = 'timing-row-of-' + i;
    let timingRowClassSel = '.timing-row-of-' + i;
    let show_more_timing_options_link = null;
    let maxOptionsofLR = trip.flightCostingsList.length - 1;

    if (trip.flightCostingsList.length > 1) {
      if (maxOptionsofLR === 1) {
        show_more_timing_options_link = (
          <span className="more-options">
            <a
              href="#"
              onClick={e => {
                this.toggleTimingOptions(timingRowClassSel, e);
              }}
              data-control={'' + timingRowClassSel}
              data-options-count={maxOptionsofLR}
              className={timingRowClass + '-link-text '}
            >
              <span className="vehoicon-keyboard_arrow_down" /> Show{' '}
              {maxOptionsofLR} more option
            </a>
          </span>
        );
      }
      if (maxOptionsofLR > 1) {
        show_more_timing_options_link = (
          <span className="more-options">
            <a
              href="#"
              onClick={e => {
                this.toggleTimingOptions(timingRowClassSel, e);
              }}
              data-control={'' + timingRowClassSel}
              data-options-count={maxOptionsofLR}
              className={timingRowClass + '-link-text '}
            >
              <span className="vehoicon-keyboard_arrow_down" />Show{' '}
              {maxOptionsofLR} more options
            </a>
          </span>
        );
      }
    }

    return (
      <article className="data-option-item test">
        <div className="data-option-item-wrapper">
          <div className="col-xs-9 col-sm-10 col-md-10 no-padding">
            <div className="col-xs-12 col-sm-6 col-md-6 splitter">
              {this.flightCellHelper(trip, 0, 'ROUNDTRIP', i)}
            </div>
            <div className="col-xs-12 col-sm-6 col-md-6">
              {this.flightCellHelper(trip, 1, 'ROUNDTRIP', i)}
            </div>
            {show_more_timing_options_link}
          </div>
          <div className="col-xs-3 col-sm-2 col-md-2 spacer-both no-padding">
            <div className="action price-info text-center">
              {trip.cost ? (
                <span className="price block">
                  <span className="WebRupee">Rs.</span>
                  {trip.cost}
                </span>
              ) : null}
              {trip.diffDetail ? (
                <PriceDiff
                  classNames={' price block '}
                  diff={trip.diffDetail}
                />
              ) : null}
              <button
                onClick={() => {
                  this.props.handleSelectedAlternateFlight(trip, i);
                }}
                className="btn btn-xs btn-primary hidden-sm hidden-xs"
              >
                Choose
              </button>
              <button
                onClick={() => {
                  this.props.handleSelectedAlternateFlight(trip, i);
                }}
                className="btn btn-sm btn-primary visible-xs visible-sm"
              >
                Choose
              </button>
            </div>
          </div>
        </div>
      </article>
    );
  }

  //New roundtrip card helper
  newOneWayCardHelper(trip, i) {
    let timingRowClass = 'timing-row-of-' + i;
    let timingRowClassSel = '.timing-row-of-' + i;
    let show_more_timing_options_link = null;
    let maxOptionsofLR = trip.flightCostingsList.length - 1;

    if (trip.flightCostingsList.length === 2) {
      show_more_timing_options_link = (
        <span className="more-options">
          <a
            href="#"
            onClick={e => {
              this.toggleTimingOptions(timingRowClassSel, e);
            }}
            data-control={'' + timingRowClassSel}
            data-options-count={maxOptionsofLR}
            className={timingRowClass + '-link-text '}
          >
            <span className="vehoicon-keyboard_arrow_down" />show{' '}
            {maxOptionsofLR} more option
          </a>
        </span>
      );
    } else if (trip.flightCostingsList.length > 2) {
      show_more_timing_options_link = (
        <span className="more-options">
          <a
            href="#"
            onClick={e => {
              this.toggleTimingOptions(timingRowClassSel, e);
            }}
            data-control={'' + timingRowClassSel}
            data-options-count={maxOptionsofLR}
            className={timingRowClass + '-link-text '}
          >
            <span className="vehoicon-keyboard_arrow_down" />Show{' '}
            {maxOptionsofLR} more options
          </a>
        </span>
      );
    } else {
    }

    return (
      <article className="data-option-item test" key={i}>
        <div className="data-option-item-wrapper">
          <div className="col-xs-9 col-sm-10 col-md-10 no-padding">
            <div className="col-xs-12 col-sm-12 col-md-12">
              {this.flightCellHelper(trip, 0, 'ONEWAY', i)}
            </div>
            {show_more_timing_options_link}
          </div>
          {/*Oneway timing options code should come here*/}
          <div className="col-xs-3 col-sm-2 col-md-2 spacer-both no-padding">
            <div className="action price-info text-center">
              {trip.cost ? (
                <span className="price block">
                  <span className="WebRupee">Rs.</span>
                  {trip.cost}
                </span>
              ) : null}
              {trip.diffDetail ? (
                <PriceDiff
                  classNames={' price block '}
                  diff={trip.diffDetail}
                />
              ) : null}
              <a
                onClick={() => {
                  this.props.handleSelectedAlternateFlight(trip, i);
                }}
                className="btn btn-xs btn-primary hidden-sm hidden-xs"
              >
                Choose
              </a>
              <a
                onClick={() => {
                  this.props.handleSelectedAlternateFlight(trip, i);
                }}
                className="btn btn-sm btn-primary visible-sm visible-xs"
              >
                Choose
              </a>
            </div>
          </div>
        </div>
      </article>
    );
  }

  renderAlternatesList() {
    let key = -1;
    return this.props.alternate_flights.map((af, i) => {
      ++key;
      const tripsList = af.flightCostingsList[0].allTrips;
      if (tripsList.length === 1) {
        return (
          <section key={key} className="change-data flat-list">
            {this.newOneWayCardHelper(af, i)}
          </section>
        );
      } else {
        return (
          <section className="change-data flat-list" key={key}>
            {this.newRoundTripCardHelper(af, i)}
          </section>
        );
      }
    });
  }

  render() {
    let showing_header_message = 'Showing available flight options';
    let content = null;
    if (this.state.element_status === 'LOADING') {
      content = (
        <div className="col-xs-12 text-center">
          <div className="inline-block block-center vmargin-large">
            <div className="clearfix">
              <div className="loading-dots" />
              <div className="loading-dots" />
              <div className="loading-dots" />
            </div>
          </div>
        </div>
      );
      showing_header_message = (
        <span className="mini block dim bold text-center spacer">
          Loading available flight for applied filters
        </span>
      );
    } else {
      if (
        !isNullorUndefined(this.props.alternate_flights) &&
        this.props.alternate_flights.length > 0
      ) {
        content = this.renderAlternatesList();
        showing_header_message = (
          <Fragment>
            <span className="block dim text-center vmargin-medium meta-text">
              {this.props.alternate_flights.length} available options to choose
              from
            </span>
          </Fragment>
        );
      } else {
        showing_header_message = (
          <span className="block dim text-center vmargin-medium meta-text">
            Oops! No flight found for the applied filters
          </span>
        );

        content = (
          <div className="col-xs-12 text-center">
            <img
              className="no-alternates-illustrartion"
              src="https://pyt-images.imgix.net/images/misc/not_found_icon.png"
              alt="Not found"
            />
          </div>
        );
      }
    }

    return (
      <div
        className={classNames('modal-row', {
          'pt-0': this.props.currentPick.status !== 'SUCCESS'
        })}
      >
        <div className={'row'}>
          {showing_header_message}
          {content}
        </div>
      </div>
    );
  }
}
