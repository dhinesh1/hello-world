import React, { Component } from 'react';
import _ from 'lodash';
import { Checkbox } from 'react-bootstrap';
import { Range } from 'rc-slider';
import { isNullorUndefined } from '../../../helpers/utilsHelper';

import { getCheckedBoxes } from '../../../helpers/DomHelpers';

export default class AlternateFlightsFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedDepartureTimeFilterText: 'Any time',
      selectedArrivalTimeFilterText: 'Any time',
      departureIncludeAllTimings: true,
      arrivalIncludeAllTimings: true,
      appliedFilters: {
        sourceProvider: props.currentPick.ourSourceProvider,
        includeNonStop: true,
        includeOneStop: true,
        includeTwoStops: true,
        includeRefundable: true,
        includeNonRefunable: true,
        includeAllAirlines: true,
        onwardSelectedDepAirportCode: this.props.filterOptions
          .onwardSelectedDepAirportCode,
        onwardSelectedArrAirportCode: this.props.filterOptions
          .onwardSelectedArrAirportCode,
        returnSelectedDepAirportCode: this.props.filterOptions
          .returnSelectedDepAirportCode,
        returnSelectedArrAirportCode: this.props.filterOptions
          .returnSelectedArrAirportCode,
        onwardArrAirportOptions: this.props.filterOptions
          .onwardArrAirportOptions,
        onwardDepAirportOptions: this.props.filterOptions
          .onwardDepAirportOptions,
        returnArrAirportOptions: this.props.filterOptions
          .returnArrAirportOptions,
        returnDepAirportOptions: this.props.filterOptions
          .returnDepAirportOptions,
        airlineCodesToBeIncluded: [],
        includeAllTimings: true,
        onwardDepartureTimes: [],
        returnDepartureTimes: [],
        fromPrice: this.props.filterOptions.minCost,
        toPrice: this.props.filterOptions.maxCost,
        applyOJFilter: false,
        isInternational: this.props.filterOptions.isInternational,
        routeInfo: {}
      }
    };
    this.getTimeStringFromValue = this.getTimeStringFromValue.bind(this);
    this.renderAirlineFilters = this.renderAirlineFilters.bind(this);
    this.handleStopsCheckboxChange = this.handleStopsCheckboxChange.bind(this);
    this.handlePriceRangeSliderChange = this.handlePriceRangeSliderChange.bind(
      this
    );
    this.getStartTimeAndEndTimeByStep = this.getStartTimeAndEndTimeByStep.bind(
      this
    );
    this.getTimeStringFromMinutes = this.getTimeStringFromMinutes.bind(this);
    this.applyFlightFilters = this.applyFlightFilters.bind(this);
    this.applyProviderFilters = this.applyProviderFilters.bind(this);
  }

  applyProviderFilters(event) {
    let newState = this.state;
    newState.appliedFilters.sourceProvider = event.target.value;
    newState.appliedFilters.fromPrice = 0;
    newState.appliedFilters.toPrice = 100000000;
    newState.appliedFilters.includeAllAirlines = true;
    this.setState(newState, () => {
      this.props.handler(this.state.appliedFilters);
    });
  }

  renderAirportRadioButtons = (selectedAirport, airportOptions, type) => {
    try {
      const optionsArray = _.cloneDeep(airportOptions || []);
      optionsArray.unshift(selectedAirport);
      let allAirports = (optionsArray || []).map((airportCode, inx) => {
        return (
          <label className="custom-options" key={inx}>
            <input
              name={type}
              type="radio"
              value={airportCode}
              defaultChecked={selectedAirport === airportCode}
              onClick={() => this.onChangeAirportCode(type, airportCode)}
            />
            <span>{airportCode}</span>
            <i />
          </label>
        );
      });
      return allAirports;
    } catch (e) {
      return null;
    }
  };

  onChangeAirportCode = (type, code) => {
    let appliedFilters = _.cloneDeep(this.state.appliedFilters);
    appliedFilters = {
      ...appliedFilters,
      [type]: code,
      isInternational: true
    };

    this.setState(
      state => {
        return {
          ...state,
          appliedFilters
        };
      },
      () => {
        this.props.handler(this.state.appliedFilters);
      }
    );
  };

  applyFlightFilters() {
    let newState = this.state;
    let selectedAirlines = getCheckedBoxes('airlines_filter') || [];
    let selectedAirlineCodes = selectedAirlines.map(sa => {
      return sa.value;
    });

    // $('#alternate-flights-hide-filter-btn').trigger('click');
    // let chosen_airlines = $('input[name=airlines_filter]:checkbox:checked')
    //   .map(function() {
    //     return $(this).val();
    //   })
    //   .get();

    // let chosen_airlines = [];
    if (selectedAirlineCodes.length > 0) {
      newState.appliedFilters.airlineCodesToBeIncluded = selectedAirlineCodes;
      newState.appliedFilters.includeAllAirlines = false;
    } else {
      // newState.appliedFilters.airlineCodesToBeIncluded = [];
      newState.appliedFilters.includeAllAirlines = true;
    }
    newState.appliedFilters.applyOJFilter = document.getElementById(
      'flights-oj-filter'
    ).checked;

    this.setState(newState, () => {
      let constructedFilter = this.state.appliedFilters;
      this.props.handler(constructedFilter);
    });
  }

  // componentDidMount() {
  //   $(document).ready(() => {
  //     $("#flights-oj-filter").prop("checked", true);
  //   });
  // }

  getStartTimeAndEndTimeByStep(step, tripWay) {
    let newState = this.state;
    let onwardFlightTimings;
    let returnFlightTimings;
    /*Deals in minutes */
    if (tripWay === 'DEPARTURE') {
      switch (step) {
        case 1: {
          onwardFlightTimings = { flightStartTime: 0, flightEndTime: 1000 };
          newState.departureIncludeAllTimings = true;
          break;
        }
        case 2: {
          onwardFlightTimings = { flightStartTime: 0, flightEndTime: 359 };
          newState.departureIncludeAllTimings = false;
          break;
        }
        case 3: {
          onwardFlightTimings = { flightStartTime: 360, flightEndTime: 719 };
          newState.departureIncludeAllTimings = false;
          break;
        }
        case 4: {
          onwardFlightTimings = { flightStartTime: 720, flightEndTime: 1079 };
          newState.departureIncludeAllTimings = false;
          break;
        }
        case 5: {
          onwardFlightTimings = { flightStartTime: 1080, flightEndTime: 1439 };
          newState.departureIncludeAllTimings = false;
          break;
        }
        default: {
          newState.appliedFilters.onwardDepartureTimes = [];
          newState.departureIncludeAllTimings = true;
          break;
        }
      }
      //checking whether the unselected item is already available in an arary.
      //if it is available removing the object from the array.
      //for onwardDepartureTimes.
      let isDuplicateValue = false;
      let isDuplicate = newState.appliedFilters.onwardDepartureTimes.some(
        function(el, index) {
          if (
            el.flightEndTime === onwardFlightTimings.flightEndTime &&
            el.flightStartTime === onwardFlightTimings.flightStartTime
          ) {
            newState.appliedFilters.onwardDepartureTimes.splice(index, 1);
            isDuplicateValue = true;
          }
        }
      );
      //if the object is not in an array push the object
      if (!isDuplicateValue) {
        newState.appliedFilters.onwardDepartureTimes.push(onwardFlightTimings);
      }
    } else {
      switch (step) {
        case 1: {
          returnFlightTimings = { flightStartTime: 0, flightEndTime: 1000 };
          newState.arrivalIncludeAllTimings = true;
          break;
        }
        case 2: {
          returnFlightTimings = { flightStartTime: 0, flightEndTime: 359 };
          newState.arrivalIncludeAllTimings = false;
          break;
        }
        case 3: {
          returnFlightTimings = { flightStartTime: 360, flightEndTime: 719 };
          newState.arrivalIncludeAllTimings = false;
          break;
        }
        case 4: {
          returnFlightTimings = { flightStartTime: 720, flightEndTime: 1079 };
          newState.arrivalIncludeAllTimings = false;
          break;
        }
        case 5: {
          returnFlightTimings = { flightStartTime: 1080, flightEndTime: 1439 };
          newState.arrivalIncludeAllTimings = false;
          break;
        }
        default: {
          newState.appliedFilters.returnDepartureTimes = [];
          newState.arrivalIncludeAllTimings = true;
          break;
        }
      }

      //checking whether the unselected item is already available in an arary
      //if it is available removing the object from the array.
      //for returnDepartureTimes.
      let isDuplicateValue = false;
      let isDuplicate = newState.appliedFilters.returnDepartureTimes.some(
        function(el, index) {
          if (
            el.flightEndTime === returnFlightTimings.flightEndTime &&
            el.flightStartTime === returnFlightTimings.flightStartTime
          ) {
            newState.appliedFilters.returnDepartureTimes.splice(index, 1);
            isDuplicateValue = true;
          }
        }
      );
      //if the object is not in an array push the object
      if (!isDuplicateValue) {
        newState.appliedFilters.returnDepartureTimes.push(returnFlightTimings);
      }
    }
    newState.appliedFilters.includeAllTimings =
      newState.departureIncludeAllTimings && newState.arrivalIncludeAllTimings;

    this.setState(newState);
  }

  renderAirlineFilters(airlines) {
    let allAirlines = (airlines || []).map((airline, inx) => (
      <div className="clearfix">
        <label className="custom-options">
          <input
            type="checkbox"
            onClick={this.applyFlightFilters}
            key={'airline_filter_' + inx + airline.airlineCode}
            value={airline.airlineCode}
            name="airlines_filter"
          />
          <span>{airline.airlineName}</span>
          <i />
        </label>
      </div>
    ));

    return (
      <div className="filter-grp tracker-flights-airlines">{allAirlines}</div>
    );
  }

  getTimeStringFromValue(v) {
    let newState = this.state;
    switch (v) {
      case 1: {
        newState.appliedFilters.includeAllTimings = true;
        return 'Any time';
      }
      case 2: {
        newState.appliedFilters.includeAllTimings = false;
        return '12am-6am';
      }
      case 3: {
        newState.appliedFilters.includeAllTimings = false;
        return '6am-12pm';
      }
      case 4: {
        newState.appliedFilters.includeAllTimings = false;
        return '12pm-6pm';
      }
      case 5: {
        newState.appliedFilters.includeAllTimings = false;
        return '6pm-12am';
      }
      default: {
        newState.appliedFilters.includeAllTimings = false;
        return '6pm-12am';
      }
    }
  }

  getTimeStringFromMinutes(v) {
    switch (v) {
      case 10000: {
        return 'Any time';
      }
      case 359: {
        return '12am-6am';
      }
      case 719: {
        return '6am-12pm';
      }
      case 1079: {
        return '12pm-6pm';
      }
      case 1439: {
        return '6pm-12am';
      }
      default: {
        return '6pm-12am';
      }
    }
  }

  handleStopsCheckboxChange(stop) {
    let newState = this.state;
    newState.appliedFilters[stop] = !newState.appliedFilters[stop];
    this.setState(newState);
    this.applyFlightFilters();
  }

  handlePriceRangeSliderChange(value) {
    let newState = this.state;
    newState.appliedFilters.fromPrice = value[0];
    newState.appliedFilters.toPrice = value[1];
    this.setState(newState);
  }

  componentDidUpdate() {
    // $('.alternate-filter-block').width(
    //   $('#alt-flights-filter-container').width() + 'px'
    // );
    // $('#alternate-flights-filter').width(
    //   $('#alt-flights-filter-container').width() + 'px'
    // );
  }

  applyJourneyTimingFilter(e, selectedOption, trip, optionId) {
    let selectedOptionClassName = document.querySelector(selectedOption)
      .className;
    if (selectedOptionClassName.indexOf('active') > -1) {
      document.querySelector(
        selectedOption
      ).className = selectedOptionClassName.replace('active', '');

      if (trip === 'onward')
        this.getStartTimeAndEndTimeByStep(optionId, 'DEPARTURE');
      // 0 in the first parameter sets value for Any time i.e 0 - 10000
      else this.getStartTimeAndEndTimeByStep(optionId, 'ARRIVAL'); // 0 in the first parameter sets value for Any time i.e 0 - 10000
    } else {
      if (selectedOptionClassName.indexOf('active') === -1) {
        document.querySelector(selectedOption).className += ' active';
      }
      if (trip === 'onward')
        this.getStartTimeAndEndTimeByStep(optionId, 'DEPARTURE');
      else this.getStartTimeAndEndTimeByStep(optionId, 'ARRIVAL');
    }
    this.applyFlightFilters();
  }

  render() {
    if (_.isEmpty(this.props.filterOptions)) {
      return null;
    } else {
      return (
        <div className="modal-alternate-filters filter-white full-hgt">
          <div className="modal-filter-header xs-hdr">
            <div className="header-bar">
              <button
                id="alternate-activities-hide-filter-btn"
                onClick={this.props.handleFilterCloseIconClick}
                type="button"
                className={'close filter-toggle clear-box-shadow visible-xs'}
              >
                <span className="vehoicon-previous" aria-hidden="true" />
              </button>
              {/*<span className="text-uppercase kern-more bolder fade">Filters</span>*/}
            </div>
          </div>

          <div
            className="filter-content tracker-flights-filter xs-midcontent"
            id="alternate-flights-filter"
          >
            <h5 className="fade">Departure times</h5>
            <span className="small dim block bold">Onward journey:</span>
            <div
              className="filter-grp btn-group btn-filter-group tracker-onwardjourney"
              role="group"
              aria-label="Basic example"
            >
              <a
                type="button"
                id="OTR_1"
                className="btn btn-sm btn-filter onward-journey-option"
                onClick={e =>
                  this.applyJourneyTimingFilter(e, '#OTR_1', 'onward', 2)
                }
              >
                <span className="vehoicon-late-eve" />12am-6am
              </a>
              <a
                type="button"
                id="OTR_2"
                className="btn btn-sm btn-filter onward-journey-option"
                onClick={e =>
                  this.applyJourneyTimingFilter(e, '#OTR_2', 'onward', 3)
                }
              >
                <span className="vehoicon-sunrise" />6am-12pm
              </a>
              <a
                type="button"
                id="OTR_3"
                className="btn btn-sm btn-filter onward-journey-option"
                onClick={e =>
                  this.applyJourneyTimingFilter(e, '#OTR_3', 'onward', 4)
                }
              >
                <span className="vehoicon-sunset" />12pm-6pm
              </a>
              <a
                type="button"
                id="OTR_4"
                className="btn btn-sm btn-filter onward-journey-option"
                onClick={e =>
                  this.applyJourneyTimingFilter(e, '#OTR_4', 'onward', 5)
                }
              >
                <span className="vehoicon-moon" />6pm-12am
              </a>
            </div>
            {this.props.currentPick.allTrips.length === 1 ? null : (
              <span className="small bold dim block half-spacer-top">
                Return journey:
              </span>
            )}
            {this.props.currentPick.allTrips.length === 1 ? null : (
              <div
                className="filter-grp btn-group btn-filter-group tracker-returnjourney"
                role="group"
                aria-label="Basic example"
              >
                <a
                  type="button"
                  id="RTR_1"
                  className="btn btn-sm btn-filter return-journey-option"
                  onClick={e =>
                    this.applyJourneyTimingFilter(e, '#RTR_1', 'return', 2)
                  }
                >
                  <span className="vehoicon-late-eve" />12am-6am
                </a>
                <a
                  type="button"
                  id="RTR_2"
                  className="btn btn-sm btn-filter return-journey-option"
                  onClick={e =>
                    this.applyJourneyTimingFilter(e, '#RTR_2', 'return', 3)
                  }
                >
                  <span className="vehoicon-sunrise" />6am-12pm
                </a>
                <a
                  type="button"
                  id="RTR_3"
                  className="btn btn-sm btn-filter return-journey-option"
                  onClick={e =>
                    this.applyJourneyTimingFilter(e, '#RTR_3', 'return', 4)
                  }
                >
                  <span className="vehoicon-sunset" />12pm-6pm
                </a>
                <a
                  type="button"
                  id="RTR_4"
                  className="btn btn-sm btn-filter return-journey-option"
                  onClick={e =>
                    this.applyJourneyTimingFilter(e, '#RTR_4', 'return', 5)
                  }
                >
                  <span className="vehoicon-moon" />6pm-12am
                </a>
              </div>
            )}
            {this.props.userDetails &&
            this.props.userDetails.userType === 'ADMIN' &&
            (this.state.appliedFilters.sourceProvider === 'PYTON' ||
              this.state.appliedFilters.sourceProvider === 'SKYPICKER') ? (
              <React.Fragment>
                <hr className="mute" />
                <h5 className="fade">Provider</h5>
                <div className="filter-grp tracker-flights-provider">
                  <div className="clearfix">
                    <label className="custom-options">
                      <input
                        type="radio"
                        onClick={this.applyProviderFilters}
                        value={'PYTON'}
                        name="provider_filter"
                        checked={
                          !isNullorUndefined(
                            this.state.appliedFilters.sourceProvider
                          ) &&
                          this.state.appliedFilters.sourceProvider === 'PYTON'
                        }
                      />
                      <span>Pyton</span>
                      <i />
                    </label>
                  </div>
                  <div className="clearfix">
                    <label className="custom-options">
                      <input
                        type="radio"
                        onClick={this.applyProviderFilters}
                        value={'SKYPICKER'}
                        name="provider_filter"
                        checked={
                          !isNullorUndefined(
                            this.state.appliedFilters.sourceProvider
                          ) &&
                          this.state.appliedFilters.sourceProvider ===
                            'SKYPICKER'
                        }
                      />
                      <span>SkyPicker</span>
                      <i />
                    </label>
                  </div>
                </div>
              </React.Fragment>
            ) : null}
            <hr className="mute" />
            {this.state.appliedFilters.returnSelectedArrAirportCode ? (
              <div className="filter-grp tracker-airport-code-international">
                <section className="clearfix fw">
                  <h5 className="fade">Onward journey:</h5>
                  <span className="small dim block bold">From</span>
                  <div className="inline-labels">
                    {this.renderAirportRadioButtons(
                      this.state.appliedFilters.onwardSelectedDepAirportCode,
                      this.state.appliedFilters.onwardDepAirportOptions,
                      'onwardDepartureAirportCode',
                      true
                    )}
                  </div>
                  <span className="small dim block bold">To</span>
                  <div className="inline-labels">
                    {this.renderAirportRadioButtons(
                      this.state.appliedFilters.onwardSelectedArrAirportCode,
                      this.state.appliedFilters.onwardArrAirportOptions,
                      'onwardArrivalAirportCode',
                      true
                    )}
                  </div>
                </section>
                <section className="clearfix fw">
                  <h5 className="fade">Return journey:</h5>
                  <span className="small dim block bold">From</span>
                  <div className="inline-labels">
                    {this.renderAirportRadioButtons(
                      this.state.appliedFilters.returnSelectedDepAirportCode,
                      this.state.appliedFilters.returnDepAirportOptions,
                      'returnDepartureAirportCode',
                      true
                    )}
                  </div>
                  <span className="small dim block bold">To</span>
                  <div className="inline-labels">
                    {this.renderAirportRadioButtons(
                      this.state.appliedFilters.returnSelectedArrAirportCode,
                      this.state.appliedFilters.returnArrAirportOptions,
                      'returnArrivalAirportCode',
                      true
                    )}
                  </div>
                </section>
              </div>
            ) : (
              <div className="filter-grp tracker-airport-code-domestic">
                <section className="clearfix fw">
                  <h5 className="fade">Onward journey:</h5>
                  <span className="small dim block bold">From</span>
                  <div className="inline-labels">
                    {this.renderAirportRadioButtons(
                      this.state.appliedFilters.onwardSelectedDepAirportCode,
                      this.state.appliedFilters.onwardDepAirportOptions,
                      'onwardDepartureAirportCode',
                      false
                    )}
                  </div>
                  <span className="small dim block bold">To</span>
                  <div className="inline-labels">
                    {this.renderAirportRadioButtons(
                      this.state.appliedFilters.onwardSelectedArrAirportCode,
                      this.state.appliedFilters.onwardArrAirportOptions,
                      'onwardArrivalAirportCode',
                      false
                    )}
                  </div>
                </section>
              </div>
            )}

            <hr className="mute" />
            <h5 className="fade">Type</h5>
            <div className="filter-grp tracker-flights-type">
              <div className="clearfix">
                <label className="custom-options">
                  <input
                    type="checkbox"
                    defaultChecked={true}
                    onChange={() =>
                      this.handleStopsCheckboxChange('includeNonStop')
                    }
                    name="stops"
                    value="0"
                  />
                  <span>Direct</span>
                  <i />
                </label>
              </div>
              <div className="clearfix">
                <label className="custom-options">
                  <input
                    type="checkbox"
                    defaultChecked={true}
                    onChange={() =>
                      this.handleStopsCheckboxChange('includeOneStop')
                    }
                    name="stops"
                    value="1"
                  />
                  <span>1 Stop</span>
                  <i />
                </label>
              </div>
              <div className="clearfix">
                <label className="custom-options">
                  <input
                    type="checkbox"
                    defaultChecked={true}
                    onChange={() =>
                      this.handleStopsCheckboxChange('includeTwoStops')
                    }
                    name="stops"
                    value="2"
                  />
                  <span>2 Stops</span>
                  <i />
                </label>
              </div>
            </div>
            <hr className="mute" />

            {this.props.splitPricing
              ? [
                  <h5 className="fade">Total price</h5>,
                  <Range
                    min={this.props.filterOptions.minCost}
                    max={this.props.filterOptions.maxCost}
                    defaultValue={[
                      this.props.filterOptions.minCost,
                      this.props.filterOptions.maxCost
                    ]}
                    range={true}
                    onChange={this.handlePriceRangeSliderChange}
                    onAfterChange={this.applyFlightFilters}
                  />,
                  <div>
                    <span className="medium-bold">
                      <span className="WebRupee">Rs.</span>
                      {this.state.appliedFilters.fromPrice}
                    </span>
                    <span className="pull-right medium-bold">
                      <span className="WebRupee">Rs.</span>
                      {this.state.appliedFilters.toPrice}
                    </span>
                  </div>
                ]
              : null}

            <div className="filter-grp tracker-flights-refund">
              <div className="clearfix">
                <label className="custom-options">
                  <input
                    type="checkbox"
                    defaultChecked={true}
                    name="types"
                    onClick={() =>
                      this.handleStopsCheckboxChange('includeRefundable')
                    }
                  />
                  <span>Refundable</span>
                  <i />
                </label>
              </div>
              <div className="clearfix">
                <label className="custom-options">
                  <input
                    type="checkbox"
                    defaultChecked={true}
                    name="types"
                    onClick={() =>
                      this.handleStopsCheckboxChange('includeNonRefunable')
                    }
                  />
                  <span>Non-Refundable</span>
                  <i />
                </label>
              </div>
            </div>
            <hr className="mute" />
            <h5 className="fade">Airlines</h5>
            {this.renderAirlineFilters(this.props.filterOptions.airlines)}
            <hr className="mute" />
            <h5 className="fade">
              <div className="clearfix">
                <label className="custom-options">
                  <input
                    type="checkbox"
                    defaultChecked={false}
                    onClick={this.applyFlightFilters}
                    id="flights-oj-filter"
                    name="oj-filter"
                    className="tracker-pytflights"
                  />
                  <span>Pickyourtrail Filter</span>
                  <i />
                </label>
              </div>
            </h5>
            <div className="filter-grp">
              <p className="dim small">
                Pickyourtrail filters out flights with times inconvenient to
                your travel plans. Turn off the filter to have more flights
                listed.
              </p>
            </div>
          </div>

          <div className="xs-ftr visible-xs">
            <button
              onClick={this.props.handleFilterCloseIconClick}
              type="button"
              className="btn btn-primary filter-update-btn btn-block"
            >
              Update
            </button>
          </div>
        </div>
      );
    }
  }
}
