import React from 'react';
import CallToAction from './visa_call_to_action';

const NonShenganVisaPanels = props => {
  let visaCost = props.visaId ? props.totalCost : '0';

  return (
    <article className="row-costed-item row">
      <div className="col-xs-9 col-sm-9 col-md-10 spacer">
        <h5 className="no-margin">
          Visa {props.onArrival ? 'on arrival' : 'fees'} for {props.country}
        </h5>
        <p className="costed-item-details meta-text">
          {props.onArrival && props.notes ? (
            <span className="pill color-white bg-accent-4">Important</span>
          ) : null}
          <span className="meta-text dim">
            {' '}
            {props.notes && props.notes.length > 0 ? props.notes[0] : null}{' '}
            {!props.onArrival ? (
              <a
                href="http://visa.pickyourtrail.com/"
                target="_blank"
                className="blue-link"
              >
                Know more about Visa requirements
              </a>
            ) : null}
          </span>
        </p>
        {!props.onArrival ? (
          <div className="row">
            <div className="col-xs-12">
              <span className="fine-text dim bold">Includes:</span>
              {props.country.toLowerCase() === 'vietnam' ? (
                <p className="fine-text dim"> Visa approval letter </p>
              ) : (
                <p className="fine-text dim">Visa and related services </p>
              )}
            </div>
          </div>
        ) : null}
      </div>
      {!props.onArrival ? (
        <div className="col-xs-3 col-sm-3 col-md-2 spacer">
          <div className="action price-info text-center">
            {visaCost ? (
              <span className="price block">
                <span className="WebRupee">Rs.</span>
                {visaCost}
              </span>
            ) : null}
            {props.allowEditingOptions ? (
              <CallToAction
                isNoVisa={!props.required}
                isNZ={
                  !props.required
                    ? false
                    : props.visaId
                      ? props.country &&
                        props.country.toLowerCase() === 'new zealand'
                      : false
                }
                visaId={props.visaId}
                isBooked={props.isBooked}
                handleCallToActionClick={props.handleCallToActionClick}
              />
            ) : null}
          </div>
        </div>
      ) : null}
    </article>
  );
};

export default NonShenganVisaPanels;
