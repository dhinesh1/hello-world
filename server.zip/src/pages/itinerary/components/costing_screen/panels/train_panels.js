import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { AppConfig } from '../../../../../app-config';
import { encodeCostingKeyForURL } from '../../../../../helpers/utilsHelper';
import TrainContainer from '../../../../../common_components/train_container';
import NoCostingObjectErrorBlock from './noCostingObjectErrorBlock';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  TRAIN_DETAILS,
  TRAIN_ALTERNATES
} from '../../../../../helpers/routesHelper';
import { bindActionCreators } from 'redux';
import { manageInterCityTransfer } from '../../../../../actions/actions_app';

const booking_state_alert = AppConfig.booking_state_alert;

/*global swal */

class TrainPanels extends Component {
  constructor(props) {
    super(props);

    this.onChangeClick = this.onChangeClick.bind(this);
    this.onViewDetailsClick = this.onViewDetailsClick.bind(this);
    this.handleCallToActionClick = this.handleCallToActionClick.bind(this)
  }

  renderRefundability(refundability) {
    if (refundability)
      return (
        <li>
          <span className="color-success vehoicon-refundable" /> Refundable
        </li>
      );
    else
      return (
        <li>
          <span className="color-danger vehoicon-non-refundable" /> Non
          Refundable
        </li>
      );
  }

  onChangeClick(train, e) {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();

    let { history, itineraryId, regionCode } = this.props;
    let currentKey = encodeCostingKeyForURL(train.key);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode,
        parentPage: routingPageType.inclusion,
        target: TRAIN_ALTERNATES,
        customParams: { trainKey: currentKey }
      })
    );
  }

  onViewDetailsClick(train, e) {
    e.preventDefault();
    let { history, itineraryId, regionCode } = this.props;
    let currentKey = encodeCostingKeyForURL(train.key);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode,
        parentPage: routingPageType.inclusion,
        target: TRAIN_DETAILS,
        customParams: { trainKey: currentKey }
      })
    );
  }

  handleCallToActionClick(payload, e) {
    e && e.preventDefault();
    this.props
      .manageInterCityTransfer(payload)
      .then()
      .catch();
  }

  renderTrainPanels() {
    let {
      userDetails,
      trainRefs,
      isBooked,
      trainCostingObj,
      itineraryId,
      regionCode,
      makeReadOnly
    } = this.props;

    if (trainRefs !== undefined && trainCostingObj !== undefined) {
      return trainRefs.map(trainId => {
        let train =
          trainCostingObj.trainCostingById &&
          trainCostingObj.trainCostingById[trainId];

        // Handler for missed costing
        if (!train) {
          return (
            <NoCostingObjectErrorBlock failedFor="train" isLastRow={false} />
          );
        }

        return (
          <TrainContainer
            key={trainId}
            train={train}
            userDetails={userDetails}
            isBooked={isBooked}
            booking_state_alert={booking_state_alert}
            history={this.props.history}
            onChangeClick={this.onChangeClick}
            onViewDetailsClick={this.onViewDetailsClick}
            regionCode={regionCode}
            itineraryId={itineraryId}
            makeReadOnly={makeReadOnly}
            handleCallToActionClick={this.handleCallToActionClick}
          />
        );
      });
    } else {
      return null;
    }
  }

  render() {
    return (
      <section className="transfers" id="all-train-panels">
        {this.renderTrainPanels()}
      </section>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    manageInterCityTransfer: bindActionCreators(manageInterCityTransfer, dispatch)
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TrainPanels)
);