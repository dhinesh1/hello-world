import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import _ from 'lodash';
import { encodeActivityKeyForURL } from '../../../../../helpers/utilsHelper';
import PassContainter from '../../../../../common_components/pass_container';

class ComboPanels extends Component {
  constructor(props) {
    super(props);

    this.renderActivityInclusions = this.renderActivityInclusions.bind(this);
    this.renderSinglePass = this.renderSinglePass.bind(this);
    this.renderAllPasses = this.renderAllPasses.bind(this);
    this.renderSingleActivityInclusion = this.renderSingleActivityInclusion.bind(
      this
    );

    this.handleDetailsClick = this.handleDetailsClick.bind(this);
    this.renderSingleTransferInclusion = this.renderSingleTransferInclusion.bind(
      this
    );
    this.renderTrainInclusions = this.renderTrainInclusions.bind(this);
    this.renderSingleTrainInclusion = this.renderSingleTrainInclusion.bind(
      this
    );
    this.renderTransferInclusions = this.renderTransferInclusions.bind(this);
    this.renderFerryInclusions = this.renderFerryInclusions.bind(this);
    this.renderSingleFerryInclusion = this.renderSingleFerryInclusion.bind(
      this
    );
  }

  handleDetailsClick(activityDetails, action, evt) {
    evt.preventDefault();
    evt.stopPropagation();
    evt.nativeEvent.stopImmediatePropagation();

    let { history, location, makeReadOnly = false } = this.props;
    let activityDetailId = activityDetails.planningToolId;

    let slot = _.find(this.props.allSlot, function(slots) {
      return (
        slots.activitySlotDetail &&
        slots.activitySlotDetail.activityId === activityDetailId
      );
    });

    if (typeof slot !== 'undefined') {
      let slotIdentifier = _.findKey(this.props.allSlot, slot);
      // console.log(slotIdentifier);

      slotIdentifier = encodeActivityKeyForURL(slotIdentifier);
      // console.log(slotIdentifier);

      if (action === 'VIEW') {
        history.push(`${location.pathname}/activity-details/${slotIdentifier}`);
      } else if(!makeReadOnly){
        history.push(
          `${location.pathname}/alternate-activities/${slotIdentifier}`
        );
      }

      // slot.slotIdentifier = _.findKey(this.props.allSlot, slot);
      // _.assign(slot.activitySlotDetail, activityDetails);
      //
      // identified slot - get days which has the slot
      // let day_ref = _.findKey(this.props.allDays, function(days) {
      //   return (
      //     days.allSlotKeys &&
      //     _.indexOf(days.allSlotKeys, slot.slotIdentifier) !== -1
      //   );
      // });
      //
      // if (typeof day_ref !== 'undefined') {
      //   let day_obj = this.props.allDays[day_ref];
      //   day_obj.month = day_obj.mon;
      //   day_obj.dayIdentifier = day_ref;
      //   _.assign(slot, _.omit(day_obj, ['mon']));
      //
      //   // identified slot - get days which has the slot
      //   let city_info = _.find(this.props.allCities, function(city) {
      //     return (
      //       city.allDayKeys &&
      //       _.indexOf(city.allDayKeys, slot.dayIdentifier) !== -1
      //     );
      //   });
      //
      //   if (typeof city_info !== 'undefined') {
      //     slot.cityId = city_info.cityId;
      //   }
      // }
    }
  }

  renderSingleActivityInclusion(activity) {
    let { costedItinerary } = this.props;

    let ac = costedItinerary.activityCostings.activityCostingById[activity];
    let a = costedItinerary.activityById[ac.activityId];

    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-8 spacer">
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{ac.mon}</span>
              <span className="date">{ac.day}</span>
            </div>
            <h5 className="no-margin">{a.title}</h5>
            <span className="small bold dim">
              {_.startCase(a.selectedTourGrade.durationType.toLowerCase())} day
              activity in {ac.cityText}
            </span>
          </div>
        </div>
        {this.props.hideDetails ? null : (
          <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
            <a
              href="javascript:void(0)"
              className="btn btn-sm btn-link dim normal"
              onClick={e => this.handleDetailsClick(a, 'VIEW', e)}
            >
              View Details
            </a>
          </div>
        )}
      </div>
    );
  }

  renderTransferInclusions(transfers) {
    return transfers.map(transfer => {
      return this.renderSingleTransferInclusion(transfer.transferKey);
    });
  }

  renderFerryInclusions(ferries) {
    return ferries.map(ferry => {
      return this.renderSingleFerryInclusion(ferry.transferKey);
    });
  }

  renderSingleFerryInclusion(ferry) {
    let { costedItinerary } = this.props;
    let f = costedItinerary.ferryCostings.ferryCostingById[ferry];

    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-8 spacer">
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{f.mon}</span>
              <span className="date">{f.day}</span>
            </div>
            <h5>Ferry - {f.text}</h5>
            <span className="small bold dim">Shared transfer</span>
          </div>
        </div>
        <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
      </div>
    );
  }

  renderSingleTransferInclusion(transferId) {
    let { costedItinerary } = this.props;
    let t = costedItinerary.transferCostings.transferCostingById[transferId];

    let t_type = null;
    if (t.type) {
      t_type = _.startCase(t.type.toLowerCase());
    }
    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-8 spacer">
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{t.mon}</span>
              <span className="date">{t.day}</span>
            </div>
            <h5 className="no-margin">{t.text}</h5>
            <span className="small bold dim">{t_type} transfer</span>
          </div>
        </div>
        <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
      </div>
    );
  }

  renderActivityInclusions(activities) {
    return activities.map(activity => {
      return this.renderSingleActivityInclusion(activity.activityKey);
    });
  }

  renderTrainInclusions(trains) {
    return trains.map(train => {
      return this.renderSingleTrainInclusion(train.transferKey);
    });
  }

  renderSingleTrainInclusion(trainId) {
    let { costedItinerary } = this.props;
    let tr = costedItinerary.trainCostings.trainCostingById[trainId];

    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-8 spacer">
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{tr.mon}</span>
              <span className="date">{tr.day}</span>
            </div>
            <h5 className="no-margin">Train - {tr.text}</h5>
            <span className="small bold dim">Shared transfer</span>
          </div>
        </div>
        <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
      </div>
    );
  }

  renderSinglePass(pass, key, isLast) {
    return (
      <PassContainter
        pass={pass}
        isLast={isLast}
        costedItinerary={this.props.costedItinerary}
        splitPrice={this.props.splitPrice}
        hideDetails={this.props.hideDetails}
        handleDetailsClick={this.handleDetailsClick}
      />
    );
  }

  renderAllPasses(passCostings) {
    let _this = this;
    let passes = [];
    let i = 0;
    let isLast = false;
    let noOfPasses = _.size(passCostings);
    _.forOwn(passCostings, function(pass, key) {
      if (i === noOfPasses - 1) {
        isLast = true;
      }
      passes.push(_this.renderSinglePass(pass, key, isLast));
      i++;
    });

    return passes;
  }

  render() {
    let passCostings = this.props.costedItinerary.passCostings;

    if (_.size(passCostings.passCostingById) > 0) {
      if (this.props.insideModal) {
        return (
          <div className="modal-row pt-0">
            <div className="cost-section-head">
              <h3 className="mute">Passes</h3>
            </div>
            {this.renderAllPasses(passCostings.passCostingById)}
          </div>
        );
      } else {
        return (
          <section className="combo-package-panel" id="all-pass-panels">
            <div className="cost-container">
              <div className="cost-section-head">
                <h3 className="mute">Passes</h3>
              </div>
              {this.renderAllPasses(passCostings.passCostingById)}
            </div>
          </section>
        );
      }
    } else {
      return null;
    }
  }
}

export default withRouter(ComboPanels);
