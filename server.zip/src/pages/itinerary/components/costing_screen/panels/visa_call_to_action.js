import React from 'react';

const CallToAction = props => {
  if (props.isNoVisa)
    return (
      <div
        data-toggle={props.isBooked ? 'tooltip' : ''}
        data-title="Flights already blocked for this trip"
        data-placement="bottom"
        data-container="body"
      >
        <a
          className={
            'btn btn-sm btn-primary ' + (props.isBooked ? 'disabled' : '')
          }
          onClick={() =>
            props.isBooked
              ? null
              : props.handleCallToActionClick('add', props.visaId)
          }
        >
          Add
        </a>
      </div>
    );
  else if (props.isNZ)
    return (
      <div
        data-toggle={props.isBooked ? 'tooltip' : ''}
        data-title="Flights already blocked for this trip"
        data-placement="bottom"
        data-container="body"
      >
        <button
          role="button"
          disabled={props.isBooked}
          className={
            'btn btn-sm btn-primary tracker-visachangebtn ' +
            (props.isBooked ? 'disabled' : '')
          }
          onClick={() => {
            props.handleCallToActionClick('change', props.visaId);
          }}
        >
          Change
        </button>
        <button
          role="button"
          disabled={props.isBooked}
          className={
            'btn btn-sm btn-outline btn-danger ' +
            (props.isBooked ? 'disabled' : '')
          }
          onClick={() => {
            props.handleCallToActionClick('remove', props.visaId);
          }}
        >
          Remove
        </button>
      </div>
    );
  else
    return (
      <div
        data-toggle={props.isBooked ? 'tooltip' : ''}
        data-title="The itinerary has already been booked. Cant make any further changes."
        data-placement="bottom"
        data-container="body"
      >
        <button
          role="button"
          className={
            'btn btn-sm btn-danger btn-outline ' +
            (props.isBooked ? 'disabled' : '')
          }
          onClick={() => {
            props.handleCallToActionClick('remove', props.visaId);
          }}
        >
          Remove
        </button>
      </div>
    );
};

export default CallToAction;
