import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import FerryContainer from '../../../../../common_components/ferry_container';
import NoCostingObjectErrorBlock from './noCostingObjectErrorBlock';
import { encodeCostingKeyForURL } from '../../../../../helpers/utilsHelper';
import { itineraryModalsRouteHelper,routingPageType,FERRY_ALTERNATES } from '../../../../../helpers/routesHelper';
import { manageInterCityTransfer } from '../../../../../actions/actions_app';
import { bindActionCreators } from 'redux';

class FerryPanels extends Component {

  handleInterCityActionClick = (payload, e) => {
    e && e.preventDefault();

    this.props
      .manageInterCityTransfer(payload)
      .then()
      .catch();
  }
  renderRefundability(refundability) {
    if (refundability)
      return (
        <span>
          <span className="color-primary-dark vehoicon-refundable" /> Refundable
        </span>
      );
    else
      return (
        <span>
          <span className="color-accent-7 vehoicon-non-refundable" /> Non
          Refundable
        </span>
      );
  }

  onChangeClick = (ferry, e) => {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();

    let { history, itineraryId, regionCode } = this.props;
    let currentKey = encodeCostingKeyForURL(ferry.key);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode,
        parentPage: routingPageType.inclusion,
        target: FERRY_ALTERNATES,
        customParams: {
          ferryKey: currentKey
        }
      })
    );
  }

  renderFerryPanels = () => {
    let { ferryRefs, ferryCostingObj, isBooked, makeReadOnly, user_details } = this.props;

    if (ferryRefs !== undefined && ferryCostingObj !== undefined) {
      return ferryRefs.map(ferryId => {
        let ferry = ferryCostingObj.ferryCostingById && ferryCostingObj.ferryCostingById[ferryId];

        // Handler for missed costing
        if (!ferry) {
          return <NoCostingObjectErrorBlock
            failedFor="ferry"
            isLastRow={false}
          />
        }

          return <FerryContainer userDetails={user_details} handleInterCityActionClick={this.handleInterCityActionClick} key={ferryId} ferry={ferry} isBooked={isBooked} onChangeClick={this.onChangeClick} makeReadOnly={makeReadOnly}/>;
      });
    } else {
      return null;
    }
  }

  render() {
    return (
      <section className="ferry-transfers">{this.renderFerryPanels()}</section>
    );
  }
}
const mapStateToProps = () => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    manageInterCityTransfer: bindActionCreators(manageInterCityTransfer, dispatch)
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(FerryPanels)
);