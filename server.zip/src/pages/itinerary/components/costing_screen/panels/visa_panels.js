import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  addVisa,
  changeVisa,
  removeVisa
} from '../../../../../actions/actions_app';
import { encodeCostingKeyForURL } from '../../../../../helpers/utilsHelper';
import NonShenganVisaPanels from './non_shengan_visa_panels';
import VisaContainer from '../../../../../common_components/visa_container';
import NoCostingObjectErrorBlock from './noCostingObjectErrorBlock';
import {
  trackEvent,
  EVENT_INCLUSIONS_MODIFIED,
  EVENT_ADD,
  EVENT_REMOVE,
  EVENT_CHANGE
} from '../../../../../helpers/ML/EventsTracker';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  CHANGE_VISA
} from '../../../../../helpers/routesHelper';
class VisaPanels extends Component {
  constructor(props) {
    super(props);

    this.handleCallToActionClick = this.handleCallToActionClick.bind(this);
  }

  handleCallToActionClick(type, visaId) {
    const types = {
      add: EVENT_ADD,
      remove: EVENT_REMOVE,
      change: EVENT_CHANGE
    };

    if (typeof type === 'string' && types[type.toLowerCase()]) {
      trackEvent(EVENT_INCLUSIONS_MODIFIED, {
        visa_interaction: types[type.toLowerCase()]
      });
    }

    switch (type.toLowerCase()) {
      case 'add':
        this.props
          .addVisa({
            itineraryId: this.props.itineraryId,
            visaKey: visaId,
            include: true
          })
          .then()
          .catch();
        break;
      case 'remove':
        this.props
          .removeVisa({
            itineraryId: this.props.itineraryId,
            visaKey: visaId,
            include: false
          })
          .then()
          .catch();
        break;
      case 'change':
        let { history, itinerary } = this.props;

        let visaKey = encodeCostingKeyForURL(visaId);
        history.push(
          itineraryModalsRouteHelper({
            itineraryId: itinerary.itinerary.itineraryId,
            regionCode: itinerary.itinerary.regionCode,
            parentPage: routingPageType.inclusion,
            target: CHANGE_VISA,
            customParams: { visaKey }
          })
        );
        break;
      default:
        return;
    }
  }

  render() {
    let renderComponent = null;
    let {
      isBooked,
      userDetails,
      visaRefs,
      visaCostings,
      splitPricing,
      allowEditingOptions,
      makeReadOnly
    } = this.props;

    const isNonEditable = isBooked && userDetails.userType !== 'ADMIN';

    if (visaRefs !== undefined && visaCostings !== undefined) {
      const visaIds =
        visaRefs.length > 0
          ? visaRefs
          : Object.keys(visaCostings.visaCostingById);
      renderComponent = visaIds.map((visaId, visaIndex) => {
        const visaDetails =
          visaCostings.visaCostingById && visaCostings.visaCostingById[visaId];

        // Handler for missed costing
        if (!visaDetails) {
          return (
            <NoCostingObjectErrorBlock failedFor="visa" isLastRow={false} />
          );
        }

        const totalVisaCost = visaCostings.totalVisaCost;
        return (
          <VisaContainer
            key={visaIndex}
            isNonEditable={isNonEditable}
            visaId={visaId}
            totalVisaCost={totalVisaCost}
            handleCallToActionClick={this.handleCallToActionClick}
            splitPricing={splitPricing}
            allowEditingOptions={allowEditingOptions}
            visaDetails={visaDetails}
            makeReadOnly={makeReadOnly}
          />
        );
      });
    } else
      renderComponent = (
        <div key={'non-shengan-panel'}>
          <NonShenganVisaPanels
            allowEditingOptions={allowEditingOptions}
            visaId={null}
            isOnArrival={true}
            splitPricing={splitPricing}
            isBooked={isNonEditable}
            totalVisaCost={visaCostings && visaCostings.totalVisaCost}
            handleCallToActionClick={this.handleCallToActionClick}
          />
         {makeReadOnly ? null : <hr className="tear" />}
        </div>
      );

    if (this.props.insideModal) {
      return (
        <div className="modal-row pt-0 cost-container">{renderComponent}</div>
      );
    } else {
      return <section className="visa">{renderComponent}</section>;
    }
  }
}

const mapStateToProps = () => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    addVisa: bindActionCreators(addVisa, dispatch),
    removeVisa: bindActionCreators(removeVisa, dispatch),
    changeVisa: bindActionCreators(changeVisa, dispatch)
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(VisaPanels)
);
