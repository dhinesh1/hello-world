import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import _ from 'lodash';
import classNames from 'classnames';
import { TripAdvisorRating } from '../../../../../common_components/Components';
import StarRating from '../../../../../common_components/StarRating';
import HotelRoomRow from '../../../../../common_components/itinerary/hotel_room_row';
import { encodeCostingKeyForURL } from '../../../../../helpers/utilsHelper';
import NoCostingObjectErrorBlock from './noCostingObjectErrorBlock';
import {
  itineraryModalsRouteHelper,
  HOTEL_DETAILS,
  HOTEL_ALTERNATES
} from '../../../../../helpers/routesHelper';

class HotelPanels extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showAlert: false,
      alertFound: false,
      alertRead: false,
      alertExpand: false,
      showInfo: false,
      alertText:
        'Non refundable hotels will cause issue to modify your trip later. You can change to refundable options with less additional increase in prices'
    };
    this.onViewDetailsClick = this.onViewDetailsClick.bind(this);
    this.onChangeClick = this.onChangeClick.bind(this);
    this.hideErrorInfo = this.hideErrorInfo.bind(this);
  }

  hideErrorInfo() {
    // document.querySelector('.danger').classList.remove('show-info');
    this.setState({ showInfo: true });
  }
  componentWillReceiveProps(nextProps) {
    let alertFound = false;

    if (nextProps && nextProps.costedItinerary) {
      // check if there are any alert to show
      let allAlerts = nextProps.costedItinerary.allAlerts;
      if (allAlerts && allAlerts.alerts && allAlerts.alerts.length > 0) {
        alertFound = _.find(
          allAlerts.alerts,
          o => o.type === 'NON_REFUNDABLE_HOTELS'
        );
      }
    }

    this.setState({ alertFound: alertFound, showInfo: false });
  }

  onViewDetailsClick(hotelDetails) {
    let { history, location, itineraryDetail } = this.props;
    let hotelKey = encodeCostingKeyForURL(hotelDetails.costingKey);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId: itineraryDetail.itineraryId,
        regionCode: itineraryDetail.regionCode,
        location,
        target: HOTEL_DETAILS,
        customParams: { hotelKey }
      })
    );
  }

  onChangeClick(currentHotel, e) {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();

    let { history, location, itineraryId, itineraryDetail } = this.props;
    let hotelKey = encodeCostingKeyForURL(currentHotel.costingKey);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode: itineraryDetail.regionCode,
        location,
        target: HOTEL_ALTERNATES,
        customParams: { hotelKey }
      })
    );
  }

  renderRoomsHelper(hotel) {
    if (hotel && hotel.roomsInHotel) {
      let rooms = hotel.roomsInHotel;
      return rooms.map((room, key) => {
        let room_no = key + 1;
        return (
          <HotelRoomRow
            hidePrice={true}
            itineraryDetail={this.props.itineraryDetail}
            userDetails={this.props.userDetails}
            packageRate={this.props.packageRate}
            itineraryId={this.props.itineraryId}
            isCurrentPick={false}
            onHotelDetails={false}
            onCostingPage={true}
            allowChangeRoom={true}
            room={room}
            room_no={room_no}
            key={'rooms_in_card_' + room_no}
            hotel={hotel}
            hotelGuestRoomConfigurations={
              this.props.hotelGuestRoomConfigurations
            }
            makeReadOnly={this.props.makeReadOnly}
          />
        );
      });
    }
  }

  renderHotelPanels() {

    let { hotelRefs, hotelCostingObj, isBooked, userDetails, makeReadOnly } = this.props;
    const isAdmin = userDetails &&
    userDetails.loggedIn &&
    userDetails.userType === 'ADMIN';
  
    if (hotelRefs !== undefined && hotelCostingObj !== undefined) {
      let hotelCostingById = hotelCostingObj.hotelCostingById;

      return hotelRefs.map((hotelId, hRow) => {
        let isLastRow = hotelRefs.length === hRow + 1;
        let hotelDetails = hotelCostingById && hotelCostingById[hotelId];
        if (!hotelDetails) {
          return (
            <NoCostingObjectErrorBlock
              failedFor="hotel"
              isLastRow={isLastRow}
            />
          );
        }

        const AOTpills = hotelDetails.ourSourceProviders ? hotelDetails.ourSourceProviders.map((item) => {
          return (<figcaption
            className='stars inverse text-right bold'><span className="pill color-white bg-accent-4">{item}</span>
          </figcaption>)
        }) : [];
        
        let hotelStatus = (hotelDetails && hotelDetails.status) || '';
        if (hotelStatus === 'SUCCESS') {
          let is_islandHopper = hotelDetails.sourceProvider === 'ISLANDHOPPER';

          const discountAppliedBatch = userDetails && userDetails.userType === 'ADMIN' && hotelDetails.discountApplied ?
            <span className={'pill color-white bg-accent-4'}> Discount Applied </span> : null;

          let discountBadge =
            hotelDetails.discountPercentage !== '0' &&
            hotelDetails.discountPercentage !== 0 &&
            hotelDetails.discountPercentage !== '-Infinity' ? (
              <div className="ribbon-container">
                <div className="ribbon-right">
                  {hotelDetails.discountPercentage}% OFF{' '}
                  <span className="hidden-xs">TODAY</span>
                </div>
              </div>
            ) : null;

          let IslandHopperDiscountBadge = null;
          if (
            is_islandHopper &&
            hotelDetails.roomOffer &&
            hotelDetails.roomOffer.discount
          ) {
            IslandHopperDiscountBadge = (
              <div className="ribbon-container">
                <div className="ribbon-right">
                  {hotelDetails.roomOffer.discount.discount}% OFF{' '}
                  <span className="hidden-xs">TODAY</span>
                </div>
              </div>
            );
          }

          let discountType = null;
          if (hotelDetails.memberOnlyDeal && hotelDetails.sale) {
            discountType = (
              <span className="promo-price fade block v-spaced">
                Promo Price!
              </span>
            );
          } else {
            if (hotelDetails.memberOnlyDeal) {
              discountType = (
                <span className="promo-price fade block v-spaced">
                  Member Discount!
                </span>
              );
            } else if (hotelDetails.sale) {
              discountType = (
                <span className=" promo-price fade block v-spaced">
                  Promo Price!
                </span>
              );
            }
          }
          return (
            <div key={hotelDetails.costingKey}>
              {hotelDetails.hotelNotRetained ? (
                <div
                  className={classNames('card-info danger', {
                    'show-info': this.state.showInfo
                      ? !this.state.showInfo
                      : hotelDetails.hotelNotRetained
                  })}
                >
                  <p className="clearfix">
                    <span className="pull-left truncate-mobile">
                      <i className="vehoicon-exclamation-circle" />
                      Oops, sorry the hotel you have selected is not available
                      for the selected dates so we have chosen another hotel.
                    </span>
                    <button
                      type="button"
                      className="btn btn-link pull-right"
                      onClick={e => this.hideErrorInfo(e)}
                    >
                      X
                    </button>
                  </p>
                </div>
              ) : null}
              <article
                className="row-costed-item row zoomable"
                onClick={e => {
                  e.preventDefault();
                  this.onViewDetailsClick(hotelDetails);
                }}
              >
                {/*diffObj && diffObj.elementChangeType !== "NONE" ?
                  <div className="alert-bar no-margin text-center mini">
                    Hey! looks like this <span className="small bold">{diffObj.oldHotelName}</span> is not available any more
                  </div>
                  : null*/}

                <div className="col-xs-9 col-sm-9 col-md-8 spacer">
                  <div className="costed-item-head">
                    <div className="date-costed">
                      <span className="month">
                        {hotelDetails.checkInMonthDisplay}
                      </span>
                      <span className="date">
                        {hotelDetails.checkInDateDisplay}
                      </span>
                    </div>
                    <h5 className="no-margin semi-bold">
                      {hotelDetails.numberOfNights} nights stay in{' '}
                      {hotelDetails.cityName}
                    </h5>
                    <span className="small dim">At {hotelDetails.name}</span>
                  </div>
                  <div className="costed-item-details clearfix no-padding">
                    <ul className="generic-options-list clearfix list-unstyled">
                      {this.renderRoomsHelper(hotelDetails)}
                    </ul>
                  </div>
                </div>
                <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
                  <li className="no-padding">
                    {isAdmin && AOTpills.length ? AOTpills : null}
                    <StarRating
                      rating={hotelDetails.stars}
                      fillEmpty={false}
                      parentClass="star-rating dim inline-block"
                      addStarClr={true}
                    />{' '}
                    Star
                  </li>
                  {is_islandHopper ? null : (
                    <li className="no-padding">
                      <TripAdvisorRating
                        rating={hotelDetails.tripAdvisorRating}
                        fillEmptyCircle={true}
                        logoAsImage={true}
                      />
                    </li>
                  )}
                  <li>
                    <span className="vehoicon-calendar-checkin" />Check-in:{' '}
                    {hotelDetails.checkInDateDisplay}{' '}
                    {hotelDetails.checkInMonthDisplay}
                  </li>
                  <li>
                    <span className="vehoicon-calendar-checkout" />Check-out:{' '}
                    {hotelDetails.checkOutDateDisplay}{' '}
                    {hotelDetails.checkOutMonthDisplay}
                  </li>
                </ul>
                <div className="col-xs-3 col-sm-3 col-md-2 spacer">
                  <div className="action price-info text-center">
                    {!hotelDetails.finalPrice ? null : (
                      <span className="price block">
                        {discountBadge}
                        <span className="WebRupee">Rs.</span>
                        {hotelDetails.finalPrice}
                        {discountType}
                      </span>
                    )}
                    {discountAppliedBatch}
                    {is_islandHopper && IslandHopperDiscountBadge
                      ? IslandHopperDiscountBadge
                      : null}
                    <div
                      data-toggle={isBooked ? 'tooltip' : ''}
                      data-title="The itinerary has already been booked. Cant make any further changes."
                      data-placement="bottom"
                      data-container="body"
                    >
                      <a
                        onClick={e =>
                          isBooked ? null : this.onChangeClick(hotelDetails, e)
                        }
                        className={
                          `btn btn-sm btn-primary tracker-hotelchangebtn 
                          ${isBooked ? 'disabled' : ''}  ${makeReadOnly ? 'hide' : ''}`
                        }
                      >
                        Change
                      </a>
                    </div>
                    <span className="block">
                      <a
                        onClick={e => {
                          e.preventDefault();
                          e.stopPropagation();
                          e.nativeEvent.stopImmediatePropagation();

                          this.onViewDetailsClick(hotelDetails);
                        }}
                        className="btn btn-sm btn-link dim normal"
                      >
                        More info
                      </a>
                    </span>
                  </div>
                </div>
              </article>
              {!isLastRow ? <hr className="tear" /> : null}
            </div>
          );
        } else {
          return (
            <div key={Math.random()}>
              <article
                className={
                  'row-costed-item row ' +
                  (hotelStatus === 'USER_REMOVED' ? 'warning' : 'danger')
                }
              >
                <div className="col-xs-9 col-sm-9 col-md-8 spacer">
                  <div className="costed-item-head">
                    <div className="date-costed">
                      <span className="month">
                        {hotelDetails.checkInMonthDisplay}
                      </span>
                      <span className="date">
                        {hotelDetails.checkInDateDisplay}
                      </span>
                    </div>
                    <h5 className="no-margin">
                      {hotelDetails.numberOfNights}{' '}
                      {hotelDetails.numberOfNights > 1 ? 'nights' : 'night'}{' '}
                      stay in {hotelDetails.cityName}
                    </h5>
                    <span
                      className={
                        'mini color-' +
                        (hotelStatus === 'USER_REMOVED' ? 'warning' : 'danger')
                      }
                    >
                      {hotelStatus === 'USER_REMOVED'
                        ? 'You have removed this hotel from itinerary!'
                        : 'Unable to find this hotels. Try after some time!'}
                    </span>
                  </div>
                </div>
                <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
                <div className="col-xs-3 col-sm-3 col-md-2 spacer">
                  <div className="action price-info text-center">
                    <div
                      data-toggle={isBooked ? 'tooltip' : ''}
                      data-title="The itinerary has already been booked. Cant make any further changes."
                      data-placement="bottom"
                      data-container="body"
                    >
                      <a
                        onClick={e =>
                          isBooked ? null : this.onChangeClick(hotelDetails, e)
                        }
                        className={
                          'btn btn-sm btn-primary ' +
                          (isBooked ? 'disabled' : '')
                        }
                      >
                        Add
                      </a>
                    </div>
                  </div>
                </div>
              </article>
              {!isLastRow ? <hr className="tear" /> : null}
            </div>
          );
        }
      });
    } else {
      return null;
    }
  }

  render() {
    const { costedItinerary, makeReadOnly} = this.props;
    if (this.props.packageRate) {
      return <section className="hotels">{this.renderHotelPanels()}</section>;
    } else {
      let {
        alertFound,
        alertRead,
        showAlert,
        alertExpand,
        alertText
      } = this.state;

      return (
        <section className="hotels">
          <div className="cost-container">
            {alertFound ? (
              <div
                className={
                  'card-info ' + (showAlert && !alertRead ? 'show-info' : '')
                }
              >
                <p className="clearfix">
                  <span
                    onClick={e => this.setState({ alertExpand: !alertExpand })}
                    className={
                      'pull-left ' + (alertExpand ? '' : 'truncate-mobile')
                    }
                  >
                    <i className="vehoicon-exclamation-circle" /> {alertText}
                  </span>
                  <button
                    type="button"
                    onClick={e => this.setState({ alertRead: true })}
                    className="btn btn-link pull-right"
                  >
                    OK
                  </button>
                </p>
              </div>
            ) : null}

            <div className="cost-section-head">
              <h3 className="mute">
                {costedItinerary.itinerary &&
                costedItinerary.itinerary.regionCode === 'mle'
                  ? 'Hotels & Transfers'
                  : 'Hotels'}
              </h3>
            </div>
            {this.renderHotelPanels()}
          </div>
        </section>
      );
    }
  }
}

export default withRouter(HotelPanels);
