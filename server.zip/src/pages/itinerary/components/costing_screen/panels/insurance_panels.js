import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  addInsurance,
  changeInsurance,
  removeInsurance
} from '../../../../../actions/actions_app';
import {
  trackEvent,
  EVENT_INCLUSIONS_MODIFIED,
  EVENT_ADD,
  EVENT_REMOVE,
  EVENT_CHANGE
} from '../../../../../helpers/ML/EventsTracker';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  CHANGE_INSURANCE
} from '../../../../../helpers/routesHelper';

class InsurancePanels extends Component {
  constructor(props) {
    super(props);

    this.handleCallToActionClick = this.handleCallToActionClick.bind(this);
  }

  handleCallToActionClick(type, data) {
    const payload = {
      ...data,
      itineraryId: this.props.itineraryId
    };

    const types = {
      add: EVENT_ADD,
      remove: EVENT_REMOVE,
      change: EVENT_CHANGE
    };

    if (typeof type === 'string' && types[type.toLowerCase()]) {
      trackEvent(EVENT_INCLUSIONS_MODIFIED, {
        insurance_interaction: types[type.toLowerCase()]
      });
    }

    switch (type.toLowerCase()) {
      case 'add':
        this.props
          .addInsurance(payload)
          .then()
          .catch();
        break;
      case 'remove':
        this.props
          .removeInsurance(payload)
          .then()
          .catch();
        break;
      case 'change':
        const { history, itineraryId, regionCode } = this.props;
        history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            parentPage: routingPageType.inclusion,
            target: CHANGE_INSURANCE
          })
        );
        break;
      default:
        break;
    }
  }

  render() {
    let costingId = this.props.insuranceCosting
      ? this.props.insuranceCosting.insuranceCostingById
      : null;
    if(this.props.makeReadOnly){
      return null;
    }
    return (
      <InsurancePanel
        allowEditingOptions={this.props.allowEditingOptions}
        insurance={costingId}
        totalInsuranceCost={
          this.props.insuranceCosting &&
          this.props.insuranceCosting.totalInsuranceCost
        }
        handleCallToActionClick={this.handleCallToActionClick}
        isBooked={this.props.isBooked}
        userDetails={this.props.userDetails}
        adult_count={this.props.adult_count}
        child_count={this.props.child_count}
        splitPricing={this.props.splitPricing}
      />
    );
  }
}

const InsurancePanel = props => {
  return (
    <article className="row-costed-item row">
      <div className="col-xs-9 col-sm-9 col-md-10 spacer">
        <h5 className="no-margin semi-bold">
          Travel insurance for {(props.insurance.countries || []).join(', ')}
        </h5>
        <p className="costed-item-details meta-text">
          {!props.insurance.required ? (
            <span className="pill color-white bg-accent-4">Important</span>
          ) : null}
          {!props.insurance.required ? (
            <span className="meta-text dim">
              &nbsp;Add Insurance to save on un-planned emergencies like lost
              passport, medical emergency, lost baggage etc. On an average it
              costs less than 20 Euros per person. Make a smart choice now.
            </span>
          ) : (
            <span className="meta-text dim">
              Smart move! We love transparency and want you to know that this is
              an average cost. Depending on the actual age of the travellers,
              this cost will vary. We will update you when it changes. Be rest
              assured.{' '}
            </span>
          )}
        </p>
        {props.insurance.required ? (
          <div className="row">
            <div className="col-xs-12">
              <span className="meta-text dim bold">Specifics:</span>
              <p className="meta-text dim">
                {props.insurance.plan} for{' '}
                {props.adult_count + props.child_count} person(s).
              </p>
            </div>
          </div>
        ) : null}
      </div>
      <div className="col-xs-3 col-sm-3 col-md-2 spacer">
        <div className="action price-info text-center">
          {props.totalInsuranceCost ? (
            <span className="price block">
              <span className="WebRupee">Rs.</span>
              {props.totalInsuranceCost}
            </span>
          ) : null}
          {props.allowEditingOptions ? (
            <CallToAction
              {...props.insurance}
              isBooked={props.isBooked}
              userDetails={props.userDetails}
              isNoInsurance={!props.insurance.required}
              handleCallToActionClick={props.handleCallToActionClick}
            />
          ) : null}
        </div>
      </div>
    </article>
  );
};

const CallToAction = props => {
  const isNonEditable =
    props.isBooked && props.userDetails.userType !== 'ADMIN';

  if (props.isNoInsurance) {
    return (
      <div
        data-toggle={isNonEditable ? 'tooltip' : ''}
        data-title="The itinerary has already been booked. Cant make any further changes."
        data-placement="bottom"
        data-container="body"
      >
        <button
          className={
            'btn btn-sm btn-primary add-insurance-ga ' +
            (isNonEditable ? 'disabled' : '')
          }
          onClick={() =>
            isNonEditable
              ? null
              : props.handleCallToActionClick('add', {
                  regionCode: props.insuranceRegion,
                  insuranceKey: props.insuranceKey,
                  include: true,
                  planId: props.planId
                })
          }
        >
          Add
        </button>
      </div>
    );
  } else {
    return (
      <div
        data-toggle={isNonEditable ? 'tooltip' : ''}
        data-title="Flights already blocked for this trip"
        data-placement="bottom"
        data-container="body"
      >
        <button
          disabled={isNonEditable}
          className={
            'btn btn-sm btn-primary change-insurance-ga tracker-inschangebtn ' +
            (isNonEditable ? 'disabled' : '')
          }
          onClick={() =>
            props.handleCallToActionClick('change', {
              regionCode: props.insuranceRegion,
              insuranceKey: props.insuranceKey,
              include: true,
              chosenPlanId: props.planId
            })
          }
        >
          Change
        </button>
        <button
          disabled={isNonEditable}
          className={
            'btn btn-sm btn-outline btn-danger fade' +
            (isNonEditable ? 'disabled' : '')
          }
          onClick={() =>
            props.handleCallToActionClick('remove', {
              regionCode: props.insuranceRegion,
              insuranceKey: props.insuranceKey,
              include: false
            })
          }
        >
          Remove
        </button>
      </div>
    );
  }
};

const mapStateToProps = () => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    addInsurance: bindActionCreators(addInsurance, dispatch),
    removeInsurance: bindActionCreators(removeInsurance, dispatch),
    changeInsurance: bindActionCreators(changeInsurance, dispatch)
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(InsurancePanels)
);
