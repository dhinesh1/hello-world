import React, { Component } from 'react'
import PropTypes from 'prop-types';

export default class NoCostingObjectErrorBlock extends Component {
  render() {
    let {failedFor, isLastRow = true } = this.props;

    return <React.Fragment>
        <article className={'row-costed-item row danger'}>
            <div className="col-xs-12 col-md-12 spacer">
                <div className="costed-item-head" style={{paddingLeft: 0}}>
                    <h5 className="no-margin">
                        Oh no <span role="img" area-label="confused">😕</span> Looks like there's an issue
                    </h5>
                    <span className={'meta-text color-accent-3'}>
                        We aren't able to fetch your {failedFor} details at the moment. Please refresh after a while.
                    </span>
                </div>
            </div>
        </article>
        {!isLastRow ? <hr className="tear" /> : null}
    </React.Fragment>
  }
}

/**
 * Default proptype
 */
NoCostingObjectErrorBlock.propTypes = {
    isLastRow: PropTypes.bool,
    failedFor: PropTypes.string
};
  