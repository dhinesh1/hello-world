import React, { Component } from 'react';

import FlightPanels from './flight_panels';
import HotelPanels from './hotel_panels';

export default class FlightHotelPanels extends Component {
  render() {
    return (
      <div className="cost-container">
        <div className="row v-spaced">
          <div className="col-md-8 col-xs-8 v-spaced">
            <div className="cost-section-head">
              <h3 className="mute no-margin">Flights + Hotel</h3>
            </div>
            <span className="small bold mute hidden-xs">
              Greater savings when you book these hotels and flights together
            </span>
          </div>
          <div className="col-md-4 col-xs-4 text-right v-spaced">
            <div className="action price-info text-center">
              <span className="price block">
                <span className="WebRupee">Rs.</span>
                {this.props.totalPackageCost}
              </span>
              {this.props.costedItinerary.totalDiff.totalFlightHotelCostChange >
                0 &&
              this.props.costedItinerary.totalDiff.flightHotelCostChangeType ===
                'PRICEDECREASE' ? (
                <span className="small bold mute block">
                  You{' '}
                  {this.props.costedItinerary.totalDiff
                    .flightHotelCostChangeType === 'PRICEINCREASE'
                    ? 'lose'
                    : 'save'}
                  <span className="WebRupee">Rs.</span>{' '}
                  {
                    this.props.costedItinerary.totalDiff
                      .totalFlightHotelCostChange
                  }
                </span>
              ) : null}
            </div>
          </div>
        </div>
        <hr className="tear" />
        <FlightPanels
          packageRate={true}
          flightRefs={this.props.costedItinerary.allFlightCostingRefs}
          isBooked={this.props.costedItinerary.itinerary.booking}
          flightCostingObj={this.props.costedItinerary.flightCostings}
        />
        <HotelPanels
          packageRate={true}
          userDetails={this.props.userDetails}
          isBooked={this.props.costedItinerary.itinerary.booking}
          hotelRefs={this.props.costedItinerary.allHotelCostingRefs}
          hotelCostingObj={this.props.costedItinerary.hotelCostings}
          hotelGuestConfiguration={
            this.props.costedItinerary.costingConfiguration
              .hotelGuestRoomConfigurations
          }
          itineraryId={this.props.costedItinerary.itinerary.itineraryId}
        />
      </div>
    );
  }
}
