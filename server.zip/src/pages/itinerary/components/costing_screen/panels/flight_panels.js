import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import _ from 'lodash';
import moment from 'moment';
import SingleFlightTrip from '../flight/single_trip_row.js';
import { encodeCostingKeyForURL } from '../../../../../helpers/utilsHelper';
import DepartureBoard from '../../../../../helpers/departureBoard';
import NoCostingObjectErrorBlock from './noCostingObjectErrorBlock';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  FLIGHT_DETAILS,
  FLIGHT_ALTERNATES,
  RATE_MATCH_FLIGHT
} from '../../../../../helpers/routesHelper';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { manageInterCityTransfer } from '../../../../../actions/actions_app.js';
/*global  swal */

class FlightPanels extends Component {
  constructor(props) {
    super(props);

    this.state = {
      alertFound: false,
      alertRead: false,
      alertExpand: false,
      alertText:
        `Heads-up! The flight you've selected arrives at odd hours. Please choose an alternative flight for a hassle-free travel`
    };

    this.onViewDetailsClick = this.onViewDetailsClick.bind(this);
    this.blockedFlightTimers = this.blockedFlightTimers.bind(this);
    this.handleCallToActionClick = this.handleCallToActionClick.bind(this);
  }

  handleCallToActionClick(payload, e) {
    e && e.preventDefault();
    this.props
      .manageInterCityTransfer(payload)
      .then()
      .catch();
  }

  onViewDetailsClick(flight) {
    let { history, costedItinerary } = this.props;
    const flightKey = encodeCostingKeyForURL(flight.key);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId: costedItinerary.itinerary.itineraryId,
        parentPage: routingPageType.inclusion,
        regionCode: costedItinerary.itinerary.regionCode,
        target: FLIGHT_DETAILS,
        customParams: { flightKey }
      })
    );
  }

  onChangeClick(flight, scenerio, e) {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();

    let { history, costedItinerary } = this.props;
    const flightKey = encodeCostingKeyForURL(flight.key);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId: costedItinerary.itinerary.itineraryId,
        parentPage: routingPageType.inclusion,
        regionCode: costedItinerary.itinerary.regionCode,
        target: FLIGHT_ALTERNATES,
        customParams: { flightKey }
      })
    );
  }

  blockedFlightTimers() {
    let _this = this;

    if (this.props.flightRefs !== undefined) {
      let { flightRefs, flightCostingObj } = this.props;
      return flightRefs.map((flightId, inx) => {
        let flight =
          flightCostingObj.flightCostingById &&
          flightCostingObj.flightCostingById[flightId];

        if (!flight) {
          return null;
        }
        let flightStatus = flight ? flight.status : '';

        if (flightStatus === 'BLOCKED') {
          let expiresIn = flight.expiresIn;
          // console.log(expiresIn);

          document.getElementById('flight-timer-' + inx).innerHTML = '';

          let board = new DepartureBoard(
            document.getElementById('flight-timer-' + inx),
            { rowCount: 1, letterCount: 5 }
          );
          // let countDownDate = new Date(expiresIn).getTime();
          let countDownDate = moment(expiresIn, 'YYYY-MM-DD HH:mm:ss.sss')
            .toDate()
            .getTime();

          // Update the count down every 1 second
          function countDownTimer() {
            // Get todays date and time
            // let now = new Date().getTime();
            let now = moment()
              .toDate()
              .getTime();

            // Find the distance between now an the count down date
            let distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            // let days = Math.floor(distance / (1000 * 60 * 60 * 24));
            // 		days = days < 10 ? '0'+days : days;
            // let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));			// only hours
            let hours = Math.floor(distance / (1000 * 60 * 60));
            hours = hours < 10 ? '0' + hours : hours;
            let minutes = Math.floor(
              (distance % (1000 * 60 * 60)) / (1000 * 60)
            );
            minutes = minutes < 10 ? '0' + minutes : minutes;
            let seconds = Math.floor((distance % (1000 * 60)) / 1000);
            seconds = seconds < 10 ? '0' + seconds : seconds;

            // let res = ""+(days > 0 ? days+":" : "")+hours+":"+minutes+":"+seconds;
            let res = hours + ':' + minutes + ':' + seconds;
            board.setValue(res);

            // If the count down is finished, write some text
            if (distance < 0) {
              clearInterval(_this.timer);
              swal(
                {
                  title: 'Oops!',
                  text:
                    'Looks like the validity of the flight that was blocked has expired. Reach out to us to block it again.',
                  animation: true,
                  showCancelButton: false,
                  confirmButtonColor: '#DD6B55',
                  confirmButtonText: 'Ok, Got it!',
                  cancelButtonText: 'No',
                  closeOnConfirm: true,
                  closeOnCancel: true
                },
                function() {
                  _this.stopTimer = true;
                  window.location.reload();
                }
              );
            }
          }
          countDownTimer();

          _this.timer = setInterval(function() {
            countDownTimer();
          }, 1000);
        }
      });
    }
  }

  componentWillReceiveProps(nextProps) {
    let alertFound = false;

    if (nextProps && nextProps.costedItinerary) {
      // check if there are any alert to show
      let allAlerts = nextProps.costedItinerary.allAlerts;
      if (allAlerts && allAlerts.alerts && allAlerts.alerts.length > 0) {
        alertFound = _.find(allAlerts.alerts, o => o.type === 'EARLY_FLIGHT');
      }
    }

    this.setState({ alertFound: alertFound });
  }

  componentDidMount() {
    this.stopTimer = false;
    this.blockedFlightTimers();
  }

  componentDidUpdate() {
    clearInterval(this.timer);

    if (!this.stopTimer) {
      this.blockedFlightTimers();
    }
  }

  renderRefundabilityUI(refundability) {
    if (refundability) {
      return (
        <li>
          <span className="vehoicon-refundable color-primary-dark" />Refundable
        </li>
      );
    } else {
      return (
        <li>
          <span className="vehoicon-non-refundable color-accent-7" />Non
          Refundable
        </li>
      );
    }
  }

  renderFlightPanels() {
    let {
      isBooked,
      userDetails,
      flightRefs,
      flightCostingObj,
      costedItinerary,
      makeReadOnly
    } = this.props;
    const { onViewDetailsClick } = this;
    const isAdmin = userDetails &&
      userDetails.loggedIn &&
      userDetails.userType === 'ADMIN';
    const isNonEditable = isBooked && userDetails && userDetails.userType !== 'ADMIN';
    if (flightRefs !== undefined && flightCostingObj !== undefined) {
      return flightRefs.map((flightId, inx) => {
        let flight =
          flightCostingObj.flightCostingById &&
          flightCostingObj.flightCostingById[flightId];
        // Checking is last row by is last index
        let isLastRow = flightRefs.length == inx + 1;

        // Handler for missed costing
        if (!flight) {
          return (
            <NoCostingObjectErrorBlock
              failedFor="flight"
              isLastRow={isLastRow}
            />
          );
        }

        let flightStatus = (flight && flight.status) || '';
        if (flightStatus === 'SUCCESS' || flightStatus === 'BLOCKED') {
          let trips = flight.trips;

          // This the calculation for finding the total excessBaggage added in the flight - we are not using it right now - but it may required in future
          // let weight = 0;
          // if (
          //   flight.excessBaggageInfo &&
          //   flight.excessBaggageInfo.excessBaggages
          // ) {
          //   let excessBaggage = flight.excessBaggageInfo.excessBaggages;
          //   excessBaggage.map(i => {
          //     i.baggageOptions.map(j => {
          //       if (j.selected === true && j.selectedQuantity > 0) {
          //         weight += j.weight * j.selectedQuantity;
          //       }
          //     });
          //   });
          // }

          const discountAppliedBatch = userDetails && userDetails.userType === 'ADMIN' && flight.rateMatches && flight.rateMatches.length > 0 ?
            <span className={'pill color-white bg-accent-4'}> Discount Applied </span> : null;


          return (
            <div key={flightId}>
              <article
                className="row-costed-item row zoomable"
                onClick={e => {
                  e.preventDefault();
                  onViewDetailsClick(flight);
                }}
              >
                <SingleFlightTrip
                  airlineCode={flight.airlineCode}
                  trips={trips}
                  tripRefs={flight.allTrips}
                />
                <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
                  <li>
                    <span className="vehoicon-seat" />
                    {_.capitalize(flight.flightClass)}
                  </li>
                  {this.renderRefundabilityUI(flight.refundable)}
                  {/* {baggage_line} */}
                </ul>
                <div className="col-xs-3 col-sm-3 col-md-2 spacer">
                  <div className="action price-info text-center">
                    {!flight.price ? (
                      ''
                    ) : (
                      <p className="price block clear-margin">
                        <span className="WebRupee">Rs.</span>
                        {flight.price}
                        {userDetails &&
                        userDetails.loggedIn &&
                        userDetails.userType === 'ADMIN' &&
                        flightStatus !== 'BLOCKED' &&
                        !makeReadOnly ? (
                          <a
                            onClick={e => {
                              e.stopPropagation();
                              e.nativeEvent.stopImmediatePropagation();

                              let flightKey = encodeCostingKeyForURL(
                                flight.key
                              );
                              this.props.history.push(
                                itineraryModalsRouteHelper({
                                  itineraryId:
                                    costedItinerary.itinerary.itineraryId,
                                  parentPage: routingPageType.inclusion,
                                  regionCode:
                                    costedItinerary.itinerary.regionCode,
                                  target: RATE_MATCH_FLIGHT,
                                  customParams: {
                                    called_from: 'FLIGHT_PANEL',
                                    flightKey
                                  }
                                })
                              );
                            }}
                          >
                            {' '}
                            <span className="vehoicon-mode_edit color-secondary dim" />
                          </a>
                        ) : null}
                      </p>
                    )}
                    {discountAppliedBatch}
                    {flightStatus === 'BLOCKED' ? (
                      <div>
                        <span className="small block fade">
                          <span className="micro normal pill success">PNR</span>&nbsp;
                          <span className="base bold">{flight.pnr}</span>
                        </span>
                        <span className="pos-r color-accent-7">
                          <span className="expires-txt fine-text">
                            Expires in (hh:mm)
                          </span>
                          {userDetails &&
                          userDetails.loggedIn &&
                          userDetails.userType === 'ADMIN' &&
                          flight.canEditFareValidity &&
                          !makeReadOnly ? (
                            <a
                              className="base expires-hh-mm"
                              style={{ zIndex: 10, cursor: 'pointer' }}
                              onClick={e => {
                                e.stopPropagation();
                                e.nativeEvent.stopImmediatePropagation();

                                let flightKey = encodeCostingKeyForURL(
                                  flight.key
                                );
                                this.props.history.push(
                                  itineraryModalsRouteHelper({
                                    itineraryId:
                                      costedItinerary.itinerary.itineraryId,
                                    parentPage: routingPageType.inclusion,
                                    regionCode:
                                      costedItinerary.itinerary.regionCode,
                                    target: RATE_MATCH_FLIGHT,
                                    customParams: {
                                      called_from: 'FLIGHT_PNR_VALIDITY',
                                      flightKey
                                    }
                                  })
                                );
                              }}
                            >
                              {' '}
                              <span className="vehoicon-mode_edit" />
                            </a>
                          ) : null}
                          <span
                            className="flight-timer normal meta-text"
                            id={'flight-timer-' + inx}
                          />
                        </span>
                      </div>
                    ) : null}
                    {flightStatus !== 'BLOCKED' ? (
                      <div>
                        <div
                          data-toggle={isBooked ? 'tooltip' : ''}
                          data-title="The itinerary has already been booked. Cant make any further changes."
                          data-placement="bottom"
                          data-container="body"
                        >
                          <a
                            className={
                              `btn btn-sm btn-primary tracker-flightchangebtn 
                              ${isBooked ? 'disabled' : ''} ${makeReadOnly ? 'hide' : ''}
                            `}
                            onClick={e =>
                              isBooked
                                ? null
                                : this.onChangeClick(flight, 'CHANGE', e)
                            }
                          >
                            Change
                          </a>
                          {
                            isAdmin &&
                              !makeReadOnly &&
                              !isNonEditable &&
                              Object.keys(flight.trips).length === 1
                              ? (
                                <a
                                  onClick={e => {
                                    e && e.stopPropagation();
                                    this.handleCallToActionClick(
                                      {
                                        itineraryId: costedItinerary.itinerary.itineraryId,
                                        key: encodeURI(flight.key),
                                        transfer: 'flight',
                                        isRemove: true
                                      },
                                      e
                                    )
                                  }}
                                  className={
                                    'btn btn-sm btn-danger btn-outline fade' +
                                    (isNonEditable ? 'disabled' : '')
                                  }
                                >
                                  Remove
                                </a>
                              ) : null}
                        </div>
                        <span className="block">
                          <a
                            href="#"
                            className="btn btn-sm btn-link"
                            onClick={e => {
                              e.preventDefault();
                              e.stopPropagation();
                              e.nativeEvent.stopImmediatePropagation();
                              onViewDetailsClick(flight);
                            }}
                          >
                            More info
                          </a>
                        </span>
                      </div>
                    ) : null}
                  </div>
                </div>
              </article>
              {flightRefs.length - 1 !== inx ? <hr className="tear" /> : null}
            </div>
          );
        } else {
          if (
            flightStatus === 'ERROR' ||
            flightStatus === 'USER_REMOVED' ||
            flightStatus === 'UNAVAILABLE'
          ) {
            let errorFlightObj =
              flight.errorDetail && flight.errorDetail.flightErrorDetails;
            let errorMessage =
              'Flight costing failed this time. Try after some time!';
            if (flightStatus === 'USER_REMOVED') {
              errorMessage = 'You have removed this flight from itinerary!';
            } else if (flightStatus === 'UNAVAILABLE') {
              errorMessage = 'Flight is unavailable. Try a different date';
            }

            return (
              <div key={flightId}>
                <article
                  className={
                    'row-costed-item row ' +
                    (flightStatus === 'USER_REMOVED' ? 'warning' : 'danger')
                  }
                >
                  <div className="col-xs-9 col-sm-9 col-md-8 spacer">
                    <div className="costed-item-head">
                      <div className="date-costed">
                        <span className="month">
                          {errorFlightObj[0].depMonth}
                        </span>
                        <span className="date">{errorFlightObj[0].depDay}</span>
                      </div>
                      <h5 className="no-margin semi-bold">
                        {errorFlightObj[0].departureCityName} -{' '}
                        {errorFlightObj[0].arrivalCityName}
                      </h5>
                      <span className="meta-text color-accent-7">
                        {errorMessage}
                      </span>
                    </div>
                  </div>
                  <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
                  <div className="col-xs-3 col-sm-3 col-md-2 spacer">
                    <div className="action price-info text-center">
                      <div
                        data-toggle={isBooked ? 'tooltip' : ''}
                        data-title="The itinerary has already been booked. Cant make any further changes."
                        data-placement="bottom"
                        data-container="body"
                      >
                        {makeReadOnly? null : <a
                          className={
                            `btn btn-sm btn-primary 
                            ${isBooked ? 'disabled' : ''}`
                          }
                          onClick={e =>
                            isBooked
                              ? null
                              : this.onChangeClick(flight, 'CHANGE', e)
                          }
                        >
                          {' '}
                          {flightStatus === 'USER_REMOVED' ? 'Add' : 'Retry'}
                        </a>}
                      </div>
                    </div>
                  </div>
                </article>
                {flightRefs.length - 1 !== inx ? <hr className="tear" /> : null}
              </div>
            );
          } else {
            return (
              <div key={Math.random()} className="row spaced-5">
                <div className="col-xs-12 single-costing-tab">
                  <div className="row messaging-container">
                    <div className="col-xs-9">
                      <p className="main-para">
                        <span className="tag-secondary grey">
                          {flightStatus === 'SOLD_OUT'
                            ? 'Sold Out'
                            : flightStatus}
                        </span>{' '}
                        <span className="message">
                          Flight costings failed this time. Try after some time!
                        </span>
                      </p>
                    </div>
                    <div className="col-xs-3">
                      <div className="action price-info text-center">
                        <div
                          data-toggle={isBooked ? 'tooltip' : ''}
                          data-title="The itinerary has already been booked. Cant make any further changes."
                          data-placement="bottom"
                          data-container="body"
                        >
                          <a
                            className={
                              'btn btn-sm btn-primary ' +
                              (isBooked ? 'disabled' : '')
                            }
                            onClick={e =>
                              isBooked
                                ? null
                                : this.onChangeClick(flight, 'CHANGE', e)
                            }
                          >
                            {' '}
                            {flightStatus === 'SOLD_OUT' ? 'Retry' : 'Add'}
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          }
        }
      });
    }
  }

  render() {
    if (this.props.packageRate) {
      return (
        <section className="flights">
          {this.renderFlightPanels()}
          <hr className="tear" />
        </section>
      );
    } else {
      let { alertFound, alertRead, alertExpand, alertText } = this.state;

      return (
        <section className="flights">
          <div className="cost-container">
            {alertFound ? (
              <div className={'card-info ' + (alertRead ? '' : 'show-info')}>
                <p className="clearfix">
                  <span
                    onClick={e => this.setState({ alertExpand: !alertExpand })}
                    className={
                      'pull-left ' + (alertExpand ? '' : 'truncate-mobile')
                    }
                  >
                    <i className="vehoicon-exclamation-circle" /> {alertText}
                  </span>
                  <button
                    type="button"
                    onClick={e => this.setState({ alertRead: true })}
                    className="btn btn-link pull-right"
                  >
                    OK
                  </button>
                </p>
              </div>
            ) : null}

            <div className="cost-section-head">
              <h3 className="mute">Flights</h3>
            </div>
            {this.renderFlightPanels()}
            {this.props.costedItinerary.itinerary.regionCode === 'dxb' ? (
              <div className="alert-bar spacer-top">
                OK To Board document for UAE Dubai is not included in the fare.
                (Compulsorily required in case of specific airlines)
              </div>
            ) : null}
          </div>
        </section>
      );
    }
  }
}

const mapStateToProps = () => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    manageInterCityTransfer: bindActionCreators(manageInterCityTransfer, dispatch)
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(FlightPanels)
);
