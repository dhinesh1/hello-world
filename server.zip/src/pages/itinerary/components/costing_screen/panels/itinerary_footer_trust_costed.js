import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { AppConfig } from '../../../../../app-config';
import Collapsible from 'react-collapsible';
import { Link } from 'react-router-dom';
import LazyLoadComponent from '../../../../../common_components/LazyLoadComponent';
import {
  trackEvent,
  EVENT_ITINERARY_MODIFIED,
  EVENT_INCLUSIONS_MODIFIED,
  EVENT_BOOKING_INITIATED
} from '../../../../../helpers/ML/EventsTracker';
import {
  itineraryModalsRouteHelper,
  CBR
} from '../../../../../helpers/routesHelper';

const API_URL = AppConfig.api_url;
const USER_TYPE_AGENT = AppConfig.user_type_agent;

class ItineraryFooterTrustCosted extends Component {
  constructor(props) {
    super(props);

    this.bookTripCall = this.bookTripCall.bind(this);
    this.updateCost = this.updateCost.bind(this);

    this.state = {
      expanded: 0
    };

    this.onTriggerClick = this.onTriggerClick.bind(this);
  }

  onTriggerClick(index) {
    if (this.state.expanded === index) {
      index = '';
    }
    this.setState({ expanded: index });
    const isInclusions =
      window &&
      window.location &&
      (window.location.pathname || '').includes('/inclusions/');
    trackEvent(
      isInclusions ? EVENT_INCLUSIONS_MODIFIED : EVENT_ITINERARY_MODIFIED,
      { faq_clicked: true }
    );
  }

  updateCost() {
    let updateCostBtn = document.getElementById('update-cost-btn');
    if (updateCostBtn) {
      updateCostBtn.click();
    }
  }

  bookTripCall(e) {
    e.preventDefault();

    trackEvent(EVENT_BOOKING_INITIATED, {	
      is_header_button: false
    });

    this.props.history.push(`/booking-travellers/${this.props.itineraryId}`);
  }

  render() {
    let { expanded } = this.state;
    if (this.props.summary !== undefined) {
      let {
        summary,
        itinerary,
        costingConfiguration,
        isBooked,
        collapse_prefix,
        userDetails,
        location
      } = this.props;
      let pdf_url = `${API_URL}cost/${
        itinerary.itineraryId
      }/downloadItineraryPdf`;
      const CostedItineraryfaqArray = [
        {
          title: 'Is this trip costed in real time prices?',
          body: `Yes, this is real-time costing. However the prices of flights, stay and others might change as per demand. Your costed itinerary will expire in 6 hours and you need to click on 'Update Cost' to view the current updated price for the itinerary.`
        },
        {
          title: 'How do I change my flights and hotel options?',
          body: `A click on the 'Change' button near the flight or hotel price will give you options to pick from. It's your itinerary, feel free!`
        },
        {
          title: 'How do I change the dates of my departure?',
          body: `Change is inevitable and we know that! You can change your travel dates by clicking the edit option under 'Itineraries and Inclusions' tab. Click on this and pick a new date and proceed with 'Calculate trip Cost'. You will get a freshly costed itinerary for the newly picked dates.`
        },
        {
          title: 'How to change the configuration of my room?',
          body: `Selected your room for 2 adults but now want to add a child? Or want to book another room as well?  The tab under 'Itineraries and Inclusions' to the rescue again! Under the 'No of passengers' drop, choose custom option. Once done, you have the complete leverage to add the passenger count and the number of rooms you require.`
        },
        {
          title: 'What help would be provided in Visa assistance?',
          body: `Visa isn't rocket science, but we are here to help. Documents to be submitted during the interview, how to book your appointment online and how to apply for travel insurance - ask us for all these queries, we are here to help!`
        },
        {
          title: `How can I book this trip? How will I get confirmations of all the bookings?`,
          body: `Yaay, you are vacation-ready! You can book this trip by paying just 50% cost of the entire trip. All of your bookings will happen in real time and you will be able to download your flight tickets and other vouchers immediately.`
        }
      ];

      return (
        <section className={`summary ${collapse_prefix}`}>
          <div className="cost-container">
            <div className="cost-section-head">
              <h3 className="mute" />
            </div>
            <article className="row-costed-item row">
              <div className="col-xs-12 col-sm-6 text-center">
                <LazyLoadComponent>
                  <img
                    className="cost-img"
                    src="https://pyt-images.imgix.net/images/misc/cost-cta-min.png"
                    alt="cost-cta"
                  />
                </LazyLoadComponent>
                {itinerary.costed && !itinerary.staleCost ? (
                  <p className="footer-happy base dim">
                    Airline and hotel prices may keep changing, block these
                    rates by paying just{' '}
                    {summary.recommendedPayment.recommendedPercentage}% now!
                  </p>
                ) : (
                  <p className="footer-happy base dim">
                    Airline and hotel prices may keep fluctuating, looks like we
                    need to update the cost of this itinerary
                  </p>
                )}

                {this.props.itinerary.costed &&
                !this.props.itinerary.staleCost ? (
                  <button
                    className="btn btn-primary tracker-pay-just-costedscreen"
                    onClick={e => this.bookTripCall(e)}
                  >
                    Pay just{' '}
                    <span className="color-accent">
                      <span className="WebRupee">Rs.</span>{' '}
                      {summary.recommendedPayment.recommendedAmountToBePaid}
                    </span>{' '}
                    &amp; book
                  </button>
                ) : (
                  <button className="btn btn-primary" onClick={this.updateCost}>
                    Update cost
                  </button>
                )}
              </div>

              {userDetails &&
              userDetails.loggedIn &&
              userDetails.userType === USER_TYPE_AGENT ? (
                <div className="col-xs-12 col-sm-6 text-center">
                  <LazyLoadComponent>
                    <img
                      className="cost-img"
                      src="https://pyt-images.imgix.net/images/misc/agent-cta-min.png"
                      alt="agent-cta"
                    />
                  </LazyLoadComponent>
                  <p className="footer-question base dim">
                    Share? Download as PDF and share to your client
                  </p>
                  <button
                    className={'btn btn-primary '}
                    onClick={e => window.open(pdf_url, '_blank')}
                  >
                    Download as PDF
                  </button>
                </div>
              ) : (
                <div className="col-xs-12 col-sm-6 text-center">
                  <LazyLoadComponent>
                    <img
                      className="cost-img"
                      src="https://pyt-images.imgix.net/images/misc/agent-cta-min.png"
                      alt="agent-cta"
                    />
                  </LazyLoadComponent>
                  <p className="footer-question base dim">
                    Questions? Talk to our travel consultants to get help with
                    planning &amp; pricing
                  </p>
                  <Link
                    key={'itineraryCostingTalkToExpertBtn'}
                    to={itineraryModalsRouteHelper({
                      itineraryId: itinerary.itineraryId,
                      regionCode: itinerary.regionCode,
                      location,
                      target: CBR
                    })}
                    className={
                      'btn btn-primary ' + this.props.talkToExportTrackerClass
                    }
                  >
                    Talk to our travel consultants
                  </Link>
                </div>
              )}
            </article>
            <div className="block zig-zag">
              <span />
            </div>
            <div className="entice-action double-spacer-both text-center no-padding">
              <div className="fw faq-outer tracker-costedfaq">
                <div className="row faq text-left padding-top no-padding no-bg-color">
                  <div className="col-md-12">
                    <div className="clearfix panel-group accordions">
                      {CostedItineraryfaqArray.map((faq, index) => {
                        return (
                          <CostedFootertrustAccordion
                            key={index}
                            index={index}
                            expanded={expanded}
                            onTriggerClick={this.onTriggerClick}
                            trigger={
                              <h5 className="panel-title">{faq.title}</h5>
                            }
                          >
                            {faq.body}
                          </CostedFootertrustAccordion>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      );
    }
  }
}

export default withRouter(ItineraryFooterTrustCosted);

const CostedFootertrustAccordion = props => (
  <section className="panel panel-default itinerary-panel">
    <Collapsible
      open={props.expanded === props.index}
      triggerTagName={'div'}
      triggerClassName={'panel-heading accordion-toggle'}
      triggerOpenedClassName={'panel-heading accordion-toggle'}
      contentInnerClassName={'panel-body'}
      handleTriggerClick={e => props.onTriggerClick(props.index)}
      trigger={props.trigger}
    >
      {props.children}
    </Collapsible>
  </section>
);
