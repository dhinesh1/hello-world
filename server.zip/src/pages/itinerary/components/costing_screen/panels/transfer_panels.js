import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import _ from 'lodash';
import { withRouter } from 'react-router-dom';

import {
  changeTransferType,
  manageInterCityTransfer
} from '../../../../../actions/actions_app';
import TransferContainer from '../../../../../common_components/transfer_container';
import NoCostingObjectErrorBlock from './noCostingObjectErrorBlock';
import { trackEvent, EVENT_INCLUSIONS_MODIFIED, EVENT_CHANGE } from '../../../../../helpers/ML/EventsTracker';
import { encodeCostingKeyForURL } from '../../../../../helpers/utilsHelper';
import { itineraryModalsRouteHelper, BUS_ALTERNATES, routingPageType } from '../../../../../helpers/routesHelper';

class TransferPanels extends Component {
  constructor(props) {
    super(props);

    this.changeTransferTypeHandler = this.changeTransferTypeHandler.bind(this);
    this.handleInterCityActionClick = this.handleInterCityActionClick.bind(this);
  }

  handleInterCityActionClick(payload, e) {
    e && e.preventDefault();

    this.props
      .manageInterCityTransfer(payload)
      .then()
      .catch();
  }

  changeTransferTypeHandler(transfer, e) {
    e.preventDefault();

    trackEvent(EVENT_INCLUSIONS_MODIFIED, {
      transfer_interaction: EVENT_CHANGE
    });

    this.props
      .changeTransferType(this.props.itineraryId, transfer.key)
      .catch(() => {
        // console.log('failed');
      });

    /*
    if(transfer.inCombo){
        swal({
                title: "This may remove your Combo Package savings",
                text: "This transfer is part of a Combo Package in your itinerary. Modifying this may remove the combo package. Are you sure you want to do this?",
                // imageUrl: '/images/cost_error.png',
                animation: true,
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Ok, Continue",
                cancelButtonText: "No, Don't modify this transfer",
                closeOnConfirm: true,
                closeOnCancel: true
            },
            function(isConfirm){
                if(isConfirm) {
                        _this.props.changeTransferType(transfer.key);
                }
                else {

                }
            });

      _this.props.changeTransferType(transfer.key);
    }
		else {
					_this.props.changeTransferType(transfer.key);
		}
		*/
  }

  onChangeBusClick = (transfer, e) => {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();

    let { history, location, itineraryId, regionCode } = this.props;
    let currentKey = encodeCostingKeyForURL(transfer.key);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode,
        parentPage: routingPageType.inclusion,
        target: BUS_ALTERNATES,
        customParams: {
          transferKey: currentKey
        }
      })
    );
  };

  renderTransferPanels() {
    let {
      transferRefs,
      isBooked,
      userDetails,
      transferCostingObj,
      child_count,
      adult_count,
      hidePrice,
      itineraryId,
      regionCode,
      makeReadOnly
    } = this.props;

    if (transferRefs !== undefined && transferCostingObj !== undefined) {
      return transferRefs.map(transferId => {
        let transfer =
          transferCostingObj.transferCostingById &&
          transferCostingObj.transferCostingById[transferId];
        let is_hidden = transfer && transfer.alternateAvailable ? '' : 'hidden';
        let transferTypeChangeText =
          transfer && transfer.type === 'PRIVATE'
            ? 'Change to shared'
            : 'Change to private';
        const isNonEditable =
          isBooked && userDetails && userDetails.userType !== 'ADMIN';

        const changeTransferTypeHandler = this.changeTransferTypeHandler;

        // Handler for missed costing
        if (!transfer) {
          return (
            <NoCostingObjectErrorBlock failedFor="transfer" isLastRow={false} />
          );
        }

        return (
          <TransferContainer
            key={transferId}
            userDetails={userDetails}
            transfer={transfer}
            is_hidden={is_hidden}
            transferTypeChangeText={transferTypeChangeText}
            isNonEditable={isNonEditable}
            child_count={child_count}
            adult_count={adult_count}
            hidePrice={hidePrice}
            itineraryId={itineraryId}
            changeTransferTypeHandler={changeTransferTypeHandler}
            handleInterCityActionClick={this.handleInterCityActionClick}
            regionCode={regionCode}
            isBooked={isBooked}
            onChangeBusClick={this.onChangeBusClick}
            makeReadOnly={makeReadOnly}
          />
        );
      });
    } else {
      return null;
    }
  }

  render() {
    return (
      <section className="transfers">{this.renderTransferPanels()}</section>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    changeTransferType: bindActionCreators(changeTransferType, dispatch),
    manageInterCityTransfer: bindActionCreators(manageInterCityTransfer, dispatch)
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TransferPanels)
);