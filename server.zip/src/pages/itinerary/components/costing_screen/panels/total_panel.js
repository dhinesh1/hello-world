import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { isNullorUndefined } from '../../../../../helpers/utilsHelper';
import { trackEvent, EVENT_BOOKING_INITIATED } from '../../../../../helpers/ML/EventsTracker';

class TotelSummaryPanel extends Component {
  convertAsList(data, type) {
    const regionCode = this.props.itinerary && this.props.itinerary.regionCode;
    if (
      type === 'inclusions' &&
      (regionCode === 'mle' || regionCode === 'sez' || regionCode === 'mus') &&
      data &&
      !data.includes('Two way Airport Hotel Transfers')
    ) {
      if (isNullorUndefined(data) || data === '') {
        data = [];
      }
      data.push(
        'Two way Airport Hotel Transfers',
        'Meal Plan as per Hotel Inclusions'
      );
    }
    let list = data.map((option, inx) => {
      return (
        <li key={'option_' + inx} className="font-secondary">
          {option}
        </li>
      );
    });

    return <ul className="meta-text dim">{list}</ul>;
  }

  bookTripCall(e) {
    e.preventDefault();

    trackEvent(EVENT_BOOKING_INITIATED, {	
      footer: true
    });

    this.props.history.push(`/booking-travellers/${this.props.itineraryId}`);
  }

  render() {
    if (this.props.summary !== undefined) {
      let {
        summary,
        itinerary,
        userDetails,
        makeReadOnly
      } = this.props;

      return (
        <section id="all-total-panels" className="summary">
          <div className="cost-container">
            <div className="cost-section-head">
              <h3 className="mute">Total cost</h3>
            </div>
            <article className="row-costed-item row">
              <div className="col-xs-12 col-sm-6">
                <h5>Inclusions</h5>
                <div className="circle-list">
                  {this.convertAsList(summary.inclusions, 'inclusions')}
                </div>
              </div>
              <div className="col-xs-12 col-sm-6">
                {userDetails &&
                userDetails.loggedIn &&
                userDetails.userType === 'AGENT' ? null : (
                  <h5>Complimentary service</h5>
                )}
                {userDetails &&
                userDetails.loggedIn &&
                userDetails.userType === 'AGENT' ? null : (
                  <p className="meta-text dim">
                    Get your timely trip updates and expert's suggestions with Pickyourtrail's{' '}
                    <a
                      href="https://land.ly/45UAR4"
                      rel={'noopener noreferrer'}
                      target="_blank"
                    >
                      Mobile App
                    </a>. You also get to stay in touch with a dedicated travel consultant throughout your trip for assistance and guidance.
                  </p>
                )}
                <h5 className="spacer-top">Exclusions</h5>
                <div className="circle-list">
                  {this.convertAsList(summary.exclusions, 'exclusion')}
                </div>
              </div>
            </article>
            <div className="row-costed-item total row">
              <div className="col-xs-12 col-sm-6">
                <p className="meta-text dim spacer-top">
                  Pickyourtrail service fee will be applied for booking and concierge support. Currency conversion charges will be levied, wherever it's applicable.
                </p>
              </div>
              <div className="col-xs-12 col-sm-6 text-center">
                <span className="h1 spacer-top block">
                  <span className="WebRupee">Rs.</span> {itinerary.totalCost}
                  {this.props.itinerary.campaign &&
                  this.props.itinerary.regionCode === 'mle' ? (
                    <sup>*</sup>
                  ) : null}
                </span>
                <span className="meta-text dim">
                  (Total cost including taxes &amp; fees)
                </span>
                {userDetails &&
                userDetails.loggedIn &&
                userDetails.userType === 'ADMIN' &&
                summary.discounts &&
                summary.discounts !== '0' &&
                !makeReadOnly ? (
                  <React.Fragment>
                    <br />
                    <span className="meta-text dim">
                      Discount on itinerary : &#8377; {summary.discounts}
                    </span>
                  </React.Fragment>
                ) : null}
              </div>

              {this.props.itinerary.campaign &&
              this.props.itinerary.regionCode === 'mle' ? (
                <div className="col-xs-12 text-center message-container">
                  <span>
                    <sup>*</sup> All rates and availability for accommodation
                    will be confirmed within 24 hours of booking.
                  </span>
                </div>
              ) : null}
            </div>
          </div>
        </section>
      );
    }
  }
}

export default withRouter(TotelSummaryPanel);
