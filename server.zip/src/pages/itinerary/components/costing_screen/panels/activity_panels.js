import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import _ from 'lodash';

import placeHolderUrls from '../../../../../common_components/Image/place_holder_urls';
import SmartImage from '../../../../../common_components/Image/smart_image';
import NoCostingObjectErrorBlock from './noCostingObjectErrorBlock';
import {
  encodeActivityKeyForURL,
  encodeCostingKeyForURL
} from '../../../../../helpers/utilsHelper';
import { ACTIVITY_DETAILS, itineraryModalsRouteHelper, ACTIVITY_ALTERNATES, RATE_MATCH_ACTIVITY } from '../../../../../helpers/routesHelper';

class ActivityPanels extends Component {
  constructor(props) {
    super(props);

    this.handleDetailsClick = this.handleDetailsClick.bind(this);
    this.renderSingleActivityPanel = this.renderSingleActivityPanel.bind(this);
  }

  // componentDidMount() {
  //   $('#view-activity-details-mobile').on('click', () => {
  //     $('#view-activity-details-desktop').trigger('click');
  //   });
  // }

  handleDetailsClick(activityDetails, action, evt) {
    evt.preventDefault();
    evt.stopPropagation();
    evt.nativeEvent.stopImmediatePropagation();

    let { history, location, regionCode, itineraryId } = this.props;
    let activityDetailId = activityDetails.planningToolId;
    let slot = _.find(this.props.allSlot, function(slots) {
      return (
        slots.activitySlotDetail &&
        slots.activitySlotDetail.activityId === activityDetailId
      );
    });

    if (typeof slot !== 'undefined') {
      let slotIdentifier = _.findKey(this.props.allSlot, slot);
      const activityKey = encodeActivityKeyForURL(slotIdentifier);

      if (action === 'VIEW') {
        history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            location,
            target: ACTIVITY_DETAILS,
            customParams: { activityKey }
          })
        );
      } else {
        history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            location,
            target: ACTIVITY_ALTERNATES,
            customParams: { activityKey }
          })
        )
      }
    }
  }

  renderSingleActivityPanel() {
    let activityDetailId = 0;
    let { itineraryId, regionCode, history, location, userDetails, isBooked, activityObjs, activityRefs, activityCostingObj, splitPricing, makeReadOnly } = this.props;
    let isAdmin =
      userDetails && userDetails.loggedIn && userDetails.userType === 'ADMIN';
    let isAgent =
      userDetails && userDetails.loggedIn && userDetails.userType === 'AGENT';

    if (activityObjs !== undefined && activityRefs !== undefined && activityCostingObj !== undefined) {
      return activityRefs.map((activityId, inx) => {
        let activityCosting = activityCostingObj.activityCostingById && activityCostingObj.activityCostingById[
          activityId
        ];
        activityDetailId = (activityCosting || {}).activityId;
        let activityDetails = activityObjs[activityDetailId];

        let isLastRow = activityRefs.length === inx + 1;

        // Handler for missed costing
        if (!activityCosting || !activityDetails) {
          return <NoCostingObjectErrorBlock 
            failedFor="activity"
            isLastRow={isLastRow}
          />
        }

        let selectedTourGrade = activityDetails.selectedTourGrade;
        let isViatorActivity = selectedTourGrade.ourSourceProvider === 'VIATOR';

        let isCancelled =
          isBooked &&
          isViatorActivity &&
          activityDetails.costingInfo &&
          activityDetails.costingInfo.cancelled;

        let changeBlocked = false;
        if (isBooked) {
          changeBlocked = isBooked && !isAdmin && !isAgent;
          // changeBlocked = (isBooked && !isAdmin && !isAgent) || ((isAdmin || isAgent) && isViatorActivity && !isCancelled);
        }

        // Surrounded with if to check the costing status else showing error screen
        if (
          activityCosting.status === 'SUCCESS' ||
          activityCosting.status === 'SOLD_OUT'
        ) {
          let cancellationBadge = isCancelled ? (
            <div className="pill color-white bg-accent-7">CANCELLED</div>
          ) : activityCosting.status === 'SOLD_OUT' ? (
            <div className="pill color-white bg-accent-7">SOLD OUT</div>
          ) : null;

          let inclusion = {
            __html: selectedTourGrade.inclusion
          };
          let cityName = activityCosting.cityText;

          let comoboPricingClasses = '';
          let comoboPricingContainerClass = 'price-info';
          let comboPricingMessageBox = null;

          if (activityCosting.inCombo) {
            comoboPricingContainerClass = splitPricing
              ? ' price-info-center'
              : ' price-info';
            comoboPricingClasses = ' strikethrough dim vmargin-small';
            comboPricingMessageBox = (
              <div className="pointing-box top">
                <span className="meta-text t-5 inline-block">
                  Included in combo package!
                </span>
              </div>
            );
          } else if (activityCosting.inSwissPass) {
            comoboPricingContainerClass = splitPricing
              ? ' price-info-center'
              : ' price-info';
            comoboPricingClasses = ' strikethrough dim vmargin-small';
            comboPricingMessageBox = (
              <div className="pointing-box top">
                <span className="meta-text t-5 inline-block">
                  Swiss Pass Special Price!
                </span>
              </div>
            );
          }

          let duration_type_raw = selectedTourGrade.durationType;
          let duration_type = null;
          switch (duration_type_raw) {
            case 'QUARTER':
              duration_type = 'Quarter day';
              break;
            case 'HALF':
              duration_type = 'Half day';
              break;
            case 'FULL':
              duration_type = 'Full day';
              break;
            default:
              duration_type = 'Half day';
          }

          let activityPriceBlock =
            activityDetails.free ||
            activityCosting.status === 'SOLD_OUT' ? null : (
              <span
                className={'price block'}
                style={
                  activityCosting.inSwissPass || activityCosting.inCombo
                    ? { marginBottom: 0 }
                    : null
                }
              >
                {(activityCosting.inSwissPass || activityCosting.inCombo) &&
                activityCosting.publishedCost ? (
                  <span className="block">
                    <span className="WebRupee">Rs.</span>
                    {activityCosting.publishedCost}
                  </span>
                ) : null}
                <span className={'price ' + comoboPricingClasses}>
                  {activityCosting.totalCost ? (
                    <span className="WebRupee">Rs.</span>
                  ) : null}
                  {activityCosting.totalCost}
                  {userDetails &&
                  userDetails.loggedIn &&
                  userDetails.userType === 'ADMIN' &&
                  !isBooked &&
                  activityCosting.viator &&
                  !makeReadOnly ? (
                    <a
                      className={'cursor-pointer'}
                      onClick={e => {
                        e.preventDefault();
                        e.stopPropagation();
                        e.nativeEvent.stopImmediatePropagation();
                        let cKey = encodeCostingKeyForURL(activityCosting.key);

                        history.push(
                          itineraryModalsRouteHelper({
                            itineraryId,
                            regionCode,
                            location,
                            target: RATE_MATCH_ACTIVITY,
                            customParams: {
                              activityKey: cKey,
                              called_from: 'ACTIVITY_PANEL'
                            }
                          })
                        );
                      }}
                    >
                      {' '}
                      <span className="vehoicon-mode_edit" />
                    </a>
                  ) : null}
                </span>
              </span>
            );

          const discountAppliedBatch = userDetails && userDetails.userType === 'ADMIN' && activityCosting.rateMatches && activityCosting.rateMatches.length > 0 ?
          <span className={'pill color-white bg-accent-4'}> Discount Applied </span> : null;


          return (
            <div key={activityDetailId}>
              <article
                className={
                  'row-costed-item row zoomable ' +
                  (isCancelled || activityCosting.status === 'SOLD_OUT'
                    ? 'danger'
                    : '')
                }
                onClick={e =>
                  this.handleDetailsClick(activityDetails, 'VIEW', e)
                }
              >
                <div className="col-xs-9 col-sm-9 col-md-8 spacer">
                  <div className="costed-item-head">
                    <div className="date-costed">
                      <span className="month">{activityCosting.mon}</span>
                      <span className="date">{activityCosting.day}</span>
                    </div>
                    <h5 className="no-margin semi-bold">
                      {activityDetails.title}
                    </h5>
                    <span className="small dim">
                      {duration_type} in {cityName}
                    </span>
                  </div>
                  <div className="costed-item-details clearfix">
                    <div className="col-xs-5 col-sm-2 col-md-3 no-padding">
                      <div className="media-shell">
                        <figure className="sd">
                          <SmartImage
                            src={activityDetails.mainPhoto}
                            disableLazyLoad={true}
                            defaultImage={placeHolderUrls.activitySmall}
                            alt={activityDetails.title}
                          />
                        </figure>
                      </div>
                    </div>
                    <div className="col-xs-7 col-sm-9 col-md-9">
                      {activityDetails.free ? null : (
                        <div>
                          <span className="fine-text fade color-grey">
                            Includes:
                          </span>
                          <div
                            className="fine-text fade color-grey circle-list"
                            dangerouslySetInnerHTML={inclusion}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
                  <li>
                    <span className="vehoicon-ion-android-time" />
                    {selectedTourGrade.duration} duration
                  </li>
                  <li>
                    <span className="vehoicon-transfer" />
                    {this.getTransferTypeString(selectedTourGrade.transferType)}
                  </li>
                  {activityDetails.costingInfo &&
                  activityDetails.costingInfo.viator ? (
                    activityDetails.costingInfo.refundable ? (
                      <li>
                        <span className="vehoicon-refundable color-success" />Refundable
                      </li>
                    ) : (
                      <li>
                        <span className="vehoicon-non-refundable color-danger" />Non
                        Refundable
                      </li>
                    )
                  ) : null}
                </ul>
                <div className="col-xs-3 col-sm-3 col-md-2 spacer">
                  <div className={'action ' + comoboPricingContainerClass}>
                    {cancellationBadge}
                    {activityDetails.free ? (
                      <span className="price block">
                        <span className="meta-text dim">Self exploration</span>
                      </span>
                    ) : (
                      activityPriceBlock
                    )}
                    {discountAppliedBatch}
                    {splitPricing &&
                    activityCosting.status === 'SUCCESS'
                      ? comboPricingMessageBox
                      : null}
                    <div
                      data-toggle={changeBlocked ? 'tooltip' : ''}
                      data-title="The itinerary has already been booked. Cant make any further changes."
                      data-placement="bottom"
                      data-container="body"
                    >
                      {makeReadOnly ? null : <a
                        className={
                          `btn btn-sm btn-primary change-activity-ga tracker-actchangebtn '
                          ${changeBlocked ? 'disabled' : ''}`
                        }
                        onClick={e =>
                          changeBlocked
                            ? null
                            : this.handleDetailsClick(
                                activityDetails,
                                'CHANGE',
                                e
                              )
                        }
                      >
                        {' '}
                        Change{' '}
                      </a>}
                    </div>
                    <span className="block">
                      <a
                        onClick={e =>
                          this.handleDetailsClick(activityDetails, 'VIEW', e)
                        }
                        href="#"
                        className="btn btn-sm btn-link dim normal"
                      >
                        More info
                      </a>
                    </span>
                  </div>
                </div>
              </article>
              {activityRefs.length - 1 !== inx ? (
                <hr className="tear" />
              ) : null}
            </div>
          );
        } else if (activityCosting.status === 'ERROR') {
          return (
            <div key={activityCosting.activityId}>
              <article className="row-costed-item row danger">
                <div className="col-xs-9 col-sm-9 col-md-8 spacer">
                  <div className="costed-item-head">
                    <div className="date-costed">
                      <span className="month">{activityCosting.mon}</span>
                      <span className="date">{activityCosting.day}</span>
                    </div>
                    <h5 className="no-margin semi-bold">
                      {activityDetails.title}
                    </h5>
                    <span className="small dim danger">
                      Sorry, Activity costing has failed currently. Please try
                      after sometime!
                    </span>
                  </div>
                </div>
                <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
                <div className="col-xs-3 col-sm-3 col-md-2 spacer">
                  <div className="action price-info text-center">
                    <div
                      data-toggle={changeBlocked ? 'tooltip' : ''}
                      data-title="The itinerary has already been booked. Cant make any further changes."
                      data-placement="bottom"
                      data-container="body"
                    >
                      {makeReadOnly ? null : <a
                        className={
                          'btn btn-sm btn-primary change-activity-ga tracker-actchangebtn ' +
                          (changeBlocked ? 'disabled' : '')
                        }
                        onClick={e =>
                          changeBlocked
                            ? null
                            : this.handleDetailsClick(
                                activityDetails,
                                'CHANGE',
                                e
                              )
                        }
                      >
                        {' '}
                        Change{' '}
                      </a>}
                    </div>
                  </div>
                </div>
              </article>
              {activityRefs.length - 1 !== inx ? (
                <hr className="tear" />
              ) : null}
            </div>
          );
        }
      });
    } else {
      return null;
    }
  }

  getTransferTypeString(transferType) {
    if (transferType === 'PRIVATE') return 'Private transfer';
    else if (transferType === 'SHARED') return 'Shared transfer';
    else if (transferType === 'NOTRANSFER') return 'No transfer';
    else return 'Transfer';
  }

  render() {
    return (
      <section className="activities">
        <div className="cost-container">
          <div className="cost-section-head">
            <h3 className="mute">Activities</h3>
          </div>
          {this.renderSingleActivityPanel()}
        </div>
      </section>
    );
  }
}

export default withRouter(ActivityPanels);
