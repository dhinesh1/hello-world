import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import NoCostingObjectErrorBlock from './noCostingObjectErrorBlock';
import { encodeActivityKeyForURL } from '../../../../../helpers/utilsHelper';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  RENTAL_CAR_DETAILS,
  RENTAL_CAR_ALTERNATES,
  RATE_MATCH_RENTAL_CAR
} from '../../../../../helpers/routesHelper';

class RentalCarPanels extends Component {
  constructor(props) {
    super(props);

    this.onDetailsClick = this.onDetailsClick.bind(this);
    this.onChangeClick = this.onChangeClick.bind(this);
  }

  onDetailsClick(rcKey, e) {
    e && e.preventDefault();
    let { history, itineraryId, regionCode } = this.props;

    let rcEncKey = encodeActivityKeyForURL(rcKey);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode,
        parentPage: routingPageType.inclusion,
        target: RENTAL_CAR_DETAILS,
        customParams: { rcKey: rcEncKey }
      })
    );
  }

  onChangeClick(transfer, e) {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
    let { history, itineraryId, regionCode } = this.props;

    let rcEncKey = encodeActivityKeyForURL(transfer.key);
    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode,
        parentPage: routingPageType.inclusion,
        target: RENTAL_CAR_ALTERNATES,
        customParams: { rcKey: rcEncKey }
      })
    );
  }

  renderTransferPanels() {
    let {
      userDetails,
      transferRefs,
      transferCostingObj,
      isBooked,
      itineraryId,
      regionCode,
      history,
      makeReadOnly
    } = this.props;

    if (transferRefs !== undefined && transferCostingObj !== undefined) {
      return transferRefs.map(transferId => {
        let transfer =
          transferCostingObj.rentalCostingById &&
          transferCostingObj.rentalCostingById[transferId];

        // Handler for missed costing
        if (!transfer) {
          return (
            <NoCostingObjectErrorBlock failedFor="transfer" isLastRow={false} />
          );
        }

        const discountAppliedBatch = userDetails && userDetails.userType === 'ADMIN' && transfer.rateMatches && transfer.rateMatches.length > 0 ?
            <span className={'pill color-white bg-accent-4'}> Discount Applied </span> : null;

        return (
          <div key={transferId}>
            <article
              className="row-costed-item row zoomable"
              onClick={e => this.onDetailsClick(transfer.key, e)}
            >
              <div className="col-xs-9 col-sm-9 col-md-8 spacer">
                <div className="costed-item-head">
                  <div className="date-costed">
                    <span className="month">{transfer.pickupMonth}</span>
                    <span className="date">{transfer.pickupDate}</span>
                  </div>
                  <h5 className="no-margin semi-bold">
                    {transfer.pickup + ' to ' + transfer.drop}
                  </h5>
                  <span className="small dim">{transfer.carTitle}</span>
                </div>
                <div className="costed-item-details clearfix">
                  <div className="col-xs-5 col-sm-2 col-md-3 no-padding">
                    <div className="media-shell">
                      <figure className="sd">
                        <img src={transfer.image} alt={'transfer-icon'} />
                      </figure>
                    </div>
                  </div>
                  <div className="col-xs-7 col-sm-9 col-md-9">
                    <span className="fine-text fade color-grey">Includes:</span>
                    <div className="circle-list">
                      <ul className="fine-text fade color-grey">
                        <li>Car {transfer.carTitle}</li>
                        <li>Pickup from {transfer.pickup}</li>
                        <li>Drop at {transfer.drop}</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
                <li>
                  <span className="vehoicon-directions_car" /> 1{' '}
                  {transfer.carType}
                </li>
                <li>
                  <span className="vehoicon-ion-android-time" />
                  {transfer.duration} duration
                </li>
                <li>
                  <span className="vehoicon-people" /> {transfer.maxSeats}{' '}
                  passengers
                </li>
                <li>
                  <span className="vehoicon-luggage" /> {transfer.maxLuggage}{' '}
                  bags
                </li>
              </ul>
              <div className="col-xs-3 col-sm-3 col-md-2 spacer">
                <div className="action price-info text-center">
                  <span className="price block">
                    {transfer.totalCost ? (
                      <span>
                        <span className="WebRupee">Rs.</span>
                        {transfer.totalCost}
                      </span>
                    ) : null}
                    {userDetails &&
                    userDetails.loggedIn &&
                    userDetails.userType === 'ADMIN' &&
                    transfer.totalCost &&
                    !makeReadOnly ? (
                      <a
                        onClick={e => {
                          e.stopPropagation();
                          e.nativeEvent.stopImmediatePropagation();

                          let rcKey = encodeActivityKeyForURL(transfer.key);

                          history.push(
                            itineraryModalsRouteHelper({
                              itineraryId,
                              regionCode,
                              parentPage: routingPageType.inclusion,
                              target: RATE_MATCH_RENTAL_CAR,
                              customParams: {
                                rcKey,
                                called_from: 'RENTAL_CAR_PANEL'
                              }
                            })
                          );
                        }}
                      >
                        {' '}
                        <span className="vehoicon-mode_edit" />
                      </a>
                    ) : null}
                  </span>
                  {discountAppliedBatch}
                  { makeReadOnly ? null : <div
                    data-toggle={isBooked ? 'tooltip' : ''}
                    data-title="Flights already blocked for this trip"
                    data-placement="bottom"
                    data-container="body"
                  >
                    <button
                      className={`btn btn-sm btn-primary tracker-transchangebtn`}
                      disabled={isBooked}
                      id="change-transfer"
                      onClick={e => {
                        this.onChangeClick(transfer, e);
                      }}
                    >
                      Change
                    </button>
                  </div>}
                </div>
              </div>
            </article>
            <hr className="tear" />
          </div>
        );
      });
    } else {
      return null;
    }
  }

  render() {
    return (
      <section className="rc-transfers">{this.renderTransferPanels()}</section>
    );
  }
}

export default withRouter(RentalCarPanels);
