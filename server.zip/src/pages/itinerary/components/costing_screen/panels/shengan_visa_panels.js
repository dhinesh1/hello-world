import React from 'react';
import CallToAction from './visa_call_to_action';

const ShenganVisaPanels = props => {
  let visaCost = props.visaId ? props.totalCost : '0';
  return (
    <article className="row-costed-item row">
      <div className="col-xs-9 col-sm-9 col-md-10 spacer">
        <h5 className="no-margin">Visa Guidance fees for {props.country}</h5>
        <p className="costed-item-details meta-text">
          <span className="pill warning">Important</span>{' '}
          <span className="meta-text dim">
            {' '}
            Visa assistance is to enable the entire visa process such as booking appointments, 
            helping with documentation checklist however visa filling and other requirement has 
            to be borne by the customer
          </span>
        </p>
        {props.splitPricing ? (
          <table className="table small visa-table">
            <thead>
              <tr>
                <td>
                  <span className="fade bold">Traveller age</span>
                </td>
                <td>
                  <span className="fade bold">Visa cost</span>
                </td>
              </tr>
            </thead>
            <tbody>
              {props.schengenCostDetails.map((schengenCostDetail, i) => {
                return (
                  <tr key={i}>
                    <td>{schengenCostDetail.travellerAge}</td>
                    <td>{schengenCostDetail.cost}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : null}
      </div>
      <div className="col-xs-3 col-sm-3 col-md-2 spacer">
        <div className="action price-info text-center">
          {visaCost ? (
            <span className="price block">
              <span className="WebRupee">Rs.</span>
              {visaCost}
            </span>
          ) : null}
          {props.allowEditingOptions ? (
            <CallToAction
              isNoVisa={!props.required}
              isNZ={false}
              visaId={props.visaId}
              isBooked={props.isBooked}
              handleCallToActionClick={props.handleCallToActionClick}
            />
          ) : null}
        </div>
      </div>
    </article>
  );
};

export default ShenganVisaPanels;
