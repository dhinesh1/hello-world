import React, { Component } from 'react';
import Scroll from 'react-scroll';
import axios from 'axios';
import { AppConfig } from '../../../../app-config';
import Sticky from 'react-stickynode';
import SweetAlert from 'sweetalert-react';

import {
  isMobile,
  CostedItineraryScroll,
  openNewLink,
  checkIndexOf,
  getItineraryTitle
} from '../../../../helpers/utilsHelper';
import {
  trackEvent,
  EVENT_QUOTE_REQUESTED
} from '../../../../helpers/ML/EventsTracker';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  EMAIL_QUOTE
} from '../../../../helpers/routesHelper';
import { triggerSimpleAjax } from '../../../../helpers/httpHelper';

const Link = Scroll.Link;

const API_URL = AppConfig.api_url;
const SOCKET_URL = AppConfig.socket_url;
const USER_TYPE_AGENT = AppConfig.user_type_agent;
const USER_TYPE_ADMIN = AppConfig.user_type_admin;

export default class TabNavPanel extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showEmailQuoteAlert: false,
      emailQuoteResponse: ''
    };
  }

  renderPackageNavItem() {
    let { costedItinerary } = this.props;

    if (costedItinerary !== undefined) {
      let priceHiddenTitleClass = costedItinerary.totalFlightHotelCost
        ? ' fine-text dim '
        : 'main-para title-only';
      if (
        costedItinerary.allFlightCostingRefs.length > 0 ||
        costedItinerary.allHotelCostingRefs.length > 0
      ) {
        return (
          <li className="package-tab">
            <Link
              to={CostedItineraryScroll.FlightsandHotels}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-125}
              className=""
            >
              <span className="icon-package" />
              <div className="label">
                <span className={priceHiddenTitleClass}>Flights + Hotels</span>
                {costedItinerary.totalFlightHotelCost ? (
                  <span className="main-para bold">
                    <span className="WebRupee">Rs.</span>{' '}
                    {costedItinerary.totalFlightHotelCost}
                    {this.props.costedItinerary.itinerary.campaign ? (
                      <sup>*</sup>
                    ) : null}
                  </span>
                ) : null}
              </div>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderFlightsNavItem() {
    let { costedItinerary } = this.props;
    if (costedItinerary !== undefined) {
      let flightPrice = this.props.costedItinerary.flightCostings
        .totalFlightCost;
      if (
        costedItinerary.allFlightCostingRefs &&
        costedItinerary.allFlightCostingRefs.length > 0
      ) {
        let priceHiddenTitleClass = flightPrice
          ? ' fine-text dim '
          : 'main-para title-only';
        return (
          <li className="flight-tab">
            <Link
              to={CostedItineraryScroll.Flights}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-120}
              className=""
            >
              <span className="icon-flight" />
              <div className="label">
                <span className={priceHiddenTitleClass}>Flights</span>
                {flightPrice ? (
                  <span className="main-para bold">
                    <span className="WebRupee">Rs.</span> {flightPrice}
                  </span>
                ) : null}
              </div>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderHotelNavItem() {
    let { costedItinerary } = this.props;
    if (costedItinerary !== undefined) {
      let hotelPricing = this.props.costedItinerary.hotelCostings
        .totalHotelCost;
      if (
        costedItinerary.allHotelCostingRefs &&
        costedItinerary.allHotelCostingRefs.length > 0
      ) {
        let priceHiddenTitleClass = hotelPricing
          ? ' fine-text dim '
          : 'main-para title-only';
        return (
          <li className="hotel-tab">
            <Link
              to={CostedItineraryScroll.Hotels}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-125}
              className=""
            >
              <span className="icon-hotel" />
              <div className="label">
                <span className={priceHiddenTitleClass}>
                  {costedItinerary.itinerary.regionCode === 'mle'
                    ? 'Hotel & Transfers'
                    : 'Hotels'}
                </span>
                {hotelPricing ? (
                  <span className="main-para bold">
                    <span className="WebRupee">Rs.</span> {hotelPricing}
                  </span>
                ) : null}
              </div>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderActivityNavItem() {
    let { costedItinerary } = this.props;
    if (costedItinerary !== undefined) {
      let activityCost = this.props.costedItinerary.activityCostings
        .totalPublishedCost;
      if (
        costedItinerary.allActivityCostingRefs &&
        costedItinerary.allActivityCostingRefs.length > 0
      ) {
        let priceHiddenTitleClass = activityCost
          ? ' fine-text dim '
          : 'main-para title-only';
        return (
          <li className="activity-tab">
            <Link
              to={CostedItineraryScroll.Activities}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-125}
              className=""
            >
              <span className="icon-activity" />
              <div className="label">
                <span className={priceHiddenTitleClass}>Activities</span>
                {activityCost ? (
                  <span className="main-para bold">
                    <span className="WebRupee">Rs.</span> {activityCost}
                  </span>
                ) : null}
              </div>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderComboNavItem() {
    let { costedItinerary } = this.props;
    if (costedItinerary.allPassCostingRefs) {
      let comboPrice = this.props.costedItinerary.passCostings.totalPassCost;
      if (costedItinerary.allPassCostingRefs.length > 0) {
        let priceHiddenTitleClass = comboPrice
          ? ' fine-text dim '
          : 'main-para title-only';
        return (
          <li className="passes-tab">
            <Link
              to={CostedItineraryScroll.PassPanels}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-125}
              className=""
            >
              <span className="icon-combo" />
              <div className="label">
                <span className={priceHiddenTitleClass}>Passes</span>
                {comboPrice ? (
                  <span className="main-para bold">
                    <span className="WebRupee">Rs.</span> {comboPrice}
                  </span>
                ) : null}
              </div>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderTransferNavItem() {
    let costedItinerary = this.props.costedItinerary;
    if (costedItinerary !== undefined) {
      let transferCost = this.props.costedItinerary.transferCostings
        .combinedTransferCost;
      if (
        (costedItinerary.allTransferCostingRefs &&
          costedItinerary.allTransferCostingRefs.length > 0) ||
        (costedItinerary.allTrainCostingRefs &&
          costedItinerary.allTrainCostingRefs.length > 0) ||
        (costedItinerary.allFerryCostingRefs &&
          costedItinerary.allFerryCostingRefs.length > 0) ||
        (costedItinerary.allRentalCostingRefs &&
          costedItinerary.allRentalCostingRefs.length > 0)
      ) {
        let priceHiddenTitleClass = transferCost
          ? ' fine-text dim '
          : 'main-para title-only';
        return (
          <li className="transfer-tab">
            <Link
              to={CostedItineraryScroll.Transfers}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-125}
              className=""
            >
              <span className="icon-transfer" />
              <div className="label">
                <span className={priceHiddenTitleClass}>Transfers</span>
                {transferCost ? (
                  <span className="main-para bold">
                    <span className="WebRupee">Rs.</span> {transferCost}
                  </span>
                ) : null}
              </div>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderVisaNavItem() {
    let { costedItinerary } = this.props;
    if (costedItinerary !== undefined) {
      let visaCost = this.props.costedItinerary.visaCostings ? this.props.costedItinerary.visaCostings.totalVisaInsuranceCost : 0;
      if (
        costedItinerary.allVisaCostingRefs &&
        costedItinerary.allVisaCostingRefs.length > 0 &&
        costedItinerary.visaCostings != null
      ) {
        let priceHiddenTitle = visaCost ? (
          <span className="fine-text dim ">Visa & Insurance</span>
        ) : (
          <span className="main-para">
            Visa &<br /> Insurance
          </span>
        );
        return (
          <li className="visa-insurance-tab">
            <Link
              to={CostedItineraryScroll.VisaInsurance}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
              offset={-125}
              className=""
            >
              <span className="icon-visa" />
              <div className="label">
                {priceHiddenTitle}
                {visaCost ? (
                  <span className="main-para bold">
                    <span className="WebRupee">Rs.</span> {visaCost}
                  </span>
                ) : null}
              </div>
            </Link>
          </li>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  renderTotalNavItem() {
    let { costedItinerary } = this.props;
    if (costedItinerary !== undefined) {
      if (costedItinerary.itinerary.totalCost !== null) {
        return (
          <div data-scroll="#all-total-panels" className="total-tab-li">
            <div className="label text-center padding">
              <span className="fine-text dim block">Total cost</span>
              <span className="medium-heading">
                <span className="WebRupee">Rs.</span>{' '}
                {this.props.costedItinerary.itinerary.totalCost}
              </span>
            </div>
          </div>
        );
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  emailQuoteClickHandler(e) {
    e.preventDefault();
    let { userDetails, costedItinerary } = this.props;

    let _this = this,
      email_value = userDetails.email,
      itineraryId = costedItinerary.itinerary.itineraryId;

    if (!userDetails.loggedIn) {
      this.props.history.push(`/login`);
    } else {
      if (userDetails.userType === USER_TYPE_AGENT) {
        // cost/5a7ae26262ab877208c8c231/downloadItineraryPdf
        let url = `${API_URL}cost/${itineraryId}/downloadItineraryPdf`;

        let win = window.open(url, '_blank');
        win.focus();
      } else if (userDetails.userType === 'ADMIN') {
        // this.props.history.push(
        //   `${this.props.history.location.pathname}/email-quote`
        // );
        this.props.history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode: costedItinerary.itinerary.regionCode,
            parentPage: routingPageType.inclusion,
            target: EMAIL_QUOTE
          })
        );
      } else {
        trackEvent(EVENT_QUOTE_REQUESTED, {
          email: email_value,
          itinerary_id: itineraryId
        });
        // http://localhost:8080/veho/cost/{itineraryId}/emailQuote
        let url = `${API_URL}cost/${itineraryId}/emailQuote`;
        let post_data = {
          itineraryId: itineraryId,
          email: email_value
        };
        axios
          .post(url, post_data)
          .then(response => {
            this.setState({
              showEmailQuoteAlert: true,
              emailQuoteResponse: response.data.message
            });
          })
          .catch(error => {
            // console.log(error.response);
          });
      }
    }
  }

  /**
   * Used to trigger the call back action for the share pdf
   */
  sharePDF = (e) => {
    e && e.preventDefault();
    const { costedItinerary = { itinerary: {} } } = this.props;
    const itineraryId = costedItinerary.itinerary.itineraryId;
    const title = getItineraryTitle(costedItinerary);
    let phoneNumber = '';
    const performAction = (number) => {
      const href = `https://wa.me/${number}?text=Unwrap your customized itinerary ${title ? `for ${title}` : ''}
            ${SOCKET_URL}cost/${itineraryId}/createpdf/v2`;
      openNewLink(href);
    }
    /**
     * To get the user details for getting the used mobile number
     */
    new Promise((res) => {
      let url = `${API_URL}itinerary/${itineraryId}/user`;
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          if (response.status === "SUCCESS") {
            let { mobileNumber, countryPhoneCode } = response.data;
            countryPhoneCode = checkIndexOf(countryPhoneCode, ['+'], -1) ?
              countryPhoneCode.slice(1, countryPhoneCode.length) : countryPhoneCode;
            phoneNumber = `${countryPhoneCode}${mobileNumber}`;
          }
          performAction(phoneNumber);
          res(response.data);
        },
        error => {
          performAction(phoneNumber);
          res(error);
        }
      );
    });
  }

  render() {
    if (this.props.purpose === 'desktop') {
      let { costedItinerary, userDetails } = this.props;

      let itineraryId = costedItinerary.itinerary.itineraryId;
      let packageRate =
        (costedItinerary.costingConfiguration &&
          costedItinerary.costingConfiguration.packageRate) ||
        false;
      return (
        <div
          className="col-md-2 hidden-sm hidden-xs"
          id="floating-menu-container"
        >
          <SweetAlert
            show={this.state.showEmailQuoteAlert}
            title="Mail sent!"
            text={this.state.emailQuoteResponse}
            animation="pop"
            onConfirm={() => this.setState({ showEmailQuoteAlert: false })}
          />

          <Sticky
            enabled={!isMobile()}
            top={124}
            bottomBoundary="#CostingPanelFilter"
          >
            <div className="left-floating-menu">
              <ul>
                {packageRate ? this.renderPackageNavItem() : null}
                {packageRate ? null : this.renderFlightsNavItem()}
                {packageRate ? null : this.renderHotelNavItem()}
                {this.renderActivityNavItem()}
                {costedItinerary.itinerary &&
                costedItinerary.itinerary.regionCode === 'mle'
                  ? null
                  : this.renderTransferNavItem()}
                {this.renderComboNavItem()}
                {
                userDetails &&
                userDetails.userType !== USER_TYPE_AGENT
                  ? this.renderVisaNavItem()
                  : null}
              </ul>

              {userDetails && userDetails.userType === USER_TYPE_AGENT
                ? null
                : this.renderTotalNavItem()}

              {userDetails &&
              userDetails.loggedIn &&
              userDetails.userType === USER_TYPE_AGENT ? (
                <div className="email-quote-li mbottom-large text-center">
                  <button
                    onClick={e => this.emailQuoteClickHandler(e)}
                    style={{ whiteSpace: 'pre-wrap' }}
                    className="btn btn-xs btn-outline btn-default email-quote-desktop-ga"
                  >
                    Download as PDF
                  </button>
                </div>
              ) : (
                <div className="email-quote-li mbottom-large text-center">
                  <button
                    onClick={e => this.emailQuoteClickHandler(e)}
                    className="btn btn-xs btn-outline btn-default email-quote-desktop-ga"
                  >
                    Get this quote by email
                  </button>
                </div>
              )}

              {userDetails &&
              userDetails.loggedIn &&
              userDetails.userType === USER_TYPE_ADMIN ? (
                <div className="email-quote-li mbottom-large text-center">
                  <a
                    href=' '
                    className="btn btn-primary btn-default"
                    target={'_blank'}
                    onClick={this.sharePDF}
                  >
                    <i className={'vehoicon-whatsapp'} /> Share PDF
                  </a>
                </div>
              ) : null}
            </div>
          </Sticky>
        </div>
      );
    }
  }
}
