import React, { Component } from 'react';
import { getAirlineLogo } from '../../../../../helpers/utilsHelper';
import SmartImage from '../../../../../common_components/Image/smart_image';

export default class SingleFlightTrip extends Component {
  constructor(props) {
    super(props);

    this.getConnectionDurationAndStopsCount = this.getConnectionDurationAndStopsCount.bind(
      this
    );
  }

  populateAirportCodes(tripDetails) {
    let trip = tripDetails;
    let noOfLayovers = trip.routes.length - 1;
    return trip.routes.map((route, inx) => {
      if (inx === 0)
        return (
          <span key={Math.random()}>
            <span
              className="inline-block faded-underline"
              data-placement="top"
              data-toggle="tooltip"
              data-title={route.departureCity}
            >
              {' '}
              {route.departureAirportCode}{' '}
            </span>&nbsp;→&nbsp;
            <span
              className="inline-block faded-underline"
              data-placement="top"
              data-toggle="tooltip"
              data-title={
                noOfLayovers === 1
                  ? this.getLayoverText(route)
                  : route.arrivalCity
              }
            >
              {' '}
              {route.arrivalAirportCode}
            </span>
          </span>
        );
      else
        return (
          <span key={Math.random()}>
            &nbsp;→&nbsp;
            <span
              className="inline-block faded-underline"
              data-placement="top"
              data-toggle="tooltip"
              data-title={route.arrivalCity}
            >
              {' '}
              {route.arrivalAirportCode}
            </span>
          </span>
        );
    });
  }

  getConnectionDurationAndStopsCount(duration, r) {
    let stops = '';
    if (r.length - 1 === 0) stops = 'Direct';
    else if (r.length - 1 === 1) stops = `${r.length - 1} stop`;
    else stops = `${r.length - 1} stops`;

    let durHours = Math.floor(duration / 60);
    let durMinutes = duration % 60;

    if (durHours !== 0)
      return { stops: stops, duration: `${durHours}h ${durMinutes}m` };
    else return { stops: stops, duration: `${durMinutes}m` };
  }

  getLayoverText(route) {
    let du_text = this.getConnectionDurationAndStopsCount(
      route.connectionDuration,
      []
    ).duration;
    return du_text + ' layover in ' + route.arrivalCity;
  }

  renderTripList(trips, tripRefs) {
    return tripRefs.map(tripId => {
      let trip = trips[tripId];
      let lastRoute = trip.routes.length - 1;
      let divider_line = '';
      if (tripRefs.indexOf(tripId) + 1 !== tripRefs.length) {
        divider_line = <hr className="invisible" />;
      }

      const airlineImg = getAirlineLogo(this.props.airlineCode);

      return (
        <div key={tripId}>
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{trip.mon}</span>
              <span className="date">{trip.day}</span>
            </div>
            <h5 className="no-margin semi-bold">
              {trip.routes[0].departureCity} —{' '}
              {trip.routes[lastRoute].arrivalCity}
            </h5>
            <span className="small dim">
              {trip.routes[0].carrierName}, {trip.routes[lastRoute].carrierName}
            </span>
          </div>
          <div className="costed-item-details clearfix">
            <div className="col-xs-9 col-sm-9 col-md-9 no-padding">
              <div className="hidden-xs col-sm-6 col-md-6 no-padding">
                <time className="block">
                  {trip.routes[0].departureTime.substring(0, 5)}
                </time>
                <span className="meta-text color-grey single-line-text">
                  {trip.routes[0].departureAirportCode},{' '}
                  {trip.routes[0].departureCity}
                </span>
                <a className="meta-text single-line-text dim secondary-link">
                  {this.populateAirportCodes(trip)}
                </a>
              </div>
              <div className="hidden-xs col-sm-6 col-md-6">
                <time className="block">
                  {trip.routes[lastRoute].arrivalTime.substring(0, 5)}
                  {trip.landSameDay ? null : (
                    <span className="meta-text dim">
                      &nbsp;{trip.landDay} {trip.landMon}
                    </span>
                  )}
                </time>
                <span className="meta-text color-grey single-line-text">
                  {trip.routes[lastRoute].arrivalAirportCode},{' '}
                  {trip.routes[lastRoute].arrivalCity}
                </span>
                <span className="meta-text single-line-text dim secondary-link mt-4">
                  {
                    this.getConnectionDurationAndStopsCount(
                      trip.duration,
                      trip.routes
                    ).duration
                  },{' '}
                  {
                    this.getConnectionDurationAndStopsCount(
                      trip.duration,
                      trip.routes
                    ).stops
                  }
                </span>
              </div>
              <div className="col-xs-12 hidden-sm hidden-md hidden-lg no-padding">
                <time className="block">
                  {trip.routes[0].departureTime.substring(0, 5)}—{trip.routes[
                    lastRoute
                  ].arrivalTime.substring(0, 5)}
                  {trip.landSameDay ? null : (
                    <span className="meta-text dim">
                      &nbsp;{trip.landDay} {trip.landMon}
                    </span>
                  )}
                </time>
                <span className="meta-text single-line-text dim">
                  {
                    this.getConnectionDurationAndStopsCount(
                      trip.duration,
                      trip.routes
                    ).duration
                  },{' '}
                  {
                    this.getConnectionDurationAndStopsCount(
                      trip.duration,
                      trip.routes
                    ).stops
                  }
                </span>
                <span className="meta-text single-line-text dim">
                  {this.populateAirportCodes(trip, true)}
                </span>
              </div>
            </div>
            <div className="col-xs-3 col-sm-2 col-md-3 no-padding">
              <div className="airline-logo-fit no-padding">
                <SmartImage
                  src={airlineImg.url}
                  alt={airlineImg.name}
                  defaultImage={airlineImg.default}
                />
              </div>
            </div>
          </div>
          {divider_line}
        </div>
      );
    });
  }

  render() {
    if (this.props.trips !== undefined) {
      return (
        <div className="col-xs-9 col-sm-9 col-md-8 spacer">
          {this.renderTripList(this.props.trips, this.props.tripRefs)}
        </div>
      );
    }
  }
}
