import React, { Component } from 'react';
import Scroll from 'react-scroll';

import FlightPanels from './panels/flight_panels';
import HotelPanels from './panels/hotel_panels';
import FlightHotelPanels from './panels/flight_plus_hotels';
import ActivityPanels from './panels/activity_panels';
import TransferPanels from './panels/transfer_panels';
import TrainPanels from './panels/train_panels';
import RentalCarPanels from './panels/rental_car_panels';
import FerryPanels from './panels/ferry_panels';
import ComboPanels from './panels/combo_panels';
import VisaPanels from './panels/visa_panels';
import InsurancePanels from './panels/insurance_panels';
import TotalPanel from './panels/total_panel';
import ItineraryFooterTrustCosted from './panels/itinerary_footer_trust_costed';
import { CostedItineraryScroll } from '../../../../helpers/utilsHelper';
import { AppConfig } from '../../../../app-config';
const USER_TYPE_AGENT = AppConfig.user_type_agent;
const Element = Scroll.Element;

export default class CostingPanelsContainer extends Component {
  constructor(props) {
    super(props);

    this.getCombinedTransferLength = this.getCombinedTransferLength.bind(this);
  }

  renderFlights() {
    if (
      this.props.costedItinerary.allFlightCostingRefs &&
      this.props.costedItinerary.allFlightCostingRefs.length > 0
    ) {
      return (
        <Element name={CostedItineraryScroll.Flights}>
          <FlightPanels
            packageRate={false}
            userDetails={this.props.userDetails}
            flightRefs={this.props.costedItinerary.allFlightCostingRefs}
            flightCostingObj={this.props.costedItinerary.flightCostings}
            showThisModal={this.props.showThisModal}
            costedItinerary={this.props.costedItinerary}
            flightsBlocked={this.props.costedItinerary.itinerary.flightsBlocked}
            isBooked={
              this.props.costedItinerary.itinerary.booking ||
              this.props.costedItinerary.itinerary.frozen
            }
            makeReadOnly={this.props.makeReadOnly}
          />
        </Element>
      );
    } else {
      return null;
    }
  }

  renderHotels() {
    if (
      this.props.costedItinerary.allHotelCostingRefs &&
      this.props.costedItinerary.allHotelCostingRefs.length > 0
    ) {
      return (
        <Element name={CostedItineraryScroll.Hotels}>
          <HotelPanels
            packageRate={false}
            userDetails={this.props.userDetails}
            isBooked={
              this.props.costedItinerary.itinerary.booking ||
              this.props.costedItinerary.itinerary.frozen
            }
            showThisModal={this.props.showThisModal}
            costedItinerary={this.props.costedItinerary}
            itineraryDetail={this.props.costedItinerary.itinerary}
            totalDiff={this.props.costedItinerary.totalDiff}
            hotelRefs={this.props.costedItinerary.allHotelCostingRefs}
            hotelCostingObj={this.props.costedItinerary.hotelCostings}
            hotelGuestConfiguration={
              this.props.costedItinerary.costingConfiguration
                .hotelGuestRoomConfigurations
            }
            itineraryId={this.props.costedItinerary.itinerary.itineraryId}
            makeReadOnly={this.props.makeReadOnly}
          />
        </Element>
      );
    } else {
      return null;
    }
  }

  renderFlightsPlusHotels() {
    if (this.props.costedItinerary.costingConfiguration.packageRate) {
      return (
        <Element name={CostedItineraryScroll.FlightHotelPanels}>
          <section id="all-flight-hotel-panels">
            <FlightHotelPanels
              {...this.props}
              userDetails={this.props.userDetails}
              totalPackageCost={this.props.costedItinerary.totalFlightHotelCost}
              splitPricing={this.props.costedItinerary.itinerary.splitPricing}
              makeReadOnly={this.props.makeReadOnly}
            />
          </section>
        </Element>
      );
    } else {
      return null;
    }
  }

  renderActivities() {
    if (
      this.props.costedItinerary.allActivityCostingRefs &&
      this.props.costedItinerary.allActivityCostingRefs.length > 0
    ) {
      return (
        <Element name={CostedItineraryScroll.Activities}>
          <ActivityPanels
            showThisModal={this.props.showThisModal}
            userDetails={this.props.userDetails}
            getAlternateActivites={this.props.getAlternateActivites}
            itineraryId={this.props.itineraryDetail.itineraryId}
            regionCode={this.props.itineraryDetail.regionCode}
            allSlot={this.props.costedItinerary.iterSlotByKey}
            allDays={this.props.costedItinerary.iterDayByKey}
            allCities={this.props.costedItinerary.iterCityByKey}
            activityRefs={this.props.costedItinerary.allActivityCostingRefs}
            activityObjs={this.props.costedItinerary.activityById}
            isBooked={
              this.props.costedItinerary.itinerary.booking ||
              this.props.costedItinerary.itinerary.frozen
            }
            activityCostingObj={this.props.costedItinerary.activityCostings}
            citiesById={this.props.costedItinerary.cityById}
            splitPricing={this.props.costedItinerary.itinerary.splitPricing}
            makeReadOnly={this.props.makeReadOnly}
          />
        </Element>
      );
    } else {
      return null;
    }
  }

  getCombinedTransferLength() {
    const {
      allTransferCostingRefs,
      allTrainCostingRefs,
      allRentalCostingRefs,
      allFerryCostingRefs
    } = this.props.costedItinerary;
    return (
      (allTransferCostingRefs || []).length +
      (allTrainCostingRefs || []).length +
      (allRentalCostingRefs || []).length +
      (allFerryCostingRefs || []).length
    );
  }

  renderTransfers() {
    const {costedItinerary = {}, userDetails, changeTransferType, child_count, adult_count, makeReadOnly } = this.props;
    if (
      costedItinerary.allTransferCostingRefs &&
      costedItinerary.allTransferCostingRefs.length > 0
    ) {
      return (
        <TransferPanels
          changeTransferType={changeTransferType}
          itineraryId={costedItinerary.itinerary.itineraryId}
          regionCode={costedItinerary.itinerary.regionCode}
          isBooked={
            costedItinerary.itinerary.booking ||
            costedItinerary.itinerary.frozen
          }
          userDetails={userDetails}
          transferRefs={costedItinerary.allTransferCostingRefs}
          child_count={child_count}
          adult_count={adult_count}
          transferCostingObj={costedItinerary.transferCostings}
          makeReadOnly={makeReadOnly}
        />
      );
    } else {
      return null;
    }
  }

  renderTrains() {
    const {costedItinerary = {}, userDetails, makeReadOnly } = this.props;
    if (
      costedItinerary.allTrainCostingRefs &&
      costedItinerary.allTrainCostingRefs.length > 0
    ) {
      return (
        <TrainPanels
          isBooked={
            costedItinerary.itinerary.booking ||
            costedItinerary.itinerary.frozen
          }
          userDetails={userDetails}
          trainRefs={costedItinerary.allTrainCostingRefs}
          trainCostingObj={costedItinerary.trainCostings}
          itineraryId={costedItinerary.itinerary.itineraryId}
          regionCode={costedItinerary.itinerary.regionCode}
          makeReadOnly={makeReadOnly}
        />
      );
    } else {
      return null;
    }
  }

  renderRentalCars() {
    const { costedItinerary = {}, userDetails, makeReadOnly } = this.props;
    if (
      costedItinerary.allRentalCostingRefs &&
      costedItinerary.allRentalCostingRefs.length > 0
    ) {
      return (
        <RentalCarPanels
          isBooked={
            costedItinerary.itinerary.booking ||
            costedItinerary.itinerary.frozen
          }
          userDetails={userDetails}
          itineraryId={costedItinerary.itinerary.itineraryId}
          regionCode={costedItinerary.itinerary.regionCode}
          transferRefs={costedItinerary.allRentalCostingRefs}
          transferCostingObj={costedItinerary.rentalCarCostings}
          makeReadOnly={makeReadOnly}
        />
      );
    } else {
      return null;
    }
  }

  renderFerries() {
    const { costedItinerary = {}, userDetails, makeReadOnly } = this.props;
    if (
      costedItinerary &&
      costedItinerary.allFerryCostingRefs &&
      costedItinerary.allFerryCostingRefs.length > 0
    ) {
      return (
        <FerryPanels
          userDetails={userDetails}
          isBooked={
            costedItinerary.itinerary.booking ||
            costedItinerary.itinerary.frozen
          }
          itineraryId={costedItinerary.itinerary.itineraryId}
          regionCode={costedItinerary.itinerary.regionCode}
          ferryRefs={costedItinerary.allFerryCostingRefs}
          ferryCostingObj={costedItinerary.ferryCostings}
          makeReadOnly={makeReadOnly}
        />
      );
    } else {
      return null;
    }
  }

  renderCombos() {
    if (this.props.costedItinerary.passCostings) {
      return (
        <ComboPanels
          allSlot={this.props.costedItinerary.iterSlotByKey}
          allDays={this.props.costedItinerary.iterDayByKey}
          passCostings={this.props.costedItinerary.passCostings}
          costedItinerary={this.props.costedItinerary}
          splitPrice={this.props.costedItinerary.itinerary.splitPricing}
          makeReadOnly={this.props.makeReadOnly}
        />
      );
    } else {
      return null;
    }
  }

  renderVisas() {
    return (
      <VisaPanels
        allowEditingOptions={true}
        itinerary={this.props.costedItinerary}
        isBooked={
          this.props.costedItinerary.itinerary.booking ||
          this.props.costedItinerary.itinerary.frozen ||
          this.props.makeReadOnly
        }
        userDetails={this.props.userDetails}
        itineraryId={this.props.costedItinerary.itinerary.itineraryId}
        visaRefs={this.props.costedItinerary.allVisaCostingRefs}
        visaCostings={this.props.costedItinerary.visaCostings}
        splitPricing={this.props.costedItinerary.itinerary.splitPricing}
        makeReadOnly={this.props.makeReadOnly}
      />
    );
  }

  renderInsurance() {
    const {
      costedItinerary,
      adult_count,
      child_count,
      userDetails,
      makeReadOnly
    } = this.props;
    const { insuranceCosting, itinerary } = costedItinerary;
    return (insuranceCosting && insuranceCosting.insuranceCostingById) && (
      <InsurancePanels
        allowEditingOptions={true}
        isBooked={
          itinerary.booking || itinerary.frozen || makeReadOnly
        }
        makeReadOnly={makeReadOnly}
        userDetails={userDetails}
        itineraryId={itinerary.itineraryId}
        insuranceCosting={insuranceCosting}
        regionCode={itinerary.regionCode}
        adult_count={adult_count}
        child_count={child_count}
        splitPricing={itinerary.splitPricing}
      />
    );
  }

  renderTotalPanel() {
    return (
      <TotalPanel
        isBooked={
          this.props.costedItinerary.itinerary.booking ||
          this.props.costedItinerary.itinerary.frozen
        }
        updatePackageRateState={this.props.updatePackageRateState}
        itineraryId={this.props.costedItinerary.itinerary.itineraryId}
        summary={this.props.costedItinerary.summary}
        userDetails={this.props.userDetails}
        itinerary={this.props.costedItinerary.itinerary}
        itineraryMinPayableAmount={
          this.props.costedItinerary.recommendedAmountToBePaid
        }
        costingConfiguration={this.props.costedItinerary.costingConfiguration}
        makeReadOnly={this.props.makeReadOnly}
      />
    );
  }

  render() {
    let { costedItinerary, userDetails, makeReadOnly } = this.props;
    const { insuranceCosting, allVisaCostingRefs } = costedItinerary;

    let packageRate = costedItinerary.costingConfiguration.packageRate;
    let splitPricing = !costedItinerary.itinerary.splitPricing;

    return (
      <div
        className="col-xs-12 col-sm-12 col-md-10 costing-panels no-padding"
        id="CostingPanelFilter"
      >
        {packageRate && splitPricing ? this.renderFlightsPlusHotels() : null}
        {!(packageRate && splitPricing) ? this.renderFlights() : null}
        {!(packageRate && splitPricing) ? this.renderHotels() : null}

        {this.renderActivities()}

        {this.getCombinedTransferLength() > 0 ? (
          <Element name={CostedItineraryScroll.Transfers}>
            <section className="all-transfers">
              <div className="cost-container">
                <div className="cost-section-head">
                  <h3 className="mute">Transfers</h3>
                </div>
                {this.renderTransfers()}
                {this.renderTrains()}
                {this.renderRentalCars()}
                {this.renderFerries()}
              </div>
            </section>
          </Element>
        ) : null}

        {this.renderCombos()}

        {!insuranceCosting && (!allVisaCostingRefs || (allVisaCostingRefs && !allVisaCostingRefs.length)) ? null : userDetails &&
        userDetails.userType !== 'AGENT' &&
        !costedItinerary.itinerary.agent ? (
          <Element name={CostedItineraryScroll.VisaInsurance}>
            <section className="visa-insurance" id="all-visa-panels">
              <div className="cost-container">
                <div className="cost-section-head">
                  <h3 className="mute">Visa & Insurance</h3>
                </div>
                {this.renderVisas()}
                {this.renderInsurance()}
              </div>
            </section>
          </Element>
        ) : null}

        {this.renderTotalPanel()}

        {!costedItinerary.itinerary.booking && !makeReadOnly? (
          <ItineraryFooterTrustCosted
            isBooked={
              costedItinerary.itinerary.booking ||
              costedItinerary.itinerary.frozen
            }
            itineraryId={costedItinerary.itinerary.itineraryId}
            summary={costedItinerary.summary}
            userDetails={this.props.userDetails}
            collapse_prefix="cs"
            talkToExportTrackerClass={
              'tracker-talk-to-an-expert-costing-screen'
            }
            itinerary={costedItinerary.itinerary}
            itineraryMinPayableAmount={
              costedItinerary.recommendedAmountToBePaid
            }
            {...this.props}
            costingConfiguration={costedItinerary.costingConfiguration}
          />
        ) : null}
      </div>
    );
  }
}
