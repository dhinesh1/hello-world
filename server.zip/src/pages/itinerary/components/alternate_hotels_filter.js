import React, { Component } from 'react';
import _ from 'lodash';
import { Range } from 'rc-slider';

import { Sparklines, SparklinesBars } from 'react-sparklines';
import { FormGroup } from 'react-bootstrap';
import StarRating from '../../../common_components/StarRating';

export default class AlternateHotelsFilter extends Component {
  constructor(props) {
    super(props);

    this.state = {};
    this.state.appliedfilters = {
      name: '',
      types: [],
      starRatings: [],
      tripAdvisorRatings: [],
      amenities: [],
      ojFilter: true,
      minPrice: props.minPrice,
      maxPrice: props.maxPrice,
      packageRate: false,
      searchTerm: ''
    };
    this.state.selectedMinPrice = props.minPrice;
    this.state.selectedMaxPrice = props.maxPrice;

    this.handlePriceRangeSliderChange = this.handlePriceRangeSliderChange.bind(
      this
    );
    this.handleFilterUpdate = this.handleFilterUpdate.bind(this);
    this.handleEnteronSearch = this.handleEnteronSearch.bind(this);
    this.onChangeSearchTerm = this.onChangeSearchTerm.bind(this);
  }

  handleEnteronSearch(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      this.handleFilterUpdate();
    }
  }

  returnSelectedValues(inputName) {
    let input = document.getElementsByName(inputName);
    let selectedValues = [];

    for (let i = 0; i < input.length; ++i) {
      if (input[i].checked) selectedValues.push(input[i].value);
    }

    return selectedValues;
  }

  componentWillReceiveProps(nextProps) {
    let newState = this.state;
    newState.selectedMinPrice = nextProps.selectedMinPrice;
    newState.selectedMaxPrice = nextProps.selectedMaxPrice;
    this.setState(newState);
  }

  componentDidUpdate() {
    // $(document).ready(() => {
    //   $('#hotel-oj-filter').prop('checked', true);
    // });
    // $('.hotel-search-text').click();
  }

  componentWillMount() {
    let _this = this;
    this.handleSearchDebounced = _.debounce(() => {
      _this.handleFilterUpdate();
    }, 400);
  }

  onChangeSearchTerm(term) {
    this.setState({ searchTerm: term }, () => {
      this.handleSearchDebounced();
    });
  }

  handleFilterUpdate(e) {
    let { currentPickHotel } = this.props;
    let is_islandHopper =
      currentPickHotel && currentPickHotel.sourceProvider === 'ISLANDHOPPER';

    let is_refundable = false;
    if (document.querySelector('#hotel-refundable-filter')) {
      is_refundable = document.querySelector('#hotel-refundable-filter')
        .checked;
    }

    let is_non_refundable = false;
    if (document.querySelector('#hotel-non-refundable-filter')) {
      is_non_refundable = document.querySelector('#hotel-non-refundable-filter')
        .checked;
    }

    let refundable =
      (is_refundable && is_non_refundable) ||
      (!is_refundable && !is_non_refundable)
        ? null
        : is_refundable && !is_non_refundable;

    const selectedFilters = {
      name: this.state.searchTerm,
      types: this.returnSelectedValues('types'),
      starRatings: this.returnSelectedValues('starRatings'),
      tripAdvisorRatings: this.returnSelectedValues('tripAdvisorRatings'),
      amenities: this.returnSelectedValues('amenities'),
      minPrice: this.state.selectedMinPrice,
      maxPrice: this.state.selectedMaxPrice,
      refundable: refundable
    };

    if (document.querySelector('#pyt-recommended-filter')) {
      selectedFilters.pytRecommended = document.querySelector(
        '#pyt-recommended-filter'
      ).checked
        ? true
        : null;
    }

    if (document.querySelector('#package-rate-checkbox')) {
      selectedFilters.packageRate = document.querySelector(
        '#package-rate-checkbox'
      ).checked;
    }

    if (document.querySelector('#offer-available-filter')) {
      selectedFilters.offerAvailable = document.querySelector(
        '#offer-available-filter'
      ).checked;
    }

    if (is_islandHopper) {
      selectedFilters.seaPlane = null;
      selectedFilters.speedBoat = null;
      selectedFilters.waterVilla = null;
      selectedFilters.offerAvailable = null;

      if (document.querySelector('#sea-plane-filter')) {
        selectedFilters.seaPlane = document.querySelector('#sea-plane-filter')
          .checked
          ? true
          : null;
      }

      if (document.querySelector('#speed-boat-filter')) {
        selectedFilters.speedBoat = document.querySelector('#speed-boat-filter')
          .checked
          ? true
          : null;
      }

      if (document.querySelector('#water-villa-filter')) {
        selectedFilters.waterVilla = document.querySelector(
          '#water-villa-filter'
        ).checked
          ? true
          : null;
      }

      if (document.querySelector('#offer-available-filter')) {
        selectedFilters.offerAvailable = document.querySelector(
          '#offer-available-filter'
        ).checked
          ? true
          : null;
      }
    }

    this.props.applyFilters(selectedFilters, 'FILTER_UPDATE_BUTTON');
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (
      this.state.selectedMinPrice !== nextState.selectedMinPrice ||
      this.state.selectedMaxPrice !== nextState.selectedMaxPrice
    ) {
      return true;
    }
    return false;
  }

  handlePriceRangeSliderChange(value) {
    let tempFilterObj = {};
    _.assign(tempFilterObj, this.state);
    tempFilterObj.selectedMinPrice = value[0];
    tempFilterObj.selectedMaxPrice = value[1];
    this.setState(tempFilterObj);
    // $('#hotel-fltr-min-price').text(value[0]);
    // $('#hotel-fltr-max-price').text(value[1]);
  }

  populatePropertyTypesFilter(propertyTypes) {
    return propertyTypes.map((property, i) => {
      return (
        <div key={'populate_type_filter_' + i} className="clearfix">
          <label className="custom-options">
            <input
              type="checkbox"
              name="types"
              key={property.code}
              value={property.code}
              onChange={this.handleFilterUpdate}
            />
            <span> {property.name.toLowerCase()} </span>
            <i />
          </label>
        </div>
      );
    });
  }

  populateHotelStarRating() {
    let hardCodedStarRatings = ['3.0', '3.5', '4.0', '4.5', '5.0'];

    return (
      <div className="filter-grp tracker-hotels-starrating">
        {hardCodedStarRatings.map((star, inx) => (
          <div key={'star_filter_' + inx} className="clearfix">
            <label
              className="custom-options checkbox"
              key={'star_filter_' + inx}
            >
              <input
                type="checkbox"
                name="starRatings"
                value={star}
                onChange={this.handleFilterUpdate}
              />
              <StarRating
                rating={star}
                fillEmpty={false}
                parentClass={'stars'}
                parentElement={'span'}
              />
              <span className="normal">{star.replace('.0', '')} </span>
              <i />
            </label>
          </div>
        ))}
      </div>
    );
  }

  populateHotelAmenitiesFilter(HotelAmenities) {
    return (
      HotelAmenities &&
      HotelAmenities.map((amenity, inx) => {
        let icon = 'vehoicon-wifi medium text-dark-grey';
        if (amenity.name === 'AIR CONDITIONING') {
          icon = 'vehoicon-compare medium text-dark-grey';
        } else if (amenity.name === 'FREE WIFI') {
          icon = 'vehoicon-wifi medium text-dark-grey';
        } else {
          icon = 'vehoicon-restaurant_menu medium text-dark-grey';
        }

        return (
          <div key={'hotel_amen_' + inx} className="clearfix">
            <label className="custom-options">
              <input
                type="checkbox"
                key={amenity.code}
                name="amenities"
                value={amenity.code}
                onChange={this.handleFilterUpdate}
              />
              <span className={icon} />{' '}
              <span> {_.capitalize(amenity.name)} </span>
              <i />
            </label>
          </div>
        );
      })
    );
  }

  populatePackageRateFilter() {
    return (
      <div className="clearfix">
        <label className="custom-options">
          <input
            type="checkbox"
            key="package-rate"
            name="package-rate"
            id="package-rate-checkbox"
            onChange={this.handleFilterUpdate}
          />
          <span> Package Rate </span>
          <i />
        </label>
      </div>
    );
  }

  render() {
    let { user_details, currentPickHotel } = this.props;
    let is_islandHopper =
      currentPickHotel && currentPickHotel.sourceProvider === 'ISLANDHOPPER';
    const isAdmin =
      user_details &&
      user_details.loggedIn &&
      user_details.userType === 'ADMIN';

    let priceRangeFilter =
      !isAdmin && !this.props.splitPricing ? null : (
        <div className="filter-grp">
          <FormGroup>
            <h6 className="fade">Total price</h6>
            <Sparklines
              data={this.props.sparkLinesData}
              height={30}
              width={262}
              style={{ marginBottom: '-10px' }}
            >
              <SparklinesBars
                style={{ fill: '#767676', fillOpacity: '0.5', stroke: 'none' }}
              />
            </Sparklines>

            <Range
              min={this.props.minPrice}
              max={this.props.maxPrice}
              defaultValue={[this.props.minPrice, this.props.maxPrice]}
              range={true}
              allowCross={false}
              name="price"
              onChange={this.handlePriceRangeSliderChange}
              onAfterChange={this.handleFilterUpdate}
            />
            <div>
              <span className="slider-price">
                <span className={'WebRupee'}>Rs.</span>{' '}
                <span id="hotel-fltr-min-price" className="medium-bold">
                  {this.state.selectedMinPrice}
                </span>
              </span>
              <span className="pull-right slider-price">
                <span className={'WebRupee'}>Rs.</span>{' '}
                <span className="medium-bold" id="hotel-fltr-max-price">
                  {this.state.selectedMaxPrice}
                </span>
              </span>
            </div>
          </FormGroup>
        </div>
      );

    if (this.props.filterOptions !== undefined) {
      const { campaign, regionCode } = this.props;

      return (
        <div className="modal-alternate-filters full-hgt">
          <div className="modal-filter-header xs-hdr">
            <div className="header-bar">
              <button
                id="alternate-activities-hide-filter-btn"
                onClick={this.props.handleFilterCloseIconClick}
                type="button"
                className={'close filter-toggle clear-box-shadow visible-xs'}
              >
                <span className="vehoicon-previous" aria-hidden="true" />
              </button>
              {/*<span className="text-uppercase kern-more bolder fade">Filters</span>*/}
            </div>
          </div>
          <div className="filter-content tracker-hotels-filter xs-midcontent">
            <TextSearchFilter
              searchTerm={this.state.searchTerm}
              onChangeSearchTerm={this.onChangeSearchTerm}
            />
            <hr className="mute" />
            {!is_islandHopper &&
            (!campaign || (campaign && regionCode !== 'mle')) ? (
              <div className="tracker-hotels-facilities">
                <FormGroup>
                  <h6 className="fade">Hotel facilities</h6>
                  <div className="filter-grp">
                    {this.props.filterOptions.amenities &&
                      this.populateHotelAmenitiesFilter(
                        this.props.filterOptions.amenities
                      )}

                    <div className="clearfix">
                      <label className="custom-options">
                        <input
                          type="checkbox"
                          key={'refundable'}
                          id="hotel-refundable-filter"
                          name="refundable"
                          value={true}
                          onChange={this.handleFilterUpdate}
                        />
                        <span
                          className={
                            'vehoicon-refundable medium text-dark-grey'
                          }
                        />
                        <span> Refundable </span>
                        <i />
                      </label>
                    </div>

                    <div className="clearfix">
                      <label className="custom-options">
                        <input
                          type="checkbox"
                          key={'non_refundable'}
                          id="hotel-non-refundable-filter"
                          name="non-refundable"
                          value={false}
                          onChange={this.handleFilterUpdate}
                        />
                        <span
                          className={
                            'vehoicon-non-refundable medium text-dark-grey'
                          }
                        />
                        <span> Non-Refundable </span>
                        <i />
                      </label>
                    </div>
                  </div>
                </FormGroup>
                <hr className="mute" />
              </div>
            ) : null}

            {priceRangeFilter}
            {priceRangeFilter !== null ? <hr className="mute" /> : null}

            {this.props.filterOptions.showPytFilter || is_islandHopper ? (
              <div className="filter-grp tracker-pythotels">
                <div className="clearfix">
                  <label className="custom-options">
                    <input
                      type="checkbox"
                      key={'refundable'}
                      id="pyt-recommended-filter"
                      name="pytRecommended"
                      value={true}
                      onChange={this.handleFilterUpdate}
                    />
                    <span> Pickyourtrail Recommended </span>
                    <i />
                  </label>
                </div>
                <p className="dim small">
                  Our expert's pick for a hassle-free stay during your vacation
                </p>
              </div>
            ) : null}
            {this.props.filterOptions.showPytFilter || is_islandHopper ? (
              <hr className="mute" />
            ) : null}

            <h6 className="fade">Star rating</h6>
            {this.populateHotelStarRating(this.props.filterOptions.starRatings)}
            {(!campaign || (campaign && regionCode !== 'mle')) &&
            !is_islandHopper ? (
              <div>
                <hr className="mute" />
                <h6 className="fade">Type</h6>
                <div className="filter-grp tracker-hotels-type">
                  {this.populatePropertyTypesFilter(
                    this.props.filterOptions.types
                  )}
                </div>
              </div>
            ) : null}

            {is_islandHopper && regionCode !== 'sez' ? (
              <div>
                <hr className="mute" />
                <h6 className="fade">Transfer type</h6>
                <div className="filter-grp tracker-transfer-type">
                  <div className="clearfix">
                    <label className="custom-options">
                      <input
                        type="checkbox"
                        key={'sea-plane'}
                        id="sea-plane-filter"
                        name="seaPlane"
                        value={true}
                        onChange={this.handleFilterUpdate}
                      />
                      <span> Sea Plane </span>
                      <i />
                    </label>
                  </div>

                  <div className="clearfix">
                    <label className="custom-options">
                      <input
                        type="checkbox"
                        key={'speed-boat'}
                        id="speed-boat-filter"
                        name="speedBoat"
                        value={true}
                        onChange={this.handleFilterUpdate}
                      />
                      <span> Speed Boat </span>
                      <i />
                    </label>
                  </div>
                </div>
              </div>
            ) : null}

            {is_islandHopper ? (
              <div>
                <hr className="mute" />
                <h6 className="fade">Other filters</h6>
                <div className="filter-grp tracker-pythotels">
                  {regionCode !== 'sez' ? (
                    <div className="clearfix">
                      <label className="custom-options">
                        <input
                          type="checkbox"
                          key={'water-villa'}
                          id="water-villa-filter"
                          name="waterVilla"
                          value={true}
                          onChange={this.handleFilterUpdate}
                        />
                        <span> Water Villa </span>
                        <i />
                      </label>
                    </div>
                  ) : null}

                  <div className="clearfix">
                    <label className="custom-options">
                      <input
                        type="checkbox"
                        key={'offer-available'}
                        id="offer-available-filter"
                        name="offerAvailable"
                        value={true}
                        onChange={this.handleFilterUpdate}
                      />
                      <span> Offer Available </span>
                      <i />
                    </label>
                  </div>
                </div>
              </div>
            ) : null}

            {(!campaign || (campaign && regionCode !== 'mle')) &&
            !is_islandHopper &&
            isAdmin ? (
              <div className="filter-grp tracker-hotels-packrate">
                <hr className="mute" />
                {this.populatePackageRateFilter()}
              </div>
            ) : null}
          </div>
          <div className="xs-ftr visible-xs">
            <button
              onClick={this.props.handleFilterCloseIconClick}
              type="button"
              className="btn btn-primary filter-update-btn btn-block"
            >
              Update
            </button>
          </div>
        </div>
      );
    } else {
      return <div>Loading filters</div>;
    }
  }
}

const TextSearchFilter = props => (
  <div className="form-group search-filter tracker-hotels-searchfil">
    <span className="vehoicon-search" />
    <input
      type="text"
      autoFocus={true}
      autoComplete="off"
      name="name"
      value={props.searchTerm}
      onChange={e => props.onChangeSearchTerm(e.target.value)}
      placeholder="Search"
      id="formInlineName"
      className="search-icon form-control hotel-search-text"
    />
  </div>
);

const HotelFacilityFilter = props => (
  <div className="tracker-hotels-facilities">
    <FormGroup>
      <h6 className="fade">Hotel facilities</h6>
      <div className="filter-grp">
        {this.populateHotelAmenitiesFilter(this.props.filterOptions.amenities)}
        <div className="clearfix">
          <label className="custom-options">
            <input
              type="checkbox"
              key={'refundable'}
              id="hotel-refundable-filter"
              name="refundable"
              value={true}
              onChange={this.handleFilterUpdate}
            />
            <span className={'vehoicon-refundable medium text-dark-grey'} />
            <span> Refundable </span>
            <i />
          </label>
        </div>
        <div className="clearfix">
          <label className="custom-options">
            <input
              type="checkbox"
              key={'non_refundable'}
              id="hotel-non-refundable-filter"
              name="non-refundable"
              value={false}
              onChange={this.handleFilterUpdate}
            />
            <span className={'vehoicon-non-refundable medium text-dark-grey'} />
            <span> Non-Refundable </span>
            <i />
          </label>
        </div>
      </div>
    </FormGroup>
    <hr className="mute" />
  </div>
);
