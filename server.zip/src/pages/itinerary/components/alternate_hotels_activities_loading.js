import React, { Component } from 'react';
import ReactPlaceholder from 'react-placeholder';
import { RectShape } from 'react-placeholder/lib/placeholders';
import _ from 'lodash';

const DummyComponent = () => <div>Dummy</div>;

export default class AlternateHotelsActivitiesLoading extends Component {
  render() {
    let fliterContent = _.range(0, 6);

    return (
      <div
        className="modal-alternate-content"
        id="alternate-activities-content"
      >
        <div className="modal-row">
          <section className="change-data grid-list">
            {fliterContent.map(item => {
              return (
                <div
                  key={'loading_placeholder_' + item}
                  className="col-xs-12 col-sm-6 col-md-4"
                >
                  <article className="data-option-item">
                    <div className="data-option-item-wrapper">
                      <RectShape
                        color="transparent"
                        className="animated-background media-image"
                        style={{ width: '100%', height: '150px' }}
                        ready={this.props.loaderState}
                      >
                        <DummyComponent />
                      </RectShape>
                      <div className="data-option-details no-padding">
                        <h6 className="title">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={2}
                            ready={this.props.loaderState}
                          >
                            <DummyComponent />
                          </ReactPlaceholder>
                        </h6>
                        <div className="row spacer">
                          <div className="col-xs-8 col-md-8">
                            <span className="dim">
                              <ReactPlaceholder
                                color="transparent"
                                className="animated-background"
                                type="text"
                                rows={2}
                                ready={this.props.loaderState}
                              >
                                <DummyComponent />
                              </ReactPlaceholder>
                            </span>
                          </div>
                          <div className="col-xs-4 col-md-4">
                            <ReactPlaceholder
                              color="transparent"
                              className="animated-background"
                              type="text"
                              rows={2}
                              ready={this.props.loaderState}
                            >
                              <DummyComponent />
                            </ReactPlaceholder>
                          </div>
                        </div>
                      </div>
                    </div>
                  </article>
                </div>
              );
            })}
          </section>
        </div>
      </div>
    );
  }
}
