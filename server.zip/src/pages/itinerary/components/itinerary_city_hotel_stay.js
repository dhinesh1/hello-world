import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { encodeCostingKeyForURL } from '../../../helpers/utilsHelper';
import { itineraryModalsRouteHelper, HOTEL_DETAILS } from '../../../helpers/routesHelper';

class ItineraryHotelStay extends Component {
  constructor(props) {
    super(props);
    this.getHotelDetails = this.getHotelDetails.bind(this);
  }

  getHotelDetails(hotelDetails) {
    const { history, itineraryId, regionCode } = this.props;
    history.push(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode,
        target: HOTEL_DETAILS,
        customParams: {
          hotelKey: encodeCostingKeyForURL(hotelDetails.costingKey)
        }
      })
    );
  }

  render() {
    let hotelCosting = this.props.hotelCosting;

    if (!hotelCosting) {
      return (
        <div key={Math.random()} className="unit-row stay-at">
          <div className="column-meta day" />
          <div className="day-activities-wrapper">
            <div className="row row-main">
              <div className="col-xs-12 col-sm-12 time-slot stay clickable no-hover-color">
                <div className="stay-image-shell">
                  <span className="vehoicon-local_hotel" />
                </div>
                <p className="base bold">
                  <span type="pill" className="pill danger">
                    Error
                  </span>{' '}
                  <span className="spaced">
                    Hotels are currently not available for the given dates in
                    this city
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      );
    } else if (hotelCosting.status === 'SUCCESS') {
      return (
        <div
          key={hotelCosting.costingKey}
          className="unit-row stay-at"
          onClick={() => this.getHotelDetails(hotelCosting)}
        >
          <div className="column-meta day" />
          <div className="day-activities-wrapper">
            <div className="row row-main">
              <div className="col-xs-12 col-sm-12 time-slot stay clickable no-hover-color">
                <div className="stay-image-shell">
                  <span className="vehoicon-local_hotel" />
                </div>
                <p className="base bold">
                  <span>{hotelCosting.name}</span>
                  <span className="mini normal fade spaced">
                    (Stay from{' '}
                    {hotelCosting.checkInMonthDisplay +
                      ' ' +
                      hotelCosting.checkInDateDisplay +
                      '-' +
                      hotelCosting.checkOutMonthDisplay +
                      ' ' +
                      hotelCosting.checkOutDateDisplay}{' '}
                    {hotelCosting.finalPrice ? (
                      <span>
                        –{' '}
                        <span className="color-primary">
                          {' '}
                          <span className="WebRupee">Rs.</span>{' '}
                          {hotelCosting.finalPrice}
                        </span>{' '}
                      </span>
                    ) : (
                      ''
                    )})
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      );
    } else if (hotelCosting.status === 'USER_REMOVED') {
      return (
        <div key={Math.random()} className="unit-row stay-at">
          <div className="column-meta day" />
          <div className="day-activities-wrapper">
            <div className="row row-main">
              <div className="col-xs-12 col-sm-12 time-slot stay no-hover-color">
                <div className="stay-image-shell">
                  <span className="vehoicon-local_hotel" />
                </div>
                <p className="base bold">
                  <span type="pill" className="pill warning">
                    Alert
                  </span>{' '}
                  <span className="small">
                    You have removed stay options in this city.
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      return (
        <div key={Math.random()} className="unit-row stay-at">
          <div className="column-meta day" />
          <div className="day-activities-wrapper">
            <div className="row row-main">
              <div className="col-xs-12 col-sm-12 time-slot stay no-hover-color">
                <div className="stay-image-shell">
                  <span className="vehoicon-local_hotel" />
                </div>
                <p className="base bold">
                  <span className="pill color-white bg-accent-4">Error</span>{' '}
                  <span className="small">
                    Something went wrong while finding stay options in this
                    city.
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      );
    }
  }
}

export default withRouter(ItineraryHotelStay);
