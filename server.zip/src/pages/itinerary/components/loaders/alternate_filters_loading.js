import React, { Component } from 'react';
import ReactPlaceholder from 'react-placeholder';

const DummyComponent = () => <div>Dummy</div>;

const OneSinglePlaceholder = props => (
  <div className="row spacer-both">
    <div className="col-xs-12 v-spaced">
      <div className="col-xs-6 row">
        <ReactPlaceholder
          color="transparent"
          className="animated-background"
          type="text"
          rows={1}
          ready={props.loaderState}
        >
          <DummyComponent />
        </ReactPlaceholder>
      </div>
    </div>
    <div className="col-xs-12">
      <ReactPlaceholder
        color="transparent"
        className="animated-background"
        type="text"
        rows={2}
        ready={props.loaderState}
      >
        <DummyComponent />
      </ReactPlaceholder>
    </div>
  </div>
);

export default class AlternateFilterLoading extends Component {
  render() {
    return (
      <div className="modal-alternate-filters">
        <div
          className="filter-content double-spacer-bottom"
          id="alternate-flights-filter"
        >
          <OneSinglePlaceholder {...this.props} />
          <OneSinglePlaceholder {...this.props} />
          <OneSinglePlaceholder {...this.props} />
          <OneSinglePlaceholder {...this.props} />
          <OneSinglePlaceholder {...this.props} />

          <div className="row spacer-both">
            <div className="col-xs-12 v-spaced">
              <div className="col-xs-6 row">
                <ReactPlaceholder
                  color="transparent"
                  className="animated-background"
                  type="text"
                  rows={1}
                  ready={this.props.loaderState}
                >
                  <DummyComponent />
                </ReactPlaceholder>
              </div>
            </div>
            <div className="col-xs-12 v-spaced">
              <ReactPlaceholder
                color="transparent"
                className="animated-background"
                type="text"
                rows={2}
                ready={this.props.loaderState}
              >
                <DummyComponent />
              </ReactPlaceholder>
            </div>
            <div className="col-xs-12 v-spaced">
              <ReactPlaceholder
                color="transparent"
                className="animated-background"
                type="text"
                rows={2}
                ready={this.props.loaderState}
              >
                <DummyComponent />
              </ReactPlaceholder>
            </div>
            <div className="col-xs-12 v-spaced">
              <ReactPlaceholder
                color="transparent"
                className="animated-background"
                type="text"
                rows={2}
                ready={this.props.loaderState}
              >
                <DummyComponent />
              </ReactPlaceholder>
            </div>
            <div className="col-xs-12 v-spaced">
              <ReactPlaceholder
                color="transparent"
                className="animated-background"
                type="text"
                rows={2}
                ready={this.props.loaderState}
              >
                <DummyComponent />
              </ReactPlaceholder>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
