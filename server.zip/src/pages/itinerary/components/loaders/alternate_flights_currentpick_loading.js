import React, { Component } from 'react';
import ReactPlaceholder from 'react-placeholder';
import { RectShape } from 'react-placeholder/lib/placeholders';

export default class AlternateFlightsCurrentPickLoading extends Component {
  render() {
    return (
      <div className="panel panel-secondary current-pick-panel">
        <div className="panel-heading">
          <button
            type="button"
            className="close white no-padding margin-neg-4"
            aria-label="Close"
          >
            <span className="vehoicon-close" aria-hidden="true" />
          </button>
          <span className="oj-modal-title no-v-margin no-padding">
            Change Flight
          </span>
        </div>
        <div className="panel-body current-pick">
          <div>
            <div className="row hidden-xs hidden-sm">
              <div className="col-md-6 flight-trip-header">
                <h4 className="bold no-top-margin">
                  <ReactPlaceholder
                    className="animated-background"
                    color="transparent"
                    type="text"
                    rows={1}
                  />
                </h4>
              </div>
              <div className="col-md-6">
                <div className="col-md-7 flight-trip-header">
                  <h4 className="bold no-top-margin truncate">
                    <ReactPlaceholder
                      color="transparent"
                      className="animated-background"
                      type="text"
                      rows={1}
                    />
                  </h4>
                </div>
                <div className="col-md-5">
                  <h4 className="no-top-margin bold">
                    <ReactPlaceholder
                      color="transparent"
                      className="animated-background"
                      type="text"
                      rows={1}
                    />
                  </h4>
                </div>
              </div>
              <div className="col-xs-12 hide-on-scroll">
                <div className="col-md-6 col-xs-12 alternate-flights-single-block right-border">
                  <div className="row v-spaced">
                    <div className="col-xs-7">
                      <div className="row">
                        <p className="small">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                          />
                        </p>
                        <span className="text-grey">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                          />
                        </span>
                      </div>
                    </div>
                    <div className="col-xs-5">
                      <RectShape
                        color="transparent"
                        className="animated-background"
                        style={{ width: 100, height: 50 }}
                      />
                    </div>
                  </div>
                  <div className="row v-spaced">
                    <div className="col-xs-11">
                      <div className="row">
                        <p className="no-v-margin">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                          />
                        </p>
                        <p className="no-v-margin">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                          />
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-6 col-xs-12 alternate-flights-single-block">
                  <div className="v-spaced">
                    <div className="col-xs-7">
                      <div className="row">
                        <p className="small">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                          />
                        </p>
                        <span className="text-grey">
                          <ReactPlaceholder
                            color="transparent"
                            className="animated-background"
                            type="text"
                            rows={1}
                          />
                        </span>
                      </div>
                    </div>
                    <div className="col-xs-5">
                      <RectShape
                        color="transparent"
                        className="animated-background"
                        style={{ width: 100, height: 50 }}
                      />
                    </div>
                  </div>
                  <div className="col-xs-12 v-spaced">
                    <div className="row">
                      <div className="col-xs-11">
                        <div className="row">
                          <p className="no-v-margin">
                            <ReactPlaceholder
                              color="transparent"
                              className="animated-background"
                              type="text"
                              rows={1}
                            />
                          </p>
                          <p className="no-v-margin">
                            <ReactPlaceholder
                              color="transparent"
                              className="animated-background"
                              type="text"
                              rows={1}
                            />
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="row hidden-md hidden-lg hidden-xl">
              <div className="col-xs-11">
                <h5 className="bold no-bottom-margin">
                  <ReactPlaceholder
                    color="transparent"
                    className="animated-background"
                    type="text"
                    rows={1}
                  />
                </h5>
                <p className="text-grey text-regular">
                  <ReactPlaceholder
                    color="transparent"
                    className="animated-background"
                    type="text"
                    rows={1}
                  />
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
