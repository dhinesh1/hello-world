import React, { Component } from 'react';

import ItinerarySlotCircle from './itinerary_grid_circle';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';

import { AppConfig } from '../../../app-config';
import { encodeActivityKeyForURL } from '../../../helpers/utilsHelper';
import {
  trackEvent,
  EVENT_ITINERARY_MODIFIED,
  EVENT_ITINERARY_COSTED,
  EVENT_PACKAGES_EDIT
} from '../../../helpers/ML/EventsTracker';
import {
  GET_COST,
  itineraryModalsRouteHelper,
  ACTIVITY_DETAILS,
  ACTIVITY_ALTERNATES
} from '../../../helpers/routesHelper';

export default class ItinerarySlot extends Component {

  getSlotTitle = (slot, makeReadOnly = false) => {
    let { isBooked, userDetails, itineraryInfo } = this.props;
    const readOnlyClass = makeReadOnly? 'hide' : '';

    switch (slot.type) {
      case 'INTERNATIONAL_ARRIVE':
        return <p className="meta-text">{slot.arrivalSlotDetail.slotText}</p>;
      case 'INTERNATIONAL_DEPART':
        return <p className="meta-text">{slot.departureSlotDetail.slotText}</p>;
      case 'ACTIVITY':
        return (
          <p className="meta-text">
            {slot.activitySlotDetail.title}{' '}
            <span className={`iti-dashed-underline color-primary spaced tracker-itinerary-change-activity ${readOnlyClass}`}>
              Change
            </span>
          </p>
        );
      case 'ACTIVITY_WITH_TRANSFER':
        return (
          <p className="meta-text">
            {slot.activitySlotDetail.title}
            {/* <span className="show-on-hover blue-text link-text underline spaced-span tiny text-uppercase bold">Replace with transfer</span> */}
          </p>
        );
      case 'LEISURE':
        return (
          <p className="meta-text">
            {slot.leisureSlotDetail.text}
            {/* hide `Add activity` button for Maldives & Mauritius */}
            {(isBooked && userDetails && userDetails.userType !== 'ADMIN') ||
            (itineraryInfo.itinerary.regionCode === 'mle') ? null : (
              <span className={`iti-dashed-underline color-primary spaced tracker-itinerary-add-activity ${readOnlyClass}`}>
                Add activity
              </span>
            )}
          </p>
        );
      case 'INTERCITY_TRANSFER':
        let t_text = '';
        if (slot.intercityTransferSlotDetailVO.transferType === 'DIRECT') {
          t_text =
            slot.intercityTransferSlotDetailVO.directTransferDetail.slotText;
        }

        return (
          <p className="meta-text">
            {t_text}
            {slot.intercityTransferSlotDetailVO.canBeReplacedWithActivity ? (
              <span className="show-on-hover iti-dashed-underline color-primary spaced">
                Replace with activity
              </span>
            ) : null}
          </p>
        );
      default:
        break;
    }
  };

  onClickActivity(slot, e) {
    e.preventDefault();
    slot.isFromAlternateList = false;
    const {
      history,
      location,
      itineraryInfo,
      campaignItineraryId,
      makeReadOnly
    } = this.props;
    const { itineraryId, regionCode } = itineraryInfo.itinerary;

    if (
      location.pathname.indexOf('packages/') > 0 &&
      itineraryInfo.itinerary.campaign &&
      history.location.pathname.indexOf(GET_COST) === -1
    ) {
      trackEvent(EVENT_ITINERARY_COSTED, {
        button: EVENT_PACKAGES_EDIT
      });
      history.push(`${location.pathname}/get-cost/${campaignItineraryId}`);
    } else {
      const activityKey = encodeActivityKeyForURL(slot.slotIdentifier);

      switch (slot.type) {
        case 'ACTIVITY':
        case 'ACTIVITY_WITH_TRANSFER':
          trackEvent(EVENT_ITINERARY_MODIFIED, {
            activity_viewed: true
          });
          history.push(
            itineraryModalsRouteHelper({
              itineraryId,
              regionCode,
              target: ACTIVITY_DETAILS,
              customParams: {
                activityKey
              }
            })
          );
          break;
        case 'LEISURE':
          if(makeReadOnly){
            return
          }
          if (!itineraryInfo.itinerary.campaign) {
            trackEvent(EVENT_ITINERARY_MODIFIED, {
              activity_added: true
            });
            history.push(
              itineraryModalsRouteHelper({
                itineraryId,
                regionCode,
                target: ACTIVITY_ALTERNATES,
                customParams: {
                  activityKey
                }
              })
            );
          }
          break;
        case 'INTERCITY_TRANSFER':
          if(makeReadOnly){
            return;
          }
          if (slot.intercityTransferSlotDetailVO.canBeReplacedWithActivity) {
            trackEvent(EVENT_ITINERARY_MODIFIED, {
              activity_viewed: true
            });
            // this.props.getAlternateActivites(slot, e);
            history.push(
              itineraryModalsRouteHelper({
                itineraryId,
                regionCode,
                target: ACTIVITY_ALTERNATES,
                customParams: {
                  activityKey
                }
              })
            );
          }
          break;
        default:
          break;
      }
    }
  }

  getCostValue = slot => {
    if (this.props.isCosted && !this.props.staleCost) {
      switch (slot.type) {
        case 'ACTIVITY_WITH_TRANSFER':
        case 'ACTIVITY':
          let costingInfo = slot.activitySlotDetail.costingInfo;
          let price = costingInfo ? costingInfo.totalCost : 0;
          if(costingInfo.status === 'SOLD_OUT'){
            return  <span className="fine-text normal fade spaced color-primary">
              <div class="pill color-white bg-accent-7">SOLD OUT</div>
            </span>;
          }
          if (slot.activitySlotDetail.free) {
            return <span className="label">, Self exploration</span>;
          } else if (
            slot.activitySlotDetail.selectedTourGrade.ourSourceProvider ===
              'VIATOR' &&
            costingInfo &&
            costingInfo.cancelled
          ) {
            return <span className="in-combo">CANCELLED</span>;
          } else {
            if (price && costingInfo) {
              if (costingInfo.inCombo) {
                return <span className="in-combo">IN COMBO</span>;
              } else if (slot.activitySlotDetail.costingInfo.inSwissPass) {
                return <span className="in-combo">IN SWISS PASS</span>;
              } else {
                return (
                  <span className="fine-text normal fade spaced color-primary">
                    <span className="WebRupee">Rs.</span> <span>{price}</span>
                  </span>
                );
              }
            }
          }
          break;
        case 'LEISURE':
          break;
        default:
          break;
      }
    }
  };

  renderAllSlotsInDay() {
    let { isBooked, userDetails, itineraryInfo, makeReadOnly } = this.props;

    const tooltip = [];
    const { booking_state_alert = '' } = AppConfig;
    this.props.slotsInDay.slots.map((recent, i) => {
      tooltip[i] = (
        <Tooltip id={'sstooltip' + i}>{booking_state_alert}</Tooltip>
      );
    });

    return this.props.slotsInDay.slots.map((slot, key) => {
      let happensInPreviousCityText = slot.prevCity
        ? "(You're still in previous city)"
        : '';

      let span_classes = 'col-sm-12';
      if (slot.span === 3) {
        span_classes = 'col-sm-12';
      } else if (slot.span === 2) {
        span_classes = 'col-sm-8';
      } else {
        span_classes = 'col-sm-4';
      }

      let disableActivitiesClick = false;
      let clickableClass = 'cursor-pointer clickable activity-details-click-ga';
      switch (slot.type) {
        case 'INTERNATIONAL_ARRIVE':
        case 'INTERNATIONAL_DEPART':
          clickableClass = 'non-clickable';
          break;
        case 'INTERCITY_TRANSFER':
          let inVo = slot.intercityTransferSlotDetailVO;
          if (!inVo.canBeReplacedWithActivity) {
            clickableClass = 'non-clickable';
          }
          if (!slot.intercityTransferSlotDetailVO.canBeReplacedWithActivity) {
            clickableClass = 'non-clickable';
          }
          break;
        case 'LEISURE':
          if (
            isBooked &&
            userDetails &&
            userDetails.userType !== 'ADMIN' &&
            userDetails.userType !== 'AGENT'
          ) {
            clickableClass = 'clickable totem-disabled';
          }
          // disable activity button for Maldives & Mauritius
          if (
            itineraryInfo.itinerary.regionCode === 'mle'
          ) {
            clickableClass = 'non-clickable totem-disabled';
            // disabling the activities click action that leads to show alternates activities model
            // for these particular island regions
            disableActivitiesClick = true;
          }
          break;
        default:
          break;
      }

      return slot.type === 'LEISURE' &&
        isBooked &&
        userDetails &&
        userDetails.userType !== 'ADMIN' &&
        userDetails.userType !== 'AGENT' ? (
        <OverlayTrigger
          id={`ot11-${key}`}
          placement="top"
          overlay={tooltip[key]}
          className={
            span_classes + ' col-xs-12 itin-cell time-slot ' + clickableClass
          }
          key={slot.slotIdentifier}
          onClick={e =>
            (slot.type === 'LEISURE' &&
              isBooked &&
              userDetails &&
              userDetails.userType !== 'ADMIN' &&
              userDetails.userType !== 'AGENT') ||
            disableActivitiesClick
              ? null
              : this.onClickActivity(slot, e)
          }
        >
          <div>
            <ItinerarySlotCircle slot={slot} called_from="slot" readOnly={makeReadOnly} />
            <span className="label">{slot.name}</span>
            {this.getCostValue(slot)}
            <span className="fine-text normal dim spaced">
              {happensInPreviousCityText}
            </span>
            {this.getSlotTitle(slot, makeReadOnly)}
          </div>
        </OverlayTrigger>
      ) : (
        <div
          key={slot.slotIdentifier}
          className={
            span_classes + ' col-xs-12 itin-cell time-slot ' + clickableClass
          }
          onClick={e =>
            (slot.type === 'LEISURE' &&
              isBooked &&
              userDetails &&
              userDetails.userType !== 'ADMIN' &&
              userDetails.userType !== 'AGENT') ||
            disableActivitiesClick
              ? null
              : this.onClickActivity(slot, e)
          }
        >
          <ItinerarySlotCircle slot={slot} called_from="slot" readOnly={makeReadOnly} />
          <span className="label">{slot.name}</span>
          {this.getCostValue(slot)}
          <span className="fine-text normal dim spaced">
            {happensInPreviousCityText}
          </span>
          {this.getSlotTitle(slot, makeReadOnly)}
        </div>
      );
    });
  }

  render() {
    return <div className="row row-main">{this.renderAllSlotsInDay()}</div>;
  }
}
