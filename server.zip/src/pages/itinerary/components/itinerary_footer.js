import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import moment from 'moment';
import { MenuItem, OverlayTrigger, Popover } from 'react-bootstrap';
import { openChatWidget } from '../../../helpers/utilsHelper';
import { withLastLocation } from 'react-router-last-location';

import {
  changeToBooking,
  toggleSplitPricing,
  getCost
} from '../../../actions/actions_app';

import axios from 'axios';
import { AppConfig } from '../../../app-config';
import {
  trackEvent,
  EVENT_ITINERARY_COSTED,
  EVENT_POSITION_FOOTER,
  EVENT_CHAT_REQUESTED
} from '../../../helpers/ML/EventsTracker';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  EMAIL_QUOTE,
  SHARE_ITINERARY,
  UPDATE_COST,
  GET_COST
} from '../../../helpers/routesHelper';

const API_URL = AppConfig.api_url;
const CDN_MISC_URL = AppConfig.imgix_base;

/*global swal */

class ItineraryFooter extends Component {
  constructor(props) {
    super(props);

    this.state = {
      itinerary: {},
      showAdminPopoverButton: true
    };

    this.showChat = this.showChat.bind(this);
    this.bookTripHandler = this.bookTripHandler.bind(this);
    this.renderAdminMenu = this.renderAdminMenu.bind(this);
    this.suffleCostHandler = this.suffleCostHandler.bind(this);
    this.emailButtonHandler = this.emailButtonHandler.bind(this);
    this.sendToPlato = this.sendToPlato.bind(this);
    this.toggleSplitPricing = this.toggleSplitPricing.bind(this);
    this.updateCostClickHandler = this.updateCostClickHandler.bind(this);
    this.onScroll = this.onScroll.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
  }

  componentWillReceiveProps(props) {
    this.setState({
      itinerary: props.itineraryDetail
    });
  }

  onScroll() {
    this.setState({
      showAdminPopoverButton: true
    });
    this.refs.adminPopover && this.refs.adminPopover.hide();
  }

  handleClickOutside(event) {
    if (!event.target.classList.contains('vehoicon-close')) {
      this.onScroll();
    }
  }

  componentDidMount() {
    window.addEventListener('scroll', this.onScroll);
    window.addEventListener('mousedown', this.handleClickOutside);
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll);
    window.removeEventListener('mousedown', this.handleClickOutside);
  }

  updateCostClickHandler(e) {
    e && e.preventDefault();
    let {
      itineraryInfo,
      userDetails,
      history,
      lastLocation
    } = this.props;

    trackEvent(EVENT_ITINERARY_COSTED, { button: EVENT_POSITION_FOOTER });
    const {itineraryId, regionCode, campaign} = itineraryInfo.itinerary;

    if (userDetails.loggedIn) {
      const configObj = itineraryInfo.costingConfiguration;

      let req_data = {
        itineraryId: itineraryId,
        costingType: 'RECOST',
        costingConfig: configObj
      };

      this.props.actions.getCost({
        itineraryId,
        regionCode,
        req_data,
        history,
        lastLocation,
        campaign
      });
    } else {
      history.push(
        itineraryModalsRouteHelper({
          itineraryId,
          regionCode,
          target: UPDATE_COST
        })
      );
    }
  }

  bookTripHandler(e) {
    e && e.preventDefault();
    let { history, itineraryInfo } = this.props;

    history.push(`/booking-travellers/${itineraryInfo.itinerary.itineraryId}`);
  }

  showChat() {}

  emailButtonHandler(e) {
    e.preventDefault();
    let { userDetails, itineraryDetail } = this.props;

    if (!userDetails.loggedIn) {
      this.props.history.push(`/login`);
    } else {
      if (userDetails.userType === 'ADMIN') {
        this.props.history.push(
          itineraryModalsRouteHelper({
            itineraryId: itineraryDetail.itineraryId,
            regionCode: itineraryDetail.regionCode,
            parentPage: routingPageType.inclusion,
            target: EMAIL_QUOTE
          })
        );
      }
    }
  }

  suffleCostHandler(e) {
    e.preventDefault();

    let url = `${API_URL}itinerary/${
      this.props.itineraryDetail.itineraryId
    }/shuffleCost`;
    axios.get(url).then(() => {
      swal('Success!', 'Email will be sent with shuffled cost soon...');
    });
  }

  moveToBooking(action, payload) {
    let _this = this;
    if (action === 'booking') {
      swal(
        {
          title: 'Are you sure?',
          text: 'You will not be able to revert this!',
          type: 'warning',
          animation: true,
          showCancelButton: true,
          confirmButtonColor: '#DD6B55',
          confirmButtonText: 'Yes, Move it!',
          cancelButtonText: 'No, Dont move to booking',
          closeOnConfirm: true,
          closeOnCancel: true
        },
        function() {
          _this.props.actions
            .changeToBooking(action, payload)
            .then(() => {})
            .catch(() => {});
        }
      );
    } else {
      swal(
        {
          title: 'Are you sure?',
          text: '',
          type: 'warning',
          animation: true,
          showCancelButton: true,
          confirmButtonColor: '#DD6B55',
          confirmButtonText: payload.booked
            ? 'Yes, Freeze it!'
            : 'Yes, Un-freeze it!',
          cancelButtonText: payload.booked ? 'No, Dont freeze' : 'No, Please',
          closeOnConfirm: true,
          closeOnCancel: true
        },
        function() {
          _this.props.actions
            .changeToBooking(action, payload)
            .then(() => {})
            .catch(() => {});
        }
      );
    }
  }

  sendToPlato(payload) {
    swal({
      title:
        '<div class"block-center"> <div class="loading-circle loading-circle-primary"></div> <h4 class="text-center">Sending to PLATO<h4></div>',
      showCancelButton: false,
      showConfirmButton: false,
      html: true
    });

    let url = `${API_URL}itinerary/${
      this.props.itineraryDetail.itineraryId
    }/sendToPlato`;
    axios.post(url, payload).then(() => {
      swal('Success!', 'The data sent to PLATO', 'success');
    });
  }

  toggleSplitPricing(payload) {
    let _this = this;
    _this.props.actions.toggleSplitPricing(payload);
  }

  renderAdminMenu() {
    let { itineraryDetail, userDetails, location, makeReadOnly } = this.props;
    let {
      costed,
      staleCost,
      booking,
      frozen,
      itineraryId,
      regionCode
    } = itineraryDetail;

    return (
      <Popover id="mobile-admin-features-popover" title="Super powers">
        <ul
          className="mobile-admin-features list-unstyled mb-0"
          onClick={() => {
            this.refs.adminPopover.hide();
            this.setState({ showAdminPopoverButton: true });
          }}
        >
          {userDetails.loggedIn &&
          userDetails.userType === 'ADMIN' &&
          !booking &&
          !frozen &&
          !makeReadOnly ? (
            <MenuItem eventKey="2" onClick={e => this.suffleCostHandler(e)}>
              <span className="vehoicon-shuffle" /> Get better cost
            </MenuItem>
          ) : null}
          {userDetails.loggedIn &&
          userDetails.userType === 'ADMIN' &&
          costed &&
          !staleCost ? (
            <MenuItem eventKey="3" onClick={e => this.emailButtonHandler(e)}>
              Share email quote
            </MenuItem>
          ) : null}
          {userDetails.loggedIn &&
          userDetails.userType === 'ADMIN' &&
          !booking &&
          !frozen &&
          !(
            this.props.itineraryShared ||
            this.props.itineraryInfo.itinerary.shared
          ) ? (
            <MenuItem
              eventKey="4"
              onClick={() => {
                this.props.history.push(
                  itineraryModalsRouteHelper({
                    itineraryId,
                    regionCode,
                    location,
                    target: SHARE_ITINERARY
                  })
                );
                // this.scrollToElement('#modal-11');
              }}
            >
              <span className="vehoicon-map" /> Share itinerary
            </MenuItem>
          ) : null}
          {userDetails.loggedIn &&
          userDetails.userType === 'ADMIN' &&
          !booking &&
          !makeReadOnly ? (
            <MenuItem
              eventKey="6"
              onClick={e =>
                this.moveToBooking('booking', {
                  itineraryId: itineraryId,
                  booked: true
                })
              }
            >
              <span className="vehoicon-ticket" /> Move to booking
            </MenuItem>
          ) : null}
          {userDetails.loggedIn &&
          userDetails.userType === 'ADMIN' &&
          !booking ? (
            <MenuItem
              eventKey="7"
              onClick={e =>
                this.sendToPlato({
                  itineraryId: itineraryId
                })
              }
            >
              <span className="vehoicon-arrow-up" /> Send to PLATO
            </MenuItem>
          ) : null}
          {userDetails.loggedIn &&
          userDetails.userType === 'ADMIN' &&
          !booking ? (
            <MenuItem
              eventKey="8"
              onClick={e =>
                this.toggleSplitPricing({
                  itineraryId: itineraryId,
                  splitPricing: !this.props.itineraryDetail.splitPricing
                })
              }
            >
              <span className="vehoicon-receipt" />
              {!this.props.itineraryDetail.splitPricing
                ? 'Enable'
                : 'Disable'}{' '}
              split pricing Cust.
            </MenuItem>
          ) : null}
        </ul>
      </Popover>
    );
  }

  buttonRenderHelper() {
    const {location, campaignItineraryId, itineraryDetail} = this.props;
    const {
      costed,
      staleCost,
      booking,
      frozen,
      campaign,
      itineraryId,
      regionCode
    } = itineraryDetail;

    if (costed && !staleCost) {
      return (
        <span
          onClick={booking || frozen ? null : this.bookTripHandler}
          className="cost-div price"
        >
          <span className="large">{this.totalCostRenderHelper()} </span>
          <span className="small normal book-this-trip-ga">
            {booking ? 'Booked' : frozen ? 'Blocked' : 'Book this trip'}
          </span>
        </span>
      );
    } else if (costed && staleCost) {
      return (
        <a
          onClick={e => this.updateCostClickHandler(e)}
          className="color-white update-cost-ga"
        >
          <span className="color-white">Update cost</span>
        </a>
      );
    } else {
      const targetGCMPath = campaign
        ? `${location.pathname}/get-cost/${campaignItineraryId}`
        : itineraryModalsRouteHelper({
          itineraryId,
          regionCode,
          target: GET_COST,
          location
        });

      return (
        <a
          onClick={e => {
            e.preventDefault();
            if (
              this.props.history.location.pathname.indexOf('get-cost') === -1
            ) {
              this.props.history.push(targetGCMPath);
            }
          }}
          className={`meta-text`}
        >
          <span className="color-white">{this.props.makeReadOnly ? 'Check Availability' : 'View trip costs'}</span>
        </a>
      );
    }
  }

  totalCostRenderHelper() {
    if (this.props.itineraryDetail.costed) {
      return (
        <span className="itinerary-price bold">
          ₹ {this.props.itineraryDetail.totalCost}
        </span>
      );
    }
  }

  render() {
    let { adult_count, child_count, userDetails, location } = this.props;
    let {
      costed,
      staleCost,
      booking,
      itineraryId,
      regionCode
    } = this.props.itineraryDetail;

    let departure_date, passengerConf;
    if (costed && !staleCost) {
      let departureDate = (this.props.itineraryInfo.costingConfiguration || {})
        .departureDate;

      departure_date = moment(departureDate, 'DD/MMM/YYYY')
        .format('MMM DD')
        .toUpperCase();
      passengerConf = adult_count + ' + ' + child_count;
    }

    return (
      <div className="full-width-section fixed-bottom itinerary-footer bg-white visible-xs">
        {this.state.showAdminPopoverButton ? null : (
          <div className="modal-backdrop fade in" />
        )}

        <div className="container-fluid">
          <div className="row footer-actions">
            {costed && !staleCost ? (
              <div
                className={
                  'text-center col-xs-6 travel-details-block flex vertical-center center'
                }
              >
                <div
                  onClick={e => {
                    e.preventDefault();
                    if (
                      !booking &&
                      this.props.history.location.pathname.indexOf(
                        'get-cost'
                      ) === -1
                    ) {
                      this.props.history.push(
                        itineraryModalsRouteHelper({
                          itineraryId,
                          regionCode,
                          target: UPDATE_COST,
                          location
                        })
                      );
                    }
                  }}
                >
                  <span
                    className={
                      'text-center block ' +
                      (booking ? 'meta-text' : 'fine-text')
                    }
                  >
                    <span className="config-texts bold">{departure_date}</span>{' '}
                    <span className="config-texts bold">
                      <span className="vehoicon-travellers2" />
                      &nbsp;{passengerConf}
                    </span>
                  </span>
                  {!booking? (
                    <span className="small edit-travel-details-cta color-primary dashed-underline block">
                      Edit travel details
                    </span>
                  ) : null}
                </div>
              </div>
            ) : (
              <div
                className={
                  'text-center col-xs-6 travel-details-block flex vertical-center center open-chat'
                }
                onClick={() => {
                  trackEvent(EVENT_CHAT_REQUESTED, {
                    element_type: 'button',
                    element_name: 'btn_chat_requested_itinerary_footer'
                  });
                  openChatWidget();
                }}
              >
                <span className="meta-text">Chat with us!</span>
              </div>
            )}
            <div
              className={
                'bg-primary text-center col-xs-6 flex vertical-center center view-trip-cost-ga'
              }
            >
              {this.buttonRenderHelper()}
            </div>

            {userDetails &&
            userDetails.userType === 'ADMIN' &&
            (costed && !staleCost) ? (
              <OverlayTrigger
                trigger="click"
                placement="top"
                ref="adminPopover"
                onClick={() => {
                  this.setState({
                    showAdminPopoverButton: !this.state.showAdminPopoverButton
                  });
                }}
                overlay={this.renderAdminMenu()}
              >
                {this.state.showAdminPopoverButton ? (
                  <span className="super-power-icon vehoicon-ion-flash" />
                ) : (
                  <span className="super-power-icon vehoicon-close" />
                )}
              </OverlayTrigger>
            ) : (
              <span className="chat-icon-btn" onClick={openChatWidget}>
                <img
                  src={`${CDN_MISC_URL}/images/misc/chat-icon.png`}
                  className="chat-icon"
                />
              </span>
            )}
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      campaignItineraryId: app.itineraryInfo.campaignItineraryId,
      userDetails: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      userDetails: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      changeToBooking: bindActionCreators(changeToBooking, dispatch),
      toggleSplitPricing: bindActionCreators(toggleSplitPricing, dispatch),
      getCost: bindActionCreators(getCost, dispatch)
    }
  };
}

export default withLastLocation(
  withRouter(connect(mapStateToProps, mapDispatchToProps)(ItineraryFooter))
);
