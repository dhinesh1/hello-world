import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import axios from 'axios';
import _ from 'lodash';
import Phone from 'react-phone-number-input';
import { parseNumber } from 'libphonenumber-js';
import { isValidMobileNumber as isValidNumber } from '../../../helpers/utilsHelper';
import { AppConfig } from '../../../app-config';
import { emailValidation } from '../../validations';
import { triggerSimpleAjax } from '../../../helpers/httpHelper';
import { withLastLocation } from 'react-router-last-location';
import {
  showLoginForm,
  getUserDetails,
  getCost
} from '../../../actions/actions_app';
import { getLeadSource } from '../../../helpers/leadSourceHelper';
import { trackEvent, EVENT_ITINERARY_COSTING_SUBMITTED } from '../../../helpers/ML/EventsTracker';

const API_URL = AppConfig.api_url;

/*global ga */
/*global fbq */

class GetCostUserAuth extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isKilled: false,
      isLoggedIn: false,
      activeBlock: 'otp',
      fieldInvalid: false,
      can_call: true,
      errorMessage: '',
      user_ref_id: '',
      user_name: '',
      user_email: '',
      otp_value: '',
      pwd_value: '',
      opt_value: '',
      mobile_number: '',
      countryCode: '+91',
      password: '',
      responseMessage: '',
      emailAlreadyExistsError: '',
      changingPhoneNumber: false,
      enableMobileGetCost: false,
      mobile_number_wrong: false,
      mobile_number_invalid: false,
      optVerificationFailed: false,
      loginVerificationFailed: false,
      user_name_empty: false,
      user_email_empty: false,
      user_otp_empty: false,
      pwd_value_empty: false,
      forgotPasswordSuccess: false,
      forgotPasswordFailed: false,
      OTPVerificationFailed: false,
      singup_error: false,
      singup_conflict: false,
      forgotPasswordIsLoading: false,
      isLoading: false,
      currentView: 'signup'
    };

    this.onEnterKeyDown = this.onEnterKeyDown.bind(this);
    this.handleGetCostClick = this.handleGetCostClick.bind(this);
    this.getCostingConfiguration = this.getCostingConfiguration.bind(this);
    this.validateGetCostSignupForm = this.validateGetCostSignupForm.bind(this);
    this.handelOnChange = this.handelOnChange.bind(this);
  }

  onEnterKeyDown(e) {
    if (e.charCode === 13) {
      e.preventDefault();

      this.handleGetCostClick();
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.mobile_number) {
      this.setState({ mobile_number: nextProps.mobile_number });
    }
  }

  onChangeInput(opt) {
    this.setState({ ...opt }, () => {
      let enableMobileGetCost = this.validateGetCostSignupForm();

      this.setState({ enableMobileGetCost: enableMobileGetCost });
    });
  }

  handelOnChange(value) {
    let countryCode = '+';
    value = value ? value : '';

    let numberValid = isValidNumber(value);
    if (numberValid) {
      let parsed = parseNumber(value, { extended: true });

      countryCode += parsed.countryCallingCode;
    }

    this.setState(
      {
        mobile_number: value,
        mobile_number_wrong: !isValidNumber(value),
        countryCode: countryCode
      },
      () => {
        let enableMobileGetCost = this.validateGetCostSignupForm();

        this.setState({ enableMobileGetCost: enableMobileGetCost });
      }
    );
  }

  validateGetCostSignupForm() {
    let { user_name, user_email, mobile_number } = this.state;
    let enableGetCost = false;

    let isEmailValid = user_email.trim() !== '' && emailValidation(user_email);

    // check sign-up form field
    if (
      user_name.trim() !== '' &&
      isEmailValid &&
      isValidNumber(mobile_number)
    ) {
      enableGetCost = true;
    }

    return enableGetCost;
  }

  getCostingConfiguration() {
    let { user_details } = this.props.app;
    let costingConfiguration = this.props.app.getCostUpdatedObject
      .costingConfig;
    let configObj = _.omit(costingConfiguration, [
      'bookingPlan_Text',
      'departureAirport_Text'
    ]);

    if (
      user_details &&
      user_details.loggedIn &&
      user_details.userType === 'ADMIN' &&
      configObj.tripStage === '2'
    ) {
      configObj.tripStage = '4'; // Booking this month
    }

    return configObj;
  }

  handleGetCostClick(e) {
    if (e) {
      e.preventDefault();
    }
    let _state = this.state;
    let tripStage = 2;

    let isFormValid = true;
    let { userDetails, history, lastLocation } = this.props;

    if (userDetails && userDetails.loggedIn) {
      const {	
        departureCity,	
        departureDate,	
        hotelGuestRoomConfigurations	
      } = this.getCostingConfiguration();	
      trackEvent(EVENT_ITINERARY_COSTING_SUBMITTED, {
        already_loggedin: true,
        fromURL: document.referrer,
        departure_city: departureCity,
        departure_date: new Date(departureDate),
        room_count: hotelGuestRoomConfigurations.length,
        adult_count: _.sumBy(hotelGuestRoomConfigurations, 'adultCount') || 0,
        child_count: _.sumBy(hotelGuestRoomConfigurations, ch => (ch.childAges && ch.childAges.length)) || 0
      });
      this.props.triggerGetCost();
      this.props.closeLoginModal();
    } else {
      isFormValid = this.validateGetCostSignupForm();

      if (!isFormValid) return false;
      else {
        this.setState({ isLoading: true }, () => {
          let url = `${API_URL}user/signup/verifyotp`;
          let itineraryId = this.props.match.params.itineraryId;

          let post_data = {
            mobileNumber: _state.mobile_number
              .replace(/\D/g, '')
              .substr(_state.countryCode.replace('+', '').length),
            id: '',
            otp: '', // user entered OTP
            userName: _state.user_name,
            email: _state.user_email,
            countryPhoneCode: _state.countryCode,
            tripStage: tripStage,
            shouldContact: true,
            leadSource: getLeadSource({
              history: history,
              lastLocation: lastLocation,
              itineraryId: itineraryId
            }),
            cpid: sessionStorage.getItem('campaignId')
          };

          axios
            .post(url, post_data)
            .then(response => {
              // console.log(response.data);
              if (response.data) {
                if (response.data.status === 'INVALID_EMAIL') {
                  let configObj = this.getCostingConfiguration();

                  let req_data = {
                    itineraryId: itineraryId,
                    costingType: 'RECOST',
                    costingConfig: configObj,
                    name: this.state.itinerary_name
                  };
                  this.props.actions.showLoginForm({
                    requestPayload: req_data,
                    history: this.props.history,
                    preState: {
                      mobile_number: _state.mobile_number,
                      user_email: response.data.data
                    }
                  });
                  const {	
                    departureCity,	
                    departureDate,	
                    hotelGuestRoomConfigurations	
                  } = configObj;	

                   trackEvent(EVENT_ITINERARY_COSTING_SUBMITTED, {	
                    already_loggedin: false,	
                    fromURL: document.referrer,
                    departure_city: departureCity,
                    departure_date: new Date(departureDate),	
                    room_count: hotelGuestRoomConfigurations.length,
                    adult_count: _.sumBy(hotelGuestRoomConfigurations, 'adultCount') || 0,
                    child_count: _.sumBy(hotelGuestRoomConfigurations, ch => (ch.childAges && ch.childAges.length)) || 0
                  });
                } else {
                  window.sessionStorage.setItem('USER_HASH_DATA', response.data.data);
                  this.props.actions.getUserDetails();
                  const {	
                    departureCity,	
                    departureDate,	
                    hotelGuestRoomConfigurations	
                  } = this.getCostingConfiguration();	

                   trackEvent(EVENT_ITINERARY_COSTING_SUBMITTED, {	
                    already_loggedin: false,
                    fromURL: document.referrer,
                    departure_city: departureCity,	
                    departure_date: new Date(departureDate),	
                    room_count: hotelGuestRoomConfigurations.length,
                    adult_count: _.sumBy(hotelGuestRoomConfigurations, 'adultCount') || 0,
                    child_count: _.sumBy(hotelGuestRoomConfigurations, ch => (ch.childAges && ch.childAges.length)) || 0
                  });

                  let itineraryId = !_.isEmpty(this.props.app.itineraryInfo)
                    ? this.props.app.itineraryInfo.campaignItineraryId
                    : this.props.match.params.itineraryId;

                  if (
                    this.props.location.pathname.indexOf('packages') > 0 ||
                    this.props.location.pathname.indexOf('vacations') > 0 ||
                    this.props.location.pathname.split('/')[1] === 'holidays' ||
                    this.props.location.pathname.indexOf('customize/mle') > 0 ||
                    this.props.location.pathname.indexOf('customize/sez') > 0 ||
                    this.props.location.pathname.indexOf('customize/mus') > 0
                  ) {
                    let url = `${API_URL}itinerary/campaign/${itineraryId}/assignUser`;
                    triggerSimpleAjax(
                      url,
                      'POST',
                      {},
                      response => {
                        this.setState({ isLoading: false }, () => {
                          this.props.actions.getCost({
                            itineraryId: response.data,
                            regionCode: this.props.match.params.searchRegion,
                            req_data: Object.assign(this.props.app.getCostUpdatedObject, {
                              itineraryId: response.data
                            }),
                            history: this.props.history,
                            lastLocation: this.props.lastLocation,
                            campaign: true
                          });

                          this.props.closeLoginModal();
                        });
                      },
                      error => {
                        console.error('Got error: ', error);
                      }
                    );
                  } else {
                    this.setState({ isLoading: false }, () => {
                      this.props.actions.getCost({
                        itineraryId: this.props.match.params.itineraryId,
                        regionCode: this.props.match.params.searchRegion,
                        req_data: this.props.app.getCostUpdatedObject,
                        history: this.props.history,
                        lastLocation: this.props.lastLocation
                      });

                      this.props.closeLoginModal();
                    });
                  }
                }
              }
            })
            .catch(error => {
              // console.log(error);
              if (error.response && error.response.status === 409) {
                this.setState({
                  isLoading: false,
                  emailAlreadyExistsError:
                    'This email ID already exists. Try using a different one'
                });

                if (error.response.data !== 'Email id already exists') {
                  if (
                    this.props.history.location.pathname.indexOf('packages') >
                      0 &&
                    this.props.match.params.destination &&
                    this.props.match.params.destination.length > 25
                  ) {
                    this.props.history.push({
                      pathname: `/packages/${
                        this.props.match.params.destination
                      }/login`,
                      state: { mobile_number: _state.mobile_number }
                    });
                  }
                  if (
                    this.props.history.location.pathname.indexOf('vacations') >
                    0
                  ) {
                    let loc =
                      (this.props.match.params.theme
                        ? '/' + this.props.match.params.theme + '-'
                        : '/') +
                      'vacations/' +
                      this.props.match.params.destination +
                      (this.props.match.params.city
                        ? '/' + this.props.match.params.city + '/'
                        : '/');
                    this.props.history.push({
                      pathname:
                        loc +
                        `get-cost/${this.props.match.params.itineraryId}/login`,
                      state: { mobile_number: _state.mobile_number }
                    });
                  } else if (
                    this.props.history.location.pathname.split('/')[1] ===
                    'holidays'
                  ) {
                    let loc =
                      '/holidays/' + this.props.match.params.destination + '/';
                    this.props.history.push({
                      pathname:
                        loc +
                        `get-cost/${this.props.match.params.itineraryId}/login`,
                      state: { mobile_number: _state.mobile_number }
                    });
                  } else if (
                    this.props.history.location.pathname.indexOf('packages') > 0
                  ) {
                    let loc =
                      (this.props.match.params.theme
                        ? '/' + this.props.match.params.theme + '-'
                        : '/') +
                      'packages/' +
                      this.props.match.params.destination +
                      (this.props.match.params.city
                        ? '/' + this.props.match.params.city + '/'
                        : '/');

                    this.props.history.push({
                      pathname:
                        loc +
                        `get-cost/${this.props.match.params.itineraryId}/login`,
                      state: { mobile_number: _state.mobile_number }
                    });
                  } else if (this.props.match.params.itineraryId) {
                    this.props.history.push({
                      pathname: `/view/${
                        this.props.match.params.itineraryId
                      }/login`,
                      state: { mobile_number: _state.mobile_number }
                    });
                  }
                }
              } else if (error.response && error.response.status === 400) {
                this.setState({
                  isLoading: false,
                  mobile_number_empty: true
                });
              }
            });
        });
      }
    }
  }

  render() {
    let {
      mobile_number,
      isLoading,
      isKilled,
      mobile_number_wrong,
      user_name,
      user_email,
      enableMobileGetCost,
      emailAlreadyExistsError
    } = this.state;

    if (isKilled) {
      return null;
    }

    return (
      <div className="modal-dialog">
        <div className="modal-content with-header">
          <div className={'modal-header'}>
            <div className="modal-header">
              <button
                className="close tracker-get-cost-modal-auth-close"
                onClick={this.props.closeLoginModal}
              >
                <i className="vehoicon-close" />
              </button>
            </div>
          </div>

          <div className="modal-body">
            <div className="modal-row">
              <div>
                {/* ACCOUNT INFO STARTS */}
                <form ref={'vForm'} id={'sign-up-form'}>
                  <div className="row">
                    <div className="col-md-12">
                      <h3 className="bold mt-0">Account info</h3>
                    </div>
                    <div className="col-md-12">
                      <div className="alert-bar mini">
                        Costed Itinerary will be saved to your account.
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <div className="clearfix small">
                          <label
                            htmlFor={'user_first_name'}
                            className="pull-left normal dim"
                          >
                            Your name
                          </label>
                        </div>
                        <input
                          value={user_name}
                          onKeyPress={this.onEnterKeyDown}
                          onChange={e =>
                            this.onChangeInput({ user_name: e.target.value })
                          }
                          type="text"
                          name={'user_first_name'}
                          className="form-control"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div
                        className={
                          'form-group ' +
                          (emailAlreadyExistsError.length === 0
                            ? ''
                            : 'has-error')
                        }
                      >
                        <div className="clearfix small">
                          <label
                            htmlFor={'user_email'}
                            className="pull-left normal dim"
                          >
                            Email
                          </label>
                        </div>
                        <input
                          value={user_email}
                          onKeyPress={this.onEnterKeyDown}
                          onChange={e =>
                            this.onChangeInput({ user_email: e.target.value })
                          }
                          type="email"
                          name={'user_email'}
                          className="form-control"
                        />
                        <span className="help-block">
                          {emailAlreadyExistsError}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-xs-12 col-md-6">
                      <div
                        className={
                          'form-group ' +
                          (mobile_number_wrong ? 'has-error' : '')
                        }
                      >
                        <div className="clearfix small">
                          <label
                            htmlFor={'user_mobile_number'}
                            className="pull-left normal dim"
                          >
                            Mobile number
                          </label>
                        </div>

                        <Phone
                          displayInitialValueAsLocalNumber={false}
                          country={'IN'}
                          value={mobile_number}
                          error={
                            mobile_number
                              ? isValidNumber(mobile_number)
                                ? undefined
                                : 'Invalid phone number'
                              : undefined
                          }
                          indicateInvalid
                          saveOnIcons={false}
                          smartCaret={false}
                          onChange={this.handelOnChange}
                        />
                      </div>
                    </div>
                    <div className="col-xs-12 col-md-6">
                      <div className="form-group clearfix">
                        <span className="pull-left mini fade mobile-shake">
                          If you are new here, account details will be sent as
                          an SMS for future reference.
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-xs-12">
                      <div className="form-group">
                        <button
                          onClick={e => this.handleGetCostClick(e)}
                          disabled={enableMobileGetCost ? '' : 'disabled'}
                          className={
                            'btn btn-primary btn-block expand tracker-get-cost-modal-auth-signup-submit ' +
                            (isLoading ? 'sending' : '')
                          }
                        >
                          Save & Get cost
                        </button>
                      </div>

                      <div className="form-group text-center">
                        <button
                          onClick={e => {
                            e.preventDefault();
                            // console.log(this.props.match);
                            if (
                              this.props.history.location.pathname.indexOf(
                                'vacations'
                              ) > 0
                            ) {
                              let loc =
                                (this.props.match.params.theme
                                  ? '/' + this.props.match.params.theme + '-'
                                  : '/') +
                                'vacations/' +
                                this.props.match.params.destination +
                                (this.props.match.params.city
                                  ? '/' + this.props.match.params.city + '/'
                                  : '/');

                              this.props.history.push({
                                pathname:
                                  loc +
                                  `get-cost/${
                                    this.props.match.params.itineraryId
                                  }/login`
                              });
                            } else if (
                              this.props.history.location.pathname.split(
                                '/'
                              )[1] === 'holidays'
                            ) {
                              let loc =
                                '/holidays/' +
                                this.props.match.params.destination +
                                '/';
                              this.props.history.push({
                                pathname:
                                  loc +
                                  `get-cost/${
                                    this.props.match.params.itineraryId
                                  }/login`
                              });
                            } else if (
                              this.props.history.location.pathname.indexOf(
                                'packages'
                              ) > 0
                            ) {
                              let loc =
                                (this.props.match.params.theme
                                  ? '/' + this.props.match.params.theme + '-'
                                  : '/') +
                                'packages' +
                                (this.props.match.params.destination
                                  ? '/' +
                                    this.props.match.params.destination +
                                    '/'
                                  : '/');
                              this.props.history.push({
                                pathname:
                                  loc +
                                  `get-cost/${
                                    this.props.match.params.itineraryId
                                  }/login`
                              });
                            } else if (
                              this.props.history.location.pathname.indexOf(
                                'customize/mle'
                              ) > 0
                            ) {
                              this.props.history.push({
                                pathname: `/customize/mle/get-cost/${
                                  this.props.match.params.itineraryId
                                }/login`
                              });
                            } else if (
                              this.props.history.location.pathname.indexOf(
                                'customize/sez'
                              ) > 0
                            ) {
                              this.props.history.push({
                                pathname: `/customize/sez/get-cost/${
                                  this.props.match.params.itineraryId
                                }/login`
                              });
                            } else if (
                              this.props.history.location.pathname.indexOf(
                                'customize/mus'
                              ) > 0
                            ) {
                              this.props.history.push({
                                pathname: `/customize/mus/get-cost/${
                                  this.props.match.params.itineraryId
                                }/login`
                              });
                            } else if (this.props.match.params.itineraryId) {
                              this.props.history.push(
                                `/view/${
                                  this.props.match.params.itineraryId
                                }/login`
                              );
                            }
                          }}
                          className="btn-link normal clear-padding tracker-get-cost-modal-auth-already-have-an-account "
                        >
                          Already have an account?
                        </button>
                      </div>
                    </div>
                  </div>
                  {/* ACCOUNT INFO ENDS */}
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {};

const mapDispatchToProps = dispatch => {
  return {
    actions: {
      showLoginForm: bindActionCreators(showLoginForm, dispatch),
      getUserDetails: bindActionCreators(getUserDetails, dispatch),
      getCost: bindActionCreators(getCost, dispatch)
    }
  };
};

export default withLastLocation(
  connect(mapStateToProps, mapDispatchToProps)(GetCostUserAuth)
);
