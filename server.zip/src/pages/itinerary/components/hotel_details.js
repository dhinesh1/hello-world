import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';

import HotelContainer from '../../../common_components/hotel_container';
import ModalLoadingIndicator from '../../../common_components/modal_loading_indicator';

import { removeHotel } from '../../../actions/actions_app';
import { encodeCostingKeyForURL } from '../../../helpers/utilsHelper';

import { AppConfig } from '../../../app-config';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  HOTEL_ALTERNATES
} from '../../../helpers/routesHelper';

const booking_state_alert = AppConfig.booking_state_alert;

class HotelDetails extends Component {
  constructor(props) {
    super(props);

    this.removeButtonClickHandler = this.removeButtonClickHandler.bind(this);
    this.changeButtonClickHandler = this.changeButtonClickHandler.bind(this);
    this.HeaderRenderHelper = this.HeaderRenderHelper.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }

  removeButtonClickHandler(hotel, event) {
    event.preventDefault();

    let removeRequestObject = {
      itineraryId: this.props.itineraryId,
      stayCostingKey: hotel.costingKey
    };

    this.props.actions
      .removeHotel(removeRequestObject)
      .then(() => {
        this.props.onCloseModal();
      })
      .catch(() => {
        this.props.onCloseModal();
      });
  }

  changeButtonClickHandler(hotel, event) {
    event.preventDefault();

    let { history, location, itineraryDetail } = this.props;
    let hotelKey = encodeCostingKeyForURL(hotel.costingKey);

    history.push(
      itineraryModalsRouteHelper({
        itineraryId: itineraryDetail.itineraryId,
        regionCode: itineraryDetail.regionCode,
        location,
        target: HOTEL_ALTERNATES,
        customParams: { hotelKey }
      })
    );
  }

  HeaderRenderHelper(hotel, makeReadOnly) {
    let { itineraryDetail, userDetails } = this.props;
    let { booking, frozen } = itineraryDetail;
    let action_buttons = null;

    let isAdmin =
      userDetails && userDetails.loggedIn && userDetails.userType === 'ADMIN';
    let removeBtn = makeReadOnly? null : (
      <button
        type="button"
        className={
          'btn btn-sm btn-default btn-outline remove-cta delete ' +
          (booking || frozen ? 'disabled' : '')
        }
        onClick={e =>
          booking || frozen ? null : this.removeButtonClickHandler(hotel, e)
        }
      >
        <span className="vehoicon-delete text-xs-only" />
        <span className="text-md-only">Remove </span>
      </button>
    );

    let changeBtn = makeReadOnly ? null : (
      <button
        type="button"
        className={
          'btn btn-primary btn-sm change-cta ' +
          (booking || frozen ? 'disabled' : '')
        }
        onClick={e =>
          booking || frozen? null : this.changeButtonClickHandler(hotel, e)
        }
      >
        Change
      </button>
    );

    if (hotel.called_from !== 'ALTERNATE_HOTELS') {
      action_buttons = makeReadOnly ? null :
        booking || frozen ? (
          <OverlayTrigger
            id="ot8"
            placement="top"
            overlay={
              <Tooltip id="hoteltooltip1">{booking_state_alert}</Tooltip>
            }
          >
            <div className={'modal-actions'}>
              {isAdmin && !makeReadOnly? removeBtn : null}
              {changeBtn}
            </div>
          </OverlayTrigger>
        ) : (
          <div className={'modal-actions'}>
            {isAdmin && !makeReadOnly? removeBtn : null}
            {changeBtn}
          </div>
        );
    } else {
      action_buttons = (
        <div className={'modal-actions'}>
          <button
            type="button"
            className="btn btn-sm btn-primary"
            onClick={e => {
              this.props.handleSelectedAlternateHotel(hotel, e);
            }}
          >
            Choose
          </button>
        </div>
      );
    }

    return (
      <div className="modal-header with-bg clearfix">
        {action_buttons}
        <span className="caps-text semi-bold kern-more fade">HOTEL</span>
        <button
          type="button"
          className="close pull-left"
          data-dismiss="modal"
          onClick={this.closeModal}
          aria-label="Close"
        >
          <i className="vehoicon-close" aria-hidden="true" />
        </button>
      </div>
    );
  }

  closeModal() {
    this.props.onCloseModal();
  }

  render() {
    let hotel = this.props.hotelDetails;
    const makeReadOnly = this.props.makeReadOnly;

    if (!Object.keys(hotel).length) {
      return <ModalLoadingIndicator />;
    } else {
      return (
        <div className={`modal-dialog`} key="hotel_details_modal">
          <div className={'modal-content with-header'}>
            {this.HeaderRenderHelper(hotel, makeReadOnly)}

            <div className="modal-body">
              <HotelContainer
                showImages={true}
                allowChangeRoom={true}
                hotelGuestRoomConfigurations={
                  this.props.hotelGuestRoomConfigurations
                }
                itineraryId={this.props.itineraryId}
                hotel={hotel}
                packageRate={this.props.packageRate}
                itineraryDetail={this.props.itineraryDetail}
                userDetails={this.props.userDetails}
                splitPricing={this.props.splitPricing}
                makeReadOnly={makeReadOnly}
              />
            </div>
          </div>
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  return {
    activeActivity: state.activeActivity,
    makeReadOnly: state.app.isReadOnly
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      removeHotel: bindActionCreators(removeHotel, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(HotelDetails);
