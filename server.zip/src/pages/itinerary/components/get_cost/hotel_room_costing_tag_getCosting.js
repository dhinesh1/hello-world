import React, { Component } from 'react';

export default class HotelRoomConfigTag extends Component {
  constructor(props) {
    super(props);

    this.changeConfig = this.changeConfig.bind(this);
    this.getRoomCount = this.getRoomCount.bind(this);
  }

  changeConfig(target, action, evt) {
    // console.log(evt);
    // evt && action === "ADD" && evt.preventDefault();

    let current_conf = this.props.conf;

    let adults = current_conf.adultCount,
      reachedRequiredMembers = false,
      childAges = current_conf.childAges,
      allMembers = this.props.getAllMemberCount();

    switch (action) {
      case 'ADD':
        evt.preventDefault();

        if (allMembers === 8) {
          reachedRequiredMembers = true;
        }

        if (target === 'adult') {
          adults += 1;
        } else {
          childAges.push(0);
        }
        break;
      case 'REMOVE':
        if (target === 'adult') {
          evt.preventDefault();

          adults -= 1;
        } else {
          childAges.splice(evt, 1);
        }
        break;
      case 'CHANGE_AGE':
        if (evt.e >= 0) {
          childAges[evt.index] = evt.e;
        } else {
          childAges.splice(evt.index, 1);
        }
        break;
      default:
        break;
    }

    // Added by - Josan - To clean child ages array - This will remove null / undefined / false values from array
    childAges = childAges.filter(e => (e === 0 ? '0' : e));

    let newConf = { adultCount: adults, childAges: childAges };
    this.props.updateRoomConfiguration({
      roomIndex: this.props.roomIndex,
      reachedRequiredMembers: reachedRequiredMembers,
      conf: newConf
    });
  }

  getRoomCount() {
    let childCount = 0;
    if (this.props.conf.childAges !== null) {
      childCount = this.props.conf.childAges.length;
    }
    return this.props.conf.adultCount + childCount;
  }

  renderChildrens() {
    let roomCount = this.getRoomCount();
    let infants = (this.props.conf.childAges || []).filter(child => {
      return child <= 2;
    });
    let is_disabled =
      this.props.reachedRequiredMembers ||
      roomCount === 6 ||
      infants.length >= this.props.conf.adultCount;
    let childCount = 0;
    if (this.props.conf.childAges !== null) {
      childCount = this.props.conf.childAges.length;
    }

    if (childCount > 0) {
      return this.props.conf.childAges.map((child, inx) => {
        return (
          <div key={'child_row_' + inx} className="child-row">
            <div
              className={
                'counter-shell children clearfix ' +
                (child >= 0 ? 'active' : '')
              }
            >
              <span
                className={'face vehoicon-' + (child > 2 ? 'child2' : 'baby')}
              />
              <span className="age">Age:</span>
              <div className="select-style">
                <select
                  className="change-child-age"
                  value={child}
                  onChange={e =>
                    this.changeConfig('child', 'CHANGE_AGE', {
                      e: e.target.value,
                      index: inx
                    })
                  }
                >
                  <option value="">--</option>
                  <option value="0">{'<1'}</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                </select>
              </div>
            </div>
            {inx === this.props.conf.childAges.length - 1 ? (
              <button
                disabled={is_disabled}
                onClick={e =>
                  is_disabled ? null : this.changeConfig('child', 'ADD', e)
                }
                className={
                  'btn collapse-toggle ' +
                  (is_disabled ? 'disabled' : 'counter-add-icon-ga')
                }
              >
                <i className="vehoicon-plus3" />
                <span className="hidden-xs">Add</span>
              </button>
            ) : (
              <button
                onClick={e => {
                  e.preventDefault();
                  this.changeConfig('child', 'REMOVE', inx);
                }}
                className="btn collapse-toggle counter-minus-icon-ga on"
              >
                <i className="vehoicon-plus3" />
              </button>
            )}
          </div>
        );
      });
    } else {
      return (
        <div className="child-row">
          <div className="counter-shell children clearfix">
            <span className={'face vehoicon-baby'} />
            <span className="age">Age:</span>
            <div className="select-style">
              <select
                className="change-child-age"
                value={''}
                disabled={is_disabled}
                onChange={e =>
                  this.changeConfig('child', 'CHANGE_AGE', {
                    e: e.target.value,
                    index: 0
                  })
                }
              >
                <option value="">--</option>
                <option value="0">{'<1'}</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
              </select>
            </div>
          </div>
          <button
            disabled={is_disabled}
            onClick={e =>
              is_disabled ? null : this.changeConfig('child', 'ADD', e)
            }
            className={
              'btn collapse-toggle ' +
              (is_disabled ? 'disabled' : 'add-child-ga')
            }
          >
            <i className="vehoicon-plus3" />
            <span className="hidden-xs">Add</span>
          </button>
        </div>
      );
    }
  }

  hotelIconRender() {
    if (this.props.roomIndex === 0) {
      return (
        <span className="room-bed-icon text-grey vehoicon-airline_seat_individual_suite ex-large" />
      );
    } else {
      return (
        <span
          onClick={() => this.props.removeRoom(this.props.roomIndex)}
          className="room-bed-icon text-danger cursor-pointer vehoicon-delete remove-room ex-large"
        />
      );
    }
  }

  render() {
    let roomCount = this.getRoomCount();
    let infants = (this.props.conf.childAges || []).filter(child => {
      return child <= 2;
    });
    let is_minus_disabled =
      this.props.conf.adultCount === 1 ||
      this.props.conf.adultCount === infants.length;
    let is_add_disabled = roomCount === 6 || this.props.reachedRequiredMembers;

    return (
      <li>
        <div className="row room-row">
          <div className="col-xs-5 col-sm-4 passenger-info">
            <div className="counter-shell adults clearfix active">
              <span className="face vehoicon-adult" />
              <span className="count">{this.props.conf.adultCount}</span>
              <button
                onClick={e =>
                  is_minus_disabled
                    ? null
                    : this.changeConfig('adult', 'REMOVE', e)
                }
                disabled={is_minus_disabled}
                className={
                  'btn pull-left ' +
                  (is_minus_disabled ? 'disabled' : 'counter-minus-icon-ga')
                }
              >
                <span className="vehoicon-minus3" />
              </button>
              <button
                onClick={e =>
                  is_add_disabled ? null : this.changeConfig('adult', 'ADD', e)
                }
                disabled={is_add_disabled}
                className={
                  'btn pull-right ' +
                  (is_add_disabled ? 'disabled' : 'counter-add-icon-ga')
                }
              >
                <span className="vehoicon-plus3" />
              </button>
            </div>
          </div>
          <div className="col-xs-5 col-sm-5 no-padding second-column">
            {this.renderChildrens()}
          </div>
          <div className="col-xs-2 col-sm-2 room-info no-padding text-center">
            <span className="vehoicon-room" />
            <span className="room-count">{this.props.roomIndex + 1}</span>
          </div>
          {this.props.roomIndex > 0 ? (
            <button
              onClick={e => {
                e.preventDefault();
                this.props.removeRoom(this.props.roomIndex);
              }}
              className={'btn-link remove-room vehoicon-delete '}
            >
              <span className="sr-only">Remove room</span>
            </button>
          ) : null}
        </div>
      </li>
    );
  }
}
