import React, { Component } from 'react';

export default class ItineraryNewDaySlot extends Component {
  render() {
    return (
      <div className={'animated col-xs-12 no-padding'}>
        <div className="text-center grey-bg col-xs-12 no-padding">
          <div className="loader-bar" />
          <span className="block bold line-height-40 v-spaced">
            Adding a night
          </span>
        </div>
      </div>
    );
  }
}
