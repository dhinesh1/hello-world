import React, { Component } from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';

import ItineraryHotelStay from './itinerary_city_hotel_stay';
import ItineraryrRentalCarBand from './itinerary_rental_car_band';
import ItinerarySlot from './itinerary_single_slot';
import Totem from './itinerary_totem';
// import ItineraryNewDaySlot from './itinerary_new_day_slot'

export default class ItineraryCityBody extends Component {
  constructor(props) {
    super(props);

    this.renderDayItem = this.renderDayItem.bind(this);
    this.renderRentalCarBand = this.renderRentalCarBand.bind(this);
  }

  renderHotelStayBlock(data) {
    if (this.props.isCosted && !this.props.staleCost) {
      const {itineraryInfo} = this.props; 
      return (
        <ItineraryHotelStay
          hotelCosting={data}
          hidePrice={this.props.hidePrice}
          itineraryId={itineraryInfo.itinerary && itineraryInfo.itinerary.itineraryId}
          regionCode={itineraryInfo.itinerary && itineraryInfo.itinerary.regionCode}
        />
      );
    }
  }

  renderDayNum(day, is_last_day) {
    let dayLabel = 'Day';
    let dayNumber = day.dayNum;

    if (this.props.isCosted && !this.props.staleCost) {
      dayLabel = day.month;
      dayNumber = day.day;
    }

    return (
      <div className={'column-meta ' + (is_last_day ? 'last-row' : 'day')}>
        <div>
          <span className="label dim dark">{dayLabel}</span>
          <span className="h4 date fade">{dayNumber}</span>
          {day.rcAvailable ? (
            <p className="vehoicon-directions_car rental-car-icon" />
          ) : null}
        </div>
      </div>
    );
  }

  renderDayItem(day, dayInx, is_last_day) {
    let {
      flightsBlocked,
      isFirstCity,
      itineraryInfo,
      isFromPackages
    } = this.props;

    if (day.type === 'new_day_placeholder') {
      return null;
      // return (
      // 	<ItineraryNewDaySlot dayIdentifier={dayInx} />
      // )
    } else {
      return (
        <div
          className={
            'unit-row ' +
            (isFirstCity && dayInx === 0
              ? ''
              : day.slots.length === 1
                ? 'single-slot-day'
                : '')
          }
        >
          {is_last_day ||
          flightsBlocked ||
          (itineraryInfo.itinerary.campaign && isFromPackages) ? null : (
            <Totem
              dayIndex={dayInx}
              key={this.props.city.cityKey + '_totem'}
              {...this.props}
              totemFor="DAY"
              target={day}
            />
          )}
          {this.renderDayNum(day, is_last_day)}
          <div className="day-activities-wrapper">
            <ItinerarySlot {...this.props} slotsInDay={day} />
          </div>
        </div>
      );
    }
  }

  renderDays() {
    let allDaysInCity = this.props.daysInCity;

    return allDaysInCity.map((day, dayInx) => {
      let is_last_day =
        this.props.city.is_last_city && allDaysInCity.length === dayInx + 1;
      let totem_class = is_last_day ? '' : 'totem-on-hover';

      return (
        <div key={day.dayIdentifier} className={'itin-row ' + totem_class}>
          {this.renderDayItem(day, dayInx, is_last_day)}
        </div>
      );
    });
  }

  renderRentalCarBand() {
    if (this.props.city.showRcTag) {
      return (
        <ItineraryrRentalCarBand
          isCosted={this.props.isCosted}
          stateCost={this.props.staleCost}
          key={this.props.city.cityKey + '_rental_car'}
          rentalCarKey={this.props.rentalCarKey}
          city={this.props.city}
          hidePrice={this.props.hidePrice}
          manageTotemClick={this.props.manageTotemClick}
        />
      );
    }
  }

  render() {
    return (
      <div className="itin-body days-block">
        {this.renderHotelStayBlock(this.props.city.hotelInCity)}
        {this.renderRentalCarBand()}
        <ReactCSSTransitionGroup
          transitionName="itinerary-city-day"
          transitionAppear={true}
          transitionEnter={true}
          transitionLeave={true}
          transitionAppearTimeout={700}
          transitionEnterTimeout={700}
          transitionLeaveTimeout={200}
        >
          {this.renderDays()}
        </ReactCSSTransitionGroup>
      </div>
    );
  }
}
