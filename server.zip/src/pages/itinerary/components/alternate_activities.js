import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import classNames from 'classnames';

import _ from 'lodash';
import PriceDiff from '../../../common_components/price_diff';
import { manageActivity } from '../../../actions/actions_app';
import placeHolderUrls from '../../../common_components/Image/place_holder_urls';
import SmartImage from '../../../common_components/Image/smart_image';
import { AppConfig } from '../../../app-config';
import { onceModalClosed } from '../../../helpers/utilsHelper';
import {
  trackEvent,
  EVENT_ITINERARY_MODIFIED,
  EVENT_INCLUSIONS_MODIFIED
} from '../../../helpers/ML/EventsTracker';
import {
  itineraryModalsRouteHelper,
  routingPageType
} from '../../../helpers/routesHelper';
const images_cdn_misc_url = AppConfig.images_cdn_misc_url;

class AlternateActivities extends Component {
  constructor(props) {
    super(props);

    this.handleActivityBlockClick = this.handleActivityBlockClick.bind(this);
    this.renderAlternateLength = this.renderAlternateLength.bind(this);
    this.handleActivityDetailsClick = this.handleActivityDetailsClick.bind(
      this
    );
    this.increasePageCount = this.increasePageCount.bind(this);
    this.state = {
      optionsToShow: 25
    };
  }

  increasePageCount() {
    this.setState({
      optionsToShow: this.state.optionsToShow + 25
    });
  }

  handleActivityBlockClick(activity) {
    let action = 'CHANGE';
    let activityWithTransfer = false;
    let activitySlot = Object.assign({}, this.props.currentPickActivity);

    let {
      itineraryInfo,
      location,
      match,
      history,
      actions,
      itineraryDetails
    } = this.props;

    // Day identifier to check RC availability
    let slotKeyInDay = _.findKey(
      itineraryInfo.iterDayByKey,
      e => e.allSlotKeys.indexOf(activitySlot.slotIdentifier) !== -1
    );

    let currentCityKey = _.findKey(
      itineraryInfo.iterCityByKey,
      i => i.allDayKeys.indexOf(slotKeyInDay) !== -1
    );
    let currentCity = itineraryInfo.iterCityByKey[currentCityKey];

    let fromCityId = currentCity.cityId;
    let toCityId = currentCity.cityId;
    if (
      activitySlot.type === 'LEISURE' ||
      activitySlot.type === 'INTERCITY_TRANSFER'
    ) {
      action = 'ADD';
    }

    if (
      activitySlot.type === 'INTERCITY_TRANSFER' ||
      activitySlot.type === 'ACTIVITY_WITH_TRANSFER'
    ) {
      fromCityId = activitySlot.intercityTransferSlotDetailVO.fromCity;
      toCityId = activitySlot.intercityTransferSlotDetailVO.toCity;
      activityWithTransfer = true;
      // } else if (activitySlot.type === 'LEISURE') {
      //   fromCityId = currentCity.cityId;
    }

    let isCancelled = false;
    if (
      activitySlot.activitySlotDetail &&
      activitySlot.activitySlotDetail.activityCostingIdentifier &&
      itineraryInfo.itinerary.costed &&
      !itineraryInfo.itinerary.staleCost
    ) {
      let costingInfo =
        itineraryInfo.activityCostings.activityCostingById[
          activitySlot.activitySlotDetail.activityCostingIdentifier
        ];

      // console.log(costingInfo);
      isCancelled = costingInfo.cancelled;
    }
    activitySlot.activitySlotDetail = activity;

    const { itineraryId, regionCode } = itineraryDetails;
    const itineraryPath = itineraryModalsRouteHelper({
      itineraryId,
      regionCode
    });
    const inclusionsPath = itineraryModalsRouteHelper({
      itineraryId,
      regionCode,
      parentPage: routingPageType.inclusion
    });

    const options = {
      action: action,
      activityWithTransfer: activityWithTransfer,
      itineraryId: itineraryId,
      activitySlot: activitySlot,
      fromCityId: fromCityId,
      toCityId: toCityId,
      cancelled: isCancelled
    };

    actions
      .manageActivity(options)
      .then(() => {
        if (location.pathname.indexOf(routingPageType.itinerary) > 0) {
          trackEvent(EVENT_ITINERARY_MODIFIED, {
            activity_added: true
          });
          history.push(itineraryPath);
        } else {
          trackEvent(EVENT_INCLUSIONS_MODIFIED, {
            activity_added: true	
          });
          history.push(inclusionsPath);
        }

        onceModalClosed();
      })
      .catch(() => {
        onceModalClosed();

        if (location.pathname.indexOf('view') > 0) {
          trackEvent(EVENT_ITINERARY_MODIFIED, {	
            activity_viewed: true	
          });
          history.push(itineraryPath);
        } else {
          trackEvent(EVENT_INCLUSIONS_MODIFIED, {	
            activity_viewed: true	
          });
          history.push(inclusionsPath);
        }
      });
  }

  handleActivityDetailsClick(option, e) {
    e.preventDefault();
    const {
      history,
      location,
      match,
      currentPickActivity,
      itineraryDetails
    } = this.props;
    const { itineraryId, regionCode } = itineraryDetails;

    let slot = { ...currentPickActivity };
    slot.activitySlotDetail = option;
    slot.isFromAlternateList = true;
    slot.handleActivityBlockClick = this.handleActivityBlockClick;

    this.props.openActivityFromAlternates({
      currentPickActivity: currentPickActivity.activitySlotDetail,
      selectedActivity: slot,
      history: history,
      location: location,
      itineraryId,
      regionCode,
      activityKey: match.params.activityKey
    });
  }

  renderAlternateLength() {
    if (this.props.alternates.length > 0) {
      return (
        <span className="mini block dim bold text-center spacer">
          {this.props.alternates.length} available options to choose from
        </span>
      );
    }
  }

  renderAlternates() {
    switch (this.props.search_state) {
      case 0:
        if (this.props.alternates.length > 0) {
          const allAlternates = this.props.alternates.map(activity => {
            let selectedTourGrade = activity.selectedTourGrade;
            let duration_type = '';

            if (selectedTourGrade.durationType === 'HALF') {
              duration_type = 'Half day';
            } else if (selectedTourGrade.durationType === 'QUARTER') {
              duration_type = 'Quarter day';
            } else {
              duration_type = 'Full day';
            }

            const activityPlaceholders = [
              placeHolderUrls.activity2Medium,
              placeHolderUrls.activityMedium
              // placeHolderUrls.activity3Medium,
            ];

            let activityType = 'Shared';
            if (activity.privateTour) activityType = 'Private';

            return (
              <div
                onClick={e => this.handleActivityDetailsClick(activity, e)}
                key={'alternates_' + activity.planningToolId}
                className="col-xs-12 col-sm-6 col-md-4"
              >
                <article
                  data-key={activity.planningToolId}
                  className="data-option-item"
                >
                  <div className="data-option-item-wrapper single-alternate-activity-option">
                    <div className="media-shell">
                      <figure className="sd">
                        <SmartImage
                          src={activity.mainPhoto}
                          disableLazyLoad={true}
                          defaultImage={_.sample(activityPlaceholders)}
                          alt={activity.title}
                        />
                      </figure>
                    </div>
                    <div className="data-option-details">
                      <h6 className="title">{activity.title}</h6>
                      <div
                        className={
                          activity.free
                            ? 'col-xs-12 col-md-12 meta'
                            : 'col-xs-8 col-md-8 meta'
                        }
                      >
                        <span className="dim">
                          {duration_type},{' '}
                          {activity.free ? (
                            <span>Self exploration</span>
                          ) : (
                            <span>{activityType}</span>
                          )}{' '}
                        </span>
                      </div>
                      <div
                        className={
                          activity.free ||
                          (activity.selectedTourGrade.diffDetail &&
                            activity.selectedTourGrade.diffDetail
                              .diffChangeType === 'NONE')
                            ? 'hidden'
                            : 'col-xs-4 col-md-4 price'
                        }
                      >
                        <span>
                          {activity.free ? (
                            <span className="block">
                              <span>Self exploration</span>
                            </span>
                          ) : activity.selectedTourGrade &&
                          activity.selectedTourGrade.cost ? (
                            <span className="block">
                              <span className="WebRupee">Rs.</span>
                              {activity.selectedTourGrade.cost}
                            </span>
                          ) : null}
                        </span>
                        {activity.selectedTourGrade &&
                        !activity.selectedTourGrade.cost &&
                        activity.selectedTourGrade.diffDetail ? (
                          <PriceDiff
                            diff={activity.selectedTourGrade.diffDetail}
                            classNames={'block'}
                          />
                        ) : null}
                      </div>
                      <div className="col-xs-8 col-md-8 rating activity">
                        <div className="hide">
                          <span className="vehoicon-happy2" />40%
                        </div>
                        <div className="hide">
                          <span className="vehoicon-smile2" />20%
                        </div>
                      </div>
                      <div className="col-xs-4 col-md-4 action">
                        <a
                          className="btn btn-xs btn-primary select-activity-ga hidden-sm hidden-xs"
                          onClick={e => {
                            e.preventDefault();
                            e.stopPropagation();
                            e.nativeEvent.stopImmediatePropagation();
                            this.handleActivityBlockClick(activity);
                          }}
                        >
                          Choose
                        </a>
                        <a
                          className="btn btn-sm btn-primary select-activity-ga visible-xs visible-sm"
                          onClick={e => {
                            e.preventDefault();
                            e.stopPropagation();
                            e.nativeEvent.stopImmediatePropagation();
                            this.handleActivityBlockClick(activity);
                          }}
                        >
                          Choose
                        </a>
                      </div>
                    </div>
                  </div>
                </article>
              </div>
            );
          });
          return allAlternates.slice(0, this.state.optionsToShow);
        } else {
          return (
            <div className="col-xs-12 text-center">
              <h4 className="v-spaced">
                <p className="other-highlights">
                  Oops! No activity options found here!
                </p>
              </h4>
              <br />
              <br />
              <img
                className="no-alternates-illustrartion"
                src={images_cdn_misc_url + 'not_found_icon.png'}
                alt="Not found"
              />
            </div>
          );
        }
      case 1:
        // loading
        return (
          <div className="col-xs-12 no-padding alternate-activities-list">
            <h4>Loading...</h4>
          </div>
        );
      case 2:
        // No result
        return (
          <div className="col-xs-12 no-padding alternate-activities-list">
            <div className="col-xs-12 text-center">
              {' '}
              <h4 className="v-spaced">
                <p className="other-highlights">
                  Oops! No activity options found here!
                </p>
              </h4>{' '}
              <br />
              <br />
              <img
                className="no-alternates-illustrartion"
                src="https://pyt-images.imgix.net/images/misc/not_found_icon.png"
                alt="Not found"
              />
            </div>
          </div>
        );
      default:
    }
  }

  render() {
    let { currentPickActivity } = this.props;
    let is_current_pick_empty =
      currentPickActivity && _.isEmpty(currentPickActivity.activitySlotDetail);

    return (
      <div
        className={classNames('modal-row clearfix', {
          'pt-0': is_current_pick_empty
        })}
      >
        {this.renderAlternateLength()}
        <section className="change-data grid-list clearfix">
          {this.renderAlternates()}
        </section>
        {this.props.alternates &&
        this.state.optionsToShow <= this.props.alternates.length ? (
          <div className={'row text-center'}>
            <div className={'col-xs-12'}>
              <button
                className={'btn btn-link'}
                onClick={this.increasePageCount}
              >
                View More Activities
              </button>
            </div>
          </div>
        ) : null}
      </div>
    );
  }
}

function mapStateToProps(state) {
  // console.log(state);

  if (state.app.itineraryInfo) {
    return {
      itineraryDetails: state.app.itineraryInfo.itineraryDetails.itinerary,
      itineraryInfo: state.app.itineraryInfo.itineraryDetails
    };
  } else {
    return {
      itineraryDetails: {},
      itineraryInfo: {}
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      manageActivity: bindActionCreators(manageActivity, dispatch)
    }
  };
}

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(AlternateActivities)
);
