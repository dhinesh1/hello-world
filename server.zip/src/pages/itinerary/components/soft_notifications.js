import React, { Component } from 'react';

export default class SoftNotification extends Component {
  constructor(props) {
    super(props);
    this.state = { duration: 12000, showClass: '', initialDelay: 500 };
    this.show = this.show.bind(this);
    this.hide = this.hide.bind(this);
    this.onClickHandler = this.onClickHandler.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.show) {
      this.show();
    } else {
      this.hide();
    }
  }

  show() {
    let _this = this;
    if (
      _this.props.action_name === 'REMOVE_ACTIVITY' ||
      _this.props.action_name === 'REMOVE_HOTEL' ||
      _this.props.action_name === 'REMOVE_FLIGHT' ||
      _this.props.action_name === 'REMOVE_CITY' ||
      _this.props.action_name === 'REMOVE_DAY_IN_CITY'
    ) {
      //setTimeout(()=>{_this.hide()},this.state.duration);
      //setTimeout(()=>{_this.setState({showClass:"slide-in"})},this.state.initialDelay); //Showing after inital delay
    }
  }

  hide() {
    let notificationElement = document.getElementById('soft-notification');
    if (notificationElement) {
      notificationElement.classList.remove('slide-in');
    }
    this.setState({ showClass: '' });
  }

  onClickHandler() {
    this.hide();
    this.props.undo({ itineraryId: this.props.itineraryId });
  }

  render() {
    return (
      <div
        className={'soft-notifications ' + this.state.showClass}
        id="soft-notification"
      >
        <p className="opener bold">
          <span id="soft-notification-text" />{' '}
          <a
            href="#"
            className="color-warning underline warning"
            id="soft-notification-undo"
            onClick={this.onClickHandler}
          >
            Undo<span className="hidden-xs"> action</span>?
          </a>
        </p>
        <a onClick={this.hide} className="close">
          <span className="vehoicon-close" />
        </a>
      </div>
    );
  }
}
