import React, { Component } from 'react';

export default class AlternateFlightsTimingRow extends Component {
  constructor(props) {
    super(props);
    this.timingOptionRowsHelper = this.timingOptionRowsHelper.bind(this);
    this.getConnectionDurationAndStopsCount = this.getConnectionDurationAndStopsCount.bind(
      this
    );
  }

  getConnectionDurationAndStopsCount(duration, r) {
    let stops = '';

    if (r.length - 1 === 0) stops = 'Direct';
    else if (r.length - 1 === 0) stops = `${r.length - 1} stop`;
    else stops = `${r.length - 1} stops`;

    let durHours = Math.floor(duration / 60);
    let durMinutes = duration % 60;

    if (durHours !== 0)
      return { stops: stops, duration: `${durHours}h ${durMinutes}m` };
    else return { stops: stops, duration: `${durMinutes}m` };
  }

  timingOptionRowsHelper(tripDetails, leg, i) {
    let inputName = 'option-' + i + '-' + leg;
    let checked;
    return tripDetails.map((option, i) => {
      let lastIndex = option.routes.length - 1;
      checked = i === 0;
      return (
        <label key={option.tripIdentifier} className="col-xs-12">
          <div className="row">
            <div className="col-xs-1">
              <div className="row">
                <input
                  type="radio"
                  defaultChecked={checked}
                  value={option.tripIdentifier}
                  name={'' + inputName}
                  data-changes-stay-start-date={option.changesStayStartDate}
                />
              </div>
            </div>
            <div className="col-xs-11 margin-neg-5">
              <div className="row">
                <div className="col-xs-2">
                  <div className="row">
                    <p className="no-v-margin">
                      {option.routes[0].departureTime.substring(
                        0,
                        option.routes[0].departureTime.length - 3
                      )}
                    </p>
                    <p className="no-v-margin">
                      {option.routes[0].depMonth}{' '}
                      {option.routes[0].depDateOfMonth}
                    </p>
                  </div>
                </div>
                <div className="col-xs-8">
                  <div className="col-xs-3">
                    <div className="row">
                      <p className="no-v-margin">&nbsp;</p>
                      <p className="no-v-margin">&nbsp;</p>
                    </div>
                  </div>
                  <div className="col-xs-6 text-center">
                    <p className="no-v-margin">
                      <span className="text-grey vehoicon-ion-android-time" />
                    </p>
                    <p className="no-v-margin text-grey text-small">
                      {
                        this.getConnectionDurationAndStopsCount(
                          option.duration,
                          option.routes
                        ).duration
                      },{' '}
                      {
                        this.getConnectionDurationAndStopsCount(
                          option.duration,
                          option.routes
                        ).stops
                      }
                    </p>
                  </div>
                  <div className="col-xs-3">
                    <div className="row">
                      <p className="no-v-margin">&nbsp;</p>
                      <p className="no-v-margin">&nbsp;</p>
                    </div>
                  </div>
                </div>
                <div className="col-xs-2">
                  <div className="row">
                    <p className="no-v-margin">
                      {option.routes[lastIndex].arrivalTime.substring(
                        0,
                        option.routes[lastIndex].arrivalTime.length - 3
                      )}
                    </p>
                    <p className="no-v-margin">
                      {option.routes[lastIndex].arrMonth}{' '}
                      {option.routes[lastIndex].arrDateOfMonth}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </label>
      );
    });
  }

  render() {
    return (
      <div>
        {this.timingOptionRowsHelper(
          this.props.tripDetails,
          this.props.leg,
          this.props.order
        )}
      </div>
    );
  }
}
