import React, { Component, Fragment } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import moment from 'moment';
import _ from 'lodash';
import CostFormat from '../../../common_components/CostFormatter';
import axios from 'axios';
import { AppConfig } from '../../../app-config';
import { Link } from 'react-router-dom';

import { SplitButton } from 'react-bootstrap';
import { MenuItem } from 'react-bootstrap';
import {
  adultsChildrenString,
  openChatWidget,
  getItineraryTitle
} from '../../../helpers/utilsHelper';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  GET_COST,
  UPDATE_COST,
  LOGIN,
  SHARE_ITINERARY,
  RATE_MATCH_TOTAL_COST
} from '../../../helpers/routesHelper';
import { GetCostModalLoadable } from '../../../helpers/loadbleComponentsHelper';
import {
  getCost,
  toggleSplitPricing,
  changeToBooking
} from '../../../actions/actions_app';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';
import { withLastLocation } from 'react-router-last-location';
import { Helmet } from 'react-helmet';
import { trackEvent, EVENT_BOOKING_INITIATED, EVENT_CANCELLATION_POLICY, EVENT_CHAT_REQUESTED } from '../../../helpers/ML/EventsTracker';

const API_URL = AppConfig.api_url;
const booking_state_alert = AppConfig.booking_state_alert;
const scrollTop = () => {
  window.scroll(0, 0);
};

/*global swal */

class ItineraryHeader extends Component {
  constructor(props) {
    super(props);

    this.state = {
      itinerary: {}
    };

    this.bookTripCall = this.bookTripCall.bind(this);
    this.moveToBooking = this.moveToBooking.bind(this);
    this.sendToPlato = this.sendToPlato.bind(this);
    this.toggleSplitPricing = this.toggleSplitPricing.bind(this);
    this.agentNetCostRenderHelper = this.agentNetCostRenderHelper.bind(this);
    this.updateCostClickHandler = this.updateCostClickHandler.bind(this);
  }

  componentDidMount() {
    GetCostModalLoadable.preload();
  }

  componentWillReceiveProps(props) {
    this.setState({
      itinerary: props.itineraryDetail
    });
  }

  updateCostClickHandler(e) {
    e && e.preventDefault();

    const {
      itineraryInfo,
      user_details,
      history,
      location,
      lastLocation
    } = this.props;
    const { itineraryId, regionCode, campaign } = itineraryInfo.itinerary;

    if (user_details.loggedIn) {
      const configObj = itineraryInfo.costingConfiguration;

      if (
        moment(configObj.departureDate, 'DD/MMM/YYYY').isSameOrBefore(
          moment()
        ) &&
        history.location.pathname.indexOf(UPDATE_COST) === -1
      ) {
        history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            target: UPDATE_COST,
            location
          })
        );
      } else {
        let req_data = {
          itineraryId: itineraryId,
          costingType: 'RECOST',
          costingConfig: configObj
        };
        this.props.actions.getCost({
            itineraryId,
            regionCode,
            req_data,
            history,
            lastLocation,
            campaign
          });
      }
    } else {
      if (history.location.pathname.indexOf(UPDATE_COST) === -1) {
        history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            target: UPDATE_COST,
            location
          })
        );
      }
    }
  }

  bookTripCall(e) {
    e.preventDefault();
    const { history, itineraryInfo, user_details } = this.props;

    if (!user_details.loggedIn) {
      // We should take them to the global login modal
      history.push('/login');
    } else {
      trackEvent(EVENT_BOOKING_INITIATED, { is_header_button: true });
      history.push(
        `/booking-travellers/${itineraryInfo.itinerary.itineraryId}`
      );
    }
  }

  suffleCostHandler(e) {
    e.preventDefault();

    let url = `${API_URL}itinerary/${
      this.props.itineraryInfo.itinerary.itineraryId
    }/shuffleCost`;
    axios.get(url).then(() => {
      swal('Email will be sent with shuffled cost soon...');
    });
  }

  openChat = () => {
    trackEvent(EVENT_CHAT_REQUESTED, {
      element_type: 'dropdown',
      element_name: 'btn_chat_requested_top_bar'
    });
    openChatWidget();
  }

  sendToPlato(payload) {
    swal({
      title:
        '<div class"block-center"> <div class="loading-circle loading-circle-primary"></div> <h4 class="text-center">Sending to PLATO<h4></div>',
      showCancelButton: false,
      showConfirmButton: false,
      html: true
    });

    let url = `${API_URL}itinerary/${
      this.props.itineraryDetail.itineraryId
    }/sendToPlato`;
    axios.post(url, payload).then(() => {
      swal('Success!', 'The data sent to PLATO', 'success');
    });
  }

  toggleSplitPricing(payload) {
    this.props.actions.toggleSplitPricing(payload);
  }

  moveToBooking(action, payload) {
    let _this = this;
    if (action === 'booking') {
      swal(
        {
          title: 'Are you sure?',
          text: 'You will not be able to revert this!',
          type: 'warning',
          animation: true,
          showCancelButton: true,
          confirmButtonColor: '#DD6B55',
          confirmButtonText: 'Yes, Move it!',
          cancelButtonText: 'No, Dont move to booking',
          closeOnConfirm: true,
          closeOnCancel: true
        },
        function() {
          _this.props.actions.changeToBooking(action, payload);
        }
      );
    } else {
      swal(
        {
          title: 'Are you sure?',
          text: '',
          type: 'warning',
          animation: true,
          showCancelButton: true,
          confirmButtonColor: '#DD6B55',
          confirmButtonText: payload.booked
            ? 'Yes, Freeze it!'
            : 'Yes, Un-freeze it!',
          cancelButtonText: payload.booked ? 'No, Dont freeze' : 'No, Please',
          closeOnConfirm: true,
          closeOnCancel: true
        },
        function() {
          _this.props.actions.changeToBooking(action, payload);
        }
      );
    }
  }

  goToCancellationPolicy = () => {
    trackEvent(EVENT_CANCELLATION_POLICY);

    window.open('/cancellation-policy', '_blank');
  }

  buttonRenderHelper() {
    let { itineraryInfo, user_details, location, makeReadOnly, campaignItineraryId } = this.props;
    let {
      costed,
      staleCost,
      booking,
      frozen,
      regionCode,
      itineraryId,
      shared,
      campaign
    } = itineraryInfo.itinerary;
    let isAdmin =
      user_details &&
      user_details.loggedIn &&
      user_details.userType === 'ADMIN';
    let isAdminAllowed = isAdmin && !booking;

    if (costed && !staleCost) {
      return booking ? (
        <OverlayTrigger
          id="ot10"
          placement="top"
          overlay={<Tooltip id="headtooltip">{booking_state_alert}</Tooltip>}
        >
          <SplitButton
            id="book-this-trip-btn"
            pullRight={true}
            disabled={booking}
            bsStyle={'primary'}
            title="Book your trip"
            key={Math.random()}
            className="n-tracker-boookyourtrip"
          >
            <MenuItem
              onClick={this.openChat}
              className="chat-with-us-desktop-ga open-chat tracker-book-your-trip-dropdown-chat-with-us"
              eventKey="1"
            >
              Chat with us!
            </MenuItem>
            <MenuItem divider />
            <MenuItem
              eventKey="5"
              onClick={this.goToCancellationPolicy}
              className="tracker-book-your-trip-dropdown-cancellation"
            >
              Cancellation Policy
            </MenuItem>
          </SplitButton>
          {/* </span> */}
        </OverlayTrigger>
      ) : (
        <SplitButton
          id="book-this-trip-btn"
          pullRight={true}
          onClick={e => (booking || frozen ? null : this.bookTripCall(e))}
          disabled={booking}
          bsStyle={'primary'}
          title="Book your trip"
          key={Math.random()}
          className="n-tracker-boookyourtrip"
        >
          <MenuItem
            onClick={this.openChat}
            className="chat-with-us-desktop-ga open-chat tracker-book-your-trip-dropdown-chat-with-us"
            eventKey="1"
          >
            Chat with us!
          </MenuItem>
          {isAdminAllowed ? <MenuItem divider /> : null}
          {isAdminAllowed ? (
            <MenuItem eventKey="3" onClick={e => this.suffleCostHandler(e)}>
              <span className="vehoicon-shuffle" /> Get better cost
            </MenuItem>
          ) : null}

          {isAdminAllowed && !shared ? (
            <MenuItem
              eventKey="4"
              onClick={e =>
                this.props.history.push(
                  itineraryModalsRouteHelper({
                    itineraryId,
                    regionCode,
                    location,
                    target: SHARE_ITINERARY
                  })
                )
              }
            >
              <span className="vehoicon-map" /> Share itinerary
            </MenuItem>
          ) : null}
          {isAdminAllowed ? (
            <MenuItem
              eventKey="7"
              onClick={() =>
                this.sendToPlato({
                  itineraryId: itineraryId
                })
              }
            >
              <span className="vehoicon-arrow-up" /> Send to PLATO
            </MenuItem>
          ) : null}
          {isAdminAllowed ? (
            <MenuItem
              eventKey="8"
              onClick={() =>
                this.toggleSplitPricing({
                  itineraryId: itineraryId,
                  splitPricing: !itineraryInfo.itinerary.splitPricing
                })
              }
            >
              <span className="vehoicon-receipt" />
              {!itineraryInfo.itinerary.splitPricing
                ? 'Enable'
                : 'Disable'}{' '}
              split pricing for cust.
            </MenuItem>
          ) : null}

          <MenuItem divider />
          <MenuItem
            eventKey="5"
            onClick={this.goToCancellationPolicy}
            className="tracker-book-your-trip-dropdown-cancellation"
          >
            Cancellation Policy
          </MenuItem>
        </SplitButton>
      );
    } else if (staleCost) {
      return (
        <button
          onClick={this.updateCostClickHandler}
          className="btn btn-primary pulse-zoomer animated infinite cta-bottom-spacer tracker-update-cost"
          id="update-cost-btn"
        >
          Update Cost
        </button>
      );
    } else {
      const getCostRoute = itineraryModalsRouteHelper({
        itineraryId : campaign ? this.props.campaignItineraryId : itineraryId,
        regionCode,
        target: GET_COST,
        location
      });

      return (
        <span>
          {this.props.history ? (
            <Link
              key={'itineraryHeaderGetCostBtn'}
              to={{
                pathname: campaign
                  ? `${this.props.history.location.pathname}/get-cost/${
                      this.props.campaignItineraryId
                    }`
                  : getCostRoute
              }}
              className="btn btn-primary-dark pulse-zoomer animated infinite cta-bottom-spacer tracker-get-tripcost"
              id="calculate-trip-cost-btn"
            >
              <span className="color-white">
                {makeReadOnly ? 'Check Availability' : campaign ? 'Get latest cost' : 'Get trip cost'}
              </span>
            </Link>
          ) : null}
        </span>
      );
    }
  }

  totalCostRenderHelper() {
    let { user_details, itineraryInfo, location, makeReadOnly } = this.props;
    let {
      costed,
      staleCost,
      booking,
      frozen,
      itineraryId,
      campaign,
      regionCode
    } = itineraryInfo.itinerary;

    let itineraryTotalCost = itineraryInfo.itinerary.totalCost;

    const pricePerPersonText = makeReadOnly ? "Price for 2 persons" : "Starting price/person";

    if (costed && !staleCost) {
      return (
        <span
          className="medium-heading text-left no-margin"
          style={{ display: 'inline-block', 'paddingRight': '16px' }}
        >
          {user_details && user_details.userType === 'AGENT' ? (
            <span className={'fine-text'} style={{ display: 'block' }}>
              Recommended price
            </span>
          ) : null}
          <span className="WebRupee">Rs.</span>{' '}
          <CostFormat cost={itineraryTotalCost} />{' '}
          {campaign && regionCode === 'mle' ? <sup>*</sup> : null}
          {user_details &&
          user_details.loggedIn &&
          (user_details.userType === 'ADMIN' ||
            user_details.userType === 'AGENT') &&
          !booking &&
          !frozen &&
          !makeReadOnly? (
            <a
              onClick={() =>
                this.props.history.push(
                  itineraryModalsRouteHelper({
                    itineraryId,
                    regionCode,
                    location,
                    target: RATE_MATCH_TOTAL_COST,
                    customParams: { called_from: 'TOTAL_COST' }
                  })
                )
              }
            >
              {' '}
              <span className="vehoicon-mode_edit color-secondary dim" />
            </a>
          ) : null}
        </span>
      );
    } else if (campaign && !staleCost && itineraryTotalCost) {
      return (
        <span
          className="medium-heading text-right no-margin"
          style={{ display: 'inline-block' }}
        >
          <span className={'fine-text light'} style={{ display: 'block' }}>
            {pricePerPersonText}
          </span>
          <span className="WebRupee">Rs.</span>{' '}
          <CostFormat cost={itineraryTotalCost} />
        </span>
      );
    }
  }

  agentNetCostRenderHelper() {
    let { user_details, itineraryInfo, location } = this.props;
    let {
      costed,
      staleCost,
      booking,
      frozen,
      itineraryId,
      agent,
      campaign,
      regionCode
    } = itineraryInfo.itinerary;
    let itineraryTotalCost = itineraryInfo.itinerary.netCost;

    if (
      (costed &&
        !staleCost &&
        user_details &&
        user_details.userType === 'AGENT') ||
      (agent && user_details.userType === 'ADMIN')
    ) {
      return (
        <span
          className="medium-heading text-left no-margin"
          style={{ display: 'inline-block' }}
        >
          <span className={'fine-text'} style={{ display: 'block' }}>
            Net price
          </span>
          <span className="WebRupee">Rs.</span>{' '}
          <CostFormat cost={itineraryTotalCost} />{' '}
          {campaign && regionCode === 'mle' ? <sup>*</sup> : null}
          {user_details.loggedIn &&
          user_details.userType === 'ADMIN' &&
          !booking &&
          !frozen ? (
            <a
              onClick={() =>
                this.props.history.push(
                  itineraryModalsRouteHelper({
                    itineraryId,
                    regionCode,
                    location,
                    target: RATE_MATCH_TOTAL_COST,
                    customParams: { called_from: 'TOTAL_NET_COST' }
                  })
                )
              }
            >
              {' '}
              <span className="vehoicon-mode_edit" />
            </a>
          ) : null}
        </span>
      );
    }
  }

  render() {
    let {
      itineraryInfo,
      target,
      adult_count,
      child_count,
      isFromPackages
    } = this.props;
    let itinerary = itineraryInfo.itinerary || {};
    const {itineraryId} = itinerary;

    const title = itinerary.title;
    let is_costed = itinerary.costed && !itinerary.staleCost;
    let { booking, frozen, flightsBlocked } = itinerary;

    let departure_date;
    if (is_costed && itineraryInfo.costingConfiguration) {
      let departureDate = itineraryInfo.costingConfiguration.departureDate;
      departure_date =
        departureDate && moment(departureDate, 'DD/MMM/YYYY').format('MMM DD');
    }
    
    let itineraryTitle = getItineraryTitle(this.props.itineraryInfo);

    const getInclusionsModalRoute = target => {
      return itineraryModalsRouteHelper({
        itineraryId: itineraryId,
        regionCode: itinerary.regionCode,
        location: this.props.location,
        target
      });
    };

    return <Fragment>
      <div className="itinerary-header bg-white">
        {isFromPackages ? null : (
          <Helmet>
            <title>{itineraryTitle} {itineraryId} | Book Now</title>
            <meta name={'description'} content={`${itineraryTitle}  (${itineraryId}). Build an itinerary completely suited to your taste and at the best online prices. Customize & book now.`} />
          </Helmet>
        )}

        <div className="container mobile-flush">
          <div className="row">
            <div className="padding-12 pb-0 col-xs-12">
              <div className="row">
                <div className="col-xs-12 itinerary-header-name">
                  <div className="row">
                    <div className="col-sm-8">
                      <h1 className="h3 n-kern">{itineraryTitle}</h1>
                    </div>
                    <div className="col-sm-4 text-right hidden-xs">
                      <div
                        className={'on-sticky-hide price-block mbottom-small'}
                      >
                        {this.totalCostRenderHelper()}
                        {this.agentNetCostRenderHelper()}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                  <ul
                    role={'tablist'}
                    className="itinerary-header-tabs tabs-border-btm nav nav-pills"
                  >
                    <li
                      className={target === 'itinerary' ? 'active' : ''}
                      role={'presentation'}
                    >
                      {this.props.match && this.props.match.params ? (
                        <Link
                          key={'itineraryHeaderTabView'}
                          to={{
                            pathname: itineraryModalsRouteHelper({
                              itineraryId: itinerary.itineraryId,
                              regionCode: itinerary.regionCode,
                              parentPage: routingPageType.itinerary
                            })
                          }}
                          role="tab"
                          onClick={scrollTop}
                        >
                          <span className="tab-text bold"> Itinerary</span>
                        </Link>
                      ) : null}
                    </li>
                    {is_costed ? (
                      <li
                        className={target === 'costing' ? 'active' : ''}
                        role={'presentation'}
                      >
                        <Link
                          key={'itineraryHeaderTabInclusions-tab-name'}
                          to={{
                            pathname: itineraryModalsRouteHelper({
                              itineraryId: itinerary.itineraryId,
                              regionCode: itinerary.regionCode,
                              parentPage: routingPageType.inclusion
                            })
                          }}
                          role="tab"
                          onClick={scrollTop}
                        >
                          <span className="tab-text bold">Inclusions</span>
                        </Link>
                      </li>
                    ) : null}
                  </ul>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6 text-right hidden-xs">
                  <div className={'on-sticky-show price-block'}>
                    {this.totalCostRenderHelper()}
                    {this.agentNetCostRenderHelper()}
                  </div>
                  <div className="clearfix pull-right">
                    {this.buttonRenderHelper()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div>
        {is_costed ? (
          <div key={1} className="itinerary-secodary-hdr hidden-xs">
            <div className="clearfix alert-bar itin-yellow-bar text-center">
              {booking || flightsBlocked || frozen ? (
                <span>
                  For{' '}
                  <b className="cursor-not-allowed color-primary-dark">
                    {adultsChildrenString(adult_count, child_count)}
                  </b>{' '}
                  travelling on{' '}
                  <b className="cursor-not-allowed color-primary-dark">
                    {departure_date}{' '}
                  </b>
                  {itineraryInfo.costingConfiguration &&
                  itineraryInfo.costingConfiguration.departureAirport !== '$$$'
                    ? `from `
                    : ``}
                  {itineraryInfo.costingConfiguration &&
                  itineraryInfo.costingConfiguration.departureAirport !==
                    '$$$' ? (
                    <b className="cursor-not-allowed color-primary-dark">
                      {' '}
                      {itineraryInfo.costingConfiguration.departureCity}
                    </b>
                  ) : null}
                </span>
              ) : (
                <span>
                  For{' '}
                  <Link
                    key={'getCost'}
                    to={{
                      pathname: getInclusionsModalRoute('update-cost')
                    }}
                  >
                    <b className="cursor-pointer color-primary underline">
                      {adultsChildrenString(adult_count, child_count)}
                    </b>
                  </Link>{' '}
                  travelling on{' '}
                  <Link
                    key={'itineraryHeaderTabInclusions-edit-departure-date'}
                    to={{
                      pathname: getInclusionsModalRoute('update-cost')
                    }}
                  >
                    <b className="cursor-pointer color-primary underline">
                      {departure_date}{' '}
                    </b>
                  </Link>
                  {itineraryInfo.costingConfiguration.departureAirport !== '$$$'
                    ? `from `
                    : ``}
                  <Link
                    key={'itineraryHeaderTabInclusions-destination'}
                    to={{
                      pathname: getInclusionsModalRoute('update-cost')
                    }}
                  >
                    <b className="cursor-pointer color-primary underline">
                      {' '}
                      {itineraryInfo.costingConfiguration.departureAirport !==
                      '$$$'
                        ? itineraryInfo.costingConfiguration.departureCity
                        : ''}
                    </b>
                  </Link>
                  <Link
                    key={'itineraryHeaderTabInclusions-edit-btn'}
                    to={{
                      pathname: getInclusionsModalRoute('update-cost')
                    }}
                  >
                    {' '}
                    <i className="inline-block vehoicon-mode_edit" />
                  </Link>
                </span>
              )}
            </div>
          </div>
        ) : null}
      </div>
    </Fragment>;
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      campaignItineraryId: app.itineraryInfo.campaignItineraryId,
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count,
      destination: app.pdgSelections.region,
      makeReadOnly: app.isReadOnly
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details,
      adult_count: app.itineraryInfo.adult_count,
      child_count: app.itineraryInfo.child_count,
      makeReadOnly: app.isReadOnly
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getCost: bindActionCreators(getCost, dispatch),
      changeToBooking: bindActionCreators(changeToBooking, dispatch),
      toggleSplitPricing: bindActionCreators(toggleSplitPricing, dispatch)
    }
  };
}

export default withLastLocation(
  connect(mapStateToProps, mapDispatchToProps)(ItineraryHeader)
);
