import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import classNames from 'classnames';

import _ from 'lodash';
import { manageActivity } from '../../../actions/actions_app';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';

import { AppConfig } from '../../../app-config';
import { encodeActivityKeyForURL } from '../../../helpers/utilsHelper';
import ActivityContainer from '../../../common_components/activity_container';
import {
  trackEvent,
  EVENT_ITINERARY_MODIFIED,
  EVENT_INCLUSIONS_MODIFIED
} from '../../../helpers/ML/EventsTracker';
import {
  ACTIVITY_ALTERNATES,
  itineraryModalsRouteHelper,
  ITINERARY_VIEW
} from '../../../helpers/routesHelper';

const booking_state_alert = AppConfig.booking_state_alert;

/*global swal */

class ActivityDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      activity: {},
      deleteActivity: false,
      backgroundHeight: '100vh'
    };
    this.removeButtonClickHandler = this.removeButtonClickHandler.bind(this);
    this.changeButtonClickHandler = this.changeButtonClickHandler.bind(this);
    this.handleSelectActivityHelper = this.handleSelectActivityHelper.bind(
      this
    );
    this.removeActivity = this.removeActivity.bind(this);
  }

  closeButtonRenderHelper() {
    return (
      <button
        type="button"
        onClick={() => this.props.onCloseModal()}
        className="close pull-left"
        data-dismiss="modal"
        aria-label="Close"
      >
        <i className="vehoicon-close" />
      </button>
    );
  }

  handleSelectActivityHelper(activeActivity) {
    activeActivity.handleActivityBlockClick(activeActivity.activitySlotDetail);

    this.props.onCloseModal(true);
  }

  actionsRenderHelper() {
    let { itineraryDetail, user_details, makeReadOnly } = this.props;
    let { booking } = itineraryDetail;

    if (this.props.onlyActivityDetails) {
      if (this.state.deleteActivity) {
        return (
          <div className="modal-actions">
            <button
              type="button"
              className="btn btn-sm btn-danger btn-outline remove-activity-final-ga"
              onClick={e => this.removeButtonClickHandler(e)}
            >
              <span className="vehoicon-ion-checkmark" aria-hidden="true" /> Yes
            </button>
            <button
              type="button"
              className="btn btn-sm btn-primary remove-activity-cancel-ga"
              onClick={() => this.setState({ deleteActivity: false })}
            >
              No!
            </button>
          </div>
        );
      } else {
        let { activeActivity } = this.props;

        if (activeActivity.isFromAlternateList) {
          return (
            <div className="modal-actions">
              <button
                type="button"
                className="btn btn-primary select-activity-in-details-ga"
                onClick={() => this.handleSelectActivityHelper(activeActivity)}
              >
                Add to itinerary
              </button>
            </div>
          );
        } else {
          let isAdmin = user_details && user_details.userType === 'ADMIN';
          let isAgent = user_details && user_details.userType === 'AGENT';

          let changeBlocked = booking;
          if (booking) {
            changeBlocked = !isAdmin && !isAgent;
          }

          return makeReadOnly ? null : (changeBlocked ? (
            <OverlayTrigger
              id="ot4"
              placement="top"
              overlay={<Tooltip id="acttooltip">{booking_state_alert}</Tooltip>}
            >
              <div className="modal-actions">
                <button
                  type="button"
                  className={
                    'btn btn-sm btn-danger btn-outline remove-cta  ' +
                    (changeBlocked ? 'disabled' : '')
                  }
                >
                  <span className="vehoicon-delete text-xs-only" />
                  <span className="text-md-only">Remove</span>
                </button>
                <button
                  type="button"
                  id="activity-details-change"
                  className={
                    'btn btn-primary btn-sm change-cta ' +
                    (changeBlocked ? 'disabled' : '')
                  }
                >
                  Change
                </button>
              </div>
              {/* </div> */}
            </OverlayTrigger>
          ) : (
            <div className="modal-actions">
              <button
                type="button"
                className={
                  'btn btn-sm btn-default btn-outline remove-cta  ' +
                  (changeBlocked ? 'disabled' : '')
                }
                onClick={e =>
                  changeBlocked ? null : this.removeButtonClickHandler(e)
                }
              >
                <span className="vehoicon-delete text-xs-only" />
                <span className="text-md-only">Remove</span>
              </button>
              <button
                type="button"
                id="activity-details-change"
                onClick={e => this.changeButtonClickHandler(e)}
                className={
                  'btn btn-primary btn-sm change-cta ' +
                  (changeBlocked ? 'disabled' : '')
                }
              >
                Change
              </button>
            </div>
          ));
        }
      }
    }
  }

  removeActivity() {
    let activity = this.props.activeActivity;
    let fromCityId = activity.cityId;
    let toCityId = activity.cityId;
    let activityWithTransfer = false;
    if (activity.type === 'ACTIVITY_WITH_TRANSFER') {
      fromCityId = activity.intercityTransferSlotDetailVO.fromCity;
      toCityId = activity.intercityTransferSlotDetailVO.toCity;
      activityWithTransfer = true;
    }

    let options = {
      action: 'REMOVE',
      activityWithTransfer: activityWithTransfer,
      itineraryId: this.props.itineraryDetail.itineraryId,
      activitySlot: activity,
      fromCityId: fromCityId,
      toCityId: toCityId,
      cancelled:
        activity.activitySlotDetail.costingInfo &&
        activity.activitySlotDetail.costingInfo.cancelled
    };

    const isInclusions =
      window &&
      window.location &&
      (window.location.pathname || '').includes('/inclusions/');
    trackEvent(
      isInclusions ? EVENT_INCLUSIONS_MODIFIED : EVENT_ITINERARY_MODIFIED,
      {	
        activity_removed: true
      }	
    );

    // this.setState({ deleteActivity: false });
    this.props.actions
      .manageActivity(options)
      .then(() => {
        this.props.onCloseModal(true, true);
      })
      .catch(() => {
        this.props.onCloseModal(true, true);
      });
  }

  removeButtonClickHandler(event) {
    event.preventDefault();

    let _this = this;
    if (
      this.props.activeActivity.activitySlotDetail.costingInfo !== undefined
    ) {
      if (this.props.activeActivity.activitySlotDetail.costingInfo.inCombo) {
        swal(
          {
            title: 'This will remove your Combo Package savings',
            text:
              'Are you sure you want to remove this activity? You might lose huge amount of savings!',
            animation: true,
            showCancelButton: true,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Ok, Continue',
            cancelButtonText: "No, Don't remove this activity",
            closeOnConfirm: true,
            closeOnCancel: true
          },
          function(isConfirm) {
            if (isConfirm) {
              _this.removeActivity();
            }
          }
        );
      } else if (
        this.props.activeActivity.activitySlotDetail.costingInfo.inSwissPass
      ) {
        swal(
          {
            title: 'This will reduce your Swiss Pass savings',
            text:
              'Are you sure you want to remove this activity? You might lose huge amount of savings!',
            animation: true,
            showCancelButton: true,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Ok, Continue',
            cancelButtonText: "No, Don't remove this activity",
            closeOnConfirm: true,
            closeOnCancel: true
          },
          function(isConfirm) {
            if (isConfirm) {
              _this.removeActivity();
            }
          }
        );
      } else {
        _this.removeActivity();
      }
    } else {
      _this.removeActivity();
    }
  }

  changeButtonClickHandler(event) {
    event.preventDefault();

    const { history, location, match, itineraryDetail } = this.props;
    const slotIdentifier = match.params.activityKey;
    const activityKey = encodeActivityKeyForURL(slotIdentifier);
    const { itineraryId, regionCode } = itineraryDetail;

    if (location.pathname.indexOf(ITINERARY_VIEW) > 0) {
      trackEvent(EVENT_ITINERARY_MODIFIED, {
        activity_changed: true
      });
      history.push(
        itineraryModalsRouteHelper({
          itineraryId,
          regionCode,
          target: ACTIVITY_ALTERNATES,
          customParams: {
            activityKey
          }
        })
      );
    } else {
      trackEvent(EVENT_INCLUSIONS_MODIFIED, {	
        activity_changed: true	
      });
      history.push(
        itineraryModalsRouteHelper({
          itineraryId,
          regionCode,
          target: ACTIVITY_ALTERNATES,
          parentPage: 'inclusions',
          customParams: {
            activityKey
          }
        })
      );
    }
  }

  activityHeaderHelper() {
    const { activeActivity } = this.props;

    return (
      <div
        className={classNames('modal-header', {
          'with-bg': !activeActivity.isFromAlternateList
        })}
      >
        {this.closeButtonRenderHelper()}
        <span className="caps-text semi-bold kern-more fade">Activity</span>
        {this.actionsRenderHelper()}
      </div>
    );
  }

  render() {
    let { activeActivity, location } = this.props;

    if (_.isEmpty(activeActivity)) {
      return (
        <div className={`modal-dialog`}>
          <div className={'modal-content with-header'}>
            <div className={'row'}>
              <div
                className={'col-xs-12 text-center'}
                style={{ height: '200px' }}
              >
                <div className="clearfix">
                  <div className="loading-dots" />
                  <div className="loading-dots" />
                  <div className="loading-dots" />
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className={`modal-dialog`}>
        <div className={'modal-content with-header'}>
          {this.activityHeaderHelper()}

          <div className="modal-body">
            <ActivityContainer
              location={location}
              showImages={true}
              activeActivity={activeActivity}
              splitPricing={this.props.itineraryDetail.splitPricing}
              allowEditOptions={true}
            />
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {};
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      manageActivity: bindActionCreators(manageActivity, dispatch)
      // cancelViatorActivity: bindActionCreators(cancelViatorActivity, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(ActivityDetails);
