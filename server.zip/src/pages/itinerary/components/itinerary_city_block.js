import React, { Component } from 'react';
import _ from 'lodash';

// import PropTypes from 'prop-types';
import ItineraryCityHead from './itinerary_city_head';
import ItineraryCityBody from './itinerary_city_body';
import ItineraryCityLinkRow from './itinerary_city_link_row_new';

export default class ItineraryCityBlock extends Component {
  // static propTypes = {
  //   openModal: PropTypes.func.isRequired,
  // };

  render() {
    let daysInCity = this.props.city.days;
    const makeReadOnly = this.props.makeReadOnly;
    let currentlyAddingDay = this.props.addingDayAfter;
    let allDayIdentifiers = _.map(daysInCity, 'dayIdentifier');
    let addDayIndex = _.indexOf(allDayIdentifiers, currentlyAddingDay);
    if (addDayIndex > -1) {
      let newDayObj = {
        dayIdentifier: 'new_day_in_' + this.props.city.cityId,
        type: 'new_day_placeholder'
      };

      daysInCity.splice(addDayIndex + 1, 0, newDayObj);
    }

    return (
      <div>
        <ItineraryCityLinkRow
          {...this.props}
          prevCityKey={this.props.prevCity.cityKey}
          cityKey={this.props.city.cityKey}
          key={this.props.city.transferSlot}
          data={this.props.city.transferSlotDetails}
        />

        <div className="city-block">
          <div className="content-box">
            <ItineraryCityHead
              {...this.props}
              key={this.props.city.cityKey + '_head'}
              makeReadOnly={makeReadOnly}
            />

            <ItineraryCityBody
              key={this.props.city.cityKey + '_body'}
              {...this.props}
              daysInCity={daysInCity}
            />
          </div>
        </div>
      </div>
    );
  }
}
