import React, { Component } from 'react';
import _ from 'lodash';

export default class InlineConfirmBox extends Component {
  constructor(props) {
    super(props);

    this.state = {
      defaultBoxType: 'confirm-danger',
      defaultClsName: 'hidden',
      text: 'Are you sure?',
      show: false,
      close: false
    };

    this.onClose = this.onClose.bind(this);
  }

  onClose() {
    let _this = this;
    _this.setState({ close: true });

    setTimeout(function() {
      _this.setState({ close: false });
      _this.props.onCancel();
    }, 600);
  }

  render() {
    let boxType = this.state.defaultBoxType;
    if (_.has(this.props, 'boxType')) {
      boxType = this.props.boxType;
    }

    let show = '';
    if (_.has(this.props, 'show')) {
      show = this.props.show;
    }

    let text = this.state.text;
    if (_.has(this.props, 'text')) {
      text = this.props.text;
    }

    let clsName = this.state.defaultClsName;
    if (!this.state.close) {
      if (show) {
        clsName = 'fadeIn';
      } else {
        clsName = 'hidden';
      }
    } else {
      clsName = 'fadeOut';
    }

    return (
      <div
        className={
          'animated inline-confirm confirm-white ' + boxType + ' ' + clsName
        }
      >
        <div className="alert-content">
          <span className="block white medium-bold line-height-1-5">
            {text}
          </span>
          <div className="confirm-actions">
            <button
              type="button"
              onClick={() => this.onClose()}
              className="btn btn-sm btn-primary-dark btn-outline"
            >
              No!
            </button>{' '}
            <button
              type="button"
              onClick={() => this.props.onConfirm()}
              className="btn btn-sm btn-danger"
            >
              <span className="vehoicon-ion-checkmark" aria-hidden="true" /> Yes
            </button>
          </div>
        </div>
      </div>
    );
  }
}
