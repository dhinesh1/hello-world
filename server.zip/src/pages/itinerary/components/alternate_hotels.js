import React, { Component } from 'react';
import classNames from 'classnames';
import { withRouter } from 'react-router-dom';
import _ from 'lodash';
import axios from 'axios';
import { TripAdvisorRating } from '../../../common_components/Components';
import StarRating from '../../../common_components/StarRating';
import PriceDiff from '../../../common_components/price_diff';
import SmartImage from '../../../common_components/Image/smart_image';
import placeHolderUrls from '../../../common_components/Image/place_holder_urls';

import { AppConfig } from '../../../app-config';
const API_URL = AppConfig.api_url;
const images_cdn_misc_url = AppConfig.images_cdn_misc_url;
/*global swal */

class AlternateHotels extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hotelsReported: [],
      element_status: '',
      header_text: 'Available hotel options to choose from'
    };
    this.showLoading = this.showLoading.bind(this);
    this.hideLoading = this.hideLoading.bind(this);
    this.reportHotel = this.reportHotel.bind(this);
  }

  componentDidUpdate(prevProps) {
    if (this.props.hotelList.length !== prevProps.hotelList.length) {
      this.hideLoading();
    } else {
      if (_.isEqual(this.props, prevProps)) {
      } else {
        this.hideLoading();
      }
    }
  }

  onViewDetailsClick(hotelDetails) {
    let {
      history,
      location,
      currentPickHotel,
      itineraryId,
      regionCode,
      match
    } = this.props;

    this.props.openHotelsFromAlternates({
      currentPickHotel: currentPickHotel,
      selectedHotel: hotelDetails,
      cacheKey: this.props.alternateHotels.cacheKey,
      history: history,
      location: location,
      itineraryId,
      regionCode,
      hotelKey: match.params.hotelKey
    });
  }

  hideLoading() {
    this.setState({
      element_status: '',
      header_text: 'Available hotel options to choose from'
    });
  }

  showLoading() {
    this.setState({
      element_status: 'LOADING',
      header_text: 'Updating results based on your filters...'
    });
  }

  reportHotel(hotel, e) {
    e.stopPropagation();
    let _this = this;
    swal(
      {
        title: 'Report Hotel!',
        text:
          'Are you sure you want to report this hotel? It will not come in any search results after this.',
        // imageUrl: '/images/cost_error.png',
        animation: true,
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: 'Yes, report',
        cancelButtonText: 'Cancel',
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm) {
        if (isConfirm) {
          let url = `${API_URL}hotel/${hotel.hotelCode}/reportHotel`;
          axios.get(url).then(() => {
            let hotelsReported = _this.state.hotelsReported;
            hotelsReported.push(hotel.hotelCode);
            _this.setState({ hotelsReported: hotelsReported });
          });
        }
      }
    );
  }

  alternateHelper(hotelList) {
    let { hotelsReported } = this.state;
    let { userDetails, currentPickHotel, isLoading } = this.props;
    // console.log(userDetails);
    let is_islandHopper =
      currentPickHotel && currentPickHotel.sourceProvider === 'ISLANDHOPPER';

    if (hotelList !== undefined) {
      return hotelList.map((hotel, i) => {
        hotel.offlineHotels = this.props.offlineHotels;
        if (hotelsReported.indexOf(hotel.hotelCode) !== -1) {
          return null;
        }

        let discountBadge = null;
        if (hotel.discountPercentage > 0) {
          discountBadge = (
            <div className="discount-badge">
              <span className="percentage">{hotel.discountPercentage}%</span>
              <span className="off-text">OFF</span>
            </div>
          );
        }

        // let $el = $('<div />').html(hotel.location);
        // let hotel_location = $($el).text();
        let hotel_location = hotel.location;
        const isAdmin = userDetails &&
        userDetails.loggedIn &&
        userDetails.userType === 'ADMIN';
        const AOTpills = hotel && hotel.ourSourceProviders ? hotel.ourSourceProviders.map((item) => {
          return <figcaption
            className={'stars inverse text-right bold'}><span className={"pill color-white bg-accent-4"}>{item}</span>
          </figcaption>
        }) : [];

        return (
          <div
            onClick={e => this.onViewDetailsClick(hotel)}
            key={i}
            className="col-xs-12 col-sm-6 col-md-4"
          >
            <article data-key={hotel.hotelCode} className="data-option-item">
              {isAdmin? (
                <div
                  className="report-hotel small"
                  onClick={e => this.reportHotel(hotel, e)}
                >
                  <a className="btn pill warning">Report</a>
                </div>
              ) : null}
              <div
                className={classNames(
                  'data-option-item-wrapper single-alternate-hotel-option',
                  {
                    active: isLoading === hotel.hotelCode
                  }
                )}
              >
                {this.props.splitPricing ? discountBadge : null}
                <div className="media-shell">
                  <figure className="sd with-text">
                    <SmartImage
                      src={hotel.imageURL}
                      alt={hotel.name}
                      disableLazyLoad={true}
                      defaultImage={placeHolderUrls.hotelMedium}
                    />
                    <StarRating
                      rating={hotel.stars}
                      fillEmpty={false}
                      insideFigure={true}
                    />
                    {isAdmin && AOTpills.length? AOTpills : null}
                    </figure>
                </div>
                <div className="data-option-details">
                  <h6 className="title">{hotel.name}</h6>
                  <div className="col-xs-8 col-md-8 meta">
                    <span className="dim truncate">{hotel_location}</span>
                  </div>
                  <div className="col-xs-4 col-md-4 price">
                    {hotel.finalPrice ? (
                      <span className="block">
                        <span className="WebRupee">Rs.</span>
                        {hotel.finalPrice}
                      </span>
                    ) : null}
                    {hotel.diffDetail && hotel.diffDetail.diffCost ? (
                      <PriceDiff diff={hotel.diffDetail} classNames={'block'} />
                    ) : null}
                  </div>
                  <div className="col-xs-8 col-md-8 clear-padding">
                    {is_islandHopper ? null : (
                      <TripAdvisorRating
                        rating={hotel.tripAdvisorRating}
                        fillEmptyCircle={true}
                      />
                    )}
                  </div>
                  <div className="col-xs-4 col-md-4 action">
                    <a
                      className={classNames(
                        'btn btn-xs btn-primary hotel-choose-button hidden-sm hidden-xs',
                        {
                          'progress-btn': isLoading
                        }
                      )}
                      onClick={e => {
                        this.props.handleSelectedAlternateHotel(hotel, e);
                      }}
                    >
                      {isLoading ? <span className={'progress-bg'} /> : null}
                      <span className={'btn-txt'}>Choose</span>
                    </a>
                    <a
                      className={classNames(
                        'btn btn-sm btn-primary hotel-choose-button show-xs-sm',
                        {
                          'progress-btn': isLoading
                        }
                      )}
                      onClick={e => {
                        this.props.handleSelectedAlternateHotel(hotel, e);
                      }}
                    >
                      {isLoading ? <span className={'progress-bg'} /> : null}
                      <span className={'btn-txt'}>Choose</span>
                    </a>
                  </div>
                </div>
              </div>
            </article>
          </div>
        );
      });
    } else {
      return <div>s</div>;
    }
  }

  render() {
    let { alternateHotels, currentPick } = this.props;

    let content = (
      <div className="col-xs-12 text-center">
        <br />
        <img
          className="no-alternates-illustrartion"
          src={images_cdn_misc_url + 'not_found_icon.png'}
          alt="Not found"
        />
      </div>
    );

    let header_text = (
      <span className={'meta-text'}>
        Oops! No other hotels found for the applied filters
      </span>
    );
    if (this.props.hotelList.length > 0) {
      content = this.alternateHelper(this.props.hotelList); //alternate hotel cards
    }

    if (this.props.loadingStatus === 'FILTERING') {
      header_text = 'Fetching hotels based on your filters...';
      content = (
        <div className="col-xs-12 text-center">
          <div className="inline-block block-center vmargin-large">
            <div className="clearfix">
              <div className="loading-dots" />
              <div className="loading-dots" />
              <div className="loading-dots" />
            </div>
          </div>
        </div>
      );
    } else {
      if (this.props.hotelList.length > 0) {
        header_text = `Showing 1 to ${this.props.hotelList.length} of ${
          alternateHotels.totalResultsWithFilters
        } available options to choose from ${
          alternateHotels.totalResultsWithFilters !==
          alternateHotels.totalResultsWithoutFilters
            ? `(filtered from ${
                alternateHotels.totalResultsWithoutFilters
              } alternates)`
            : ''
        }`;
      } else if (this.props.lastRequestType !== 'WITH_FILTER') {
        header_text = (
          <span className={'meta-text'}>Oops! No hotel options found.</span>
        );
      }
    }

    let loadMoreLink =
      this.props.moreAvailable && this.props.loadingStatus !== 'FILTERING' ? (
        <div className="col-xs-12 text-center" id="load-more-link">
          <a
            onClick={() => this.props.loadMore()}
            className="txt-primary text-center cursor-pointer"
          >
            Load more
          </a>
        </div>
      ) : null;

    return (
      <div
        className={classNames('modal-row ', {
          'pt-0': currentPick && currentPick.status !== 'SUCCESS'
        })}
      >
        <span className="block dim text-center vmargin-medium meta-text">
          {header_text}
        </span>
        <section className="change-data grid-list">
          <div className={'row'}>
            {content}
            {loadMoreLink}
          </div>
        </section>
      </div>
    );
  }
}

export default withRouter(AlternateHotels);
