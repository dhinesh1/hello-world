import React, { Component } from 'react';
import _ from 'lodash';

import Totem from './itinerary_totem';
import { minutesToStr } from '../../../helpers/utilsHelper';

export default class ItineraryCityLinkRow extends Component {
  constructor(props) {
    super(props);

    // this.renderTotem = this.renderTotem.bind(this);
    this.handleInterCityTransferClick.bind(this);
    this.transferTextHelper.bind(this);
  }

  getTransferIcon(transferMode) {
    switch (transferMode) {
      case 'RENTALCAR':
      case 'CAR':
        return 'vehoicon-directions_car';
      case 'TRAIN': {
        return 'vehoicon-train';
      }
      case 'FERRY': {
        return 'vehoicon-directions_boat';
      }
      case 'BUS': {
        return 'vehoicon-directions_bus';
      }
      case 'FLIGHT': {
        return 'vehoicon-flight';
      }
      default:
        return 'vehoicon-directions_bus';
    }
  }

  getTransferDate(transfer_obj) {
    if (this.props.isCosted && !this.props.staleCost) {
      if (
        this.props.data.type !== 'INTERNATIONAL_ARRIVE' &&
        this.props.data.type !== 'INTERNATIONAL_DEPART'
      ) {
        return (
          <div
            className="text-center day-number-container column"
            data-new-row="true"
          >
            <span className="label">
              {transfer_obj.dayRef ? transfer_obj.dayRef.mon : ''}
            </span>
            <br />
            <span className="day-number">
              {transfer_obj.dayRef ? transfer_obj.dayRef.day : ''}
            </span>
          </div>
        );
      }
    }
  }

  getDisplayIconText() {
    let transfer_obj = this.props.data;
    const { costingInfo  = {} } = transfer_obj;
    const isUserRemoved = costingInfo.status === "USER_REMOVED";
    let transfer_info = this.transferTextHelper(transfer_obj);
    let transfer_cost = transfer_info && transfer_info.transfer_cost;
    let inCombo = false;
    let inSwissPass = false;

    let transfer_slot_text = 'Transfer Text',
      transfer_icon = this.getTransferIcon('FLIGHT'),
      transit_icon = false;

    switch (transfer_obj.type) {
      case 'INTERNATIONAL_ARRIVE':
        transfer_slot_text =
          transfer_obj.arrivalSlotDetail.transferIndicatorText;
        break;
      case 'INTERNATIONAL_DEPART':
        transfer_slot_text =
          transfer_obj.departureSlotDetail.transferIndicatorText;
        break;
      case 'ACTIVITY_WITH_TRANSFER':
      case 'INTERCITY_TRANSFER':
        if (
          transfer_obj.intercityTransferSlotDetailVO.transferType === 'DIRECT'
        ) {
          transfer_slot_text =
            transfer_obj.intercityTransferSlotDetailVO.directTransferDetail
              .transferIndicatorText;
          transfer_icon = this.getTransferIcon(
            transfer_obj.intercityTransferSlotDetailVO.directTransferDetail
              .transferMode
          );
        } else if (
          transfer_obj.intercityTransferSlotDetailVO.transferType === 'TRANSIT'
        ) {
          transfer_slot_text =
            transfer_obj.intercityTransferSlotDetailVO.transitTransferDetail
              .transferIndicatorText;
          let arrivalTransit =
            transfer_obj.intercityTransferSlotDetailVO.transitTransferDetail
              .arrivalTransit;
          let arrivalTransitMode = arrivalTransit
            ? arrivalTransit.transitMode
            : 'TRAIN';
          let arrival_icon = this.getTransferIcon(arrivalTransitMode);

          let departTransit =
            transfer_obj.intercityTransferSlotDetailVO.transitTransferDetail
              .departTransit;
          let departTransitMode = departTransit
            ? departTransit.transitMode
            : 'TRAIN';
          let depart_icon = this.getTransferIcon(departTransitMode);

          transfer_icon = (
            <span className="icon-group">
              <span className={'icon white ' + arrival_icon} />
              <span className={'icon white ' + depart_icon} />
            </span>
          );
          transit_icon = true;
        } else {
          transfer_slot_text = 'inter city transfer text';
        }
        break;
      default:
        transfer_slot_text = 'transfer text';
    }

    let transfer_icon_ele = <span className={`icon white ${!isUserRemoved ?  transfer_icon : 'vehoicon-transfer'}`} />;
    if (transit_icon) {
      transfer_icon_ele = transfer_icon;
    }

    if (transfer_obj.costingInfo !== undefined) {
      inCombo = transfer_obj.costingInfo.inCombo;
      inSwissPass = transfer_obj.costingInfo.inSwissPass;
    }

    return (
      <div className="col-xs-12 col-sm-12 event-slot extra-spaced no-hover-color">
        <div className="transfer-image-shell">{transfer_icon_ele}</div>
        <p className={`meta-text bold ${isUserRemoved ? 'hide' : ''}`}>
          {transfer_slot_text}
          {transfer_info &&
          transfer_obj.type !== 'INTERNATIONAL_DEPART' &&
          !inCombo &&
          !inSwissPass &&
          this.props.isCosted &&
          !this.props.staleCost &&
          transfer_cost ? (
            <span className="fine-text normal fade spaced">
              <span className="color-primary">
                <span className="WebRupee">Rs.</span> {transfer_cost}
              </span>
            </span>
          ) : null}
        </p>
      </div>
    );
  }

  transferTextHelper(transfer_obj) {
    let transfer_text = '',
      transfer_duration = 0,
      transfer_cost = 0;

    if (this.props.isCosted && !this.props.staleCost) {
      switch (transfer_obj.type) {
        case 'INTERNATIONAL_ARRIVE':
          if (
            !transfer_obj.costingInfo ||
            (transfer_obj.costingInfo &&
              transfer_obj.costingInfo.status !== 'SUCCESS')
          ) {
            return null;
          }
          let trip_info =
            transfer_obj.costingInfo.trips[
              transfer_obj.arrivalSlotDetail.tripKey
            ];

          let stops = '';
          if (trip_info) {
            let trip_length = trip_info.routes.length - 1;

            if (trip_length === 0) stops = 'Direct';
            else if (trip_length === 1) stops = `${trip_length} stop`;
            else stops = `${trip_length} stops`;
          }

          transfer_duration = trip_info ? minutesToStr(trip_info.duration) : '';
          transfer_text = transfer_duration + ', ' + stops;
          transfer_cost = transfer_obj.costingInfo.price;
          break;
        case 'INTERNATIONAL_DEPART':
          transfer_text =
            transfer_obj.departureSlotDetail.transferIndicatorText;
          break;
        case 'INTERCITY_TRANSFER':
          transfer_text = transfer_obj.costingInfo
            ? _.isNumber(transfer_obj.costingInfo.duration)
              ? minutesToStr(transfer_obj.costingInfo.duration)
              : transfer_obj.costingInfo.duration
            : 'duration';
          transfer_cost = transfer_obj.costingInfo
            ? transfer_obj.costingInfo.totalCost
            : 0;

          break;
        case 'ACTIVITY_WITH_TRANSFER':
          transfer_text = transfer_obj.activitySlotDetail.costingInfo
            ? transfer_obj.activitySlotDetail.costingInfo.cityText
            : 'duration';
          transfer_cost = transfer_obj.activitySlotDetail.costingInfo
            ? transfer_obj.activitySlotDetail.costingInfo.totalCost
            : null;
          break;
        default:
          transfer_text = 'transfer text';
      }
    }

    return { transfer_text: transfer_text, transfer_cost: transfer_cost };
  }

  handleInterCityTransferClick(type) {
    if (type.type === 'INTERNATIONAL_ARRIVE') {
      this.props.showThisModal(
        'flight_details_modal',
        this.props.data.costingInfo
      );
    } else if (
      type.intercityTransferSlotDetailVO.directTransferDetail.transferMode ===
      'TRAIN'
    ) {
      this.props.showThisModal('trainDetailsModal', {
        ...this.props.data.costingInfo,
        called_from: 'ITINERARY_PAGE'
      });
    } else {
      this.props.showThisModal(
        'flight_details_modal',
        this.props.data.costingInfo
      );
    }
  }

  renderTotem() {
    if (
      this.props.data.type !== 'INTERNATIONAL_ARRIVE' &&
      this.props.data.type !== 'INTERNATIONAL_DEPART' &&
      this.props.data.intercityTransferSlotDetailVO &&
      this.props.data.intercityTransferSlotDetailVO.alternateModesAvailable
    ) {
      return (
        <Totem
          dayIndex={0}
          {...this.props}
          key={'transfer_totem_' + this.props.cityKey}
          totemFor="INTERCITY"
          target={Object.assign(this.props.city, {
            prevCityKey: this.props.prevCityKey
          })}
        />
      );
    }
  }

  render() {
    let transferObject = this.props.data;

    return (
      <div className="transfer">
        <div key={Math.random()} className="unit-row totem-on-hover">
          {this.renderTotem()}
          <div
            className={
              'column-meta ' +
              (transferObject.type === 'INTERNATIONAL_ARRIVE'
                ? 'top-row'
                : 'transfer')
            }
          >
            {this.getTransferDate(transferObject)}
          </div>

          <div className="transfer-wrapper transfer">
            <div className="row row-main">{this.getDisplayIconText()}</div>
          </div>
        </div>
      </div>
    );
  }
}
