import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import classNames from 'classnames';

import InlineConfirmBox from '../components/inline_confirm_box';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';

import { AppConfig } from '../../../app-config';
import {
  decodeActivityKeyFromURL,
  encodeActivityKeyForURL
} from '../../../helpers/utilsHelper';
import { addDayInCity, removeDayInCity } from '../../../actions/actions_app';
import { trackEvent, EVENT_ITINERARY_MODIFIED } from '../../../helpers/ML/EventsTracker';
import {itineraryModalsRouteHelper, ENABLE_TOTEM, ALTERNATE_TRANSFER_MODE} from '../../../helpers/routesHelper';

const booking_state_alert = AppConfig.booking_state_alert;
const IMAGE_CDN_BASE = AppConfig.imgix_base;

class Totem extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showConfirm: '',
      onConfirmText:
        'This will remove activities planned for this day. Continue?',
      currentOption: {},
      addDayAlert: false,
      removeDayAlert: false,
      clearAllAlerrt: false,
      enableTotem: false
    };

    this.totemRenderHelper = this.totemRenderHelper.bind(this);
    this.manageTotemClick = this.manageTotemClick.bind(this);
    this.onConfirmClick = this.onConfirmClick.bind(this);
    this.onCancelClick = this.onCancelClick.bind(this);
  }

  componentDidMount() {
    this.checkOverlayStatus();
  }

  componentDidUpdate() {
    this.checkOverlayStatus();
  }

  checkOverlayStatus() {
    let { match, target } = this.props;

    // if(match.params.dayIdentifier === target.dayIdentifier){
    //   onceModalOpened();
    // }
  }

  manageTotemClick(options, e) {
    e.preventDefault();

    switch (options.action_target) {
      case 'DAY':
        options.cityId = this.props.city.cityId;
        let day = this.props.target;

        if (options.action === 'REMOVE') {
          trackEvent(EVENT_ITINERARY_MODIFIED, {
            night_removed: true
          });
          if (day.slots.length === 1 && day.slots[0].type === 'LEISURE') {
            this.props.actions
              .removeDayInCity({
                itineraryId: this.props.itineraryInfo.itinerary.itineraryId,
                cityId: options.cityId,
                dayIdentifier: options.dayIdentifier
              })
              .then(() => {})
              .catch(() => {});
          } else {
            let confirmText =
              this.props.isCosted && !this.props.staleCost
                ? 'This will remove activities planned for this day and may update your itinerary. Continue?'
                : 'This will remove activities planned for this day. Continue?';

            this.setState({
              showConfirm: true,
              onConfirmText: confirmText,
              currentOption: options
            });
          }
          this.handleRowTotemCloseClick();
        } else {
          trackEvent(EVENT_ITINERARY_MODIFIED, {	
            night_added: true
          });
          this.props.actions
            .addDayInCity({
              itineraryId: this.props.itineraryInfo.itinerary.itineraryId,
              cityId: options.cityId,
              dayIdentifier: options.dayIdentifier
            })
            .then(() => {
              this.handleRowTotemCloseClick();
            })
            .catch(() => {
              this.handleRowTotemCloseClick();
            });
        }
        break;
      case 'TRANSFER':
        if (options.action === 'CHANGE') {
          trackEvent(EVENT_ITINERARY_MODIFIED, {	
            transfer_changed: true	
          });
          // this.handleRowTotemCloseClick();
          let { history, match, cityKey, prevCityKey } = this.props;

          history.push(
            itineraryModalsRouteHelper(
              {
                itineraryId: match.params.itineraryId,
                regionCode: match.params.searchRegion,
                target: ALTERNATE_TRANSFER_MODE,
                customParams: {
                  transferMode: options.transfer.directTransferDetail.transferMode,
                  prevCityKey,
                  cityKey
                }
              }
            )
          )
        }
        break;
      default:
        break;
    }
  }

  totemRenderHelper() {
    let is_hidden = '';
    let city = '';
    let { match, target, totemFor } = this.props;

    switch (totemFor) {
      case 'DAY':
        let day = this.props.target;
        is_hidden = this.props.dayIndex === 0 ? 'hidden' : '';

        return (
          <ul
            className={classNames('day-totem-options-container ', {
              show:
                match && match.params && match.params.dayIdentifier
                  ? match.params.dayIdentifier === target.dayIdentifier
                  : false
            })}
          >
            <li
              onClick={e =>
                this.manageTotemClick(
                  {
                    action_target: 'DAY',
                    action: 'ADD',
                    dayIdentifier: day.dayIdentifier
                  },
                  e
                )
              }
              className="btn-add-night totem-add-night fine-text"
            >
              <img
                src={`${IMAGE_CDN_BASE}/images/icons/icon-add-night.png`}
                alt={'add night'}
              />
              Add Night
            </li>
            <li
              onClick={e =>
                this.manageTotemClick(
                  {
                    action_target: 'DAY',
                    action: 'REMOVE',
                    dayIdentifier: day.dayIdentifier
                  },
                  e
                )
              }
              className={
                'totem-remove-night btn-remove-night fine-text ' + is_hidden
              }
            >
              <img
                src={`${IMAGE_CDN_BASE}/images/icons/icon-remove-night.png`}
                alt={'remove night'}
              />
              Remove Night
            </li>
          </ul>
        );
      case 'INTERCITY':
        city = this.props.target;
        let transfer_obj =
          city.transferSlotDetails.intercityTransferSlotDetailVO;

        return (
          <ul
            className={classNames('day-totem-options-container ', {
              show:
                match && match.params && match.params.dayIdentifier
                  ? decodeActivityKeyFromURL(match.params.dayIdentifier) ===
                    target.transferSlot
                  : false
            })}
          >
            <li
              onClick={e =>
                this.manageTotemClick(
                  {
                    action_target: 'TRANSFER',
                    action: 'CHANGE',
                    transfer: transfer_obj,
                    prevCityKey: city.prevCityKey,
                    nextCityKey: city.cityKey
                  },
                  e
                )
              }
              className="btn-add-night totem-add-night fine-text"
            >
              <img
                src={`${IMAGE_CDN_BASE}/images/icons/icon-edit-city.png`}
                alt={'edit transfer'}
              />
              Change Transfer
            </li>
          </ul>
        );
      default:
        break;
    }
  }

  onConfirmClick() {
    let options = this.state.currentOption;

    this.props.actions.removeDayInCity({
      itineraryId: this.props.itineraryInfo.itinerary.itineraryId,
      cityId: options.cityId,
      dayIdentifier: options.dayIdentifier
    });

    this.setState({ showConfirm: false });
  }

  onCancelClick() {
    this.setState({ showConfirm: false });
  }

  handleRowTotemClick(e) {
    e.preventDefault();

    if (this.props.isBooked || this.props.makeReadOnly) {
      return false;
    } else {
      const { history, location, target, totemFor, itineraryInfo } = this.props;
      const {itineraryId, regionCode} = itineraryInfo.itinerary;

      if (totemFor === 'INTERCITY') {
        const encodedKey = encodeActivityKeyForURL(target.transferSlot);

        history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            target: ENABLE_TOTEM,
            customParams: {
              dayIdentifier: encodedKey
            }
          })
        );
      } else {
        history.push(
          itineraryModalsRouteHelper({
            itineraryId,
            regionCode,
            target: ENABLE_TOTEM,
            customParams: {
              dayIdentifier: target.dayIdentifier
            }
          })
        );
      }
    }
  }

  handleRowTotemCloseClick() {
    const { history, itineraryInfo } = this.props;
    const {itineraryId, regionCode} = itineraryInfo.itinerary;

    history.replace(
      itineraryModalsRouteHelper({
        itineraryId,
        regionCode
      })
    );
  }

  render() {
    const {isBooked, makeReadOnly} = this.props;
    let { showConfirm } = this.state;
    let { match, target, totemFor } = this.props;

    return (
      <div
        className={classNames('totem-wrap', totemFor.toLowerCase(), {
          'confirm-active': showConfirm,
          'totem-active':
            match && match.params && match.params.dayIdentifier
              ? totemFor === 'INTERCITY'
                ? decodeActivityKeyFromURL(match.params.dayIdentifier) ===
                  target.transferSlot
                : match.params.dayIdentifier === target.dayIdentifier
              : false
        })}
      >
        <InlineConfirmBox
          text={this.state.onConfirmText}
          onConfirm={this.onConfirmClick}
          onCancel={this.onCancelClick}
          show={this.state.showConfirm}
        />

        {isBooked ? (
          <OverlayTrigger
            placement="top"
            overlay={<Tooltip id="tottooltip">{booking_state_alert}</Tooltip>}
          >
            <div
              className={'row-totem animated-medium-fast zoomIn totem-disabled'}
            >
              <div
                onClick={e => this.handleRowTotemClick(e)}
                className="text-center edit-icon"
              >
                <i className="vehoicon-mode_edit" />
              </div>
            </div>
          </OverlayTrigger>
        ) : (
          !makeReadOnly ? <div
            className={
              'row-totem animated-medium-fast zoomIn ' +
              (isBooked ? 'totem-disabled' : '')
            }
          >
            <div
              onClick={e => this.handleRowTotemClick(e)}
              className="text-center edit-icon"
            >
              <i className="vehoicon-mode_edit" />
            </div>
          </div>
         : null)}
        <div
          className="row-totem-close"
          onClick={e => this.handleRowTotemCloseClick(e)}
        >
          <span className="vehoicon-close" />
        </div>
        {!makeReadOnly ? this.totemRenderHelper() : null}

        {match && match.params && match.params.dayIdentifier ? (
          <div
            className={classNames('modal-backdrop fade', {
              in:
                (totemFor === 'INTERCITY' &&
                  decodeActivityKeyFromURL(match.params.dayIdentifier) ===
                    target.transferSlot) ||
                (totemFor === 'DAY' &&
                  target.dayIdentifier === match.params.dayIdentifier)
            })}
          />
        ) : null}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {makeReadOnly: state.app.isReadOnly};
};

const mapDispatchToProps = dispatch => {
  return {
    actions: {
      addDayInCity: bindActionCreators(addDayInCity, dispatch),
      removeDayInCity: bindActionCreators(removeDayInCity, dispatch)
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Totem);
