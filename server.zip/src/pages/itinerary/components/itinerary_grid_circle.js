import React, { Component } from 'react';
import { getImgIXUrl, getAirlineLogo } from '../../../helpers/utilsHelper';
import SmartImage from '../../../common_components/Image/smart_image';
import LazyLoadComponent from '../../../common_components/LazyLoadComponent';

export default class ItinerarySlotCircle extends Component {
  constructor(props) {
    super(props);

    this.getTransferIcon = this.getTransferIcon.bind(this);
  }

  getTransferIcon(transferMode) {
    switch (transferMode) {
      case 'RENTALCAR':
      case 'CAR':
        return <span className="icon-in-circle vehoicon-directions_car" />;
      case 'TRAIN': {
        return <span className="icon-in-circle vehoicon-train" />;
      }
      case 'FERRY': {
        return <span className="icon-in-circle vehoicon-directions_boat" />;
      }
      case 'BUS': {
        return <span className="icon-in-circle vehoicon-directions_bus" />;
      }
      case 'SHUTTLE': {
        return <span className="icon-in-circle vehoicon-directions_bus" />;
      }
      case 'FLIGHT': {
        /**
         * TODO: Get a placeholder for missing airline code
         */
        if (this.props.slot.costingInfo) {
          if (this.props.slot.costingInfo.airlineCode) {
            const imgData = getAirlineLogo(this.props.slot.costingInfo.airlineCode);
            return (
              <SmartImage
                className="itin-cell-thumb"
                alt={imgData.name}
                src={imgData.url}
                defaultImage={imgData.default}
              />
            );
          } else {
            return <span className="icon-in-circle vehoicon-flight" />;
          }
        } else {
          return <span className="icon-in-circle vehoicon-flight" />;
        }
      }
      case 'FLIGHT_ARRIVE': {
        return <span className="icon-in-circle vehoicon-flight_land" />;
      }
      case 'FLIGHT_DEPART': {
        return <span className="icon-in-circle vehoicon-flight_takeoff" />;
      }
      case 'HOTEL': {
        return (
          <span className="icon-in-circle vehoicon-airline_seat_individual_suite" />
        );
      }
      default:
        return <span className="icon-in-circle vehoicon-flight_land" />;
    }
  }

  render() {
    let { slot, called_from, readOnly=false } = this.props;

    let transferMode = 'FLIGHT';
    switch (slot.type) {
      case 'INTERNATIONAL_ARRIVE':
        transferMode = called_from === 'link_row' ? 'FLIGHT' : 'FLIGHT_ARRIVE';
        break;
      case 'INTERNATIONAL_DEPART':
        transferMode = called_from === 'link_row' ? 'FLIGHT' : 'FLIGHT_DEPART';
        break;
      case 'ACTIVITY_WITH_TRANSFER':
        transferMode = 'CAR';
        break;
      case 'INTERCITY_TRANSFER':
        if (slot.intercityTransferSlotDetailVO.transferType === 'DIRECT') {
          transferMode =
            slot.intercityTransferSlotDetailVO.directTransferDetail
              .transferMode;
        }
        break;
      default:
        transferMode = 'FLIGHT';
    }

    if (slot.type === 'ACTIVITY') {
      return (
        <div>
          <div className="activity-image-shell top-activity">
            <LazyLoadComponent>
              <img
                alt={'main'}
                src={getImgIXUrl(slot.activitySlotDetail.mainPhoto,"w=50&h=50&auto=format")}
              />
            </LazyLoadComponent>
          </div>
        </div>
      );
    } else if (slot.type === 'HOTEL') {
      let hotel_img = <span className={this.getTransferIcon(slot.type)} />;

      if (slot.mainPhoto !== '') {
        hotel_img = (
          <img
            alt={'main'}
            className={'itin-cell-thumb'}
            src={slot.mainPhoto}
          />
        );
      }

      return <div className="circle">{hotel_img}</div>;
    } else if (slot.type === 'LEISURE') {
      if(readOnly){
        return null;
      }
      return (
        <div className="activity-image-shell top-activity">
          <span className="icon-in-circle vehoicon-add" />
        </div>
      );
    } else {
      return (
        <div className="activity-image-shell top-activity">
          {this.getTransferIcon(transferMode)}
        </div>
      );
    }
  }
}
