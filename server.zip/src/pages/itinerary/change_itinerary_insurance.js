import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import axios from 'axios';
import Collapsible from 'react-collapsible';

import PriceDiff from '../../common_components/price_diff';
import { AppConfig } from '../../app-config';
import { onceModalClosed, onceModalOpened } from '../../helpers/utilsHelper';
import { changeInsurance } from '../../actions/actions_app';
import { itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';
const API_URL = AppConfig.api_url;

/*global swal */

class ChangeItineraryInsurance extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      currentInsurance: {},
      chosenPlanId: '',
      insuranceChoice: '',
      insuranceOptions: [],
      expanded: 0
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.changeItineraryInsurance = this.changeItineraryInsurance.bind(this);
    this.costTotal = this.costTotal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.renderTotalCost = this.renderTotalCost.bind(this);
    this.renderDiffCost = this.renderDiffCost.bind(this);
    this.getCurrentDetails = this.getCurrentDetails.bind(this);

    this.onTriggerClick = this.onTriggerClick.bind(this);
  }

  onTriggerClick(index) {
    if (this.state.expanded === index) {
      index = '';
    }

    this.setState({ expanded: index });
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.insuranceCosting &&
      !Object.keys(this.state.insuranceChoice).length
    ) {
      let currentDetail =
        props.itineraryInfo.insuranceCosting.insuranceCostingById;

      this.setState(
        {
          chosenPlanId: currentDetail.planId,
          insuranceChoice: currentDetail.planId,
          currentInsurance: currentDetail
        },
        () => {
          let reqData = {
            itineraryId: props.itineraryInfo.itinerary.itineraryId,
            regionCode: currentDetail.insuranceRegion,
            chosenPlanId: currentDetail.planId
          };

          this.getInsuranceOptions(reqData);
        }
      );
    }
  }

  openModal() {
    this.setState(
      {
        showModal: true
      },
      () => {
        onceModalOpened();
      }
    );
  }

  closeModal() {
    let { history, itineraryDetail } = this.props;

    setTimeout(() => {
      this.setState({ showModal: false }, () => {
        onceModalClosed();
        history.push(
          itineraryModalsRouteHelper({
            itineraryId: itineraryDetail.itineraryId,
            regionCode: itineraryDetail.regionCode,
            parentPage: routingPageType.inclusion
          })
        );
      });
    }, 400);
  }

  getInsuranceOptions(requestPayload) {
    const url = `${API_URL}itinerary/insurance/change`;

    axios
      .post(url, requestPayload)
      .then(response => {
        this.setState({ insuranceOptions: response.data.options });
      })
      .catch(() => {
        swal('Something went wrong. Try again.');
      });
  }

  changeItineraryInsurance(updateStateOnly = true, choice = null, e) {
    e && e.preventDefault();

    if (updateStateOnly) {
      this.setState({
        insuranceChoice: choice
      });
    } else {
      this.props.actions
        .changeInsurance({
          insuranceKey: this.state.currentInsurance.insuranceKey,
          planId: this.state.insuranceChoice,
          regionCode: this.state.currentInsurance.insuranceRegion,
          include: true,
          itineraryId: this.props.itineraryDetail.itineraryId
        })
        .then(() => {
          this.closeModal();
        })
        .catch(() => {
          this.closeModal();
        });
    }
  }

  costTotal() {
    if (this.state.insuranceChoice) {
      if (this.state.chosenPlanId === this.state.insuranceChoice) {
        return this.state.currentInsurance.totalCost;
      } else {
        let matchindId = this.state.insuranceOptions.find(
          x => x.id === this.state.insuranceChoice
        );
        return matchindId.approximateCost;
      }
    } else {
      return this.state.currentInsurance.totalCost;
    }
  }

  renderDiffCost() {
    let { insuranceChoice, chosenPlanId, insuranceOptions } = this.state;

    if (chosenPlanId !== insuranceChoice) {
      let chosenIns = insuranceOptions.find(x => x.id === insuranceChoice);

      if (
        chosenIns.diffDetail &&
        chosenIns.diffDetail.diffChangeType !== 'NONE'
      ) {
        return (
          <PriceDiff
            tooltip={false}
            diff={{
              diffChangeType: chosenIns.diffDetail.diffChangeType,
              diffCost: chosenIns.diffDetail.diffCost
            }}
            classNames={'total-price base bold'}
          />
        );
      }
    }
  }

  renderTotalCost() {
    if (
      this.state.currentInsurance &&
      this.state.currentInsurance.totalCost !== undefined
    ) {
      let existingCost = parseInt(
        this.state.currentInsurance.totalCost.toString().replace(/,/g, ''),
        10
      );
      let newCost = parseInt(
        this.costTotal()
          .toString()
          .replace(/,/g, ''),
        10
      );
      let priceDiff = existingCost - newCost;
      let priceDiffDisplay = Math.abs(priceDiff);

      if (priceDiff > 0) {
        return (
          <PriceDiff
            tooltip={false}
            diff={{
              diffChangeType: 'PRICEINCREASE',
              diffCost: priceDiffDisplay
            }}
            classNames={'total-price base bold'}
          />
        );
      } else if (priceDiff < 0) {
        return (
          <PriceDiff
            tooltip={false}
            diff={{
              diffChangeType: 'PRICEDECREASE',
              diffCost: priceDiffDisplay
            }}
            classNames={'total-price base bold'}
          />
        );
        // } else {
        //   return (
        //     <span className="total-price base bold">
        //       <span className="WebRupee">Rs.</span> {existingCost}
        //     </span>
        //   );
      }
    } else {
      return null;
    }
  }

  handleKeyUp(e) {
    // let ele = this.refs.modal;
    if (e.keyCode === 27) this.closeModal();
  }

  render() {
    let {
      insuranceChoice,
      currentInsurance,
      insuranceOptions,
      expanded
    } = this.state;

    return (
      <div
        tabIndex="0"
        ref="modal"
        className={
          'modal fade modal-sticky-header alternate-modal ' +
          (this.state.showModal ? 'in' : '')
        }
      >
        <div className="modal-dialog">
          <div className={'modal-content with-header'}>
            <div className="modal-header">
              <div className="pull-right">
                <button
                  type="button"
                  className="btn btn-primary btn-sm change-cta"
                  onClick={e => this.changeItineraryInsurance(false, null, e)}
                  disabled={this.state.chosenPlanId === insuranceChoice}
                >
                  Apply
                </button>
              </div>
              <span className="caps-text semi-bold kern-more fade">
                Change Insurance
              </span>
              <button
                type="button"
                onClick={this.closeModal}
                className="close pull-left"
                data-dismiss="modal"
              >
                <i className="vehoicon-close" />
              </button>
            </div>
            {currentInsurance && Object.keys(currentInsurance).length ? (
              <div className="modal-body">
                <div className="current-pick-panel">
                  <div className="current-pick-content hotel">
                    <div className="col-xs-9 col-md-10">
                      <span className="single-line-text fade small no-margin">
                        Total travel insurance cost
                      </span>
                    </div>
                    <div className="col-xs-3 col-md-2 text-right">
                      {this.props.itineraryDetail.splitPricing ? (
                        <span className="total-price base bold">
                          <span className="WebRupee">Rs.</span>{' '}
                          {this.costTotal()}
                        </span>
                      ) : null}
                      {!this.props.itineraryDetail.splitPricing
                        ? this.renderDiffCost()
                        : null}
                    </div>
                  </div>
                </div>

                <div className="modal-row">
                  <ModalDetails
                    {...this.props}
                    changeItineraryInsurance={this.changeItineraryInsurance}
                  >
                    {insuranceOptions.map((insuranceOption, index) => (
                      <InsuranceOption
                        key={insuranceOption.id}
                        {...insuranceOption}
                        index={index}
                        expanded={expanded}
                        onTriggerClick={this.onTriggerClick}
                        selectedInsurance={insuranceChoice}
                        changeItineraryInsurance={this.changeItineraryInsurance}
                        checked={insuranceOption.id === insuranceChoice}
                      />
                    ))}
                  </ModalDetails>
                </div>
              </div>
            ) : (
              <div className="modal-body">
                <div className={'row'}>
                  <div
                    className={'col-xs-12 text-center'}
                    style={{ height: '200px' }}
                  >
                    <div className="clearfix">
                      <div className="loading-dots" />
                      <div className="loading-dots" />
                      <div className="loading-dots" />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
}

const ModalDetails = props => {
  return (
    <div className="row">
      <div className="col-xs-12">
        <h4 className="dim padding">Insurance Options</h4>
        <div className="panel-group accordions visainsurence-accordion">
          {/* "list oj-list hover-block line-height-30 border-bottom border-dark-grey"> */}
          {props.children}
        </div>
      </div>
    </div>
  );
};

const InsuranceOption = props => {
  return (
    <InsuranceAccordion
      index={props.index}
      expanded={props.expanded}
      onTriggerClick={props.onTriggerClick}
      trigger={
        <div
          className="panel-title"
          onClick={e => props.changeItineraryInsurance(true, props.id, e)}
        >
          <div className="inline-block">
            {props.checked ? (
              <span className="list-tick-round animated flipInY">
                <span className="vehoicon-ion-checkmark" />
              </span>
            ) : (
              <span className="list-numbering-round animated fadeIn">
                {props.index + 1}
              </span>
            )}
          </div>
          <div className="inline-block ">
            <span className="base">{props.name}</span>
          </div>
        </div>
      }
    >
      <ul className="small dim">
        {props.inclusions.map((inclusion, n) => (
          <Inclusions key={'Inclusion' + props.id + n} text={inclusion} />
        ))}
      </ul>
      {props.costDetails ? (
        <div className="small dim">
          <table className="table table-bordered table-hover">
            <tbody>
              <tr>
                <th className="padding-left-3">Min. Age</th>
                <th className="padding-left-20">Max. Age</th>
                <th className="padding-left-20">Cost</th>
              </tr>
              {props.costDetails &&
                props.costDetails.map(costDetail => (
                  <CostDetail
                    key={
                      costDetail.minAge + costDetail.maxAge + costDetail.cost
                    }
                    {...costDetail}
                  />
                ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </InsuranceAccordion>
  );
};

const Inclusions = props => {
  return <li>{props.text}</li>;
};

const CostDetail = props => {
  return (
    <tr className="border-top-bottom">
      <td className="padding-left-3 text-center">{props.minAge}</td>
      <td className="padding-left-20 text-center">{props.maxAge}</td>
      <td className="padding-left-20 text-center">₹{props.cost}</td>
    </tr>
  );
};

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      changeInsurance: bindActionCreators(changeInsurance, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  ChangeItineraryInsurance
);

const InsuranceAccordion = props => (
  <section className="panel panel-default">
    <Collapsible
      open={props.expanded === props.index}
      triggerTagName={'div'}
      triggerClassName={'panel-heading accordion-toggle'}
      triggerOpenedClassName={'panel-heading accordion-toggle'}
      contentInnerClassName={'panel-body'}
      handleTriggerClick={e => props.onTriggerClick(props.index)}
      trigger={props.trigger}
    >
      {props.children}
    </Collapsible>
  </section>
);
