import React, { Component } from 'react';
import PropTypes from 'prop-types';
// import modalsList from './modalsList';
import { AppConfig } from '../../app-config';
import axios from 'axios';

const API_URL = AppConfig.api_url;

/*global swal */

class EditTripCityModal extends Component {
  static propTypes = {
    isClosing: PropTypes.bool.isRequired,
    closeModal: PropTypes.func.isRequired,
    editCityMode: PropTypes.string.isRequired,
    itineraryId: PropTypes.string.isRequired,
    cityToReplace: PropTypes.number.isRequired,
    editCityOptions: PropTypes.object.isRequired,
    addCity: PropTypes.func.isRequired,
    replaceCity: PropTypes.func.isRequired,
    citySelectedToReplace: PropTypes.object.isRequired
  };

  constructor() {
    super();

    this.state = {
      modalClass: '',
      cities: [],
      citiesToShow: [],
      searchQuery: '',
      isLoading: true
    };
    this.search = this.search.bind(this);
  }

  componentWillMount() {
    const url =
      this.props.editCityMode === 'add'
        ? `${API_URL}city/options/add`
        : `${API_URL}city/${this.props.cityToReplace}/options/replace`;

    const data = this.props.editCityOptions;

    axios
      .post(url, data)
      .then(response => {
        this.setState({
          cities: response.data,
          citiesToShow: response.data,
          isLoading: false
        });
      })
      .catch(e => {
        this.setState({ isLoading: false });
        if (e.response.status === 401) {
          this.props.closeModal();
          swal({
            title: 'Sorry about this!',
            text: "You don't have permission to change other users itinerary",
            animation: true,
            showCancelButton: false,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Try again!',
            cancelButtonText: 'No, cancel!',
            closeOnConfirm: true,
            closeOnCancel: true
          });
        }
      });
  }

  componentDidMount() {
    this.setState({
      modalClass: 'in'
    });
  }

  search(event) {
    this.setState({
      searchQuery: event.target.value
    });
    if (this.state.searchQuery) {
      const searchQuery = event.target.value.toLowerCase().replace(/\s/g, '');
      const citiesToShow = this.state.cities.filter(city => {
        const name = (city.cityName + city.country)
          .toLowerCase()
          .replace(/\s/g, '');
        return name.indexOf(searchQuery) > -1;
      });
      this.setState({
        citiesToShow
      });
    } else {
      this.setState({
        citiesToShow: this.state.cities
      });
    }
  }

  render() {
    const cities = this.state.cities.filter(
      city => city.canReplace || city.canAdd
    );
    const citiesToShow = this.state.citiesToShow.filter(
      city => city.canReplace || city.canAdd
    );

    const clickClose = event => {
      if (event) event.preventDefault();
      this.props.closeModal();
    };

    const keyPressed = event => {
      if (event.keyCode === 27) {
        this.props.closeModal();
      }
    };

    return (
      <div
        tabIndex={0}
        onKeyUp={keyPressed}
        className={`edit-trip-search modal changes fade ${
          this.state.modalClass
        } ${this.props.isClosing ? 'out' : ''}`}
      >
        <div className="modal-dialog">
          <div className="modal-content with-footer">
            <div
              className={`modal-body ${
                cities.length ? '' : 'text-center vertical-center'
              }`}
            >
              <div className="modal-scroll-container">
                <div className={`modal-row ${cities.length ? '' : 'fw'}`}>
                  <div className={'row'}>
                    <div className={'col-xs-12'}>
                      {cities.length ? (
                        <div className="row search-row vertical-center">
                          <div className="col-xs-10 col-md-11 no-padding">
                            <div className="search-bar">
                              <input
                                type="text"
                                value={this.state.searchQuery}
                                onChange={this.search}
                                placeholder={`Find a city to ${
                                  this.props.editCityMode === 'add'
                                    ? 'Add'
                                    : 'Replace'
                                }`}
                              />
                            </div>
                          </div>
                          <div className="col-xs-2 col-md-1 no-padding text-right">
                            <a
                              href="#"
                              onClick={clickClose}
                              className={`tracking-cancel-${
                                this.props.editCityMode
                              }-city-modal`}
                            >
                              Cancel
                            </a>
                          </div>
                        </div>
                      ) : null}

                      {citiesToShow.length || this.state.isLoading ? (
                        <div className="search-results">
                          {this.props.editCityMode === 'add' ||
                          this.state.isLoading ? (
                            this.props.editCityOptions.entry ||
                            this.props.editCityOptions.exit ? (
                              <p>
                                Listing cities that have international airports
                                for you to fly back to your country
                              </p>
                            ) : (
                              <p>
                                Showing cities that can be connected to the
                                current cities
                              </p>
                            )
                          ) : (
                            <p>{`Our recommendations for cities to replace ${
                              this.props.citySelectedToReplace.cityName
                            } with:`}</p>
                          )}
                          <ul className="list-unstyled">
                            {citiesToShow.map((city, index) => {
                              return (
                                <CityRow
                                  key={index}
                                  editCityMode={this.props.editCityMode}
                                  editCityOptions={this.props.editCityOptions}
                                  addCity={this.props.addCity}
                                  replaceCity={this.props.replaceCity}
                                  city={city}
                                  replaceIndex={this.props.replaceIndex}
                                  previousCityIndex={
                                    this.props.previousCityIndex
                                  }
                                  closeModal={clickClose}
                                  {...city}
                                />
                              );
                            })}
                          </ul>
                        </div>
                      ) : cities.length ? (
                        <p className={'h5 text-center'}>
                          No cities matching your search query!
                        </p>
                      ) : (
                        <p>
                          Hey! Looks like there are no other city connection
                          possible here. Please try adding a city from another
                          route.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer text-right hidden-xs">
              <button
                className={`btn btn-link link-dark pull-left dim no-padding tracking-close-${
                  this.props.editCityMode
                }-city-modal`}
                onClick={clickClose}
                tabIndex={-1}
              >
                <span className="vehoicon-close" />
              </button>
              <button className="btn btn-secondary disabled">
                Apply Changes
              </button>
            </div>
          </div>

          {/* MOBILE FOOTER STARTS */}
          <div className="modal-footer modal-footer-mobile text-right visible-xs">
            <button
              className={`btn btn-link link-dark pull-left dim no-padding tracking-close-${
                this.props.editCityMode
              }-city-modal`}
              onClick={clickClose}
              tabIndex={-1}
            >
              <span className="vehoicon-close" />
            </button>
            <button className="btn btn-secondary disabled">
              Apply Changes
            </button>
          </div>
          {/* MOBILE FOOTER ENDS */}
        </div>
      </div>
    );
  }
}

const CityRow = props => {
  const performAction = () => {
    if (props.editCityMode === 'add') {
      props.addCity(props.editCityOptions.previousCityIndex, props.city);
    } else {
      props.replaceCity(props.editCityOptions.replaceIndex, props.city);
    }
    props.closeModal();
  };

  return (
    <li onClick={performAction}>
      <span className="pull-left srch-lft">
        <b>
          {props.cityName}, {props.country}
        </b>
        <p>{props.descriptionText}</p>
      </span>
      <span className="pull-right text-center srch-rgt">
        <i className="vehoicon-thumbs-down" />
        <p>{props.matchingPercentage}%</p>
      </span>
    </li>
  );
};

export default EditTripCityModal;
