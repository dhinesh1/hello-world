import React, { Component } from 'react';
import { connect } from 'react-redux';
import classNames from 'classnames';
import { bindActionCreators } from 'redux';
import _ from 'lodash';
import axios from 'axios';
import SweetAlert from 'sweetalert-react';

import { updateFlight } from '../../actions/actions_app';

import AlternateFlights from './components/alternate_flights';
import AlternateFlightsFilter from './components/alternate_flights_filter';
import AlternateFlightsLoadingSingle from './components/loaders/alternate_flights_loading_single';
import AlternateFilterLoading from './components/loaders/alternate_filters_loading';

import { AppConfig } from '../../app-config';
import {
  decodeCostingKeyFromURL,
  onceModalClosed,
  onceModalOpened,
  isNullorUndefined
} from '../../helpers/utilsHelper';
import {
  itineraryModalsRouteHelper,
  routingPageType
} from '../../helpers/routesHelper';
const API_URL = AppConfig.api_url;

/*global swal */

class AlternateFlightsModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      dataFetched: false,
      alternate_flights_response: {},
      showLoading: false,
      currentPick: {},
      alternateHotelsRequest: {},
      mobileFilterClass: '',
      mobileAlternatesClass: '',
      backgroundHeight: '100vh',
      showStartDateChangeAlert: false,
      enableFilterOnMobile: false,
      updateFlightsRequestData: {}
    };

    this.closeModal = this.closeModal.bind(this);
    this.getAlternateFlights = this.getAlternateFlights.bind(this);

    this.handleSelectedAlternateFlight = this.handleSelectedAlternateFlight.bind(
      this
    );
    this.hideFlightFilters = this.hideFlightFilters.bind(this);
    this.showFlightFilters = this.showFlightFilters.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.proceedToChangeFlight = this.proceedToChangeFlight.bind(this);
    this.getCurrentFlight = this.getCurrentFlight.bind(this);
  }

  componentDidMount() {
    this.setState(
      {
        showModal: true
      },
      () => {
        onceModalOpened();

        this.getCurrentFlight(this.props);
      }
    );
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentFlight(props);
  }

  getCurrentFlight(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.flightCostings &&
      !Object.keys(this.state.currentPick).length
    ) {
      let currentFlightKey = this.props.match.params.flightKey;
      currentFlightKey = decodeCostingKeyFromURL(currentFlightKey);

      let currentFlight =
        props.itineraryInfo.flightCostings.flightCostingById[currentFlightKey];

      this.setState({ currentPick: currentFlight }, () => {
        this.getAlternateFlights();
      });
    }
  }

  getAlternateFlights(filters = {}) {
    let flight = this.state.currentPick;
    let { itineraryDetail } = this.props;
    let isFiltering = false;
    if (!Object.keys(filters).length) {
      filters = {
        includeNonStop: true,
        includeOneStop: true,
        includeTwoStops: true,
        includeRefundable: true,
        includeNonRefunable: true,
        includeAllAirlines: true,
        includeAllTimings: true,
        fromPrice: 0,
        toPrice: 100000000,
        applyOJFilter: false
      };
    } else {
      isFiltering = true;
    }
    let flightRequestData = {
      sourceProvider: !isNullorUndefined(filters.sourceProvider)
        ? filters.sourceProvider
        : this.state.currentPick.ourSourceProvider,
      itineraryId: itineraryDetail.itineraryId,
      dbFlightId: flight.dbFlightId,
      flightFiltersRequest: filters
    };

    this.setState(
      {
        showLoading: true,
        alternateFlightsRequest: flightRequestData,
        dataFetched: false
      },
      () => {
        let url = `${API_URL}flight/alternateflights`;
        axios
          .post(url, flightRequestData)
          .then(response => {
            this.setState({
              alternate_flights_response: response.data,
              dataFetched: !isNullorUndefined(
                response.data.comboFlightCostings
              ),
              showLoading: false
            });
          })
          .catch(error => {
            console.warn(error);

            swal(
              {
                title: 'Oops!',
                text: 'An unexpected error occurred while fetching flights.',
                animation: true,
                showCancelButton: false,
                confirmButtonColor: '#DD6B55',
                confirmButtonText: 'Try again!',
                cancelButtonText: 'Cancel',
                closeOnConfirm: true,
                closeOnCancel: true
              },
              function(isConfirm) {}
            );
          });
      }
    );
  }

  handleSelectedAlternateFlight(selectedFlight, i) {
    let tripIdentifiers = [];
    let changesStayStartDate = null;
    let selectedFlightIdentifier;

    let fromInputName = `option-${i}-1`;
    let toInputName = `option-${i}-2`;
    if (
      selectedFlight.flightTripsList.length === 2 &&
      document.querySelector('input[name=' + toInputName + ']')
    ) {
      tripIdentifiers[0] = document.querySelector(
        'input[name=' + fromInputName + ']:checked'
      ).value;
      tripIdentifiers[1] = document.querySelector(
        'input[name=' + toInputName + ']:checked'
      ).value;
      changesStayStartDate = document
        .querySelector('input[name=' + fromInputName + ']:checked')
        .getAttribute('data-changes-stay-start-date');
    } else {
      tripIdentifiers[0] = document.querySelector(
        'input[name=' + fromInputName + ']:checked'
      ).value;
      changesStayStartDate = document
        .querySelector('input[name=' + fromInputName + ']:checked')
        .getAttribute('data-changes-stay-start-date');
    }

    const selectedInput = `option-${i}-1`;
    selectedFlightIdentifier = document.querySelector(
      'input[name=' + selectedInput + ']:checked'
    ).value;

    let updateFlightsRequestData = {
      itineraryId: this.props.itineraryDetail.itineraryId,
      cacheRefKey: this.state.alternate_flights_response.referenceKeys,
      flightCostingConfigKey: '',
      tripIdentifiers: tripIdentifiers,
      dbFlightId: this.state.currentPick.dbFlightId,
      validatingAirline: selectedFlight.validatingAirline,
      selectedFlightIdentifier
    };

    this.setState(
      {
        updateFlightsRequestData
      },
      () => {
        if (changesStayStartDate == 'true') {
          this.setState({
            showStartDateChangeAlert: true
          });
        } else {
          this.proceedToChangeFlight();
        }
      }
    );
  }

  proceedToChangeFlight() {
    this.props.actions
      .updateFlight(this.state.updateFlightsRequestData)
      .then(() => {
        this.closeModal(true);
      })
      .catch(() => {
        this.closeModal(true);
      });
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  closeModal(replace = false) {
    let { history, location, itineraryDetail } = this.props;
    this.setState({ showModal: false, alternate_flights_response: {} }, () => {
      onceModalClosed();

      const pageUrl = itineraryModalsRouteHelper({
        itineraryId: itineraryDetail.itineraryId,
        regionCode: itineraryDetail.regionCode,
        location
      });

      if (replace) {
        history.replace(pageUrl);
      } else {
        history.push(pageUrl);
      }
    });
  }

  hideFlightFilters() {
    this.setState({ enableFilterOnMobile: false });
  }

  showFlightFilters() {
    this.setState({ enableFilterOnMobile: true });
  }

  render() {
    let filterOptionsData = { minCost: 2290, maxCost: 63421, airlines: [] };
    let flightCurrentPickText = null;
    let noCurrentPickClass = 'no-current-pick';
    let { match } = this.props;
    /* will be set to null if there is no current Pick */
    let modalTitle = 'Change flight';
    /* will be set to "Add flight" if there is no current Pick */
    let alternateFlights = {};

    if (!_.isEmpty(this.state.alternate_flights_response)) {
      alternateFlights = this.state.alternate_flights_response;
    }

    if (alternateFlights.comboFlightCostings !== undefined) {
      filterOptionsData = {
        minCost: Math.floor(alternateFlights.minFlightsPrice),
        maxCost: Math.ceil(alternateFlights.maxFlightsPrice),
        airlines: alternateFlights.airlineCodeNameList,
        onwardSelectedDepAirportCode:
          alternateFlights.onwardSelectedDepAirportCode,
        onwardSelectedArrAirportCode:
          alternateFlights.onwardSelectedArrAirportCode,
        returnSelectedDepAirportCode:
          alternateFlights.returnSelectedDepAirportCode,
        returnSelectedArrAirportCode:
          alternateFlights.returnSelectedArrAirportCode,
        onwardArrAirportOptions: alternateFlights.onwardArrAirportOptions,
        onwardDepAirportOptions: alternateFlights.onwardDepAirportOptions,
        returnArrAirportOptions: alternateFlights.returnDepAirportOptions,
        returnDepAirportOptions: alternateFlights.returnArrAirportOptions
      };
    } else {
      filterOptionsData = {};
    }

    //This block is to get current pick string
    let currentPick = this.state.currentPick;

    if (currentPick && currentPick.allTrips) {
      if (currentPick.allTrips.length === 2) {
        //Roundtrip flights current pick text generation
        let trip1 = currentPick.trips[currentPick.allTrips[0]];
        let trip2 = currentPick.trips[currentPick.allTrips[1]];
        let trip1RoutesLastIndex = trip1.routes.length - 1;
        let trip2RoutesLastIndex = trip2.routes.length - 1;
        let trip1DisplayText = `${trip1.routes[0].departureAirportCode} → ${
          trip1.routes[trip1RoutesLastIndex].arrivalAirportCode
        }`;
        let trip2DisplayText = `${trip2.routes[0].departureAirportCode} → ${
          trip2.routes[trip2RoutesLastIndex].arrivalAirportCode
        }`;
        flightCurrentPickText = `${
          this.state.currentPick.airlineName
        } roundtrip flight : ${trip1DisplayText} and ${trip2DisplayText}`;
        noCurrentPickClass = '';
      } else {
        //Oneway flights current pick text generation
        if (currentPick.identifier) {
          let trip1 = currentPick.trips[currentPick.allTrips[0]];
          let trip1RoutesLastIndex = trip1.routes.length - 1;
          let trip1DisplayText = `from ${trip1.routes[0].departureCity} to ${
            trip1.routes[trip1RoutesLastIndex].arrivalCity
          }`;
          flightCurrentPickText = `${
            this.state.currentPick.airlineName
          } flight ${trip1DisplayText}`;
          noCurrentPickClass = '';
        } else {
          modalTitle = 'Add flight';
        }
      }
    }

    return (
      <div
        tabIndex="0"
        ref="modal"
        className={classNames('modal fade alternate-modal width-auto ', {
          in: this.state.showModal
        })}
        id="alternate-flights-modal"
      >
        <SweetAlert
          show={this.state.showStartDateChangeAlert}
          title="Change in Landing Date"
          text={`This option shifts your landing date. We would need to re-check hotel availability and other prices for the new dates. This will take a while. Hold Tight.`}
          onConfirm={() => {
            this.setState({ showStartDateChangeAlert: false }, () => {
              this.proceedToChangeFlight();
            });
          }}
          showCancelButton
          animation="pop"
          confirmButtonText={'Ok, Continue'}
          cancelButtonText={"No, Don't change my flight"}
          onEscapeKey={() => this.setState({ showStartDateChangeAlert: false })}
          onCancel={() => this.setState({ showStartDateChangeAlert: false })}
          onOutsideClick={() =>
            this.setState({ showStartDateChangeAlert: false })
          }
        />

        <div
          className={classNames('modal-dialog', {
            'enable-filter': this.state.enableFilterOnMobile
          })}
        >
          <div className="container modal-alternate-wrapper">
            <div className="row">
              <div className="filter-display col-md-3 gutter-less-filter">
                {!_.isEmpty(filterOptionsData) ? (
                  <AlternateFlightsFilter
                    handleFilterCloseIconClick={this.hideFlightFilters}
                    filterOptions={filterOptionsData}
                    userDetails={this.props.user_details}
                    currentPick={currentPick}
                    handler={this.getAlternateFlights}
                    onCloseModal={this.closeModal}
                    splitPricing={this.props.itineraryDetail.splitPricing}
                    classes={this.state.mobileFilterClass}
                  />
                ) : (
                  <AlternateFilterLoading loaderState={false} />
                )}
              </div>
              <div className="col-md-9 mobile-hide-on-filter">
                {!this.state.showLoading || this.state.dataFetched ? (
                  <div
                    className="modal-content with-header"
                    id="alternate-flights-content"
                  >
                    <div className="modal-header">
                      <div className="pull-right visible-xs visible-sm">
                        <button
                          className="trans-btn"
                          onClick={this.showFlightFilters}
                        >
                          <i className="vehoicon-tune modal-filter" />
                        </button>
                      </div>
                      <span className="text-uppercase kern-more bolder fade">
                        {modalTitle}
                      </span>
                      <button
                        type="button"
                        className="close"
                        onClick={this.closeModal}
                      >
                        <i className="vehoicon-close" />
                      </button>
                    </div>

                    <div className={'modal-body'}>
                      {this.state.alternate_flights_response
                        .comboFlightCostings &&
                      currentPick.identifier &&
                      currentPick.status === 'SUCCESS' ? (
                        <div className="current-pick-panel">
                          <div className="current-pick-content hotel clearfix">
                            <div className="col-xs-9 col-md-10">
                              <span className="single-line-text fade small no-margin">
                                Changing: {flightCurrentPickText}{' '}
                              </span>
                            </div>
                            <div className="col-xs-3 col-md-2 text-right">
                              {currentPick && currentPick.price ? (
                                <span className="total-price small bold dim">
                                  <span className="WebRupee">Rs.</span>{' '}
                                  {currentPick.price}
                                </span>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      ) : null}

                      <AlternateFlights
                        setBackgroundHeight={this.setBackgroundHeight}
                        handleFilterIconClick={this.showFlightFilters}
                        handleSelectedAlternateFlight={
                          this.handleSelectedAlternateFlight
                        }
                        ref="alternates"
                        currentPick={currentPick}
                        noCurrentPickClass={noCurrentPickClass}
                        modalTitle={modalTitle}
                        alternate_flights={
                          this.state.alternate_flights_response
                            .comboFlightCostings
                        }
                        onCloseModal={this.closeModal}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="modal-alternate-content">
                    <div className="modal-row">
                      <AlternateFlightsLoadingSingle loaderState={false} />
                      <AlternateFlightsLoadingSingle loaderState={false} />
                      <AlternateFlightsLoadingSingle loaderState={false} />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      updateFlight: bindActionCreators(updateFlight, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  AlternateFlightsModal
);
