import React from 'react';
import { connect } from 'react-redux';
import RequestCallbackModal from './request_callback_modal';
import RequestCallbackModal2 from './request_callback_modal_new';

const RequestCallbackWrapper = (props) => {
  const { location } = props;
  if(location && typeof location.search === 'string' && location.search.indexOf('autocbr') > -1 && props.isPaid) {
    return <RequestCallbackModal2 {...props} />
  }
  return <RequestCallbackModal {...props} />
}

const mapStateToProps = ({ packages = {} }) => {
  const { content } = packages;
  let isPaid = null;
  if(content && typeof content === "object" && Object.keys(content).length) {
    const { campaignDetails={} } = content;
    isPaid = campaignDetails.paid;
  }

  return { isPaid }
}
export default connect(mapStateToProps)(RequestCallbackWrapper);