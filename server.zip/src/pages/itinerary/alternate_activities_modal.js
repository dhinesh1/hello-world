import React, { Component } from 'react';
import { connect } from 'react-redux';
import _ from 'lodash';
import { bindActionCreators } from 'redux';
import { openActivityFromAlternates } from '../../actions/actions_app';

import AlternateHotelsActivitiesLoading from './components/loaders/alternate_hotels_activities_loading';
import AlternateFilterLoading from './components/loaders/alternate_filters_loading';
import AlternateActivitiesFilter from './components/alternate_activities_filter';
import AlternateActivities from './components/alternate_activities';

import {
  decodeActivityKeyFromURL,
  onceModalClosed,
  onceModalOpened
} from '../../helpers/utilsHelper';
import axios from 'axios';

import { AppConfig } from '../../app-config';
import classNames from 'classnames';
import {
  trackEvent,
  EVENT_INCLUSIONS_MODIFIED,
  EVENT_ITINERARY_MODIFIED
} from '../../helpers/ML/EventsTracker';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  ITINERARY_ROUTES,
  inclusionsRoute
} from '../../helpers/routesHelper';
import { Route, Switch } from 'react-router-dom';
import { ActivityDetailsModalLoadable } from '../../helpers/loadbleComponentsHelper';
const API_URL = AppConfig.api_url;

class AlternateActivitiesModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      showLoading: true,
      showContentPlaceHolders: false,
      search_state: 0,
      filteredAlternates: [],
      allAlternates: [],
      current_slot: {},
      recommendedActivitiesFound: false,
      backgroundHeight: '100vh',
      enableFilterOnMobile: false
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.doSearch = this.doSearch.bind(this);
    this.hideActivityFilters = this.hideActivityFilters.bind(this);
    this.showActivityFilters = this.showActivityFilters.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);

    this.sortActivities = this.sortActivities.bind(this);
    this.getCurrentDetails = this.getCurrentDetails.bind(this);

    this.getAlternateActivites = this.getAlternateActivites.bind(this);
    this.getOtherActivities = this.getOtherActivities.bind(this);
    this.getAlternateActivitesActual = this.getAlternateActivitesActual.bind(
      this
    );
  }

  componentDidMount() {
    this.openModal();

    this.getCurrentDetails(this.props);
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  componentWillReceiveProps(props) {
    this.getCurrentDetails(props);
  }

  getCurrentDetails(props) {
    if (
      props.itineraryInfo &&
      Object.keys(props.itineraryInfo).length &&
      props.itineraryInfo.iterSlotByKey &&
      !Object.keys(this.state.current_slot).length
    ) {
      let currentSlotKey = this.props.match.params.activityKey;
      currentSlotKey = decodeActivityKeyFromURL(currentSlotKey);

      let currentDetail = props.itineraryInfo.iterSlotByKey[currentSlotKey];

      if (!currentDetail) {
        this.closeModal();
      }

      const isInclusions =
        window &&
        window.location &&
        (window.location.pathname || '').includes('/inclusions/');
      trackEvent(
        isInclusions ? EVENT_INCLUSIONS_MODIFIED : EVENT_ITINERARY_MODIFIED,
        {
          activity_changed: true
        }	
      );

      currentDetail.slotIdentifier = currentSlotKey;
      if (
        currentDetail.type !== 'LEISURE' &&
        currentDetail.type !== 'INTERCITY_TRANSFER'
      ) {
        let activityDetails =
          props.itineraryInfo.activityById[
            currentDetail.activitySlotDetail.activityId
          ];
        _.assign(currentDetail.activitySlotDetail, activityDetails);

        let activityCostingDetails = {};
        if (
          props.itineraryInfo.itinerary.costed &&
          !props.itineraryInfo.itinerary.staleCost
        ) {
          activityCostingDetails =
            props.itineraryInfo.activityCostings.activityCostingById[
              currentDetail.activitySlotDetail.activityCostingIdentifier
            ];
        }

        currentDetail = { ...currentDetail, ...activityCostingDetails };
      }

      this.setState({ current_slot: currentDetail }, () => {
        this.getAlternateActivites(currentDetail);
      });
    }
  }

  getAlternateActivites(current_slot, e) {
    if (
      current_slot.type !== 'LEISURE' &&
      current_slot.type !== 'INTERCITY_TRANSFER' &&
      current_slot.activitySlotDetail.costingInfo &&
      current_slot.activitySlotDetail.costingInfo.inCombo
    ) {
      /*swal(
        {
          title: 'This will remove your Combo Package savings',
          text:
            'This activity is part of a Combo Package in your itinerary. Changing this will remove the Combo Package. Are you sure you want to do this?',
          // imageUrl: '/images/cost_error.png',
          animation: true,
          showCancelButton: true,
          confirmButtonColor: '#DD6B55',
          confirmButtonText: 'Ok, Continue',
          cancelButtonText: "No, Don't change this activity",
          closeOnConfirm: true,
          closeOnCancel: true
        },
        isConfirm => {
          if (isConfirm) {
            this.getAlternateActivitesActual(current_slot);
          }
        }
      );*/
    } else {
      this.getAlternateActivitesActual(current_slot, e);
    }
  }

  getOtherActivities(current) {
    let allActivities = this.props.itineraryInfo.activityById;
    if (!_.isEmpty(current)) {
      allActivities = _.omit(allActivities, [current]);
    }

    return _.keys(allActivities);
  }

  getAlternateActivitesActual(current_slot, e) {
    let { itineraryInfo } = this.props;
    // Day identifier to check RC availability
    let slotKeyInDay = _.findKey(
      itineraryInfo.iterDayByKey,
      e => e.allSlotKeys.indexOf(current_slot.slotIdentifier) !== -1
    );
    let slotInDay = itineraryInfo.iterDayByKey[slotKeyInDay];

    let currentCityKey = _.findKey(
      itineraryInfo.iterCityByKey,
      i => i.allDayKeys.indexOf(slotKeyInDay) !== -1
    );

    let currentCityIndex = _.findIndex(
      itineraryInfo.itinerary.allCityKeys,
      o => o === currentCityKey
    );

    let currentCity = itineraryInfo.iterCityByKey[currentCityKey];

    let current_activity_id = '';
    let showOtherSlots = false;
    let showActivitiesWithTransferOnly = false;

    let activity = current_slot.activitySlotDetail;
    let city_id = currentCity.cityId;
    let dropCityId = currentCity.cityId;
    switch (current_slot.type) {
      case 'ACTIVITY':
        current_activity_id = activity && activity.activityId;
        break;
      case 'LEISURE':
        showOtherSlots = true;
        break;
      case 'ACTIVITY_WITH_TRANSFER':
      case 'INTERCITY_TRANSFER':
        showActivitiesWithTransferOnly = true;
        city_id = current_slot.intercityTransferSlotDetailVO.fromCity;
        dropCityId = current_slot.intercityTransferSlotDetailVO.toCity;
        break;
      default:
        break;
    }

    if (current_slot.prevCity && slotInDay) {
      let prevCityKey =
        itineraryInfo.itinerary.allCityKeys[currentCityIndex - 1];
      dropCityId = city_id = itineraryInfo.iterCityByKey[prevCityKey].cityId;
    }

    let activityCostingKey =
      (current_slot.activitySlotDetail &&
        current_slot.activitySlotDetail.activityCostingIdentifier) ||
      '';

    let req_config = {
      cityId: city_id,
      itineraryId: itineraryInfo.itinerary.itineraryId,
      currentActivityId: current_activity_id,
      alternateActivityIds: this.getOtherActivities(current_activity_id),
      timeSlotType: 6,
      showOtherSlots: showOtherSlots,
      slotSpan: current_slot.span,
      startSlot: current_slot.start,
      showActivitiesWithTransferOnly: showActivitiesWithTransferOnly,
      dropCityId: dropCityId,
      rcAvailable: slotInDay.rcAvailable,
      primaryTravelMode: 'UNKNOWN',
      activityCostingKey: activityCostingKey
    };

    this.setState({ showLoading: true }, () => {
      let url = `${API_URL}activity/alternates`;
      axios.post(url, req_config).then(response => {
        let allAlternates = response.data.data;

        let alternates = this.sortActivities(allAlternates);
        let allRecommendedActivities = allAlternates.filter(
          activity => activity.recommended
        );

        this.setState(
          {
            search_state: 0,
            showLoading: false,
            allAlternates: alternates,
            recommendedActivitiesFound: allRecommendedActivities.length > 0
          },
          () => {
            if (this.state.filteredAlternates.length === 0) {
              this.setState({
                filteredAlternates: alternates
              });
            }
          }
        );
      });
    });
  }

  openModal() {
    this.setState({ showModal: true }, () => {
      onceModalOpened();
    });
  }

  closeModal() {
    const { history, location, itineraryDetail } = this.props;
    const { itineraryId, regionCode } = itineraryDetail;

    const itineraryPath = itineraryModalsRouteHelper({
      itineraryId,
      regionCode
    });
    const inclusionsPath = itineraryModalsRouteHelper({
      itineraryId,
      regionCode,
      parentPage: routingPageType.inclusion
    });

    setTimeout(() => {
      this.setState(
        {
          showModal: false,
          showLoading: true,
          search_state: 0,
          filteredAlternates: [],
          allAlternates: []
        },
        () => {
          onceModalClosed();

          if (location.pathname.indexOf(routingPageType.itinerary) > 0) {
            history.push(itineraryPath);
          } else {
            history.push(inclusionsPath);
          }
        }
      );
    }, 400);
  }

  hideActivityFilters() {
    this.setState({ enableFilterOnMobile: false });
  }

  showActivityFilters() {
    this.setState({ enableFilterOnMobile: true });
  }

  sortActivities(activities) {
    let allAlternates = activities;
    let allFreeActivities = allAlternates
      ? allAlternates.filter(activity => activity.free)
      : [];
    let allCostedActivities = allAlternates
      ? allAlternates.filter(activity => !activity.free)
      : [];

    let alternates = [];
    if (!this.props.itineraryDetail.splitPricing) {
      let allNonDiffActivities = allCostedActivities.filter(
        activity => !activity.selectedTourGrade.diffDetail
      );
      if (allNonDiffActivities.length > 0) {
        allNonDiffActivities = _.sortBy(allNonDiffActivities, [
          function(o) {
            return _.toNumber(
              o.selectedTourGrade.cost &&
                o.selectedTourGrade.cost.replace(',', '')
            );
          }
        ]);

        alternates = alternates.concat(allNonDiffActivities);
      }

      let allDecreasedActivities = allCostedActivities.filter(
        activity =>
          activity.selectedTourGrade.diffDetail &&
          activity.selectedTourGrade.diffDetail.diffChangeType ===
            'PRICEDECREASE'
      );
      if (allDecreasedActivities.length > 0) {
        allDecreasedActivities = _.sortBy(allDecreasedActivities, [
          function(o) {
            return o.selectedTourGrade.diffDetail.diffCost;

            // return _.toNumber(
            //   o.selectedTourGrade.diffDetail.diffCost.replace(',', '')
            // );
          }
        ]);

        alternates = alternates.concat(_.reverse(allDecreasedActivities));
      }

      let allNoneActivities = allCostedActivities.filter(
        activity =>
          activity.selectedTourGrade.diffDetail &&
          activity.selectedTourGrade.diffDetail.diffChangeType === 'NONE'
      );
      if (allNoneActivities.length > 0) {
        alternates = alternates.concat(allNoneActivities);
      }

      let allIncreasedActivities = allCostedActivities.filter(
        activity =>
          activity.selectedTourGrade.diffDetail &&
          activity.selectedTourGrade.diffDetail.diffChangeType ===
            'PRICEINCREASE'
      );
      if (allIncreasedActivities.length > 0) {
        allIncreasedActivities = _.sortBy(allIncreasedActivities, [
          function(o) {
            return o.selectedTourGrade.diffDetail.diffCost;

            // return _.toNumber(
            //   o.selectedTourGrade.diffDetail.diffCost.replace(',', '')
            // );
          }
        ]);

        alternates = alternates.concat(allIncreasedActivities);
      }
    } else {
      alternates = _.sortBy(allCostedActivities, [
        function(o) {
          return _.toNumber(
            o.selectedTourGrade.cost &&
              o.selectedTourGrade.cost.replace(',', '')
          );
        }
      ]);
    }
    alternates = alternates.concat(allFreeActivities);

    return alternates;
  }

  doSearch(options) {
    let filteredAlternates = this.state.allAlternates;
    const term = options.searchTerm.trim().toLowerCase();

    filteredAlternates = filteredAlternates.filter(activity => {
      return (
        (options.types !== 'free' || activity.free) &&
        (options.types !== 'recommended' || activity.recommended) &&
        (term.length === 0 || new RegExp(term, 'i').test(activity.title)) &&
        (_.isEmpty(options.otherFilters) ||
          Object.keys(options.otherFilters).reduce(
            (acc, ele) => acc && activity[ele],
            true
          )) &&
        (options.interests.length === 0 ||
          options.interests.reduce(
            (acc, ele) => acc || activity.interests.includes(ele),
            false
          )) &&
        _.toNumber(
          activity.selectedTourGrade.cost &&
            activity.selectedTourGrade.cost.replace(',', '')
        ) <= options.maxPrice &&
        _.toNumber(
          activity.selectedTourGrade.cost &&
            activity.selectedTourGrade.cost.replace(',', '')
        ) >= options.minPrice &&
        (options.timeFilter.length === 0 ||
          options.timeFilter.reduce(
            (acc, ele) =>
              acc || activity.selectedTourGrade.durationType === ele,
            false
          ))
      );
    });
    filteredAlternates = this.sortActivities(filteredAlternates);

    this.setState({
      search_state: filteredAlternates.length ? 0 : 2,
      filteredAlternates: filteredAlternates
    });
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  render() {
    if (this.state.showLoading) {
      return (
        <div
          className={
            'modal fade alternate-modal width-auto ' +
            (this.state.showModal ? 'in' : '')
          }
          id="change-activity-modal"
        >
          <div className={'modal-dialog'}>
            <div className="container modal-alternate-wrapper">
              <div className="row">
                <div className="filter-display col-md-3 gutter-less-filter">
                  <AlternateFilterLoading loaderState={false} />
                </div>

                <div className="col-md-9 mobile-hide-on-filter">
                  <div className={'modal-content with-header'}>
                    <div className="modal-header">
                      <div className="header-bar mobile-toggle">
                        <div className="pull-right visible-xs visible-sm">
                          <button className="trans-btn">
                            <span className="vehoicon-tune modal-filter" />
                          </button>
                        </div>

                        <span className="text-uppercase kern-more bolder fade">
                          Change Activity
                        </span>

                        <button
                          type="button"
                          className="close"
                          onClick={this.closeModal}
                        >
                          <i className="vehoicon-close" />
                        </button>
                      </div>
                    </div>

                    <div className={'modal-body'}>
                      <AlternateHotelsActivitiesLoading
                        loaderState={false}
                        title={'Change Activity'}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      const priceArray = this.state.allAlternates.map(activity => {
        return _.toNumber(
          activity.selectedTourGrade.cost &&
            activity.selectedTourGrade.cost.replace(',', '').trim()
        );
      });
      const minPrice = _.min(priceArray),
        maxPrice = _.max(priceArray);

      let { current_slot } = this.state;

      let priceValue = null;
      let comboBadge = null;
      if (
        !_.isEmpty(current_slot) &&
        !_.isEmpty(current_slot.activitySlotDetail)
      ) {
        if (current_slot.activitySlotDetail.costingInfo !== undefined) {
          if (current_slot.activitySlotDetail.costingInfo.inCombo)
            comboBadge = (
              <span className="in-combo for-current-pick">IN COMBO</span>
            );
        }

        priceValue = current_slot.activitySlotDetail.free ? (
          <span className="block small">
            <span className="pill success color-white">Self exploration</span>
          </span>
        ) : (
          <span className="total-price small bold dim">
            <span className="WebRupee">Rs.</span> {current_slot.totalCost}
          </span>
        );
      }

      return (
        <div
          tabIndex="0"
          className={
            'modal fade alternate-modal width-auto ' +
            (this.state.showModal ? 'in' : '')
          }
          id="change-activity-modal"
        >
          <button
            style={{ display: 'none' }}
            type="button"
            onClick={this.hideActivityFilters}
            className="btn btn-primary tracker-activity-mobile-filter-update filter-update-btn filter-update-btn-fixed"
          >
            Update
          </button>

          <div
            className={classNames('modal-dialog', {
              'enable-filter': this.state.enableFilterOnMobile
            })}
          >
            <div className="container modal-alternate-wrapper">
              <div className="row">
                <div className="filter-display col-md-3 gutter-less-filter">
                  <AlternateActivitiesFilter
                    splitPricing={this.props.itineraryDetail.splitPricing}
                    handleFilterCloseIconClick={this.hideActivityFilters}
                    onCloseModal={this.closeModal}
                    minPrice={minPrice}
                    maxPrice={maxPrice}
                    recommendedActivitiesFound={
                      this.state.recommendedActivitiesFound
                    }
                    doSearch={this.doSearch}
                    user_details={this.props.user_details}
                  />
                </div>
                <div className="col-md-9 mobile-hide-on-filter">
                  <div className={'modal-content with-header'}>
                    <div className="modal-header">
                      <div className="header-bar mobile-toggle">
                        <div className="pull-right visible-xs visible-sm">
                          <button
                            className="trans-btn"
                            onClick={this.showActivityFilters}
                          >
                            <span className="vehoicon-tune modal-filter" />
                          </button>
                        </div>

                        <span className="text-uppercase kern-more bolder fade">
                          Change Activity
                        </span>

                        <button
                          type="button"
                          className="close"
                          onClick={this.closeModal}
                        >
                          <i className="vehoicon-close" />
                        </button>
                      </div>
                    </div>

                    <div className={'modal-body'}>
                      {!_.isEmpty(current_slot) &&
                      !_.isEmpty(current_slot.activitySlotDetail) ? (
                        <div className="current-pick-panel">
                          <div className="current-pick-content hotel">
                            <div className="col-xs-9 col-md-9">
                              {/* <a className="toggle-panel" href="#"><span className="vehoicon-arrow_downward" /><span className="sr-only">More info</span></a> */}
                              <span className="single-line-text fade small no-margin">
                                Changing:{' '}
                                {current_slot.activitySlotDetail.title}
                              </span>
                            </div>
                            <div className="col-xs-3 col-md-3 text-right">
                              {current_slot.activitySlotDetail.free ||
                              current_slot.activitySlotDetail.selectedTourGrade
                                .cost
                                ? priceValue
                                : null}
                              {current_slot.activitySlotDetail.costingInfo &&
                              current_slot.activitySlotDetail.costingInfo
                                .inCombo
                                ? comboBadge
                                : null}
                            </div>
                          </div>
                        </div>
                      ) : null}

                      <AlternateActivities
                        handleFilterIconClick={this.showActivityFilters}
                        onCloseModal={this.closeModal}
                        itineraryId={this.props.itineraryId}
                        currentPickActivity={current_slot}
                        search_state={this.state.search_state}
                        alternates={this.state.filteredAlternates}
                        openActivityFromAlternates={
                          this.props.actions.openActivityFromAlternates
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Routes */}
          {/* Activity details from Alternates */}
          <Switch>
            <Route
              path={ITINERARY_ROUTES.ACTIVITY_ALTERNATES_DETAILS_ROUTE}
              exact
              component={ActivityDetailsModalLoadable}
            />

            <Route
              path={inclusionsRoute.ALTERNATE_ACTIVITY_DETAILS}
              exact
              component={ActivityDetailsModalLoadable}
            />
          </Switch>
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      openActivityFromAlternates: bindActionCreators(
        openActivityFromAlternates,
        dispatch
      )
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  AlternateActivitiesModal
);
