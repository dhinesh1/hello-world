import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { fetchDataForPDF } from '../../actions/actions_app';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import PDFV1Itinerary from './components/itinerary';

class ItineraryPDFv1 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      content: {}
    };
  }

  componentDidMount() {
    let { match, pdfData } = this.props;

    if (!Object.keys(pdfData).length) {
      this.props.actions.fetchDataForPDF(match.params.itineraryId);
    }
  }

  render() {
    if (!Object.keys(this.props.pdfData).length) {
      return <div>This is for testing in server</div>;
    } else {
      let content = this.props.pdfData;

      return <PDFV1Itinerary content={content} />;
    }
  }
}

function mapStateToProps(state) {
  let app = state.app;
  let pdfData = app.pdfData;

  return {
    pdfData: pdfData,
    user_details: app.user_details
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      fetchDataForPDF: bindActionCreators(fetchDataForPDF, dispatch)
    }
  };
}

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(ItineraryPDFv1)
);
