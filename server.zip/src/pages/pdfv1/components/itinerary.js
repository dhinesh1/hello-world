import React, { Component } from 'react';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

class PDFV1Itinerary extends Component {
  render() {
    let { content } = this.props;

    return (
      <div
        id="itinerary-details"
        style={{
          width: '8.5in',
          backgroundColor: '#eee',
          margin: '0px auto',
          padding: '0.5in 0.5in 0.5in 0.3in',
          position: 'relative',
          color: '#000',
          fontFamily: 'Arial'
        }}
      >
        <div
          style={{
            backgroundColor: '#aaa',
            color: '#fff',
            width: '100%',
            padding: 10,
            textAlign: 'center'
          }}
          id="interests-header"
        >
          <table width="100%" border={0} cellPadding={0} cellSpacing={0}>
            <tbody>
              <tr>
                <td align="right" width="45%">
                  <img
                    alt={'activities'}
                    src="https://pyt-images.imgix.net/images/misc/activities_white.png"
                    width="32px"
                    style={{ margin: '15px 0px' }}
                  />
                </td>
                <td align="left" width="55%">
                  <h4>&nbsp;&nbsp;&nbsp;Interests Chosen</h4>
                </td>
              </tr>
              <tr>
                <td colSpan={2} align="center">
                  {content.interests}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div style={{ width: '102%', padding: 0, margin: '50px 0px' }}>
          <table
            width="100%"
            style={{ padding: 0 }}
            border="1px"
            cellPadding={10}
            cellSpacing={0}
          >
            <thead>
              <tr>
                <td width="20%">DAY</td>
                <td width="20%">MORNING</td>
                <td width="20%">AFTERNOON</td>
                <td width="20%">EVENING</td>
                <td width="20%">HOTEL</td>
              </tr>
            </thead>
            <tbody align="center" className="intinerary-rows">
              {content.itinerary.iterCities.map((city, inx) => {
                return city.iterDays.map((day, dInx) => {
                  return (
                    <tr key={'v1_single_city_' + inx + dInx}>
                      <td>
                        <div className="calendar">
                          <span>DAY</span>
                          <h2>{day.dayNum}</h2>
                        </div>
                      </td>
                      {day.slotPlans.length === 1 ? (
                        day.slotPlans[0].slotText.toUpperCase() ===
                        'MORNING' ? (
                          [
                            <td key={'city_' + dInx + '_0'}>
                              {day.slotPlans[0].slotDescription}
                            </td>,
                            <td colSpan={2} key={'city_' + dInx + '_1'}>
                              At leisure
                            </td>
                          ]
                        ) : day.slotPlans[0].slotText.toUpperCase() ===
                        'MORNING TO NOON' ? (
                          [
                            <td colSpan={2} key={'city_' + dInx + '_0'}>
                              {day.slotPlans[0].slotDescription}
                            </td>,
                            <td key={'city_' + dInx + '_1'}>At leisure</td>
                          ]
                        ) : day.slotPlans[0].slotText.toUpperCase() ===
                        'NOON' ? (
                          [
                            <td key={'city_' + dInx + '_0'}>At leisure</td>,
                            <td key={'city_' + dInx + '_1'}>
                              {day.slotPlans[0].slotDescription}
                            </td>,
                            <td key={'city_' + dInx + '_2'}>At leisure</td>
                          ]
                        ) : day.slotPlans[0].slotText.toUpperCase() ===
                        'EVENING' ? (
                          [
                            <td colSpan={2} key={'city_' + dInx + '_0'}>
                              At leisure
                            </td>,
                            <td key={'city_' + dInx + '_1'}>
                              {day.slotPlans[0].slotDescription}
                            </td>
                          ]
                        ) : day.slotPlans[0].slotText.toUpperCase() ===
                        'NOON TO EVENING' ? (
                          [
                            <td key={'city_' + dInx + '_0'}>At leisure</td>,
                            <td colSpan={2} key={'city_' + dInx + '_1'}>
                              {day.slotPlans[0].slotDescription}
                            </td>
                          ]
                        ) : day.slotPlans[0].slotText.toUpperCase() ===
                        'FULL DAY' ? (
                          <td colSpan={3} key={'city_' + dInx + '_0'}>
                            {day.slotPlans[0].slotDescription}
                          </td>
                        ) : (
                          day.slotPlans.map((slot, sInx) => {
                            return (
                              <td colSpan={1} key={'city_' + dInx + '_' + sInx}>
                                {slot.slotDescription}
                              </td>
                            );
                          })
                        )
                      ) : day.slotPlans.length === 2 ? (
                        day.slotPlans[0].slotText.toUpperCase() === 'MORNING' &&
                        day.slotPlans[1].slotText.toUpperCase() ===
                          'EVENING' ? (
                          [
                            <td key={'city_' + dInx + '_0'}>
                              {day.slotPlans[0].slotDescription}
                            </td>,
                            <td key={'city_' + dInx + '_1'}>At leisure</td>,
                            <td key={'city_' + dInx + '_2'}>
                              {day.slotPlans[1].slotDescription}
                            </td>
                          ]
                        ) : day.slotPlans[0].slotText.toUpperCase() ===
                          'MORNING TO NOON' &&
                        day.slotPlans[1].slotText.toUpperCase() ===
                          'EVENING' ? (
                          [
                            <td colSpan={2} key={'city_' + dInx + '_0'}>
                              {day.slotPlans[0].slotDescription}
                            </td>,
                            <td key={'city_' + dInx + '_2'}>
                              {day.slotPlans[1].slotDescription}
                            </td>
                          ]
                        ) : day.slotPlans[0].slotText.toUpperCase() ===
                          'MORNING' &&
                        day.slotPlans[1].slotText.toUpperCase() ===
                          'NOON TO EVENING' ? (
                          [
                            <td key={'city_' + dInx + '_0'}>
                              {day.slotPlans[0].slotDescription}
                            </td>,
                            <td colSpan={2} key={'city_' + dInx + '_2'}>
                              {day.slotPlans[1].slotDescription}
                            </td>
                          ]
                        ) : (
                          day.slotPlans.map((slot, sInx) => {
                            return (
                              <td key={'city_' + dInx + '_' + sInx}>
                                {slot.slotDescription}
                              </td>
                            );
                          })
                        )
                      ) : (
                        day.slotPlans.map((slot, sInx) => {
                          return (
                            <td key={'city_' + dInx + '_' + sInx}>
                              {slot.slotDescription}
                            </td>
                          );
                        })
                      )}

                      {dInx === 0 ? (
                        <td rowSpan={city.iterDays.length}>
                          {city.iterDays.length} night{city.iterDays.length > 1
                            ? 's'
                            : ''}{' '}
                          in {city.cityName}
                        </td>
                      ) : null}
                    </tr>
                  );
                });
              })}
            </tbody>
          </table>
        </div>
        <br />
        <br />
      </div>
    );
  }
}

export default PDFV1Itinerary;
