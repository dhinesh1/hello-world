import React, { Component } from 'react';
import { teamInfo } from '../helpers/teamInfo';
import { scrollToTop } from '../helpers/utilsHelper';
import SmartImage from '../common_components/Image/smart_image';
import classNames from 'classnames';
import { Helmet } from 'react-helmet';
export default class AboutUs extends Component {
  constructor(props) {
    super(props);

    this.state = {
      expandIndex: '',
      viewMore: false
    };

    this.toggleMilestones = this.toggleMilestones.bind(this);
    this.expandThis = this.expandThis.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }

  toggleMilestones() {
    if (this.state.viewMore) {
      // scroll back
      this.scorlledTop = 600;
    } else {
      this.scorlledTop = 0;
    }

    this.setState({ viewMore: !this.state.viewMore }, () => {
      if (this.scorlledTop > 0) {
        scrollToTop(this.scorlledTop, 500);
      }
    });
  }

  expandThis(index, e) {
    e && e.preventDefault();

    if (this.state.expandIndex === index) {
      index = '';
    }

    this.setState({ expandIndex: index });
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.expandThis();
  }

  componentDidMount() {
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  render() {
    let { viewMore } = this.state;

    let hiddenCardClassName = classNames({
      'timeline-card': true,
      hidecard: !viewMore
    });

    let hiddenCardWTClassName = classNames({
      'timeline-card': true,
      hidecard: !viewMore,
      'mt-75': true
    });

    return (
      <section className="about-us">
        <Helmet>
          <title>About the Team | Pickyourtrail</title>
          <meta
            name={'description'}
            content={
              'We want to make every vacation a memorable experience! Come, discover a new way of travel - The Pickyourtrail way!'
            }
          />
        </Helmet>

        <div className="aboutus-bg" />
        <section className="title-sec">
          <h1 className="journey">Journey</h1>
        </section>
        <section id="pyt-timeline" className="abt-timeline-outer">
          <div className="container">
            <div className="row">
              <div className="col-xs-12 abt-timeline-inner">
                <div className="timeline-card">
                  <div className="yearBlock">
                    <p>2018</p>
                  </div>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t23.jpg"
                    />
                    <h4>Recognition and Accolades</h4>
                    <p>
                      We were awarded the ‘Start-up of the year’ at the Tiecon
                      awards. Excited and award-thirsty to win more with your
                      support!
                    </p>
                    <span className="cd-date">October, 2018</span>
                  </div>
                </div>
                <div className="timeline-card">
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t22.jpg"
                    />
                    <h4>The Bigger family</h4>
                    <p>
                      We are a family of 85 now and are keen on growing.
                      Stronger than ever, we are awaiting more challenges and
                      milestones to break. The family is up for it.
                    </p>
                    <span className="cd-date">August, 2018</span>
                  </div>
                </div>
                <div className="timeline-card">
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t21.jpg"
                    />
                    <h4>Spreading the word</h4>
                    <p>
                      Our co-founder, Hari shares his thoughts on travel and the
                      journey of Pickyourtrail to Tamil{' '}
                      <a
                        href="https://tamil.thehindu.com/business/article24423463.ece"
                        rel="nofollow noopener noreferrer"
                        target="_blank"
                      >
                        The Hindu
                      </a>{' '}
                      and Healthwealthbridge, a{' '}
                      <a
                        href="https://open.spotify.com/episode/2PygMmdcn2pssZmcGkqIHU"
                        target="_blank"
                        rel="nofollow noopener noreferrer"
                      >
                        podcast
                      </a>{' '}
                      by Dr.Amrita
                    </p>
                    <span className="cd-date">July, 2018</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t20.jpg"
                    />
                    <h4>On cloud nine</h4>
                    <p>
                      We were ecstatic after winning the 'Most Innovative Travel
                      Startup' award at the Travel Tech Launchpad Summit
                      organized by FICCI. That month we also did our highest
                      number of converts!
                    </p>
                    <span className="cd-date">March, 2018</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t19.jpg"
                    />
                    <h4>Love &amp; love only</h4>
                    <p>
                      We started the new year in style. Travel Boutique Online
                      awards us for being the best performing travel partner.
                      This catapulted us in doing great sales throughout the
                      month.
                    </p>
                    <span className="cd-date">February, 2018</span>
                  </div>
                </div>
                <div className={hiddenCardWTClassName}>
                  <div className="yearBlock">
                    <p>2017</p>
                  </div>

                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t18.jpg"
                    />
                    <h4>Crafting our story in Tamil</h4>
                    <p>
                      5000 trips in 3 years at a growth rate of 120% - Yourstory
                      celebrates our success story with a comprehensive Tamil
                      article. There is no greater joy &#x1F642;
                    </p>
                    <span className="cd-date">August, 2017</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t17.jpg"
                    />
                    <h4>The biggest bang of all time!</h4>
                    <p>
                      We have arrived! The Google-BCG Travel Trends Report of
                      2017 called us the benchmark in the industry for our
                      comprehensive customer experience!
                    </p>
                    <span className="cd-date">June, 2017</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t16.jpg"
                    />
                    <h4>Love from the press!</h4>
                    <p>
                      From being favourite startups for YourStory and Techinasia
                      to being featured in the Times of India, Economic Times,
                      and EnTracker - we felt loved!
                    </p>
                    <span className="cd-date">April, 2017</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://d3lf10b5gahyby.cloudfront.net/misc/t15.jpg"
                    />
                    <h4>We got a brand new look!</h4>
                    <p>
                      The quicker, faster and brilliant new Pickyourtrail got
                      launched to much applause! With a smart new logo to the
                      boot!
                    </p>
                    <span className="cd-date">March, 2017</span>
                  </div>
                </div>
                <div className={hiddenCardWTClassName}>
                  <div className="yearBlock">
                    <p>2016</p>
                  </div>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t14.jpg"
                    />
                    <h4>Bigger dreams, bigger spaces</h4>
                    <p>
                      Found out our quaint basement office couldn't handle our
                      buzz - we found a new home. Hola, T. Nagar!
                    </p>
                    <span className="cd-date">December, 2016</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t13.jpg"
                    />
                    <h4>Not just a number!</h4>
                    <p>
                      Our second breather to realize we crafted 1000 trails!
                      Yes!! The only way forward is up, my friend.
                    </p>
                    <span className="cd-date">November, 2016</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t12.jpg"
                    />
                    <h4>Been Down Under &amp; done that</h4>
                    <p>
                      Oi, we were recognized as an Aussie Specialist, mate! We
                      are now the official consultants to OZ!
                    </p>
                    <span className="cd-date">October, 2016</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t11.jpg"
                    />
                    <h4>Another milestone</h4>
                    <p>
                      We got into the Top 10 travel innovators at the
                      Phocuswright Asia-Pacific Travel Innovation Summit 2016!
                    </p>
                    <span className="cd-date">May, 2016</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t10.jpg"
                    />
                    <h4>We move home</h4>
                    <p>
                      With huge ambitions on the radar, we outgrew our cosy
                      home.We found a bigger office at Abiramapuram.
                    </p>
                    <span className="cd-date">February, 2016</span>
                  </div>
                </div>
                <div className={hiddenCardWTClassName}>
                  <div className="yearBlock">
                    <p>2015</p>
                  </div>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t09.jpg"
                    />
                    <h4>Recognising Talent</h4>
                    <p>Our first attempt at identifying culture keepers</p>
                    <span className="cd-date">October, 2015</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t07.jpg"
                    />
                    <h4>Things got Real-er!</h4>
                    <p>
                      Took a breather, counted, and realized we had crafted 300
                      trails. 300 happy stories! Ah, the joy!
                    </p>
                    <span className="cd-date">August, 2015</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t08.jpg"
                    />
                    <h4>We launched our App</h4>
                    <p>
                      We embraced technology as our soulmate - finally found a
                      team of techies! Aah, the stuff of epic love stories.
                    </p>
                    <span className="cd-date">July, 2015</span>
                  </div>
                </div>
                <div className={hiddenCardWTClassName}>
                  <div className="yearBlock">
                    <p>2014</p>
                  </div>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content" id="slide-right">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t06.jpg"
                    />
                    <h4>Hello world, it's Pickyourtrail!</h4>
                    <p>
                      Our first international trade fair at Singapore.
                      Pickyourtrail hogged the limelight!
                    </p>
                    <span className="cd-date">October, 2014</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t05.jpg"
                    />
                    <h4>Our first ever recognition!</h4>
                    <p>
                      Our caliber was measured awesome and we were listed among
                      the top ten in Tech Sparks Awards 2014.
                    </p>
                    <span className="cd-date">October, 2014</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t04.jpg"
                    />
                    <h4>Every hive needs a bee</h4>
                    <p>
                      We got our first employee, a multi-tasking travel
                      consultant. Little did we realise that we will turn
                      30-strong soon!
                    </p>
                    <span className="cd-date">May, 2014</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t02.jpg"
                    />
                    <h4>Our first home</h4>
                    <p>
                      A small, but cosy co-working space for Pickyourtrail. We
                      grew a little and moved again to a bigger place.
                    </p>
                    <span className="cd-date">April, 2014</span>
                  </div>
                </div>
                <div className={hiddenCardWTClassName}>
                  <div className="yearBlock">
                    <p>2013</p>
                  </div>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t03.jpg"
                    />
                    <h4>The first trail</h4>
                    <p>
                      Firsts are always cherished, a 4-nights trip to Chiang
                      Mai, Thailand. Happy travellers make us happy!
                    </p>
                    <span className="cd-date">December, 2013</span>
                  </div>
                </div>
                <div className={hiddenCardClassName}>
                  <div className="pyt-timeline-img" />
                  <div className="pyt-timeline-content">
                    <img
                      className="timeline-img"
                      src="https://dig82prjykzgf.cloudfront.net/t01.jpg"
                    />
                    <h4>The year it all began</h4>
                    <p>
                      Two travellers discovered their flair for vacation
                      planning on a EuroTrip. A year later, Pickyourtrail was
                      born.
                    </p>
                    <span className="cd-date">December, 2013</span>
                  </div>
                </div>
                <div className="view-more-outer">
                  <div className="view-more">
                    <button
                      className="btn btn-block btn-primary more-desk"
                      onClick={this.toggleMilestones}
                      id="more"
                    >
                      {viewMore
                        ? 'View less milestones'
                        : 'View more milestones'}
                    </button>
                  </div>
                </div>
                <span className="dashed-line" />
              </div>
            </div>
          </div>
        </section>
        <section className="founders-outer">
          <div className="container">
            <div className="row founders-inner">
              <div className="col-md-4 col-xs-12 founders">
                <h3>Hari Ganapathy</h3>
                <span className="designation">Co-Founder</span>
                <div className="founders-icon">
                  <a
                    target="_blank"
                    href="https://www.facebook.com/hari.ganapathy"
                    rel="noopener noreferrer"
                  >
                    <span className="vehoicon-facebook" />
                  </a>
                  <a
                    target="_blank"
                    href="https://twitter.com/haripyt"
                    rel="noopener noreferrer"
                  >
                    <span className="vehoicon-twitter vertical-middle" />
                  </a>
                  <a
                    target="_blank"
                    href="https://in.linkedin.com/in/hariganapathy"
                    rel="noopener noreferrer"
                  >
                    <span className="vehoicon-linkedin" />
                  </a>
                </div>
                <p className="desc">
                  Hari is your quintessential jack-of-all-trades. He has dabbled
                  roles across Strategy, Sales, Marketing and Investment
                  banking. His love for travel combined with the urge to leave a
                  dent in the universe drew him to Pickyourtrail. Having
                  achieved his 30 countries-by-30 goal, he's looking forward to
                  his dream trail - to experience the Trans-Siberian Railway.
                  Hari holds an MBA from IIM Bangalore.
                </p>
              </div>
              <div className="col-md-4 col-xs-12 founders">
                <h3>Srinath Shankar</h3>
                <span className="designation">Co-Founder</span>
                <div className="founders-icon">
                  <a
                    target="_blank"
                    href="https://www.facebook.com/srinath.shankar.92"
                    rel="noopener noreferrer"
                  >
                    <span className="vehoicon-facebook" />
                  </a>
                  <a
                    target="_blank"
                    href="https://twitter.com/shankar_srinath"
                    rel="noopener noreferrer"
                  >
                    <span className="vehoicon-twitter vertical-middle" />
                  </a>
                  <a
                    target="_blank"
                    href="https://www.linkedin.com/pub/srinath-shankarnarayanan/13/262/b45"
                    rel="noopener noreferrer"
                  >
                    <span className="vehoicon-linkedin" />
                  </a>
                </div>
                <p className="desc">
                  Bikes, Travel and Data are what give Srinath the high in life.
                  An All India True Wanderer 2.0 competition runner up and
                  Flickr photography finalist, he prides himself in having biked
                  18,000 km across India. His in-depth research and knowledge
                  about places continues to amaze us (and our customers).
                  Srinath holds an MBA from NMIMS, Bombay. His dream trail is to
                  explore the Australian outback on a bike.
                </p>
              </div>
              <div className="col-md-4 col-xs-12 founders">
                <i className="founders-img" />
              </div>
            </div>
          </div>
        </section>
        <section className="team-outer hidden-xs">
          <div className="container team-inner">
            <h2>Team</h2>
            <p className="team-intro">
              Behind every great story is a great (and growing) team working to
              build and recreate that story. Meet ours -{' '}
            </p>
            <ul id="og-grid" className="og-grid">
              {teamInfo.map((item, inx) => {
                if (item.active) {
                  return (
                    <SingleTeamMemberInfo
                      key={'team_cont_' + inx}
                      index={inx}
                      isExpanded={inx === this.state.expandIndex}
                      item={item}
                      expandThis={this.expandThis}
                    />
                  );
                }
              })}
            </ul>
          </div>
        </section>
        <section className="alumnus-outer hidden-xs">
          <div className="container alumnus-inner text-center">
            <div className="row">
              <h2 className="bold">Alumnus</h2>
              <p>We had a blast when they were with us!</p>
              <div className="alumnus-img">
                <ul>
                  <li>
                    <img src="https://d3lf10b5gahyby.cloudfront.net/alumnus/Akmal.png" />
                  </li>
                  <li>
                    <img src="https://d3lf10b5gahyby.cloudfront.net/alumnus/Farah.png" />
                  </li>
                  <li>
                    <img src="https://d3lf10b5gahyby.cloudfront.net/alumnus/Krishna.png" />
                  </li>
                  <li>
                    <img src="https://d3lf10b5gahyby.cloudfront.net/alumnus/Mugdha.png" />
                  </li>
                  <li>
                    <img src="https://d3lf10b5gahyby.cloudfront.net/alumnus/Poojitha.png" />
                  </li>
                  <li>
                    <img src="https://d3lf10b5gahyby.cloudfront.net/alumnus/Sushman.png" />
                  </li>
                  <li>
                    <img src="https://d3lf10b5gahyby.cloudfront.net/alumnus/Varsha.png" />
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </section>
    );
  }
}

const SingleTeamMemberInfo = props => (
  <li className={classNames({ 'og-expanded': props.isExpanded })}>
    <a href="#" onClick={e => props.expandThis(props.index, e)}>
      <SmartImage
        className="team-thumb"
        src={props.item.thumb}
        defaultImage={`https://i.kym-cdn.com/photos/images/original/000/724/811/13a.jpg`}
        alt={props.item.name}
      />
      <div className="team-title">
        <div>
          <h4>{props.item.name}</h4>
          <span>{props.item.aka}</span>
        </div>
      </div>
    </a>
    {props.isExpanded ? <ExpandedContainer {...props} /> : null}
  </li>
);

const ExpandedContainer = props => (
  <div
    className="og-expander"
    style={{ transition: 'height 350ms ease', height: 490 }}
  >
    <div className="og-expander-inner">
      <span
        className="og-close"
        onClick={e => props.expandThis(props.index, e)}
      />
      <div className="og-fullimg">
        <div className="og-loading" style={{ display: 'none' }} />
        <img src={props.item.largeImage} style={{ display: 'inline' }} />
      </div>
      <div className="og-details">
        <h4>{props.item.name}</h4>
        <span>{props.item.aka}</span>
        <p dangerouslySetInnerHTML={{ __html: props.item.desc }} />
      </div>
    </div>
  </div>
);
