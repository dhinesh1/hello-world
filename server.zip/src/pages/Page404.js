import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Status } from '../helpers/httpStatusHelper';
import Helmet from 'react-helmet';

class Page404 extends Component {
  render() {
    return (
      <Status code={404}>
        <Helmet>
          <title>404 Page not found</title>
        </Helmet>
        <div className="container xs-full-width notfound">
          <section className="row">
            <div className="col-sm-7 col-sm-push-5 astronaut-icon">
              <i />
            </div>
            <div className="col-sm-5 col-sm-pull-7">
              <p className="color-grey dim">
                Error code {this.props.status ? this.props.status : 404}{' '}
              </p>
              <h1 className="vmargin-medium bold">
                Oops! We don't do trails to outer space (yet).
              </h1>
              <p className="fade vmargin-large">
                Have you clicked on a wrong trail? Don't worry, it happens even
                to the best of us. Let's get you back to earth trails. We are
                still the best at it!
              </p>
              <Link to={'/customize'} className="btn btn-primary">
                Let's plan a trip back on earth
              </Link>
              <div className="clearfix vmargin-medium">
                <span className="fade">Or,</span>
                <ul className="list-unstyled mb-0">
                  <li>
                    <a href="https://blog.pickyourtrail.com">
                      Read the latest from our blog
                    </a>
                  </li>
                  <li>
                    <Link to="/about-us">More about us</Link>
                  </li>
                </ul>
              </div>
            </div>
          </section>
        </div>
      </Status>
    );
  }
}

export default Page404;
