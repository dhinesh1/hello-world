import React from 'react';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import Sticky from 'react-stickynode';

import { isFaqMobile, is_server } from '../helpers/utilsHelper';

import FloatingCTA from './landing/FloatingCTA';
import StickyFooterMobile from './landing/mobile_components/StickyFooterMobile';

class IndiaTravelGuide extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showFloatingCTA: false,
      showMobileFloatCTA: false
    };
  }

  componentDidMount() {
    if (!is_server()) {
      if (!isFaqMobile()) {
        const _that = this;
        window.addEventListener(
          'scroll',
          function() {
            let scroll = this.scrollY;
            if (
              (scroll > 360 && scroll < 520) ||
              (scroll < 16871 && scroll > 5044)
            ) {
              _that.setState({ showFloatingCTA: true });
            }

            if (scroll < 320 || scroll > 16871) {
              _that.setState({ showFloatingCTA: false });
            }
          },
          {
            capture: true,
            passive: true
          }
        );
      } else {
        const _that = this;
        window.addEventListener(
          'scroll',
          function() {
            let scroll = this.scrollY;
            if (scroll > 280 && scroll < 350) {
              _that.setState({ showMobileFloatCTA: true });
            }

            if (scroll < 280 && scroll > 100) {
              _that.setState({ showMobileFloatCTA: false });
            }
          },
          {
            capture: true,
            passive: true
          }
        );
      }
    }
  }

  render() {
    let { seoMetaData } = this.props;
    let { showFloatingCTA, showMobileFloatCTA } = this.state;

    return (
      <div>
        <FloatingCTA show={showFloatingCTA} />

        <Helmet>
          {seoMetaData ? <title>{seoMetaData.metaTitle}</title> : null}

          {seoMetaData ? (
            <meta name={'description'} content={seoMetaData.metaDescription} />
          ) : null}

          <meta
            property="og:image"
            content="https://pyt-images.imgix.net/images/product_blog/indias-wanderlust.png"
          />
          <meta
            property="og:image:url"
            content="https://pyt-images.imgix.net/images/product_blog/indias-wanderlust.png"
          />
          <meta
            property="og:image:secure_url"
            content="https://pyt-images.imgix.net/images/product_blog/indias-wanderlust.png"
          />
          <meta property="og:image:type" content="image/png" />
          <meta property="og:type" content="website" />
          <meta
            property="og:title"
            content={
              seoMetaData
                ? seoMetaData.metaTitle
                : '2018 International Travel Trends & Bucket Lists - #HowIndiaTravels!'
            }
          />
          <meta
            property="og:description"
            content={
              seoMetaData
                ? seoMetaData.metaDescription
                : 'Find out #HowIndiaTravels, top travel trends in 2018 for international locations & stories by recent Indian travellers. Also, discover the emerging travel destinations for couples, family and kids.'
            }
          />
          <meta
            property="og:url"
            content="https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas"
          />
        </Helmet>

        <section className="india-travel-trends">
          <div className="hero-banner">
            <div className="container">
              <div className="row">
                <div className="col-md-12 no-padding">
                  <div className="banner_content text-center">
                    <h1>
                      India's Wanderlust Tales
                      <span>2018 travel trends & bucket lists</span>
                    </h1>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="container xs-full-width">
            <div className="row">
              <div className="col-xs-12">
                <Sticky
                  enabled={!isFaqMobile()}
                  top={100}
                  bottomBoundary="#traveltrendContent"
                >
                  <div className="side-bar text-center">
                    <a
                      href="http://www.facebook.com/sharer.php?u=https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <i className="vehoicon-facebook-square" />
                    </a>
                    <a
                      href="https://twitter.com/share?url=https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas&amp;text=Check%20out%20India's%20Wanderlust%20Tales%202018%20-%20travel%20trends%20&%20bucket%20lists&amp;hashtags=pickyourtrail&amp;hashtags=keeptravelling&amp;hashtags=howindiatravels"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <i className="vehoicon-twitter" />
                    </a>
                  </div>
                </Sticky>
                <div className="article-outer" id="traveltrendContent">
                  <div className="article-content">
                    <p>
                      Madhavi and Kumar's home in Bengaluru is a place of
                      wonder. As you enter, you are transported to many places
                      all at once; a Barong mask from Bali welcomes you as a
                      windchime with little Eiffel towers tinkles away merrily.
                      A colourful part of the main hall catches the eye where
                      Oktoberfest beer mugs vie for attention with a cute little
                      cow from Switzerland. Every corner of their home is filled
                      with{' '}
                      <a
                        href="https://blog.pickyourtrail.com/best-souvenir-stories-from-across-the-world/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        souvenirs
                      </a>{' '}
                      from their travels across the globe. Inspired by this
                      couple? We were wonderstruck too.
                    </p>
                    <p>
                      When this Bengaluru couple got married three years ago,
                      they were given a DIY travel album as a gift. This set
                      them off to sincerely fill the pages and in the process
                      fall in love with travel itself. The couple finds
                      happiness in packing for their next adventure and quotes
                      Pico Iyer when asked for inspiration - "Serendipity is our
                      tour guide, assisted by caprice"! The duo has travelled to
                      more than 12 countries together and are looking to hit the
                      30 number in a short time. Which gets us to an interesting
                      fact, 30-by-30 travel goals are the biggest thing in
                      Indian social media currently.
                    </p>
                    <p>
                      With an increasing number of Indians like Madhavi and
                      Kumar packing their bags to exotic locales abroad, there's
                      a lot of wanderlust in the air. Travel seems to be giving
                      Indians a high and we at Pickyourtrail took a deeper look
                      into how Indians are travelling. We followed the trends of
                      why, how and where Indians are travelling - and discovered
                      that we Indians love travel and how!
                    </p>
                    <h2>75 million passports: Wanderlust hits India!</h2>
                    <p>
                      Allow us to throw a few numbers at you - in year 2000,
                      less than 5 million Indians were heading out of the
                      country. Today, around 20 million Indians are setting off
                      to foreign lands seeking new experiences. According to the
                      UNWTO, this number will increase exponentially to 50
                      million in the next three years.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/passport_2x.png"
                      alt="The little blue book aka the Indian Passport is all powerful. Access to 50+ visa-free countries and more!"
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      The little blue book aka the Indian Passport is all
                      powerful. Access to 50+ visa-free countries and more!
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      Now examine this, 75 million passports today in India, but
                      only 20 million people travelling? The huge gap only tells
                      us that there's going to be whole lot of travelling
                      Indians in the next few years. Visa regulations are also a
                      lot easier for Indian passport holders. The Indian
                      passport is a pretty powerful one: it ranks 59 on the
                      power index. This means Indians can travel to 59 countries
                      without a visa or an easy visa-on-arrival. Not just this,
                      if you hold an Indian passport and already have a valid US
                      visa, you can enter more than 15 countries such as
                      Philippines, Columbia and more. With barriers such as visa
                      slowly melting away, India is ready to explore the world.
                    </p>
                    <blockquote>
                      <mark>
                        The power of the Indian passport - travel visa free to
                        more than 50 countries!
                      </mark>
                      <a
                        href="https://twitter.com/share?url=https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas&amp;text=The power of the Indian passport - travel visa free to more than 50 countries! - @pickyourtrail&amp;hashtags=howindiatravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <span className="vehoicon-twitter" />
                      </a>
                    </blockquote>
                    <p>
                      We came across a<a
                        rel="nofollow noopener noreferrer"
                        href="https://timesofindia.indiatimes.com/business/india-business/in-a-first-travel-emerges-as-top-reason-for-indians-to-spend-money-abroad/articleshow/58332942.cms"
                        target="_blank"
                      >
                        {' '}
                        Times Of India
                      </a>{' '}
                      reportage that mentions that travel has turned out to be
                      the top reasons for Indians to spend money outside the
                      country. So it's not just Madhavi and Kumar who are
                      travelling, but a lot more Indians are looking to explore
                      the world. We sure are excited, more power to the Indian
                      Passport!
                      <br />
                      The number story clearly shows the exponential growth
                      that's set to happen. What's more interesting is the
                      changing preferences of the Indian traveller. From wanting
                      the comfort of travelling in groups to soaking in the
                      local culture, tasting local produce its a very important
                      transition as these habits help in the overall growth of
                      the economy.
                    </p>
                    <h2>The leisurely Indian and how he has changed</h2>
                    <p>
                      "It's precisely those who are busiest who most need to
                      give themselves a break", said someone famous. Looks like
                      we Indians are taking him very seriously indeed and giving
                      ourselves those leisurely breaks quite often. India's
                      holiday patterns are changing and dramatically too. We are
                      no longer tied to domestic holidays, but are open to
                      taking those leisure breaks abroad too.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/travellers%402x.png"
                      alt="Indians are vacationing more often! We take our vacations at least once a year, apart for business travel and family visits."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      Indians are vacationing more often! We take our vacations
                      at least once a year, apart for business travel and family
                      visits.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <h3>Who is travelling more?</h3>
                    <p>
                      No longer is the trip abroad reserved for the students or
                      working professionals. Among the 21 million Indians going
                      abroad, India Tourism discovered that more than 25% of
                      these travellers are going out of the country on a
                      holiday. As the number of outbound travellers from India
                      increases, the leisure traveller amongst these is also
                      increasing 25% Year-on-Year.{' '}
                    </p>
                    <h3>Booming economy, great internet, happy tourists</h3>
                    <p>
                      The UNWTO has ranked India as one of the fastest growing
                      outbound markets in the world with the volume of
                      travellers going up by 25% every year. India's population
                      is a young one when compared to highly populated countries
                      such as China.
                    </p>
                    <blockquote>
                      <mark>
                        In 2013, Indians took the international trip once in 21
                        months. Today, we holiday once in a year!
                      </mark>
                      <a
                        href="https://twitter.com/share?url=https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas&amp;text=In 2013, Indians took the international trip once in 21 months. Today, we holiday once in a year! - @pickyourtrail&amp;hashtags=howindiatravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <span className="vehoicon-twitter" />
                      </a>
                    </blockquote>
                    <p>
                      Outbound travel has also been impacted by the Modi
                      government's digital India move. The number of internet
                      users in India was 432 million in 2016 and is growing at a
                      8% rate, according to market research firm
                      <a
                        rel="nofollow noopener noreferrer"
                        href="http://www.livemint.com/Industry/QWzIOYEsfQJknXhC3HiuVI/Number-of-Internet-users-in-India-could-cross-450-million-by.html"
                        target="_blank"
                      >
                        {' '}
                        IMRB International
                      </a>. They also mention that the overall internet
                      penetration in India is 31%. This heightened exposure to
                      the internet has given the average Indian more chance to
                      see the world around him and get inspired to travel.
                    </p>
                    <p>
                      With a healthy GDP growth, booming economy and higher
                      spending incomes, travel is now more accessible to the
                      emerging middle class of India. Add to that a huge
                      increase in the number of
                      <a
                        href="https://blog.pickyourtrail.com/travel-hackers-guide-flight-fares-savings/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        low cost airlines
                      </a>{' '}
                      and you have more Indians becoming frequent flyers!
                    </p>
                    <h3>The great Indian family vacation(s)</h3>
                    <p>
                      With the world becoming their oyster, Indians are now
                      looking at at least one international vacation every year.
                      In 2013, the frequency at which Indians took a trip abroad
                      on leisure was 21 months. Today, the same has come down to
                      13 months, which is one trip a year. We work hard the
                      entire year, stick to domestic trips during smaller
                      holidays and then plan for that one gigantic family
                      vacation to a fabulous international destination.
                    </p>
                    <blockquote>
                      <mark>
                        After Zindagi Na Milegi Dobara released, Spain reported
                        80% hike in Indian tourists.
                      </mark>
                      <a
                        href="https://twitter.com/share?url=https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas&amp;text=After Zindagi Na Milegi Dobara released, Spain reported 80%25 hike in Indian tourists. - @pickyourtrail&amp;hashtags=howindiatravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <span className="vehoicon-twitter" />
                      </a>
                    </blockquote>
                    <p>
                      Indians travelling abroad, we noticed, like to make the
                      most of their vacation. An average international leisure
                      trip lasts for 12 - 14 days when it comes to places like
                      New Zealand, Australia or Europe. Locations in South East
                      Asia such as Bali, Thailand, Singapore are easily reached
                      and therefore the average vacation is planned for 5 - 7
                      days.
                    </p>
                    <h2>Re-defining the free independent traveller</h2>
                    <p>
                      When Priyanka and Dharmender Dubey first approached us at
                      Pickyourtrail for a honeymoon trip, they were looking at
                      the Andamans. The Dubeys were not aware that a beautiful
                      destination such as Bali was accessible at more or less
                      the same cost as that of an Indian holiday. They were
                      pleasantly shocked that they could fly abroad for their
                      honeymoon. They did and
                      <a
                        href="https://blog.pickyourtrail.com/why-bali-was-the-best-choice-for-our-honeymoon/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        wrote an ode
                      </a>{' '}
                      to beautiful Bali too.
                    </p>
                    <a
                      className="fw travel-trends-outer"
                      href="https://pickyourtrail.com/packages/the-7-day-guide-to-culture-and-nature-in-bali/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <div className="row travel-trends-box">
                        <div
                          className="col-md-4 col-sm-4 col-xs-3 travel-trends-left-img"
                          style={{
                            backgroundImage:
                              'url("https://pyt-images.imgix.net/images/product_blog/itinerary-box/bali-small.jpeg")'
                          }}
                        />
                        <div className="col-md-8 col-sm-8 col-xs-9 travel-trends-right-txt">
                          <h4>Beautiful Bali is waiting to be explored</h4>
                          <p>
                            <span className="hidden-xs">
                              Pack your bags for a 7 day culture trail to Ubud
                              and Seminyak
                            </span>
                            https://pickyourtrail.com
                          </p>
                        </div>
                      </div>
                    </a>
                    <p>
                      The definition of the Indian traveller is a pretty complex
                      one - there are people who travel for adventure, some for
                      food and others just to add the feather of a destination
                      to their travel hat. From the honeymooners who went to the
                      Andamans, to those who now go to Bali or the families that
                      now go on yearly vacations to the Swiss Alps or Iceland
                      even - Indian travellers are coming of age. Not just are
                      they vacationing abroad, the average Indian spends more
                      than the American travellers: UNWTO reports that Indian
                      travellers spend abroad is $1200 whereas the American only
                      spends $700! One other reason thats changing the consumer
                      behaviour is that international vacations are no more
                      inaccessible.
                    </p>
                    <blockquote>
                      <mark>
                        Did you know that the average Indian traveller spends
                        $1200 abroad while the American only spends $700!
                      </mark>
                      <a
                        href="https://twitter.com/share?url=https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas&amp;text=Did you know that the avg Indian traveller spends $1200 abroad while the American only spends $700! - @pickyourtrail&amp;hashtags=howindiatravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <span className="vehoicon-twitter" />
                      </a>
                    </blockquote>
                    <p>
                      At Pickyourtrail, we like to call travellers like Priyanka
                      and Dharmender - FIT or the Free Independent Traveller.
                      FITs are those who hate the coach tours, like to plan
                      their own travel, hate boring itineraries and love
                      unscheduled days. These are people who like to explore a
                      destination at their own pace, absorbing the country's
                      unique food, culture and ethos. Hence our motto - unwrap
                      the world{' '}
                    </p>
                    <p>
                      The FITs are not just the solo travellers or backpackers,
                      but also families or groups of friends who don't like to
                      tow the boring line. We would classify our FITs into two
                      broad categories - the young adventurer and the Family
                      travellers.{' '}
                    </p>
                    <h3>The young adventurer </h3>
                    <p>
                      India is counted as the 'youngest' among all countries in
                      the Asia Pacific region, considering the number of its
                      citizens below 30. The number of first time international
                      travellers such as the Dubeys are quite a large number.
                      According to a study by Amadeus, 23% of Indian leisure
                      travellers are under the 30 age group.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/travel-adventures.jpg"
                      alt="The trend among young Indian adventurers and honeymooners is to explore lesser known destinations and popular world festivals."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      The trend among young Indian adventurers and honeymooners
                      is to explore lesser known destinations and popular world
                      festivals.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      {' '}
                      Young Indians in the age group of 24 to 35 largely belong
                      to this category of first time international travellers.
                      They are either solo trippers, honeymooners or the
                      Double-Income-No-Kids (DINK) couples. Honeymooners form a
                      huge part of the total number of travellers we get at
                      Pickyourtrail. Considering these first timers are at an
                      age bracket that allows them to spend more on vacations,
                      they opt for more adventurous trails. From climbing
                      volcanoes in Bali to bungee jumping in New Zealand, they
                      are ready to splurge for an adrenaline packed adventure.
                    </p>
                    <h3>The family </h3>
                    <p>
                      Families with children are the other big travellers in the
                      leisure segment in India. The big annual holiday that most
                      families plan is now an international one. We have
                      families who travel together to Iceland on a roadtrip to
                      see the Northern Lights or the one that travelled to
                      celebrate a birthday or an anniversary to Egypt. While the
                      spending power of families may be lesser than the younger
                      couples or solo travellers, they do try to maximize their
                      vacation with as many activities as possible.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/family-vacations.jpg"
                      alt="The great Indian family vacations have moved to international destinations. Europe, NZ here we come!"
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      The great Indian family vacations have moved to
                      international destinations. Europe, NZ here we come!
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      Navin Ragade, our traveller is a well travelled man.
                      However, for his family, the Thailand trip was the first
                      ever international vacation. This was a special one that
                      celebrated his wife's birthday and turned out to be one
                      that the family looks back to always. Meanwhile, Navin is
                      planning his next vacation abroad.
                      <a
                        href="https://blog.pickyourtrail.com/best-thailand-family-vacation-itinerary/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Read his story here
                      </a>
                    </p>
                    <a
                      className="fw travel-trends-outer"
                      href="https://pickyourtrail.com/packages/7-grandeur-days-in-bangkok-and-pattaya-for-a-fun-holiday/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <div className="row travel-trends-box">
                        <div
                          className="col-md-4 col-sm-4 col-xs-3 travel-trends-left-img"
                          style={{
                            backgroundImage:
                              'url("https://pyt-images.imgix.net/images/product_blog/itinerary-box/thailand-small.jpeg")'
                          }}
                        />
                        <div className="col-md-8 col-sm-8 col-xs-9 travel-trends-right-txt">
                          <h4>Discover Thailand's hidden gems</h4>
                          <p>
                            <span className="hidden-xs">
                              Book your week long trip to Bangkok and Pattaya
                            </span>
                            https://pickyourtrail.com
                          </p>
                        </div>
                      </div>
                    </a>
                    <h2>Following the Indian traveller: Popular vacations</h2>
                    <p>
                      "Paris is always a good idea", said Audrey Hepburn. Our
                      travellers are nodding their head animatedly to this.
                    </p>
                    <p>
                      A week ago, we had a traveller who visited France,
                      Switzerland and Austria - three countries in 2 weeks.
                      While we did think it might have been a rush, Prashanth
                      did not seem to to think so. Such was his eagerness to see
                      as much of Europe as he could!{' '}
                    </p>
                    <p>
                      Yet another family is back from UK - London and Ireland,
                      with their toddlers in tow. London got Mithila quoting
                      Samuel Johnson while Ireland had her open mouthed with its
                      awe inspiring beauty. They did everything from building
                      castles in Legoland, rubbing shoulders with the Royal
                      family at Buckingham castle and driving through beautiful
                      Ireland.
                      <a
                        href="https://blog.pickyourtrail.com/the-ideal-united-kingdom-vacation-package-for-happy-families/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Here's their story
                      </a>.
                    </p>
                    <p>
                      It seems to us Europe holds a special place in the hearts
                      of Indians.
                    </p>
                    <h3>Where do we vacation?</h3>
                    <p>
                      UNWTO reports mention that Europe sees 20% of the
                      travellers from India's outbound traffic. Favourite
                      countries in Europe include UK, France, Italy, Germany and
                      Switzerland. European tourism boards have been focusing a
                      lot on Indian tourists and are welcoming them with warmth.
                      Europe has a special charm and appeals to the backpackers,
                      honeymooners and families in equal measure.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/favorites%402x.png"
                      alt="S.E Asia is a hot favourite with Indian travellers. Europe, New Zealand and Australia are popular destinations too."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      S.E Asia is a hot favourite with Indian travellers.
                      Europe, New Zealand and Australia are popular destinations
                      too.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      New Zealand and Australia take a fair share of the Indian
                      tourists. The UNTWO counts 10% of Indian outbound tourists
                      headed to these countries. Both these countries are
                      getting quite popular for adventure tourism:
                      <a
                        href="https://blog.pickyourtrail.com/10-ways-to-kick-up-some-fun-in-australia/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        Australia's
                      </a>{' '}
                      outbacks are well known in this respect. Not far behind is
                      <a
                        href="https://blog.pickyourtrail.com/9-reasons-why-skydiving-in-new-zealand-is-the-best/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        New Zealand
                      </a>{' '}
                      with its Nevis swing, the world's biggest swing and
                      adrenalin powered Jet Boating options.
                    </p>
                    <p>
                      The biggest part of Indian tourists go to Asia Pacific
                      region, namely Dubai, Singapore, Thailand, Malaysia and
                      Indonesia. Much of Indian tourists prefer South East Asian
                      destinations for two main reasons - top most being the
                      proximity therefore, less time wasted in travel. These
                      destinations also don't take us Indians too far from home
                      in terms of culture and food, the familiarity factor gives
                      a feeling of safety. This is more so for first time
                      travellers outside India.{' '}
                    </p>
                    <h3>When do we go for our vacations?</h3>
                    <blockquote>
                      <mark>
                        Summer vacations are not too far. Have you planned yours
                        yet? SOS to Pickyourtrail
                      </mark>
                      <a
                        href="https://twitter.com/share?url=https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas&amp;text=Summer vacations are not too far. Have you planned yours yet? Here's help. - @pickyourtrail&amp;hashtags=howindiatravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <span className="vehoicon-twitter" />
                      </a>
                    </blockquote>
                    <p>
                      While the new age Indian traveller is a different animal,
                      there are somethings that don't change. Vacations in India
                      are often associated with school vacations, the longest of
                      which is the summer holidays between April and June. It is
                      not surprising that Tourism India finds a half of
                      travellers prefer to take their trip abroad in this
                      period.{' '}
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/holidays%402x.png"
                      alt="We love summers! Nearly 50% of Indian travellers prefer to go on their international vacation between April and June."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      We love summers! Nearly 50% of Indian travellers prefer to
                      go on their international vacation between April and June.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      What is more surprising is that the segment of India that
                      preferred local hill stations during winter is now moving
                      to exotic locales abroad. More than 25% of travellers
                      visit international destinations during the months of
                      October to December. Winter destinations are quite
                      exciting, here's more on
                      <a
                        href="https://blog.pickyourtrail.com/chasing-the-snow-queen-exploring-white-winter-vacations-across-the-world/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        what they hold for you.
                      </a>
                    </p>
                    <h2>
                      Vacation planning: Breaking the barriers of boring
                      itineraries
                    </h2>
                    <p>
                      The Indian traveller is moving from packaged tours to
                      becoming the free independent traveller. Though these
                      independent travellers constitute a large part of the
                      traveller base in India, the era of the brick-and-mortar
                      travel agents is still not dead. A recent report by
                      research firm
                      <a
                        rel="nofollow noopener noreferrer"
                        href="http://www.integreon.com/The-Indian-Outbound-Traveler"
                        target="_blank"
                      >
                        {' '}
                        Integreon
                      </a>{' '}
                      highlights that 80% of travellers prefer booking their
                      vacation through travel agents. Only the remaining
                      minority prefer self planning.
                    </p>
                    <blockquote>
                      <mark>
                        Indians are breaking barriers. 20% of Indians book their
                        vacations online, a big move from the traditional travel
                        agent.
                      </mark>
                      <a
                        href="https://twitter.com/share?url=https://pickyourtrail.com/2018-travel-trends-international-vacations-ideas&amp;text=Indians are breaking barriers. 20%25 of Indians book their vacations online, a big move from the traditional travel agent. - @pickyourtrail&amp;hashtags=howindiatravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <span className="vehoicon-twitter" />
                      </a>
                    </blockquote>
                    <p>
                      This minority is a growing lot though. Which is one of the
                      reasons that we at Pickyourtrail prefer to be a Tech &
                      Touch company where people can talk to our people, yet let
                      technology and expertise help them plan their vacation.
                      Travel agents are associated with boring itineraries and
                      much of back and forth. Online tech travel companies like
                      us break these barriers and bring the freedom and pride of
                      self planning, with technology to bring in speed.
                    </p>
                    <h3>Vacation planning: not for the faint hearted!</h3>
                    <p>
                      We found that most travellers tend to run through nearly
                      30 sites online in the process of planning their vacation.
                      While people find flights in one place and hotels in
                      another, very few sites offer a complete traveller
                      experience. Say hello to Pickyourtrail.{' '}
                    </p>
                    <p>
                      <a
                        href="https://blog.pickyourtrail.com/how-to-plan-a-summer-vacation-across-two-countries-in-4-steps/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        Vikas Kyatsandra
                      </a>{' '}
                      from Bengaluru planned and booked his family's summer
                      vacation to Singapore and Thailand in exactly 2 hours. No,
                      that's not a typo there. He did book his entire 10 day
                      vacation in just 2 hours with Pickyourtrail! But that is
                      definitely not the case for the common man who goes
                      through many months of planning for that one international
                      vacation.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/bookingtime%402x.png"
                      alt="Nearly 50% of Indian travellers plan and book their international vacations within 30 days of travel."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      Nearly 50% of Indian travellers plan and book their
                      international vacations within 30 days of travel.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      According to reports of
                      <a
                        target="_blank"
                        href="https://pata.org/store/wp-content/uploads/2015/09/Ve_September_A4_Sept30-1.pdf"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        PATA
                      </a>, the planning process to an intern ational vacation
                      takes nearly double the time of the actual booking
                      process. By what we see, Indians prefer to book closer to
                      the date of travel. Nearly 45% of travellers book their
                      travel a month before they depart, while 25% take the
                      safer route of booking 1 to 3 months before the travel
                      date. Surprisingly, there is even a fairly large 20% of
                      travellers who decide to book their trip just a week
                      before they fly out!
                    </p>
                    <h2 className="article-header">
                      Where will India head to in the coming years?
                    </h2>
                    <p>
                      In 2010, the famous Julia Roberts starrer, 'Eat, Pray,
                      Love' hit the silver screen. All of a sudden, Bali was the
                      place to go to. While most of the world headed there, we
                      Indians were only beginning to wake up to the world of
                      travel. It wasn't exactly the era of low cost airlines,
                      you still had to pay full fare and worry about your
                      wallet.
                    </p>
                    <h3>The Bali bet</h3>
                    <p>
                      In 2013 when we launched Pickyourtrail, Bali was a small
                      island destination that not too many travel agents were
                      interested in marketing. Thailand and Malaysia were more
                      popular amongst both travellers and the agents.
                    </p>
                    <p>
                      We took a bet on Bali then and we haven't regretted!
                      Bali's value-for-money-vacations became a popular option
                      among Indians who wanted a close-by destination that easy
                      on their wallets. Bali is also one place where Indians
                      become millionaires; stay in 5-star accommodations at
                      3-star rates and experience a culture that is most
                      friendly. Today Bali is the budget destinations for
                      families, honeymooners or adventure seekers,
                      <a
                        href="https://blog.pickyourtrail.com/10-incredible-things-to-do-in-bali-that-will-change-your-life/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        here's an idea
                      </a>{' '}
                      of what Bali holds for you.
                    </p>
                    <h3>Emerging Tourist Destinations: Top 5 in 2018</h3>
                    <p>
                      In 2018, we are predicting that these are the locations
                      that are going to top the charts among Indian tourists.{' '}
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/hotlist%402x.png"
                      alt="We predict that Eastern Europe, Australia,  New Zealand, South Africa and Seychelles are going to be the hot destinations for travellers in 2018."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      We predict that Eastern Europe, Australia, New Zealand,
                      South Africa and Seychelles are going to be the hot
                      destinations for travellers in 2018.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      Here's our bucket-list for 2018. Plenty of reasons why you
                      should head there too.{' '}
                    </p>
                    <h4 className="subheading">1. Seychelles</h4>
                    <p>
                      <a
                        href="https://pickyourtrail.com/packages/seychelles/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Seychelles
                      </a>{' '}
                      is the next Maldives of 2018. This paradise comes ahead of
                      most island destinations across the world when it comes to
                      an idyllic holiday. With holidays becoming stress busters,
                      leisure vacation destinations are going to be much more in
                      demand. In 2015, Seychelles saw just 8000 Indians visiting
                      the islands, this has gone up by more than 40 per cent.
                      The archipelago is now on our list for the coming year,
                      what with celebrities like Prince William and Kate
                      honeymooning there.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/seychelles.jpeg"
                      alt="Seychelles is where British royalty honeymooned and is now a popular honeymoon or couple destination."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      Seychelles is where British royalty honeymooned and is now
                      a popular honeymoon or couple destination.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      Here are top reasons why Indians will head to Seychelles
                      in 2018:
                    </p>
                    <ul className="style-disc">
                      <li>Indians are exempted from Visa</li>
                      <li>Mumbai now has direct flights to Seychelles</li>
                      <li>No driving license required for Indian travellers</li>
                      <li>Accommodation getting more affordable</li>
                    </ul>
                    <h4 className="subheading">2. Australia</h4>
                    <p>
                      <a
                        href="https://pickyourtrail.com/packages/australia/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {' '}
                        Australia
                      </a>{' '}
                      Tourism recently revealed that the top five Aussie
                      attractions that Indian travellers look for are Australian
                      beaches, iconic landmarks, wildlife, food & wine and the
                      Great Barrier Reef. Not surprising that this year, more
                      than 2,70,000 travellers have been to Australia, almost
                      15% more than last year's arrivals.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/operahouse.jpeg"
                      alt="The Sydney Opera House was built in 1973 and is a UNESCO World Heritage site."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      The Sydney Opera House was built in 1973 and is a UNESCO
                      World Heritage site.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      The Land Down Under is definitely to be watched out for in
                      2018 we say. Take a pick from these reasons to choose Oz
                      as your next vacation spot.
                    </p>
                    <ul>
                      <li>
                        Melbourne, Adelaide and Perth are in the list of Top 10
                        world's most liveable cities. Melbourne has been on the
                        list for the seven years in a row.{' '}
                      </li>
                      <li>
                        The Great Barrier Reef is a huge draw for its amazing
                        colours and underwater diversity. A once in a lifetime
                        visit and a must on any worthy traveller's bucket list.{' '}
                      </li>
                      <li>
                        Indians rated Australia's food & wine as the best in the
                        world. The variety of cuisine that is available in this
                        country is like no other, even for vegetarians. The land
                        of Masterchef Australia after all.
                      </li>
                      <li>
                        Australia's free online visa application process only
                        makes it easier for Indians wanting to holiday. If you
                        have a decent travel history, you may even get a three
                        year, multiple entry visa.{' '}
                      </li>
                    </ul>
                    <a
                      className="fw travel-trends-outer"
                      href="https://pickyourtrail.com/packages/the-ideal-6-day-australia-vacation-itinerary-for-families/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <div className="row travel-trends-box">
                        <div
                          className="col-md-4 col-sm-4 col-xs-3 travel-trends-left-img"
                          style={{
                            backgroundImage:
                              'url("https://pyt-images.imgix.net/images/product_blog/itinerary-box/australia-small.jpeg")'
                          }}
                        />
                        <div className="col-md-8 col-sm-8 col-xs-9 travel-trends-right-txt">
                          <h4>
                            Book your vacation to the land of Kangaroos and
                            Kaolas
                          </h4>
                          <p>
                            <span className="hidden-xs">
                              Hop across Sydney, Cairns and Melbourne in a week.
                            </span>
                            https://pickyourtrail.com
                          </p>
                        </div>
                      </div>
                    </a>
                    <h4 className="subheading">3. South Africa</h4>
                    <p>
                      <a
                        href="https://pickyourtrail.com/get-packing/south-africa/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        South Africa
                      </a>{' '}
                      loves India. With India ranking eighth among all
                      international arrivals in South Africa, the country sure
                      has a soft corner for Indians. More than 80,000 people
                      have visited South Africa last year and in the coming
                      years, more than 1 lakh travellers are expected to visit.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/south-africa.jpeg"
                      alt="The Big Five of South Africa are the lion, leopard, rhino, cape buffalo and the elephant. Spot Zebras too!"
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      The Big Five of South Africa are the lion, leopard, rhino,
                      cape buffalo and the elephant. Spot Zebras too!
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>Here's why you should visit the country:</p>
                    <ul>
                      <li>
                        South Africa is becoming the preferred adventure
                        destination with its wild life safaris as a huge draw,
                        among other activities.
                      </li>
                      <li>
                        The country is a relatively economic stay with 15 night
                        vacation packages starting from INR 1 lakh upwards.{' '}
                      </li>
                      <li>
                        More than 3000 adventure tourism activities are
                        available for you to choose from.
                      </li>
                      <li>
                        There is no better place for wildlife photography than
                        South Africa.
                      </li>
                      <li>
                        The country has eased its Visa norms for Indians
                        considerably, and the process is faster too.
                      </li>
                    </ul>
                    <h4 className="subheading">4. New Zealand</h4>
                    <p>
                      When{' '}
                      <a
                        href="https://pickyourtrail.com/packages/new-zealand/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        New Zealand
                      </a>{' '}
                      roped in Bollywood star Siddharth Malhotra to promote the
                      tourism, Indian travellers discovered this beautiful
                      country. It still remains to be explored to its fullest
                      and we predict NZ will be where couples and families are
                      going to be headed to in the summer of 2018.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/sidharth-malhotra-nz.jpeg"
                      alt="New Zealand is a great place for adventure buffs."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      New Zealand is a great place for adventure buffs.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>
                      Why the land of the Kiwis is going to be hot in the coming
                      years:
                    </p>
                    <ul>
                      <li>
                        New Zealand is great for travellers who love to explore
                        on their own. Self drive holidays are the best way to
                        see the country.
                      </li>
                      <li>
                        While there are no direct flights, convenient hubs like
                        Kuala Lumpur, Singapore and Bangkok make NZ popular.
                      </li>
                      <li>
                        November to March is when most Indians go on vacations
                        for Christmas and summer vacations. This is a great time
                        to visit NZ, as the weather is great!
                      </li>
                      <li>
                        Adventure or leisure, honeymoons or families - New
                        Zealand is loved by all travellers.
                      </li>
                    </ul>
                    <a
                      className="fw travel-trends-outer"
                      href="https://pickyourtrail.com/packages/a-new-zealand-itinerary-for-14-fabulous-days/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <div className="row travel-trends-box">
                        <div
                          className="col-md-4 col-sm-4 col-xs-3 travel-trends-left-img"
                          style={{
                            backgroundImage:
                              'url("https://pyt-images.imgix.net/images/product_blog/itinerary-box/newzealand-small.jpeg")'
                          }}
                        />
                        <div className="col-md-8 col-sm-8 col-xs-9 travel-trends-right-txt">
                          <h4>
                            Book your trip to the magical land of the Maoris,
                            New Zealand
                          </h4>
                          <p>
                            <span className="hidden-xs">
                              Meet the Maoris, stargaze a bit, walk the glaciers
                              and more at NZ
                            </span>
                            https://pickyourtrail.com
                          </p>
                        </div>
                      </div>
                    </a>
                    <h4 className="subheading">5. Eastern Europe</h4>
                    <p>
                      <a
                        href="https://pickyourtrail.com/packages/europe/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Eastern Europe
                      </a>{' '}
                      is a part of the world that is yet to be discovered by
                      travellers. A region that is known as a backpackers jaunt,
                      this part of Europe is where we predict travellers are
                      going to be headed to. Slovenia, Croatia, Russia, Poland,
                      Hungary are some East European countries that are hotspots
                      when it comes to culture, scenic landscapes and even
                      cuisine. Russia's colourful spires and the legends of the
                      Kremlin are a magnet for travellers who are interested in
                      history and culture. On the other hand places such as
                      Prague and Austria is where you should be headed if you
                      are a romantic seeking beauty, beer or great food.
                    </p>
                  </div>
                  <figure>
                    <img
                      src="https://pyt-images.imgix.net/images/product_blog/eastern-europe-1.jpeg"
                      alt="Take up a Game of Thrones itinerary, Croatia is where you need to be headed to."
                    />
                    <a
                      href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                    <figcaption>
                      Take up a Game of Thrones itinerary, Croatia is where you
                      need to be headed to.
                    </figcaption>
                  </figure>
                  <div className="article-content">
                    <p>Why Eastern Europe you ask?</p>
                    <ul>
                      <li>
                        Eastern Europe is a fusion of contemporary and medieval
                        that is a rarity to be witnessed by any traveller.{' '}
                      </li>
                      <li>
                        A slew of movies and TV series have their shoot
                        locations here.{' '}
                      </li>
                      <li>
                        Eastern Europe is relatively less pricier than its more
                        well known cousins such as France and Italy
                      </li>
                      <li>
                        People are warm and welcoming, a great place to start
                        your European adventure.
                      </li>
                    </ul>
                    <p>
                      Our motto for 2018 is to live with no excuses and travel
                      with no regrets. Does our bucket-list look enticing? What
                      is yours? Get your travel goals set for the year and tell
                      us where you are headed. Do leave your comments on our
                      feature at{' '}
                      <a href="mailto:stories@pickyourtrail.com">
                        stories@pickyourtrail.com
                      </a>. Happy travels!
                    </p>
                    <a
                      className="fw travel-trends-outer"
                      href="https://pickyourtrail.com/packages/luxury-redefined-your-perfect-9-day-european-honeymoon/?utm_source=pickyourtrail.com&utm_campaign=HowIndiaTravels"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <div className="row travel-trends-box">
                        <div
                          className="col-md-4 col-sm-4 col-xs-3 travel-trends-left-img"
                          style={{
                            backgroundImage:
                              'url("https://pyt-images.imgix.net/images/product_blog/itinerary-box/europe-small.jpeg")'
                          }}
                        />
                        <div className="col-md-8 col-sm-8 col-xs-9 travel-trends-right-txt">
                          <h4>
                            Plan a trip to Europe, the melting pot of cultures
                          </h4>
                          <p>
                            <span className="hidden-xs">
                              Explore the scenic vistas of Paris, Amsterdam and
                              Venice in 9 days.
                            </span>
                            https://pickyourtrail.com
                          </p>
                        </div>
                      </div>
                    </a>
                    <div style={{ display: 'none' }}>
                      <a
                        className="fw travel-trends-outer"
                        href="https://pickyourtrail.com/packages/the-fascinating-five-day-dubai-package-for-the-adventure-lovers"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <div className="row travel-trends-box">
                          <div
                            className="col-md-4 col-sm-4 col-xs-3 travel-trends-left-img"
                            style={{
                              backgroundImage:
                                'url("https://pyt-images.imgix.net/images/product_blog/itinerary-box/dubai-small.jpeg")'
                            }}
                          />
                          <div className="col-md-8 col-sm-8 col-xs-9 travel-trends-right-txt">
                            <h4>Book your 5 day adventure to dazzling Dubai</h4>
                            <p>
                              <span className="hidden-xs">
                                Desert Safaris, cruises, skyscrapers and more
                                awaits in Dubai
                              </span>
                              https://pickyourtrail.com
                            </p>
                          </div>
                        </div>
                      </a>
                      <a
                        className="fw travel-trends-outer"
                        href="https://pickyourtrail.com/packages/beauty-and-charm-overloaded-an-offbeat-singapore-getaway"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <div className="row travel-trends-box">
                          <div
                            className="col-md-4 col-sm-4 col-xs-3 travel-trends-left-img"
                            style={{
                              backgroundImage:
                                'url("https://pyt-images.imgix.net/images/product_blog/itinerary-box/singapore-small.jpeg")'
                            }}
                          />
                          <div className="col-md-8 col-sm-8 col-xs-9 travel-trends-right-txt">
                            <h4>Explore Singapore with this 3 day trip</h4>
                            <p>
                              <span className="hidden-xs">
                                Discover Singapore in this quick weekend getaway
                              </span>
                              https://pickyourtrail.com
                            </p>
                          </div>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <StickyFooterMobile showMobileFloatCTA={showMobileFloatCTA} />
        </section>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    seoMetaData: state.app.seoMetaData
  };
}

export default connect(mapStateToProps)(IndiaTravelGuide);
