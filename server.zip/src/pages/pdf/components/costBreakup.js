import React from 'react';
import { getImgIXUrl } from '../../../helpers/utilsHelper';
import Footer from './footer';

export default function PDFCostBreakup({ content }) {
  if(!content.overview) return null;

  let hideSplitPricing = content.commonParams.hideSplitPricing;
  const hotelTitle =
    content.commonParams && content.commonParams.regionCode === 'mle'
      ? 'Hotels & Transfers'
      : 'Hotels';
  return (
    <div className="page cost-breakup-page">
      {!content.commonParams.agent ? (
        <img
          className="google-badge"
          src="https://pyt-images.imgix.net/images/pdf-assets/google_badge.png"
          width="155pt"
          height="191pt"
          alt={'google-badge'}
        />
      ) : null}

      <table align="center" className="pricing-breakup-table" cellSpacing={0}>
        <tbody>
          {/* SINGLE PRICING ROW STARTS*/}
          {content.overview.costEntities.map((costEntity, inx) => {
            return content.commonParams.packageRate ? (
              costEntity.type === 'FLIGHT_HOTELS' ? (
                <SinglePricingRow
                  key={costEntity.type + '_' + inx}
                  iconImage="https://pyt-images.imgix.net/images/pdf-assets/flight_hotels.png"
                  title={'Flights + Hotels'}
                  costEntity={costEntity}
                  hideSplitPricing={hideSplitPricing}
                />
              ) : null
            ) : (
              ((costEntity.type === 'FLIGHTS' ? (
                <SinglePricingRow
                  key={costEntity.type + '_' + inx}
                  iconClass={'vehoicon-flight'}
                  title={'Flights'}
                  costEntity={costEntity}
                  hideSplitPricing={hideSplitPricing}
                />
              ) : costEntity.type === 'HOTELS' ? (
                <SinglePricingRow
                  key={costEntity.type + '_' + inx}
                  iconClass={'vehoicon-local_hotel'}
                  title={hotelTitle}
                  costEntity={costEntity}
                  hideSplitPricing={hideSplitPricing}
                />
              ) : null): null)
            );
          })}
          {/* First loop to check if flights+hotels or only flights and hotels ends here */}

          {content.overview.costEntities.map((costEntity, inx) => {
            switch (costEntity.type) {
              case 'TRANSFERS':
                return (
                  <SinglePricingRow
                    key={costEntity.type + '_' + inx}
                    iconClass={'vehoicon-swap_vertical_circle'}
                    title={'Transfers'}
                    costEntity={costEntity}
                    hideSplitPricing={hideSplitPricing}
                  />
                );
              case 'ACTIVITIES':
                return (
                  <SinglePricingRow
                    key={costEntity.type + '_' + inx}
                    iconClass={'vehoicon-confirmation_number'}
                    title={'Activities'}
                    costEntity={costEntity}
                    hideSplitPricing={hideSplitPricing}
                  />
                );
              case 'SELF_EXPLORATION':
                return (
                  <SinglePricingRow
                    key={costEntity.type + '_' + inx}
                    iconClass={'vehoicon-confirmation_number'}
                    title={'Self Exploration Activities'}
                    costEntity={costEntity}
                    hideSplitPricing={hideSplitPricing}
                  />
                );
              case 'COMBOS':
                return (
                  <SinglePricingRow
                    key={costEntity.type + '_' + inx}
                    iconClass={'vehoicon-local_play'}
                    title={'Passes'}
                    costEntity={costEntity}
                    hideSplitPricing={hideSplitPricing}
                  />
                );
              case 'DISCOUNTS':
                return (
                  <SinglePricingRow
                    key={costEntity.type + '_' + inx}
                    iconImage={getImgIXUrl(
                      'https://d3lf10b5gahyby.cloudfront.net/pdf-assets/discounts-2x.png'
                    )}
                    title={'Discounts'}
                    costEntity={costEntity}
                    hideSplitPricing={hideSplitPricing}
                  />
                );
              case 'OTHERS':
                return (
                  <SinglePricingRow
                    key={costEntity.type + '_' + inx}
                    iconClass={'vehoicon-list'}
                    title={'Other Expenses'}
                    costEntity={costEntity}
                    hideSplitPricing={hideSplitPricing}
                  />
                );
              default:
                break;
            }
          })}
          {/* SINGLE PRICING ROW ENS */}
        </tbody>
      </table>
      <table className="breakup-footer-table" width="230px">
        <tbody>
          <tr>
            <td align="center">
              <h5>Total cost including taxes</h5>
              <span className="micro color-grey">
                As costed on {content.commonParams.quotedOnDateFormatted} at{' '}
                {content.commonParams.quotedOnTimeFormatted}
              </span>
              <h3 className="bold shrink-first">
                ₹{content.commonParams.totalCost}
              </h3>
              {content.commonParams.agent ? null : (
                <p className="price-fineprint">
                  The taxes and fees component includes - All government taxes
                  levied for your bookings. PickYourTrail service fee for
                  booking and concierge support. All currency conversion charges
                  wherever applicable
                </p>
              )}
            </td>
          </tr>
        </tbody>
      </table>

      {content.commonParams.agent ? null : (
        <div className="text-center">
          <a
            href={`${content.commonParams.itineraryUrl}`}
            className="pay-book-cta center"
          >
            Pay &amp; book your vacation
          </a>
        </div>
      )}

      {content.commonParams.agent ? null : <Footer />}
    </div>
  );
}

function SinglePricingRow({
  iconImage,
  iconClass,
  title,
  hideSplitPricing,
  costEntity
}) {
  return (
    <tr>
      <td className="table-icon-block" align="left">
        {iconClass ? (
          <span className={iconClass} />
        ) : (
          <img
            alt={'img-icon'}
            className="img-icon"
            src={iconImage}
            width={20}
          />
        )}
      </td>
      <td>
        <h5>{title}</h5>
        {hideSplitPricing ? null : (
          <span className="h6">{costEntity.percentage}% of cost</span>
        )}
      </td>
      <td align="right">
        {!hideSplitPricing ? (
          <h5 className="shrink-first">₹{costEntity.cost}</h5>
        ) : (
          <h5>
            <span className="vehoicon-check_circle included-tick" />
          </h5>
        )}
      </td>
    </tr>
  );
}
