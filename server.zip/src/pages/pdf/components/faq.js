import React from 'react';

export default function PDFFaq() {
  return (
    <div className="page">
      <header className="clearfix">
        <h1 className="pull-left">FAQ</h1>
      </header>
      <div className="qa">
        <section className="insidebreak-avoid">
          <h3 className="bold">
            Is this itinerary customizable? How can I make the changes to
            further personalize it according to my requirement?
          </h3>
          <p className="color-grey">
            Of course! This itinerary is completely yours and you can
            personalize it however you want your vacation to be! Just click on
            the link 'Make Changes' in this document and it will take you to
            your own Pickyourtrail itinerary anf you can 'Edit' the trip or
            'Change' flights or hotels or activities or anything you absolutely
            wish to do!
          </p>
        </section>
        <section className="insidebreak-avoid">
          <h3 className="bold">
            How do I know this itinerary suits my interests?
          </h3>
          <p className="color-grey">
            If you created this itinerary in our website, you would have noticed
            that we keep your interests in mind and use our smart algorithm to
            suggest the cities and activities that are most suitable for you.
            And if our travel consultants had a chat with you and sent this
            itinerary - Be rest assured they would have taken extra efforts to
            ensure this itinerary perfectly suits your requirements. you can
            always customize this itinerary further by clicking on 'Make
            Changes' link in this doc.
          </p>
        </section>
        <section className="insidebreak-avoid">
          <h3 className="bold">
            Will anyone be able to help me out in crafting my perfect itinerary?
          </h3>
          <p className="color-grey">
            You can craft your own awesome itinerary in just a few clicks.
            However, we do understand that you may still have queries on the
            itinerary or the destination. Travel consultants details are
            available in this document and they are just a call away! You can
            feel free to contact them anytime during 9.00am to 8.00pm from
            Mondays to Saturdays. You can also chat with our consultants from
            our website or request for a call back from our website and our team
            will be more than happy to help you with all your needs!
          </p>
        </section>
        <section className="insidebreak-avoid">
          <h3 className="bold">
            What kind of Visa Assistance would be provided by Pickyourtrail?
          </h3>
          <p className="color-grey">
            Visa isn't rocket science but it can be nerve wrecking for some
            destinations. Worry not! We are here to help. We will provide
            information on the documents that needs to be submitted, best
            practices for applying visa, how to book your appointment and assist
            you in the process throughout.
          </p>
        </section>
        <section className="insidebreak-avoid">
          <h3 className="bold">
            Is the itinerary costed real time? How long are these prices valid?
          </h3>
          <p className="color-grey">
            Yes, everything you see as a part of your itinerary is real-time
            costing and you would be able to book your vacation for those
            prices. However, the costs of flights, hotels and some activities
            are highly fluctuating and will change as per demand. Your costed
            itinerary will expire in 6 hours and you need to click on 'Update
            Cost' to view the current updated price for the itinerary.
          </p>
        </section>
        <section className="insidebreak-avoid">
          <h3 className="bold">
            How do I confirm and book this itinerary? When will I get my
            confirmations and vouchers?
          </h3>
          <p className="color-grey">
            You are vacation-ready! You can book the entire trip by paying just
            70% cost of the total cost. All your bookings will happen real time
            and you will be able download your vouchers for flights and hotels
            from the Your Trips page in our website within 24 hours from the
            time of booking. On full payment - you will get a consolidated set
            of vouchers for the entire vacation.
          </p>
        </section>
        <section className="insidebreak-avoid">
          <h3 className="bold">
            Do I need any documents that I need to submit to initiate booking?
          </h3>
          <p className="color-grey">
            No documents are required to confirm your bookings however please
            keep your passport copies handy. Kindly ensure that you type in the
            names only as per passport and double check on all the details you
            are keying in. In case you don’t have a last name on your passport,
            feel free to give your travel consultants a call so that they can
            help you out and ensure a hassle free booking experience. Happy
            Travels!
          </p>
        </section>
      </div>
    </div>
  );
}
