import React from 'react';
import moment from 'moment';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function PDFTestimonials({ content }) {
  return (
    <div className="page">
      {/* TESTIMONIALS PAGE STARTS*/}
      <div className="star-rating-box">
        <img
          className="logo-mark"
          alt="logo-mark"
          src={getImgIXUrl(
            'https://d3lf10b5gahyby.cloudfront.net/pdf-assets/facebook-logo.png'
          )}
          width="40px"
          height="40px"
        />
        <br />
        <img
          className="stars"
          alt="stars"
          src={getImgIXUrl(
            'https://d3lf10b5gahyby.cloudfront.net/pdf-assets/stars.png'
          )}
        />
        <p className="rating-text grey777">Aggregate ratings from 800+</p>
        <p className="rating-text grey777">Travellers on facebook</p>
      </div>
      <ul className="traveller-photo-grid">
        <li>
          <img
            alt={'testimonial-1'}
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/testimonials/1.jpg',
              'w=238&h=179&auto=compress&fit=facearea&facepad=10'
            )}
            width="238px"
            height="179px"
          />
        </li>
        <li>
          <img
            alt={'testimonial-2'}
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/testimonials/2.jpg',
              'w=354&h=179&auto=compress&fit=facearea&facepad=10'
            )}
            width="354px"
            height="179px"
          />
        </li>
        <li>
          <img
            alt={'testimonial-3'}
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/testimonials/3.jpg',
              'w=298&h=179&auto=compress&fit=crop'
            )}
            width="298px"
            height="179px"
          />
        </li>
      </ul>
      <ul className="traveller-photo-grid">
        <li>
          <img
            alt={'testimonial-4'}
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/testimonials/4.jpg',
              'w=194&h=179&auto=compress&fit=facearea&facepad=10'
            )}
            width="194px"
            height="179px"
          />
        </li>
        <li>
          <img
            alt={'testimonial-5'}
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/testimonials/5.jpg',
              'w=299&h=179&auto=compress&fit=crop'
            )}
            width="299px"
            height="179px"
          />
        </li>
        <li>
          <img
            alt={'testimonial-6'}
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/testimonials/6.png',
              'w=248&h=179&auto=compress&fit=crop'
            )}
            width="248px"
            height="179px"
          />
        </li>
        <li>
          <img
            alt={'testimonial-7'}
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/testimonials/7.jpg',
              'w=143&h=179&auto=compress&fit=crop'
            )}
            width="143px"
            height="179px"
          />
        </li>
      </ul>
      <div className="testimonial-box need-help">
        <div className="help-testimonials no-border">
          <div className="tst-btm">
            <div className="tst-img clearfix">
              <img
                className="pull-left"
                src={getImgIXUrl(
                  content.testimonial.profileImageUrl,
                  'w=32&h=32&auto=compress'
                )}
                alt={content.testimonial.personName}
              />
              <p className="pull-left">
                <b className="bold">{content.testimonial.personName}</b>{' '}
                reviewed <b className="bold">Pickyourtrail</b> -{' '}
                <i>{content.testimonial.star}</i>
                <span className="fw pull-left">
                  Travelled to {content.testimonial.destinationName} in{' '}
                  {moment(content.testimonial.travelDate).format(
                    'DD MMMM YYYY'
                  )}
                </span>
              </p>
            </div>
            <p className="color-grey">{content.testimonial.review}</p>
          </div>
        </div>
      </div>
      {/* TESTIMONIALS PAGE ENDS */}
    </div>
  );
}
