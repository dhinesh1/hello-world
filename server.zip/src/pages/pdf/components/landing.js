import React from 'react';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function PDFLanding({ content }) {
  if(!content.landingPage) return null;

  return (
    <div className="page cover-page">
      {/* COVER PAGE STARTS */}
      {!content.commonParams.agent ? (
        <img
          alt={'pyt-logo'}
          src="https://pyt-images.imgix.net/images/web_app/logo/pickyourtrail-logo.svg"
          width="203px"
        />
      ) : null}

      <h1 className="bold fs-46">{content.landingPage.pdfTitle}</h1>
      <img
        className="cover-city-image"
        src={`${getImgIXUrl(
          content.landingPage.pdfImageUrl,
          'w=440&h=705&fit=crop&auto=compress'
        )}`}
        width="440px"
        height="705px"
        alt={'city-cover'}
      />
      <div className="yellow-bg" />
      <div className="content-box">
        <ul className="list-unstyled">
          <li>
            <span className="text-green caps content-label bold">VISITING</span>{' '}
            <span className="content-value bold">
              {content.landingPage.visitingCitiesText}
            </span>
          </li>
          <li>
            <span className="text-green caps content-label bold">Duration</span>{' '}
            <span className="content-value bold">
              {content.landingPage.noOfNights} nights,{' '}
              {content.landingPage.noOfDays} days
            </span>
          </li>
          <li>
            <span className="text-green caps content-label bold">
              Departing
            </span>{' '}
            <span className="content-value bold">
              {content.commonParams.departureDateFormatted}{' '}
              {content.commonParams.departurePlace === 'Outside India'
                ? null
                : `from ${content.commonParams.departurePlace}`}
            </span>
          </li>
          <li>
            <span className="text-green caps content-label bold">
              travellers
            </span>{' '}
            <span className="content-value bold">
              {content.commonParams.adultCount} adult{content.commonParams
                .adultCount > 1
                ? 's'
                : null}
              {content.commonParams.childCount !== 0
                ? ` , ${content.commonParams.childCount} child${
                    content.commonParams.childCount > 1 ? 'ren' : ''
                  }`
                : null}
              {content.commonParams.infantCount !== 0
                ? ` , ${content.commonParams.infantCount} child${
                    content.commonParams.infantCount > 1 ? 's' : ''
                  }`
                : null}
            </span>
          </li>
        </ul>
        <h1 className="price-box fs-38">₹{content.commonParams.totalCost}</h1>
        <span className="quoted-on">
          QUOTED ON {content.commonParams.quotedOnDateFormatted}
        </span>
      </div>
      {/* COVER PAGE ENDS */}
    </div>
  );
}
