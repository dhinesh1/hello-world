import React from 'react';

export default function PDFGetQuote() {
  return (
    <div className="page">
      <header className="clearfix">
        <h1 className="pull-left">Got a quote?</h1>
      </header>
      <div className="qa">
        <section className="insidebreak-avoid">
          <h3 className="bold">
            For the quality service that Pickyourtrail offers, does it charge
            more than other travel companies?
          </h3>
          <p className="color-grey normal">
            Pickyourtrail is breaking the benchmark for service in travel
            industry but in spite of that we are one of the most cost effective
            travel companies in India and ensure that we offer only the best
            prices to our customers. Moreover, the best part of Pickyourtrail is
            customers have the liberty to choose and pick from a varied set of
            options across flights, hotels and activities and decide on what
            works best according to their requirement and budget.
          </p>
        </section>
        <section className="insidebreak-avoid">
          <h3 className="bold">
            Comparing with another quote? Wondering why the prices aren't the
            same?
          </h3>
          <p className="color-grey normal">
            The prices might vary between Pickyourtrail and other travel agents
            mainly because of the following reasons. Request you to take the
            efforts and compare so that you are not in for a shock later during
            your vacations.
          </p>
          <ul className="color-grey normal padded-list">
            <li>
              Pickyourtrail itineraries is completely personalized private tours
              whereas other travel agents plan a lot of group tours
            </li>
            <li>
              Check the layover time in flights - noted cases of transit time
              more than 8 hours!
            </li>
            <li>Confirm on the refundability status of hotels</li>
            <li>If all the acitivity inclusions are the same</li>
            <li>Review if all the transfer types are similar</li>
          </ul>
          <p className="color-grey normal">
            Also most importantly there might be taxes and fees that will be
            added at a later stage just before booking the vacation. In
            pickyourtrail, what you see is what you get. Once you have costed
            the itinerary, you would be able to book the itinerary at the exact
            same price.*
          </p>
        </section>
        <section className="insidebreak-avoid">
          <h3>
            If you have checked all the above and if you still find a competing
            quote from another travel company, we will not only match the offer
            but we will also offer upto ₹4000 cashback!*
          </h3>
          <p className="color-grey">
            * Terms and conditions apply and pickyourtrail holds the rights for
            approval according to its descretion
          </p>
        </section>
      </div>
    </div>
  );
}
