import React from 'react';
import { AppConfig } from '../../../app-config';
import { getImgIXUrl } from '../../../helpers/utilsHelper';
const CONTACT_NUMBER = AppConfig.website_contact_number;

export default function Footer() {
  return (
    <footer className="standard-footer text-center">
      <img
        src="https://pyt-images.imgix.net/images/web_app/logo/pickyourtrail-logo.svg"
        alt="pickyourtrail logo"
        width={146}
      />
      <p>
        No:36, Sudhama Commercial Building, 3rd Floor, Vijayaraghava Road,<br/>
        T.Nagar, Chennai 600017, Tamilnadu, India.
      </p>
      <p>
        <a href={`tel:+91${CONTACT_NUMBER}`}>
          <i className="vehoicon-phone_iphone color-pink" /> +91{' '}
          {CONTACT_NUMBER}
        </a>
        <a href="mailto:planners@pickyourtrail.com">
          <img
            src="https://pyt-images.imgix.net/images/pdf-assets/email-icon-pink.png"
            alt="Email"
          />{' '}
          planners@pickyourtrail.com
        </a>
      </p>
      <hr />
      <ul className="clearfix list-unstyled">
        <li>
          <img
            alt="Iceland logo"
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/misc/Ice-land-logo.png'
            )}
          />
        </li>
        <li>
          <img
            alt="Hong-Kong logo"
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/misc/hong-kong-logo.png'
            )}
          />
        </li>
        <li>
          <img
            alt="Aussie-logo"
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/misc/aussie-logo.png'
            )}
          />
        </li>
        <li>
          <img
            alt="Specialist Agent"
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/misc/nz-logo.png'
            )}
          />
        </li>
        <li>
          <img
            alt="Austrian Certified"
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/misc/austria-logo.png'
            )}
          />
        </li>
        <li>
          <img
            alt="philippines-logo"
            src={getImgIXUrl(
              'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/misc/philippines-logo.png'
            )}
          />
        </li>
      </ul>
    </footer>
  );
}
