import React from 'react';

export default function PDFOthers({ content }) {
  return (
    <div className="page">
      <header className="clearfix">
        <h1 className="pull-left">Others</h1>
      </header>
      <div className="others">
        {/* others-row starts */}
        {content.others.insuranceIncluded && content.others.insurance ? (
          <section className="clearfix section-block insidebreak-avoid">
            <div className="clearfix icon-title-block">
              <div className="pull-left col-70">
                <div className="pull-left icon">
                  <i className="vehoicon-security" />
                </div>
                <div className="pull-left col-90">
                  <h5 className="bold">
                    Travel Insurance for{' '}
                    {content.others.insurance.countriesCommaSeperateText}
                  </h5>
                  <p className="color-grey">
                    {content.others.insurance.plan} for{' '}
                    {content.commonParams.totalPax} person(s).
                  </p>
                  <div className="others-txt color-grey">
                    <ul className="list-unstyled cmn-list">
                      {content.others.insurance.inclusions.map(
                        (insuranceList, inInx) => {
                          return (
                            <li key={'insurance_' + inInx}>{insuranceList}</li>
                          );
                        }
                      )}
                    </ul>
                  </div>
                </div>
              </div>
              <div className="pull-left col-30 text-right">
                {content &&
                content.others &&
                content.others.insurance.totalInsuranceCost ? (
                  <h6 className="color-grey shrink-first">
                    ₹ {content.others.insurance.totalInsuranceCost}
                  </h6>
                ) : null}
                <p className="color-pink micro">NON-REFUNDABLE</p>
              </div>
            </div>
          </section>
        ) : null}
        {/* others-row ends */}

        {content.others.visaIncluded && content.others.visaCostings
          ? content.others.visaCostings.map((visa, vInx) => {
              return (
                <section
                  className="clearfix section-block insidebreak-avoid"
                  key={'visa_' + vInx}
                >
                  <div className="clearfix icon-title-block">
                    <div className="pull-left col-70">
                      <div className="pull-left icon">
                        <i className="vehoicon-security" />
                      </div>
                      <div className="pull-left col-90">
                        <h5 className="bold">
                          Visa information for {visa.country}
                        </h5>
                        <div className="others-txt color-grey">
                          {visa.schengen ? (
                            <ul className="list-unstyled cmn-list">
                              <li>Our visa success rate has been 98.8%.</li>
                              <li>Charges for visa assistance applicable</li>
                              <li>
                                Visa assistance is to enable the entire visa process such as booking appointments, 
                                helping with documentation checklist however visa filling and other requirement has 
                                to be borne by the customer.
                              </li>
                              <li>
                                Granting of visa is at the discretion of the
                                visa issuing authority.
                              </li>
                              <li>
                                We are not responsible for the Visa issue delays
                                post your submission. However, we will help you
                                with the expedite process.
                              </li>
                            </ul>
                          ) : visa.onArrival ? (
                            <p>Visa is free on arrival.</p>
                          ) : (
                            <p>
                              Our visa success rate has been 98.8%. Charges for
                              visa assistance applicable End to end support on
                              the entire visa process, documentation,
                              appointment booking and other queries. Granting of
                              visa is at the discretion of the visa issuing
                              authority. We are not responsible for the Visa
                              issue delays post your submission. However, we
                              will help you with the expedite process.
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="pull-left col-30 text-right">
                      {visa.totalCost ? (
                        <h6 className="color-grey shrink-first">
                          ₹ {visa.totalCost}
                        </h6>
                      ) : null}
                      <p className="color-pink micro">NON-REFUNDABLE</p>
                    </div>
                  </div>
                </section>
              );
            })
          : null}
      </div>
    </div>
  );
}
