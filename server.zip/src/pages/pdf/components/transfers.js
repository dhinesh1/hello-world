import React from 'react';
import PDFPageHeader from './header';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function PDFTrasnsfers({ content }) {
  let transferType = false;
  return (
    <div className="page">
      <PDFPageHeader content={content} pageTitle={'Transfers'} />

      {content.pdfTransfers.transfers.map((transfer, inx) => {
        if(transfer.status !== "SUCCESS") return null;

        if (transfer.type === 'SHARED') {
          transferType = true;
        }
        return (
          <section
            className="clearfix section-block insidebreak-avoid"
            key={'transfers_' + inx}
          >
            {/* transfers-row starts */}
            <div className="clearfix icon-title-block">
              <div className="pull-left col-70">
                <div className="pull-left icon">
                  {transfer.type === 'PRIVATE' ? (
                    <i className="vehoicon-directions_car" />
                  ) : (
                    <i className="vehoicon-directions_bus" />
                  )}
                </div>

                <div className="pull-left col-90">
                  <h5 className="bold">{transfer.text}</h5>
                  <p>
                    <b className="bold">
                      {transfer.day} {transfer.mon}
                    </b>,
                    {transfer.dayOfWeek} .{' '}
                    <span className="color-grey">
                      {transfer.numberOfVehicles} {transfer.vehicle}
                    </span>
                  </p>
                  {content.commonParams.regionCode === 'eur' &&
                  transfer.vehicle.toUpperCase() === 'CAR' ? (
                    <p className="micro color-grey pt-10">
                      <span className={'bold'}>Note:</span> These transfers have
                      a strict no. of luggage and dimension restriction -
                      Baggage allowed per person is one handbag + medium size
                      baggage (158cm)
                    </p>
                  ) : null}
                </div>
              </div>

              <div className="pull-left col-30 text-right">
                {transfer.inCombo ? (
                  <span className="color-green micro bold">
                    INCLUDED IN COMBO
                  </span>
                ) : transfer.inSwissPass ? (
                  <span className="color-green micro bold">
                    INCLUDED IN SWISS PASS
                  </span>
                ) : transfer.publishedCost ? (
                  <h6 className="color-grey">₹ {transfer.publishedCost}</h6>
                ) : null}
                <p className="color-grey micro">REFUNDABLE</p>
              </div>
            </div>
            {/* transfers-row ends */}
          </section>
        );
      })}

      {content.pdfTransfers.ferries.map((ferry, inx) => {
        if(ferry.status !== "SUCCESS") return null;

        return (
          <section
            className="clearfix section-block insidebreak-avoid"
            key={'ferry_' + inx}
          >
            {/* transfers-row starts */}
            <div className="clearfix icon-title-block">
              <div className="pull-left col-70">
                <div className="pull-left icon">
                  <i className="vehoicon-directions_boat" />
                </div>
                <div className="pull-left col-90">
                  <h5 className="bold">{ferry.text}</h5>
                  <p>
                    <b className="bold">
                      {ferry.day} {ferry.mon}
                    </b>, {ferry.dayOfWeek} .{' '}
                    <span className="color-grey">1 Ferry</span>
                  </p>
                </div>
              </div>
              <div className="pull-left col-30 text-right">
                {ferry.publishedCost ? (
                  <h6 className="color-grey shrink-first">
                    ₹ {ferry.publishedCost}
                  </h6>
                ) : null}
                <p className="color-grey micro">REFUNDABLE</p>
              </div>
            </div>
            {/* transfers-row ends */}
          </section>
        );
      })}

      {content.pdfTransfers.trains.map((train, inx) => {
        if(train.status !== "SUCCESS") return null;

        return (
          <section
            className="clearfix section-block insidebreak-avoid"
            key={'train_' + inx}
          >
            {/* train transfers-row starts */}
            <div className="clearfix icon-title-block">
              <div className="pull-left col-70">
                <div className="pull-left icon">
                  <i className="vehoicon-train" />
                </div>
                <div className="pull-left col-90">
                  <h5 className="bold">{train.text}</h5>
                  <p>
                    <span className="color-grey">
                      Duration {train.duration}{' '}
                    </span>{' '}
                    <br />
                    {train.stops ? (
                      <span className="color-grey">
                        {train.stops} {train.stops > 1 ? 'stops' : 'stop'} ({' '}
                        {train.stopNames} )
                      </span>
                    ) : null}
                  </p>
                </div>
              </div>
              <div className="pull-left col-30 text-right">
                {train.inCombo ? (
                  <span className="color-green micro bold">
                    INCLUDED IN COMBO
                  </span>
                ) : train.inSwissPass ? (
                  <span className="color-green micro bold">
                    INCLUDED IN SWISS PASS
                  </span>
                ) : train.publishedCost ? (
                  <h6 className="color-grey">₹ {train.publishedCost}</h6>
                ) : null}

                {train.refundable ? (
                  <p className="color-grey micro">REFUNDABLE</p>
                ) : (
                  <p className="color-pink micro">NON REFUNDABLE</p>
                )}
              </div>
            </div>
            <table
              className="img-block"
              width="100%"
              border={0}
              cellPadding={0}
              cellSpacing={0}
            >
              <tbody>
                <tr>
                  <td className="img-lft" width="15%">
                    <img
                      src={getImgIXUrl(
                        'https://d3lf10b5gahyby.cloudfront.net/pdf-assets/train.jpeg',
                        'w=100&h=60&auto=compress'
                      )}
                      alt="Train"
                    />
                  </td>
                  <td className="img-rgt" width="85%">
                    <table
                      width="100%"
                      border={0}
                      cellPadding={0}
                      cellSpacing={0}
                    >
                      <tbody>
                        <tr>
                          <td align="left" className="col-3 time">
                            <h5 className="color-grey">
                              {train.departureTime}
                            </h5>
                            <p>
                              <b className="bold">
                                {train.day} {train.mon}
                              </b>,
                              {train.dayOfWeek}
                            </p>
                            <p className="micro">{train.pickup}</p>
                          </td>
                          <td align="center" className="col-3 time">
                            <i className="color-grey vehoicon-ion-android-time" />
                            <h5 className="color-grey micro">
                              {train.duration}
                            </h5>
                          </td>
                          <td align="right" className="col-3 time">
                            <h5 className="color-grey">{train.arrivalTime}</h5>
                            <p>
                              <b className="bold">
                                {train.day} {train.mon}
                              </b>,
                              {train.dayOfWeek}
                            </p>
                            <p className="micro">{train.drop}</p>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
            {/* train transfers-row ends */}
          </section>
        );
      })}

      {content.pdfTransfers.cars.map((car, inx) => {
        if(car.status !== "SUCCESS") return null;

        return (
          <section
            key={"transfers_"+inx}
            className="clearfix section-block insidebreak-avoid">
            {/* car transfers-row starts */}
            <div className="clearfix icon-title-block">
              <div className="pull-left col-70">
                <div className="pull-left icon">
                  <i className="vehoicon-directions_car" />
                </div>
                <div className="pull-left col-90">
                  <h5 className="bold">{car.text}</h5>
                  <p>
                    <span className="color-grey">
                      Self Drive Car . {car.duration} days rental
                    </span>
                  </p>
                </div>
              </div>
              <div className="pull-left col-30 text-right">
                {car.totalCost ? (
                  <h6 className="color-grey shrink-first">₹ {car.totalCost}</h6>
                ) : null}

                <p className="color-pink micro">NON REFUNDABLE</p>
              </div>
            </div>
            <table
              className="img-block"
              width="100%"
              border={0}
              cellPadding={0}
              cellSpacing={0}
            >
              <tbody>
                <tr>
                  <td className="img-lft" width="15%">
                    <img
                      src={getImgIXUrl(
                        'https://d3lf10b5gahyby.cloudfront.net/pdf-assets/car.jpg',
                        'w=100&h=60&auto=compress'
                      )}
                      alt="Car"
                    />
                  </td>
                  <td className="img-rgt" width="85%">
                    <table
                      width="100%"
                      border={0}
                      cellPadding={0}
                      cellSpacing={0}
                    >
                      <tbody>
                        <tr>
                          <td align="left" className="col-3 time">
                            <h5 className="color-grey">{car.pickupTime}</h5>
                            <p>
                              <b className="bold">
                                {car.pickupDate} {car.pickupMonth}
                              </b>,
                              {car.pickupDayOfWeek}
                            </p>
                            <p className="micro">{car.pickup}</p>
                          </td>
                          <td align="left" className="col-3 time">
                            <h5 className="color-grey">{car.dropTime}</h5>
                            <p>
                              <b className="bold">
                                {car.dropDate} {car.dropMonth}
                              </b>,
                              {car.dropDayOfWeek}
                            </p>
                            <p className="micro">{car.drop}</p>
                          </td>
                          <td align="left" className="col-3 time">
                            <p className="color-grey">
                              Type: {car.carType}
                              <br />
                              GPS:{' '}
                              {car.gpsIncluded ? 'Included' : 'Not included'}
                              <br />
                            </p>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
            {/* car transfers-row ends */}
          </section>
        );
      })}

      {content.commonParams.regionCode === 'aus' && transferType ? (
        <p className="fs-12 color-grey">
          Note: Shared shuttle timings vary depending on the number of
          travellers - transfer departures are usually on an hourly basis
        </p>
      ) : null}
    </div>
  );
}
