import React from 'react';
import moment from 'moment';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function PDFNeedHelp({ content }) {
  if(!content.needHelp) return null;

  return (
    <div className="page">
      <header className="clearfix">
        <h1 className="pull-left">Need Help?</h1>
      </header>
      <div className="container need-help">
        <section className="help-avatar text-center">
          <img
            src={getImgIXUrl(content.needHelp.salesExpert.profileImage)}
            alt={content.needHelp.salesExpert.userName}
          />
        </section>
        <section className="help-testimonials insidebreak-avoid">
          <div className="address text-center">
            <b className="bold">{content.needHelp.salesExpert.userName}</b>
            <p>
              {content.needHelp.salesExpert.tripsPlanned} trips planned,
              {content.needHelp.salesExpert.descriptiveTag}.<br />
              {
                content.needHelp.salesExpert.expertTag
              }.<a href="tel:$content.needHelp.salesExpert.mobileNumber">
                <i className="vehoicon-phone_iphone" />{' '}
                {content.needHelp.salesExpert.countryPhoneCode}
                {content.needHelp.salesExpert.mobileNumber}
              </a>
            </p>
          </div>
          <div className="tst-btm insidebreak-avoid">
            <div className="tst-img clearfix insidebreak-avoid">
              <img
                className="pull-left"
                src={getImgIXUrl(
                  content.needHelp.expertTestimonial.profileImageUrl,
                  'w=32&h=32&auto=compress'
                )}
                alt={content.needHelp.expertTestimonial.personName}
              />
              <p className="pull-left">
                <b className="bold">
                  {content.needHelp.expertTestimonial.personName}
                </b>{' '}
                reviewed <b className="bold">Pickyourtrail</b> -{' '}
                <i>{content.needHelp.expertTestimonial.star}</i>
                <span className="fw">
                  Travelled to{' '}
                  {content.needHelp.expertTestimonial.destinationName} in{' '}
                  {moment(content.needHelp.expertTestimonial.travelDate).format(
                    'DD MMMM YYYY'
                  )}
                </span>
              </p>
            </div>
            <p className="color-grey insidebreak-avoid">
              {content.needHelp.expertTestimonial.review}
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
