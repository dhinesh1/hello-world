import React from 'react';
import PDFPageHeader from './header';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function PDFItineray({ content }) {
  if(!content.itinerary) return null;

  return (
    <div className="page itinerary-page">
      <PDFPageHeader content={content} pageTitle={'Itinerary'} />

      <div className="itinerary-container">
        {content.itinerary.iterCities.map((city, inx) => {
          return (
            <div className="single-itinerary-city" key={'single_itin_' + inx}>
              <div className="city-content">
                <img
                  alt={'map-marker'}
                  src={getImgIXUrl(
                    'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/map-marker-icon.png'
                  )}
                  width="40px"
                  height="40px"
                />
                <h5 className="bold city-title">
                  {city.cityName}, {city.countryName}
                </h5>
                <span>
                  {city.noOfNights} Night{city.noOfNights > 1 ? 's' : null} stay
                </span>
              </div>
              {city.iterDays.map((day, dInx) => {
                return (
                  <table
                    className="itinerary-table"
                    cellSpacing={5}
                    key={'day_' + dInx}
                  >
                    <tbody>
                      {day.slotPlans.map((slot, sInx) => {
                        return (
                          <tr key={'slot_' + sInx}>
                            <td className="date-block" valign="top">
                              {sInx === 0 ? day.displayDate : null}
                            </td>
                            <td>
                              <span className="slot-name">{slot.slotText}</span>{' '}
                              -{' '}
                              <span className="slot-text">
                                {slot.slotDescription}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}
