import React from 'react';
import PDFPageHeader from './header';

export default function PDFCombos({ content }) {
  if(!content.pdfCombos.pdfCombos) return null;

  return (
    <div className="page">
      <PDFPageHeader content={content} pageTitle={'Pass'} />

      <div className="combo">
        {content.pdfCombos.pdfCombos.map((combo, inx) => {
          return (
            <section key={"combo_"+inx} className="clearfix section-block insidebreak-avoid">
              <div className="clearfix icon-title-block">
                <div className="pull-left col-70">
                  <div className="pull-left icon">
                    <i className="vehoicon-confirmation_number" />
                  </div>
                  <div className="pull-left col-90">
                    <h5 className="bold">{combo.title}</h5>
                    <p className="color-grey">{combo.description}</p>
                  </div>
                </div>
                <div className="pull-left col-30 text-right">
                  {combo.totalCost ? (
                    <h6 className="color-grey shrink-first">
                      ₹ {combo.totalCost}
                    </h6>
                  ) : null}
                </div>
              </div>

              <table cellPadding={0} cellSpacing={0}>
                <tbody>
                  <tr>
                    <td className="savings-title text-center" colSpan={2}>
                      You make{' '}
                      <span className="color-pink">
                        {combo.savingsPercentage}% savings
                      </span>{' '}
                      (₹{combo.savings}) over the actual price by choosing this
                      combo
                    </td>
                  </tr>
                  <tr>
                    <td width="20%">&nbsp;</td>
                    <td width="80%">
                      <h5>Inclusions</h5>
                    </td>
                  </tr>
                  {combo.inclusions.map((inclusion, inInx) => {
                    return (
                      <tr key={"combo_inc_"+inInx}>
                        <td valign="top" width="20%">
                          {inclusion.date} {inclusion.month}
                        </td>
                        <td width="80%">
                          <p>
                            {inclusion.title}{' '}
                            {inclusion.transferType !== null ? (
                              <span className="color-grey micro db">
                                {inclusion.transferType}
                              </span>
                            ) : null}
                          </p>
                        </td>
                      </tr>
                    );
                  })}
                  <tr>
                    <td width="20%">&nbsp;</td>
                    <td width="80%">
                      <h5>Other Inclusions</h5>
                      <ul className="list-unstyled cmn-list">
                        {
                          combo.otherInclusions.map((otherInclusions, oInx) => {
                            return <li key={"other_inc_"+oInx}>{otherInclusions}</li>
                          })
                        }
                      </ul>
                    </td>
                  </tr>
                </tbody>
              </table>
            </section>
          );
        })}
      </div>
    </div>
  );
}
