import React from 'react';
import Footer from './footer';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function PDFFinalPage({ content }) {
  return (
    <div className="page with-std-ftr">
      <div className="globe-bg text-center">
        <img
          src={getImgIXUrl(
            'https://d3lf10b5gahyby.cloudfront.net/pdf-assets/vacation-image.png',
            'w=320&h=296&auto=compress'
          )}
          alt="Happy Vacations"
        />
        {content.commonParams.agent ? null : (
          <div className="clearfix">
            <a className="color-grey" href="https://pickyourtrail.com/">
              pickyourtrail.com
            </a>
          </div>
        )}
      </div>
      {content.commonParams.agent ? null : <Footer />}
    </div>
  );
}
