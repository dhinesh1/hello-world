import React from 'react';
import PDFPageHeader from './header';
import { AppConfig } from '../../../app-config';
import _ from 'lodash';
import {
  getImgIXUrl,
  getConnectionDuration
} from '../../../helpers/utilsHelper';
const AIRLINE_CDN = AppConfig.airline_cdn;

export default function PDFFlights({ content }) {
  if(!content.pdfFlights) return null;

  return (
    <div className="page">
      <PDFPageHeader content={content} pageTitle={'Flights'} />

      <div className="flights">
        {/* transit-row starts */}

        {content.pdfFlights.flights.map((flight, inx) => {
          return (
            <section className="clearfix section-block" key={'flight_' + inx}>
              <div className="clearfix icon-title-block insidebreak-avoid">
                <div className="pull-left col-70">
                  <div className="pull-left icon">
                    <i className="vehoicon-flight" />
                  </div>
                  <div className="pull-left col-90">
                    <h5 className="bold">{flight.text}</h5>
                    {flight.status === 'BLOCKED' ? (
                      <p className="color-grey">
                        PNR: {flight.pnr} . Blocked till {flight.expiresIn}
                      </p>
                    ) : flight.trips.length > 1 ? (
                      <p className="color-grey">Round trip flight</p>
                    ) : (
                      <p className="color-grey">One way flight</p>
                    )}
                  </div>
                </div>
                <div className="pull-left col-30 text-right">
                  {flight.price ? (
                    <h6 className="color-grey shrink-first">₹{flight.price}</h6>
                  ) : null}
                  {flight.refundable ? (
                    <p className="color-pink micro">REFUNDABLE</p>
                  ) : (
                    <p className="color-pink micro">NON REFUNDABLE</p>
                  )}
                </div>
              </div>

              {/* Looping each trip here */}
              {flight.allTrips.map((tripKey, tInx) => {
                let trip = flight.trips[tripKey];

                // If the trip itself is not found we don't have to continue
                if(!trip) return null;

                let routesInThisTrip = trip.routes.length - 1;
                let layover_row = null;
                return (
                  <table
                    className="transit-table insidebreak-avoid"
                    border={0}
                    width="100%"
                    cellPadding={0}
                    cellSpacing={0}
                    key={'trip_' + tInx}
                  >
                    <tbody>
                      <tr>
                        <td className="pb-15" colSpan={4}>
                          <p>
                            <b className="bold">
                              {trip.routes[0].departureCity} -{' '}
                              {trip.routes[routesInThisTrip].arrivalCity}
                            </b>{' '}
                            <span className="color-grey">
                              {routesInThisTrip > 0
                                ? `${routesInThisTrip} stop`
                                : `Direct flight`}. Duration {trip.flyTime}
                            </span>
                          </p>
                        </td>
                      </tr>

                      {trip.routes.map((route, rInx) => {
                        let airlineCode = route.carrierCode;
                        if (route.connectionDuration > 0)
                          layover_row = (
                            <h5 className="color-grey micro">
                              {getConnectionDuration(route.connectionDuration)}{' '}
                              layover in {route.arrivalCity}
                            </h5>
                          );
                        else layover_row = null;
                        // if(flight.excessBaggageInfo) {
                        //   // console.log(
                        //     flight.excessBaggageInfo.excessBaggages[0].baggageOptions
                        //   );
                        // }
                        let tripBaggage = [];
                        if (flight.excessBaggageInfo) {
                          _.filter(
                            flight.excessBaggageInfo.excessBaggages,
                            eb => {
                              eb.baggageOptions.map(ebBo => {
                                if (
                                  ebBo.selected &&
                                  ebBo.weight > 0 &&
                                  eb.origin === route.departureAirportCode &&
                                  eb.destination === route.arrivalAirportCode
                                ) {
                                  tripBaggage.push(ebBo);
                                }
                              });
                            }
                          );
                        }

                        return (
                          <tr key={"flight_row_"+rInx}>
                            <td>
                              <table width="663">
                                <tr key={'route_' + tInx + '_' + rInx}>
                                  {/* flight-row starts */}
                                  <td
                                    className="pr-10"
                                    align="center"
                                    valign="top"
                                    width="15%"
                                  >
                                    <img
                                      src={getImgIXUrl(
                                        `//${AIRLINE_CDN}${airlineCode}.png`,
                                        'w=64&h=32&auto=enhance'
                                      )}
                                      alt={route.carrierName}
                                    />
                                    <p className="micro color-grey">
                                      {route.carrierName}
                                      <br />
                                      {route.flightNumber} / Economy
                                    </p>
                                    {/*
                              <p className="micro color-grey">
                                {tripBaggage[0].selectedQuantity}x{tripBaggage[0].weight} {`KG Check-in baggage`}
                              </p>
                              */}
                                  </td>
                                  <td
                                    className="pr-10 time"
                                    align="left"
                                    valign="top"
                                    width="28.33%"
                                  >
                                    <h5 className="color-grey">
                                      {route.departureAirportCode}{' '}
                                      {route.departureTime}
                                    </h5>
                                    <p>
                                      <b className="bold">
                                        {route.depDateOfMonth} {route.depMonth}
                                      </b>,
                                      {route.departureDayOfWeek}
                                    </p>
                                    <p className="micro">
                                      {route.departureCity}
                                    </p>
                                  </td>
                                  <td
                                    className="pr-10 time"
                                    align="center"
                                    valign="top"
                                    width="28.33%"
                                  >
                                    <i className="color-grey vehoicon-ion-android-time" />
                                    <h5 className="color-grey micro">
                                      {route.flyTime}
                                    </h5>
                                    {layover_row}
                                  </td>
                                  <td
                                    className="time"
                                    align="right"
                                    valign="top"
                                    width="28.33%"
                                  >
                                    <h5 className="color-grey">
                                      {route.arrivalTime}{' '}
                                      {route.arrivalAirportCode}
                                    </h5>
                                    <p>
                                      <b className="bold">
                                        {route.arrDateOfMonth} {route.arrMonth}
                                      </b>,
                                      {route.arrivalDayOfWeek}
                                    </p>
                                    <p className="micro">{route.arrivalCity}</p>
                                  </td>
                                  {/* flight-row ends */}
                                </tr>
                                <tr>
                                  <td colSpan="4">
                                    {tripBaggage[0] ? (
                                      <p className="micro color-grey">
                                        {`${
                                          tripBaggage[0].selectedQuantity
                                        } x ${
                                          tripBaggage[0].weight
                                        } KG Check-in baggage`}
                                      </p>
                                    ) : null}
                                    {tripBaggage[1] ? (
                                      <p className="micro color-grey">
                                        {`${
                                          tripBaggage[1].selectedQuantity
                                        } x ${
                                          tripBaggage[1].weight
                                        } KG Check-in baggage`}
                                      </p>
                                    ) : null}
                                    {tripBaggage[2] ? (
                                      <p className="micro color-grey">
                                        {`${
                                          tripBaggage[2].selectedQuantity
                                        } x ${
                                          tripBaggage[2].weight
                                        } KG Check-in baggage`}
                                      </p>
                                    ) : null}
                                    {tripBaggage[3] ? (
                                      <p className="micro color-grey">
                                        {`${
                                          tripBaggage[3].selectedQuantity
                                        } x ${
                                          tripBaggage[3].weight
                                        } KG Check-in baggage`}
                                      </p>
                                    ) : null}
                                    {tripBaggage[4] ? (
                                      <p className="micro color-grey">
                                        {`${
                                          tripBaggage[4].selectedQuantity
                                        } x ${
                                          tripBaggage[4].weight
                                        } KG Check-in baggage`}
                                      </p>
                                    ) : null}
                                  </td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    {/* transit-table ends */}
                  </table>
                );
              })}
              {/* Looping each route here */}
            </section>
          );
        })}
      </div>
    </div>
  );
}
