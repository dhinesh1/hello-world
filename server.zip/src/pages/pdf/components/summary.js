import React from 'react';
import { AppConfig } from '../../../app-config';
const CONTACT_NUMBER = AppConfig.website_contact_number;

export default function PDFSummary({ content }) {
  if(!content.pdfSummary) return null;

  const regionCode =
    content && content.commonParams ? content.commonParams.regionCode : '';
  if (
    content.pdfSummary &&
    content.pdfSummary.summary &&
    (regionCode === 'mle' || regionCode === 'sez' || regionCode === 'mus') &&
    !content.pdfSummary.summary.inclusions.includes(
      'Two way Airport Hotel Transfers'
    )
  ) {
    content.pdfSummary.summary.inclusions.push(
      'Two way Airport Hotel Transfers',
      'Meal Plan as per Hotel Inclusions'
    );
  }
  return (
    <div className="page">
      <i className="summary-bg" />
      <header className="clearfix">
        <h1 className="pull-left">Summary</h1>
      </header>
      <div className="summary">
        <section className="clearfix">
          <div className="pull-left col-2 insidebreak-avoid">
            <h3 className="color-grey">Inclusions</h3>
            <ul className="list-unstyled cmn-list insidebreak-avoid">
              {content.pdfSummary.summary.inclusions.map((inclusion, inx) => {
                return <li key={'summary_inc_' + inx}>{inclusion}</li>;
              })}
            </ul>
          </div>
          <div className="pull-left col-2 insidebreak-avoid">
            {content.commonParams.agent ? null : (
              <h3 className="color-grey">Complimentary Service</h3>
            )}
            {content.commonParams.agent ? null : (
              <ul className="list-unstyled cmn-list insidebreak-avoid">
                {content.pdfSummary.summary.complimentaryServices.map(
                  (complementaryService, inx) => {
                    return (
                      <li key={'com_ser_' + inx}>{complementaryService}</li>
                    );
                  }
                )}
              </ul>
            )}

            <h3 className="color-grey">Exclusions</h3>
            <ul className="list-unstyled cmn-list insidebreak-avoid">
              {content.pdfSummary.summary.exclusions.map((exclusion, inx) => {
                return <li key={'com_exc_' + inx}>{exclusion}</li>;
              })}
            </ul>
          </div>
        </section>
        <section className="container text-center total-cost-tax insidebreak-avoid">
          <h4>Total cost including taxes</h4>
          <span className="color-grey micro">
            As costed on {content.commonParams.quotedOnDateFormatted} at{' '}
            {content.commonParams.quotedOnTimeFormatted}
          </span>
          <h5 className="bold shrink-first">
            ₹ {content.commonParams.totalCost}
          </h5>

          {content.commonParams.agent ? null : (
            <div>
              <p className="color-grey micro">
                The taxes and fees component includes - All government taxes
                levied for your bookings. PickYourTrail service fee for booking
                and concierge support. All currency conversion charges wherever
                applicable
              </p>
              <a
                href={content.commonParams.itineraryUrl}
                className="pay-book-cta center"
              >
                Pay &amp; book your vacation
              </a>
              <p className="color-grey micro">
                Please contact our travel specialist to generate a new payment
                link in case this link expires or is not working.
              </p>
              <p>
                <a href={`tel:+91${CONTACT_NUMBER}`}>
                  <i className="vehoicon-phone_iphone color-pink" /> +91{' '}
                  {CONTACT_NUMBER}
                </a>
              </p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
