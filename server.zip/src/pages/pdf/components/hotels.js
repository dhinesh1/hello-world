import React from 'react';
import PDFPageHeader from './header';
import StarRating from './../../../common_components/StarRating';
import { TripAdvisorRating } from './../../../common_components/Components';
import { MealsMapping } from '../../../helpers/island_hopper_mle_meals_mapping';
import { getImgIXUrl, getMealType } from '../../../helpers/utilsHelper';

export default function PDFHotels({ content }) {
  if(!content.pdfHotels) return null;

  const headerTitle =
    content.commonParams && content.commonParams.regionCode === 'mle'
      ? 'Hotels & Transfers'
      : 'Hotels';
  return (
    <div className="page hotel-page" id="hotel-page">
      <PDFPageHeader content={content} pageTitle={headerTitle} />

      <div className="hotels-container">
        {content.pdfHotels.hotels.map((hotelCosting, inx) => {
          if (hotelCosting.roomsInHotel && hotelCosting.status === 'SUCCESS') {
            return (
              <section className="single-hotel-section" key={'hotel_' + inx}>
                {/* SINGLE HOTEL STARTS */}
                <div className="clearfix icon-title-block">
                  <div className="pull-left col-70">
                    <div className="pull-left icon">
                      <i className="vehoicon-local_hotel" />
                    </div>
                    <div className="pull-left col-90">
                      <h5 className="bold">
                        {hotelCosting.name}
                        <StarRating
                          rating={hotelCosting.stars}
                          fillEmpty={false}
                          parentElement={'span'}
                          parentClass={'hotel-star-rating'}
                        />
                      </h5>
                      <p>
                        <b className="bold">{hotelCosting.cityName}</b> .{' '}
                        <span className="color-grey normal">
                          {' '}
                          {hotelCosting.numberOfNights} Night stay
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="pull-left col-30 text-right">
                    {hotelCosting.finalPrice ? (
                      <h6 className="color-grey shrink-first">
                        ₹{hotelCosting.finalPrice}
                      </h6>
                    ) : null}
                  </div>
                </div>
                <div className="hotel-second-row clearfix">
                  <div className="checkin-block">
                    <span className="color-grey label">Check In</span>
                    <span className="checkin-date">
                      <span className="bold">
                        {hotelCosting.checkInDateDisplay}{' '}
                        {hotelCosting.checkInMonthDisplay}
                      </span>, {hotelCosting.checkInDayOfWeek}{' '}
                      <span className="color-grey">14:00</span>
                    </span>
                  </div>
                  <div className="checkout-block">
                    <span className="color-grey label">Check Out</span>
                    <span className="checkin-date">
                      <span className="bold">
                        {hotelCosting.checkOutDateDisplay}{' '}
                        {hotelCosting.checkOutMonthDisplay}
                      </span>, {hotelCosting.checkOutDayOfWeek}{' '}
                      <span className="color-grey">11:00</span>
                    </span>
                  </div>
                  <div className="rating-price-block">
                    <span className="ta-rating-container">
                      <TripAdvisorRating
                        rating={hotelCosting.tripAdvisorRating}
                        logoAsImage={true}
                        fillEmptyCircle={true}
                        wrapperClass={'ta-rating'}
                      />
                    </span>

                    {hotelCosting.tripAdvisorReviewCount > 0 ? (
                      <p className="color-grey" style={{ textAlign: 'right' }}>
                        {hotelCosting.tripAdvisorReviewCount} reviews
                      </p>
                    ) : null}
                  </div>
                </div>

                {hotelCosting.roomsInHotel.map((roomChoice, rmInx) => {
                  let bedChoices = [],
                    mealType;
                  if (roomChoice.mealType) {
                    mealType = roomChoice.mealType;
                    //returns the mealType text to display in inclusion page instead of showing as HB, BB, AI.
                    mealType = getMealType(mealType);
                  }
                  return (
                    <div className="room-row clearfix" key={'room_' + rmInx}>
                      {roomChoice.roomImages &&
                      roomChoice.roomImages.length > 0 ? (
                        <img
                          alt={"room-"+rmInx}
                          className="room-photo"
                          src={`${roomChoice.roomImages[0]}`}
                          width="109px"
                          height="69px"
                        />
                      ) : (
                        <img
                          alt="room-default"
                          className="room-photo"
                          src={getImgIXUrl(
                            'https://d3lf10b5gahyby.cloudfront.net/misc/HL_execrmnight01_386x310_FitToBoxSmallDimension_Center.jpg',
                            'w=109&h=69'
                          )}
                          width="109px"
                          height="69px"
                        />
                      )}
                      <div className="room-text-block clearfix">
                        <p className="room-name">{roomChoice.name}</p>
                        {roomChoice.refundable ? (
                          <span className="refundability refundable">
                            REFUNDABLE
                          </span>
                        ) : (
                          <span className="refundability refundable">
                            NON REFUNDABLE
                          </span>
                        )}

                        {roomChoice.rateForDifferentDays &&
                        roomChoice.roomTypeCode === '200369115' &&
                        roomChoice.rateCode === '202242768' &&
                        roomChoice.rateForDifferentDays.length === 2 ? (
                          <span className="refundability refundable">
                            Honeymoon Special
                          </span>
                        ) : null}

                        {roomChoice.bedTypes ? (
                          <p className="room-type-text">
                            {roomChoice.bedTypes.map((bedType, inx) => {
                              bedChoices.push(bedType);
                            })}

                            {bedChoices.join(', ')}
                          </p>
                        ) : null}

                        <ul className="list-unstyled room-amenities">
                          {roomChoice.freeWireless ? (
                            <li>
                              <span className="vehoicon-wifi" />Free wifi
                            </li>
                          ) : null}

                          {roomChoice.roomSize ? (
                            <li>
                              <span className="vehoicon-enlarge7" />
                              {roomChoice.roomSize}
                            </li>
                          ) : null}

                          {roomChoice.mealType ? (
                            <li>
                              <span className={'vehoicon-restaurant_menu'} />
                              <span>{mealType}</span> <br />
                              {hotelCosting &&
                              (hotelCosting.speedBoat ||
                                hotelCosting.seaPlane) ? (
                                <span>
                                  Two way Airport Hotel Transfers{hotelCosting.speedBoat &&
                                  hotelCosting.seaPlane
                                    ? ' (Speedboat/SeaPlane)'
                                    : hotelCosting.seaPlane
                                      ? ' (Seaplane)'
                                      : ' (Speedboat)'}
                                </span>
                              ) : null}
                            </li>
                          ) : roomChoice.freeBreakfast ? (
                            <li>
                              <span className="vehoicon-restaurant_menu" />Free
                              Breakfast
                            </li>
                          ) : null}
                        </ul>
                        {roomChoice.availCode === 'RQ' ? (
                          <ul className="list-unstyled room-amenities">
                            <li className="color-accent-7">
                              <span className="refundable">On Request*</span>
                            </li>
                          </ul>
                        ) : null}
                        {/* description for hoenymoon special to show in PDF */}
                        {roomChoice && roomChoice.extraInclusions ? (
                          <div className="cmn-list pull-left fw pt-10">
                            <p
                              className="color-grey"
                              style={{ 'margin-bottom': '8px' }}
                            >
                              Honeymoon Special
                            </p>
                            <ul className="room-type-text">
                              {roomChoice.extraInclusions.map((item, inx) => (
                                <li key={`extra_inclusions_${inx}`}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  );
                })}

                {/* SINGLE HOTEL ENDS */}
              </section>
            );
          }
        })}

        <p className="fs-12 color-grey">
          Note - Check in check out timings are only indicative and each hotels
          holds the right for changing the timings according to their
          discretion.
        </p>
      </div>
    </div>
  );
}
