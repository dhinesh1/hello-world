import React from 'react';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function PDFHowToBook({ content }) {
  return (
    <div className="page">
      <header className="clearfix">
        <h1 className="pull-left">How to book</h1>
      </header>
      <div className="howtobook">
        <section className="insidebreak-avoid">
          <p className="color-grey">
            Pickyourtrail offers a flexible Payment plan to make your dream
            vacation a reality. Here is a break up of your payment schedule. You
            can make the payments online or by IMPS bank transfer.
          </p>
        </section>
        <section className="clearfix pt-30 insidebreak-avoid">
          <div className="pull-left col-2">
            <p className="bold">Total cost including taxes</p>
            <span className="color-grey micro">
              As costed on {content.commonParams.quotedOnDateFormatted} at{' '}
              {content.commonParams.quotedOnTimeFormatted}
            </span>
          </div>
          <div className="pull-right col-2 text-right">
            <h3 className="bold shrink-first">
              ₹ {content.commonParams.totalCost}
            </h3>
          </div>
        </section>
        <table className="insidebreak-avoid" cellPadding={0} cellSpacing={0}>
          <tbody>
            <tr>
              <td width="45%" className="bold">
                Initial payment &amp; confirmation
              </td>
              <td width="18.33%" className="bold text-center">
                Part 01
              </td>
              <td width="18.33%" className="bold text-center">
                Part 02
              </td>
              <td width="18.33%" className="bold text-center">
                Part 03
              </td>
            </tr>
            <tr>
              <td width="45%">More than 35 days to departure</td>
              <td width="18.33%" className="text-center">
                <h4 className="shrink-first">
                  ₹ {content.paymentDetail.paymentAmount50Percent}
                </h4>
                <p className="color-pink">50% of total</p>
              </td>
              <td width="18.33%" className="text-center">
                <h4 className="shrink-first">
                  ₹ {content.paymentDetail.paymentAmount20Percent}
                </h4>
                <p className="color-pink">20% of total</p>
                <p className="color-grey micro">
                  Pay Within 14 days of first payment
                </p>
              </td>
              <td width="18.33%" className="text-center">
                <h4 className="shrink-first">
                  ₹ {content.paymentDetail.paymentAmount30Percent}
                </h4>
                <p className="color-pink">30% of total</p>
                <p className="color-grey micro">
                  Pay before 21 days of departure
                </p>
              </td>
            </tr>
            <tr>
              <td width="45%">Between 21-35 days to departure</td>
              <td width="18.33%" className="text-center">
                <p className="color-grey">Not available</p>
              </td>
              <td width="18.33%" className="text-center">
                <h4 className="shrink-first">
                  ₹ {content.paymentDetail.paymentAmount70Percent}
                </h4>
                <p className="color-pink">70% of total</p>
              </td>
              <td width="18.33%" className="text-center">
                <h4 className="shrink-first">
                  ₹ {content.paymentDetail.paymentAmount30Percent}
                </h4>
                <p className="color-pink">30% of total</p>
                <p className="color-grey micro">
                  Pay before 21 days of departure
                </p>
              </td>
            </tr>
            <tr>
              <td width="45%">Less than 21 days to departure</td>
              <td width="18.33%" className="text-center">
                <p className="color-grey">Not available</p>
              </td>
              <td width="18.33%" className="text-center">
                <p className="color-grey">Not available</p>
              </td>
              <td width="18.33%" className="text-center">
                <h4 className="shrink-first">
                  ₹ {content.paymentDetail.paymentAmount100Percent}
                </h4>
                <p className="color-pink">Full payment</p>
              </td>
            </tr>
            <tr>
              <td height={43} className="color-grey micro" colSpan={4}>
                You will get all your booking vouchers by email, within 2-3
                working days after your initial payment. A consolidated voucher
                will be sent after making the final payment.
              </td>
            </tr>
          </tbody>
        </table>
        <section className="clearfix acc-details border-bottom">
          <div className="pull-left payment-info-block">
            <h5 className="inline bold">Pay Online</h5>{' '}
            <img
              src={getImgIXUrl(
                'https://d3lf10b5gahyby.cloudfront.net/pdf-assets/payment-cards-2.png'
              )}
              alt="Payment Cards"
            />
            <p className="color-grey micro pb-15 pt-10 lock-icon">
              Secure SSL Payment Gateway. Accepts all major cards and <br />payment
              modes.<br />
            </p>
          </div>
          <div className="pull-left cta-block text-right">
            <a
              href={content.commonParams.itineraryUrl}
              className="pay-book-cta center"
            >
              <span className="fs-18">Pay &amp; book your vacation</span>
            </a>
          </div>
        </section>
        <section className="clearfix acc-details">
          <h5 className="bold">Bank Transfer options</h5>
          <div className="pull-left col-2">
            <h5 className="color-grey bold">HSBC Bank</h5>
            <ul className="clearfix list-unstyled color-grey">
              <li>
                <span>Account:</span>{' '}
                {content.commonParams.virtualAccountNumber}
              </li>
              <li>
                <span>Name:</span> Travel Troops Global Pvt Ltd
              </li>
              <li>
                <span>Branch:</span> Chennai Main Branch
              </li>
              <li>
                <span>IFSCode:</span> HSBC0600002
              </li>
              <li>
                <span>Swift Code:</span> HSBCINBB
              </li>
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
}
