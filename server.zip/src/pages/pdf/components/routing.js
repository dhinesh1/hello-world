import React from 'react';
import PDFPageHeader from './header';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function Routing({ content }) {
  if(!content.pdfRoute) return null;

  return (
    <div className="page routes-page">
      <PDFPageHeader content={content} pageTitle={'Route'} />

      {content.pdfRoute.containers.map((container, inx) => {
        return (
          <div className="route-container" key={'route_' + inx}>
            {container.cities.map((routeCity, r_inx) => {
              return (
                <div className="single-city" key={'single_city_' + r_inx}>
                  {routeCity.first ? (
                    content.pdfRoute.departureCity === 'Outside India' ? (
                      <p className="pre-link">
                        <span className="vehoicon-flight" /> Departing on day{' '}
                        {content.pdfRoute.departureDayNum}
                      </p>
                    ) : (
                      <p className="pre-link">
                        <span className="vehoicon-flight" /> Departing{' '}
                        {content.pdfRoute.departureCity} on day{' '}
                        {content.pdfRoute.departureDayNum}
                      </p>
                    )
                  ) : routeCity.transfer === 'Car' ||
                  routeCity.transfer === 'Minivan' ||
                  routeCity.transfer === 'Rentalcar' ? (
                    <TransferLink
                      iconClass={'vehoicon-directions_car'}
                      routeCity={routeCity}
                    />
                  ) : routeCity.transfer === 'Train' ? (
                    <TransferLink
                      iconClass={'vehoicon-train'}
                      routeCity={routeCity}
                    />
                  ) : routeCity.transfer === 'Bus' ||
                  routeCity.transfer === 'Shuttle' ? (
                    <TransferLink
                      iconClass={'vehoicon-directions_bus'}
                      routeCity={routeCity}
                    />
                  ) : routeCity.transfer === 'Ferry' ? (
                    <TransferLink
                      iconClass={'vehoicon-ferry'}
                      routeCity={routeCity}
                    />
                  ) : routeCity.transfer === 'Boat' ? (
                    <TransferLink
                      iconClass={'vehoicon-directions_boat'}
                      routeCity={routeCity}
                    />
                  ) : routeCity.transfer === 'Flight' ? (
                    <TransferLink
                      iconClass={'vehoicon-flight'}
                      routeCity={routeCity}
                    />
                  ) : null}

                  <div className="city-content">
                    <img
                      alt={'nights-stay'}
                      src={getImgIXUrl(
                        'https://s3.ap-south-1.amazonaws.com/oceanjar-new/images/pdf-assets/map-marker-icon.png'
                      )}
                      width="40px"
                      height="40px"
                    />
                    <h5 className="bold city-title">{routeCity.city}</h5>
                    <span>{routeCity.nights} Nights stay</span>
                  </div>

                  {routeCity.last ? (
                    content.pdfRoute.returningCity === 'Outside India' ? (
                      <p className="pre-link">
                        <span className="vehoicon-flight" /> Returning on day{' '}
                        {content.pdfRoute.returnDayNum}
                      </p>
                    ) : (
                      <p className="pre-link">
                        <span className="vehoicon-flight" /> Returning{' '}
                        {content.pdfRoute.returningCity} on day{' '}
                        {content.pdfRoute.returnDayNum}
                      </p>
                    )
                  ) : null}
                </div>
              );
            })}
          </div>
        );
      })}

      <div className="globe-graffiti" />
    </div>
  );
}

function TransferLink({ iconClass, routeCity }) {
  return (
    <p className="pre-link">
      <span className={iconClass} /> Transfer by {routeCity.transfer} on day{' '}
      {routeCity.transferDayNum}
    </p>
  );
}
