import React from 'react';

export default function PDFPageHeader({ content, pageTitle }) {
  return (
    <header className="clearfix">
      <h1 className="pull-left">{pageTitle}</h1>
      {content.commonParams.agent ? null : (
        <a
          href={content.commonParams.itineraryUrl}
          className="pull-right hdr-rgt text-center color-pink"
        >
          <span className="clearfix db">
            Trip cost: ₹<b className="bold shrink-first">
              {content.commonParams.totalCost}
            </b>
          </span>{' '}
          <i className="clearfix micro db">MAKE CHANGES</i>
        </a>
      )}
    </header>
  );
}
