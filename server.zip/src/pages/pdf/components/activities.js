import React, { Fragment } from 'react';
import PDFPageHeader from './header';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export default function PDFActivities({ content }) {
  if(!content.pdfActivites.activities) return null;

  return (
    <div className="page">
      <PDFPageHeader content={content} pageTitle={'Activities'} />

      {content.pdfActivites.activities.map((activityCosting, inx) => {
        let id = activityCosting.activityId;
        let activity = content.pdfActivites.activityMap[id];

        if(!activity) return null;

        return (
          <section
            className="clearfix section-block insidebreak-avoid"
            key={'activity_' + inx}
          >
            {/* activity-row starts */}
            <div className="clearfix icon-title-block">
              <div className="pull-left col-70">
                <div className="pull-left icon">
                  <i className="vehoicon-confirmation_number" />
                </div>
                <div className="pull-left col-90">
                  <h5 className="bold">{activity.title}</h5>
                  <p className="color-grey">
                    {activity.privateTour ? 'Private tour' : 'Activity'}

                    {activity.selectedTourGrade.transferType === 'SHARED'
                      ? 'with Shared Transfer'
                      : activity.selectedTourGrade.transferType === 'PRIVATE'
                        ? 'with Private Transfer'
                        : activity.selectedTourGrade.transferType ===
                          'NOTRANSFER'
                          ? 'without Transfer'
                          : null}
                  </p>
                </div>
              </div>
              <div className="pull-left col-30 text-right">
                {activity.free ? (
                  <span className="color-green mini">SELF EXPLORATION</span>
                )  : <Fragment>{activityCosting.inCombo ? (
                    <span className="color-green micro bold">
                      COMBO SPL. PRICE
                    </span>
                  ) : activityCosting.inSwissPass ? (
                    <span className="color-green micro bold">
                      SWISS PASS SPL. PRICE
                    </span>
                  ) : null}

                  <p className="color-grey micro">
                    {activityCosting.refundable ? 'REFUNDABLE' : 'NON REFUNDABLE'}
                  </p>
                </Fragment>
              }

                
              </div>
            </div>
            <div className="clearfix img-block">
              <div className="pull-left img-lft">
                <img
                  src={getImgIXUrl(
                    activity.mainPhoto,
                    'auto=enhance&w=100&h=75&fit=crop'
                  )}
                  alt="Activity"
                />
              </div>
              <div className="pull-right img-rgt">
                <div className="clearfix pb-15">
                  <div className="pull-left col-30">
                    {activity.selectedTourGrade.departureTime &&
                    activity.selectedTourGrade.departureTime !== '' ? (
                      <h5 className="color-grey">
                        {`${activity.selectedTourGrade.departureTime.substring(
                          0,
                          2
                        )}:${activity.selectedTourGrade.departureTime.substring(
                          2,
                          4
                        )}`}
                      </h5>
                    ) : null}

                    <p>
                      <b className="bold">
                        {activityCosting.day} {activityCosting.mon}
                      </b>, {activityCosting.dayOfWeek}
                    </p>
                  </div>
                  <div className="pull-left col-70">
                    <h5 className="color-grey">
                      Duration: {activity.selectedTourGrade.duration}
                    </h5>
                    <p className="color-grey">
                      Hotel pickup:{' '}
                      {activity.selectedTourGrade.pickupType === 'Hotel'
                        ? 'Yes'
                        : 'No'}
                    </p>
                  </div>
                </div>
                {activity &&
                activity.selectedTourGrade &&
                activity.selectedTourGrade.inclusion ? (
                  <div
                    className="clearfix fw list-unstyled cmn-list color-grey"
                    dangerouslySetInnerHTML={{
                      __html: `
                        <div class='pull-left col-48 grn-list'>
                          <p class="color-grey bold" style="margin-bottom: 8px;">Inclusions</p>
                          ${activity.selectedTourGrade.inclusion}
                        </div>
                        <div class='pull-right col-48 red-list'>
                          <p class="color-grey bold" style="margin-bottom: 8px;">Exclusions</p>
                          ${activity.selectedTourGrade.exclusion &&
                            activity.selectedTourGrade.exclusion}
                        </div>
                      `
                    }}
                  />
                ) : null}
              </div>
            </div>
            {/* activity-row ends */}
          </section>
        );
      })}
    </div>
  );
}
