import React from 'react';

export default function PDFCancellation({ content }) {
  return (
    <div className="page">
      <header className="clearfix">
        <h1 className="pull-left">
          Cancellations<br />&amp; Refunds
        </h1>
      </header>

      <div className="refunds">
        {content.commonParams.agent ? null : (
          <p className="color-grey insidebreak-avoid">
            We understand your travel plans may change. With that in mind,
            Pickyourtrail has a very simple cancellation policy: regardless of
            whether you made your reservation online, using our mobile
            applications, or via our travel consultation, we have a standard
            cancellation policy as below.
          </p>
        )}

        {/* title-table starts */}
        <table
          className="insidebreak-avoid"
          align="center"
          border={0}
          width="100%"
          cellPadding={0}
          cellSpacing={0}
        >
          <tbody>
            <tr>
              <td className="no-border" colSpan={5} height={15} />
            </tr>
            <tr className="no-border">
              <td align="left" width="40%">
                TIME OF CANCELLATION:(Days before departure)
              </td>
              <td align="right" width="15%">
                <b>&gt; 30 DAYS</b>
              </td>
              <td align="right" width="15%">
                <b>7 - 30 DAYS</b>
              </td>
              <td align="right" width="15%">
                <b>&lt; 7 DAYS</b>
              </td>
            </tr>
          </tbody>
        </table>
        {/* title-table ends */}

        {/* Total Refund */}
        {content.pdfCancellation.cancellations.map((cancellation, cInx) => {
          if (cancellation.type === 'TOTAL') {
            return (
              <table
                className="insidebreak-avoid"
                align="center"
                border={0}
                width="100%"
                cellPadding={0}
                cellSpacing={0}
                key={'total_' + cInx}
              >
                <tbody>
                  <tr className="no-border">
                    <td width="40%" className="color-pink">
                      TOTAL REFUND
                    </td>
                    {cancellation.entries[0].rates.map((rate, rInx) => (
                      <td align="right" width="15%" key={'total_rate_' + rInx}>
                        {rate.refund}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            );
          }
        })}

        {content.commonParams.hideSplitPricing ? null : (
          <div>
            {content.commonParams.packageRate ? (
              content.pdfCancellation.cancellations.map(
                (cancellation, cInx) => {
                  {
                    /* Flights+Hotels */
                  }

                  if (cancellation.type === 'FLIGHTS_HOTELS') {
                    return (
                      <table
                        className="insidebreak-avoid"
                        align="center"
                        border={0}
                        width="100%"
                        cellPadding={0}
                        cellSpacing={0}
                        key={'FLIGHTS_HOTELS_' + cInx}
                      >
                        <tbody>
                          <tr className="no-border">
                            <td width="40%" className="color-pink">
                              FLIGHTS + HOTELS
                            </td>
                            {cancellation.entries[0].rates.map((rate, rInx) => (
                              <td
                                align="right"
                                width="15%"
                                key={'flights_hotel_rate_' + rInx}
                              >
                                {rate.refund}
                              </td>
                            ))}
                          </tr>
                        </tbody>
                      </table>
                    );
                  }
                }
              )
            ) : (
              <div>
                {content.pdfCancellation.cancellations.map(
                  (cancellation, cInx) => {
                    {
                      /* Flights+Hotels */
                    }

                    if (cancellation.type === 'FLIGHTS') {
                      return (
                        <table
                          className="insidebreak-avoid"
                          align="center"
                          border={0}
                          width="100%"
                          cellPadding={0}
                          cellSpacing={0}
                          key={'FLIGHTS_' + cInx}
                        >
                          <tbody>
                            <tr className="no-border">
                              <td colSpan={'4'} className="color-pink">
                                FLIGHTS
                              </td>
                            </tr>

                            {cancellation.entries.map((entry, eInx) => {
                              return (
                                <tr key={'entry_' + eInx}>
                                  <td width="40%">{entry.name}</td>
                                  {entry.rates.map((rate, rInx) => (
                                    <td
                                      align="right"
                                      width="15%"
                                      key={'flights_rate_' + rInx}
                                    >
                                      {rate.refund}
                                    </td>
                                  ))}
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      );
                    }
                  }
                )}

                {content.pdfCancellation.cancellations.map(
                  (cancellation, cInx) => {
                    {
                      /* Flights+Hotels */
                    }

                    if (cancellation.type === 'HOTELS') {
                      return (
                        <table
                          className="insidebreak-avoid"
                          align="center"
                          border={0}
                          width="100%"
                          cellPadding={0}
                          cellSpacing={0}
                          key={'HOTELS_' + cInx}
                        >
                          <tbody>
                            <tr className="no-border">
                              <td colSpan={'4'} className="color-pink">
                                HOTELS
                              </td>
                            </tr>

                            {cancellation.entries.map((entry, eInx) => {
                              return (
                                <tr key={'entry_' + eInx}>
                                  <td width="40%">{entry.name}</td>
                                  {entry.rates.map((rate, rInx) => (
                                    <td
                                      align="right"
                                      width="15%"
                                      key={'hotels_rate_' + rInx}
                                    >
                                      {rate.refund}
                                    </td>
                                  ))}
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      );
                    }
                  }
                )}
              </div>
            )}

            {/* Transfers */}
            {content.pdfCancellation.cancellations.map((cancellation, cInx) => {
              {
                /* Flights+Hotels */
              }

              if (cancellation.type === 'TRANSFERS') {
                return (
                  <table
                    className="insidebreak-avoid"
                    align="center"
                    border={0}
                    width="100%"
                    cellPadding={0}
                    cellSpacing={0}
                    key={'TRANSFERS_' + cInx}
                  >
                    <tbody>
                      <tr className="no-border">
                        <td colSpan={'4'} className="color-pink">
                          TRANSFERS
                        </td>
                      </tr>

                      {cancellation.entries.map((entry, eInx) => {
                        return (
                          <tr key={'entry_' + eInx}>
                            <td width="40%">{entry.name}</td>
                            {entry.rates.map((rate, rInx) => (
                              <td
                                align="right"
                                width="15%"
                                key={'transfers_rate_' + rInx}
                              >
                                {rate.refund}
                              </td>
                            ))}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                );
              }
            })}

            {/* Activities */}
            {content.pdfCancellation.cancellations.map((cancellation, cInx) => {
              {
                /* Flights+Hotels */
              }

              if (cancellation.type === 'ACTIVITIES') {
                return (
                  <table
                    className="insidebreak-avoid"
                    align="center"
                    border={0}
                    width="100%"
                    cellPadding={0}
                    cellSpacing={0}
                    key={'ACTIVITIES_' + cInx}
                  >
                    <tbody>
                      <tr className="no-border">
                        <td colSpan={'4'} className="color-pink">
                          ACTIVITIES
                        </td>
                      </tr>

                      {cancellation.entries.map((entry, eInx) => {
                        return (
                          <tr key={'entry_' + eInx}>
                            <td width="40%">{entry.name}</td>
                            {entry.rates.map((rate, rInx) => (
                              <td
                                align="right"
                                width="15%"
                                key={'activities_rate_' + rInx}
                              >
                                {rate.refund}
                              </td>
                            ))}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                );
              }
            })}

            {/* Combos */}
            {content.pdfCancellation.cancellations.map((cancellation, cInx) => {
              {
                /* Flights+Hotels */
              }

              if (cancellation.type === 'COMBOS') {
                return (
                  <table
                    className="insidebreak-avoid"
                    align="center"
                    border={0}
                    width="100%"
                    cellPadding={0}
                    cellSpacing={0}
                    key={'COMBOS_' + cInx}
                  >
                    <tbody>
                      <tr className="no-border">
                        <td colSpan={'4'} className="color-pink">
                          PASSES
                        </td>
                      </tr>

                      {cancellation.entries.map((entry, eInx) => {
                        return (
                          <tr key={'entry_' + eInx}>
                            <td width="40%">{entry.name}</td>
                            {entry.rates.map((rate, rInx) => (
                              <td
                                align="right"
                                width="15%"
                                key={'combos_rate_' + rInx}
                              >
                                {rate.refund}
                              </td>
                            ))}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                );
              }
            })}

            {/* Others */}
            {content.pdfCancellation.cancellations.map((cancellation, cInx) => {
              {
                /* Flights+Hotels */
              }

              if (cancellation.type === 'OTHERS') {
                return (
                  <table
                    className="insidebreak-avoid"
                    align="center"
                    border={0}
                    width="100%"
                    cellPadding={0}
                    cellSpacing={0}
                    key={'OTHERS_' + cInx}
                  >
                    <tbody>
                      <tr className="no-border">
                        <td colSpan={'4'} className="color-pink">
                          OTHERS
                        </td>
                      </tr>

                      {cancellation.entries.map((entry, eInx) => {
                        return (
                          <tr key={'entry_' + eInx}>
                            <td width="40%">{entry.name}</td>
                            {entry.rates.map((rate, rInx) => (
                              <td
                                align="right"
                                width="15%"
                                key={'others_rate_' + rInx}
                              >
                                {rate.refund}
                              </td>
                            ))}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                );
              }
            })}

            {/* Taxes */}
            {content.pdfCancellation.cancellations.map((cancellation, cInx) => {
              {
                /* Flights+Hotels */
              }

              if (cancellation.type === 'TAXES') {
                return (
                  <table
                    className="insidebreak-avoid"
                    align="center"
                    border={0}
                    width="100%"
                    cellPadding={0}
                    cellSpacing={0}
                    key={'TAXES_' + cInx}
                  >
                    <tbody>
                      <tr className="no-border">
                        <td width="40%" className="color-pink">
                          Taxes and Fees
                        </td>
                        {cancellation.entries[0].rates.map((rate, rInx) => (
                          <td
                            align="right"
                            width="15%"
                            key={'taxes_rate_' + rInx}
                          >
                            {rate.refund}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                );
              }
            })}
          </div>
        )}
      </div>
    </div>
  );
}
