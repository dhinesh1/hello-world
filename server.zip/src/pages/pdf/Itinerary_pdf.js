import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { fetchDataForPDF } from '../../actions/actions_app';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

// Components
import PDFLanding from './components/landing';
import PDFCostBreakup from './components/costBreakup';
import PDFTestimonials from './components/testimonials';
import Routing from './components/routing';
import PDFItineray from './components/itinerary';
import PDFFlights from './components/flights';
import PDFHotels from './components/hotels';
import PDFTrasnsfers from './components/transfers';
import PDFActivities from './components/activities';
import PDFCombos from './components/combos';
import PDFOthers from './components/others';
import PDFSummary from './components/summary';
import PDFHowToBook from './components/howToBook';
import PDFNeedHelp from './components/needHelp';
import PDFCancellation from './components/cancellation';
import PDFFaq from './components/faq';
// import PDFGetQuote from './components/getQuote';
import PDFFinalPage from './components/finalPage';

class ItineraryPDF extends Component {
  constructor(props) {
    super(props);

    this.state = {
      content: {}
    };
  }

  componentDidMount() {
    let { match, pdfData } = this.props;

    if (!Object.keys(pdfData).length) {
      this.props.actions.fetchDataForPDF(match.params.itineraryId);
    }
  }

  render() {
    if (!Object.keys(this.props.pdfData).length) {
      return <div>This is for testing in server</div>;
    } else {
      let content = this.props.pdfData;

      return (
        <div>
          <PDFLanding content={content} />
          <PDFCostBreakup content={content} />
          {content.commonParams.agent ? null : (
            <PDFTestimonials content={content} />
          )}
          <Routing content={content} />
          <PDFItineray content={content} />
          {content.pdfFlights.included ? (
            <PDFFlights content={content} />
          ) : null}
          {content.pdfHotels.included ? <PDFHotels content={content} /> : null}
          {content.pdfTransfers.included ? (
            <PDFTrasnsfers content={content} />
          ) : null}
          {content.pdfActivites.included ? (
            <PDFActivities content={content} />
          ) : null}
          {content.pdfCombos.included ? <PDFCombos content={content} /> : null}
          {content.others.visaIncluded || content.others.insuranceIncluded ? (
            <PDFOthers content={content} />
          ) : null}
          <PDFSummary content={content} />
          {content.commonParams.agent || !content.paymentDetail ? null : (
            <PDFHowToBook content={content} />
          )}
          {content.commonParams.agent ? null : (
            <PDFNeedHelp content={content} />
          )}
          <PDFCancellation content={content} />
          {content.commonParams.agent ? null : <PDFFaq content={content} />}
          {/* {content.commonParams.agent &&
          content.commonParams.showGetQuote ? null : (
            <PDFGetQuote content={content} />
          )} */}
          <PDFFinalPage content={content} />
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  let app = state.app;
  let pdfData = app.pdfData;

  return {
    pdfData: pdfData,
    user_details: app.user_details
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      fetchDataForPDF: bindActionCreators(fetchDataForPDF, dispatch)
    }
  };
}

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(ItineraryPDF)
);
