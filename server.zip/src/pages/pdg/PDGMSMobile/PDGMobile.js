import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';
import { isFaqMobile } from '../../../helpers/utilsHelper';
import PDGMobileBanner from './PDGMobileBanner';
import PDGMobileContent from './PDGMobileContent';

import Slider from 'react-slick';

export default class PDGMobile extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    let {
      showPopUp,
      closePopup,
      clickCustomize,
      hotelDetails,
      isClicked
    } = this.props;
    let mobileContent =
      hotelDetails &&
      hotelDetails.hotelDetails.map((review, index) => {
        return (
          <section className="clearfix fw">
            <PDGMobileBanner
              nightStay={review.nights}
              cityName={review.cityName}
              hotelDetails={hotelDetails}
              isClicked={isClicked}
              mobileDetails={review}
            />
            <PDGMobileContent
              hotelDetails={hotelDetails}
              mobileDetails={review}
            />
          </section>
        );
      });
    return (
      <section
        className={classNames(
          'pdg-details-popup pdg-hotel-details visible-xs',
          {
            'xs-slide-up': showPopUp
          }
        )}
      >
        <div className="pdg-details-hdr">
          <span className="medium-heading bold">Details</span>
          <button
            type="button"
            className="btn btn-link-grey close-details"
            onClick={e => closePopup(e)}
          >
            <i className="vehoicon-close" />
          </button>
        </div>

        <div className="pdg-details-content">{mobileContent}</div>

        <div className="pdg-details-ftr grey-bg">
          {/* <div className="price-dtls">
                        <strong>
                            <i>₹</i> {hotelDetails.price}
                        </strong>
                        <span>per person</span>
                    </div> */}
          <button
            type="button"
            className="btn btn-primary btn-block"
            onClick={e => clickCustomize(e, hotelDetails.campaignItineraryId)}
          >
            Customize to fit your needs
          </button>
        </div>
      </section>
    );
  }
}
