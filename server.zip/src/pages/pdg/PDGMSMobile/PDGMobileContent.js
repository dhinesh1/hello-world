import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import { bindActionCreators } from 'redux';
import _ from 'lodash';
import { isFaqMobile } from '../../../helpers/utilsHelper';
import StarRating from '../maldivesPDG/PDGStarRating';

export default class PDGMobileContent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    let { hotelDetails, mobileDetails } = this.props;
    let speciality =
      mobileDetails.specialities &&
      mobileDetails.specialities.map((detail, index) => {
        return (
          <li>
            <span className="icon color-grey-secondary fade">
              <i className={detail.specialityIcon} />
            </span>
            <p>
              <b>{detail.specialityName}: </b>
              {detail.specialityDescription}
            </p>
          </li>
        );
      });
    return (
      <div className="clearfix fw inner-content">
        <h6 className="main-para bold fade mt-0 mbottom-small">
          {mobileDetails.name} <StarRating rating={mobileDetails.stars} />
        </h6>
        <p className="fine-text light color-grey">
          {mobileDetails.description}
        </p>
        <hr />
        {speciality ? (
          <h6 className="main-para bold fade mt-0 mbottom-small">Options</h6>
        ) : null}
        <ul className="pdg-options-list fine-text color-grey light">
          {speciality}
        </ul>
        {speciality ? <hr /> : null}

        <h6 className="main-para bold fade mt-0 mbottom-small">
          Hotel Amenities
        </h6>

        <ul className="amenities-list fine-text color-grey light">
          <GetInclusionLineItem inclusion={mobileDetails.amenityDisplayList} />
        </ul>
      </div>
    );
  }
}

export function GetInclusionLineItem(inclusion) {
  let amenitiesTake =
    inclusion && inclusion.inclusion && _.take(inclusion.inclusion, 6);
  let amenities =
    inclusion.inclusion &&
    amenitiesTake.map((inclu, review) => {
      return (
        <li>
          <i className={inclu.iconUrl} />
          {'  '}
          {'  '} {inclu.amenityName}{' '}
        </li>
      );
    });
  return amenities;
}
