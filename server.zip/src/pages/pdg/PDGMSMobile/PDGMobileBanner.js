import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';
import { isFaqMobile } from '../../../helpers/utilsHelper';
import Slider from 'react-slick';

export default class PDGMobileBanner extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    let { hotelDetails, mobileDetails, nightStay, cityName } = this.props;
    let settings = {
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: true,
      infinite: true,
      speed: 500,
      lazyLoad: 'ondemand',
      responsive: [
        {
          settings: {
            infinite: false,
            slidesToShow: 1
          }
        }
      ]
    };
    let imageUrl = mobileDetails.imageURL;
    let otherImage = mobileDetails.otherImages;
    let imageSlider =
      otherImage &&
      otherImage.map((review, index) => {
        return (
          <div
            data-index={Date.now()}
            key={Math.random()}
            style={{ width: 360 }}
          >
            <figure
              key={Math.random()}
              style={{
                backgroundImage: `url(${review})`
              }}
            >
              <figcaption className="fig-title">
                <span className="tag-tertiary white truncate medium">
                  {nightStay} nights
                </span>
              </figcaption>
            </figure>
          </div>
        );
      });
    return (
      <div className="clearfix fw mbottom-medium" style={{ height: 172 }}>
        <Slider {...settings} className="pdg-slider slider-1 slick-dotted">
          {imageSlider}
        </Slider>
      </div>
    );
  }
}
