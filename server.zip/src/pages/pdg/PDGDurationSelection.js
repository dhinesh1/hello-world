import React, { Component } from 'react';
import classNames from 'classnames';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getRegionDetails, setMinMaxDays } from '../../actions/actions_app';
import DurationCard from '../../common_components/pdg/DurationCard';
import StepText from '../../common_components/pdg/StepText';
import PDGTitleSection from '../../common_components/pdg/PDGTitleSection';
import PDGQuestionText from '../../common_components/pdg/PDGQuestionText';
import ActiveStageIndicator from '../../common_components/pdg/ActiveStageIndicator';
import { fixPDGHeader, hideChatIconOnMobile } from '../../helpers/utilsHelper';
import { Redirect } from 'react-router-dom';
import { trackEvent, EVENT_PDG_DURATION_SELECTED } from '../../helpers/ML/EventsTracker';

class PDGDurationSelection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      noOfActives: 1,
      show: false,
      showed: false,
      durationSelected: false,
      region: null
    };
    this.setSelectedDuration = this.setSelectedDuration.bind(this);
  }

  componentDidMount() {
    hideChatIconOnMobile();

    let dW = window.innerWidth;
    if (dW > 767) {
      document.addEventListener('scroll', fixPDGHeader);
    }

    setTimeout(() => {
      this.setState({ noOfActives: 3, show: true }, () => {
        setTimeout(() => {
          this.setState({ showed: true });
        }, 600);
      });
    }, 10);
  }

  componentWillUnmount(): void {
    document.removeEventListener('scroll', fixPDGHeader);
  }

  setSelectedDuration(minDays, maxDays) {
    let regionCode =
      this.props.match &&
      this.props.match.params &&
      this.props.match.params.searchRegion;

    this.props.actions.setMinMaxDays(minDays, maxDays);
    
    trackEvent(EVENT_PDG_DURATION_SELECTED, {
      duration: minDays + ' - ' + maxDays
    })

    this.props.history.push(`/customize/${regionCode}/month/duration`);
  }

  render() {
    let { noOfActives, show, showed } = this.state;
    let props = this.props;

    let {
      pdgSelections,
      regionObject,
      region,
      regionDetails,
      themeNames
    } = props;
    let { durationList } = props.regionDetails;
    let { searchRegion } = props.match.params;

    let containerClassNames = classNames({
      'search-container': true,
      'show-search': true
    });

    let innerStepClassName = classNames(
      'clearfix pdg-days next-slide search-options-wrapper',
      {
        'slide-left-in': show,
        showed: showed
      }
    );

    if (props.regionDetails.durationList) {
      return (
        <div className={containerClassNames}>
          <div className="search-content">
            {/* search-field starts */}
            <section className="clearfix search-field">
              <StepText
                mainText={'NOW PLANNING'}
                mainTextMobile={
                  this.props.region
                    ? this.props.region.regionName
                    : searchRegion
                }
                params={props.match.params}
                showSentence={true}
                pdgData={pdgSelections}
                selectedThemes={themeNames}
              />
              <section className="clearfix search-input-container">
                <PDGTitleSection
                  showInput={false}
                  showTitle={true}
                  isForwardAvailable={this.props.pdgSelections.maxDays}
                  handleBack={() => {
                    this.props.history.goBack();
                  }}
                  handleForward={() => {
                    this.props.history.goForward();
                  }}
                  title={
                    this.props.region
                      ? this.props.region.regionName
                      : searchRegion
                  }
                  titleMobile={`Trip duration`}
                />
                <ActiveStageIndicator
                  currentStepIndex={2}
                  actives={noOfActives}
                />
              </section>
            </section>
            {/* search-field ends */}
            <section className={innerStepClassName}>
              <PDGQuestionText
                mainQuestion={'How many days have you got?'}
                subText={'Pick your approximate duration for the trip'}
              />
              {durationList ? (
                <DurationCardList
                  durationList={durationList.durationInfo}
                  setSelectedDuration={this.setSelectedDuration}
                  minDays={props.pdgSelections.minDays}
                  maxDays={props.pdgSelections.maxDays}
                />
              ) : null}
            </section>
          </div>
        </div>
      );
    } else {
      return <Redirect to={`../`} />;
    }
  }
}

function mapStateToProps(state) {
  // console.log(state.app);

  return {
    regionDetails: {
      durationList: state.app.regionDetails
    },
    region: state.app.regionDetails,
    regionObject: state.app.regionObject,
    pdgSelections: state.app.pdgSelections,
    themeNames: state.app.themeNames
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getRegionDetails: bindActionCreators(getRegionDetails, dispatch),
      setMinMaxDays: bindActionCreators(setMinMaxDays, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(PDGDurationSelection);

function DurationCardList({
  durationList,
  setSelectedDuration,
  minDays,
  maxDays
}) {
  const c = durationList.map((durationItem, i) => {
    return (
      <DurationCard
        setSelectedDuration={setSelectedDuration}
        {...durationItem}
        i={i + 1}
        key={i}
        checked={
          minDays === durationItem.minDays && maxDays === durationItem.maxDays
        }
      />
    );
  });

  return <div className="clearfix row-eq-hgt n-tracker-totalhmdays">{c}</div>;
}
