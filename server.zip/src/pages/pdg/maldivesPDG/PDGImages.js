import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import Slider from 'react-slick';
import _ from 'lodash';
import { isFaqMobile, isMobile } from '../../../helpers/utilsHelper';

export default class PDGImages extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    let { hotelAPI } = this.props;
    let settings = {
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: true,
      infinite: true,
      speed: 500,
      lazyLoad: 'ondemand',
      responsive: [
        {
          settings: {
            infinite: false,
            slidesToShow: 1
          }
        }
      ]
    };

    let imageUrl,
      otherImage = null;
    let nightStay = null;
    let imageSlider =
      hotelAPI &&
      hotelAPI.hotelDetails &&
      hotelAPI.hotelDetails.length &&
      hotelAPI.hotelDetails.map((review, i) => {
        imageUrl = review.imageURL;
        otherImage = review.otherImages;
        nightStay = review.nights;
        return (
          otherImage &&
          otherImage.map((review, index) => {
            review = index === 0 ? imageUrl : review;
            return (
              <div
                tabIndex={index}
                data-index={Date.now()}
                key={`photo-feed-${index}`}
                style={{ width: 200 }}
              >
                <figure
                  style={{
                    backgroundImage: `url(${review})`
                  }}
                >
                  <figcaption className="fig-title">
                    <span className="tag-tertiary white truncate medium">
                      {nightStay} nights
                    </span>
                  </figcaption>
                </figure>
              </div>
            );
          })
        );
      });
    return (
      <div className="left-img">
        <figure
          className="visible-xs"
          style={{ backgroundImage: `url(${imageUrl})` }}
        >
          <figcaption className="fig-title">
            <span className="tag-tertiary white truncate medium">
              {nightStay} nights
            </span>
          </figcaption>
        </figure>
        <Slider
          {...settings}
          className="pdg-slider slider-1 hidden-xs slick-dotted"
        >
          {imageSlider}
        </Slider>
      </div>
    );
  }
}
