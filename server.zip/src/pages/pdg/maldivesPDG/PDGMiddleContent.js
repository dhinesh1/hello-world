import React, { Fragment, Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';
import {
  hideChatIconOnMobile,
  isFaqMobile
} from '../../../helpers/utilsHelper';
import StarRating from './PDGStarRating';
import { MenuItem, OverlayTrigger, Overlay, Popover } from 'react-bootstrap';

export default class PDGMiddleContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showAmenities: false
    };
    this.moreActivities = this.moreActivities.bind(this);
    this.ShowPopover = this.ShowPopover.bind(this);
    this.closeActivities = this.closeActivities.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.tabClicked !== nextProps.tabClicked) {
      this.setState({ showAmenities: false });
    }
  }

  closeActivities(e) {
    let t = this.state;
    t.showAmenities = !t.showAmenities;
    this.setState(t);
  }
  moreActivities(e) {
    let t = this.state;
    t.showAmenities = !t.showAmenities;
    this.setState(t);
  }

  ShowPopover(detail) {
    let speciality =
      detail.specialities &&
      detail.specialities.map((data, index) => {
        return (
          <ul className="pdg-options-list fine-text color-grey light">
            <li>
              <span className="icon color-grey-secondary fade">
                <i className={data.specialityIcon} />
              </span>
              <p>
                <b>{data.specialityName}: </b>
                {data.specialityDescription}
              </p>
            </li>
          </ul>
        );
      });
    return <Popover>{speciality}</Popover>;
  }

  render() {
    let { showAmenities } = this.state;
    let { hotelAPI } = this.props;
    let honeyMoonSpecial = false;
    let itineratyContent =
      hotelAPI &&
      hotelAPI.hotelDetails.map((pack, index) => {
        let specialities =
          pack &&
          pack.specialities &&
          pack.specialities.map((data, i) => {
            if (
              data.specialityName === 'Honeymoon Inclusions' ||
              data.specialityName === 'Honeymoon Special'
            ) {
              honeyMoonSpecial = true;
            }
            return (
              <Fragment>
                {data.specialityName === 'Honeymoon Inclusions' ||
                data.specialityName === 'Honeymoon Special' ? null : (
                  <li>
                    <i className={data.specialityIcon} /> {data.specialityName}{' '}
                  </li>
                )}
                {pack.specialities.length - 1 === i ? (
                  <OverlayTrigger
                    placement="top"
                    containerPadding={20}
                    delayHide={-200}
                    ref="overlaytriger"
                    overlay={this.ShowPopover(pack)}
                  >
                    <i className="vehoicon-help_outline" />
                  </OverlayTrigger>
                ) : null}
              </Fragment>
            );
          });
        return (
          <div
            className={classNames('middle-content', {
              extendContent: !showAmenities
            })}
            onClick={e => (showAmenities ? null : this.moreActivities(e))}
          >
            <h5>
              {honeyMoonSpecial ? (
                <span className="clearfix fw caps-text-tiny color-accent-1 bold">
                  <i className="vehoicon-heart fine-text" /> Honeymoon Special
                </span>
              ) : null}
              <span>{pack.name}</span> <StarRating rating={pack.stars} />
            </h5>
            <ul className="list-inline meta-text color-grey fade mb-0 hidden-xs">
              {specialities}
              <li
                className={classNames({
                  hide: showAmenities
                })}
              >
                <a id="showAmenities" href="javascript:void(0);">
                  View Details
                </a>
              </li>
            </ul>

            <div
              className={classNames('clearfix fw description-txt hidden-xs', {
                'hide-desc': !showAmenities
              })}
            >
              <p className="fine-text light color-grey mb-0 hidden-xs">
                {pack.description} <br />
                <a
                  className={classNames('viewless meta-text regular', {
                    hide: !showAmenities
                  })}
                  id="showAmenities"
                  href="javascript:void(0);"
                  onClick={e => this.closeActivities(e, true)}
                >
                  View less
                </a>
              </p>

              <ul className="list-unstyled fine-text light color-grey fade mb-0">
                <GetInclusionLineItem inclusion={pack.amenityDisplayList} />
              </ul>
            </div>
          </div>
        );
      });
    return itineratyContent ? itineratyContent : null;
  }
}

export function GetInclusionLineItem(inclusion) {
  let amenitiesTake =
    inclusion && inclusion.inclusion && _.take(inclusion.inclusion, 5);
  let amenities =
    inclusion.inclusion &&
    amenitiesTake.map((inclu, review) => {
      return (
        <li>
          <i className={inclu.iconUrl} />
          {'  '}
          {'  '} {inclu.amenityName}{' '}
        </li>
      );
    });
  return amenities;
}
