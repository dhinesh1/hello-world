import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';

export default class StarRating extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    let { rating } = this.props;
    let full_ratings = parseInt(rating, 10);
    let half_star_value = rating % full_ratings;
    let half_star = <i className={`vehoicon-star_half`} />;
    let full_stars = _.range(0, full_ratings).map((star, key) => {
      return <i className="vehoicon-star" />;
    });
    let empty_stars = null;
    let remaining_stars_count = 5 - Math.ceil(rating);

    if (remaining_stars_count >= 1) {
      empty_stars = _.range(0, remaining_stars_count).map((star, key) => {
        return <i className="vehoicon-star_border" />;
      });
    }
    return (
      <span className="star-rating">
        {full_stars}
        {half_star_value > 0 ? half_star : null}
        {empty_stars}
      </span>
    );
  }
}
