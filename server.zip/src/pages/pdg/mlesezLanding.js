import React, { Component } from 'react';
import classNames from 'classnames';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getMalSezHotel, clearMLESEZ } from '../../actions/actions_app';
import Login from '../Login';
import _ from 'lodash';
import {
  GetCostModalLoadable,
  CostingDelayScreenLoadable
} from '../../helpers/loadbleComponentsHelper';
import StepText from '../../common_components/pdg/StepText';
import PDGTitleSection from '../../common_components/pdg/PDGTitleSection';
import ActiveStageIndicator from '../../common_components/pdg/ActiveStageIndicator';
import {
  hideChatIconOnMobile,
  isFaqMobile,
  fixPDGHeader,
  fixPDGCitiesHeader,
  onceModalClosed
} from '../../helpers/utilsHelper';
import { Route, Switch } from 'react-router-dom';
import PDGTabSorting from './PDGTabsSorting';
import PDGSeychellesContent from './seychellesPDG/PDGSeychellesContent';
import PDGMobile from './PDGMSMobile/PDGMobile';
import PDGMaldivesContent from './maldivesPDG/PDGMaldivesContent';

class MleSezLanding extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      topDeals: 0,
      tabclicked: null,
      filteredHotelDetails: [],
      showMobileHD: {},
      showPopUp: false,
      maldivesSort: [
        { Text: 'Top resorts', value: 0, keyIndex: 0 },
        { Text: '4 stars', value: 4, keyIndex: 1 },
        { Text: '5 stars', value: 5, keyIndex: 2 }
      ],
      mauritiusSort: [
        { Text: 'Top resorts', value: 0, keyIndex: 0 },
        { Text: '4 nights', value: 4, keyIndex: 1 },
        { Text: '5+ nights', value: 5, keyIndex: 2 }
      ],
      seychellesSort: [
        { Text: 'Top resorts', value: 0, keyIndex: 0 },
        { Text: '5-6 nights', value: 5, keyIndex: 1 },
        { Text: '7+ nights', value: 7, keyIndex: 2 }
      ],
      regionCode: props.match.params.searchRegion,
      regionName:
        props.match.params.searchRegion === 'sez'
          ? 'Seychelles'
          : props.match.params.searchRegion === 'mle'
            ? 'Maldives'
            : 'Mauritius'
    };

    this.openMobileDetails = this.openMobileDetails.bind(this);
    this.closePopup = this.closePopup.bind(this);
    this.clickCustomize = this.clickCustomize.bind(this);
    this.tabClick = this.tabClick.bind(this);
    this.filterByHotelStarRating = this.filterByHotelStarRating.bind(this);

    this.isSeychellesPage = props.match.params.searchRegion === 'sez';
    this.isMaldivesPage = props.match.params.searchRegion === 'mle';
  }

  tabClick(value) {
    const filtered = this.filterByHotelStarRating(
      this.props.hotelDetails,
      value
    );
    this.setState({
      filteredHotelDetails: filtered,
      topDeals: value,
      tabclicked: value
    });
  }

  filterByHotelStarRating(hotelDetails, hotelStarRating) {
    if (this.isSeychellesPage) {
      if (hotelStarRating) {
        return _.filter(hotelDetails, p => {
          let totalnights = [];
          let nights = _.filter(p.hotelDetails, function(el) {
            totalnights.push(el.nights);
          });
          let value = totalnights.reduce((a, b) => a + b, 0);
          if (hotelStarRating === 5) {
            return value >= 5 && value <= 6;
          } else if (hotelStarRating === 7) {
            return value >= 7;
          } else {
            return p.hotelDetails.some(data => {
              return data.topResort;
            });
          }
        });
      } else {
        return this.props.topResorts;
      }
    } else {
      if (hotelStarRating && hotelDetails) {
        if (this.isMaldivesPage) {
          return _.filter(hotelDetails, p => {
            if (hotelStarRating === 4) {
              return p.hotelDetails.some(data => {
                return data.stars === 4 || data.stars === 4.5;
              });
            } else if (hotelStarRating === 5) {
              return p.hotelDetails.some(data => {
                return data.stars === 5;
              });
            } else {
              return this.props.topResorts;
            }
          });
        } else {
          return _.filter(hotelDetails, p => {
            if (hotelStarRating === 5) {
              return p.hotelDetails.some(data => {
                return data.nights >= 5;
              });
            } else if (hotelStarRating === 4) {
              return p.hotelDetails.some(data => {
                return data.nights === 4;
              });
            } else {
              return this.props.topResorts;
            }
          });
        }
      } else {
        return this.props.topResorts;
      }
    }
  }

  clickCustomize(e, itinerayID) {
    e.preventDefault();
    let value = this.props;
    if (value.history.location.pathname.indexOf('get-cost') === -1) {
      value.history.push(
        `${value.history.location.pathname}/get-cost/${itinerayID}` +
          `${
            value.history.location.search
              ? value.history.location.search + ''
              : ''
          }`
      );
    }
  }
  componentDidMount() {
    hideChatIconOnMobile();

    let dW = window.innerWidth;
    if (dW > 767) {
      document.addEventListener('scroll', fixPDGHeader);
    }
    document.addEventListener('scroll', fixPDGCitiesHeader);

    let reqdata = { regionCode: this.state.regionCode };
    this.props.actions.getMalSezHotel(reqdata);
    setTimeout(() => {
      this.setState({ show: true });
    }, 10);
  }

  componentDidUpdate() {
    if (this.props.location.pathname === this.props.match.url) {
      onceModalClosed();
    }
  }

  openMobileDetails(e, showmItinerary) {
    if (isFaqMobile()) {
      const ele = document.querySelector('.pdg-details-content');
      ele && ele.scrollTo(0, 0);
      this.setState({ showPopUp: true, showMobileHD: showmItinerary });
    } else {
      this.setState({ showPopUp: false });
    }
  }

  closePopup(e) {
    this.setState({ showPopUp: false });
  }

  componentWillUnmount() {
    this.props.actions.clearMLESEZ();

    document.removeEventListener('scroll', fixPDGHeader);
    document.removeEventListener('scroll', fixPDGCitiesHeader);
  }

  render() {
    let props = this.props;
    let {
      maldivesSort,
      seychellesSort,
      regionCode,
      regionName,
      mauritiusSort
    } = this.state;
    let { hotelDetails } = props;
    let containerClassNames = classNames({
      'search-container': true,
      'show-search': true
    });

    let paramsVal = { searchRegion: regionCode };
    let filtered = this.state.filteredHotelDetails.length
      ? this.state.filteredHotelDetails
      : hotelDetails
        ? this.props.topResorts
        : null;

    return (
      <div>
        <Switch>
          <Route
            path={`/customize/${regionCode}/get-cost/:itineraryId`}
            exact={true}
            component={GetCostModalLoadable}
          />
          <Route
            path={`/customize/${regionCode}/get-cost/:itineraryId/login`}
            component={Login}
          />
          <Route
            path={`/customize/${regionCode}/get-cost/:itineraryId/signup`}
            component={props => (
              <Login
                {...props}
                actionType="SIGNUP"
                headerText="Join the travel tribe!"
                subText="Save your itineraries and make unlimited edits. Create an account to get started right-away!"
              />
            )}
          />
          <Route
            path={`/customize/${regionCode}/get-cost/:itineraryId/costing-delay`}
            component={CostingDelayScreenLoadable}
          />
        </Switch>
        <div className={containerClassNames}>
          <div className="search-content">
            {/* search-field starts */}
            <section className="clearfix search-field">
              <StepText
                params={paramsVal}
                mainText={'PLAN A VACATION TO'}
                mainTextMobile={regionName}
                showSentence={false}
              />
              <section className="clearfix search-input-container">
                <PDGTitleSection
                  showInput={false}
                  showTitle={true}
                  handleBack={() => {
                    this.props.history.goBack();
                  }}
                  handleForward={() => {
                    this.props.history.goForward();
                  }}
                  title={regionName}
                  titleMobile={
                    this.isSeychellesPage ? 'Choose Package' : 'Choose Property'
                  }
                />
                <ActiveStageIndicator currentStepIndex={0} actives={2} />
              </section>
            </section>
            {!hotelDetails ? (
              <div
                className="hero-banner vertical-center bg-white"
                style={{ height: 300 }}
              >
                <div className="center-block text-center loading-bars">
                  <span className="bar1" />
                  <span className="bar2" />
                  <span className="bar3" />
                  <span className="bar4" />
                </div>
              </div>
            ) : null}

            {hotelDetails &&
            filtered &&
            filtered.length &&
            hotelDetails.length ? (
              <section
                className={classNames('clearfix search-options-wrapper', {
                  'slide-left-in': this.state.show
                })}
              >
                <div className="clearfix text-center hidden-xs pdg-title">
                  <h4>Which hotel you'd like to stay in? </h4>
                </div>

                <PDGTabSorting
                  clickingTabs={this.tabClick}
                  hotelDetails={hotelDetails}
                  sortingOptions={
                    this.isSeychellesPage
                      ? seychellesSort
                      : this.isMaldivesPage
                        ? maldivesSort
                        : mauritiusSort
                  }
                />

                {this.isSeychellesPage ? (
                  <div className="clearfix fw" id="seyContent">
                    <PDGSeychellesContent
                      hotelDetails={filtered}
                      tabClicked={this.state.tabclicked}
                      history={this.props.history}
                      openMobileDetails={this.openMobileDetails}
                      showPopUp={this.state.showPopUp}
                      closePopup={this.closePopup}
                      clickCustomize={this.clickCustomize}
                    />
                  </div>
                ) : (
                  <div className="clearfix fw" id="malContent">
                    <PDGMaldivesContent
                      hotelDetails={filtered}
                      tabClicked={this.state.tabclicked}
                      history={this.props.history}
                      openMobileDetails={this.openMobileDetails}
                      showPopUp={this.state.showPopUp}
                      closePopup={this.closePopup}
                      clickCustomize={this.clickCustomize}
                    />
                  </div>
                )}
              </section>
            ) : null}
          </div>
          {isFaqMobile() &&
          hotelDetails &&
          !_.isEmpty(this.state.showMobileHD) &&
          hotelDetails.length ? (
            <PDGMobile
              isClicked={true}
              hotelDetails={this.state.showMobileHD}
              showPopUp={this.state.showPopUp}
              closePopup={this.closePopup}
              clickCustomize={this.clickCustomize}
            />
          ) : null}
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  if (state.hotelDetails) {
    let topResort = null;
    if (state.hotelDetails.content) {
      topResort = _.filter(state.hotelDetails.content, function(el) {
        return el.hotelDetails.some(data => {
          return data.topResort;
        });
      });
    }
    return {
      topResorts: topResort,
      hotelDetails: state.hotelDetails.content,
      hasError: state.hotelDetails.hasError,
      error: state.hotelDetails.error
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getMalSezHotel: bindActionCreators(getMalSezHotel, dispatch),
      clearMLESEZ: bindActionCreators(clearMLESEZ, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(MleSezLanding);
