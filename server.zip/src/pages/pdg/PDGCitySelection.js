import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import { connect } from 'react-redux';
import { AppConfig } from '../../app-config';
import { bindActionCreators } from 'redux';
import {
  getTopCities,
  addCityId,
  removeCityId,
  createItinerary,
  removeAllCityIds,
  setSelectedPDGCities
} from '../../actions/actions_app';
import _ from 'lodash';

import SweetAlert from 'sweetalert-react';
import SingleCityCard from '../../common_components/pdg/SingleCityCard';
import SingleComboCard from '../../common_components/pdg/SingleComboCard';
import StepText from '../../common_components/pdg/StepText';
import PDGTitleSection from '../../common_components/pdg/PDGTitleSection';
import CityFooterMobile from '../../common_components/pdg/CityFooterMobile';
import CityBottomOptions from '../../common_components/pdg/CityBottomOptions';
import CityTagsContainer from '../../common_components/pdg/CityTagsContainer';
import ActiveStageIndicator from '../../common_components/pdg/ActiveStageIndicator';
import { triggerSimpleAjax } from '../../helpers/httpHelper';
import {
  fixPDGHeader,
  fixPDGCitiesHeader,
  searchStringInArray,
  hideChatIconOnMobile,
  isFaqMobile
} from '../../helpers/utilsHelper';
import CitySearchError from '../../common_components/CitySearchError';
import { trackEvent, EVENT_PDG_CITY_REMOVED, EVENT_PDG_CITY_ADDED } from '../../helpers/ML/EventsTracker';

class PDGCitySelection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      noOfActives: 4,
      show: false,
      choosenCityOpen: false,
      showed: false,
      showAlert: false,
      showBottomOptions:
        (props.pdgSelections || { cities: [] }).cities.length > 0,
      isLoading: false,
      cityType: 'ALL_CITIES',
      citySearchText: '',
      expandSearch: false,
      selectedCityObjects: [],
      viewSelectedCities: false,
      citiesSelectedForRemoval: [],
      citiesSelectedForRemovalNames: [],
      sweetAlertConfig: {
        title: 'Unable to create itinerary',
        text: 'Something went wrong. Please try again again',
        type: 'warning',
        animation: 'pop'
      },
      prefixWord: ''
    };

    this.setCityTabViewType = this.setCityTabViewType.bind(this);
    this.addSelectedCity = this.addSelectedCity.bind(this);
    this.removeSelectedCity = this.removeSelectedCity.bind(this);
    this.createItinerary = this.createItinerary.bind(this);
    this.createComboItinerary = this.createComboItinerary.bind(this);
    this.onInputChange = this.onInputChange.bind(this);
    this.expandCitySearchBox = this.expandCitySearchBox.bind(this);
    this.collapseCitySearchBox = this.collapseCitySearchBox.bind(this);
    this.openSelectedCityListView = this.openSelectedCityListView.bind(this);
    this.closeSelectedCityListView = this.closeSelectedCityListView.bind(this);
    this.addToRemoveCityList = this.addToRemoveCityList.bind(this);
    this.clearAllCities = this.clearAllCities.bind(this);
    this.clearSelectedCities = this.clearSelectedCities.bind(this);
    this.switchToAllCitiesTab = this.switchToAllCitiesTab.bind(this);

    this.getPrefixWord = this.getPrefixWord.bind(this);
  }

  addSelectedCityObjToComponentState(cityObj) {
    let t = this.state;
    t.selectedCityObjects.push(cityObj);
    this.setState(t);
  }

  componentDidMount() {
    hideChatIconOnMobile();

    let dW = window.innerWidth;
    if (dW > 767) {
      document.addEventListener('scroll', fixPDGHeader);
    }
    document.addEventListener('scroll', fixPDGCitiesHeader);

    let selectedCity = localStorage.getItem('selected_city');
    let { pdgSelections } = this.props;
    let alreadySelectedCities = pdgSelections.cities;
    let selectedCityObj = selectedCity && JSON.parse(selectedCity);
    if (
      selectedCityObj &&
      !alreadySelectedCities.includes(parseInt(selectedCityObj.cityId))
    ) {
      triggerSimpleAjax(
        `${AppConfig.api_url}misc/getSelectedCity`,
        'POST',
        { cityId: selectedCityObj.cityId },
        response => {
          if (response.status === 'SUCCESS') {
            let city = response.data;
            this.addSelectedCity(city, city.name);

            // this.props.actions.addCityId(city.id, city.name).then(() => {
            //   this.addSelectedCityObjToComponentState(city);
            //   this.props.actions.getTopCities(this.props.pdgSelections);
            //   this.setCityTabViewType('ALL_CITIES');
            //
            //   // this.setState({showBottomOptions: true});
            // });
          }
        },
        error => {
          console.error(error);
        }
      );
      setTimeout(() => {
        this.setState({ noOfActives: 5, show: true, showBottomOptions: true });
      }, 10);
    } else {
      this.props.actions.getTopCities(this.props.pdgSelections);
      // console.log('getting cities');

      setTimeout(() => {
        setTimeout(() => {
          this.setState({ showed: true });
        }, 500);
        this.setState({ noOfActives: 5, show: true });
      }, 10);
    }
  }

  handleBack = () => {
    this.props.history.goBack();
  };

  handleForward = () => {
    this.props.history.go(+1);
  };

  componentWillReceiveProps(nextProps) {
    let t = this.state;
    if (nextProps && nextProps.topCities && !nextProps.topCities.combos) {
      if (this.state.cityType === 'TOP_COMBOS') {
        t.cityType = 'HIDDEN_GEMS';
        this.setState(t);
      }
    }

    if (nextProps.itineraryCreationError) {
      t.showAlert = true;
      this.setState(t);
    }
  }

  componentWillUnmount(): void {
    document.removeEventListener('scroll', fixPDGHeader);
    document.removeEventListener('scroll', fixPDGCitiesHeader);
  }

  expandCitySearchBox() {
    this.setState({
      expandSearch: true,
      cityType: 'ALL_CITIES',
      tempTab: this.state.cityType
    });
    this.nameInput.focus();
  }

  collapseCitySearchBox(goBack = false) {
    let t = this.state;
    t.expandSearch = false;

    if (t.citySearchText === '' && goBack) {
      t.cityType = t.tempTab;
    }
    t.citySearchText = '';

    this.setState(t);
  }

  addSelectedCity(city, cityName) {
    if (this.state.isLoading) {
      return null;
    }
    let { pdgSelections } = this.props;
    let alreadySelectedCities = pdgSelections.cities;
    if (alreadySelectedCities.length <= 7) {
      let cityId = city.id;

      if (alreadySelectedCities && !alreadySelectedCities.includes(cityId)) {
        let cityCardEl = document.getElementById(`city-${cityId}`);
        if (cityCardEl) {
          cityCardEl.classList.add('remove');
        }
        const { cityType, citySearchText } = this.state;

        this.setState({ citySearchText: '' }, () => {
          if (this.state.expandSearch) {
            this.nameInput.focus();
          }
        });

        this.props.actions.addCityId(cityId, cityName).then(() => {
          this.addSelectedCityObjToComponentState(city);

          let itineraryRequestObject = this.props.pdgSelections;
          itineraryRequestObject.cityActivityMap = [];

          trackEvent(EVENT_PDG_CITY_ADDED, {
            city: cityName,	
            tab_selected: cityType,	
            search_text: citySearchText
          });

          this.props.actions.getTopCities(itineraryRequestObject).then(() => {
            this.getPrefixWord();

            let allRemovedCards = document.querySelectorAll(
              '.city-card-wrapper.remove'
            );
            if (allRemovedCards) {
              [].forEach.call(allRemovedCards, el => {
                el.classList.remove('remove');
              });
            }
          });

          if (!this.state.showBottomOptions) {
            this.setState({ showBottomOptions: true });
          }
        });
      }
    } else {
      let sweetAlertConfig = {
        title: 'Too many cities!',
        text:
          'Hey! You can select a maximum of 8 cities at this stage. You can however customize and add any number of cities once your itinerary is created!',
        type: 'warning',
        animation: 'pop'
      };
      let t = this.state;
      t.sweetAlertConfig = sweetAlertConfig;
      t.showAlert = true;
      this.setState(t);
    }
  }

  onInputChange(e) {
    let t = this.state;
    t[e.target.name] = e.target.value;
    this.setState(t);
  }

  switchToAllCitiesTab() {
    this.setCityTabViewType('ALL_CITIES');
  }

  removeSelectedCity(cityId, cityName) {
    this.props.actions.removeCityId(cityId, cityName).then(() => {
      this.setState({
        showBottomOptions: this.props.selectedCityNames.length > 0
      });
      let itineraryRequestObject = this.props.pdgSelections;
      itineraryRequestObject.cityActivityMap = [];
      this.props.actions.getTopCities(this.props.pdgSelections);
      
      trackEvent(EVENT_PDG_CITY_REMOVED, {
        city: cityName
      });
    });
  }

  clearAllCities() {
    this.props.actions.removeAllCityIds().then(() => {
      this.setState({
        selectedCityObjects: [],
        viewSelectedCities: false,
        showBottomOptions: false
      });
    });
  }

  clearSelectedCities() {
    let newSetOfCities = _.difference(
      this.props.pdgSelections.cities,
      this.state.citiesSelectedForRemoval
    );
    let newSetOfCitiesNames = _.difference(
      this.props.selectedCityNames,
      this.state.citiesSelectedForRemovalNames
    );
    // track all the removed cities
    this.state.citiesSelectedForRemoval.forEach((city_id, index) => {
      trackEvent(EVENT_PDG_CITY_REMOVED, {	
        city: this.state.citiesSelectedForRemovalNames[index]
      });
    });

    let t = this.state;
    this.props.actions.setSelectedPDGCities(
      newSetOfCities,
      newSetOfCitiesNames
    );
    t.viewSelectedCities = false;
    t.selectedCityObjects = _.filter(t.selectedCityObjects, selectedCity => {
      return !t.citiesSelectedForRemoval.includes(selectedCity.id);
    });
    t.citiesSelectedForRemoval = [];
    t.citiesSelectedForRemovalNames = [];
    t.showBottomOptions = newSetOfCitiesNames.length > 0;

    this.setState(t, () => {
      this.props.actions.getTopCities(this.props.pdgSelections);
      let selectedCityCardWrapper = document.querySelectorAll(
        '.selected-city-card-wrapper'
      );
      let cityCardWrapper = document.querySelectorAll('.city-card-wrapper');

      for (let i = 0; i < selectedCityCardWrapper.length; i++) {
        selectedCityCardWrapper[i].classList.remove('remove');
      }

      for (let j = 0; j < cityCardWrapper.length; j++) {
        cityCardWrapper[j].classList.remove('remove');
      }
    });
  }

  addToRemoveCityList(city, e) {
    let t = this.state;
    if (!_.includes(t.citiesSelectedForRemoval, city.id)) {
      t.citiesSelectedForRemoval.push(city.id);
      t.citiesSelectedForRemovalNames.push(city.name);
    } else {
      t.citiesSelectedForRemoval.splice(
        t.citiesSelectedForRemoval.indexOf(city.id),
        1
      );
      t.citiesSelectedForRemovalNames.splice(
        t.citiesSelectedForRemovalNames.indexOf(city.name),
        1
      );
    }
    this.setState(t);
  }

  createItinerary() {
    let pdgSelections = this.props.pdgSelections;
    const themes = this.props.themeNames;
    if (this.state.showAlert) {
      this.setState({ showAlert: false });
    }
    if (pdgSelections.cities && pdgSelections.cities.length > 0) {
      pdgSelections.comboId = null;
    }
    this.setState({ isLoading: true }, () => {
      this.props.actions.createItinerary({...pdgSelections, themes}, this.props.history);
    });
  }

  createComboItinerary(comboId) {
    let pdgSelections = this.props.pdgSelections;
    const themes = this.props.themeNames;
    pdgSelections.comboId = comboId;
    this.props.actions.createItinerary({...pdgSelections, themes}, this.props.history);
  }

  setCityTabViewType(type) {
    let t = this.state;
    t.cityType = type;
    let ele = document.querySelector('.search-container.show-search');
    if (ele && ele.scrollTop > 170) {
      ele.scrollTo({
        top: isFaqMobile() ? 0 : 191,
        left: 0,
        behavior: 'smooth'
      });
    }
    this.setState(t, () => {
      this.collapseCitySearchBox();
    });
  }

  openSelectedCityListView() {
    let t = this.state;
    t.viewSelectedCities = true;
    this.setState(t);
    setTimeout(() => {
      this.setState({ choosenCityOpen: true });
    }, 500);
  }

  closeSelectedCityListView() {
    let t = this.state;
    t.viewSelectedCities = false;
    t.choosenCityOpen = false;
    this.setState(t);
  }

  getPrefixWord() {
    let { topCities } = this.props;
    let remainingMaxDays = topCities ? topCities.remainingMaxDays : null;

    let prefixWord = '';
    if (remainingMaxDays > 3) {
      const greetingWords = [
        'Good Choice!',
        'Perfect!',
        'Awesome',
        'Keep going!'
      ];
      prefixWord =
        greetingWords[Math.floor(Math.random() * greetingWords.length)];
    } else if (remainingMaxDays > 1 && remainingMaxDays <= 3) {
      prefixWord = 'Looks just fine...';
    } else if (remainingMaxDays > -2 && remainingMaxDays <= 1) {
      prefixWord = 'Hmmm..';
    } else {
      const alertWords = ['You sure?', 'Alert!'];
      prefixWord = alertWords[Math.floor(Math.random() * alertWords.length)];
    }

    this.setState({ prefixWord });
  }

  render() {
    let containerClassNames = classNames({
      'search-container': true,
      'show-search': true,
      'bottom-options-shown': this.state.showBottomOptions
    });

    let props = this.props;
    let { searchRegion } = props.match && props.match.params;
    let { noOfActives, citiesSelectedForRemoval, prefixWord } = this.state;
    let topComboActive = classNames('n-tracker-topcombos', {
      active: this.state.cityType === 'TOP_COMBOS'
    });

    let hiddenGemsActive = classNames('n-tracker-hiddengems', {
      active: this.state.cityType === 'HIDDEN_GEMS'
    });

    let allCitiesActive = classNames('n-tracker-allcities', {
      active: this.state.cityType === 'ALL_CITIES'
    });

    let tabSearchClassNames = classNames({
      'tab-search expand': true,
      expand: this.state.expandSearch
    });

    let {
      pdgSelections,
      themeNames,
      selectedCityNames,
      topCities,
      region,
      regionObject
    } = this.props;
    let {
      viewSelectedCities,
      selectedCityObjects,
      showAlert,
      sweetAlertConfig
    } = this.state;
    if (themeNames) {
      return (
        <div className={containerClassNames}>
          {pdgSelections.comboId ? (
            <SweetAlert
              show={showAlert}
              title={sweetAlertConfig.title}
              text={sweetAlertConfig.text}
              type={sweetAlertConfig.type}
              animation={sweetAlertConfig.animation}
              onConfirm={() => this.setState({ showAlert: false })}
              showCancelButton={false}
              confirmButtonText={'Okay'}
            />
          ) : (
            <SweetAlert
              show={showAlert}
              title={sweetAlertConfig.title}
              text={sweetAlertConfig.text}
              type={sweetAlertConfig.type}
              animation={sweetAlertConfig.animation}
              onCancel={() => this.setState({ showAlert: false })}
              onConfirm={() => this.createItinerary()}
              confirmButtonText={'Create Itinerary'}
              showCancelButton={true}
            />
          )}

          <div className="search-content">
            {/* search-field starts */}
            <section className="clearfix search-field">
              <StepText
                mainText={'NOW PLANNING'}
                mainTextMobile={region ? region.regionName : searchRegion}
                showSentence={true}
                params={props.match.params}
                pdgData={pdgSelections}
                selectedThemes={themeNames}
              />
              <section className="clearfix search-input-container">
                {/*<PDGTitleSection
                  showInput={false}
                  showTitle={true}
                  title={
                    regionObject
                      ? regionObject.search
                      : region
                        ? region.regionName
                        : searchRegion
                  }
                  titleMobile="Choose cities"
                  handleBack={this.handleBack}
                  handleForward={this.handleForward}
                />*/}
                {isFaqMobile() ? (
                  <div className="clearfix pos-r input-holder">
                    <input
                      type="text"
                      className="fw"
                      placeholder={`Find a city in ${
                        region ? region.regionName : searchRegion
                      }`}
                      ref={input => {
                        this.nameInput = input;
                      }}
                      value={this.state.citySearchText}
                      name="citySearchText"
                      onChange={this.onInputChange}
                      onFocus={this.expandCitySearchBox}
                    />
                    {this.state.citySearchText &&
                    this.state.citySearchText.length > 0 ? (
                      <i
                        onClick={() => {
                          this.setState({ citySearchText: '' });
                        }}
                        className="vehoicon-backspace visible-xs input-clear-icon"
                      />
                    ) : null}
                  </div>
                ) : pdgSelections && pdgSelections.cities.length === 0 ? (
                  <PDGTitleSection
                    showInput={false}
                    showTitle={true}
                    handleFoward={e => {
                      this.props.history.goForward();
                    }}
                    handleBack={e => {
                      e.preventDefault();
                      this.props.history.goBack();
                    }}
                    title={
                      regionObject
                        ? regionObject.search
                        : region
                          ? region.regionName
                          : searchRegion
                    }
                    titleMobile="Choose cities"
                  />
                ) : (
                  <div className="clearfix pos-r input-holder">
                    <CityTagsContainer
                      removeSelectedCity={this.removeSelectedCity}
                      selectedCityNames={selectedCityNames}
                      selectedCityIds={pdgSelections.cities}
                    />
                  </div>
                )}
                <ActiveStageIndicator
                  currentStepIndex={3}
                  actives={noOfActives}
                />
              </section>
            </section>
            {/* search-field ends */}
            <div>
              <section className="clearfix pdg-cities search-options-wrapper">
                <div className="clearfix inner-search hidden-xs">
                  <input
                    type="text"
                    placeholder="Find a city"
                    ref={input => {
                      this.nameInput = input;
                    }}
                    autoComplete="off"
                    value={this.state.citySearchText}
                    name="citySearchText"
                    onChange={this.onInputChange}
                    onFocus={this.expandCitySearchBox}
                  />
                  <i className="vehoicon-close cursor-pointer" />
                </div>
                {/*
                <PDGQuestionText
                  mainQuestion={'What are your must-visit cities?'}
                  subText={'Pick your choice of places'}
                /> */}
                {/* <div
                  className={classNames('next-slide', {
                    'slide-left-in': true,
                    showed: this.state.showed
                  })}
                > */}
                {!viewSelectedCities ? (
                  <div className="clearfix pos-r tab-links-container">
                    <div className="clearfix tab-holder">
                      <ul className="pull-left list-unstyled tab-links">
                        <li
                          onClick={() => this.setCityTabViewType('ALL_CITIES')}
                          className={allCitiesActive}
                        >
                          All cities
                        </li>
                        <li
                          onClick={() => this.setCityTabViewType('HIDDEN_GEMS')}
                          className={hiddenGemsActive}
                        >
                          Hidden gems
                        </li>
                        {topCities && topCities.combos ? (
                          <li
                            onClick={() =>
                              this.setCityTabViewType('TOP_COMBOS')
                            }
                            className={topComboActive}
                          >
                            Trending combos
                          </li>
                        ) : null}
                      </ul>
                      {/*
                    <div className={tabSearchClassNames}>
                      <div className="tab-search-input">
                        <input
                          type="text"
                          placeholder="Find a city"
                          ref={input => {
                            this.nameInput = input;
                          }}
                          value={this.state.citySearchText}
                          name="citySearchText"
                          onChange={this.onInputChange}
                          onFocus={this.expandCitySearchBox}
                          />
                        <i className="vehoicon-search cursor-pointer visible-xs" />
                        <i className="vehoicon-close cursor-pointer" />
                      </div>
                    </div>
                    */}
                      {/* <div className={tabSearchClassNames}>
                      <div className="tab-search-input">
                        <input
                          ref={input => {
                            this.nameInput = input;
                          }}
                          type="text"
                          placeholder="Find a city"
                          value={this.state.citySearchText}
                          name="citySearchText"
                          onChange={this.onInputChange}
                          onFocus={this.expandCitySearchBox}
                          // onBlur={this.collapseCitySearchBox}
                        />
                        <i
                          onClick={this.expandCitySearchBox}
                          className="vehoicon-search cursor-pointer visible-xs"
                        />
                        <i
                          onClick={e => this.collapseCitySearchBox(true)}
                          className="vehoicon-close cursor-pointer"
                        />
                      </div>
                    </div> */}
                    </div>
                  </div>
                ) : null}
                {/* </div> */}
                {!viewSelectedCities ? (
                  topCities ? (
                    this.state.cityType !== 'TOP_COMBOS' ? (
                      <CityCardList
                        cityName={this.state.citySearchText}
                        addSelectedCity={this.addSelectedCity}
                        type={this.state.cityType}
                        cities={topCities.options}
                        citiesSelectedForRemoval={citiesSelectedForRemoval}
                      />
                    ) : topCities.combos ? (
                      <ComboList
                        cityName={this.state.citySearchText}
                        combos={topCities.combos}
                        createComboItinerary={this.createComboItinerary}
                      />
                    ) : null
                  ) : null
                ) : (
                  <div
                    className={classNames('next-slide', {
                      'slide-left-in': this.state.choosenCityOpen
                    })}
                  >
                    <CityCardList
                      cityCardContainerClass="selected-city-card-wrapper"
                      cityName={this.state.citySearchText}
                      addSelectedCity={this.addSelectedCity}
                      cities={selectedCityObjects}
                      addToRemoveCityList={this.addToRemoveCityList}
                      citiesSelectedForRemoval={citiesSelectedForRemoval}
                      switchToAllCitiesTab={this.switchToAllCitiesTab}
                    />
                  </div>
                )}
              </section>
            </div>
          </div>
          {topCities ? (
            <CityBottomOptions
              show={this.state.showBottomOptions}
              remainingMinDays={topCities.remainingMinDays}
              remainingMaxDays={topCities.remainingMaxDays}
              createItinerary={this.createItinerary}
              isLoading={this.state.isLoading}
              prefixWord={prefixWord}
            />
          ) : null}

          {!viewSelectedCities && topCities && isFaqMobile() ? (
            <CityFooterMobile
              screenType={'CHOOSE_CITIES'}
              openSelectedCityListView={this.openSelectedCityListView}
              show={this.state.showBottomOptions}
              remainingMinDays={topCities.remainingMinDays}
              remainingMaxDays={topCities.remainingMaxDays}
              createItinerary={this.createItinerary}
              selectedCities={pdgSelections.cities}
              citiesSelectedForRemoval={citiesSelectedForRemoval}
              isLoading={this.state.isLoading}
            />
          ) : null}

          {viewSelectedCities && topCities && isFaqMobile() ? (
            <CityFooterMobile
              screenType={'CHOSEN_CITIES'}
              selectedCities={pdgSelections.cities}
              openSelectedCityListView={this.openSelectedCityListView}
              closeSelectedCityListView={this.closeSelectedCityListView}
              show={this.state.showBottomOptions}
              clearAllCities={this.clearAllCities}
              citiesSelectedForRemoval={citiesSelectedForRemoval}
              clearSelectedCities={this.clearSelectedCities}
            />
          ) : null}
        </div>
      );
    } else {
      return <Redirect to={`../..`} />;
    }
  }
}

function mapStateToProps(state) {
  return {
    topCities: state.app.topCities,
    regionDetails: state.app.topCities,
    pdgSelections: state.app.pdgSelections,
    themeNames: state.app.themeNames,
    selectedCityNames: state.app.selectedCityNames,
    itineraryCreationError: state.app.itineraryCreationError,
    region: state.app.regionDetails,
    regionObject: state.app.regionObject
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getTopCities: bindActionCreators(getTopCities, dispatch),
      addCityId: bindActionCreators(addCityId, dispatch),
      removeCityId: bindActionCreators(removeCityId, dispatch),
      createItinerary: bindActionCreators(createItinerary, dispatch),
      removeAllCityIds: bindActionCreators(removeAllCityIds, dispatch),
      setSelectedPDGCities: bindActionCreators(setSelectedPDGCities, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(PDGCitySelection);

function CityCardList({
  cities,
  type,
  addSelectedCity,
  cityName,
  cityCardContainerClass,
  addToRemoveCityList,
  citiesSelectedForRemoval,
  switchToAllCitiesTab
}) {
  let filteredCity = cities;
  if (type === 'HIDDEN_GEMS') {
    filteredCity = _.filter(cities, { hiddenGem: true });
  }

  let cityNameLowerCase = cityName.trim().toLowerCase();

  if (cityName !== '') {
    filteredCity = _.filter(filteredCity, city => {
      return (
        new RegExp(cityNameLowerCase, 'i').test(city.name) ||
        new RegExp(cityNameLowerCase, 'i').test(city.country)
      );
    });
  }

  const c = filteredCity.map((city, i) => {
    return (
      <SingleCityCard
        addSelectedCity={!cityCardContainerClass ? addSelectedCity : null}
        addToRemoveCityList={
          cityCardContainerClass ? addToRemoveCityList : null
        }
        city={city}
        i={i + 1}
        currentTab={type}
        key={i}
        containerName={cityCardContainerClass}
        citiesSelectedForRemoval={citiesSelectedForRemoval}
      />
    );
  });

  if (c.length === 0) {
    return (
      <div className={'clearfix'}>
        <CitySearchError
          switchToAllCitiesTab={switchToAllCitiesTab}
          type={type}
        />
      </div>
    );
  } else {
    return <div className="clearfix">{c}</div>;
  }
}

function ComboList({ combos, createComboItinerary, cityName }) {
  let filteredCombos = _.filter(combos, combo => {
    return searchStringInArray(cityName.toLowerCase(), combo.cityNames) > -1;
  });

  const c = filteredCombos.map((combo, i) => {
    return (
      <SingleComboCard
        createComboItinerary={createComboItinerary}
        {...combo}
        i={i + 1}
        key={i}
      />
    );
  });

  if (c.length === 0) {
    return (
      <div className={'clearfix'}>
        <CitySearchError type={'COMBO'} />
      </div>
    );
  } else {
    return <div className="clearfix">{c}</div>;
  }
}
