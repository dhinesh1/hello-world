import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';
import {
  hideChatIconOnMobile,
  isFaqMobile
} from '../../../helpers/utilsHelper';

import PDGSeychellesImages from './PDGSeychellesImages';
import PDGMiddleContent from './PDGMiddleContent';
import PDGSeychellesExpansion from './PDGSeychellesExpansion';

export default class PDGSeychellesContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      detailExpand: true,
      clickedDetails: null,
      expandItineriesData: {},
      initial: false,
      fromCloseiconClick: false
    };
    this.moreActivities = this.moreActivities.bind(this);
    this.clickCustomize = this.clickCustomize.bind(this);
    this.closePreviousExpansion = this.closePreviousExpansion.bind(this);
  }

  closePreviousExpansion(e) {
    let ele = e.target.closest('.pdg-seychelles-wrapper');
    let t = this.state;
    t.initial = true;
    t.clickedDetails = ele.tabIndex;
    t.detailExpand = !t.detailExpand;
    t.fromCloseiconClick = true;
    this.setState(t);
  }
  moreActivities(e, itineraries) {
    let ele = e.target.closest('.pdg-seychelles-wrapper');
    let t = this.state;
    t.initial = true;
    t.expandItineriesData = itineraries;
    t.clickedDetails = ele.tabIndex;
    t.detailExpand = !t.detailExpand;
    t.fromCloseiconClick = false;
    this.setState(t);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.tabClicked !== nextProps.tabClicked) {
      this.setState({ clickedDetails: null });
    }
  }

  showGetCostModal(e, itineraries, buttonClick) {
    if (isFaqMobile()) {
      this.props.openMobileDetails(e, itineraries);
    } else if (
      (e.target &&
        !isFaqMobile() &&
        e.target.tagName.toLowerCase() !== 'a' &&
        e.target.tagName.toLowerCase() !== 'i' &&
        !e.target.closest('.extendContent') &&
        e.target.tagName.toLowerCase() !== 'button') ||
      buttonClick
    ) {
      e.preventDefault();
      let itineraryId = itineraries.campaignItineraryId;
      if (this.props.history.location.pathname.indexOf('get-cost') === -1) {
        this.props.history.push(
          `${this.props.history.location.pathname}/get-cost/${itineraryId}` +
            `${
              this.props.history.location.search
                ? this.props.history.location.search + ''
                : ''
            }`
        );
      }
    }
  }
  clickCustomize(e, hotelAPI, customizeClick) {
    e.preventDefault();
    this.showGetCostModal(e, hotelAPI, customizeClick);
  }

  render() {
    let { clickCustomize, hotelDetails } = this.props;
    let itineraries =
      hotelDetails &&
      hotelDetails.map((pack, i) => {
        let totalnights = [];
        let nights = _.filter(pack.hotelDetails, function(el) {
          totalnights.push(el.nights);
        });
        let value = totalnights.reduce((a, b) => a + b, 0);
        return (
          <section
            className="pdg-seychelles-wrapper"
            tabIndex={i}
            onClick={e => this.showGetCostModal(e, pack, false)}
          >
            <div
              className={classNames('clearfix sey-main-card', {
                hide:
                  this.state.initial === false
                    ? this.state.initial
                    : this.state.fromCloseiconClick
                      ? false
                      : i === this.state.clickedDetails
              })}
            >
              <PDGSeychellesImages
                hotelAPI={pack.hotelDetails}
                hotelDetails={pack}
                totalNights={value}
              />

              <PDGMiddleContent
                hotelAPI={pack}
                extendActivties={this.moreActivities}
              />

              <PDGRightContent
                hotelAPI={pack}
                clickCustomize={this.clickCustomize}
              />

              <div className="clearfix fw btm-price">
                <ul className="list-unstyled fine-text light mb-0">
                  <li>
                    <a className="color-grey" href="javascript:void(0);">
                      View Details
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            {!_.isEmpty(this.state.expandItineriesData) &&
            this.state.clickedDetails === i ? (
              <PDGSeychellesExpansion
                hotelAPI={this.state.expandItineriesData}
                detailExpand={this.state.detailExpand}
                currentIndex={i}
                isCloseIconClick={this.state.fromCloseiconClick}
                clickCustomize={this.clickCustomize}
                clickedDetails={this.state.clickedDetails}
                closeActivities={this.closePreviousExpansion}
              />
            ) : null}
          </section>
        );
      });
    return itineraries;
  }
}

export function PDGRightContent({ clickCustomize, hotelAPI }) {
  return (
    <div className="rgt-price hidden-xs">
      <div className="cust-btn">
        <button
          type="button"
          className="btn btn-primary btn-sm"
          onClick={e => clickCustomize(e, hotelAPI, true)}
        >
          Customize
        </button>
        <p className="color-grey light fade">
          Change inclusions, optimize costs
        </p>
      </div>
    </div>
  );
}
