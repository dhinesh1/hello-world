import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';
import {
  hideChatIconOnMobile,
  isFaqMobile
} from '../../../helpers/utilsHelper';
import StarRating from '../maldivesPDG/PDGStarRating';
import { MenuItem, OverlayTrigger, Overlay, Popover } from 'react-bootstrap';

export default class PDGMiddleContent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.ShowPopover = this.ShowPopover.bind(this);
  }

  ShowPopover(detail) {
    let speciality =
      detail.specialities &&
      detail.specialities.map((data, index) => {
        return (
          <ul className="pdg-options-list fine-text color-grey light">
            <li>
              <span className="icon color-grey-secondary fade">
                <i className={data.specialityIcon} />
              </span>
              <p>
                <b>{data.specialityName}: </b>
                {data.specialityDescription}
              </p>
            </li>
          </ul>
        );
      });
    return <Popover>{speciality}</Popover>;
  }

  render() {
    let { extendActivties } = this.props;
    let { hotelAPI, isExpanded } = this.props;
    let itineratyContent =
      hotelAPI &&
      hotelAPI.hotelDetails.map((pack, index) => {
        return (
          <p className="title-txt">
            <span className="pill-outline hidden-sm square primary-dark text-uppercase bold">
              {pack.cityName}, {pack.nights}N
            </span>
            <span>
              {pack.name.length > 25
                ? pack.name.substring(0, 25) + '...'
                : pack.name}
            </span>{' '}
            <StarRating rating={pack.stars} />
          </p>
        );
      });
    let specialities =
      hotelAPI &&
      hotelAPI.hotelDetails.map((pack, index) => {
        return (
          pack.specialities &&
          pack.specialities.map((data, i) => {
            return (
              <li>
                <i className={data.specialityIcon} /> {data.specialityName}{' '}
                {pack.specialities.length - 1 === i ? (
                  <OverlayTrigger
                    placement="top"
                    ref="overlaytriger"
                    overlay={this.ShowPopover(pack)}
                  >
                    <i className="vehoicon-help_outline" />
                  </OverlayTrigger>
                ) : null}
              </li>
            );
          })
        );
      });
    return (
      <div
        className="middle-content extendContent"
        onClick={e =>
          isFaqMobile() ? null : this.props.extendActivties(e, hotelAPI)
        }
      >
        {itineratyContent}{' '}
        <ul className="list-inline meta-text color-grey fade mb-0 hidden-xs">
          {isExpanded
            ? specialities
            : specialities && (specialities[0] || specialities[1])}
          {isExpanded ? null : (
            <li>
              <a href="javascript:void(0);" id="showDetailsCard">
                View Details
              </a>
            </li>
          )}
        </ul>
      </div>
    );
  }
}
