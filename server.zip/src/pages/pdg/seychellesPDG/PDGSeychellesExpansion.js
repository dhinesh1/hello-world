import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';
import {
  searchStringInArray,
  hideChatIconOnMobile,
  isFaqMobile
} from '../../../helpers/utilsHelper';

import Slider from 'react-slick';
import PDGSeychellesImages from './PDGSeychellesImages';
import PDGMiddleContent from './PDGMiddleContent';
import StarRating from '../maldivesPDG/PDGStarRating';
import PDGRightContent from './PDGSeychellesContent';

export default class PDGSeychellesExpansion extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    let {
      expanded,
      hotelAPI,
      expandedIndex,
      isCloseIconClick,
      currentIndex,
      detailExpand,
      clickedDetails
    } = this.props;
    let itineratyContent =
      hotelAPI &&
      hotelAPI.hotelDetails.map((pack, index) => {
        return (
          <section className="destination-card">
            <PDGExpandedImages hotelAPI={pack} />
            <PDGExpandcontent
              hotelAPI={pack}
              currentIndex={index}
              hotelDetailslength={hotelAPI.hotelDetails.length}
              closeActivities={this.props.closeActivities}
            />
            {index === 0 ? (
              <div className="rgt-price hidden-xs">
                {/* <p className="regular medium-heading mb-0">₹ {hotelAPI.price}</p>
                            <span className="fine-text color-grey light">Per person</span> */}
                <div className="cust-btn">
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={e => this.props.clickCustomize(e, hotelAPI, true)}
                  >
                    Customize
                  </button>
                  <p className="color-grey light fade">
                    Change inclusions, optimize costs
                  </p>
                </div>
              </div>
            ) : null}
          </section>
        );
      });
    return (
      <div
        className={classNames('sey-details-wrap hidden-xs', {
          hide: isCloseIconClick ? true : !(currentIndex === clickedDetails)
        })}
      >
        {/* <button
          className="btn btn-link-grey details-close"
          onClick={e => this.props.closeActivities(e)}
        >
          <i className="vehoicon-close" />
        </button> */}
        {itineratyContent}
      </div>
    );
  }
}

function PDGExpandcontent(hotelAPI, hotelDetailslength, currentIndex) {
  let specialities =
    hotelAPI.hotelAPI &&
    hotelAPI.hotelAPI.specialities &&
    hotelAPI.hotelAPI.specialities.map((data, i) => {
      return (
        <li>
          <i className={data.specialityIcon} /> {data.specialityName}{' '}
          {/* {hotelAPI.hotelAPI.specialities.length - 1 === i ? (
            <i className="vehoicon-help_outline" />
          ) : null} */}
        </li>
      );
    });
  return (
    <div className="middle-content">
      <h5>
        <span>{hotelAPI.hotelAPI.name}</span>
        <StarRating rating={hotelAPI.hotelAPI.stars} />
      </h5>
      <ul className="list-inline meta-text color-grey fade mb-0 hidden-xs">
        {specialities}
      </ul>
      <div className="clearfix fw description-txt hidden-xs">
        <p className="fine-text light color-grey mb-0 hidden-xs">
          {hotelAPI.hotelAPI.description}
          <br />
          {hotelAPI.hotelDetailslength - 1 === hotelAPI.currentIndex ? (
            <a
              className={classNames('meta-text regular', {
                hide: false
              })}
              id="showAmenities"
              href="javascript:void(0);"
              onClick={e => hotelAPI.closeActivities(e)}
            >
              View less
            </a>
          ) : null}
        </p>
        <ul className="list-unstyled fine-text light color-grey fade mb-0">
          <GetInclusionLineItem
            inclusion={hotelAPI.hotelAPI.amenityDisplayList}
          />
        </ul>
      </div>
    </div>
  );
}

export function GetInclusionLineItem(inclusion) {
  let amenitiesTake =
    inclusion && inclusion.inclusion && _.take(inclusion.inclusion, 5);
  let amenities =
    inclusion.inclusion &&
    amenitiesTake.map((inclu, review) => {
      return (
        <li>
          <i className={inclu.iconUrl} />
          {'  '}
          {'  '} {inclu.amenityName}{' '}
        </li>
      );
    });
  return amenities;
}

function PDGExpandedImages({ hotelAPI }) {
  let settings = {
    slidesToShow: 1,
    slidesToScroll: 1,
    infinite: true,
    speed: 500,
    arrows: true,
    responsive: [
      {
        settings: {
          infinite: false,
          slidesToShow: 1
        }
      }
    ]
  };

  let imageUrl = hotelAPI.imageURL;
  let imageSlider =
    hotelAPI.otherImages &&
    hotelAPI.otherImages.length &&
    hotelAPI.otherImages.map((review, i) => {
      review = i === 0 ? imageUrl : review;
      return (
        <div
          tabIndex={i}
          data-index={Date.now()}
          key={`photo-feed-${i}`}
          style={{ width: 200 }}
        >
          <figure
            style={{
              backgroundImage: `url(${review})`
            }}
          >
            <figcaption className="fig-title">
              <span className="tag-tertiary white truncate medium">
                {hotelAPI.nights} nights
              </span>
            </figcaption>
          </figure>
        </div>
      );
    });
  return (
    <div className="left-img">
      <div className="clearfix fw twin-img visible-xs">
        <figure style={{ backgroundImage: `url(${imageUrl})` }}>
          <figcaption className="fig-title">
            <span className="tag-tertiary white truncate medium">
              {' '}
              {hotelAPI.nights} nights
            </span>
          </figcaption>
        </figure>
        <figure
          style={{
            backgroundImage: `url(${
              hotelAPI.otherImages ? hotelAPI.otherImages[0] : imageUrl
            })`
          }}
        />
      </div>
      <Slider
        {...settings}
        className="pdg-slider slider-1 hidden-xs slick-dotted"
      >
        {imageSlider}
      </Slider>
    </div>
  );
}
