import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';
import { hideChatIconOnMobile, isFaqMobile } from '../../helpers/utilsHelper';

export default class PDGTabSorting extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeIndex: 0
    };
    this.clickDeals = this.clickDeals.bind(this);
  }

  clickDeals(value, index) {
    let ele = document.documentElement;
    if (ele && ele.scrollTop > 170) {
      ele.scrollTo({
        top: isFaqMobile() ? 0 : 191,
        left: 0,
        behavior: 'smooth'
      });
    }
    this.setState({ activeIndex: index });
    this.props.clickingTabs(value);
  }

  render() {
    let { sortingOptions } = this.props;
    let loopingLi =
      sortingOptions &&
      sortingOptions.map((details, index) => {
        return (
          <li
            className={classNames({
              active: this.state.activeIndex === details.keyIndex
            })}
            value={details.Value}
            onClick={e => this.clickDeals(details.value, details.keyIndex)}
          >
            {' '}
            {details.Text}{' '}
          </li>
        );
      });
    return (
      // PDG tabs
      <div className="clearfix tab-links-container tablinks-sort-filter">
        <div className="clearfix tab-holder">
          <ul className="pull-left list-unstyled tab-links">{loopingLi}</ul>
        </div>
      </div>
    );
  }
}
