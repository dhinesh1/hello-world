import React, { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';
import classNames from 'classnames';
import _ from 'lodash';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  getThemes,
  setInterestIds,
  setThemeNames,
  createItinerary,
  setThemeIds
} from '../../actions/actions_app';

import InterestCard from '../../common_components/pdg/InterestCard';
import StepText from '../../common_components/pdg/StepText';
import PDGTitleSection from '../../common_components/pdg/PDGTitleSection';
import PDGQuestionText from '../../common_components/pdg/PDGQuestionText';
import ActiveStageIndicator from '../../common_components/pdg/ActiveStageIndicator';
import { fixPDGHeader } from '../../helpers/utilsHelper';
import { trackEvent, EVENT_PDG_THEMES_SELECTED, EVENT_PDG_CHOOSE_CITIES } from '../../helpers/ML/EventsTracker';

class PDGInterestSelection extends Component {
  constructor(props) {
    super(props);
    let pdgSelections = props.pdgSelections || {};
    this.state = {
      noOfActives: 3,
      show: false,
      showed: false,
      showBottomOptions: false,
      selectedThemeIds: pdgSelections.themeIds || [],
      isLoading: false
    };
    this.updateInterestSelect = this.updateInterestSelect.bind(this);
    this.getAllInterestIDs = this.getAllInterestIDs.bind(this);
    this.onThemeSelectChange = this.onThemeSelectChange.bind(this);
    this.getItinerestIdsByThemeIds = this.getItinerestIdsByThemeIds.bind(this);
    this.showBottomOptionsButton = this.showBottomOptionsButton.bind(this);
    this.hideBottomOptionsButton = this.hideBottomOptionsButton.bind(this);
    this.getThemeNamesByIds = this.getThemeNamesByIds.bind(this);
    this.createPytItinerary = this.createPytItinerary.bind(this);
    this.setTextforCitySelection = this.setTextforCitySelection.bind(this);
  }

  setTextforCitySelection() {
    if (this.state.selectedThemeIds.indexOf('5') > -1) {
      return 'Awesome! Let’s roll right-away!';
    } else {
      let length = this.state.selectedThemeIds.length;
      switch (length) {
        case 1:
          return 'Oh, your choices are just about fine!';
        case 2:
          return 'Ah, that’s some quality stuff mate!';
        case 3:
          return 'Wohoo those are some great choices!';
        case 4:
          return 'Yay! Quite the explorer aren’t you?';
        default:
          return '';
      }
    }
  }

  componentDidMount() {
    this.props.actions.getThemes();

    let dW = window.innerWidth;
    if (dW > 767) {
      document.addEventListener('scroll', fixPDGHeader);
    }

    setTimeout(() => {
      this.setState({ noOfActives: 4, show: true }, () => {
        setTimeout(() => {
          this.setState({ showed: true });
        }, 600);
      });
    }, 10);
  }

  componentWillUnmount(): void {
    document.removeEventListener('scroll', fixPDGHeader);
  }

  getAllInterestIDs(categoryInterestMap) {
    return _.map(_.flatMapDeep(categoryInterestMap, 'interests'), 'id');
  }

  getItinerestIdsByThemeIds(categoryInterestMap, themeIds) {
    let interestId = [];
    themeIds.map(themeId => {
      if (themeId !== '5') {
        categoryInterestMap[parseInt(themeId, 10) - 1].interests.map(
          interest => {
            interestId.push(interest.id);
          }
        );
      } else {
        interestId = this.getAllInterestIDs(categoryInterestMap);
      }
    });

    return interestId;
  }

  getThemeNamesByIds(categoryInterestMap, themeIds) {
    return themeIds.map(themeId => {
      if (themeId !== '5') {
        return _.find(categoryInterestMap, c => {
          return c.category.id == themeId;
        }).category.name;
      } else {
        return 'A bit of everything';
      }
    });
  }

  createPytItinerary() {
    let pdgSelections = this.props.pdgSelections;
    const themes = this.props.themeNames;
    pdgSelections.buildPytItinerary = true;

    this.setState({ isLoading: true }, () => {
      this.props.actions
        .createItinerary({...pdgSelections, themes}, this.props.history)
        .then(() => {
          // this.setState({isLoading: false})
        });
    });
  }

  showBottomOptionsButton() {
    let t = this.state;
    t.showBottomOptions = true;
    this.setState(t);
  }

  hideBottomOptionsButton() {
    let t = this.state;
    t.showBottomOptions = false;
    this.setState(t);
  }

  onThemeSelectChange(e) {
    let t = this.state;

    if (e.target.checked) {
      // console.log('target checked', e.target.value);

      if (e.target.value === '5') {
        let cbarray = document.getElementsByName('interest-card-input');
        for (let i = 0; i < cbarray.length; i++) {
          cbarray[i].checked = cbarray[i].value > 4;
        }

        t.selectedThemeIds = ['5'];
      } else {
        t.selectedThemeIds.push(e.target.value);
      }
    } else {
      t.selectedThemeIds = _.pull(t.selectedThemeIds, e.target.value);
    }
    this.setState(t, () => {
      this.props.actions.setInterestIds(
        this.getItinerestIdsByThemeIds(
          this.props.categoryInterestMapping,
          this.state.selectedThemeIds
        )
      );

      let themeNames = this.getThemeNamesByIds(
        this.props.categoryInterestMapping,
        this.state.selectedThemeIds
      );
      this.props.actions.setThemeNames(themeNames);

      trackEvent(EVENT_PDG_THEMES_SELECTED, {
        themes: themeNames
      });

      this.props.actions.setThemeIds(t.selectedThemeIds);
      if (this.state.selectedThemeIds.length > 0) {
        this.showBottomOptionsButton();
      } else {
        this.hideBottomOptionsButton();
      }
    });
  }

  updateInterestSelect(theme, interests) {
    if (theme.id !== '5') {
      // const interestIds = interests.map(interest => {
      //   return interest.id;
      // });
    } else {
      this.getAllInterestIDs(this.props.categoryInterestMapping);
    }
  }

  chooseCitiesAction = () => {
    trackEvent(EVENT_PDG_CHOOSE_CITIES);
  };

  render() {
    let { noOfActives, show, showed, isLoading } = this.state;
    let props = this.props;

    let { regionObject, region } = props;
    let { searchRegion } = props.match.params;
    let containerClassNames = classNames({
      'search-container': true,
      'show-search': true,
      'bottom-options-shown': this.state.showBottomOptions
    });

    let innerStepClassName = classNames(
      'clearfix pdg-interests next-slide search-options-wrapper',
      {
        'slide-left-in': show,
        showed: showed
      }
    );

    let bottomOptionsClassNames = classNames({
      'bottom-options-bar': true,
      'text-center': true,
      'slide-up':
        this.state.showBottomOptions ||
        (props.themeNames && props.themeNames.length)
    });
    if (props.regionDetails.durationList) {
      return (
        <div className={containerClassNames}>
          <div className="search-content">
            <section className="clearfix pdg-interests">
              {/* search-field starts */}
              <section className="clearfix search-field">
                <StepText
                  params={props.match.params}
                  mainText={'NOW PLANNING'}
                  mainTextMobile={
                    regionObject
                      ? regionObject.search
                      : region
                        ? region.regionName
                        : searchRegion
                  }
                  showSentence={true}
                  pdgData={this.props.pdgSelections}
                  selectedThemes={this.props.themeNames}
                />
                <section className="clearfix search-input-container">
                  <PDGTitleSection
                    showInput={false}
                    showTitle={true}
                    title={
                      regionObject
                        ? regionObject.search
                        : region
                          ? region.regionName
                          : searchRegion
                    }
                    handleBack={() => {
                      this.props.history.goBack();
                    }}
                    handleForward={() => {
                      this.props.history.goForward();
                    }}
                    titleMobile="Preferences"
                  />
                  <ActiveStageIndicator
                    currentStepIndex={1}
                    actives={noOfActives}
                  />
                </section>
              </section>
              {/* search-field ends */}
              <section className={innerStepClassName}>
                <PDGQuestionText
                  mainQuestion={'What do you like to see and do?'}
                  subText={'Pick your best interests'}
                />
                <div className="clearfix row-eq-hgt">
                  <ThemeList
                    selectedThemeIds={this.state.selectedThemeIds}
                    updateInterestSelect={this.updateInterestSelect}
                    themes={this.props.categoryInterestMapping}
                    onThemeSelectChange={this.onThemeSelectChange}
                    selectedThemes={props.themeNames}
                  />
                </div>
              </section>
            </section>
          </div>

          <div className={bottomOptionsClassNames}>
            <section className="bottom-options-content">
              <div className="clearfix hidden-xs sm-text">
                {this.props.match.params.searchRegion !== 'eur' &&
                this.props.match.params.searchRegion !== 'sin' &&
                this.props.match.params.searchRegion !== 'anz' &&
                this.props.match.params.searchRegion !== 'aus' &&
                this.props.match.params.searchRegion !== 'nz' &&
                this.props.match.params.searchRegion !== 'mar' &&
                this.props.match.params.searchRegion !== 'rou' &&
                this.props.match.params.searchRegion !== 'dxb' ? (
                  <p className="pull-left">
                    Next,{' '}
                    <Link
                      to={`${this.props.location.pathname}/interests/`}
                      className="n-tracker-choose-citiescta"
                      onClick={this.chooseCitiesAction}
                    >
                      Choose cities you'd like to visit
                    </Link>{' '}
                    or
                  </p>
                ) : null}

                {this.props.match.params.searchRegion === 'eur' ||
                this.props.match.params.searchRegion === 'aus' ||
                this.props.match.params.searchRegion === 'anz' ||
                this.props.match.params.searchRegion === 'nz' ? (
                  <div>
                    <p className="pull-left">
                      {this.setTextforCitySelection()}
                    </p>
                    <Link
                      to={`${this.props.location.pathname}/interests/`}
                      className="btn btn-primary n-tracker-choose-citiescta pull-right"
                      onClick={this.chooseCitiesAction}
                    >
                      Choose cities you'd like to visit
                    </Link>{' '}
                  </div>
                ) : (
                  <button
                    disabled={isLoading}
                    className={classNames(
                      'btn btn-primary n-tracker-getapyt-itinerarycta',
                      {
                        'pull-right':
                          this.props.match.params.searchRegion !== 'sin' &&
                          this.props.match.params.searchRegion !== 'mar' &&
                          this.props.match.params.searchRegion !== 'rou' &&
                          this.props.match.params.searchRegion !== 'dxb',
                        'progress-btn': isLoading
                      }
                    )}
                    onClick={this.createPytItinerary}
                  >
                    {isLoading ? <span className="progress-bg" /> : null}
                    {this.props.match.params.searchRegion !== 'sin' &&
                    this.props.match.params.searchRegion !== 'rou' &&
                    this.props.match.params.searchRegion !== 'mar' &&
                    this.props.match.params.searchRegion !== 'dxb' ? (
                      <span className="btn-txt">
                        Get a Pickyourtrail itinerary
                      </span>
                    ) : (
                      <span className={'btn-txt'}>
                        View your Pickyourtrail personalized<span className="dim">
                          ™
                        </span>{' '}
                        itinerary
                      </span>
                    )}
                  </button>
                )}
              </div>

              {this.props.match.params.searchRegion !== 'eur' &&
              this.props.match.params.searchRegion !== 'sin' &&
              this.props.match.params.searchRegion !== 'mar' &&
              this.props.match.params.searchRegion !== 'anz' &&
              this.props.match.params.searchRegion !== 'aus' &&
              this.props.match.params.searchRegion !== 'nz' &&
              this.props.match.params.searchRegion !== 'rou' &&
              this.props.match.params.searchRegion !== 'dxb' ? (
                <div className="clearfix visible-xs xs-btns">
                  <div className="btn-col pull-left">
                    <Link
                      to={`${this.props.location.pathname}/interests/`}
                      className="btn btn-light btn-block n-tracker-mbl-choosecitiescta"
                      onClick={this.chooseCitiesAction}
                    >
                      Choose cities
                    </Link>
                  </div>
                  <div className="btn-col pull-right">
                    <button
                      className="btn btn-primary btn-block n-tracker-mbl-builditinerarycta"
                      onClick={this.createPytItinerary}
                    >
                      Build itinerary
                    </button>
                  </div>
                </div>
              ) : this.props.match.params.searchRegion === 'eur' ? (
                <div className="clearfix visible-xs xs-btns">
                  <Link
                    to={`${this.props.location.pathname}/interests/`}
                    className="btn btn-primary btn-block n-tracker-mbl-choosecitiescta"
                    onClick={this.chooseCitiesAction}
                  >
                    Choose cities
                  </Link>
                </div>
              ) : (
                <div className="clearfix visible-xs xs-btns">
                  <button
                    className="btn btn-primary btn-block n-tracker-mbl-builditinerarycta"
                    onClick={this.createPytItinerary}
                  >
                    Get a Pickyourtrail<span className="dim">™</span> itinerary
                  </button>
                </div>
              )}
            </section>
          </div>
        </div>
      );
    } else {
      return <Redirect to={`..`} />;
    }
  }
}

function mapStateToProps(state) {
  return {
    regionDetails: {
      durationList: state.app.regionDetails
    },
    categoryInterestMapping: state.app.categoryInterestMapping,
    pdgSelections: state.app.pdgSelections,
    themeNames: state.app.themeNames,
    region: state.app.regionDetails,
    regionObject: state.app.regionObject
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getThemes: bindActionCreators(getThemes, dispatch),
      setInterestIds: bindActionCreators(setInterestIds, dispatch),
      setThemeNames: bindActionCreators(setThemeNames, dispatch),
      createItinerary: bindActionCreators(createItinerary, dispatch),
      setThemeIds: bindActionCreators(setThemeIds, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(
  PDGInterestSelection
);

function ThemeList({
  themes,
  updateInterestSelect,
  onThemeSelectChange,
  selectedThemeIds,
  selectedThemes
}) {
  // let themes_4 = themes && themes.length > 4 ? _.dropRight(themes, 2) : themes;
  let themes_4 = _.dropRight(themes, 0);

  let a_bit_of_everything = {
    category: { id: 5, name: 'A bit of everything' },
    interests: []
  };
  let isChecked;
  let isBitOfEverything =
    selectedThemes && selectedThemes[0] === 'A bit of everything';
  const t = themes_4.map((theme, i) => {
    isChecked = (selectedThemes || []).some(value => {
      return value === theme.category.name;
    });
    return (
      <InterestCard
        onThemeSelectChange={onThemeSelectChange}
        updateInterestSelect={updateInterestSelect}
        disabled={_.includes(selectedThemeIds, '5') || isBitOfEverything}
        {...theme}
        i={i}
        key={i}
        checked={isChecked}
      />
    );
  });
  return (
    <div className="clearfix row-eq-hgt n-tracker-totalseeanddo">
      {t}
      <InterestCard
        onThemeSelectChange={onThemeSelectChange}
        updateInterestSelect={updateInterestSelect}
        {...a_bit_of_everything}
        i={5}
        key={5}
        checked={isBitOfEverything}
      />
    </div>
  );
}
