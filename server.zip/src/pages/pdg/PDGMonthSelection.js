import React, { Component } from 'react';
import classNames from 'classnames';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  getRegionDetails,
  setMonth,
  setRegionObject
} from '../../actions/actions_app';

import MonthCard from '../../common_components/pdg/MonthCard';
import StepText from '../../common_components/pdg/StepText';
import PDGTitleSection from '../../common_components/pdg/PDGTitleSection';
import PDGQuestionText from '../../common_components/pdg/PDGQuestionText';
import ActiveStageIndicator from '../../common_components/pdg/ActiveStageIndicator';
import { fixPDGHeader, hideChatIconOnMobile } from '../../helpers/utilsHelper';
import { trackEvent, EVENT_PDG_MONTH_SELECTED } from '../../helpers/ML/EventsTracker';

class PDGDMonthSelection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      noOfActives: 2,
      show: false,
      showed: false,
      region: null,
      monthSelected: false
    };
    this.setSelectedMonth = this.setSelectedMonth.bind(this);
  }

  componentDidMount() {
    hideChatIconOnMobile();

    let dW = window.innerWidth;
    if (dW > 767) {
      document.addEventListener('scroll', fixPDGHeader);
    }

    let { match } = this.props;
    let { searchRegion } = match.params;
    this.props.actions.getRegionDetails(searchRegion);

    let selectedCity = localStorage.getItem('selected_city');
    if (selectedCity) {
      this.props.actions.setRegionObject(JSON.parse(selectedCity));
    }

    setTimeout(() => {
      this.setState({ noOfActives: 2, show: true }, () => {
        setTimeout(() => {
          this.setState({ showed: true });
        }, 600);
      });
    }, 10);
  }

  componentWillUnmount(): void {
    document.removeEventListener('scroll', fixPDGHeader);
  }

  setSelectedMonth(month, is_our_pick=false) {
    this.setState({ monthSelected: month });
    this.props.actions.setMonth(month);

    let regionCode =
      this.props.match &&
      this.props.match.params &&
      this.props.match.params.searchRegion;

    trackEvent(EVENT_PDG_MONTH_SELECTED, { month, is_our_pick });
    this.props.history.push(`/customize/${regionCode}/month`);
  }

  render() {
    let { noOfActives, show, showed } = this.state;
    let props = this.props;

    let { regionObject, region } = props;
    let { searchRegion } = props.match.params;
    let containerClassNames = classNames({
      'search-container': true,
      'show-search': true
    });

    let innerStepClassName = classNames(
      'clearfix pdg-weather next-slide search-options-wrapper',
      {
        'slide-left-in': show,
        showed: showed
      }
    );

    let { durationList } = props.regionDetails;
    let isPreferredMonth = props.pdgSelections.preferredMonth;
    return (
      <div className={containerClassNames}>
        <div className="search-content">
          {/* search-field starts */}
          <section className="clearfix search-field">
            <StepText
              params={props.match.params}
              mainText={
                isPreferredMonth ? 'NOW PLANNING' : 'PLAN A VACATION TO'
              }
              pdgData={this.props.pdgSelections}
              mainTextMobile={
                regionObject
                  ? regionObject.search
                  : region
                    ? region.regionName
                    : searchRegion
              }
              showSentence={isPreferredMonth ? true : false}
              selectedThemes={this.props.themeNames}
            />
            <section className="clearfix search-input-container">
              <PDGTitleSection
                showInput={false}
                showTitle={true}
                isForwardAvailable={this.props.pdgSelections.preferredMonth}
                handleBack={() => {
                  this.props.history.goBack();
                }}
                handleForward={() => {
                  this.props.history.goForward();
                }}
                title={
                  regionObject
                    ? regionObject.search
                    : region
                      ? region.regionName
                      : searchRegion
                }
                titleMobile={`Time of travel`}
              />
              <ActiveStageIndicator
                currentStepIndex={0}
                actives={noOfActives}
              />
            </section>
          </section>
          {/* search-field ends */}
          <section className={innerStepClassName}>
            <PDGQuestionText
              mainQuestion={'When do you want to explore?'}
              subText={'Pick your suitable month for travelling'}
            />
            {durationList ? (
              <MonthCardList
                months={durationList.weatherInfo}
                setSelectedMonth={this.setSelectedMonth}
                selectedMonth={props.pdgSelections.preferredMonth}
              />
            ) : null}
          </section>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    regionDetails: {
      durationList: state.app.regionDetails
    },
    pdgSelections: state.app.pdgSelections,
    themeNames: state.app.themeNames,
    region: state.app.regionDetails,
    regionObject: state.app.regionObject
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      setRegionObject: bindActionCreators(setRegionObject, dispatch),
      getRegionDetails: bindActionCreators(getRegionDetails, dispatch),
      setMonth: bindActionCreators(setMonth, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(PDGDMonthSelection);

function MonthCardList({ months, setSelectedMonth, selectedMonth }) {
  const m =
    months &&
    months.map((month, i) => {
      return (
        <MonthCard
          setSelectedMonth={setSelectedMonth}
          {...month}
          i={i + 1}
          key={i}
          checked={month.month === selectedMonth}
        />
      );
    });

  return (
    <div className="clearfix row-eq-hgt n-tracker-totalplantotravel">{m}</div>
  );
}
