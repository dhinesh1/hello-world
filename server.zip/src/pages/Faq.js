import React, { Component } from 'react';
import Collapsible from 'react-collapsible';
import Scroll from 'react-scroll';
import Sticky from 'react-stickynode';
import { isFaqMobile, FaqsSec } from '../helpers/utilsHelper';
import { Helmet } from 'react-helmet';
import { trackPage, PAGE_FAQ } from '../helpers/ML/EventsTracker';
const Element = Scroll.Element;
const Link = Scroll.Link;
export default class Faq extends Component {
  constructor(props) {
    super(props);

    this.state = {
      expanded: 0
    };
    this.questionIndex = '';
    this.onTriggerClick = this.onTriggerClick.bind(this);
  }

  componentDidMount() {
    let deskTopLinks = document.querySelectorAll('.faq-tabs li');
    deskTopLinks.forEach(function(elem) {
      elem.addEventListener('click', function(event) {
        // this function does stuff

        // let scrollPos =
        //   document.querySelector(this.getAttribute('href')).offsetTop - 149;
        // scrollToTop(scrollPos, 500);

        // var scrollPos = $('body > .main-container').find($(this).attr('href')).offset().top - (offsetHeight - 1);
        // $('body,html').animate({
        //   scrollTop: scrollPos
        // }, 500, function () {
        // });

        event.preventDefault();
      });
    });
  }

  onQuestionClick = (e) => {
    if (this.questionIndex === '' || e.target.innerText !== this.questionIndex) {
      this.questionIndex = e.target.innerText;
      trackPage(PAGE_FAQ, {
        question_clicked: e.target.innerText
      })
    }
  }

  onTriggerClick(index) {
    if (this.state.expanded === index) {
      index = '';
    }

    this.setState({ expanded: index });
  }

  onTabClick = (e) => {
    trackPage(PAGE_FAQ, {
      tab_clicked: e.target.innerText
    })
  }

  render() {
    let { expanded } = this.state;

    return (
      <section className="static-pages static-faq">
        <Helmet>
          <title>
            FAQ on Travel, Visa, Holiday & Honeymoon Packages | PickYourtrail
          </title>
          <meta
            name={'description'}
            content={
              'Pickyourtrail FAQ section has answers to all your travel related queries. ✓Tailor-Made Luxury Holiday ✓Discover Great Deals ✓Book in Just One Click ✓100% Flexibility'
            }
          />
        </Helmet>

        <div id="faqheader" className="static-header">
          <h1>Frequently asked questions</h1>
        </div>

        <div className="container">
          <div className="row">
            <div className="col-md-10 col-md-offset-1">
              <div className="static-content">
                <Sticky
                  enabled={!isFaqMobile()}
                  top={72}
                  bottomBoundary="#FaqContent"
                >
                  <ul className="clearfix list-unstyled bg-white tab-links faqtab-links hidden-xs">
                    <li>
                      <Link
                        to={FaqsSec.Faqs}
                        activeClass="active"
                        spy={true}
                        smooth={true}
                        duration={500}
                        offset={-144}
                        className=""
                        onClick={this.onTabClick}
                      >
                        FAQs
                      </Link>
                    </li>
                    <li>
                      <Link
                        to={FaqsSec.Changestoitinerary}
                        activeClass="active"
                        spy={true}
                        smooth={true}
                        duration={500}
                        offset={-144}
                        className=""
                        onClick={this.onTabClick}
                      >
                        Changes to itinerary
                      </Link>
                    </li>
                    <li>
                      <Link
                        to={FaqsSec.Beforebooking}
                        activeClass="active"
                        spy={true}
                        smooth={true}
                        duration={500}
                        offset={-144}
                        className=""
                        onClick={this.onTabClick}
                      >
                        Before booking
                      </Link>
                    </li>
                    <li>
                      <Link
                        to={FaqsSec.Afterbooking}
                        activeClass="active"
                        spy={true}
                        smooth={true}
                        duration={500}
                        offset={-144}
                        className=""
                        onClick={this.onTabClick}
                      >
                        After booking
                      </Link>
                    </li>
                    <li>
                      <Link
                        to={FaqsSec.Duringtravel}
                        activeClass="active"
                        spy={true}
                        smooth={true}
                        duration={500}
                        offset={-144}
                        className=""
                        onClick={this.onTabClick}
                      >
                        During travel
                      </Link>
                    </li>
                  </ul>
                </Sticky>
                <div className="row" id="FaqContent">
                  <div className="col-md-12">
                    <Element name={FaqsSec.Faqs}>
                      {/* FAQs start  */}
                      <div className="panel-group accordions">
                        <h3>FAQs</h3>

                        <FaqAccordion
                          index={0}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              How are you different from other players?
                            </h4>
                          }
                        >
                          <p>
                            <strong>No Pre-Packaged Tours</strong> - We are the
                            world’s first ever platform to let travellers build,
                            customize and edit their itineraries, basis their
                            interests.
                          </p>

                          <p>
                            <strong>Quality Supply</strong> - We believe in
                            genuineness, in building vacations true to our
                            travellers’ hearts. Why don’t you check out our
                            Facebook page? Thanks to our 9 point check before
                            onboarding partners, we have 850+ 5 star reviews
                            from genuine travellers like you.
                          </p>

                          <p>
                            <strong>Mobile Concierge</strong> - The only company
                            in India to provide real time chat support - we will
                            be there for you throughout your vacation. Want to
                            upgrade your room, plan a surprise or change plans?
                            Ping us and we will help you out!
                          </p>
                        </FaqAccordion>
                        <FaqAccordion
                          index={1}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Local travel agents take 24-48 hours to give me a
                              customized itinerary. How do you do it so fast?
                              And, can I trust your pricing?
                            </h4>
                          }
                        >
                          <p>
                            Our proprietary routing algorithm was built on our
                            learning's from over 1000+ trails we have hand
                            crafted. The algorithm not only helps you with
                            activity suggestions based on your interests, it
                            also works to combine your cities - keeping in mind
                            both travel times and cost of travel across all
                            available modes of transport.
                          </p>

                          <p>
                            Our machine learning algorithm ensures that each
                            itinerary created on the platform helps refine our
                            results and gives travellers the right itinerary.
                            Our integrations with best in class partners ensures
                            that you will be able to see your total trip cost in
                            less than 50 seconds flat.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={2}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Why should I update cost frequently after I have
                              built my itinerary and costed it?{' '}
                            </h4>
                          }
                        >
                          <p>
                            We partner with the world’s top tech companies to
                            get you real time pricing. Unlike other places where
                            they have "hotel a or similar" - at Pickyourtrail -
                            what you see is what you get. As millions of
                            travellers like you are looking to head out, and
                            hence, the hotel and flight availability changes by
                            the minute. To ensure that you get the best possible
                            room, we need to continuously update the costing.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={3}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              You are a young company, how do I trust you with
                              my yearly break?
                            </h4>
                          }
                        >
                          <p>
                            We are India’s top rated personalized vacations
                            company on Facebook. We have created 20 years worth
                            happiness through our trails. And 95% of our
                            travellers have rated us 5 star! We have been
                            featured in the Business Line, Economic Times and
                            Yourstory to name a few publications! We are one of
                            the two Indian startups to be a part of the Amadeus
                            Next program! We could go on, but we would rather
                            you read testimonials from genuine travellers like
                            you{' '}
                            <a href="/testimonials" target="_blank">
                              here
                            </a>. Give us a try. We assure you that you will not
                            only enjoy the Pickyourtrail way of traveling, but
                            keep wanting more of it!
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={4}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What is your price match guarantee and how does it
                              apply?
                            </h4>
                          }
                        >
                          <p>
                            We work with over 145 suppliers from all over the
                            world to get you the best possible pricing. In case
                            you get a cheaper quote for the same set of
                            inclusions, we will match the quote you find and
                            also waive our planning and concierge fee for you!
                            And that’s how confident we are about our pricing.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={5}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What is the taxes and fees component?
                            </h4>
                          }
                        >
                          <p>
                            The taxes and fees component takes into account all
                            local and international government service taxes and
                            our booking and concierge fees. Our fees range
                            between Rs. 1000 - Rs. 5000 per person depending on
                            the complexity of the itinerary and duration. For
                            instance,in a few countries in Europe and Asia, the
                            municipal taxes (charged by the mayor of the city)
                            will need to be paid during check-out. This is not
                            included. They range between Rs. 50 - Rs. 100 per
                            person per night.
                          </p>
                        </FaqAccordion>
                      </div>
                    </Element>
                  </div>

                  <div className="col-md-12">
                    <Element name={FaqsSec.Changestoitinerary}>
                      {/* FAQs start  */}
                      <div className="panel-group accordions" id="accordion2">
                        <h3>Changes to itinerary</h3>

                        <FaqAccordion
                          index={6}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What if I want to make some changes to my
                              personalized itinerary?
                            </h4>
                          }
                        >
                          <p>
                            Raison d'Être. That's why we built the product. Go
                            ahead, and click on{' '}
                            <button className="btn btn-xs btn-primary cursor-default">
                              Change
                            </button>
                            button next to hotels, flights, trains, transfer
                            modes and voila you can change them then and there.
                            We believe we have most used cases covered, let us
                            know if there is something else that we could add to
                            make your experience awesome-er. Drop us a line at{' '}
                            <a href="mailto:idea@pickyourtrail.com">
                              idea@pickyourtrail.com
                            </a>.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={7}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              How do I change city?
                            </h4>
                          }
                        >
                          <p>
                            Ahh, looks like we have an involved traveler. Fret
                            not. We have you covered. Do you spot the{' '}
                            <strong>edit option</strong> next to the cities?
                            Click on it. You would be surprised by what a click
                            of button can do! You can change,replace or add a
                            city :)
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={8}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              I want to spend more nights in a city and reduce
                              nights from other city(ies). Is it possible?
                            </h4>
                          }
                        >
                          <p>
                            Your wish is our command! Look out for our pencil
                            icon <i className="vehoicon-mode_edit" /> as you
                            hover over days, and click on it to add / remove
                            days to your heart’s content.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={9}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Can I change the itinerary on mobile also?
                            </h4>
                          }
                        >
                          <p>
                            Yes, you can! SmartPhones are amazing and we love
                            them too. So go ahead, click on the enable editing
                            button, and change to your hearts content. By the
                            way, you can also get a real time cost on mobile!
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={10}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              I want a quote on my email, how do I do that?
                            </h4>
                          }
                        >
                          <p>
                            Bingo, do you see the{' '}
                            <img
                              src="https://pyt-images.imgix.net/images/misc/faq-quote.png"
                              width="100px"
                            />{' '}
                            button? Hit that, fill in your email, and voila!
                            Your quote has reached your inbox! Share it with
                            your fiance, family and let us know if there is
                            something that we can do to help you book :)
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={11}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Is there a way to change my hotel room?
                            </h4>
                          }
                        >
                          <p>
                            Click on room details under the hotel listed. You
                            will be able to view the room that is pre-selected.
                            To change the room click on{' '}
                            <button className="btn btn-xs btn-primary cursor-default">
                              Change room
                            </button>{' '}
                            option which pops up on clicking room details.
                            Easy-peasy!
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={12}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              I don’t see the city I want to visit on your
                              website. What do I do?
                            </h4>
                          }
                        >
                          <p>
                            Shucks. That’s bad. Maybe you are indeed one in a
                            million. Fret not, you should be able to drop us a
                            postcard from your product. If not - go ahead and
                            send a mail to{' '}
                            <a href="mailto:planners@pickyourtrail.com">
                              planners@pickyourtrail.com
                            </a>{' '}
                            and we will reach out to you!
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={13}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              I want to take a flight instead of a train. Is
                              that possible?
                            </h4>
                          }
                        >
                          <p>
                            You can easily change your mode of transfer by
                            clicking on the pencil icon{' '}
                            <i className="vehoicon-mode_edit" /> between cities.
                            You can swap between train, air and other available
                            modes of transport.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={14}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What if the activity I want is not available with
                              you?
                            </h4>
                          }
                        >
                          <p>
                            Woah, you got us there. This is a rare case. Why
                            don’t you drop us an email or chat with us to let us
                            know? We will add that in a jiffy for you! And, by
                            the way - you get a 10% discount on that activity.
                            Finders keepers and all, you know! :)
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={15}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              I want to change the time of my activity, is that
                              possible?
                            </h4>
                          }
                        >
                          <p>
                            We try and slot activities in the best possible time
                            slot. We take into consideration facts like the
                            historical queue length, if it’s a view-point, what
                            the best time to be there is, type of activity and
                            other parameters. If you still want to go ahead and
                            change the activity you can do so by removing it
                            first from that time slot, and adding it in your
                            desired time-slot.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={16}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              I have a child with me, how do I know which
                              activities are suitable for him / her?
                            </h4>
                          }
                        >
                          <p>
                            We are glad you asked! There is a child-friendly
                            filter on activities, too. We recommend you use it
                            to find the relevant, best possible activities for
                            him / her.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={17}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What is the customer rating next to hotels?
                            </h4>
                          }
                        >
                          <p>
                            It’s a mix of both online and our customers’ reviews
                            of hotels. The idea is to help you narrow down on a
                            hotel of your choice quickly. While you are at it,
                            go ahead and toggle with the breakfast and free wifi
                            filters.
                          </p>
                        </FaqAccordion>
                      </div>
                    </Element>
                  </div>

                  <div className="col-md-12">
                    <Element name={FaqsSec.Beforebooking}>
                      {/* FAQs start  */}
                      <div className="panel-group accordions" id="accordion3">
                        <h3>Before booking</h3>

                        <FaqAccordion
                          index={18}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What are the documents I need to submit to
                              initiate booking?
                            </h4>
                          }
                        >
                          <p>
                            Keep your passport copies handy. Kindly ensure that
                            you type in the names only as per passport. In case
                            you don’t have a last name on your passport, kindly
                            give us a call.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={19}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              I want to check visa requirements before I confirm
                              and pay. How do I do that?
                            </h4>
                          }
                        >
                          <p>
                            We encourage you to understand all visa requirements
                            as it’s one of the most time consuming processes.
                            For a quick summary, visit our page -<a
                              target="_blank"
                              rel="noopener noreferrer"
                              href="https://visa.pickyourtrail.com"
                            >
                              visa.pickyourtrail.com
                            </a>. Do ensure that you have also cross checked
                            against the embassy website as we all know how
                            governments can change decisions overnight! :)
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={20}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What are the passport requirements for
                              international travel?
                            </h4>
                          }
                        >
                          <p>
                            Your passport needs to have a validity of 6 months
                            from the date of arrival back into the country.
                            There should have not been any observations made on
                            your passport.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={21}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Can I freeze my rates once I have finalized the
                              itinerary?
                            </h4>
                          }
                        >
                          <p>
                            Yes, you can freeze the cost by paying 50% of the
                            overall trip cost as booking confirmation fee.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={22}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Do I need to have booking confirmations for
                              initiating visa documents?
                            </h4>
                          }
                        >
                          <p>
                            Depending on the country you are visiting, you may
                            or may not need flight and hotel vouchers for your
                            visa application.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={23}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Will you be helping me with Visas as well?
                            </h4>
                          }
                        >
                          <p>
                            Yes, we will assist you with your visa documentation
                            for a fee. This is to ensure that your documentation
                            is done right and you have got all the proofs
                            required. Do keep in mind that the issuance of visa
                            is solely based on the visa assessing officer! We
                            cannot guarantee visa issuance. In the last 1000+
                            trails, only 6 customers have been denied a visa.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={24}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What happens once I have made the payment?
                            </h4>
                          }
                        >
                          <p>
                            Once you have made the payment, you will receive a
                            payment confirmation. Our backend technology will
                            initiate the booking process and we will keep you
                            posted. You will then receive a status email of all
                            your bookings within 24 hours.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={25}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What is the cancellation policy once payment is
                              done?
                            </h4>
                          }
                        >
                          <p>
                            The cancellation policy for flights, hotels, trains
                            and car rental is as per their cancellation policy.
                            For activities and transfers, the payment is
                            non-refundable if it is under 21 days of departure.
                            Our service charges are non-refundable.
                          </p>
                        </FaqAccordion>
                      </div>
                    </Element>
                  </div>

                  <div className="col-md-12">
                    <Element name={FaqsSec.Afterbooking}>
                      {/* FAQs start  */}
                      <div className="panel-group accordions" id="accordion4">
                        <h3>After booking</h3>

                        <FaqAccordion
                          index={26}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What happens if I want to change activities after
                              I have confirmed?
                            </h4>
                          }
                        >
                          <p>
                            Cancellation of any activities is based on the
                            cancellation policy stated on the voucher. If it is
                            feasible and there is availability in the new
                            activity that you want, you can go ahead and change
                            the same.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={27}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Will the prices increase after I have booked my
                              trip?
                            </h4>
                          }
                        >
                          <p>
                            This is the rarest of rare case. This generally
                            happens when multiple travellers are looking at the
                            same room. Given we cannot block rooms and air
                            tickets, there are chances that your prices may have
                            changed after you booked. In such cases, we will
                            intimate you as soon as we come to know of it and
                            also ensure that we provide you suitable options.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={28}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              I want to cancel my trip due to personal reasons,
                              but there is no cancel button. How do I go about
                              it?
                            </h4>
                          }
                        >
                          <p>
                            You would need to write us an email as we will have
                            to speak to all our partners to give you a
                            consolidated cancellation amount. It will take
                            anywhere between 48-72 hours for the same.
                          </p>
                        </FaqAccordion>
                      </div>
                    </Element>
                  </div>

                  <div className="col-md-12">
                    <Element name={FaqsSec.Duringtravel}>
                      {/* FAQs start  */}
                      <div className="panel-group accordions" id="accordion5">
                        <h3>During travel</h3>

                        <FaqAccordion
                          index={29}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              How can I get in touch with you during the
                              vacation?
                            </h4>
                          }
                        >
                          <p>
                            You can reach out to us on the dedicated support
                            platform. We are available from 7am IST to 10pm IST.
                            In times when we are not available you will be able
                            to reach either or local partners or the direct
                            activity provider mentioned in the email.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={30}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              What if one of my scheduled experience gets
                              cancelled?
                            </h4>
                          }
                        >
                          <p>
                            This is a rare event at Pickyourtrail, as we only
                            work with top 5 partners in every destination. If
                            sudden changes in weather or other such unforeseen
                            events lead to cancellation, you will be refunded
                            the amount for the experience as per the
                            cancellation policy of the experience provider.
                            Also, if there is sufficient heads up, we try and
                            give you an equally exciting option, based on your
                            interests.
                          </p>

                          <p>
                            <strong>
                              Our normal refund policy is 15 working days from
                              the date of the cancelled activity or any other
                              inclusion.
                            </strong>{' '}
                            In case there's a delay beyond this time, the team
                            will keep the customer informed.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={31}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              Who can help us with emergencies when we miss the
                              flight or lose baggage?
                            </h4>
                          }
                        >
                          <p>
                            It is always best to get in touch with the airline
                            people directly to get a quick solution. You can
                            also reach out to us through the support group or
                            call the emergency number listed in the support
                            group.
                          </p>
                        </FaqAccordion>

                        <FaqAccordion
                          index={32}
                          expanded={expanded}
                          onTriggerClick={this.onTriggerClick}
                          trigger={
                            <h4 className="panel-title" onClick={this.onQuestionClick}>
                              How do we handle emergencies when we lose our
                              passports?
                            </h4>
                          }
                        >
                          <p>
                            You can either lodge a police complaint or call up
                            the embassy to figure out a better solution.
                          </p>
                        </FaqAccordion>
                      </div>
                    </Element>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
}

const FaqAccordion = props => (
  <section className="panel panel-default">
    <Collapsible
      open={props.expanded === props.index}
      triggerTagName={'div'}
      triggerClassName={'panel-heading accordion-toggle'}
      triggerOpenedClassName={'panel-heading accordion-toggle'}
      contentInnerClassName={'panel-body'}
      handleTriggerClick={() => props.onTriggerClick(props.index)}
      trigger={props.trigger}
    >
      {props.children}
    </Collapsible>
  </section>
);
