import React, { Component } from 'react';
import { Helmet } from 'react-helmet';

export default class CancellationPolicy extends Component {
  render() {
    return (
      <section className="static-pages">
        <Helmet>
          <title>Cancellation Policy | Pickyourtrail</title>
          <meta
            name={'description'}
            content={
              'We understand your travel plans may change. With that in mind, Pickyourtrail.com has a very simple cancellation policy.'
            }
          />
        </Helmet>

        <div className="static-header">
          <h1>Cancellation Policy</h1>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-md-10 col-md-offset-1">
              <div className="static-content">
                <p className="dim vmargin-large">
                  We understand your travel plans may change. With that in mind,
                  Pickyourtrail.com (parent company Travel Troops Global Private
                  Limited) has a very simple cancellation policy: regardless of
                  whether you made your reservation online, using our mobile
                  applications, or via our travel consultation, we have a
                  standard cancellation policy as below.
                </p>
                <h3>Flights</h3>
                <p>
                  The cancellation policy of Flights is determined by the
                  Airline that you have booked with and our cancellation policy
                  will mirror the same.
                </p>
                <h3>Hotels</h3>
                <p>
                  All hotel cancellations are basis hotel cancellation policy
                  mentioned in the vouchers. Any refunds or cancellations are
                  subject to this policy.
                </p>
                <h3>Trains</h3>
                <p>
                  The cancellation policy of Trains are determined by the Train
                  company that you have booked with and our cancellation policy
                  will mirror the same.
                </p>
                <h3>Activities and Transfers</h3>
                <p>
                  All activities and transfers cancellations are basis their own
                  cancellation policy mentioned in the vouchers/itinerary PDF.
                  Any refunds or cancellations are subject to their policy.
                </p>
                <h3>Visa, Insurance, Planning fees and other taxes</h3>
                <p>
                  No refund shall be provided for the same upon cancellation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
}
