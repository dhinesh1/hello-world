import React, { Component, Fragment } from 'react';
import Button from '../common_components/basic_components/Button';
import Password from '../common_components/basic_components/Password';
import MobileNumber from '../common_components/basic_components/MobileNumber';
import Text from '../common_components/basic_components/Text';
import axios from 'axios/index';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import classNames from 'classnames';
import RenderCostingPanel from './itinerary/components/get_cost_components/costing_leftside_panel';
import _ from 'lodash';
import { AppConfig } from '../app-config';
import { getUserDetails, showLoginForm, getCost } from '../actions/actions_app';
import { login, getOTP, loginWithOTP } from '../actions/actions_login_app';
import {
  isFaqMobile,
  onceModalOpened,
  is_server,
  animate,
  checkIndexOf,
  getRandomValue,
  isValidName,
  getImgIXUrl,
  isValidMobileNumber as isValidNumber,
  getPackageKeyFromPathname,
  isEmptyObject
} from '../helpers/utilsHelper';
import { triggerSimpleAjax } from '../helpers/httpHelper';
import Swipe from 'react-easy-swipe';
import { withLastLocation } from 'react-router-last-location';

import { emailValidation } from './validations';
import { getLeadSource } from '../helpers/leadSourceHelper';
import { USER_SIGNUP, USER_SIGNUP_GETCOST } from '../helpers/ML/EventsTracker';

import { getGetCostingHelperRoute } from '../helpers/routesHelper';
import {
  itineraryModalsRouteHelper,
  SIGNUP,
  LOGIN
} from '../helpers/routesHelper';

const API_URL = AppConfig.api_url;

/**
 * Login component
 */
class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      countryPhoneCode: '+91',
      mobileNumber: '',
      password: '',
      otp: '',
      email: '',
      userName: '',
      isKilled: true,
      showModal: false,
      profileNotFound: false,
      forgetPasswordResponse: '',
      OTPResponseId: '',
      headerText: props.headerText || 'Welcome back!',
      subText: props.subText || '',
      isLoading: false,
      loginError: false,
      loginErrorResponse: '',
      loginImages: [],
      loginQuotes: [],
      loginImage: '',
      loginQuote: '',
      validationState: {
        mobileNumberInvalid: false,
        otpInvalid: false,
        passwordInvalid: false
      },
      signUpValidation: {
        emailResponse: '',
        mobileNumberResponse: '',
        userNameResponse: ''
      },
      actionType: props.actionType || 'LOGIN'
    };
    this.canValidate = false;
    /**<-------------Internal Functions------------------> */
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.clearErrorValidation = this.clearErrorValidation.bind(this);
    this.triggerValidation = this.triggerValidation.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.setActionProperties = this.setActionProperties.bind(this);
    this.onSwipeMove = this.onSwipeMove.bind(this);
    this.onSwipeEnd = this.onSwipeEnd.bind(this);
    this.getCostingConfiguration = this.getCostingConfiguration.bind(this);
    this.setSignUp = this.setSignUp.bind(this);

    /**<-------------Internal API Actions------------------> */
    this.getOTPClickHandler = this.getOTPClickHandler.bind(this);
    this.triggerLogin = this.triggerLogin.bind(this);
    this.triggerSignup = this.triggerSignup.bind(this);

    /**<-------------Internal Component Instance------------------> */
    this.mobileInstance = React.createRef();
    this.passwordInstance = React.createRef();
    this.nameInstance = React.createRef();
    this.emailInstance = React.createRef();
    this.otpInstance = React.createRef();

    this.isItineraryView = checkIndexOf(
      this.props.location.pathname,
      ['/view/', '/inclusions/']
    );
  }

  /**
   * Gather the login image and testimonial from server
   */
  componentDidMount() {
    let { app, history, location } = this.props;
    let { isItineraryPage } = this.state;

    if (this.state.actionType === 'SIGNUP') {
      this.getSignupCall();
    } else {
      this.callLoginImageRequest();
    }

    if (location.state && location.state.mobile_number) {
      let state = this.state;
      state.mobileNumber = location.state.mobile_number;
      if (location.state.errorMessage) {
        state.headerText = 'Account exists';
        state.subText = location.state.errorMessage;
      } else {
        state.headerText = 'Welcome back!';
        state.subText =
          'Looks like you have an account created with this mobile number. Please Login to calculate the trip cost.';
      }
      this.setState(state);
      this.openModal(isItineraryPage);
    } else if (
      !checkIndexOf(location.pathname, ['/signup', '/login'], -1) &&
      !Object.keys(app.getCostUpdatedObject).length
    ) {
      let pathName = location.pathname;

      pathName.replace('/login', '');
      pathName.replace('/signup', '');

      history.replace(pathName);
    } else {
      this.openModal(isItineraryPage);
    }

    document.addEventListener('keyup', this.handleKeyUp);
  }

  callLoginImageRequest = () => {
    /** this is worked for fetch only */
    let loginBannerURL =
      'https://s3.ap-south-1.amazonaws.com/oceanjar-new/ui/json_static/login.json';
    fetch(loginBannerURL)
      .then(response => response.json())
      .then(resData => {
        let images = resData.data.images;
        let quotes = resData.data.quotes;
        let imageIndex = getRandomValue(0, images.length - 1);
        let quoteIndex = getRandomValue(0, quotes.length - 1);
        this.setState(
          {
            loginImages: images,
            loginImage: images[imageIndex],
            loginQuotes: quotes,
            loginQuote: quotes[quoteIndex],
            isKilled: false
          },
          () => {
            this.openModal();
          }
        );
      });
  };

  getSignupCall = () => {
    let url = `${API_URL}testimonial/getForSignUp`;
    axios
      .get(url)
      .then(response => {
        if (response.data.status === 'SUCCESS') {
          let {
            coverImage,
            shortestReview = '',
            destination = '',
            ttype = '',
            fName = ''
          } =
            response.data.data || {}; // placing "|| {}" here - UI should be rendered even there is no response 'data' from server.
          this.setState({
            isKilled: false,
            loginImage: getImgIXUrl(
              coverImage,
              'w=520&h=1200&fit=facearea&facepad=10&auto=enhance'
            ),
            tripText: shortestReview,
            place: ttype + ' TRIP TO ' + destination,
            fName: fName
          });
        }
      })
      .catch(e => {
        console.error(e);
      });
  };

  /**
   * Unbind the key up event performed hered
   */
  componentWillUnmount() {
    document.body.className = document.body.className.replace(
      'scroll-locked',
      ''
    );
    let backDropEle = document.querySelector('.modal-backdrop');
    backDropEle.className = backDropEle.className.replace('in', '');
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  /**
   * Error response has been assigned here
   * @param {*} nextProps
   */
  componentWillReceiveProps(nextProps) {
    let app = nextProps.app;
    if (this.state.actionType === 'SIGNUP' && !this.state.fName) {
      this.getSignupCall();
    }
    if (app && app.action) {
      let state = this.state;
      switch (app.action) {
        case 'LOGIN_ERROR':
          state.loginError = true;
          state.loginErrorResponse = app.response;
          break;
        case 'GET_OTP_FAILED':
          switch (app.response.status) {
            case 'VERIFICATIONFAILED':
              state.isLoading = false;
              state.profileNotFound = true;
              state.forgetPasswordResponse = app.response.statusMessage;
              break;
          }
          break;
        case 'GET_OTP_SUCCESS':
          this.canValidate = false;
          state.OTPResponseId = app.response.id;
          state.isLoading = false;
          if (state.actionType === 'OTP') {
            state.actionType = 'FORGOT';
            state.headerText = 'Hey there!';
            state.subText = 'Enter the OTP for validation';
          }
          break;
      }
      this.setState({ ...state });
    }
  }

  /**
   * This method used to perform animation
   * @param {*} isItineraryView
   */
  openModal(isItineraryView = false) {
    this.setState(
      { isKilled: !this.state.loginImage || false, isItineraryView },
      () => {
        setTimeout(() => {
          this.setState({ showModal: true });
        }, 10);
        onceModalOpened();
      }
    );
  }
  /**
   * Navigate the respected URL based on request
   */
  navigateExactPath = path => {
    const { lastLocation, history, match, app, location, packages, hotelDetails } = this.props;
    const {itineraryDetails = {}} = app.itineraryInfo;
    const {itinerary} = itineraryDetails;

    if (
      lastLocation &&
      (checkIndexOf(lastLocation.pathname, ['get-cost']) ||
        match.params.itineraryId)
    ) {
      let loc = itineraryModalsRouteHelper({
        itineraryId: match.params.itineraryId,
        regionCode: match.params.searchRegion,
        target: path === "signup" ? SIGNUP : LOGIN,
        location
      });

      if(hotelDetails && hotelDetails.content || (itinerary && itinerary.campaign) || packages && packages.content ){
        loc = getGetCostingHelperRoute({
          pathname: history.location.pathname,
          itineraryId: match.params.itineraryId,
          target: path
        });
      }
      history.replace(loc);
    } else {
      history.replace(`/${path}`);
    }
  };

  alreadyAccountHandler = e => {
    e.preventDefault();
    this.navigateExactPath('login');
  };

  setSignUp() {
    this.navigateExactPath('signup');
  }

  /**
   * This function used to close the modal and navigate to respected page once closed
   */
  closeModal() {
    let {
      history,
      lastLocation,
      match,
      location,
      hotelDetails,
      packages,
      app
    } = this.props;
    let pathName = (lastLocation || {}).pathname || '';

    this.setState({ showModal: false }, () => {
      setTimeout(() => {
        if (
          checkIndexOf(pathName, ['your-vacations', 'yourtrips', 'account'])
        ) {
          window.location = '/';
        } else if (match.params.itineraryId) {
          const campaign = ((hotelDetails && hotelDetails.content) || (packages && packages.content) || 
          (app.itineraryInfo && app.itineraryInfo.campaignDetail && app.itineraryInfo.campaignItineraryId));
          if(campaign){
            const pathName = getPackageKeyFromPathname(location.pathname);

            history.push("/"+pathName);
          }else{
            history.push(
              itineraryModalsRouteHelper({
                itineraryId: match.params.itineraryId,
                regionCode: match.params.searchRegion,
                location
              })
            );
          }
        } else if (
          !lastLocation ||
          (lastLocation && lastLocation.pathname === '/')
        ) {
          window.location = '/';
        } else {
          history.goBack();
        }
      }, 300);
    });
  }

  /**
   * Trigger when click the escape button
   * @param {*} e
   */
  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  /**
   * Login error validation performed here
   * @param {*} scenario
   */
  triggerValidation(scenario = 'login') {
    let {
      mobileNumber,
      password,
      actionType,
      otp,
      validationState,
      forgetPasswordResponse
    } = this.state;
    this.clearErrorValidation();
    if (scenario === 'login') {
      validationState.mobileNumberInvalid = !isValidNumber(mobileNumber);
      validationState.passwordInvalid =
        !password.trim().length || validationState.mobileNumberInvalid;
      validationState.loginInvalidResponse = '';
      if (mobileNumber.length > 3 && password.trim().length) {
        validationState.loginInvalidResponse = validationState.mobileNumberInvalid
          ? 'Registered mobile number is not valid'
          : '';
      }
      if (actionType === 'FORGOT') {
        validationState.otpInvalid = !otp.trim().length || otp.length !== 6;
      } else if (actionType === 'OTP') {
        validationState.mobileNumberInvalid = !isValidNumber(mobileNumber);
        forgetPasswordResponse = !isValidNumber(mobileNumber)
          ? 'Entered mobile number is not valid'
          : forgetPasswordResponse;
      }
    } else if (scenario === 'get_otp') {
      validationState.mobileNumberInvalid = !isValidNumber(mobileNumber);
      validationState.otpInvalid = false;
      validationState.passwordInvalid = false;
    }
    this.setState({ forgetPasswordResponse, validationState });
    return _.every(_.valuesIn(validationState), e => !e);
  }

  /**
   * This function used to get the instance of the internal components
   * @param {*} calBackFunction
   * @param isLoading
   */
  getInstance(calBackFunction, isLoading = true) {
    let mobileIns = (this.mobileInstance.current || {}).state;
    let passwordIns = (this.passwordInstance.current || {}).state;
    let otpIns = (this.otpInstance.current || {}).state;
    let nameIns = (this.nameInstance.current || {}).state;
    let emailIns = (this.emailInstance.current || {}).state;
    this.setState(
      {
        mobileNumber: mobileIns
          ? mobileIns.extensionNumber + mobileIns.mobileNumber
          : '',
        countryPhoneCode: mobileIns ? mobileIns.extensionNumber : '+91',
        password: passwordIns ? passwordIns.value : '',
        otp: otpIns ? otpIns.value : '',
        userName: nameIns ? nameIns.value : '',
        email: emailIns ? emailIns.value : '',
        isLoading: isLoading
      },
      () => {
        calBackFunction();
      }
    );
  }

  /**
   * Login action performed here
   * @param {*} e
   */
  triggerLogin(e) {
    this.canValidate = true;
    e && e.preventDefault();
    this.clearErrorValidation();
    /** Call back function to get the instance of the internal components */
    this.getInstance(() => {
      if (this.triggerValidation()) {
        this.setState({ isLoading: true }, () => {
          let props = this.props;
          let {app, hotelDetails} = props;

          let {
            countryPhoneCode,
            mobileNumber,
            password,
            actionType,
            otp,
            OTPResponseId
          } = this.state;

          let match = props.match;
          const isItineraryView =
            this.isItineraryView || match.params.itineraryId;
          let strippedPhoneNumber = mobileNumber
            .replace(/\D/g, '')
            .substr(countryPhoneCode.replace('+', '').length);
          let reqData = {
            countryPhoneCode: countryPhoneCode,
            mobileNumber: strippedPhoneNumber,
            password: password
          };

          // Campaign itinerary ID - Needs to fetch from URL only in case of packages/vacations/Island PDG flow
          // Which is being determined by the below conditions. 
          // Case 1: app.packages will be there in case packages/vacations flow
          // Case 2: app.hotelDetails.content will be there only in case of PDG IH flow
          // Case 3: app.itineraryInfo.campaignItineraryId will be there in detailed Itinerary screen ( packages/:slug )
          // Otherwise this has to be null - as this parameter being used as validator for the assignUser flow
          const itcampaignItineraryId =
            (app.packages && Array.isArray(app.packages.filteredItineraries) && app.packages.filteredItineraries.length)
            || (hotelDetails && hotelDetails.content) ?
              match.params.itineraryId
            : (!isEmptyObject(app.itineraryInfo) && app.itineraryInfo.campaignItineraryId
              ? app.itineraryInfo.campaignItineraryId
              : null);

          if (actionType === 'FORGOT') {
            reqData.otp = otp;
            reqData.id = OTPResponseId;
          }

          if (isItineraryView) {
            /* LOGIN WITH OTP */
            props.actions
              .login({
                req_data: reqData,
                isItineraryView: true,
                getCostObject: app.getCostUpdatedObject,
                history: props.history,
                loginType: 'USER',
                location: props.history.location,
                lastLocation: props.lastLocation,
                campaignItineraryId: itcampaignItineraryId,
                match: match
              })
              .then(() => {
                this.setState({ isLoading: false, showModal: false });

                /* Google analytics event triggering starts */
                if (!is_server() && window.gtag) {
                  window.gtag('event', 'login', {
                    event_category: 'engagement',
                    event_label: 'method',
                    value: '0'
                  });
                }
                /* Google analytics event triggering ends */
              })
              .catch(() => {
                this.setState({ isLoading: false });
              });
          } else {
            /** DEFAULT LOGIN ACTION */
            props.actions
              .login({
                req_data: reqData,
                isItineraryView: false,
                history: props.history,
                loginType: 'USER',
                location: props.location,
                lastLocation: props.lastLocation,
                match: match
              })
              .then(() => {
                this.setState({ isLoading: false, showModal: false });

                /* Google analytics event triggering starts */
                if (!is_server() && window.gtag) {
                  window.gtag('event', 'login', {
                    event_category: 'engagement',
                    event_label: 'method',
                    value: '0'
                  });
                }
                /* Google analytics event triggering ends */
              })
              .catch(() => {
                this.setState({ isLoading: false });
              });
          }
        });
      } else {
        this.setState({ isLoading: false });
      }
    });
  }

  /**
   * Signup click event called here
   * @param {*} e
   */
  triggerSignup(e) {
    e && e.preventDefault();
    this.canValidate = true;
    /**
     * To avoid the multiple time trigger for the signup button
     */
    if (!this.state.disabledSignupButton) {
      this.setState(
        {
          disabledSignupButton: true
        },
        () => {
          this.getInstance(() => {
            this.validateSignUpForm();
          });
        }
      );
    }
  }

  getCostingConfiguration() {
    let { user_details } = this.props.app;
    let costingConfiguration = this.props.app.getCostUpdatedObject
      .costingConfig;
    let configObj = _.omit(costingConfiguration, [
      'bookingPlan_Text',
      'departureAirport_Text'
    ]);

    if (
      user_details &&
      user_details.loggedIn &&
      user_details.userType === 'ADMIN' &&
      configObj.tripStage === '2'
    ) {
      configObj.tripStage = '4'; // Booking this month
    }

    return configObj;
  }

  /**
   * Signup validation performed here
   */
  validateSignUpForm() {
    let state = this.state;
    this.inputSignupHandler();
    let { userName, email, mobileNumber, countryPhoneCode } = state;
    let isEmailValid = email.trim() !== '' && emailValidation(email);
    let isMobileNumberValid = isValidNumber(mobileNumber);
    let isUserNameValid = userName.trim() !== '';
    let strippedPhoneNumber = mobileNumber
      .replace(/\D/g, '')
      .substr(countryPhoneCode.replace('+', '').length);
    let validationState = state.validationState;
    validationState.mobileNumberInvalid = !isMobileNumberValid;
    validationState.emailInvalid = !isEmailValid;
    validationState.isUserNameValid = !isUserNameValid;

    const { actions, lastLocation, history, match, app, packages, hotelDetails } = this.props;
    const {itineraryDetails = {}} = app.itineraryInfo;
    const {itinerary} = itineraryDetails;
    
    const itineraryId = match.params.itineraryId;
    const regionCode = (!_.isEmpty(app.itineraryInfo) ? itinerary.regionCode : match.params.searchRegion) || 'region';

    this.setState(validationState, () => {
      if (isEmailValid && isMobileNumberValid && isUserNameValid) {
        let url = `${API_URL}user/signup/verifyotp`;
        if (!itineraryId) {
          url = `${API_URL}user/homePage/signup`;
        }
        let post_data = {
          mobileNumber: strippedPhoneNumber,
          userName: userName,
          email: email,
          countryPhoneCode: countryPhoneCode,
          leadSource: getLeadSource({
            history,
            lastLocation
          }),
          cpid: sessionStorage.getItem('campaignId')
        };
        axios
          .post(url, post_data)
          .then(response => {
            if (response.data) {
              window.sessionStorage.setItem('USER_HASH_DATA', response.data.data);
              if (
                response.data.status === 'SUCCESS' &&
                response.data.message === 'User Created'
              ) {
                this.closeModal();
              }
              if (response.data.status === 'INVALID_EMAIL') {
                /**
                 * To check the GCM flow here for costing account
                 */
                let configObj = this.getCostingConfiguration();
                if (Object.keys(configObj).length) {
                  let req_data = {
                    itineraryId: itineraryId,
                    costingType: 'RECOST',
                    costingConfig: configObj
                  };

                  actions.showLoginForm({
                    requestPayload: req_data,
                    regionCode,
                    history,
                    preState: {
                      mobile_number: state.mobileNumber,
                      user_email: response.data.data,
                      errorMessage: response.data.message
                    },
                    campaign: ((packages && packages.content) || (hotelDetails && hotelDetails.content) || itinerary && itinerary.campaign)
                  });
                } else {
                  state.actionType = 'LOGIN';
                  state.headerText = 'Account exists';
                  state.subText = response.data.message;
                  state.isLoading = false;
                  state.disabledSignupButton = false;

                  this.setState(state);
                }
              } else {
                this.setState({ isLoading: false }, () => {
                  // second parameter is to identify the sign-up type
                  // if itineraryId is present then it is from getCostModal
                  // if there is no itinerary id then user signed up from signup form/modal
                  actions.getUserDetails(
                    {},
                    !match.params.itineraryId
                      ? USER_SIGNUP
                      : USER_SIGNUP_GETCOST
                  );

                  if (!this.isItineraryView && itineraryId) {
                    triggerSimpleAjax(
                      `${API_URL}itinerary/campaign/${itineraryId}/assignUser`,
                      'POST',
                      {},
                      response => {
                        actions.getCost({
                          itineraryId: response.data,
                          regionCode,
                          req_data: Object.assign(this.props.app.getCostUpdatedObject, {
                            itineraryId: response.data
                          }),
                          history,
                          lastLocation,
                          campaign: true 
                        });
                      },
                      error => {
                        console.error('Got error: ', error);
                      }
                    );
                  } else if (match.params.itineraryId) {
                    actions.getCost({
                      itineraryId,
                      regionCode,
                      req_data: app.getCostUpdatedObject,
                      history,
                      lastLocation
                    });
                  } else if (
                    response.data.status === 'VERIFIED' &&
                    response.data.message === 'User created'
                  ) {
                    this.closeModal();
                  }
                });
              }
            }
          })
          .catch(error => {
            if (!error.response) {
              return null;
            }
            if (error.response && error.response.status === 409) {
              if (error.response.data === 'Mobile number already exists') {
                state.actionType = 'LOGIN';
                state.headerText = 'Welcome back!';
                state.subText =
                  'Looks like you have an account created with this mobile number. Please login with your details';
                state.isLoading = false;
              } else if (error.response.data === 'Email id already exists') {
                state.validationState.emailAlreadyExist =
                  'This email ID already exists. Try using a different one';
                state.isLoading = false;
              }
              state.disabledSignupButton = false;
              this.setState(state);
            } else if (error.response && error.response.status === 400) {
              // _this.setState({
              //   isLoading: false,
              //   mobile_number_empty: true
              // });
            }
          });
      } else {
        this.setState({ isLoading: false, disabledSignupButton: false });
      }
    });
  }

  /**
   * Clear the validation error
   * @param {*} e
   */
  clearErrorValidation(e) {
    e && e.preventDefault();
    let validationState = this.state.validationState;
    validationState.mobileNumberInvalid = false;
    validationState.passwordInvalid = false;
    validationState.emailAlreadyExist = '';
    validationState.isUserNameValid = false;
    validationState.emailInvalid = '';
    validationState.loginInvalidResponse = '';

    this.setState({
      forgetPasswordResponse: '',
      profileNotFound: false,
      loginError: false,
      loginErrorResponse: '',
      validationState,
      signUpValidation: {
        emailResponse: '',
        mobileNumberResponse: '',
        userNameResponse: ''
      }
    });
  }

  /**
   * To generate the OTP based on mobile number
   */
  getOTPClickHandler(e) {
    e && e.preventDefault();
    this.canValidate = true;
    const executeOTP = () => {
      if (this.triggerValidation('get_otp')) {
        let { countryPhoneCode, mobileNumber } = this.state;
        let strippedPhoneNumber = mobileNumber
          .replace(/\D/g, '')
          .substr(countryPhoneCode.replace('+', '').length);
        this.props.actions.getOTP({
          countryPhoneCode: countryPhoneCode,
          mobileNumber: strippedPhoneNumber
        });
      } else {
        this.setState({ isLoading: false });
      }
    };
    this.getInstance(executeOTP);
  }

  inputLoginHandler = () => {
    this.getInstance(() => {
      this.setState({ isLoading: false }, () => {
        if (this.canValidate) {
          this.triggerValidation();
        }
      });
    });
  };

  inputSignupHandler = () => {
    this.getInstance(() => {
      let state = this.state;
      this.setState({ isLoading: false }, () => {
        let { validationState, signUpValidation } = this.state;
        if (this.canValidate) {
          let { userName, email, mobileNumber } = state;
          let inValidEmail = !emailValidation(email);
          let inValidUserName = !isValidName(userName);
          let inValidPhoneNumber = !isValidNumber(mobileNumber);
          if (!userName.trim().length) {
            validationState.isUserNameValid = true;
          } else if (inValidUserName) {
            validationState.isUserNameValid = true;
            signUpValidation.userNameResponse =
              'Special characters not allowed';
          } else {
            validationState.isUserNameValid = false;
          }
          if (!email) {
            validationState.emailInvalid = true;
          } else if (inValidEmail) {
            validationState.emailInvalid = true;
            signUpValidation.emailResponse = 'Entered email is not valid';
          } else {
            validationState.emailInvalid = false;
          }
          if (mobileNumber.length < 4) {
            validationState.mobileNumberInvalid = true;
          } else if (inValidPhoneNumber) {
            validationState.mobileNumberInvalid = true;
            signUpValidation.mobileNumberResponse =
              'Entered mobile number is not valid';
          } else {
            validationState.mobileNumberInvalid = false;
          }
          this.setState({
            isLoading: false,
            validationState: validationState
          });
        }
      });
    }, false);
  };

  /**
   * Trigger when touch move in mobile
   * @param {*} position
   * @param {*} event
   */
  onSwipeMove(position) {
    let element = document.getElementById('login-container');
    this.setState({ positionY: position.y });
    if (element && position.y > 0) {
      element.style.top = position.y + 'px';
    }
  }

  /**
   * Trigger when touch end in mobile
   */
  onSwipeEnd() {
    let _this = this;
    let positionY = this.state.positionY;
    let startValue = 0;
    let isClose = false;
    if (Math.round(positionY / window.innerHeight * 100) > 20) {
      isClose = true;
      startValue = window.innerHeight - positionY;
    } else {
      startValue -= positionY;
    }
    let duration = 200;
    let element = document.getElementById('login-container');
    if (element) {
      animate({
        duration: duration,
        timing: function(currentTime) {
          return (
            -startValue * Math.cos(currentTime / duration * (Math.PI / 2)) +
            startValue +
            positionY
          );
        },
        execute: progress => {
          if (progress > 0) {
            // console.log(progress);
            element.style.top = progress + 'px';
          }
        },
        end: () => {
          if (isClose) {
            _this.closeModal();
          }
        }
      });
    }
    this.setState({ positionY: 0 });
  }

  /**
   * Action properties assigned here
   * @param {*} actionType
   * @param {*} headerText
   * @param {*} subText
   */
  setActionProperties(
    actionType = 'LOGIN',
    headerText = 'Welcome back!',
    subText = ''
  ) {
    this.canValidate = false;
    this.setState(
      {
        actionType: actionType,
        headerText: headerText,
        subText: subText,
        isLoading: false
      },
      () => {
        this.clearErrorValidation();
      }
    );
  }

  /**
   * Render method called here
   */
  render() {
    let {
      showModal,
      isKilled,
      forgetPasswordResponse,
      profileNotFound,
      headerText,
      mobileNumber,
      countryPhoneCode,
      subText,
      loginError,
      loginErrorResponse,
      validationState,
      actionType,
      isLoading,
      loginImage,
      signUpValidation,
      disabledSignupButton
    } = this.state;
    let isFromGetCost =
      checkIndexOf((this.props.lastLocation || {}).pathname, ['get-cost']) &&
      (this.props.app.regionStatus || {}).regionName;
    if (isKilled && !this.props.isTestKilled) {
      return null;
    }

    return (
      <Fragment>
        <div
          className={classNames(
            'modal fade modal-sticky-header modal-touch-header primary-popups',
            {
              slideUp: isFaqMobile(),
              in: showModal && loginImage,
              'costing-popup': isFromGetCost && !isFaqMobile()
            }
          )}
          tabIndex={-1}
        >
          <div className="modal-dialog" id="login-container">
            <div className="modal-content with-header">
              <Swipe
                onSwipeMove={this.onSwipeMove}
                onSwipeEnd={this.onSwipeEnd}
              >
                {/* Mobile Scroll - Tab Element Start */}
                <div
                  id="tab-btn"
                  className="modal-header touch-header"
                  data-dismiss="modal"
                >
                  <Button buttonClass="tap-btn" />
                </div>
              </Swipe>
              {/* Mobile Scroll - Tab Element End */}

              {/* Login Modal Element Start Here */}
              <div className="modal-body">
                <div className="inner-content">
                  {!isFromGetCost ? (
                    <RenderLeftSidePanel
                      image={this.state.loginImage}
                      quotes={this.state.loginQuote}
                      isSignUp={this.state.actionType === 'SIGNUP'}
                      tripText={this.state.tripText}
                      place={this.state.place}
                      fName={this.state.fName}
                    />
                  ) : (
                    <RenderCostingPanel
                      regionStatus={this.props.app.regionStatus}
                    />
                  )}
                  <RenderRightSidePanel
                    headerText={headerText}
                    mobileNumber={mobileNumber}
                    countryPhoneCode={countryPhoneCode}
                    subText={subText}
                    loginError={loginError}
                    loginErrorResponse={loginErrorResponse}
                    validationState={validationState}
                    actionType={actionType}
                    profileNotFound={profileNotFound}
                    forgetPasswordResponse={forgetPasswordResponse}
                    isLoading={isLoading}
                    nameInstance={this.nameInstance}
                    emailInstance={this.emailInstance}
                    triggerCloseModal={this.closeModal}
                    triggerLogin={this.triggerLogin}
                    triggerSignup={this.triggerSignup}
                    triggerOTP={this.getOTPClickHandler}
                    mobileInstance={this.mobileInstance}
                    passwordInstance={this.passwordInstance}
                    otpInstance={this.otpInstance}
                    loginChangeCall={this.inputLoginHandler}
                    signUpChangeCall={this.inputSignupHandler}
                    setSignUp={this.setSignUp}
                    setLogin={this.alreadyAccountHandler}
                    disabledSignupButton={disabledSignupButton}
                    signUpValidation={signUpValidation}
                    setForgot={() => {
                      this.setActionProperties(
                        'OTP',
                        'Oh yes!',
                        "Let's retrieve your account!"
                      );
                    }}
                  />
                </div>
              </div>
              {/* Login Modal Element End Here */}
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

/**********--Functional Components Starts Here--**********/

/**
 * To get the backdrop screen
 */
export const GetBackDropScreen = () => {
  return <div className="modal-backdrop fade in" />;
};

/**
 * To render the left side panel for the login modal
 */
export const RenderLeftSidePanel = props => {
  let text = (props.quotes || {}).text;
  let author = (props.quotes || {}).author;
  let place = props.place;
  let tripText = props.tripText;
  let fName = props.fName;
  return (
    <aside
      className="hidden-xs"
      style={{
        backgroundImage: 'url(' + getImgIXUrl(props.image) + ')'
      }}
    >
      <div className="side-content">
        <p className="fine-text light mbottom-medium">
          {props.isSignUp ? tripText : text}
        </p>
        {!props.isSignUp ? (
          <p className="caps-text-tiny bold mb-0">{author}</p>
        ) : (
          <p className="caps-text-tiny bold mb-0 dim">
            {fName} <br /> {place}
          </p>
        )}
      </div>
    </aside>
  );
};

/**
 * To Render right side panel for tge login modal
 */
export const RenderRightSidePanel = props => {
  let { triggerCloseModal, headerText, subText } = props;

  return (
    <div className="right-content">
      <div className="top-btns hidden-xs">
        <Button
          buttonClass="pull-right btn btn-link"
          clickAction={triggerCloseModal}
        >
          <i className="vehoicon-close" />
        </Button>
      </div>
      <RenderHeaderText headerText={headerText} subText={subText} />
      <form action="#">
        {<RenderInsideComponents {...props} />}
        <RenderFooterComponent {...props} />
      </form>
    </div>
  );
};

/**
 * Right side inside elementd render here
 * @param {*} props
 */
export const RenderInsideComponents = props => {
  let {
    mobileInstance,
    passwordInstance,
    validationState,
    loginError,
    loginErrorResponse,
    actionType,
    nameInstance,
    emailInstance,
    setForgot,
    profileNotFound,
    otpInstance,
    forgetPasswordResponse,
    triggerOTP,
    mobileNumber = '',
    countryPhoneCode = '+91',
    loginChangeCall,
    signUpChangeCall,
    signUpValidation
  } = props;
  let strippedPhoneNumber = mobileNumber
    .replace(/\D/g, '')
    .substr(countryPhoneCode.replace('+', '').length);
  switch (actionType) {
    case 'SIGNUP': {
      return (
        <Fragment>
          <Text
            nameField
            ref={nameInstance}
            isError={validationState.isUserNameValid}
            labelText="Your name"
            placeHolder="Your name"
            errorResponse={
              signUpValidation.userNameResponse || 'Enter your name'
            }
            changeCall={signUpChangeCall}
          />
          <Text
            ref={emailInstance}
            isError={
              validationState.emailInvalid || validationState.emailAlreadyExist
            }
            labelText="Email"
            placeHolder="Email"
            changeCall={signUpChangeCall}
            errorResponse={
              signUpValidation.emailResponse ||
              validationState.emailAlreadyExist ||
              'Enter your mail address'
            }
          />
          <MobileNumber
            ref={mobileInstance}
            isSignUp={true}
            isError={validationState.mobileNumberInvalid}
            errorResponse={
              signUpValidation.mobileNumberResponse ||
              'Enter your valid mobile number'
            }
            changeCall={signUpChangeCall}
          />
        </Fragment>
      );
    }
    case 'FORGOT': {
      return (
        <Fragment>
          <MobileNumber
            ref={mobileInstance}
            disabled={true}
            isChange={true}
            changeCall={props.setForgot}
          />
          <Password
            ref={otpInstance}
            isError={loginError || validationState.otpInvalid}
            errorResponse={loginErrorResponse || 'Please enter valid otp'}
            placeHolder="Enter OTP"
            labelText="Enter OTP"
            maxLength={6}
            isOTP={true}
            forgotAction={triggerOTP}
            changeCall={loginChangeCall}
          />
          <Password
            ref={passwordInstance}
            isError={validationState.passwordInvalid}
            errorResponse={'Please Enter Password'}
            placeHolder="Set a new password"
            changeCall={loginChangeCall}
            labelText="Set a new password"
          />
        </Fragment>
      );
    }
    case 'OTP': {
      return (
        <MobileNumber
          ref={mobileInstance}
          isError={profileNotFound || validationState.mobileNumberInvalid}
          changeCall={loginChangeCall}
          errorResponse={
            forgetPasswordResponse ||
            'Enter your registered mobile number and click Get OTP'
          }
        />
      );
    }
    default: {
      return (
        <Fragment>
          <MobileNumber
            ref={mobileInstance}
            isError={loginError || validationState.mobileNumberInvalid}
            mobileNumber={strippedPhoneNumber}
            extensionNumber={countryPhoneCode}
            changeCall={loginChangeCall}
          />
          <Password
            ref={passwordInstance}
            enableForgot={true}
            forgotAction={setForgot}
            isError={loginError || validationState.passwordInvalid}
            changeCall={loginChangeCall}
            errorResponse={
              loginErrorResponse ||
              validationState.loginInvalidResponse ||
              'Enter your registered mobile number and password'
            }
            placeHolder="Password"
            labelText="Password"
          />
        </Fragment>
      );
    }
  }
};

/**
 * Footer components render here
 * @param {*} param0
 */
export const RenderFooterComponent = ({
  triggerLogin,
  setSignUp,
  actionType,
  triggerSignup,
  setLogin,
  triggerOTP,
  isLoading,
  disabledSignupButton = false
}) => {
  let isSignUp = actionType === 'SIGNUP';
  let isOTP = actionType === 'OTP';
  return (
    <div className="btns-row">
      <Button
        buttonClass="btn btn-primary btn-lg btn-block"
        buttonText={isSignUp ? 'Sign up for free' : isOTP ? 'Get OTP' : 'Login'}
        type="submit"
        disabledSignupButton={isSignUp && disabledSignupButton}
        clickAction={
          isSignUp ? triggerSignup : isOTP ? triggerOTP : triggerLogin
        }
        isLoading={isLoading}
      />
      {actionType !== 'FORGOT' ? (
        <Button
          buttonClass="btn btn-link"
          buttonText={
            isSignUp ? 'Already got an account' : 'Sign up for a free account'
          }
          clickAction={isSignUp ? setLogin : setSignUp}
        />
      ) : null}
    </div>
  );
};

/**
 * Header Text for Login Modal Render
 */
export const RenderHeaderText = ({ headerText, subText }) => {
  return (
    <div className="title-txt">
      <span className="visible-xs center-block" />
      <h5 className="medium-heading bold">{headerText}</h5>
      {subText ? <p className="fine-text light color-grey">{subText}</p> : null}
    </div>
  );
};
/**********--Functional Components End Here--**********/

//<!--------------------Redux State Handler--------------------!>
function mapDispatchToProps(dispatch) {
  return {
    actions: {
      login: bindActionCreators(login, dispatch),
      getOTP: bindActionCreators(getOTP, dispatch),
      loginWithOTP: bindActionCreators(loginWithOTP, dispatch),
      getUserDetails: bindActionCreators(getUserDetails, dispatch),
      showLoginForm: bindActionCreators(showLoginForm, dispatch),
      getCost: bindActionCreators(getCost, dispatch)
    }
  };
}

export default withLastLocation(
  connect(state => state, mapDispatchToProps)(Login)
);
