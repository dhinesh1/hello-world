import React, { Component } from 'react';

import Vouchers from '../booked_itinerary/tabs/vouchers';
import Payments from '../booked_itinerary/tabs/payments';
import Visa from '../booked_itinerary/tabs/visa';
import BonVoyage from '../booked_itinerary/tabs/bon_voyage';
import { getKeyValuefromUrlString } from '../../helpers/utilsHelper';
import Tabs from 'react-responsive-tabs';

// IMPORTANT you need to include the default styles
//import 'react-responsive-tabs/styles.css';

export default class RightMainContent extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    let { bookedTrip } = this.props;
    let activetab = getKeyValuefromUrlString(window.location.href, 'activetab');
    let voucherActiveCls = '';
    let paymentsActiveCls = '';
    let visaActiveCls = '';
    if (activetab) {
      if (activetab === 'vouchers') {
        voucherActiveCls = 'active';
      } else if (activetab === 'payments') {
        paymentsActiveCls = 'active';
      } else if (activetab === 'visa') {
        visaActiveCls = 'active';
      }
    } else {
      if (bookedTrip.vouchers) {
        voucherActiveCls = 'active';
      } else {
        paymentsActiveCls = 'active';
      }
    }

    let visaClass = '';

    if (!bookedTrip.visaStatus) visaClass = 'col-3';

    return (
      <div className="col-xs-12 col-sm-8 col-sm-push-4 col-md-9 col-md-push-3">
        <section className="clearfix title-row">
          <p className="meta-text">ID #{bookedTrip.uniqueIdentifier}</p>
          <h3 className="large-heading fade">{bookedTrip.tripName}</h3>
        </section>
        <section className="clearfix visible-xs mbottom-large depart-details">
          <div className="row">
            <div className="col-xs-12">
              <span className="pill accent-1">
                {bookedTrip.daysToGo} days to go
              </span>
              <section className="depart-list">
                <p>
                  <span>Departing:</span> {bookedTrip.departureDate}{' '}
                  <a id="moreLink" href="#">
                    More...
                  </a>
                </p>
                <div id="moreDetails" className="hide">
                  <p>
                    <span>Booked on:</span> {bookedTrip.bookedOnDate}
                  </p>
                  <p>
                    <span>Booked for:</span> {bookedTrip.adults} adults{' '}
                    {bookedTrip.children !== 0
                      ? bookedTrip.children === 1
                        ? `, ${bookedTrip.children} child`
                        : `, ${bookedTrip.children} children`
                      : ``}
                  </p>
                  <p>
                    <span>From:</span> {bookedTrip.departureCity}
                  </p>
                  <p>
                    <span>Duration:</span> {bookedTrip.nights} nights{' '}
                    <a id="lessLink" href="#">
                      Less...
                    </a>
                  </p>
                </div>
              </section>
            </div>
          </div>
        </section>

        <Tabs
          showMore={false}
          transformWidth={600}
          items={[
            {
              title: (
                <p>
                  <i className="vehoicon-receipt" /> Vouchers
                  <span>Download vouchers</span>
                </p>
              ),
              getContent: () => (
                <div className={`tab-pane ${voucherActiveCls}`} id="vouchers">
                  <Vouchers bookedTrip={bookedTrip} />
                </div>
              )
            },
            {
              title: (
                <div className={`${paymentsActiveCls} ${visaClass}`}>
                  <p>
                    <i className="vehoicon-account_balance_wallet" />
                    {' Payments'}
                    <br />
                    <span className="highlight">
                      {bookedTrip.paymentDetail &&
                      bookedTrip.paymentDetail.productPaymentAllowed
                        ? `Next due on ${bookedTrip.nextPaymentDue}`
                        : null}
                      {''}
                      {bookedTrip.paymentDetail.fullPaymentMade
                        ? `Paid in full`
                        : null}
                      {!(
                        bookedTrip.paymentDetail &&
                        bookedTrip.paymentDetail.productPaymentAllowed
                      ) && !bookedTrip.paymentDetail.fullPaymentMade ? (
                        <span>&nbsp;</span>
                      ) : null}
                    </span>
                  </p>
                </div>
              ),
              getContent: () => (
                <div
                  className={`tab-pane payments-tab payments ${paymentsActiveCls}`}
                  id="payments"
                >
                  <Payments {...this.props} bookedTrip={bookedTrip} />
                </div>
              )
            },
            {
              title: (
                <div className={`${visaActiveCls}`}>
                  <p>
                    <i className="vehoicon-fingerprint2" /> Visa <br />
                    <span>
                      {bookedTrip.visaStatus && bookedTrip.visaStatus.onArrival
                        ? `Visa on arrival`
                        : `Visa needed`}
                    </span>
                  </p>
                </div>
              ),
              getContent: () => (
                <div className={`tab-pane ${visaActiveCls}`} id="visa">
                  <Visa bookedTrip={bookedTrip} />
                </div>
              )
            },
            {
              title: (
                <div className={`${visaClass}`}>
                  <p>
                    <i className="vehoicon-flight_takeoff" /> Bon Voyage
                    <br />
                    <span>{bookedTrip.daysToGo} days to go</span>
                  </p>
                </div>
              ),
              getContent: () => (
                <div className={`tab-pane`} id="bon-voyage">
                  <BonVoyage bookedTrip={bookedTrip} />
                </div>
              )
            }
          ]}
        />
      </div>
    );
  }
}
