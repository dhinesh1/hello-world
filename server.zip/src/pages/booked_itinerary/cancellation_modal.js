import React, { Component } from 'react';
import axios from 'axios';
import { AppConfig } from '../../app-config';
import classNames from 'classnames';
const API_URL = AppConfig.api_url;

export default class CancellationModal extends Component {
  constructor(props) {
    super(props);
    this.handleInputChange = this.handleInputChange.bind(this);
    this.makeCancellationRequest = this.makeCancellationRequest.bind(this);
    this.state = {
      cancallationRequestText: '',
      cancellationRequestType: 'PARTIAL_CANCELLATION',
      itineraryId: 0,
      showSuccessMessage: false
    };
  }

  handleInputChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  makeCancellationRequest(e) {
    // console.log(API_URL);
    e.preventDefault();
    // Url: http://localhost:8080/veho/payment/initiatepayment
    let req_config = {
      cancallationRequestText: this.state.cancallationRequestText,
      cancellationRequestType: this.state.cancellationRequestType,
      itineraryId: this.props.bookedTrip.itineraryId
    };
    let _this = this;
    let url = `${API_URL}misc/cancellationPolicyRequest`;
    axios.post(url, req_config).then(response => {
      _this.props.cancellationRequested();
      _this.setState({ showSuccessMessage: true });
    });
  }

  render() {
    let {
      bookedTrip,
      showCancellationModal,
      hideCancellationModal
    } = this.props;
    let { showSuccessMessage } = this.state;
    let modalClassNames = classNames('modal fade cancelpolicy-popup', {
      in: showCancellationModal
    });

    return (
      <div className={modalClassNames} id="cancelPopup" tabIndex={-1}>
        <div className="modal-dialog">
          <div className="modal-content with-footer">
            <div className="modal-body">
              <h5 className="medium-heading bold">
                Changes &amp; Cancellation
              </h5>
              <p className="fine-text color-grey mbottom-large">
                Cancellation charges for specific bookings may vary. Please
                refer to the Cancellation section on the{' '}
                <a
                  className="underline"
                  href={bookedTrip.downloadPdfUrl}
                  download={true}
                >
                  trip PDF
                </a>{' '}
                before proceeding.
              </p>
              {!showSuccessMessage ? (
                <section className="clearfix">
                  <label className="custom-options">
                    <input
                      type="radio"
                      value={'PARTIAL_CANCELLATION'}
                      checked={
                        this.state.cancellationRequestType ===
                        'PARTIAL_CANCELLATION'
                      }
                      name="cancellationRequestType"
                      onChange={this.handleInputChange}
                    />
                    <span>Partial cancellation</span>
                    <i />
                  </label>
                  <label className="custom-options">
                    <input
                      type="radio"
                      value={'RESCHEDULE_VACATION'}
                      checked={
                        this.state.cancellationRequestType ===
                        'RESCHEDULE_VACATION'
                      }
                      name="cancellationRequestType"
                      onChange={this.handleInputChange}
                    />
                    <span>Re-schedule vacation</span>
                    <i />
                  </label>
                  <label className="custom-options">
                    <input
                      type="radio"
                      value={'CANCEL_ENTIRE_VACATION'}
                      checked={
                        this.state.cancellationRequestType ===
                        'CANCEL_ENTIRE_VACATION'
                      }
                      name="cancellationRequestType"
                      onChange={this.handleInputChange}
                    />
                    <span>Cancel entire vacation</span>
                    <i />
                  </label>
                </section>
              ) : null}

              {!showSuccessMessage ? (
                <section className="clearfix">
                  <textarea
                    className="form-control"
                    name={'cancallationRequestText'}
                    onChange={this.handleInputChange}
                    placeholder="Describe your requirements"
                    defaultValue={this.state.cancallationRequestText}
                    rows="6"
                  />
                </section>
              ) : null}

              {showSuccessMessage ? (
                <div className={'alert alert-success'}>
                  Your Cancellation request is received. We will get back to you
                  in 24 - 48 hours.
                </div>
              ) : null}
            </div>
            <div className="modal-footer">
              <button
                onClick={hideCancellationModal}
                type="button"
                className="pull-left btn close"
                data-dismiss="modal"
              >
                <i className="vehoicon-close" />
              </button>
              {!showSuccessMessage ? (
                <button
                  type="button"
                  disabled={
                    this.state.cancallationRequestText.length === 0
                      ? true
                      : false
                  }
                  className="pull-right btn btn-primary tracker-yourtrips-trip-cancellation-cta"
                  onClick={this.makeCancellationRequest}
                >
                  Send request
                </button>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
