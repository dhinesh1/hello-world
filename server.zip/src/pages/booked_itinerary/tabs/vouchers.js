import React, { Component } from 'react';
import _ from 'lodash';

export default class Vouchers extends Component {
  constructor(props) {
    super(props);
    this.renderFlightVouchers = this.renderFlightVouchers.bind(this);
    this.renderHotelVouchers = this.renderHotelVouchers.bind(this);
    this.renderTransferVouchers = this.renderTransferVouchers.bind(this);
    this.renderActivityVouchers = this.renderActivityVouchers.bind(this);
  }

  renderFlightVouchers(flights) {
    let platoLineItemVoucherAvailable = false;
    if (flights && flights.flightsIncluded) {
      platoLineItemVoucherAvailable =
        flights.flightLineItems.filter(
          item => item.voucherUrl && item.voucherUrl.length > 0
        ).length > 0;
    }

    let flightItemList = flights.flightLineItems.map((flight, i) => {
      if (flight.voucherUrl && flight.voucherUrl.length > 0) {
        return (
          <li key={`flight-item-${i}`}>
            <a
              className={'underline'}
              href={flight.voucherUrl}
              target={'_blank'}
              download
            >
              {flight.flightDetailFormatted}
            </a>
          </li>
        );
      } else {
        return (
          <li
            className={
              platoLineItemVoucherAvailable
                ? 'under-process'
                : flights.flightVouchersAvaiable &&
                  !_.isEmpty(flights.voucherUrl)
                  ? ''
                  : 'under-process'
            }
            key={`flight-item-${i}`}
          >
            {flight.flightDetailFormatted}
          </li>
        );
      }
    });

    if (flights.flightsIncluded) {
      return (
        <section className="clearfix">
          <h5 className="small-heading">
            <i className="vehoicon-flight" />Flights{' '}
            {/* flights.flightVouchersAvaiable &&
            !platoLineItemVoucherAvailable ? (
              <span>
                -{' '}
                <a target="_blank" href={`${API_URL}cost/${this.props.bookedTrip.itineraryId}/downloadFlightVoucher`} download>
                  Download vouchers
                </a>
              </span>
            ) : null */}
          </h5>
          <ul className="download-list list-unstyled clearfix">
            {flightItemList}
          </ul>
        </section>
      );
    } else return null;
  }

  renderHotelVouchers(hotels) {
    let platoLineItemVoucherAvailable = false;
    if (hotels && hotels.hotelsIncluded) {
      platoLineItemVoucherAvailable =
        hotels.hotelsList.filter(
          item => item.voucherUrl && item.voucherUrl.length > 0
        ).length > 0;
    }

    let hotelItemList = hotels.hotelsList.map((hotel, i) => {
      if (hotel.voucherUrl && hotel.voucherUrl.length > 0) {
        return (
          <li key={`hotel-item-${i}`}>
            <a
              className={'underline'}
              href={hotel.voucherUrl}
              target={'_blank'}
              download
            >
              {hotel.hotelName} - {hotel.cityName}
            </a>
          </li>
        );
      } else {
        return (
          <li
            className={
              platoLineItemVoucherAvailable
                ? 'under-process'
                : hotels.hotelVouchersAvailable && !_.isEmpty(hotels.voucherUrl)
                  ? ''
                  : 'under-process'
            }
            key={`hotel-item-${i}`}
          >
            {hotel.hotelName} - {hotel.cityName}
          </li>
        );
      }
    });

    if (hotels.hotelsIncluded) {
      return (
        <section className="clearfix">
          <h5 className="small-heading">
            <i className="vehoicon-local_hotel" />Hotels{' '}
            {/* hotels.hotelVouchersAvailable && !platoLineItemVoucherAvailable ? (
              <span>
                -{' '}
                <a target="_blank" href={`${API_URL}cost/${this.props.bookedTrip.itineraryId}/downloadHotelVoucher`} download>
                  Download vouchers
                </a>
              </span>
            ) : null */}
          </h5>
          <ul className="download-list list-unstyled clearfix">
            {hotelItemList}
          </ul>
        </section>
      );
    } else {
      return null;
    }
  }

  renderTransferVouchers(transfers) {
    let transfersItemList = transfers.transfers.map((transfer, i) => {
      if (transfer.voucherUrl && transfer.voucherUrl.length > 0) {
        return (
          <li key={`transfer-item-${i}`}>
            <a
              className={'underline'}
              href={transfer.voucherUrl}
              target={'_blank'}
              download
            >
              {transfer.type} from {transfer.from} to {transfer.to}
            </a>
          </li>
        );
      } else {
        return (
          <li className={'under-process'} key={`transfer-item-${i}`}>
            {transfer.type} from {transfer.from} to {transfer.to}
          </li>
        );
      }
    });

    if (transfers.included) {
      return (
        <section className="clearfix">
          <h5 className="small-heading">
            <i className="vehoicon-transfer_within_a_station" />Transfers
          </h5>
          <ul className="download-list list-unstyled clearfix">
            {transfersItemList}
          </ul>
        </section>
      );
    } else {
      return null;
    }
  }

  renderActivityVouchers(activites) {
    let activitesItemList = activites.activites.map((activity, i) => {
      if (activity.voucherUrl && activity.voucherUrl.length > 0) {
        return (
          <li key={`activity-item-${i}`}>
            <a
              className={'underline'}
              href={activity.voucherUrl}
              target={'_blank'}
              download
            >
              {activity.name} - {activity.day}
            </a>
          </li>
        );
      } else {
        return (
          <li className={'under-process'} key={`activity-item-${i}`}>
            {activity.name} - {activity.day}{' '}
          </li>
        );
      }
    });

    if (activites.included) {
      return (
        <section className="clearfix">
          <h5 className="small-heading">
            <i className="vehoicon-confirmation_number" />Activities
          </h5>
          <ul className="download-list list-unstyled clearfix">
            {activitesItemList}
          </ul>
        </section>
      );
    } else {
      return null;
    }
  }

  render() {
    let { bookedTrip, isForAgent } = this.props;
    let { vouchers } = bookedTrip;
    const { voucherUrlPlatoResponse } = bookedTrip;
    let shouldProcessingBeShownFlight = true;
    let shouldProcessingBeShownHotel = true;
    if (vouchers && vouchers.flights.flightsIncluded) {
      shouldProcessingBeShownFlight = !vouchers.flights.flightVouchersAvaiable;
    } else {
      shouldProcessingBeShownFlight = false;
    }

    if (vouchers && vouchers.hotels.hotelsIncluded) {
      shouldProcessingBeShownHotel = !vouchers.hotels.hotelVouchersAvailable;
    } else {
      shouldProcessingBeShownHotel = false;
    }

    if (vouchers) {
      return (
        <div className="clearfix vouchers">
          {isForAgent
            ? null
            : [
                <section className="row btn-row">
                  <div className="col-sm-7 col-md-9">
                    {shouldProcessingBeShownFlight &&
                    shouldProcessingBeShownHotel ? (
                      <p className="meta-text">
                        <i className="vehoicon-cached" /> Some of your bookings
                        are still under processing.
                      </p>
                    ) : null}
                  </div>
                  <div className="col-sm-5 col-md-3 text-right">
                    {voucherUrlPlatoResponse &&
                    voucherUrlPlatoResponse.voucher ? (
                      <a
                        href={voucherUrlPlatoResponse.voucher}
                        target={'_blank'}
                        className="btn btn-primary"
                        download
                      >
                        <i className="vehoicon-get_app" /> Download all
                      </a>
                    ) : null}
                  </div>
                </section>,
                <hr />
              ]}

          {vouchers && vouchers.flights
            ? this.renderFlightVouchers(vouchers.flights)
            : null}
          {vouchers && vouchers.hotels
            ? this.renderHotelVouchers(vouchers.hotels)
            : null}
          {vouchers && vouchers.transfers
            ? this.renderTransferVouchers(vouchers.transfers)
            : null}
          {vouchers && vouchers.activites
            ? this.renderActivityVouchers(vouchers.activites)
            : null}
        </div>
      );
    } else {
      return <div className="clearfix vouchers" />;
    }
  }
}
