import React, { Component } from 'react';

export default class Payments extends Component {
  constructor(props) {
    super(props);
    this.renderPaymentOptions = this.renderPaymentOptions.bind(this);
    this.renderPaymentHistory = this.renderPaymentHistory.bind(this);
    const { bookedTrip={} } = this.props;
    const { paymentDetail={} } = bookedTrip;
    this.state = {
      paymentType:
        paymentDetail.upcomingPayments &&
        paymentDetail.upcomingPayments.length
          ? paymentDetail.upcomingPayments[0].paymentType
          : ''
    };
  }

  handlePaymentmentOptionChange(paymentType) {
    this.setState({ paymentType: paymentType });
  }

  renderPaymentOptions(upcomingPayments) {
    return upcomingPayments.map((payment, i) => {
      return (
        <label
          key={`upcoming-payment-option-${i}`}
          className="custom-options small"
        >
          <input
            defaultChecked
            onChange={() => {
              this.handlePaymentmentOptionChange(payment.paymentType);
            }}
            checked={
              this.state.paymentType == payment.paymentType ? true : false
            }
            type="radio"
            value={payment.paymentType}
            name="payment_option"
          />
          <span className="bold payment-name">
            {payment.paymentType === 'PARTIAL_70' ||
            payment.paymentType === 'PARTIAL_50'
              ? `Partial payment`
              : `Full payment`}
          </span>{' '}
          -{' '}
          <span className="color-grey">
            ₹{payment.paymentAmount} (completes {payment.percent}% of total)
          </span>
          <i />
        </label>
      );
    });
  }

  renderPaymentHistory(paymentsHistory) {
    return paymentsHistory.map((payment, i) => {
      return (
        <tr key={`payment-histroy-row-${i}`}>
          <td>
            <span className="color-grey">{payment.dateOfPayment} </span>
          </td>
          <td>{payment.paymentTransactionId}</td>
          <td>
            <span className={'WebRupee'}>Rs.</span> {payment.amountFormatted}
          </td>
        </tr>
      );
    });
  }

  render() {
    let { bookedTrip } = this.props;
    let { paymentDetail } = bookedTrip;
    let { paymentsHistory } = paymentDetail;

    return (
      <div>
        {/* PAYMENT MESSAGE BOX STARTS */}
        {paymentDetail.productPaymentAllowed ? (
          <div className="clearfix mbottom-medium">
            <div className="make-payment-left">
              <div className="pointed-ribbon point-right">
                {' '}
                <span className="vehoicon-exclamation-circle" /> Your next
                payment is due{' '}
                {bookedTrip.nextPaymentDueIn == 0
                  ? `today`
                  : `in ${bookedTrip.nextPaymentDueIn} days`}{' '}
              </div>
            </div>
            <div className="make-payment-right">
              <span className="meta-text dim">
                Please make your payments before the scheduled dates or your
                bookings will become void.
              </span>
            </div>
          </div>
        ) : null}
        {/* PAYMENT MESSAGE BOX ENDS */}
        {/* PAYMENT MESSAGE BOX STARTS */}
        {paymentDetail.productPaymentAllowed ? (
          <div className="row hidden-xs">
            <div className="col-xs-12 col-md-9 payment-options-section">
              {this.renderPaymentOptions(paymentDetail.upcomingPayments)}
            </div>
            <div className="col-md-3 col-xs-12 payment-options-section">
              <a
                className="btn btn-primary pull-right"
                onClick={e =>
                  this.props.handlePayBtnClick(this.state.paymentType, e)
                }
              >
                Make payment
              </a>
            </div>
          </div>
        ) : null}
        {/* PAYMENT MESSAGE BOX STARTS */}
        {/* PAYMENT HISTORY BOX STARTS */}
        {paymentsHistory.length > 0 ? (
          <div className="payments-table-container">
            <h5 className="small-heading semi-bold color-primary">
              Payment History
            </h5>
            <table className="table payment-histroy-table">
              <thead>
                <tr>
                  <th>DATE</th>
                  <th>TRANSACTION ID</th>
                  <th>AMOUNT</th>
                </tr>
              </thead>
              <tbody>{this.renderPaymentHistory(paymentsHistory)}</tbody>
            </table>
            <p className="color-grey mini hidden-xs">
              Payments done through IMPS bank transfers may take a few hours to
              get updated here.
            </p>
          </div>
        ) : null}
        {/* PAYMENT HISTORY BOX ENDS */}
      </div>
    );
  }
}
