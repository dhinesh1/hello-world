import React, { Component } from 'react';

export default class BonVoyage extends Component {
  constructor(props) {
    super(props);
  }

  generateGuidesCities(cities) {
    return cities.map((city, i) => {
      let cityImageUrl = `https://d2pkrotgd5anq5.cloudfront.net/city/230x270/${
        city.guidesCityImageUrl
      }`;
      return (
        <div key={`guides-city-${i}`} className="col-sm-6 col-md-3">
          <a href={city.guidesLink} target="_blank">
            <figure
              className="text-center"
              style={{ backgroundImage: `url(${cityImageUrl})` }}
            >
              <figcaption className="small-heading">
                {city.guidesCityName}
              </figcaption>
            </figure>
          </a>
        </div>
      );
    });
  }

  render() {
    let { bookedTrip } = this.props;
    let { bonVoyageVO } = bookedTrip;
    let { guidesCities } = bonVoyageVO;
    guidesCities = guidesCities ? guidesCities : [];

    return (
      <div className="clearfix bon-voyage">
        {guidesCities.length > 0 ? (
          <section className="clearfix">
            <h5 className="small-heading">Explore our travel guides</h5>
            <p className="meta-text">
              Our consultants have curated a great deal of travel tips and local
              wisdom to these guides. Make sure to go through them before you
              embark on this epic trip.
            </p>
          </section>
        ) : null}
        <section className="row mbottom-small">
          {this.generateGuidesCities(guidesCities)}
        </section>
        <section className="clearfix">
          <h5 className="small-heading">Vacation checklist</h5>
          <p className="meta-text">
            <a href={bookedTrip.packingChecklistDownloadLink} download>
              <b>Download our vacation checklist</b>
            </a>{' '}
            before you pack your bags!
          </p>
        </section>
      </div>
    );
  }
}
