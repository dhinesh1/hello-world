import React, { Component } from 'react';
import axios from 'axios';
import _ from 'lodash';
import { AppConfig } from '../../../app-config';
const API_URL = AppConfig.api_url;

export default class Visa extends Component {
  constructor(props) {
    super(props);
    this.handleRadioSelect = this.handleRadioSelect.bind(this);
    this.renderVisaRegions = this.renderVisaRegions.bind(this);
    this.getVisaDocumentLinkForSelectedConfig = this.getVisaDocumentLinkForSelectedConfig.bind(
      this
    );
    this.renderRegionsDropdown = this.renderRegionsDropdown.bind(this);
    this.state = {
      martialStatus: this.props.bookedTrip.visaPreferenceDetail
        .preferredOptionOfTravel,
      occupationType: this.props.bookedTrip.visaPreferenceDetail
        .preferredOptionOfRelationShip
    };
  }

  handleRadioSelect(target, value) {
    this.setState({ [target]: value });
  }

  getVisaDocumentLinkForSelectedConfig(
    documentsArray,
    martialStatus,
    occupationType
  ) {
    let visaObject = null;
    visaObject = _.filter(documentsArray, {
      martialStatus: martialStatus,
      occupationType: occupationType
    })[0];
    if (visaObject) {
      return visaObject.visaDocumentsDownloadLink;
    } else {
      return '#';
    }
  }

  renderVisaRegions(visaDetails) {
    return visaDetails.map(visa => {
      if (!visa) return null;
      return (
        <section
          key={`visa-region-for-${visa.visaRegion}`}
          className="clearfix visa-details vmargin-medium"
        >
          <div className="row heading-row">
            <div className="col-md-4">
              <h5 className="small-heading">{visa.visaRegion}</h5>
            </div>
            <div className="col-md-8">
              {!visa.onArrival ? (
                <p className="meta-text">
                  <span>
                    <i className="color-grey">Apply by :</i> {visa.applyByDate}
                  </span>
                  <span>
                    <i className="color-grey">Processing time :</i>{' '}
                    {visa.visaProcessingTime}{' '}
                    {visa.visaProcessingTime == '1' ? `day` : `days`}
                  </span>
                </p>
              ) : (
                <p className="meta-text">
                  <span>Visa on arrival</span>
                </p>
              )}
            </div>
          </div>
          <hr />
          <div
            className="clearfix visa-content"
            dangerouslySetInnerHTML={{ __html: visa.visaDetailText }}
          />
          {/*
        <div className="clearfix">
          <h4>Documents - Proof of relationships &amp; travel</h4>
          <ul className="dotted-list list-unstyled clearfix">
            <li>Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum.</li>
            <li>Dapibus Mattis Condimentum Ultricies Nullam</li>
          </ul>
        </div>
        <div className="clearfix">
          <h4>Documents - Proof of Income</h4>
          <ul className="dotted-list list-unstyled clearfix">
            <li>Our consultants have curated a great deal of travel tips and local wisdom to these guides. Make sure to go through them before you embark on this epic trip.</li>
          </ul>
        </div> */}
        </section>
      );
    });
  }

  renderRegionsDropdown(visaDetails, martialStatus, occupationType) {
    return visaDetails.map((visa, i) => {
      if (!visa) return null;
      if (visa.onArrival) return null;
      return (
        <li key={`visa-dropdown-${i}`}>
          <a
            href={this.getVisaDocumentLinkForSelectedConfig(
              visaDetails[i].documentDetails,
              martialStatus,
              occupationType
            )}
          >
            {visa.visaRegion}
          </a>
        </li>
      );
    });
  }

  render() {
    let {
      visaDetails,
      visaPreferenceDetail,
      visaStatus
    } = this.props.bookedTrip;
    let { martialStatus, occupationType } = this.state;

    let isDownloadButtonVisible = true;

    const visaOnArrivals = visaDetails.map(visa => {
      if (!visa) return true;
      if (visa.onArrival) return true;
      return false;
    });

    const onArrivalsCompact = _.compact(visaOnArrivals);

    if (onArrivalsCompact.length === visaDetails.length)
      isDownloadButtonVisible = false;

    return (
      <div className="clearfix visa">
        <section className="row btn-row">
          <div className="col-xs-12 col-sm-12 col-md-8">
            <div className="pull-left options-group">
              <span>Occupation: </span>
              <label className="custom-options">
                <input
                  type="radio"
                  value={'SALARIED'}
                  checked={
                    this.state.occupationType == 'SALARIED' ? true : false
                  }
                  onChange={() => {
                    this.handleRadioSelect('occupationType', 'SALARIED');
                  }}
                  name="occupation"
                />
                Salaried
                <i />
              </label>
              <label className="custom-options">
                <input
                  type="radio"
                  value={'SELF_EMPLOYED'}
                  checked={
                    this.state.occupationType == 'SELF_EMPLOYED' ? true : false
                  }
                  onChange={() => {
                    this.handleRadioSelect('occupationType', 'SELF_EMPLOYED');
                  }}
                  name="occupation"
                />
                Self employed
                <i />
              </label>
            </div>
            <div className="pull-left options-group">
              <span>Group type: </span>
              <label className="custom-options">
                <input
                  type="radio"
                  value={'SOLO'}
                  checked={this.state.martialStatus == 'SOLO' ? true : false}
                  onChange={() => {
                    this.handleRadioSelect('martialStatus', 'SOLO');
                  }}
                  name="group_type"
                />
                Solo
                <i />
              </label>
              <label className="custom-options">
                <input
                  type="radio"
                  value={'COUPLE'}
                  checked={this.state.martialStatus == 'COUPLE' ? true : false}
                  onChange={() => {
                    this.handleRadioSelect('martialStatus', 'COUPLE');
                  }}
                  name="group_type"
                />
                Couple
                <i />
              </label>
              <label className="custom-options">
                <input
                  type="radio"
                  value={'FAMILY'}
                  checked={this.state.martialStatus == 'FAMILY' ? true : false}
                  onChange={() => {
                    this.handleRadioSelect('martialStatus', 'FAMILY');
                  }}
                  name="group_type"
                />
                Family
                <i />
              </label>
            </div>
          </div>
          <div className="col-xs-12 col-sm-12 col-md-4">
            {isDownloadButtonVisible ? (
              visaDetails.length > 1 ? (
                <div className="dropdown pull-right">
                  <button
                    onClick={this.getVisaDetails}
                    className="btn btn-primary dropdown-toggle"
                    type="button"
                    data-toggle="dropdown"
                  >
                    Download docs <i className="caret" />
                  </button>
                  <ul className="dropdown-menu">
                    {this.renderRegionsDropdown(
                      visaDetails,
                      martialStatus,
                      occupationType
                    )}
                  </ul>
                </div>
              ) : (
                <a
                  className="btn btn-primary pull-right"
                  href={this.getVisaDocumentLinkForSelectedConfig(
                    visaDetails[0].documentDetails,
                    martialStatus,
                    occupationType
                  )}
                >
                  Download docs{' '}
                </a>
              )
            ) : null}
          </div>
        </section>

        {this.renderVisaRegions(visaDetails)}
      </div>
    );
  }
}
