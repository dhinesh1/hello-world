// Core
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import _ from 'lodash';
import axios from 'axios';
//import {fakewaffle} from '../booked_itinerary/vendor/responsive_tabs';
import classNames from 'classnames';
import PaymentForm from '../../common_components/PaymentForm';
import Sidebar from '../booked_itinerary/sidebar';
import PaymentMobile from '../booked_itinerary/payment_mobile';
import RightMainContent from '../booked_itinerary/right_main_content';
import CancellationModal from '../booked_itinerary/cancellation_modal';
import SweetAlert from 'sweetalert-react';
import 'react-responsive-tabs/styles.css';
import { is_server, getUserDeviceInfo } from '../../helpers/utilsHelper';
import { getUserDetails } from '../../actions/actions_app';

// import SavedItineraries from '../dashboard/components/saved_itineraries';
import { AppConfig } from '../../app-config';
import { itineraryModalsRouteHelper } from '../../helpers/routesHelper';
const SELF_URL = is_server()
  ? ''
  : window.location.protocol + '//' + window.location.hostname;

const SELF_PORT = is_server()
  ? ''
  : window.location.hostname === 'localhost'
    ? ':' + window.location.port
    : '';

const API_URL = AppConfig.api_url;

class BookedTripDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      bookedTrip: {},
      paymentParams: {
        url: 'https://test.payu.in/_payment',
        merchantId: 'gtKFFx',
        hash:
          'b5f12d420ee6e33bd64d5a12a2b59a85e311b05214cf7ebbc7f4ccddd8ddb413a94125929ec22c5854b283469dc1e39753ccc7a3c64e28b311a32b12b3eab7a9',
        transactionId: 'VEHO_576b7e829e386c1472a47543_1466672250322',
        amount: '92433',
        email: 'sushman11@test.com',
        productInfo: 'Vacation for sushman',
        successUrl: `${SELF_URL + SELF_PORT}/payment/processing`,
        failureUrl: `${SELF_URL + SELF_PORT}/payment/processing`,
        firstName: 'Sushman',
        lastName: 'Dev',
        cancelUrl: `${SELF_URL + SELF_PORT}/payment/processing`,
        address1: 'Abirampuram',
        address2: '',
        city: 'Chennai',
        state: 'TN',
        country: 'TN',
        zipCode: 'a1234',
        userDefinedOne: '576b7e829e386c1472a47543',
        userDefinedTwo: '56f4112adafea84d50e7d1e8',
        userDefinedThree: 'PARTIAL',
        userDefinedFour: '311200000',
        userDefinedFive: 'TEST'
      },
      isFetching: true,
      isCancellationRequested: false,
      showCancellationModal: false,
      mountCancellationModal: false,
      showAlert: false,
      sweetAlertConfig: {
        title: '',
        text: '',
        type: '',
        animation: 'pop'
      }
    };

    this.handleTabChange = this.handleTabChange.bind(this);
    this.handlePayBtnClick = this.handlePayBtnClick.bind(this);
    this.tabsAndFooterFunctions = this.tabsAndFooterFunctions.bind(this);
    this.cancellationRequested = this.cancellationRequested.bind(this);
    this.mountCancellationModal = this.mountCancellationModal.bind(this);
    this.showCancellationModal = this.showCancellationModal.bind(this);
    this.hideCancellationModal = this.hideCancellationModal.bind(this);
    this.onClickOutsideCancelModalHandler = this.onClickOutsideCancelModalHandler.bind(
      this
    );
  }

  cancellationRequested() {
    this.setState({
      isCancellationRequested: true
    });
  }

  mountCancellationModal() {
    let t = this.state;
    t.mountCancellationModal = true;
    this.setState(t);
    setTimeout(() => {
      this.showCancellationModal();
    }, 200);
  }

  unMountCancellationModal() {
    let t = this.state;
    t.mountCancellationModal = false;
    this.setState(t);
  }

  showCancellationModal() {
    let t = this.state;
    t.showCancellationModal = true;
    this.setState(t);
  }

  hideCancellationModal() {
    let t = this.state;
    t.showCancellationModal = false;
    this.setState(t);
    setTimeout(() => {
      this.unMountCancellationModal();
    }, 200);
  }

  componentWillMount() {
    this.props.actions
      .getUserDetails()
      .then(() => {
        if (this.props.user_details && this.props.user_details.loggedIn) {
          let itineraryId = this.props.match.params.itineraryId;
          let _this = this;

          let url = `${API_URL}user/bookedtripdetails/itinerary/${itineraryId}`;
          this.setState({ isFetching: true }, () => {
            axios.get(url).then(response => {
              // console.log(response);
              _this.setState({
                bookedTrip: response.data,
                isFetching: false
              });
            });
          });
        } else {
          this.props.history.push(`/login`);
        }
      })
      .catch(() => {
        this.props.history.push(`/login`);
      });
  }

  tabsAndFooterFunctions() {
    // $('.nav-tabs a').click(function(e) {
    //   e.preventDefault();
    //   $(this).tab('show');
    // });

    function manageStickyFooterTopPadding() {
      let totalBarHgt = document
        .querySelector('.mobile-payment-bar')
        .outerHeight();
      let titleBarHgt = document.querySelector('.btn-bar').outerHeight();
      let btmPosition = totalBarHgt - titleBarHgt;

      // default bottom position
      document.querySelector('.mobile-payment-bar').css('bottom', -btmPosition);

      if (document.querySelector('.mobile-payment-bar').hasClass('open')) {
        document
          .querySelector('#mobile-spacer-bottom')
          .css('height', totalBarHgt);
      } else {
        document
          .querySelector('#mobile-spacer-bottom')
          .css('height', titleBarHgt);
      }
    }

    //manageStickyFooterTopPadding();
  }

  componentDidUpdate() {
    // RESPONSIVE TABS
    //this.tabsAndFooterFunctions();
  }

  componentDidMount() {
    //this.tabsAndFooterFunctions();
  }

  onClickOutsideCancelModalHandler(e) {
    if (e.target.classList.contains('cancelpolicy-popup')) {
      this.hideCancellationModal();
    }
  }

  handlePayBtnClick(option, e) {
    e.preventDefault();
    // Url: http://localhost:8080/veho/payment/initiatepayment
    let req_config = {
      itineraryId: this.state.bookedTrip.itineraryId,
      userId: '',
      paymentOptionType: option
    };
    let _this = this;
    let paymentParams = _this.state.paymentParams;
    const url = `${API_URL}payment/initiatepayment`;
    axios
      .post(url, req_config, {
        headers: { "Version": "V_2", "user_device": getUserDeviceInfo() }
      })
      .then(response => {
        // console.log('response', response.data);
        _.assign(paymentParams, response.data.data);
        // console.log('paymentParams', JSON.stringify(paymentParams));
        _this.setState({ paymentParams: paymentParams }, () => {
          const paymentForm = document.forms.paymentForm;
          paymentForm && paymentForm.submit();
        });
      })
      .catch(error => {
        let sweetAlertConfig = {
          title: 'Oops! Something went wrong',
          text:
            'We are unable initiate your payment process. Please get it touch with your Travel Consultants for assistance.',
          type: 'warning',
          animation: 'pop'
        };
        _this.setState({ showAlert: true, sweetAlertConfig: sweetAlertConfig });
      });
  }

  handleTabChange(selectedKey) {
    this.setState({
      activeTab: selectedKey
    });
  }

  render() {
    let {
      bookedTrip,
      isFetching,
      showCancellationModal,
      showAlert,
      sweetAlertConfig
    } = this.state;
    let modalBgClassNames = classNames('modal-backdrop fade', {
      in: showCancellationModal
    });

    if (isFetching) {
      return (
        <div className="loader-wrapper bg-white">
          <div className="loading-rounded color-primary lg" />
        </div>
      );
    } else {
      return (
        <div
          className="your-trips"
          onClick={this.onClickOutsideCancelModalHandler}
        >
          <SweetAlert
            show={showAlert}
            title={sweetAlertConfig.title}
            text={sweetAlertConfig.text}
            animation="pop"
            onConfirm={() => this.setState({ showAlert: false })}
          />

          {this.state.mountCancellationModal ? (
            <CancellationModal
              showCancellationModal={this.state.showCancellationModal}
              bookedTrip={bookedTrip}
              hideCancellationModal={this.hideCancellationModal}
              cancellationRequested={this.cancellationRequested}
            />
          ) : null}
          <div className="container xs-full-width">
            <div className="row dim mbottom-medium top-links">
              <div className="col-xs-6 text-left">
                <a href="/your-vacations">
                  <i className="vehoicon-arrow-left" />{' '}
                  <span className="hidden-xs">Your Vacations</span>
                  <span className="visible-xs">Back</span>
                </a>
              </div>
              <div className="col-xs-6 text-right">
                <a href={itineraryModalsRouteHelper({
                  regionCode: bookedTrip.regionCode ? bookedTrip.regionCode : "region",
                  itineraryId: bookedTrip.itineraryId
                })}>
                  <i className="vehoicon-list" /> View itinerary
                </a>
              </div>
            </div>
            <div className="row">
              <RightMainContent
                handlePayBtnClick={this.handlePayBtnClick}
                bookedTrip={bookedTrip}
                mountCancellationModal={this.state.mountCancellationModal}
              />
              <Sidebar
                mountCancellationModal={this.mountCancellationModal}
                bookedTrip={bookedTrip}
                isCancellationRequested={this.state.isCancellationRequested}
              />
            </div>
            <div className="visible-xs" id="mobile-spacer-bottom" />
          </div>
          {bookedTrip.paymentDetail &&
          bookedTrip.paymentDetail.productPaymentAllowed ? (
            <PaymentMobile
              handlePayBtnClick={this.handlePayBtnClick}
              bookedTrip={bookedTrip}
            />
          ) : null}
          {/* smiley-rating starts */}
          <div className="smiley-rating-container hidden-xs hidden-sm text-center">
            <section className="smiley-rating">
              <span>Hey, how do you rate your booking experience?</span>
              <label className="smiley-1">
                <input type="radio" defaultValue={1} name="smiley-rating" />
                <i />
              </label>
              <label className="smiley-2">
                <input type="radio" defaultValue={2} name="smiley-rating" />
                <i />
              </label>
              <label className="smiley-3">
                <input type="radio" defaultValue={3} name="smiley-rating" />
                <i />
              </label>
              <label className="smiley-4">
                <input type="radio" defaultValue={4} name="smiley-rating" />
                <i />
              </label>
              <label className="smiley-5">
                <input type="radio" defaultValue={5} name="smiley-rating" />
                <i />
              </label>
            </section>
          </div>
          {/* smiley-rating ends */}
          {/* message-notification starts */}
          <div className="msg-notification text-center hide">
            <p>Thanks. Our executive will contact you soon.</p>
          </div>
          {/* message-notification ends */}
          <PaymentForm paymentParams={this.state.paymentParams} />
          <div
            onClick={this.hideCancellationModal}
            className={modalBgClassNames}
          />
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  return { ...state.app };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getUserDetails: bindActionCreators(getUserDetails, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(BookedTripDetails);
