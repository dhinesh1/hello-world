import React, { Component } from 'react';
import axios from 'axios';
import { AppConfig } from '../../app-config';
import _ from 'lodash';
const API_URL = AppConfig.api_url;

export default class PaymentMobile extends Component {
  constructor(props) {
    super(props);
    this.renderPaymentOptions = this.renderPaymentOptions.bind(this);
    this.handlePaymentmentOptionChange = this.handlePaymentmentOptionChange.bind(
      this
    );
    this.state = {
      paymentType:
        this.props.bookedTrip.paymentDetail.upcomingPayments &&
        this.props.bookedTrip.paymentDetail.upcomingPayments.length
          ? this.props.bookedTrip.paymentDetail.upcomingPayments[0].paymentType
          : ''
    };
  }

  renderPaymentOptions(upcomingPayments) {
    return upcomingPayments.map((payment, i) => {
      return (
        <label
          key={`upcoming-payment-option-mobile${i}`}
          className="custom-options"
        >
          <input
            type="radio"
            onChange={() => {
              this.handlePaymentmentOptionChange(payment.paymentType);
            }}
            checked={
              this.state.paymentType == payment.paymentType ? true : false
            }
            type="radio"
            value={payment.paymentType}
            name="payment_option_mobile"
          />
          {payment.paymentType === 'PARTIAL_70' ||
          payment.paymentType === 'PARTIAL_50'
            ? `Partial payment`
            : `Full payment`}{' '}
          - <span>₹{payment.paymentAmount}</span>
          <i />
        </label>
      );
    });
  }

  handlePaymentmentOptionChange(paymentType) {
    this.setState({ paymentType: paymentType });
  }

  render() {
    let { bookedTrip } = this.props;
    let { paymentDetail } = bookedTrip;

    return (
      <div className="visible-xs mobile-payment-bar">
        <section className="clearfix btn-bar">
          <div id="pay-txt-link" className="pull-left left-txt text-right">
            <b>₹{paymentDetail.upcomingPayments[0].paymentAmount}</b>
            <p className="dim">
              {paymentDetail.upcomingPayments[0].paymentType === 'PARTIAL_70' ||
              paymentDetail.upcomingPayments[0].paymentType === 'PARTIAL_50'
                ? `Partial payment`
                : `Full payment`}
            </p>
          </div>
          <div className="pull-right right-button">
            <button
              type="button"
              className="btn btn-block btn-primary"
              onClick={e =>
                this.props.handlePayBtnClick(this.state.paymentType, e)
              }
            >
              Make payment
            </button>
          </div>
        </section>
        <section id="pay-txt-content" className="pay-options">
          {this.renderPaymentOptions(paymentDetail.upcomingPayments)}
        </section>
      </div>
    );
  }
}
