import React, { Component } from 'react';
import { AppConfig } from '../../app-config';
import SmartImage from '../../common_components/Image/smart_image';
import {itineraryModalsRouteHelper} from '../../helpers/routesHelper';
const API_URL = AppConfig.api_url;

export default class Sidebar extends Component {
  constructor(props) {
    super(props);
  }

  getBuddyImage(salesOwner) {
    return (
      <SmartImage
        src={salesOwner.imageUrl}
        defaultImage={`https://d3lf10b5gahyby.cloudfront.net/misc/default-profile.png`}
        alt={salesOwner.name}
      >
        <p className="meta-text">{salesOwner.name}</p>
        <b>
          <i className="vehoicon-phone2" /> +91 {salesOwner.mobileNumber}
        </b>
      </SmartImage>
    );
  }

  render() {
    let { bookedTrip, mountCancellationModal } = this.props;
    let { salesOwner } = bookedTrip;
    let cityImageURL = `https://d3lf10b5gahyby.cloudfront.net/city/320x320/${
      bookedTrip.itineraryImage
    }`;
    let itineraryUrl = itineraryModalsRouteHelper({
      regionCode: bookedTrip.regionCode ? bookedTrip.regionCode : "region",
      itineraryId: bookedTrip.itineraryId
    });

    let socialMessage = `I've just booked my ${
      bookedTrip.regionName
    } vacation with Pickyourtrail. Here's my awesome itinerary. Check it out! ${itineraryUrl}`;
    return (
      <div className="col-xs-12 col-sm-4 col-sm-pull-8 col-md-3 col-md-pull-9">
        <section className="vacation-details hidden-xs">
          <figure
            className="mbottom-medium"
            style={{ backgroundImage: `url(${cityImageURL})` }}
          >
            <span>{bookedTrip.daysToGo} days to go</span>
          </figure>
          <ul className="list-unstyled">
            <li>
              <span>Departing:</span> {bookedTrip.departureDate}
            </li>
            <li>
              <span>Booked on:</span> {bookedTrip.bookedOnDate}
            </li>
            <li>
              <span>Booked for:</span> {bookedTrip.adults} adults{' '}
              {bookedTrip.children !== 0
                ? bookedTrip.children === 1
                  ? `, ${bookedTrip.children} child`
                  : `, ${bookedTrip.children} children`
                : ``}
            </li>
            <li>
              <span>From:</span> {bookedTrip.departureCity}
            </li>
            <li>
              <span>Duration:</span> {bookedTrip.nights} nights
            </li>
          </ul>
        </section>
        <section className="total-row vmargin-medium">
          <div className="row text-center">
            <div className="col-xs-6">
              <h6 className="caps-text-tiny dim">Total Cost</h6>
              <span>₹{bookedTrip.totalCost}</span>
            </div>
            <div className="col-xs-6">
              <h6 className="caps-text-tiny dim">You Paid</h6>
              <span>₹{bookedTrip.totalPaid}</span>
            </div>
          </div>
          <div className="row text-center buddy-contact">
            <div className="col-md-12">
              <h5 className="caps-text-small dim">YOUR TRIP BUDDY</h5>
              {this.getBuddyImage(salesOwner)}
            </div>
          </div>
        </section>
        <section className="download-links">
          <ul className="list-unstyled meta-text">
            {bookedTrip.cancelled ||
            this.props.isCancellationRequested ? null : (
              <li>
                <button
                  className="underline btn btn-link tracker-yourtrips-cancel-trip-link-sidebar"
                  onClick={mountCancellationModal}
                >
                  Changes or Cancellation
                </button>
              </li>
            )}
            <li>
              <a
                className="underline tracker-download-packing-checklist-link-sidebar"
                target="_blank"
                href={bookedTrip.packingChecklistDownloadLink}
                download
              >
                Packing checklist
              </a>
            </li>
            <li>
              <a
                className="underline tracker-download-trip-pdf-link-sidebar"
                target="_blank"
                download={true}
                href={`${API_URL}cost/${
                  bookedTrip.itineraryId
                }/downloadItineraryPdf`}
              >
                Download Trip PDF
              </a>
            </li>
          </ul>
        </section>
        <section className="pyt-social-share vpadding-medium">
          <p className="fine-text">
            Spread the vacation mood! Share your itinerary with friends
          </p>
          <ul className="list-unstyled">
            <li>
              <a
                className="tracker-yourtrips-fb-share"
                href={`https://www.facebook.com/sharer/sharer.php?u=${itineraryUrl}`}
                target="_blank"
              >
                <i className="vehoicon-facebook" />
              </a>
            </li>
            <li>
              <a
                className="tracker-yourtrips-twitter-share"
                href={`http://twitter.com/share?text=${socialMessage}`}
                target="_blank"
              >
                <i className="vehoicon-twitter" />
              </a>
            </li>
            <li className="hidden-md hidden-lg">
              <a
                className="tracker-yourtrips-whatsapp-share"
                href="whatsapp://send"
                data-text={socialMessage}
                data-href={itineraryUrl}
              >
                <i className="vehoicon-whatsapp" />
              </a>
            </li>
          </ul>
        </section>
      </div>
    );
  }
}
