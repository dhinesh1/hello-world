import React, { Component } from 'react';
import { AppConfig } from '../../app-config';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Switch, Route, Link } from 'react-router-dom';
import { CareerDetailsLoadable } from '../../helpers/loadbleComponentsHelper';
import { scrollToTop, getImgIXUrl } from '../../helpers/utilsHelper';
import Helmet from 'react-helmet';
import OpenPositions from './components/OpenPositions';
import { getCareersContent } from '../../actions/actions_static_pages';
import BannerSVG from '../../common_components/static/BannerSVG';
import LifeAt from '../../common_components/static/LifeAt';
import MileStoneModal from '../../common_components/static/MileStoneModal';
import OurValues from './components/OurValues';
import AlumniSpeakSlider from './components/AlumniSpeak';

const SOCKET_URL = AppConfig.socket_url;
const mileStoneData =
  require('../../common_components/static/milestone_data.json') || {};

class Careers extends Component {
  state = {
    isOpen: false,
    index: 0,
    showHiring: true
  };

  componentDidMount(): void {
    // the career content getting api call will triggered 
    // in the index js to provide the careers page as server side renderd
    if(!this.props.careers){ // Checking if the careers data found in the props - REDUX Store
      // If its rendered in CSR and careers content in not there in props this API will triggered here
      this.props.actions.getCareersContent();
    }
    
    // Getting back to top of the page
    scrollToTop(1, 500);

    // Registering event listers for clickable (milestone) SVG elements
    document
      .querySelectorAll('.milestone')
      .forEach(ele => ele.addEventListener('click', this.onClick));
  }

  componentWillUnmount() {
    // De-registering events from the milestone elements in the SVG
    document
      .querySelectorAll('.milestone')
      .forEach(ele => ele.removeEventListener('click', this.onClick));
  }

  /**
   * Event triggered when closing the milestone modal
   */
  closeModal = event => {
    this.setState({ isOpen: false });
  };

  /**
   * Click event used when clicking the items in SVG
   * Using the common class called 'milestone' retrieved the element and used the unique class to get the clickable index
   * Example: milestone-01,etc..,
   */
  onClick = event => {
    if (event.target.closest('.milestone')) {
      let indexVal = parseInt(
        event.target
          .closest('.milestone')
          .firstChild.className.baseVal.split('-')[1]
      );
      this.setState({ isOpen: !this.state.isOpen, index: indexVal - 1 });
    }
  };

  render() {
    const { jobDetail = {}, history = { location: {} } } = this.props;
    const { metaInfo = {} } = jobDetail;
    let ogImage = metaInfo.ogImage ? metaInfo.ogImage : '';
    const pathName = history.location.pathname;
    return (
      <section className="careers-new">
        <Helmet>
          <title>{metaInfo.title || `Careers | Pickyourtrail`}</title>
          <meta
            name={'description'}
            content={
              metaInfo.description ||
              "Passionate? Hungry for growth? Want to spearhead in life? Here's your chance to work with Pickyourtrail, India's most exciting travel startup!"
            }
          />
          <meta
            property="og:image"
            content={
              ogImage.replace('https:', 'http:') ||
              'http://pyt-images.imgix.net/images/web_app/career-og-new.png'
            }
          />
          <meta
            property="og:image:url"
            content={
              ogImage.replace('https:', 'http:') ||
              'http://pyt-images.imgix.net/images/web_app/career-og-new.png'
            }
          />
          <meta
            property="og:image:secure_url"
            content={
              ogImage ||
              'https://pyt-images.imgix.net/images/web_app/career-og-new.png'
            }
          />
          <meta property="og:image:type" content="image/png" />
          <meta property="og:type" content="website" />
          <meta
            property="og:title"
            content={metaInfo.title || 'Pickyourtrail - Career Hunt'}
          />
          <meta
            property="og:description"
            content={
              metaInfo.description ||
              "Join our team at Pickyourtrail and show us what you're made of!"
            }
          />
          <meta
            property="og:url"
            content={
              SOCKET_URL + pathName.slice(1, pathName.length) ||
              'https://pickyourtrail.com/careers'
            }
          />
        </Helmet>

        <Switch>
          <Route
            path="/careers/:currentOpeningKey"
            component={CareerDetailsLoadable}
          />
        </Switch>

        <div className="hero-banner">
          <div className="container hidden-xs">
            <div className="row">
              <div className="col-xs-6">
                <ul className="clearfix list-unstyled tab-links">
                  <li>
                    <Link to="/about-us">About</Link>
                  </li>
                  <li className="active">
                    <Link to="/careers">Careers</Link>
                    {this.state.showHiring ? (
                      <div className="inline-tooltip">We are hiring!</div>
                    ) : null}
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <BannerSVG />
        </div>

        <section className="hero-content">
          <div className="container">
            <div className="row">
              <div className="col-xs-12">
                <h1 className="bold color-grey-secondary hidden-xs">
                  We are{' '}
                  <span className="text-strikethrough">travel planners</span>
                </h1>

                <h1 className="bold color-grey-secondary visible-xs">
                  Careers
                  {this.state.showHiring ? (
                    <div className="inline-tooltip">We are hiring!</div>
                  ) : null}
                </h1>
              </div>

              <div className="col-sm-5 col-xs-12">
                <p className="color-grey-secondary indent-padding">
                  Well, there's more to us than just planning trips for
                  wanderlusts. Starting from data scientists to marketing
                  mavericks - our superheroes possess a variety of superpowers!
                  Now, let's talk about you. Are you someone who is passionate
                  about learning and scaling? Can you binge-watch product
                  launches? Are you that code-guru who is addicted to writing
                  thousands and thousand lines of code without breaking a sweat?
                  Awesome! You'll feel right at home in Pickyourtrail. Go on,
                  see where you fit in Pickyourtrail and let's unwrap the world
                  together!
                </p>
              </div>
              <div className="col-sm-6 col-sm-offset-1 col-xs-12 col-xs-offset-0 hidden-xs">
                <AlumniSpeakSlider
                  alumniData={
                    (this.props.careers && this.props.careers.alumniSpeaks) ||
                    null
                  }
                />
              </div>
            </div>
          </div>
        </section>

        {/* Our values starts */}
        <OurValues />
        {/* Our values ends */}

        <OpenPositions careersData={this.props.careers || null} />

        <LifeAt />

        {this.state.isOpen ? (
          <MileStoneModal
            isOpen={this.state.isOpen}
            index={this.state.index}
            dataSource={mileStoneData.data}
            closeModal={this.closeModal}
          />
        ) : null}
      </section>
    );
  }
}

function mapStateToProps(state) {
  return {
    careers: state.careers ? state.careers.careersData : null,
    user_details: state.app.user_details,
    jobDetail: state.app.jobDetail
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getCareersContent: bindActionCreators(getCareersContent, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Careers);
