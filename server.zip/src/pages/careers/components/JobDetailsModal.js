import React, { Component } from "react";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { fetchJobDetail } from '../../../actions/actions_app';
import classNames from "classnames";
import { onceModalClosed, onceModalOpened, isMobile } from "../../../helpers/utilsHelper";
import { trackPage, PAGE_CAREERS } from "../../../helpers/ML/EventsTracker";

class JobDetailsModal extends Component {

  state = {
    isOpen: true
  }

  /**
   * This lifecycle method will be triggered once on DOM mounting
   */
  componentDidMount() {
    const { match={}, jobDetail={} } = this.props;
    if(!Object.keys(jobDetail).length) {
      trackPage(PAGE_CAREERS, {
        position_name: jobDetail.roleName
      });
      this.props.actions.fetchJobDetail(match.params && match.params.currentOpeningKey)
    }

    onceModalOpened();
    document.addEventListener('keyup', this.handleKeyUp);
  }

  closeModal = () => {
    this.setState({
      isOpen: false
    }, () => {
      this.props.history.push('/careers');
      onceModalClosed();
      this.props.actions.clearJobDetail();
    });
  }

  handleKeyUp = (e) => {
    if (e.keyCode === 27) this.closeModal();
  }

  /**
   * This lifecycle method will be triggered once on Component Unmounting
   */
  componentWillUnmount() {
    onceModalClosed();
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  render() {
    const { isOpen } = this.state;
    const { jobDetail={} } = this.props;
    const { roleName, roleDesc, reqExperience, type, atsUrl } = jobDetail;
    
    if(!Object.keys(jobDetail).length) return null;

    return (
      <div
        className={classNames(
          "modal fade modal-sticky-header milestone-modal",
          {
            in: isOpen
          }
        )}
      >
        <div className="modal-dialog">
          <div className="modal-content with-header">
            <div className="modal-header">
              {
                isMobile() ? null : <span>{roleName}</span>
              }
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                onClick={this.closeModal}
              >
                <i className="vehoicon-close" />
              </button>
            </div>

            <div className="modal-body">
              <div className="row">
                <div className="col-sm-12">
                  {
                    isMobile() ? 
                      <h2>{roleName}</h2>
                      : null
                  }
                  <p>{roleDesc}</p>
                </div>
              </div>
              <div className="row vertical-center">
                <div className="col-xs-6">
                  <a href={atsUrl} target="_blank" className="color-grey main-para">Read more</a>
                </div>
                <div className="col-xs-6">
                  <a href={atsUrl} target="_blank" className="btn btn-primary pull-right">Apply Now</a>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    jobDetail: state.app.jobDetail ? state.app.jobDetail : {}
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    actions: {
      fetchJobDetail: bindActionCreators(fetchJobDetail, dispatch),
      clearJobDetail: () => {
        dispatch({
          type: 'CLEAR_CAREERS_DETAIL'
        });
      }
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(JobDetailsModal);
