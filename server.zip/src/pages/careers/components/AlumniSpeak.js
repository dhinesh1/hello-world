import React, { PureComponent, Component } from 'react';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

export class AlumniSpeak extends PureComponent {
  render() {
    let {
      description,
      facebookLink,
      linkedinLink,
      name,
      profileImg,
      team
    } = this.props;

    return (
      <div className={'alumni-content'}>
        <p>{description}</p>
        <div className={'profile-details'}>
          <img alt={'alumni-img'} src={getImgIXUrl(profileImg)} />
          <div className={''}>
            <span className={'profile-name'}>{name}</span>
            {facebookLink ? (
              <a href={facebookLink}>
                {' '}
                <span className={'vehoicon-facebook-square'} />
              </a>
            ) : null}
            {linkedinLink ? (
              <a href={linkedinLink}>
                {' '}
                <span className={'vehoicon-linkedin'} />
              </a>
            ) : null}
          </div>
          <span className={'alumni-department'}>{team}</span>
        </div>
      </div>
    );
  }
}

class AlumniSpeakSlider extends Component {
  state = {
    currentContent: 0
  };

  render() {
    if (!this.props.alumniData) return null;

    let { currentContent } = this.state;
    let currentOpening = this.props.alumniData[currentContent] || {};

    return (
      <div className={'alumni-testimonials-container'}>
        <div className={'alumni-header'}>
          <h2>Alumni speak</h2>

          <div className={'nav-buttons'}>
            <button
              disabled={currentContent === 0}
              onClick={() => {
                let newVal = currentContent - 1;
                this.setState({ currentContent: newVal });
              }}
              className={'btn btn-sm btn-default btn-outline'}
            >
              <span className={'vehoicon-left'} />
            </button>{' '}
            <button
              disabled={currentContent === this.props.alumniData.length - 1}
              onClick={() => {
                let newVal = currentContent + 1;
                this.setState({ currentContent: newVal });
              }}
              className={'btn btn-sm btn-default btn-outline'}
            >
              <span className={'vehoicon-left rotate-180'} />
            </button>
          </div>
        </div>

        <AlumniSpeak {...currentOpening} />
      </div>
    );
  }
}

export default AlumniSpeakSlider;
