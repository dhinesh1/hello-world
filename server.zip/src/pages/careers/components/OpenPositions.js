import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';
import Collapsible from 'react-collapsible';
import Scroll from 'react-scroll';
import LazyLoadComponent from '../../../common_components/LazyLoadComponent';
import { getImgIXUrl } from '../../../helpers/utilsHelper';
const Element = Scroll.Element;
const ScrollLink = Scroll.Link;

const ContentBlock = ({ description, roles, forMobile }) => {
  let block = (
    <Fragment>
      <p>{description}</p>
      <ul className="list-unstyled">
        {roles.map((item, i) => {
          return (
            <li key={item.code + i}>
              <Link to={`/careers/${item.openingsKey}`}>
                {item.roleName}
                <b>{item.reqExperience} YEARS EXPERIENCE</b>
              </Link>
            </li>
          );
        })}
      </ul>
    </Fragment>
  );

  if (forMobile) return block;
  return <div className={'col-sm-6'}>{block}</div>;
};

const ImageBlock = ({
  position = '',
  size,
  name,
  primaryImg,
  secondaryImg,
  forMobile
}) => {
  let block = (
    <div className={`image-block ${position} ${size}`}>
      <span>
        <b>{name}</b>
      </span>
      <LazyLoadComponent>
        <div
          className="primary-img"
          style={{ backgroundImage: `url('${getImgIXUrl(primaryImg)}')` }}
        />
        <div
          className="secondary-img"
          style={{ backgroundImage: `url('${getImgIXUrl(secondaryImg)}')` }}
        />
      </LazyLoadComponent>
    </div>
  );

  if (forMobile) {
    return block;
  }
  return <div className={'col-sm-6'}>{block}</div>;
};

class TeamCategoryBlock extends Component {
  render() {
    const {
      teamId,
      name,
      primaryImg,
      secondaryImg,
      description = '',
      roles = [],
      contentFirst = true,
      index
    } = this.props;

    const contentProps = {
      description,
      roles
    };
    const imageBlockProps = {
      name,
      primaryImg,
      secondaryImg,
      size: roles.length < 5 ? 'small-block' : ''
    };

    const scrollTarget = name.toLowerCase().replace(/\s/g, '-');
    return (
      <Fragment>
        <Element name={scrollTarget} className="row team-positions hidden-xs">
          {contentFirst ? (
            <Fragment>
              <ContentBlock {...contentProps} />
              <ImageBlock {...imageBlockProps} />
            </Fragment>
          ) : (
            <Fragment>
              <ImageBlock {...imageBlockProps} position="left" />
              <ContentBlock {...contentProps} />
            </Fragment>
          )}
        </Element>
        <Collapsible
          open={index === 0}
          triggerTagName={'div'}
          triggerOpenedClassName={'row-expanded'}
          contentInnerClassName={'team-positions'}
          classParentString="visible-xs Collapsible"
          trigger={<h5>{imageBlockProps.name}</h5>}
        >
          <ImageBlock {...imageBlockProps} forMobile />
          <ContentBlock {...contentProps} forMobile />
        </Collapsible>
      </Fragment>
    );
  }
}

class OpenPositions extends Component {
  render() {
    let { careersData = [] } = this.props;

    if (!careersData) return null;

    return (
      <section className="open-positions">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <h4 className="bold mbottom-medium">Open Positions</h4>
              <ul className="list-unstyled team-category hidden-xs">
                {careersData.careerTeams.map(item => {
                  const scrollTarget = item.name
                    .toLowerCase()
                    .replace(/\s/g, '-');
                  return (
                    <li key={item.teamId}>
                      <ScrollLink
                        to={scrollTarget}
                        spy={true}
                        smooth={true}
                        duration={500}
                        offset={-144}
                        className="pill-outline bg base"
                      >
                        {item.name}
                      </ScrollLink>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
          {careersData.careerTeams.map((item, i) => {
            return (
              <TeamCategoryBlock
                key={item.teamId}
                contentFirst={i % 2 === 0}
                index={i}
                {...item}
                roles={careersData.careersMap[item.teamId]}
              />
            );
          })}
        </div>
      </section>
    );
  }
}

export default OpenPositions;
