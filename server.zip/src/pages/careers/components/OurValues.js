import React from 'react';
import LazyLoadComponent from '../../../common_components/LazyLoadComponent';
import { getImgIXUrl } from '../../../helpers/utilsHelper';

const OurValues = () => (
  <section className={'our-values'}>
    <div className={'container'}>
      <h3>Our values</h3>
      <ul className={'clearfix list-unstyled'}>
        <li>
          <LazyLoadComponent>
            <img
              className={'our-values-1'}
              src="https://pyt-images.imgix.net/images/web_app/careers/core-value-1.png"
              alt={'core-value-1'}
            />
          </LazyLoadComponent>
          <div className={'content-holder'}>
            <h4>Results Over Reason</h4>
            <p>
              To value actions over intentions and demonstrate high levels of
              perseverance
            </p>
          </div>
        </li>

        <li>
          <LazyLoadComponent>
            <img
              className={'our-values-2'}
              src="https://pyt-images.imgix.net/images/web_app/careers/core-value-2.png"
              alt={'core-value-1'}
            />
          </LazyLoadComponent>
          <div className={'content-holder'}>
            <h4>Innovation</h4>
            <p>
              Bring in a fresh pair of eyes to every situation. Question the
              status quo without fear.
            </p>
          </div>
        </li>

        <li>
          <LazyLoadComponent>
            <img
              className={'our-values-3'}
              src="https://pyt-images.imgix.net/images/web_app/careers/core-value-3.png"
              alt={'core-value-1'}
            />
          </LazyLoadComponent>
          <div className={'content-holder'}>
            <h4>Communication</h4>
            <p>
              Listen well, write concisely, articulate clearly and understand
              before you respond.
            </p>
          </div>
        </li>

        <li>
          <LazyLoadComponent>
            <img
              className={'our-values-4'}
              src="https://pyt-images.imgix.net/images/web_app/careers/core-value-4.png"
              alt={'core-value-1'}
            />
          </LazyLoadComponent>
          <div className={'content-holder'}>
            <h4>Empathy</h4>
            <p>
              Put ourselves in the shoes of the customers and co-workers and do
              what’s best for them.
            </p>
          </div>
        </li>
      </ul>
    </div>
  </section>
);

export default OurValues;
