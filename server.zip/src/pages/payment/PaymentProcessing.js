import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  checkPaymentStatus,
} from '../../actions/actions_app';
import { clearAllTimeouts } from '../../helpers/utilsHelper';
import { itineraryModalsRouteHelper, routingPageType } from '../../helpers/routesHelper';
import { LoadingBars } from '../../helpers/loaderHelper';
import { PropTypes } from 'prop-types';

class PaymentProcessing extends Component {
  // Adding prop type validators for this component
  static propTypes = {
    paymentResponse: PropTypes.object,
    paymentStatus: PropTypes.object,
    paymentProcessing: PropTypes.object,
    paymentFailure: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
    history: PropTypes.object.isRequired,
    actions: PropTypes.object,
  }

  state = {
    checkedPaymentStatusOnce: false
  }
  
  componentDidMount() {
    const { paymentProcessing, history, match } = this.props;

    if(paymentProcessing && paymentProcessing.data && !paymentProcessing.paymentValid) {
      const location = (window || { location: {} }).location;
      const document = (window || { document: {} }).document;
      const isMobileApp = JSON.parse(localStorage.getItem('mobileAppDetails')) && document && location;
      if (isMobileApp) {
        localStorage.removeItem('mobileAppDetails');
        document.location.href = location.origin + `/payment/failure`;
      } else {
        history.replace(`/payment/failure`);
      }
    } else {
      /**
       * If payment response is not there in store - which means the page got reloaded / the page visited directly 
       * with the URL (not part of the payment process)
       * In such case Will redirect the user back to home page
       * Also moved the verify payment call to node server side - to avoid an extra hop between server to client - 
       * this will ensure our backend server got whatever we received from the PG-end also this 
       * ensure the data is not tampered on the client end - entire process will happen on server
       */
      if (!paymentProcessing) {
        // Home page has to hard-loaded using window to render it properly on server - required for SSR pages
        const { itineraryid } = match.params || {};
        if(itineraryid)
          window.location.href = "/customize/region/view/"+itineraryid;
        else
          window.location.href = "/";
      } else {
        const { itineraryId, paymentType } = paymentProcessing;
    
        // Trigger payment status check API
        this.props.actions.checkPaymentStatus({ itineraryId, paymentType });
      }
  
    }
  }

  /**
   * Moved this functionality to componentDidUpdate as 
   * componentWillReceiveProps(nextProps) is deprecated in recent react versions
   */
  componentDidUpdate() {
    let { paymentProcessing, paymentStatus, history } = this.props;

    const { itineraryId, paymentType, udf1 } = paymentProcessing;
    const reqObj = { itineraryId, paymentType };
    let location = (window || { location: {} }).location;
    let document = (window || { document: {} }).document;
    let isMobileApp =
      JSON.parse(localStorage.getItem('mobileAppDetails')) &&
      document &&
      location;

    if (paymentStatus && Object.keys(paymentStatus).length) {
      const inclusionsPagePath = itineraryModalsRouteHelper({
        itineraryId: udf1,
        regionCode: "region",
        parentPage: routingPageType.inclusion
      });

      switch (paymentStatus.paymentStatus) {
        case 'SUCCESS':
          clearAllTimeouts();
          if (isMobileApp) {
            localStorage.removeItem('mobileAppDetails');
            document.location.href = location.origin + `/payment/success`;
          } else {
            history.replace(`/payment/success`);
          }
          break;
        case 'FAILURE':
          clearAllTimeouts();
          if (isMobileApp) {
            localStorage.removeItem('mobileAppDetails');
            document.location.href = location.origin + `/payment/failure`;
          } else {
            history.replace(`/payment/failure`);
          }
          break;
        case 'CANCEL':
          clearAllTimeouts();
          if (isMobileApp) {
            localStorage.removeItem('mobileAppDetails');
            document.location.href = location.origin + inclusionsPagePath;
          } else {
            history.replace(inclusionsPagePath);
          }
          break;
        case 'INITIATE':
        case 'PENDING':
        case 'PROCESSING':
          setTimeout(() => {
            this.props.actions.checkPaymentStatus(reqObj);
          }, 5000);
          break;
        default:
          break;
      }
    } else {
      if (!this.state.checkedPaymentStatusOnce) {
        this.props.actions.checkPaymentStatus(reqObj);

        this.setState({ checkedPaymentStatusOnce: true });
      }
    }
  }

  render() {
    return (
      <div className="container text-center">
        <div className={'clearfix double-spacer-both'} />
        <div className={'clearfix double-spacer-both'}>
          <p className={'large-heading bold'}>
            Please wait as we connect with our partners to confirm your payment.
          </p>
          <p className={'light fade'}>
            Don't close or refresh this page please!
          </p>
        </div>
        <LoadingBars />
      </div>
    );
  }
}

function mapStateToProps(state) {
  return { ...state.payment };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      checkPaymentStatus: bindActionCreators(checkPaymentStatus, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(PaymentProcessing);
