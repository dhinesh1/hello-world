import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Link } from 'react-router-dom';
import { paymentFailure } from '../../actions/actions_app';
import { hideChatIconOnMobile } from '../../helpers/utilsHelper';
import { PropTypes } from 'prop-types';
import {
  trackEvent,
  EVENT_PAYMENT_FAILED
} from '../../helpers/ML/EventsTracker';

class PaymentFailure extends Component {
  // Adding prop type validators for this component
  static propTypes = {
    paymentStatus: PropTypes.object.isRequired,
    paymentProcessing: PropTypes.object.isRequired
  };

  componentDidMount() {
    let isVoyagerApp = JSON.parse(localStorage.getItem('mobileAppDetails'));
    if (isVoyagerApp) {
      hideChatIconOnMobile();
    }

    trackEvent(EVENT_PAYMENT_FAILED);

    const { paymentStatus, paymentProcessing } = this.props;
    // Check if paymentStatus and paymentProcessing in the Redux store.
    // if it's not there we should redirect the user to homepage as this only happen while page accessed directly / reload
    // Prevously it was handled in <Redirect /> component of react-router-dom which will replace the existing entry in the history object -
    // and home page needs to be reloaded to SSR-ed
    if (!paymentProcessing && !paymentStatus) {
      window.location.href = '/';
    }
  }
  render() {
    const { paymentStatus, paymentProcessing } = this.props;

    // Removed else {} which will never be render in the life-cycle. Also it had default content while we design and misleading / not work for the user.
    if (paymentProcessing && paymentStatus) {
      return (
        <section className="payment-failure">
          <div className="container xs-full-width">
            <div className="row">
              <div className="col-xs-12 text-center">
                <div className="failure-container">
                  <span className="paymentfailure-img" />
                  <h2 className="large-heading">
                    Oops! Your transaction didn’t go through.
                  </h2>
                  <p className="payment-gateway">
                    This usually happens when the payment gateway encounters a
                    problem while processing your payment. Please click here to{' '}
                    <Link
                      key={'navPaymentProcessing'}
                      to={
                        '/customize/region/view/' +
                        paymentProcessing.itineraryId
                      }
                    >
                      Go back and retry payment
                    </Link>
                  </p>
                  <div className="payment-failure-table vmargin-medium">
                    <p className="imps-txt">
                      Alternatively you can make an IMPS transfer for{' '}
                      <span className="semi-bold">
                        {paymentProcessing.amount}
                      </span>{' '}
                      &amp; mention the trip ID{' '}
                      <span className="semi-bold">
                        {paymentProcessing.tripId}
                      </span>{' '}
                      as transaction remark
                    </p>
                    <table className="table">
                      <tbody>
                        <tr>
                          <td>Bank Name</td>
                          <td>HSBC Bank</td>
                        </tr>
                        <tr>
                          <td>Branch</td>
                          <td>Chennai Main Branch</td>
                        </tr>
                        <tr>
                          <td>IFSC Code</td>
                          <td>HSBC0600002</td>
                        </tr>
                        <tr>
                          <td>Account Type</td>
                          <td>Current Account</td>
                        </tr>
                        <tr>
                          <td>Swift Code</td>
                          <td>HSBCINBB</td>
                        </tr>
                        <tr>
                          <td>Beneficiary Name</td>
                          <td>Travel Troops Global Pvt Ltd</td>
                        </tr>
                        <tr>
                          <td>Beneficiary Account Number</td>
                          <td>{paymentProcessing.virtualAccountNumber}</td>
                        </tr>
                        {/*
                        <tr>
                          <td>UPI Id</td>
                          <td>
                            <span>pickyourtrail@hdfcbank</span>
                          </td>
                        </tr>*/}
                      </tbody>
                    </table>
                  </div>
                  <p className="vmargin-small footer-txt">
                    For questions regarding this booking, email{' '}
                    <a href="mailto:ops@pickyourtrail.com">
                      ops@pickyourtrail.com
                    </a>{' '}
                    or call us on{' '}
                    <span className="semi-bold">+91 7358154141</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      );
    } else {
      return null;
    }
  }
}

function mapStateToProps(state) {
  return {
    ...state.payment
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      paymentFailure: bindActionCreators(paymentFailure, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(PaymentFailure);
