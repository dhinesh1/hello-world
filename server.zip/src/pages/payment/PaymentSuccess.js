import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import PropTypes from 'prop-types';
import { trackEvent, EVENT_PAYMENT_SUCCESS } from '../../helpers/ML/EventsTracker';

class PaymentSuccess extends Component {
  // Adding prop type validators for this component
  static propTypes = {
    paymentStatus: PropTypes.object.isRequired
  };

  componentDidMount() {
    trackEvent(EVENT_PAYMENT_SUCCESS);
    // trackEvent(EVENT_BOOKING_COMPLETED);
    // Check if paymentStatus and paymentProcessing in the Redux store.
    // if it's not there we should redirect the user to homepage as this only happen while page accessed directly / reload
    // Prevously it was handled in <Redirect /> component of react-router-dom which will replace the existing entry in the history object -
    // and home page needs to be reloaded to SSR-ed
    if (!this.props.paymentStatus) {
      window.location.href = '/';
    }
  }

  render() {
    let { paymentStatus } = this.props;
    if (paymentStatus && paymentStatus.paymentStatus === 'SUCCESS') {
      return (
        <div>
          <div className="container">
            <section className="row payment-success mbottom-large">
              <div className="col-xs-12 col-sm-4 col-md-4 text-center">
                <span className="happy-vacations" />
              </div>
              <div className="col-xs-12 col-sm-8 col-md-8">
                <h2 className="xs-text-center">
                  Your payment of &#8377;{paymentStatus.paidAmount} towards the
                  booking of your vacation to {paymentStatus.regionCode} is
                  successful.
                </h2>
                <ul className="list-unstyled mb-0">
                  <li>
                    Please note your transaction ID -{' '}
                    <b>{paymentStatus.transactionId}</b>
                  </li>
                  <li>Your vouchers will be emailed to you shortly</li>
                  <li>
                    Visit{' '}
                    <a href="/your-vacations" target="_blank">
                      Your Vacations
                    </a>{' '}
                    for Visa guidelines, packing checklists, destination guides
                    and more.
                  </li>
                </ul>
              </div>
            </section>
          </div>

          <div className="balloon-wrapper fly-fully hidden-xs">
            <div className="balloon">
              <span className="balloon-inner">
                <i className="vehoicon-directions_car" />
              </span>
            </div>
            <div className="balloon">
              <span className="balloon-inner">
                <i className="vehoicon-local_play" />
              </span>
            </div>
            <div className="balloon">
              <span className="balloon-inner">
                <i className="vehoicon-flight" />
              </span>
            </div>
            <div className="balloon">
              <span className="balloon-inner">
                <i className="vehoicon-airline_seat_individual_suite" />
              </span>
            </div>
          </div>
        </div>
      );
    } else if (paymentStatus) {
      return <Redirect to={`/customize/region/view/${paymentStatus.itineraryId}`} />;
    } else {
      return null;
    }
  }
}

function mapStateToProps(state) {
  return {
    ...state.payment
  };
}

export default connect(mapStateToProps)(PaymentSuccess);
