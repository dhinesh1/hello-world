import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import classNames from 'classnames';
import _ from 'lodash';
import { login } from '../actions/actions_login_app';

class AgentLogin extends Component {
  constructor(props) {
    super(props);

    this.state = {
      agentId: '',
      password: '',
      loginError: false,
      loginErrorResponse: '',

      validationState: {
        agentIdInvalid: false,
        passwordInvalid: false
      }
    };

    this.triggerLogin = this.triggerLogin.bind(this);
    this.triggerValidation = this.triggerValidation.bind(this);
    this.onInputChange = this.onInputChange.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    // console.log(nextProps);

    if (nextProps.app.action) {
      let currentState = this.state;
      currentState.loginError =
        nextProps.app.action === 'LOGIN_ERROR' || 'NOT_FOUND';
      if (currentState.loginError) {
        currentState.loginErrorResponse = nextProps.app.response;
        currentState.validationState.agentIdInvalid = true;
        currentState.validationState.passwordInvalid = true;
      }

      this.setState({ ...currentState });
    }
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  onInputChange(e) {
    let currentState = this.state;
    currentState[e.target.name] = e.target.value;

    this.setState({ ...currentState });
  }

  triggerValidation() {
    let validationState = this.state.validationState;
    let { agentId, password } = this.state;

    validationState.agentIdInvalid = !agentId.trim().length;
    validationState.passwordInvalid = !password.trim().length;

    // console.log(validationState.agentIdInvalid);
    // console.log(validationState.passwordInvalid);
    this.setState({ validationState });
    // console.log(validationState);
    // console.log(_.every(_.valuesIn(validationState), e => !e));
    return _.every(_.valuesIn(validationState), e => !e);
  }

  triggerLogin(e) {
    e && e.preventDefault();

    if (this.triggerValidation()) {
      // console.log('form validated');

      let { agentId, password } = this.state;

      //   agentId = agentId.replace(/\D/g, '');

      let reqData = {
        agentId: agentId,
        password: password
      };
      this.props.actions.login({
        req_data: reqData,
        isItineraryView: false,
        getCostObject: null,
        history: null,
        loginType: 'AGENT',
      })
    } else {
      // console.log('form has errors');
    }
  }

  render() {
    let {
      agentId,
      password,
      validationState,
      loginError,
      loginErrorResponse
    } = this.state;

    return (
      <div className="container">
        <div className="row">
          <div className="col-xs-12">
            <div className="agents-login-container">
              <form id="agent-login-form" autoComplete="off">
                <input type="text" style={{ display: 'none' }} />
                <input type="password" style={{ display: 'none' }} />
                <div
                  className={classNames('form-group', {
                    'has-error': validationState.agentIdInvalid
                  })}
                >
                  <div className="clearfix small">
                    <label className="control-label">Agent ID</label>
                  </div>
                  <input
                    type="text"
                    className="form-control"
                    id="agent_username"
                    name={'agentId'}
                    autoComplete="off"
                    onChange={this.onInputChange}
                    value={agentId}
                  />
                </div>
                <div
                  className={classNames('form-group', {
                    'has-error': validationState.passwordInvalid
                  })}
                >
                  <div className="clearfix small">
                    <label className="control-label">Password</label>
                  </div>
                  <input
                    type="password"
                    className="form-control"
                    id="agent_login_password"
                    name={'password'}
                    onChange={this.onInputChange}
                    value={password}
                  />
                  {loginError ? (
                    <span className="help-block">{loginErrorResponse}</span>
                  ) : null}
                </div>
                <div className="form-group" id="login-cta">
                  <button
                    type="submit"
                    className="btn btn-primary btn-lg btn-block"
                    onClick={this.triggerLogin}
                  >
                    Login
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      login: bindActionCreators(login, dispatch)
    }
  };
}

export default connect(state => state, mapDispatchToProps)(AgentLogin);
