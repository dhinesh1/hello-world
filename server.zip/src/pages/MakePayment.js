import React, { Component, Fragment } from 'react';
import PaymentOptions from '../common_components/PaymentOptions';
import WizardHeader from './booking/components/WizardHeader';
import PaymentInfoBlock from './booking/components/PaymentInfoBlock';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import {
  getLivePrice,
  generateAndSentOTP,
  verifyAdminBookingOTP,
  proceedWithoutBooking,
  setCounterAlert
} from '../actions/actions_app';
import {
  hideChatIconOnMobile,
  is_server,
  isFaqMobile
} from '../helpers/utilsHelper';
import SweetAlert from 'sweetalert-react';
import Loader from '../common_components/Loader';
import {itineraryModalsRouteHelper, routingPageType} from '../helpers/routesHelper';
import { Redirect } from 'react-router-dom';

class MakePayment extends Component {
  constructor(props) {
    super(props);
    this.state = {
      termsConditionsAccepted: false,
      highlightTerms: false,
      adminBookingFlow: {
        action: '',
        reason: '',
        otp: '',
        otherReason: false
      },
      showOtpSendErrorModal: false,
      showSweetAlert: false,
      showBookingFailureModal: false,
      sweetalertContent: {
        title: '',
        text: '',
        type: '',
        confirmButtonText: ''
      },
      validations: {
        otpValid: true,
        otherReasonValid: true
      }
    };
    this.handleTncChange = this.handleTncChange.bind(this);
    this.addErrorClassToTnC = this.addErrorClassToTnC.bind(this);
    this.generateOTP = this.generateOTP.bind(this);
    this.setSelectedReason = this.setSelectedReason.bind(this);
    this.setSelectedAction = this.setSelectedAction.bind(this);
    this.verifyOTP = this.verifyOTP.bind(this);
    this.otpOnChangeHandler = this.otpOnChangeHandler.bind(this);
    this.moveToBooking = this.moveToBooking.bind(this);
    this.otherReasonChangeHandler = this.otherReasonChangeHandler.bind(this);
    this.validateInputs = this.validateInputs.bind(this);
  }

  componentDidMount() {
    hideChatIconOnMobile();
    const itineraryId = this.props.match && this.props.match.params.itineraryId;

    const details =
      this.props.app && this.props.app.itineraryInfo.itineraryDetails;
    if (this.props.history && (!details || (details && !details.livePrice))) {
      this.props.history.push(`/booking-review/${itineraryId}`);
    }
    this.toggleCounterElement(true);
  }

  toggleCounterElement(isEnable) {
    let isMobile = isFaqMobile();
    let counterElement = document.querySelector(
      isMobile ? '#mobile-timer' : '#desktop-timer'
    );
    if (counterElement && counterElement.classList) {
      counterElement.classList[isEnable ? 'remove' : 'add']('hide');
    }
  }

  validateInputs() {
    let tempState = this.state;
    tempState.validations.otpValid =
      tempState.adminBookingFlow.otp.length === 6;
    tempState.validations.otherReasonValid =
      tempState.adminBookingFlow.reason.length >= 3;

    this.setState(tempState);

    if (tempState.adminBookingFlow.action === 'ACTUALBOOKING') {
      return (
        tempState.validations.otpValid && tempState.validations.otherReasonValid
      );
    } else {
      return tempState.validations.otherReasonValid;
    }
  }
  componentWillUnmount() {
    this.toggleCounterElement(false);
  }
  componentWillReceiveProps(nextProps) {
    let tempState = this.state;

    if (tempState.adminBookingFlow.action === 'ACTUALBOOKING') {
      if (
        nextProps.app.otpFailureResponse ||
        nextProps.app.adminBookingSuccess ||
        nextProps.app.adminBookingFailure
      ) {
        tempState.showOtpSendErrorModal = nextProps.app.otpFailureResponse;

        if (nextProps.app.adminBookingSuccess) {
          tempState.showSweetAlert = true;
          tempState.sweetalertContent.title = `Booking process started successfully`;
          tempState.sweetalertContent.text =
            nextProps.app.adminBookingSuccess.message;
          tempState.sweetalertContent.type = `success`;
          tempState.sweetalertContent.confirmButtonText = `Go to the itinerary page`;
        } else if (nextProps.app.adminBookingFailure) {
          tempState.showSweetAlert = true;
          tempState.sweetalertContent.title = `Something went wrong`;
          tempState.sweetalertContent.text =
            nextProps.app.adminBookingFailure.message &&
            nextProps.app.adminBookingFailure.message.length > 0
              ? nextProps.app.adminBookingFailure.message
              : `Unknown error occurred while try to process your admin booking. Please try again later`;
          tempState.sweetalertContent.type = `error`;
          tempState.sweetalertContent.confirmButtonText = `Okay`;
        }

        this.setState(tempState);
      }
    } else if (
      nextProps.app.adminMovetoBookingSuccess ||
      nextProps.app.adminMovetoBookingFailure
    ) {
      if (nextProps.app.adminMovetoBookingSuccess) {
        tempState.showSweetAlert = true;
        tempState.sweetalertContent.title = `Moved to booking successfully`;
        tempState.sweetalertContent.text = `This itinerary is moved to booking stage.`;
        tempState.sweetalertContent.type = `success`;
        tempState.sweetalertContent.confirmButtonText = `Go to the itinerary page`;
      } else {
        tempState.showSweetAlert = true;
        tempState.sweetalertContent.title = `Unable to move to booking`;
        tempState.sweetalertContent.text = `Something went wrong while moving the itinerary to booking`;
        tempState.sweetalertContent.type = `error`;
        tempState.sweetalertContent.confirmButtonText = `Okay`;
      }

      this.setState(tempState);
    }
  }

  handleTncChange(e) {
    let highlightTerms = this.state.termsConditionsAccepted;
    this.setState({
      termsConditionsAccepted: e.target.checked,
      highlightTerms: highlightTerms
    });
  }

  addErrorClassToTnC() {
    this.setState({ highlightTerms: false }, () => {
      this.setState({ highlightTerms: true });
    });
  }

  setSelectedAction(e) {
    let tempState = this.state;
    tempState.adminBookingFlow.action = e.target.value;
    tempState.adminBookingFlow.reason = '';
    tempState.adminBookingFlow.otherReason = false;
    this.setState(tempState);
  }

  otpOnChangeHandler(e) {
    let tempState = this.state;
    tempState.adminBookingFlow.otp = e.target.value;
    this.setState(tempState);
  }

  otherReasonChangeHandler(e) {
    let tempState = this.state;
    tempState.adminBookingFlow.reason = e.target.value;
    this.setState(tempState);
  }

  setSelectedReason(e) {
    let tempState = this.state;
    tempState.adminBookingFlow.reason = e.target.value;
    if (tempState.adminBookingFlow.reason === 'Other') {
      tempState.adminBookingFlow.reason = '';
      tempState.adminBookingFlow.otherReason = true;
    } else {
      tempState.adminBookingFlow.otherReason = false;
    }
    this.setState(tempState);
  }

  generateOTP() {
    let itineraryId = this.props.app.itineraryInfo.itineraryDetails.itinerary
      .itineraryId;
    this.props.actions.generateAndSentOTP({
      offlineItineraryId: itineraryId,
      reason: this.state.adminBookingFlow.reason
    });
  }

  verifyOTP() {
    if (this.validateInputs()) {
      let itineraryId = this.props.app.itineraryInfo.itineraryDetails.itinerary
        .itineraryId;
      this.props.actions.verifyAdminBookingOTP({
        offlineItineraryId: itineraryId,
        reason: this.state.adminBookingFlow.reason,
        otp: this.state.adminBookingFlow.otp
      });
    }
  }

  moveToBooking() {
    if (this.validateInputs()) {
      let itineraryId = this.props.app.itineraryInfo.itineraryDetails.itinerary
        .itineraryId;
      this.props.actions.proceedWithoutBooking({
        booked: true,
        itineraryId: itineraryId,
        reason: this.state.adminBookingFlow.reason
      });
    }
  }

  render() {
    let { app, match } = this.props;
    let { user_details } = app;
    let {
      highlightTerms,
      termsConditionsAccepted,
      sweetalertContent,
      validations,
      adminBookingFlow
    } = this.state;
    let { itineraryDetails } = app.itineraryInfo;
    
    if(!itineraryDetails || (itineraryDetails && !itineraryDetails.livePrice)){
      const itineraryId = match && match.params.itineraryId;

      return <Redirect to={`/booking-review/${itineraryId}`} />
    }

    const inclusionsPagePath = itineraryModalsRouteHelper({
      itineraryId: itineraryDetails.itinerary.itineraryId,
      regionCode: itineraryDetails.itinerary.regionCode,
      parentPage: routingPageType.inclusion
    });
      
    if (
      user_details &&
      (user_details.userType === 'USER' || user_details.userType === 'AGENT')
    ) {
      return (
        <div className="clearfix booking-pages">
          {app.itineraryInfo && app.itineraryInfo.itineraryDetails ? (
            <WizardHeader
              stepTitle={'Make payment'}
              itineraryId={
                app.itineraryInfo.itineraryDetails.itinerary.itineraryId
              }
              prevStepUrl={`/booking-review/${
                app.itineraryInfo.itineraryDetails.itinerary.itineraryId
              }`}
              activeTab={3}
            />
          ) : (
            <Loader showLoading />
          )}
          <SweetAlert
            show={app.showAlert}
            title="Oh-oh"
            text={`Your 10 minutes are up! The current trip cost would have changed by now. Go back and finish the entire booking process immediately to ensure your total costs remain intact.`}
            animation="pop"
            confirmButtonText={'Go back to itinerary'}
            confirmButtonColor={'#26CF96'}
            onConfirm={() => {
              this.props.actions.setCounterAlert(false);
              this.props.history.push(inclusionsPagePath);
            }}
          />
          <section className="booking-pages-content no-footer">
            <div className="clearfix payment-container">
              {app.itineraryInfo &&
              app.itineraryInfo.itineraryDetails &&
              app.itineraryInfo.itineraryDetails.paymentSchedule ? (
                <PaymentInfoBlock
                  highlightTerms={highlightTerms}
                  handleTncChange={this.handleTncChange}
                  itineraryDetail={app.itineraryInfo.itineraryDetails}
                  adultCount={app.itineraryInfo.adult_count}
                  childCount={app.itineraryInfo.child_count}
                  itinerary={app.itineraryInfo.itineraryDetails.itinerary}
                />
              ) : null}

              {app.itineraryInfo &&
              app.itineraryInfo.itineraryDetails &&
              app.itineraryInfo.itineraryDetails.paymentSchedule ? (
                <PaymentOptions
                  termsConditionsAccepted={termsConditionsAccepted}
                  userDetails={app.user_details}
                  addErrorClassToTnC={this.addErrorClassToTnC}
                  itineraryDetail={itineraryDetails}
                  paymentScheduleDetail={
                    app.itineraryInfo.itineraryDetails.paymentSchedule
                  }
                />
              ) : null}

              {app.itineraryInfo &&
              app.itineraryInfo.itineraryDetails &&
              app.itineraryInfo.itineraryDetails.paymentSchedule ? (
                <div className="balloon-wrapper stay-bottom hidden-xs">
                  <div className="balloon">
                    <span className="balloon-inner">
                      <i className="vehoicon-directions_car" />
                    </span>
                  </div>
                  <div className="balloon">
                    <span className="balloon-inner">
                      <i className="vehoicon-local_play" />
                    </span>
                  </div>
                  <div className="balloon">
                    <span className="balloon-inner">
                      <i className="vehoicon-flight" />
                    </span>
                  </div>
                  <div className="balloon">
                    <span className="balloon-inner">
                      <i className="vehoicon-airline_seat_individual_suite" />
                    </span>
                  </div>
                </div>
              ) : null}
            </div>
          </section>
        </div>
      );
    } else if (user_details && user_details.userType === 'ADMIN') {
      return (
        <div className="clearfix booking-pages">
          <SweetAlert
            show={this.state.showOtpSendErrorModal}
            title={`Error sending OTP`}
            text={`Something went wrong when sending OTP. Please try again!`}
            animation="pop"
            onConfirm={() => this.setState({ showOtpSendErrorModal: false })}
          />

          <SweetAlert
            show={this.state.showSweetAlert}
            title={sweetalertContent.title}
            text={sweetalertContent.text}
            animation="pop"
            type={sweetalertContent.type}
            confirmButtonText={sweetalertContent.confirmButtonText}
            onConfirm={() => {
              this.setState({ showSweetAlert: false });
              if (
                (app.adminBookingSuccess || app.adminMovetoBookingSuccess) &&
                !is_server()
              ) {
                window.location = inclusionsPagePath;
              }
            }}
          />

          {app.itineraryInfo && app.itineraryInfo.itineraryDetails ? (
            <WizardHeader
              stepTitle={'Make payment'}
              itineraryId={
                app.itineraryInfo.itineraryDetails.itinerary.itineraryId
              }
              prevStepUrl={`/booking-review/${
                app.itineraryInfo.itineraryDetails.itinerary.itineraryId
              }`}
              activeTab={3}
            />
          ) : (
            <Loader showLoading />
          )}
          <div className="container vmargin-large">
            <div className="row">
              <div className="col-sm-4 col-sm-offset-4">
                <div className="col-md-12">
                  <div className="form-group">
                    <label className="control-label">Action</label>
                    <div className="custom-select">
                      <select
                        className="form-control"
                        onChange={e => {
                          this.setSelectedAction(e);
                        }}
                      >
                        <option value="">Select</option>
                        <option value="MOVETOBOOKING">
                          Proceed without bookings (Move to booking)
                        </option>
                        <option value="ACTUALBOOKING">
                          Proceed with bookings
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="form-group">
                    <label className="control-label">Reason</label>
                    <div className="custom-select">
                      {adminBookingFlow.action === 'MOVETOBOOKING' ? (
                        <select
                          className="form-control"
                          value={
                            adminBookingFlow.otherReason
                              ? 'Other'
                              : adminBookingFlow.reason
                          }
                          onChange={e => {
                            this.setSelectedReason(e);
                          }}
                        >
                          <option value="">Select</option>
                          <option value="Duplicate Itinerary">
                            Duplicate Itinerary
                          </option>
                          <option value="No product booking possible">
                            No product booking possible
                          </option>
                          <option value="Rate Match">Rate Match</option>
                          <option value="Other">Others</option>
                        </select>
                      ) : (
                        <select
                          value={
                            adminBookingFlow.otherReason
                              ? 'Other'
                              : adminBookingFlow.reason
                          }
                          className={`form-control`}
                          onChange={e => {
                            this.setSelectedReason(e);
                          }}
                        >
                          <option value="">Select</option>
                          <option value="TT Client">TT Client</option>
                          <option value="Offline payment">
                            Offline payment
                          </option>
                          <option value="Other">Others</option>
                        </select>
                      )}
                    </div>
                  </div>
                </div>

                {adminBookingFlow.otherReason ? (
                  <div className="col-md-12">
                    <div
                      className={
                        validations.otherReasonValid
                          ? `form-group form-group-lg`
                          : `form-group form-group-lg has-error`
                      }
                    >
                      <div className="label-animative">
                        <input
                          type="text"
                          className="form-control"
                          onChange={e => {
                            this.otherReasonChangeHandler(e);
                          }}
                          placeholder="Other Reason"
                          autoComplete="off"
                        />
                        <label className="control-label">Other Reason</label>
                        <i className="label-bg" />
                      </div>
                    </div>
                  </div>
                ) : null}

                {adminBookingFlow.action === 'ACTUALBOOKING' &&
                app.otpSuccessResponse &&
                adminBookingFlow.reason !== '' ? (
                  <Fragment>
                    <div className="col-md-12">
                      <div
                        className={
                          validations.otpValid
                            ? `form-group form-group-lg`
                            : `form-group form-group-lg has-error`
                        }
                      >
                        <div className="label-animative">
                          <input
                            onChange={e => {
                              this.otpOnChangeHandler(e);
                            }}
                            type="text"
                            className="form-control"
                            placeholder="OTP"
                            autoComplete="off"
                          />
                          <label className="control-label">OTP</label>
                          <i className="label-bg" />
                        </div>
                      </div>
                    </div>
                    <div className="col-md-12">
                      <button
                        type="button"
                        onClick={this.verifyOTP}
                        className="btn btn-primary-dark btn-block"
                      >
                        Continue
                      </button>
                    </div>
                  </Fragment>
                ) : null}

                <div className="col-md-12 vmargin-medium">
                  {adminBookingFlow.action === '' ||
                  adminBookingFlow.reason === '' ? (
                    <button
                      type="button"
                      onClick={e => e.preventDefault()}
                      disabled
                      className="btn btn-primary-dark btn-block disabled"
                    >
                      Choose any option
                    </button>
                  ) : adminBookingFlow.action === 'ACTUALBOOKING' &&
                  !app.otpSuccessResponse ? (
                    <button
                      type="button"
                      onClick={this.generateOTP}
                      className="btn btn-primary-dark btn-block"
                    >
                      Generate OTP
                    </button>
                  ) : adminBookingFlow.action === 'MOVETOBOOKING' ? (
                    <button
                      type="button"
                      onClick={this.moveToBooking}
                      className="btn btn-primary-dark btn-block"
                    >
                      Move to booking
                    </button>
                  ) : null}
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      return null;
    }
  }
}

function mapStateToProps(state) {
  return {
    ...state
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getLivePrice: bindActionCreators(getLivePrice, dispatch),
      generateAndSentOTP: bindActionCreators(generateAndSentOTP, dispatch),
      verifyAdminBookingOTP: bindActionCreators(
        verifyAdminBookingOTP,
        dispatch
      ),
      proceedWithoutBooking: bindActionCreators(
        proceedWithoutBooking,
        dispatch
      ),
      setCounterAlert: bindActionCreators(setCounterAlert, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(MakePayment);
