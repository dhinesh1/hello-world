import React, { Component } from 'react';
import axios from 'axios';

import { onceModalClosed, onceModalOpened } from '../../../helpers/utilsHelper';
import { AppConfig } from '../../../app-config';
import Vouchers from '../../booked_itinerary/tabs/vouchers';
import Loader from '../../../common_components/Loader';

const API_URL = AppConfig.api_url;

export default class GetVoucherModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      isFetching: false,
      bookedItinerary: {}
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }

  openModal() {
    this.setState({ isKilled: false }, () => {
      setTimeout(() => {
        this.setState({ showModal: true });
      }, 10);

      onceModalOpened();
    });
  }

  closeModal() {
    this.setState({ showModal: false }, () => {
      onceModalClosed();

      this.props.hideModal();
    });
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  componentDidMount() {
    let { showGetVoucherModal, currentBookedItinerary } = this.props;

    if (!this.state.showModal && showGetVoucherModal) {
      this.openModal();
    }

    this.setState({ isFetching: true }, () => {
      let url = `${API_URL}user/bookedtripdetails/itinerary/${currentBookedItinerary}`;
      axios.get(url).then(response => {
        this.setState({
          bookedItinerary: response.data,
          isFetching: false
        });
      });
    });

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  render() {
    let { bookedItinerary, isFetching } = this.state;

    return (
      <div
        tabIndex="0"
        ref="modal"
        className={
          'modal fade modal-sticky-header alternate-modal ' +
          (this.state.showModal ? 'in' : '')
        }
      >
        <div className={`modal-dialog`}>
          <div className={`modal-content with-header`}>
            <div className="modal-header with-bg">
              <span className="caps-text semi-bold kern-more fade">
                Vouchers
              </span>
              <button
                type="button"
                className="pull-left close"
                onClick={this.closeModal}
                data-dismiss="modal"
              >
                <i className="vehoicon-close" />
              </button>

              {bookedItinerary.voucherUrlPlatoResponse &&
              bookedItinerary.voucherUrlPlatoResponse.voucher ? (
                <div className={'modal-actions'}>
                  <a
                    href={bookedItinerary.voucherUrlPlatoResponse.voucher}
                    target={'_blank'}
                    className="btn btn-primary"
                    download
                  >
                    <i className="vehoicon-get_app" /> Download all
                  </a>
                </div>
              ) : null}
            </div>

            <div className="modal-body" ref={'_modalContent'}>
              <div className="modal-row pt-0 your-trips">
                <div className={'row'}>
                  <div className={'col-xs-12'}>
                    {isFetching ? (
                      <Loader />
                    ) : (
                      <Vouchers
                        bookedTrip={bookedItinerary}
                        isForAgent={true}
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
