import React, { Component } from 'react';
import axios from 'axios';

import { onceModalClosed, onceModalOpened } from '../../../helpers/utilsHelper';
import { AppConfig } from '../../../app-config';

const API_URL = AppConfig.api_url;

export default class LedgerViewModal extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      isFetching: false,
      ledgerData: {}
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }

  openModal() {
    this.setState({ isKilled: false }, () => {
      setTimeout(() => {
        this.setState({ showModal: true });
      }, 10);

      onceModalOpened();
    });
  }

  closeModal() {
    this.setState({ showModal: false }, () => {
      onceModalClosed();

      this.props.hideModal();
    });
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  componentDidMount() {
    let { user_details, showLedgerView } = this.props;

    if (!this.state.showModal && showLedgerView) {
      this.openModal();
    }

    this.setState({ isFetching: true }, () => {
      let url = `${API_URL}agent/ledger`;
      let req_config = { agentId: user_details.agentId, from: '', to: '' };
      axios.post(url, req_config).then(response => {
        this.setState({
          ledgerData: response.data,
          isFetching: false
        });
      });
    });

    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  render() {
    let { ledgerData, isFetching } = this.state;

    return (
      <div
        tabIndex="0"
        ref="modal"
        className={
          'modal fade modal-sticky-header agents-modal width-auto ' +
          (this.state.showModal ? 'in' : '')
        }
      >
        <div className={`modal-dialog`}>
          <div className={`container modal-content with-header`}>
            <div className="modal-header">
              <button
                type="button"
                className="pull-left close"
                onClick={this.closeModal}
                data-dismiss="modal"
              >
                <i className="vehoicon-close" />
              </button>
              <span className="caps-text semi-bold kern-more fade">
                Ledger view
              </span>
            </div>

            <div className="modal-body" ref={'_modalContent'}>
              <div className="modal-detail-content">
                <div className="modal-row">
                  <div className={'row'}>
                    <div className={'col-xs-12'}>
                      <h4 className={'text-center semi-bold medium-heading'}>
                        Account statement
                      </h4>
                      <div className={'row'}>
                        <div className={'col-xs-12 col-sm-3'}>
                          <span className={'dim meta-text'}>From: </span>
                          <span className={'meta-text'}>{ledgerData.from}</span>
                        </div>
                        <div className={'col-xs-12 col-sm-3'}>
                          <span className={'dim meta-text'}>To: </span>
                          <span className={'meta-text'}>{ledgerData.to}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <table
                    className={'table table-bordered table-condensed meta-text'}
                  >
                    <thead>
                      <tr>
                        <th className={'text-center'}>Date</th>
                        <th className={'text-center'}>Narration</th>
                        <th className={'text-center'}>Chq/Ref No</th>
                        <th className={'text-center'}>Value Dt</th>
                        <th className={'text-center'}>Debit Amt.</th>
                        <th className={'text-center'}>Credit Amt.</th>
                        <th className={'text-center'}>Cur. Balance</th>
                      </tr>
                    </thead>

                    <tbody>
                      {isFetching ? (
                        <tr>
                          <td colSpan={'7'} className={'text-center'}>
                            Fetching transactions...
                          </td>
                        </tr>
                      ) : ledgerData &&
                      ledgerData.transactions &&
                      ledgerData.transactions.length > 0 ? (
                        ledgerData.transactions.map((trans, inx) => (
                          <tr key={'Trans_' + inx}>
                            <td className={'text-center'}>
                              {trans.createdDate}
                            </td>
                            <td>{trans.summary}</td>
                            <td className={'text-right'}>{trans.txnId}</td>
                            <td className={'text-center'}>{trans.txnDate}</td>
                            <td className={'text-right'}>
                              {trans.type === 'DEBIT' ? trans.amount : ''}
                            </td>
                            <td className={'text-right'}>
                              {trans.type === 'CREDIT' ? trans.amount : ''}
                            </td>
                            <td className={'text-right'}>
                              {trans.stageBalance}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={'7'} className={'text-center'}>
                            No transactions found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>

                  <div className={'row'}>
                    <div className={'col-xs-12'}>
                      <h5 className={'text-uppercase main-para semi-bold'}>
                        Statement summary :-
                      </h5>
                      <div className={'row'}>
                        <div className={'col-xs-12 col-sm-2'}>
                          <div className={'semi-bold meta-text'}>
                            Opening Balance
                          </div>
                          <span className={'meta-text'}>
                            {ledgerData.openingBalance}
                          </span>
                        </div>
                        <div className={'col-xs-12 col-sm-2'}>
                          <div className={'semi-bold meta-text'}>Dr count</div>
                          <span className={'meta-text'}>
                            {ledgerData.debitCount}
                          </span>
                        </div>
                        <div className={'col-xs-12 col-sm-2'}>
                          <div className={'semi-bold meta-text'}>Cr count</div>
                          <span className={'meta-text'}>
                            {ledgerData.creditCount}
                          </span>
                        </div>
                        <div className={'col-xs-12 col-sm-2'}>
                          <div className={'semi-bold meta-text'}>Debits</div>
                          <span className={'meta-text'}>
                            {ledgerData.debitSum}
                          </span>
                        </div>
                        <div className={'col-xs-12 col-sm-2'}>
                          <div className={'semi-bold meta-text'}>Credits</div>
                          <span className={'meta-text'}>
                            {ledgerData.creditSum}
                          </span>
                        </div>
                        <div className={'col-xs-12 col-sm-2'}>
                          <div className={'semi-bold meta-text'}>
                            Closing Balance
                          </div>
                          <span className={'meta-text'}>
                            {ledgerData.closingBalance}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
