// Core
import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getUserDetails } from '../../actions/actions_app';

import { Tab, Nav, NavItem, Tooltip, OverlayTrigger } from 'react-bootstrap';
import axios from 'axios';
import _ from 'lodash';
import CircularProgressbar from 'react-circular-progressbar';

import { AppConfig } from '../../app-config';
import Collapsible from 'react-collapsible';
import LedgerViewModal from './modals/ledger_view_modal';

import 'react-circular-progressbar/dist/styles.css';
import GetVoucherModal from './modals/get_vouchers_modal';
import { itineraryModalsRouteHelper } from '../../helpers/routesHelper';

const API_URL = AppConfig.api_url;

const COMPLETED = 'COMPLETED';
const IN_PROGRESS = 'IN_PROGRESS';
const CANCELLED = 'CANCELLED';
const CANCEL_INITIATED = 'CANCELLATION_INITIATED';
/* global swal */

class AgentDashboard extends Component {
  constructor(props) {
    super(props);

    this.state = {
      userData: null,
      isFetching: true,
      showLedgerView: false,
      showGetVoucherModal: false,
      activeTab: 'saved'
    };

    this.openItinerary = this.openItinerary.bind(this);
    this.showLedger = this.showLedger.bind(this);

    this.handleTabChange = this.handleTabChange.bind(this);
    this.renderBookedStatus = this.renderBookedStatus.bind(this);
    this.downloadVouchers = this.downloadVouchers.bind(this);
    this.initCancel = this.initCancel.bind(this);
    this.onClickPayment = this.onClickPayment.bind(this);
    this.fetchAgentDashboard = this.fetchAgentDashboard.bind(this);

    this.hideModal = () => this.setState({ showLedgerView: false });
    this.hideVoucherModal = () => this.setState({ showGetVoucherModal: false });
  }

  handleTabChange(selectedKey) {
    this.setState({
      activeTab: selectedKey
    });
  }

  componentDidMount() {
    if (!this.props.user_details) {
      // console.log('No user details in props');
      this.props.actions.getUserDetails();
    } else if (this.props.user_details.loggedIn && !this.state.userData) {
      this.fetchAgentDashboard();
    }
  }

  componentWillReceiveProps(nextProps) {
    let { history } = this.props;
    // console.log('will receive props: ', nextProps);

    if (nextProps.user_details) {
      if (nextProps.user_details.loggedIn && !this.state.userData) {
        this.fetchAgentDashboard();
      } else {
        //Redirect to agent login page
        // console.log('Logged out user trying to access agent dashboard');
        history.push('/agents/login');
      }
    }
  }

  fetchAgentDashboard() {
    this.setState({ isFetching: true }, () => {
      let url = `${API_URL}agent/dashboard`;
      let req_config = { agentId: this.props.user_details.agentId };
      axios.post(url, req_config).then(response => {
        this.setState({
          userData: response.data,
          isFetching: false
        });
      });
    });
  }

  openItinerary(item, itemGroup) {
    let { user_details } = this.props;
    let { userData } = this.state;

    let targetItineraries = userData[itemGroup];
    let itineraryIndex = _.findIndex(targetItineraries, o => {
      return o.itineraryId === item.itineraryId;
    });

    // adding fetching for show loading
    targetItineraries[itineraryIndex]['fetchingCosting'] = true;
    userData[itemGroup] = targetItineraries;

    this.setState({ userData }, () => {
      let url = `${API_URL}agent/itinerary/detail`;
      let req_data = {
        itineraryId: item.itineraryId,
        agentId: user_details.agentId
      };

      axios.post(url, req_data).then(response => {
        targetItineraries[itineraryIndex]['costDetails'] = response.data;
        targetItineraries[itineraryIndex]['fetchingCosting'] = false;
        userData[itemGroup] = targetItineraries;

        this.setState({ userData });
      });
    });
  }

  showLedger(e) {
    e.preventDefault();

    this.setState({ showLedgerView: true });
  }

  downloadVouchers(item, e) {
    e.preventDefault();
    e.stopPropagation();

    this.setState({
      showGetVoucherModal: true,
      currentBookedItinerary: item.itineraryId
    });
  }

  initCancel(item, e) {
    e.preventDefault();
    e.stopPropagation();

    let _this = this;
    let { userData } = this.state;
    let targetItineraries = userData['bookedItineraries'];
    let itineraryIndex = _.findIndex(targetItineraries, o => {
      return o.itineraryId === item.itineraryId;
    });

    swal(
      {
        title: 'Are you sure?',
        animation: true,
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: 'Yes! Proceed',
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm) {
        if (isConfirm) {
          // adding fetching for show loading
          targetItineraries[itineraryIndex]['cancelReqInitiated'] = true;
          userData['bookedItineraries'] = targetItineraries;

          _this.setState({ userData }, () => {
            let url = `${API_URL}itinerary/${item.itineraryId}/cancel`;
            let req_config = { itineraryId: item.itineraryId };

            axios.post(url, req_config).then(response => {
              targetItineraries[itineraryIndex][
                'bookingStatus'
              ] = CANCEL_INITIATED;
              targetItineraries[itineraryIndex]['cancelReqInitiated'] = false;
              userData['bookedItineraries'] = targetItineraries;

              _this.setState({ userData });
            });
          });
        }
      }
    );
  }

  renderBookedStatus(item) {
    let viewBtn = (
      <button className={'btn btn-default btn-outline btn-xs'}>
        View cost
      </button>
    );
    let getVouchers = (
      <button
        onClick={e => this.downloadVouchers(item, e)}
        className={'btn btn-xs btn-primary'}
      >
        Get vouchers
      </button>
    );
    let cancelBooking = (
      <button
        onClick={e => this.initCancel(item, e)}
        className={'btn btn-danger btn-outline btn-xs'}
      >
        Cancel
      </button>
    );
    let bookingInProgress = (
      <button className={'color-warning inline-block btn btn-xs'}>
        <img
          src={'http://d3lf10b5gahyby.cloudfront.net/icons/in-progress.gif'}
        />{' '}
        Bookings In progress
      </button>
    );

    switch (item.bookingStatus) {
      case COMPLETED:
        return (
          <div>
            {viewBtn} {getVouchers} {cancelBooking}
          </div>
        );
      case IN_PROGRESS:
        return (
          <div>
            {viewBtn} {bookingInProgress} {cancelBooking}
          </div>
        );
      case CANCELLED:
        return (
          <div>
            <span className={'color-danger'}>Cancelled</span>
          </div>
        );
      case CANCEL_INITIATED:
        return (
          <div>
            <span className={'color-warning'}>Cancellation initiated</span>
          </div>
        );
      default:
        return <div>{viewBtn}</div>;
    }
  }

  onClickPayment(item, e) {
    e.preventDefault();
    e.stopPropagation();

    let _this = this;
    let { userData } = this.state;
    let targetItineraries = userData['bookedItineraries'];
    let itineraryIndex = _.findIndex(targetItineraries, o => {
      return o.itineraryId === item.itineraryId;
    });

    // adding fetching for show loading
    targetItineraries[itineraryIndex]['paymentInitiated'] = true;
    userData['bookedItineraries'] = targetItineraries;

    _this.setState({ userData }, () => {
      let url = `${API_URL}agent/payment/initiate`;
      let req_config = {
        itineraryId: item.itineraryId,
        userId: '',
        paymentOptionType: 'FULL'
      };

      axios.post(url, req_config).then(response => {
        if (response.data.status === 'SUCCESS') {
          targetItineraries[itineraryIndex]['costDetails']['paymentDone'] =
            item.costDetails.paymentDone + item.costDetails.paymentRemaining;
          targetItineraries[itineraryIndex]['costDetails'][
            'paymentRemaining'
          ] = 0;
          targetItineraries[itineraryIndex]['costDetails']['paymentDue'] = '';
          targetItineraries[itineraryIndex]['paymentInitiated'] = false;
          userData['bookedItineraries'] = targetItineraries;

          _this.setState({ userData }, () => {
            // let successText = <span>Your payment of <b><span className={"WebRupee"}>Rs.</span> {response.data.amount}</b> for itinerary <b># {response.data.uniqueIdentifier}</b> is successful. The payment reference number is <b>{response.data.referenceNumber}</b></span>;
            let amount = response.data.amount;
            let uniqueIdentifier = response.data.uniqueIdentifier;
            let referenceNumber = response.data.referenceNumber;
            let successText =
              'Your payment of Rs. ' +
              amount +
              ' for itinerary #' +
              uniqueIdentifier +
              ' is successful. The payment reference number is' +
              referenceNumber;
            _this.setState({ paymentSubmitting: false }, () => {
              swal(
                {
                  title: 'Success!',
                  type: 'success',
                  text: successText,
                  // imageUrl: '/images/cost_error.png',
                  animation: true,
                  showCancelButton: false,
                  confirmButtonColor: '#DD6B55',
                  confirmButtonText: 'Ok, Got it',
                  closeOnConfirm: true,
                  closeOnCancel: true
                },
                function(isConfirm) {
                  // console.log(isConfirm);

                  window.location.reload();
                }
              );
            });
          });
        } else {
          _this.setState({ paymentSubmitting: false }, () => {
            swal(
              {
                title: 'Oops!',
                type: 'warning',
                text:
                  'Looks like your transaction has failed. Please check your balance and try again later.',
                // imageUrl: '/images/cost_error.png',
                animation: true,
                showCancelButton: false,
                confirmButtonColor: '#DD6B55',
                confirmButtonText: 'Ok, Got it',
                closeOnConfirm: true,
                closeOnCancel: true
              },
              function(isConfirm) {
                // console.log(isConfirm);
              }
            );
          });
        }
      });
    });
  }

  render() {
    let { isFetching, userData, activeTab } = this.state;
    let { user_details } = this.props;
    if (isFetching) {
      return (
        <div className="loader-wrapper">
          <div className="loading-rounded color-primary lg" />
        </div>
      );
    } else {
      // let itineraries = userData.itineraries;
      let {
        costedItineraries,
        bookedItineraries,
        maxAllowedItineraries,
        availableItineraries
      } = userData;

      let redStroke = `rgba(217, 83, 79, 1)`;
      let greenStroke = `rgba(92, 184, 92, 1)`;
      let orangeStroke = `rgba(240, 173, 78, 1)`;

      let remainingPercentage =
        100 / (maxAllowedItineraries / availableItineraries);
      let strokeColor =
        remainingPercentage < 25
          ? redStroke
          : remainingPercentage < 50
            ? orangeStroke
            : greenStroke;

      let helpText =
        availableItineraries > 0
          ? `Maximum number of costings allowed is ${maxAllowedItineraries}. Free up spaces by booking an itinerary.`
          : `You have costed itineraries ${maxAllowedItineraries} times. Please book an itinerary to restart the counting.`;

      return (
        <div className={'agents-dashboard '} style={{ position: 'relative' }}>
          <div className="clearfix">
            <div className="itinerary-header bg-grey-medium">
              <div className="container">
                <div className="row">
                  <div className="col-xs-12">
                    <h1 className="large-heading text-center spacer color-white bold">
                      Your Dashboard
                    </h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="clearfix">
            <div className={'col-xs-12'}>
              <div className="itin-grid" style={{ paddingTop: '54px' }}>
                <div className={'container'}>
                  <div className={'row'}>
                    <div className={'col-xs-12'}>
                      <div className={'row'}>
                        <div
                          className={
                            'col-xs-6 col-xs-offset-3 col-md-2 col-md-offset-0 text-center'
                          }
                        >
                          <CircularProgressbar
                            percentage={100 - remainingPercentage}
                            styles={{
                              path: { stroke: strokeColor },
                              fill: strokeColor
                            }}
                            initialAnimation={true}
                            text={availableItineraries + ' Left'}
                          />
                          <OverlayTrigger
                            id="ot5"
                            placement="bottom"
                            overlay={
                              <Tooltip id="traintooltip">{helpText}</Tooltip>
                            }
                          >
                            <span
                              className={
                                'inline-block cursor-pointer color-primary meta-text dashed-underline'
                              }
                            >
                              What's this?
                            </span>
                          </OverlayTrigger>
                        </div>
                        <div className={'col-xs-6 col-md-4'}>
                          <h4 className={'dim medium-heading semi-bold'}>
                            Basic Details
                          </h4>
                          <span className={'block meta-text dim'}>
                            Agent ID#:
                          </span>
                          <h2 className={'no-margin medium-heading semi-bold'}>
                            {userData.agentId}
                          </h2>
                          <span className={'block main-text'}>
                            {user_details.email}
                          </span>
                          <span className={'block main-text'}>
                            {user_details.mobileNumber}
                          </span>
                        </div>
                        <div className={'col-xs-6 col-md-3'}>
                          <h4 className={'dim medium-heading semi-bold'}>
                            Account Details
                          </h4>
                          <span className={'block meta-text dim'}>
                            Available credit:
                          </span>
                          <h2 className={'no-margin semi-bold'}>
                            <span className={'WebRupee'}>Rs.</span>{' '}
                            {userData.availableCredit}
                          </h2>
                          <a
                            className={'underline'}
                            href={'#view-ledger'}
                            onClick={this.showLedger}
                          >
                            View ledger
                          </a>
                        </div>
                        <div className={'col-xs-12 col-md-3'}>
                          <h4 className={'dim medium-heading semi-bold'}>
                            Start planning
                          </h4>
                          <a
                            href={'/'}
                            target={'_blank'}
                            className={'btn btn-lg btn-primary'}
                          >
                            Create new itinerary
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className={'row'}>
                  <div className={'col-xs-12 itin-grid-inner'}>
                    <Tab.Container
                      id="tabs"
                      activeKey={activeTab}
                      onSelect={this.handleTabChange}
                      generateChildId={(eventKey, type) =>
                        `user-dashboard-header-${type}-${eventKey}`
                      }
                    >
                      <div className="row">
                        <div className="col-xs-12">
                          <div className="clearfix">
                            <div className="row">
                              <div className="col-xs-12">
                                <Nav
                                  bsStyle="tabs"
                                  className="clearfix list-unstyled agents-tab tab-links"
                                >
                                  <NavItem eventKey="saved">
                                    Saved Itineraries
                                  </NavItem>
                                  <NavItem eventKey="booked">
                                    Booked itineraries
                                  </NavItem>
                                </Nav>
                              </div>
                              {/*<div className="col-xs-12 col-sm-3 text-right">*/}
                              {/*<a className="btn btn-xs btn-secondary"><span className="vehoicon-add_circle" /> Add luggage</a>*/}
                              {/*</div>*/}
                            </div>
                          </div>
                        </div>

                        <div className="col-xs-12">
                          <Tab.Content animation className="dashboard-content">
                            <Tab.Pane eventKey="saved">
                              <div className="row">
                                <div className={'col-xs-12 spacer-both'}>
                                  <section className={'dashboard-table-view'}>
                                    <div className={'row-head'}>
                                      <div className={'row'}>
                                        <div className={'col-xs-12 col-md-1'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Unique ID
                                          </span>
                                        </div>
                                        <div className={'col-xs-12 col-md-4'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Itinerary Name
                                          </span>
                                        </div>
                                        <div className={'col-xs-12 col-md-1'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Region
                                          </span>
                                        </div>
                                        <div className={'col-xs-4 col-md-2'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Created date
                                          </span>
                                        </div>
                                        <div className={'col-xs-4 col-md-2'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Departure date
                                          </span>
                                        </div>
                                        <div className={'col-xs-12 col-md-2'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Actions
                                          </span>
                                        </div>
                                      </div>
                                    </div>

                                    <div className={'row-body small'}>
                                      {costedItineraries &&
                                      costedItineraries.length > 0 ? (
                                        costedItineraries.map((item, key) => {
                                          const itineraryPage = itineraryModalsRouteHelper({
                                            itineraryId: item.itineraryId,
                                            regionCode: item.regionCode ? item.regionCode : 'region'
                                          })
                                          const title = (
                                            <div className="row">
                                              <div
                                                className={
                                                  'col-xs-12 col-sm-12 col-md-1'
                                                }
                                              >
                                                <span className={'meta-text'}>
                                                  {item.uniqueIdentifier}
                                                </span>
                                              </div>
                                              <div
                                                className={'col-xs-12 col-md-4'}
                                              >
                                                <span className={'meta-text'}>
                                                  {item.itineraryName}
                                                </span>
                                                <a
                                                  style={{ marginLeft: '5px' }}
                                                  href={itineraryPage}
                                                  onClick={e =>
                                                    e.stopPropagation()
                                                  }
                                                  className={'text-primary '}
                                                  target={'_blank'}
                                                >
                                                  view
                                                </a>
                                              </div>
                                              <div
                                                className={'col-xs-12 col-md-1'}
                                              >
                                                <span className={'meta-text'}>
                                                  {item.region}
                                                </span>
                                              </div>
                                              <div
                                                className={'col-xs-4 col-md-2'}
                                              >
                                                <span className={'meta-text'}>
                                                  {item.createdDate}
                                                </span>
                                              </div>
                                              <div
                                                className={'col-xs-4 col-md-2'}
                                              >
                                                <span className={'meta-text'}>
                                                  {item.departureDate}
                                                </span>
                                              </div>
                                              {item.staleCost ? (
                                                <div
                                                  className={
                                                    'col-xs-12 col-md-2 meta-text'
                                                  }
                                                >
                                                  <span
                                                    className={
                                                      'pill color-white bg-accent-3'
                                                    }
                                                  >
                                                    Expired!
                                                  </span>
                                                  <a
                                                    href={itineraryPage}
                                                    onClick={e =>
                                                      e.stopPropagation()
                                                    }
                                                    className={'text-primary '}
                                                    style={{
                                                      marginLeft: '5px'
                                                    }}
                                                    target={'_blank'}
                                                  >
                                                    Update cost
                                                  </a>
                                                </div>
                                              ) : (
                                                <div
                                                  className={
                                                    'col-xs-12 col-md-2 text-right'
                                                  }
                                                >
                                                  <button
                                                    className={
                                                      'btn btn-default btn-outline btn-xs'
                                                    }
                                                  >
                                                    View cost
                                                  </button>
                                                  <a
                                                    href={`/booking-travellers/${
                                                      item.itineraryId
                                                    }`}
                                                    target={'_blank'}
                                                    onClick={e =>
                                                      e.stopPropagation()
                                                    }
                                                    className={
                                                      'btn btn-primary btn-xs'
                                                    }
                                                  >
                                                    Book this trip
                                                  </a>
                                                </div>
                                              )}
                                            </div>
                                          );

                                          return (
                                            <Collapsible
                                              trigger={title}
                                              triggerDisabled={item.staleCost}
                                              onOpening={() =>
                                                this.openItinerary(
                                                  item,
                                                  'costedItineraries'
                                                )
                                              }
                                              open={false}
                                              key={key + '_itinerary_list'}
                                            >
                                              <ExpandedCostingView
                                                key={item.itineraryId}
                                                {...this.props}
                                                isFor={'saved'}
                                                item={item}
                                              />
                                            </Collapsible>
                                          );
                                        })
                                      ) : (
                                        <div className={'row'}>
                                          <div className={'col-xs-12'}>
                                            <h3 className={'text-center'}>
                                              No itineraries found
                                            </h3>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  </section>
                                </div>
                              </div>
                            </Tab.Pane>

                            <Tab.Pane eventKey="booked">
                              <div className="row">
                                <div className={'col-xs-12 spacer-both'}>
                                  <section className={'dashboard-table-view'}>
                                    <div className={'row-head'}>
                                      <div className={'row'}>
                                        <div className={'col-xs-12 col-md-1'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Unique ID
                                          </span>
                                        </div>
                                        <div className={'col-xs-12 col-md-3'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Itinerary Name
                                          </span>
                                        </div>
                                        <div className={'col-xs-12 col-md-1'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Region
                                          </span>
                                        </div>
                                        <div className={'col-xs-4 col-md-2'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Created date
                                          </span>
                                        </div>
                                        <div className={'col-xs-4 col-md-2'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Departure date
                                          </span>
                                        </div>
                                        <div className={'col-xs-12 col-md-3'}>
                                          <span
                                            className={'main-para semi-bold'}
                                          >
                                            Actions
                                          </span>
                                        </div>
                                      </div>
                                    </div>

                                    <div className={'row-body small'}>
                                      {bookedItineraries &&
                                      bookedItineraries.length > 0 ? (
                                        bookedItineraries.map((item, key) => {
                                          let title = (
                                            <BookedCardTitle
                                              item={item}
                                              renderBookedStatus={
                                                this.renderBookedStatus
                                              }
                                            />
                                          );

                                          return (
                                            <Collapsible
                                              trigger={title}
                                              triggerDisabled={
                                                item.bookingStatus ===
                                                  CANCELLED ||
                                                item.bookingStatus ===
                                                  CANCEL_INITIATED
                                              }
                                              onOpening={() =>
                                                this.openItinerary(
                                                  item,
                                                  'bookedItineraries'
                                                )
                                              }
                                              open={false}
                                              key={key + '_itinerary_list'}
                                            >
                                              <ExpandedCostingView
                                                key={item.itineraryId}
                                                onClickPayment={
                                                  this.onClickPayment
                                                }
                                                isFor={'booked'}
                                                {...this.props}
                                                item={item}
                                              />
                                            </Collapsible>
                                          );
                                        })
                                      ) : (
                                        <div className={'row'}>
                                          <div className={'col-xs-12'}>
                                            <h3 className={'text-center'}>
                                              No itineraries found
                                            </h3>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  </section>
                                </div>
                              </div>
                            </Tab.Pane>
                          </Tab.Content>
                        </div>
                      </div>
                    </Tab.Container>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Ledger view Modal */}
          {this.state.showLedgerView ? (
            <LedgerViewModal
              {...this.state}
              {...this.props}
              hideModal={this.hideModal}
            />
          ) : null}

          {this.state.showGetVoucherModal ? (
            <GetVoucherModal
              {...this.state}
              {...this.props}
              hideModal={this.hideVoucherModal}
            />
          ) : null}
        </div>
      );
    }
  }
}

const BookedCardTitle = ({ item, renderBookedStatus }) => {
  const itineraryPage = itineraryModalsRouteHelper({
    itineraryId: item.itineraryId,
    regionCode: item.regionCode ? item.regionCode : "region"
  });

  return <div className="row">
    <div className={'col-xs-12 col-md-1'}>
      <span className={'meta-text'}>{item.uniqueIdentifier}</span>
    </div>
    <div className={'col-xs-12 col-md-3'}>
      <span className={'meta-text'}>{item.itineraryName}</span>
      <a
        style={{ marginLeft: '5px' }}
        href={itineraryPage}
        onClick={e => e.stopPropagation()}
        className={'text-primary'}
        target={'_blank'}
      >
        view
      </a>
    </div>
    <div className={'col-xs-12 col-md-1'}>
      <span className={'meta-text'}>{item.region}</span>
    </div>
    <div className={'col-xs-4 col-md-2'}>
      <span className={'meta-text'}>{item.createdDate}</span>
    </div>
    <div className={'col-xs-4 col-md-2'}>
      <span className={'meta-text'}>{item.departureDate}</span>
    </div>
    <div className={'col-xs-12 col-md-3 meta-text'}>
      {renderBookedStatus(item)}
    </div>
  </div>
};

function mapStateToProps(state) {
  // console.log(state);
  let app = state.app;

  return {
    user_details: app.user_details
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getUserDetails: bindActionCreators(getUserDetails, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(AgentDashboard);

const ExpandedCostingView = props => (
  <div className={'row spacer'}>
    {props.item.fetchingCosting ? (
      <div className={'col-xs-10 col-xs-offset-1'}>
        <div className="clearfix text-center">
          <div className="loading-dots" />
          <div className="loading-dots" />
          <div className="loading-dots" />
        </div>
        <div className="meta-text text-center">Fetching</div>
      </div>
    ) : !props.item.costDetails ? null : (
      <div className={'col-xs-10 col-xs-offset-1'}>
        <div className={'row'}>
          <div className={'col-xs-6'}>
            <div className={'row spacer-half'}>
              <div className={'col-xs-6'}>
                <span className={'meta-text dim'}>Total cost</span>
              </div>
              <div className={'col-xs-6'}>
                <span>
                  <span className={'WebRupee'}>Rs.</span>{' '}
                  {props.item.costDetails.totalPrice}
                </span>
              </div>
            </div>

            <div className={'row spacer-half'}>
              <div className={'col-xs-6'}>
                <span className={'meta-text dim'}>Net cost</span>
              </div>
              <div className={'col-xs-6'}>
                <span>
                  <span className={'WebRupee'}>Rs.</span>{' '}
                  {props.item.costDetails.netPrice}
                </span>
              </div>
            </div>

            <div className={'row spacer-half'}>
              <div className={'col-xs-6'}>
                <span className={'meta-text dim'}>Margin you make</span>
              </div>
              <div className={'col-xs-6'}>
                <span>
                  <span className={'WebRupee'}>Rs.</span>{' '}
                  {props.item.costDetails.margin}
                </span>
              </div>
            </div>
          </div>

          {props.isFor === 'booked' ? (
            <div className={'col-xs-6'}>
              <div className={'row spacer-half'}>
                <div className={'col-xs-6'}>
                  <span className={'meta-text dim'}>Payment done</span>
                </div>
                <div className={'col-xs-6'}>
                  <span>{props.item.costDetails.paymentDone}</span>
                </div>
              </div>

              <div className={'row spacer-half'}>
                <div className={'col-xs-6'}>
                  <span className={'meta-text dim'}>Payment remaining</span>
                </div>
                <div className={'col-xs-6'}>
                  <span>{props.item.costDetails.paymentRemaining}</span>
                  {props.item.costDetails.paymentPending ? (
                    <button
                      onClick={e => props.onClickPayment(props.item, e)}
                      style={{ marginLeft: '5px' }}
                      className={
                        'btn btn-xs btn-primary ' +
                        (props.item.paymentInitiated ? 'sending' : '')
                      }
                    >
                      Pay now
                    </button>
                  ) : null}
                </div>
              </div>

              <div className={'row spacer-half'}>
                <div className={'col-xs-6'}>
                  <span className={'meta-text dim'}>Next pay due</span>
                </div>
                <div className={'col-xs-6'}>
                  <span>{props.item.costDetails.dueDate}</span>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    )}
  </div>
);
