import React, { Component } from 'react';

export default class CareersV2 extends Component {
  render() {
    return (
      <section className={'careers-page-v2'}>
        {/* Banner Image Starts */}
        <div className="banner-image">
          <div className="container hidden-xs">
            <div className="row">
              <div className="col-xs-6">
                <ul className="clearfix list-unstyled tab-links">
                  <li>
                    <a href="#">About</a>
                  </li>
                  <li className="active">
                    <a href="#">Careers</a>
                    <div role="tooltip" className="fade in tooltip right">
                      <div className="tooltip-arrow" />
                      <div className="tooltip-inner">We are hiring!</div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="svg-container" />
        </div>
        {/* Banner Image Ends */}

        {/* Banner Content starts */}
        <section className="banner">
          <div className="container">
            <div className="row">
              <div className="col-xs-12">
                <h1 className="bold color-grey-secondary">
                  We are{' '}
                  <span className="text-strikethrough">travel planners</span>
                </h1>

                <div className="inline-tooltip">We are hiring!</div>
              </div>
              <div className="col-sm-5 col-xs-12">
                <p className="color-grey-secondary">
                  Contrary to popular belief, Lorem Ipsum is not simply random
                  text. It has roots in a piece of classical Latin literature
                  from 45 BC, making it over 2000 years old. Richard McClintock,
                  a Latin professor at Hampden-Sydney College in Virginia,
                  looked up one of the more obscure Latin words, consectetur,
                  from a Lorem Ipsum passage, and going through the cites of the
                  word in classical literature, discovered the undoubtable
                  source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of
                  "de Finibus Bonorum et Malorum”.
                </p>
              </div>
              <div className="col-sm-6 col-sm-offset-1 col-xs-12 col-xs-offset-0 hidden-xs">
                <div className={'alumni-testimonials-container'}>
                  <div className={'alumni-header'}>
                    <h2>Alumni speak</h2>

                    <div className={'nav-buttons'}>
                      <button className={'btn btn-sm btn-default btn-outline'}>
                        <span className={'vehoicon-left'} />
                      </button>{' '}
                      <button className={'btn btn-sm btn-default btn-outline'}>
                        <span className={'vehoicon-left rotate-180'} />
                      </button>
                    </div>
                  </div>

                  <div className={'alumni-content'}>
                    <p>
                      Contrary to popular belief, Lorem Ipsum is not simply
                      random text. It has roots in a piece of classical Latin
                      literature from 45 BC, making it over 2000 years old.{' '}
                    </p>
                    <div className={'profile-details'}>
                      <img
                        alt={'alumni-img'}
                        src={'https://pyt-images.imgix.net/images/misc/t21.jpg'}
                      />
                      <div className={''}>
                        <span className={'profile-name'}>Sushman Dev </span>
                        <a href={'#'}>
                          {' '}
                          <span className={'vehoicon-facebook-square'} />
                        </a>
                        <a href={'#'}>
                          {' '}
                          <span className={'vehoicon-twitter'} />
                        </a>
                      </div>
                      <span className={'alumni-department'}>Engineering</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Banner Content ends */}

        {/* Our values starts */}
        <section className={'our-values'}>
          <div className={'container'}>
            <h3>Our values</h3>
            <ul className={'clearfix list-unstyled'}>
              <li>
                <span className={'our-values-1'} />
                <div className={'content-holder'}>
                  <h4>Results Over Reason</h4>
                  <p>
                    To value actions over intentions and demonstrate high levels
                    of perseverance
                  </p>
                </div>
              </li>

              <li>
                <span className={'our-values-2'} />
                <div className={'content-holder'}>
                  <h4>Innovation</h4>
                  <p>
                    Bring in a fresh pair of eyes to every situation. Question
                    the status quo without fear.
                  </p>
                </div>
              </li>

              <li>
                <span className={'our-values-3'} />
                <div className={'content-holder'}>
                  <h4>Communication</h4>
                  <p>
                    Listen well, write concisely, articulate clearly and
                    understand before you respond.
                  </p>
                </div>
              </li>

              <li>
                <span className={'our-values-4'} />
                <div className={'content-holder'}>
                  <h4>Empathy</h4>
                  <p>
                    Put ourselves in the shoes of the customers and co-workers
                    and do what’s best for them.
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </section>
        {/* Our values ends */}
      </section>
    );
  }
}
