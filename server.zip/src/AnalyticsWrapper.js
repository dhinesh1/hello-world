import React from 'react';
import ReactRouterPageViewHelper from './helpers/ML/ReactRouterPageViewHelper';

export default function AnalyticsWrapper({ isServer, children }) {
  if (isServer) return children;
  else
    return (
      <ReactRouterPageViewHelper id={`UA-46926915-1`}>
        {children}
      </ReactRouterPageViewHelper>
    );
}
