import React, { Component } from 'react';
import { Redirect, Route, Switch, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

import {
  is_server,
  isFaqMobile,
  openChatWidget,
  getQueryStringValue,
  checkIndexOf
} from './helpers/utilsHelper';
import { identifyLeadSource } from './helpers/leadSourceHelper';
import classNames from 'classnames';

// Common components - without router
import OffCanvasMenu from './common_components/OffCanvasMenu';
import Navbar from './common_components/Navbar';
import Footer from './common_components/Footer';

// Login modal
import Login from './pages/Login';

// Moved Home, packages, vacations, SEM and voyager out of the main bundle by moving them as loadable components
import { inclusionsRoute } from './helpers/routesHelper';

import {
  AboutUsLoadable,
  AgentDashboardLoadable,
  AgentLoginLoadable,
  BookedTripDetailsLoadable,
  BookingPassengersLoadable,
  BookingReviewLoadable,
  CancellationPolicyLoadable,
  CareersLoadable,
  ContactLoadable,
  CostingScreenLoadable,
  FaqLoadable,
  ItineraryPageWrapperLoadable,
  ItineraryPDFLoadable,
  MagicItineraryLoadable,
  MakePaymentLoadable,
  PaymentFailureLoadable,
  PaymentProcessingLoadable,
  PaymentSuccessLoadable,
  PDGCitySelectionLoadable,
  PDGDurationSelectionLoadable,
  PDGInterestSelectionLoadable,
  PDGMonthSelectionLoadable,
  PostCardLoadable,
  PostcardSuccessLoadable,
  PrivacyPolicyLoadable,
  SavedItinerariesLoadable,
  SearchModalLoadable,
  TermsAndConditionsLoadable,
  TestimonialsComponentLoadable,
  YourAccountLoadable,
  YourVacationsHomeLoadable,
  IndiaTravelTrendsLoadable,
  ItineraryPDFv1Loadable,
  MalSezHotelsLoadable,
  RequestCallbackModalLoadable,
  SiteMapLoadable,
  AssignUserLoadable,
  HomeLoadable,
  SemLoadable,
  PackagesLoadable,
  VoyagerLoadable,
  CredLoyalityLoadable,
  CredLoyalityTCLoadable,
  PreferencesUnsubscribePageLoadable
} from './helpers/loadbleComponentsHelper';
import Page404 from './pages/Page404';
//code
// Locale set for calendar plugin
import moment from 'moment';
import momentLocalizer from 'react-widgets-moment';
import ErrorBoundary from './helpers/ErrorBoundary';

import AnalyticsWrapper from './AnalyticsWrapper';

import { ITINERARY_ROUTES } from './helpers/routesHelper';

moment.locale('en');
momentLocalizer();

class App extends Component {
  constructor(props) {
    super(props);

    if (!is_server()) {
      identifyLeadSource();

      let campaignId = unescape(
        getQueryStringValue(this.props.location.search, 'cpid')
      )
        .replace('+', ' ')
        .trim();
      if (campaignId.length) {
        sessionStorage.setItem('campaignId', campaignId);
      }

      if (!sessionStorage.getItem('packagesv3')) {
        sessionStorage.setItem('packagesv3', true);
      }
      if (!localStorage.getItem('popover')) {
        localStorage.setItem('popover', true);
      }
      if (!sessionStorage.getItem('CBRPackExitpopup')) {
        sessionStorage.setItem('CBRPackExitpopup', true);
      }

      if (this.props.history.location.pathname.split('/')[1] === 'vacations') {
        if (!sessionStorage.getItem('CampaignAUSVacations')) {
          sessionStorage.setItem('CampaignAUSVacations', true);
        }
        if (!sessionStorage.getItem('CBRExitpopup')) {
          sessionStorage.setItem('CBRExitpopup', true);
        }
      }

      if(sessionStorage && !sessionStorage.getItem('source')){
        sessionStorage.setItem('source', window.location.href);
      }
    }

    this.state = {
      isVoyagerApp: false
    };
  }

  componentDidMount() {
    let t = this.state;
    t.isVoyagerApp = JSON.parse(localStorage.getItem('mobileAppDetails'));
    this.setState(t);

    // To check and update leadSource in-case of SSR
    identifyLeadSource();
  }

  render() {
    let { location, history, isPaid } = this.props;
    let { state } = this;
    let isModal =
      location &&
      location.state &&
      location.state.modal &&
      this.previousChildren;

    let { pathname } = location;
    function PDGCitySelectionComponent(props) {
      return <PDGCitySelectionLoadable {...state} {...props} />;
    }

    return (
      <AnalyticsWrapper isServer={is_server()}>
        {pathname.indexOf('createpdf') > 0 ||
        pathname.indexOf('voyager') > 0 ||
        pathname.split('/')[1] === 'holidays' ? null : (
          <OffCanvasMenu history={history} />
        )}
        <div className="main-container">
          {(pathname.indexOf('createpdf') > 0 ||
            isPaid ||
            pathname === '/cred-bali' ||
            pathname.split('/')[1] === 'holidays' ||
            (pathname.indexOf('booking-travellers') > 0 && isFaqMobile()) ||
            (pathname.indexOf('booking-review') > 0 && isFaqMobile()) ||
            (this.state.isVoyagerApp &&
              pathname.indexOf('payment/failure') > 0) ||
            pathname.indexOf('payment/processing') > 0 ||
            pathname.indexOf('voyager') > 0 ||
            (pathname.indexOf('make-payment') > 0 && isFaqMobile())) &&
          !(pathname.indexOf('your-vacations') > 0) ? null : (
            <Navbar
              isBookingReview={
                pathname.indexOf('booking-review') > 0 ||
                pathname.indexOf('make-payment') > 0
              }
            />
          )}

          <ErrorBoundary>
            <div
              className={classNames('clearfix content-wrap', {
                'vh-hgt':
                  pathname.indexOf('404') > 0 ||
                  pathname.indexOf('payment/processing') > 0
              })}
            >
              {isModal ? this.previousChildren : this.props.children}

              <Switch>
                {/* Home page */}
                <Route path="/" exact={true} component={HomeLoadable} />
                <Route
                  path="/request-callback"
                  exact={true}
                  component={RequestCallbackModalLoadable}
                />

                {/* Search modal */}
                <Route
                  path="/customize/"
                  exact={true}
                  component={SearchModalLoadable}
                />

                {/* PDG flow screens - starts here */}
                {(checkIndexOf(pathname, [
                  'customize/mle',
                  'customize/sez',
                  'customize/mus'
                ]) && !checkIndexOf(pathname, ['/view/', '/inclusions'])) ? (
                  <Route
                    path="/customize/:searchRegion"
                    component={MalSezHotelsLoadable}
                  />
                ) : (
                  <Route
                    path="/customize/:searchRegion"
                    exact={true}
                    component={PDGMonthSelectionLoadable}
                  />
                )}

                <Route
                  path="/customize/:searchRegion/month"
                  exact={true}
                  component={PDGDurationSelectionLoadable}
                />
                <Route
                  path="/customize/:searchRegion/month/duration"
                  exact={true}
                  component={PDGInterestSelectionLoadable}
                />
                <Route
                  path="/customize/:searchRegion/month/duration/interests"
                  exact={true}
                  component={PDGCitySelectionComponent}
                  props={this.props}
                />
                {/* PDG flow screens - ends here */}

                <Route
                  path="/cred-bali"
                  exact={true}
                  component={CredLoyalityLoadable}
                />

                <Route
                  path="/cred-bali/terms-and-conditions"
                  exact={true}
                  component={CredLoyalityTCLoadable}
                />

                {/* Itinerary screen */}
                <Route
                  path={ITINERARY_ROUTES.ITINERARY_VIEW_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                  />

                {/* Itinerary View - with totem */}
                <Route
                  path={ITINERARY_ROUTES.ENABLE_TOTEM_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />
                {/* Alternate transfer modes */}
                <Route
                  path={ITINERARY_ROUTES.ALTERNATE_TRANSFER_MODE_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Get cost modal */}
                <Route
                  path={ITINERARY_ROUTES.GET_COST_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Get cost - login - modal */}
                <Route
                  path={ITINERARY_ROUTES.LOGIN_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Get cost - signup - modal */}
                <Route
                  path={ITINERARY_ROUTES.SIGNUP_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Update cost modal */}
                <Route
                  path={ITINERARY_ROUTES.UPDATE_COST_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Edit trip modal */}
                <Route
                  path={ITINERARY_ROUTES.EDIT_TRIP_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Share Itinerary modal */}
                <Route
                  path={ITINERARY_ROUTES.SHARE_ITINERARY_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Activity details modal */}
                <Route
                  path={ITINERARY_ROUTES.ACTIVITY_DETAILS_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Alternate activities modal */}
                <Route
                  path={ITINERARY_ROUTES.ACTIVITY_ALTERNATES_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Alternate activities modal */}
                <Route
                  path={ITINERARY_ROUTES.ACTIVITY_ALTERNATES_DETAILS_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Costing in progress modal */}
                <Route
                  path={ITINERARY_ROUTES.COSTING_IN_PROGRESS_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Hotel details modal */}
                <Route
                  path={ITINERARY_ROUTES.HOTEL_DETAILS_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Alternate Hotel modal */}
                <Route
                  path={ITINERARY_ROUTES.HOTEL_ALTERNATES_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Alternate Hotel -> details modal */}
                <Route
                  path={ITINERARY_ROUTES.HOTEL_ALTERNATES_DETAILS_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Alternate Hotel room modal */}
                <Route
                  path={ITINERARY_ROUTES.HOTEL_ALTERNATE_ROOMS_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Rate match modals */}
                <Route
                  path={ITINERARY_ROUTES.RATE_MATCH_ACTIVITY_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />
                <Route
                  path={ITINERARY_ROUTES.RATE_MATCH_HOTEL_ROOM_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />
                <Route
                  path={ITINERARY_ROUTES.RATE_MATCH_TOTAL_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                <Route
                  path={ITINERARY_ROUTES.CBR_ROUTE}
                  exact
                  component={ItineraryPageWrapperLoadable}
                />

                {/* Costing screen */}
                <Route
                  path={inclusionsRoute.INCLUSIONS_PAGE}
                  exact
                  component={CostingScreenLoadable}
                />

                {/** COSTING SCREEN MODALS START */}

                <Route
                  path={inclusionsRoute.UPDATE_COST}
                  exact
                  component={CostingScreenLoadable}
                />

                <Route
                  path={inclusionsRoute.EMAIL_QUOTE}
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.SHARE_ITINERARY}
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.LOGIN}
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.REQUEST_CALLBACK}
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.COSTING_DELAY}
                  component={CostingScreenLoadable}
                />

                {/* Flight modals */}
                <Route
                  path={inclusionsRoute.FLIGHT_DETAILS}
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.ALTERNATE_FLIGHTS}
                  component={CostingScreenLoadable}
                />

                {/* Hotel modals */}
                <Route
                  path={inclusionsRoute.HOTEL_DETAILS}
                  exact
                  component={CostingScreenLoadable}
                />

                {/* Alternate hotels */}
                <Route
                  path={inclusionsRoute.ALTERNATE_HOTEL}
                  exact
                  component={CostingScreenLoadable}
                />

                {/* Alternate hotel rooms */}
                <Route
                  path={inclusionsRoute.ALTERNATE_ROOM}
                  exact
                  component={CostingScreenLoadable}
                />

                {/* Activities modals */}
                <Route
                  path={inclusionsRoute.ACTIVITY_DETAILS}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.ALTERNATE_ACTIVITY_DETAILS}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.ALTERNATE_ACTIVITY}
                  exact
                  component={CostingScreenLoadable}
                />

                {/* Visa Insurance Modals */}
                <Route
                  path={inclusionsRoute.CHANGE_INSURANCE}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.CHANGE_VISA}
                  exact
                  component={CostingScreenLoadable}
                />

                {/* Rental Car Modals */}
                <Route
                  path={inclusionsRoute.RENTAL_CAR_DETAILS}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.CHANGE_RENTAL_CAR_INSURANCE}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.ALTERNATE_RENTAL_CAR}
                  exact
                  component={CostingScreenLoadable}
                />

                {/* Train Modals */}
                <Route
                  path={inclusionsRoute.TRAIN_DETAILS}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.TRAIN_ALTERNATE}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.BUS_ALTERNATE}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.FERRY_ALTERNATE}
                  exact
                  component={CostingScreenLoadable}
                />

                {/* Rate Match common screen */}
                <Route
                  path={inclusionsRoute.RATE_MATCH_ACTIVITY}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.RATE_MATCH_FLIGHT}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.RATE_MATCH_RENTAL_CAR}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.RATE_MATCH_TRAIN}
                  exact
                  component={CostingScreenLoadable}
                />
                <Route
                  path={inclusionsRoute.RATE_MATCH_HOTEL_ROOM}
                  exact
                  component={CostingScreenLoadable}
                />

                <Route
                  path={inclusionsRoute.RATE_MATCH_TOTAL_COST}
                  exact
                  component={CostingScreenLoadable}
                />

                <Route
                  path={inclusionsRoute.ALTERNATE_HOTEL_DETAILS}
                  exact
                  component={CostingScreenLoadable}
                />

                {/** COSTING SCREEN MODALS END */}

                {/* Booking traveller screens */}
                <Route
                  path="/booking-travellers/:itineraryId"
                  component={BookingPassengersLoadable}
                />

                {/* Booking review screens */}
                <Route
                  path="/booking-review/:itineraryId"
                  component={BookingReviewLoadable}
                />

                {/* Payment screens */}
                <Route
                  path="/make-payment/:itineraryId"
                  exact={true}
                  component={MakePaymentLoadable}
                />
                <Route
                  path="/payment/success"
                  component={PaymentSuccessLoadable}
                />
                <Route
                  path="/payment/processing/:type?/:itineraryid?/:transid?"
                  component={PaymentProcessingLoadable}
                />
                <Route
                  path="/payment/failure"
                  component={PaymentFailureLoadable}
                />

                <Route path="/all" exact={true} component={SiteMapLoadable} />

                {/* Profile screen */}
                <Route
                  path="/your-vacations/"
                  exact={true}
                  component={YourVacationsHomeLoadable}
                />
                <Route
                  path="/unsubscribe/:code?"
                  exact={true}
                  component={PreferencesUnsubscribePageLoadable}
                />
                <Route
                  path="/account"
                  exact={true}
                  component={YourAccountLoadable}
                />
                <Route
                  path="/saved-itineraries/"
                  exact={true}
                  component={SavedItinerariesLoadable}
                />
                <Route
                  path="/yourtrips/:itineraryId"
                  exact={true}
                  component={BookedTripDetailsLoadable}
                />

                <Route path="/holidays/:destination" component={SemLoadable} />

                {/* Static pages */}
                <Route path="/login" exact={true} component={Login} />
                <Route
                  path="/signup"
                  exact={true}
                  component={props => (
                    <Login
                      {...props}
                      actionType="SIGNUP"
                      headerText="Join the travel tribe!"
                      subText="Save your itineraries and make unlimited edits. Create an account to get started right-away!"
                    />
                  )}
                />
                <Route
                  path="/testimonials"
                  component={TestimonialsComponentLoadable}
                />

                <Route path="/careers" component={CareersLoadable} />

                <Route path="/faq" component={FaqLoadable} />
                <Route path="/about-us" component={AboutUsLoadable} />
                <Route path="/contact-us" component={ContactLoadable} />
                <Route
                  path="/terms-and-conditions"
                  component={TermsAndConditionsLoadable}
                />
                <Route
                  path="/privacy-policy"
                  component={PrivacyPolicyLoadable}
                />
                <Route
                  path="/cancellation-policy"
                  component={CancellationPolicyLoadable}
                />

                {/* Post card pages */}
                <Route
                  path="/get-packing/:destination"
                  component={PostCardLoadable}
                />
                <Route
                  path="/postcard-success"
                  component={PostcardSuccessLoadable}
                />

                {/* PDF */}
                <Route
                  path="/cost/:itineraryId/createpdf"
                  exact={true}
                  component={ItineraryPDFv1Loadable}
                />

                <Route
                  path="/cost/:itineraryId/createpdf/v2"
                  exact={true}
                  component={ItineraryPDFLoadable}
                />

                {/* Agent URLs */}
                <Route
                  path="/agent/dashboard"
                  exact={true}
                  component={AgentDashboardLoadable}
                />
                <Route
                  path="/agents/login"
                  exact={true}
                  component={AgentLoginLoadable}
                />

                {/* Magic link */}
                <Route
                  path={'/itinerary/view/:hash'}
                  exact
                  component={MagicItineraryLoadable}
                />

                <Route
                  path={'/itinerary/:sampleItineraryId/assignUser'}
                  exact
                  component={AssignUserLoadable}
                />

                <Route
                  path={'/2018-travel-trends-international-vacations-ideas'}
                  component={IndiaTravelTrendsLoadable}
                />

                {/*Voyager app*/}
                <Route path={'/voyager'} component={VoyagerLoadable} />

                <Route path={'/404'} component={Page404} />

                <Route path={'/*'} component={PackagesLoadable} />

                <Redirect to={'/404'} />
              </Switch>
            </div>
          </ErrorBoundary>

          {((pathname.indexOf('view') > 0 ||
            isPaid || 
            pathname.indexOf('login') > 0 ||
            pathname.split('/')[1] === 'holidays' ||
            pathname.indexOf('inclusions') > 0 ||
            pathname.indexOf('createpdf') > 0 ||
            pathname.indexOf('booking-travellers') > 0 ||
            pathname.indexOf('make-payment') > 0 ||
            pathname.indexOf('404') > 0 ||
            pathname.split('/')[1] === 'all' ||
            pathname.indexOf('payment/success') > 0 ||
            pathname.indexOf('voyager') > 0 ||
            (this.state.isVoyagerApp &&
              pathname.indexOf('payment/failure') > 0) ||
            pathname.indexOf('payment/processing') > 0 ||
            pathname.indexOf('customize') > 0) &&
            !(pathname.indexOf('your-vacations') > 0)) ||
          pathname.indexOf('cred') > 0 ? null : (
            <Footer openChatWidget={openChatWidget} pathname={pathname} />
          )}

          <div className="modal-backdrop fade" />
        </div>
      </AnalyticsWrapper>
    );
  }
}

const mapStateToProps = ({ packages = {} }) => {
  const { content } = packages;
  let isPaid = null;
  if(content && typeof content === "object" && Object.keys(content).length) {
    const { campaignDetails={} } = content;
    isPaid = campaignDetails.paid;
  }

  return { isPaid }
}

export default withRouter(connect(mapStateToProps)(App));

