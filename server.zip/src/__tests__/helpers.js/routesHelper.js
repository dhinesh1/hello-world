import { itineraryModalsRouteHelper } from '../../helpers/routesHelper';

describe('Helper::itineraryModalsRouteHelper', () => {
  it('calls for INCLUSIONS_PAGE', () => {
    const result = itineraryModalsRouteHelper({
      itineraryId: '1212',
      regionCode: 'eur',
      parentPage: 'inclusions'
    });
    expect(result).toEqual('/customize/eur/inclusions/1212');
  });
  it('calls for VIEW_PAGE', () => {
    const result = itineraryModalsRouteHelper({
      itineraryId: '1212',
      regionCode: 'eur',
      parentPage: 'view'
    });
    expect(result).toEqual('/customize/eur/view/1212');
  });
});
