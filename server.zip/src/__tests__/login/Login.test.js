import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import Login, { RenderLeftSidePanel } from '../../pages/Login';
import { CustomProvider } from '../../__actions__/__services';
import { BrowserRouter } from 'react-router-dom';
import { getDefaultProps } from '../../__fixtures__/getDefaultProps';
const props = getDefaultProps;
/** To Set the service for mock */

describe('LOGIN', () => {
  describe('LOGIN::Render', () => {
    it('LOGIN::Crashing', () => {
      shallow(
        <CustomProvider>
          <BrowserRouter>
            <Login />
          </BrowserRouter>
        </CustomProvider>
      );
    });

    it('Login::WithoutArguments', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <Login {...props} isTestKilled={true} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Login::SignUp::WithoutArguments', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <Login {...props} isTestKilled={true} actionType="SIGNUP" />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Login::Forgot::WithoutArguments', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <Login {...props} isTestKilled={true} actionType="FORGOT" />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Login::OTP::WithoutArguments', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <Login {...props} isTestKilled={true} actionType="OTP" />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Login::LeftSidePanel', () => {
      let props = {
        fName: undefined,
        image: 'https://pyt-images.imgix.net/images/login/login_bg_3.jpeg',
        isSignUp: false,
        place: undefined,
        quotes: {
          author: 'Dalai Lama',
          text: 'Once a year, go someplace you’ve never been before.'
        }
      };
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RenderLeftSidePanel {...props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Login::SignUp::LeftSidePanel', () => {
      let props = {
        fName: 'Sanjeev Venkataramanan',
        image:
          'https://pyt-images.imgix.net/images/testimonials/622/fbCover/800xh/cover.jpg?w=520&h=1200&fit=facearea&facepad=10&auto=enhance',
        isSignUp: true,
        place: 'Family TRIP TO Seminyak',
        quotes: '',
        tripText: 'Had a wonderful stay in Bali! Thanks to PYT team!'
      };
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RenderLeftSidePanel {...props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });
  });
});
