import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import { CustomProvider } from '../../../__actions__/__services';
import { getDefaultProps } from '../../../__fixtures__/getDefaultProps';
import { BrowserRouter } from 'react-router-dom';
import { RequestCallbackModal } from '../../../pages/itinerary/request_callback_modal';
const props = getDefaultProps;

describe('Request Callback Modal', () => {
  describe('Request::Callback::Modal', () => {
    it('Request::Callback::Modal::Crashing', () => {
      shallow(
        <CustomProvider>
          <BrowserRouter>
            <RequestCallbackModal />
          </BrowserRouter>
        </CustomProvider>
      );
    });

    it('Request::Callback::Modal::WithArguments::Succeed', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RequestCallbackModal {...props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Request::Callback::Modal::WithArguments::WithEmail::NotValid', () => {
      let localProps = props;
      localProps.user_details.email = 'a@a';
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RequestCallbackModal {...localProps} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Request::Callback::Modal::WithArguments::WithPhoneNumber::NotValid', () => {
      let localProps = props;
      localProps.user_details.phoneNumber = 8973;
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RequestCallbackModal {...localProps} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Request::Callback::Modal::WithArguments::WithName::NotValid', () => {
      let localProps = props;
      localProps.user_details.name = '';
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RequestCallbackModal {...localProps} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Request::Callback::Modal::WithArguments::Valid', () => {
      let localProps = props;
      localProps.user_details.name = 'Akbar';
      localProps.user_details.phoneNumber = 9876543210;
      localProps.user_details.email = 'a@gmail.com';
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RequestCallbackModal {...localProps} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });
  });
});
