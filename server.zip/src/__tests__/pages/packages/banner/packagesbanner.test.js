import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import FeaturedBanner from '../../../../pages/packageV3/banner/FeaturedBanner';
import { getPackage } from '../../../../__actions__/__actions.app';
import getPackages from '../../../../__fixtures__/getPackagesResponse';
import { packagesReducer } from '../../../../store/packagesReducer';
import { getService, getMockStore } from '../../../../__actions__/__services';
const mockStore = getMockStore();

/** To Set the service for mock */
let mockServiceCreator;

describe('Packages Featured Banner', () => {
  const packages = getPackages;
  describe('Campaign::Featured::Banner::Render', () => {
    it('FeaturedBanner::Crashing', () => {
      shallow(<FeaturedBanner />);
    });

    it('FeaturedBanner::Snapshot::WithoutArguments', () => {
      const renderedValue = renderer.create(<FeaturedBanner />).toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('FeaturedBanner::Snapshot::WithArguments', () => {
      const renderedValue = renderer
        .create(<FeaturedBanner {...packages} />)
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('FeaturedBanner::BannerText', () => {
      let wrapper = shallow(<FeaturedBanner {...packages} />);
      expect(wrapper.find('.boxed-meta p').text()).toBe(
        getPackages.campaignDetails.bannerText
      );
    });
  });

  //   describe('Campaign Featured Banner::Action::Reducer', () => {
  //     let store;

  //     beforeEach(() => {
  //       store = mockStore({});
  //     });
  //     afterEach(() => {
  //       store.clearActions();
  //     });

  //     it('FeaturedBanner::Actions::Success', () => {
  //       mockServiceCreator = getService();
  //       store
  //         .dispatch(
  //           getVacations(
  //             {},
  //             mockServiceCreator({ type: 'FETCH_PACKAGES', response: packages })
  //           )
  //         )
  //         .then(() => {
  //           expect(store.getActions()).toContainEqual({
  //             type: 'FETCH_PACKAGES',
  //             payload: packages
  //           });
  //         });
  //       store.clearActions();
  //     });

  //     it('FeaturedBanner::Actions::Failed', done => {
  //       mockServiceCreator = getService(false);
  //       store
  //         .dispatch(
  //           getVacations(
  //             {},
  //             mockServiceCreator({ type: 'FETCH_PACKAGES', response: packages })
  //           )
  //         )
  //         .then(() => {
  //           expect(store.getActions()).toContainEqual({
  //             type: 'FETCH_PACKAGES_ERROR'
  //           });
  //           done();
  //         });
  //     });

  //     it('FeaturedBanner::Reducer::Failed', () => {
  //       mockServiceCreator = getService(false);
  //       store
  //         .dispatch(
  //           getVacations({}, mockServiceCreator({ type: 'FETCH_PACKAGES' }))
  //         )
  //         .then(() => {
  //           expect(vacationsReducer(null, store.getActions()[0]).hasError).toBe(
  //             true
  //           );
  //         });
  //     });

  //     it('FeaturedBanner::Reducer::Failed::WithoutPayload', () => {
  //       mockServiceCreator = getService(true);
  //       store
  //         .dispatch(
  //           getVacations({}, mockServiceCreator({ type: 'FETCH_PACKAGES' }))
  //         )
  //         .then(() => {
  //           expect(vacationsReducer(null, store.getActions()[0]).hasError).toBe(
  //             false
  //           );
  //           expect(!vacationsReducer(null, store.getActions()[0]).content).toBe(
  //             true
  //           );
  //         });
  //     });
  //     it('FeaturedBanner::Reducer::Success', () => {
  //       mockServiceCreator = getService(true);
  //       store
  //         .dispatch(
  //           getVacations(
  //             {},
  //             mockServiceCreator({ type: 'FETCH_PACKAGES', response: packages })
  //           )
  //         )
  //         .then(() => {
  //           expect(vacationsReducer(null, store.getActions()[0]).hasError).toBe(
  //             false
  //           );
  //         });
  //     });
  //   });
});
