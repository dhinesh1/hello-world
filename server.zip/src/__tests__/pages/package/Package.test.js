import React from 'react';
import { shallow } from 'enzyme';
import Packages from '../../../pages/packageV3/Packages';
import {
  CustomProvider,
  getPackagesProps
} from '../../../__actions__/__services';
const LocalProps = getPackagesProps();

it('Packages root renders without crashing', () => {
  shallow(
    <CustomProvider>
      <Packages {...LocalProps} />
    </CustomProvider>
  );
});
