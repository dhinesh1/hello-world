import React from 'react';
import { shallow } from 'enzyme';
import Sem from '../../../pages/sem/Sem';
import {
  CustomProvider,
  getPackagesProps
} from '../../../__actions__/__services';

const LocalProps = getPackagesProps();

describe('SEM Page', () => {
  it('SEM :: Render', () => {
    shallow(
      <CustomProvider {...LocalProps}>
        <Sem />
      </CustomProvider>
    );
  });
});
