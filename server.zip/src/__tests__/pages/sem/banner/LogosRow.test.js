import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import LogosRow from '../../../../pages/sem/banner/LogosRow';

describe('SEM Logos row', () => {
  it('LogosRow :: Render', () => {
    shallow(<LogosRow />);
  });
});
