import React from 'react';
import { shallow } from 'enzyme';
import SemBanner from '../../../../pages/sem/banner/SemBanner';
import {
  CustomProvider,
  getPackagesProps
} from '../../../../__actions__/__services';

const LocalProps = getPackagesProps();

describe('SEM Page Banner', () => {
  it('SemBanner :: Render', () => {
    shallow(
      <CustomProvider {...LocalProps}>
        <SemBanner />
      </CustomProvider>
    );
  });
});
