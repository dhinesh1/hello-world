import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import FeaturedBanner from '../../../../pages/packageV3/banner/FeaturedBanner';
import { getVacations } from '../../../../__actions__/__actions.app';
import getVacation from '../../../../__fixtures__/getVacationResponse';
import { vacationsReducer } from '../../../../store/vacationsReducer';
import { getService, getMockStore } from '../../../../__actions__/__services';
const mockStore = getMockStore();

/** To Set the service for mock */
let mockServiceCreator;

describe('Campaign Featured Banner', () => {
  const vacations = getVacation;
  describe('Campaign::Featured::Banner::Render', () => {
    it('FeaturedBanner::Crashing', () => {
      shallow(<FeaturedBanner />);
    });

    // it('FeaturedBanner::Snapshot::WithoutArguments', () => {
    //   const renderedValue = renderer.create(<FeaturedBanner />).toJSON();
    //   expect(renderedValue).toMatchSnapshot();
    // });

    it('FeaturedBanner::Snapshot::WithArguments', () => {
      const renderedValue = renderer
        .create(<FeaturedBanner {...vacations} />)
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('FeaturedBanner::BannerText', () => {
      let wrapper = shallow(<FeaturedBanner {...vacations} />);
      expect(wrapper.find('.boxed-meta p').text()).toBe(
        getVacation.campaignDetails.bannerText
      );
    });
  });

  describe('Campaign Featured Banner::Action::Reducer', () => {
    let store;

    beforeEach(() => {
      store = mockStore({});
    });
    afterEach(() => {
      store.clearActions();
    });

    it('FeaturedBanner::Actions::Success', () => {
      mockServiceCreator = getService();
      store
        .dispatch(
          getVacations(
            {},
            mockServiceCreator({ type: 'FETCH_VACATIONS', response: vacations })
          )
        )
        .then(() => {
          expect(store.getActions()).toContainEqual({
            type: 'FETCH_VACATIONS',
            payload: vacations
          });
        });
      store.clearActions();
    });

    it('FeaturedBanner::Actions::Failed', done => {
      mockServiceCreator = getService(false);
      store
        .dispatch(
          getVacations(
            {},
            mockServiceCreator({ type: 'FETCH_VACATIONS', response: vacations })
          )
        )
        .then(() => {
          expect(store.getActions()).toContainEqual({
            type: 'FETCH_VACATIONS_ERROR'
          });
          done();
        });
    });

    it('FeaturedBanner::Reducer::Failed', () => {
      mockServiceCreator = getService(false);
      store
        .dispatch(
          getVacations({}, mockServiceCreator({ type: 'FETCH_VACATIONS' }))
        )
        .then(() => {
          expect(vacationsReducer(null, store.getActions()[0]).hasError).toBe(
            true
          );
        });
    });

    it('FeaturedBanner::Reducer::Failed::WithoutPayload', () => {
      mockServiceCreator = getService(true);
      store
        .dispatch(
          getVacations({}, mockServiceCreator({ type: 'FETCH_VACATIONS' }))
        )
        .then(() => {
          expect(vacationsReducer(null, store.getActions()[0]).hasError).toBe(
            false
          );
          expect(!vacationsReducer(null, store.getActions()[0]).content).toBe(
            true
          );
        });
    });
    it('FeaturedBanner::Reducer::Success', () => {
      mockServiceCreator = getService(true);
      store
        .dispatch(
          getVacations(
            {},
            mockServiceCreator({ type: 'FETCH_VACATIONS', response: vacations })
          )
        )
        .then(() => {
          expect(vacationsReducer(null, store.getActions()[0]).hasError).toBe(
            false
          );
        });
    });
  });
});
