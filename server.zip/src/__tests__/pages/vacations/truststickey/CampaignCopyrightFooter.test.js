import React from 'react';
import renderer from 'react-test-renderer';
import CampaignCopyrightFooter from '../../../../pages/PVCommonComponents/CampaignCopyrightFooter';
import { BrowserRouter } from 'react-router-dom';

describe('Campaign Copy Right Footer', () => {
  it('Campaign-Copy-Right-Footer :: Snapshot', () => {
    const renderedValue = renderer
      .create(
        <BrowserRouter>
          <CampaignCopyrightFooter />
        </BrowserRouter>
      )
      .toJSON();
    expect(renderedValue).toMatchSnapshot();
  });
});
