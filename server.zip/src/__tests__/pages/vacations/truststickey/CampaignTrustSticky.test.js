import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import CampaignTrustSticky from '../../../../pages/packageV3/trustSticky/TrustSticky';
import * as enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
enzyme.configure({ adapter: new Adapter() });

import { getVacationsProps } from '../../../../__actions__/__services';
const LocalProps = getVacationsProps();

describe('Campaign Trust Sticky React Component', () => {
  let wrapper;
  beforeEach(() => {
    wrapper = shallow(<CampaignTrustSticky {...LocalProps.packages} />);
  });
  it('Campaign-Trust-Sticky :: Snapshot', () => {
    const renderedValue = renderer
      .create(<CampaignTrustSticky {...LocalProps.packages} />)
      .toJSON();
    expect(renderedValue).toMatchSnapshot();
  });
  // it('Campaign-Trust-Sticky :: Render', () => {
  //   expect(wrapper.contains('Instant Personalisation')).toBe(true);
  // });
  it('Campaign-Trust-Sticky :: Help Button', () => {
    expect(wrapper.find('button.btn-primary').type()).toEqual('button');
  });
  it('Campaign-Trust-Sticky :: Pull-up', () => {
    wrapper.setState({ showTrustBlock: true });
    expect(wrapper.find('section.pull-up')).not.toBe(null);
  });
});
