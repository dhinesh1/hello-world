import React from 'react';
import { shallow } from 'enzyme';
import Packages from '../../../pages/packageV3/Packages';
import {
  getVacationsProps,
  CustomProvider
} from '../../../__actions__/__services';
const LocalProps = getVacationsProps();

it('Vacations root renders without crashing', () => {
  shallow(
    <CustomProvider>
      <Packages {...LocalProps} />
    </CustomProvider>
  );
});
