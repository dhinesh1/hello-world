import React from 'react';
import { shallow } from 'enzyme';
import CampaignMiddleCol from '../../../../pages/PVCommonComponents/MiddleCol';

it('Campaign Middle Column renders without crashing', () => {
  shallow(<CampaignMiddleCol />);
});
