import React from 'react';
import { shallow } from 'enzyme';
import {
  PackageCardList,
  SinglePackageCard
} from '../../../../pages/packageV3/PackagesContent/PackagesContent';
import PackagesContent from '../../../../pages/packageV3/PackagesContent/PackagesContent';
import renderer from 'react-test-renderer';
import { BrowserRouter } from 'react-router-dom';
import {
  getVacationsProps,
  CustomProvider,
  getEventParams
} from '../../../../__actions__/__services';
const LocalProps = getVacationsProps();

describe('Campaign Content', () => {
  const vacations = LocalProps.packages;
  const length = vacations && vacations.filteredItineraries.length;
  describe('Campaign::Content::Render', () => {
    it('Campaign::content::renders::without-crashing', () => {
      shallow(<PackagesContent {...LocalProps} />);
    });
    // it('Campaign::Content::Snapshot', () => {
    //   const renderedValue = renderer.create(<CustomProvider><BrowserRouter><PackagesContent {...LocalProps}/></BrowserRouter></CustomProvider>).toJSON();
    //   expect(renderedValue).toMatchSnapshot();
    // });
  });

  describe('Campaign::Content::Render::Element', () => {
    let wrapper;
    let props = LocalProps;
    props.isTestCase = true;
    beforeEach(() => {
      wrapper = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <PackagesContent {...props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
    });

    it('Campaign::Content::TotalElements', () => {
      // here 8 is AdSection
      expect(wrapper.children.length).toBe(length + 9);
    });

    it('Campaign::Content::Checking Add Sections', () => {
      for (let i = 0; i < length; i++) {
        if (i % 6 === 3) {
          expect(wrapper.children[i].children.length === 2).toBe(true);
          expect(wrapper.children[i].children[0].props.className).toBe(
            'mbottom-medium'
          );
          expect(wrapper.children[i].children[0].children[0]).toBe(
            'Looking for something more customised to meet your taste?'
          );
          expect(wrapper.children[i].children[1].children[0].type).toBe(
            'button'
          );
          expect(wrapper.children[i].children[1].children[2].type).toBe('b');
          expect(wrapper.children[i].props.className).toBe(
            'clearfix ad-section'
          );
        }
      }
    });

    it('Campaign::Content::Vacation::Checking', () => {
      let element = wrapper.children[0];
      expect(element.children[0].props.className).toBe('left-col hidden-xs');
      expect(element.children[0].children[0].props.className).toBe(
        'pkg-slider slick-initialized slick-slider slick-dotted'
      );
      let middleColumn = element.children[1];
      expect(middleColumn.children[0].props.className).toBe('xs-banner-holder');
      expect(
        middleColumn.children[0].children[0].children[0].children[0].children[0]
      ).toBe(vacations.filteredItineraries[0].title);
    });

    it('Campaign::Content::Vacation::Checking::itinerary::cost', () => {
      let element;
      let j = 0;
      for (let i = 0; i < length; i++) {
        if (j % 6 === 3) {
          j++;
        }
        element =
          wrapper.children[j].children[2].children[0].children[0].children[1];
        expect(+element.props.content).toBe(
          Math.ceil(vacations.filteredItineraries[i].itineraryCost)
        );
        j++;
      }
    });
  });

  describe('Campaign::Content::GetCostModel', () => {
    let shallowElement;
    let props = LocalProps;
    props.isTestCase = true;
    beforeEach(() => {
      shallowElement = shallow(<PackagesContent {...props} />);
    });

    it('Campaign::Content::Checking::Itinerary-ID::Once', () => {
      let campaignContent = shallowElement.getElements()[0].props.children[1];
      let campaignCardList = shallow(
        <PackageCardList {...campaignContent.props} />
      );
      let singleCardElement;
      let paths;
      let props;
      for (let i = 0; i < length; i++) {
        if (!(i % 6 === 3)) {
          singleCardElement = shallow(
            <SinglePackageCard {...campaignCardList.getElements()[i].props} />
          );
          singleCardElement.simulate('click', getEventParams());
          props = shallowElement.instance().props;
          paths = props.history.location.pathname.split('/');
          expect(paths[2]).toBe('get-cost');
          expect(
            paths[3] ===
              props.packages.filteredItineraries[i].campaignItineraryId
          ).toBe(!i);
        }
      }
    });

    it('Campaign::Content::Checking::Itinerary-ID::All', () => {
      let campaignContent = shallowElement.getElements()[0].props.children[1];
      let campaignCardList = shallow(
        <PackageCardList {...campaignContent.props} />
      );
      let singleCardElement;
      let paths;
      let props;
      let j = 0;
      for (let i = 0; i < length; i++) {
        if (j % 6 === 3) {
          j++;
        }
        shallowElement.instance().props.history.location.pathname = '/';
        singleCardElement = shallow(
          <SinglePackageCard {...campaignCardList.getElements()[j].props} />
        );
        singleCardElement.simulate('click', getEventParams());
        props = shallowElement.instance().props;
        paths = props.history.location.pathname.split('/');
        expect(paths[2]).toBe('get-cost');
        expect(paths[3]).toBe(
          props.packages.filteredItineraries[i].campaignItineraryId
        );
        j++;
      }
    });

    it('Campaign::Content::Checking::SingleCard::Snapshot', () => {
      let campaignContent = shallowElement.getElements()[0].props.children[1];
      let campaignCardList = shallow(
        <PackageCardList {...campaignContent.props} />
      );
      let renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <SinglePackageCard {...campaignCardList.getElements()[0].props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });
  });
});
