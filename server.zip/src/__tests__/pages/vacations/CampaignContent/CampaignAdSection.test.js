import React from 'react';
import { shallow } from 'enzyme';
import CampaignAdSection from '../../../../pages/PVCommonComponents/Adsection';

import renderer from 'react-test-renderer';
import {
  getVacationsProps,
  CustomProvider
} from '../../../../__actions__/__services';
import RequestCallbackModal from '../../../../pages/itinerary/request_callback_modal';
import { BrowserRouter } from 'react-router-dom';
const LocalProps = getVacationsProps();

describe('Campaign Ad Section', () => {
  const vacations = LocalProps.packages;
  describe('Campaign::Content::Render', () => {
    it('Campaign Ad section::renders without crashing', () => {
      shallow(<CampaignAdSection {...LocalProps} />);
    });
  });

  describe('Campaign::Ad::Section', () => {
    it('Campaign::AdSection::Button::Customize::Aus', () => {
      let shallowElement = shallow(<CampaignAdSection {...LocalProps} />);
      shallowElement.find('button').simulate('click');
      expect(shallowElement.instance().props.history.location.pathname).toBe(
        '/customize'
      );
    });

    it('Campaign::AdSection::Link::Callback', () => {
      let shallowElement = shallow(<CampaignAdSection {...LocalProps} />);
      shallowElement.find('.tracker-pkg-talkbtn').simulate('click');
      expect(shallowElement.find('.tracker-pkg-talkbtn').props('to').to).toBe(
        '/customize/request-callback'
      );
      expect(
        shallowElement.find('.tracker-pkg-talkbtn').props('to').children
      ).toBe('Talk to our travel consultants');
    });

    it('Campaign::Request::CallBack::Snapshot', () => {
      let renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RequestCallbackModal {...LocalProps} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });
  });
});
