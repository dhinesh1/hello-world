import React from 'react';
import { shallow } from 'enzyme';
import CampaignSlider from '../../../../pages/PVCommonComponents/ImageSlider';

it('Campaign Slider renders without crashing', () => {
  shallow(<CampaignSlider {...{ imageUrl: '' }} />);
});
