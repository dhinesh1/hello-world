import CampaignTestiMonial from '../../../../pages/PVCommonComponents/TestiMonial';
import React from 'react';
import { shallow } from 'enzyme';
import CampaignContent from '../../../../pages/packageV3/PackagesContent/PackagesContent';
import renderer from 'react-test-renderer';
import { BrowserRouter } from 'react-router-dom';
import {
  getVacationsProps,
  CustomProvider
} from '../../../../__actions__/__services';
const LocalProps = getVacationsProps();

describe('Testimonials', () => {
  const vacations = LocalProps.packages;
  describe('Campaign::Testimonials', () => {
    it('Campaign::Testimonials::without::crashing', () => {
      shallow(<CampaignTestiMonial />);
    });
  });

  describe('Campaign::Testimonials::Render::Element', () => {
    let wrapper;
    let props = LocalProps;
    props.isTestCase = true;
    beforeEach(() => {
      wrapper = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <CampaignContent {...props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
    });
    it('Campaign::Content::Checking Offer Section::testimonials', () => {
      let length = vacations.filteredItineraries.length;
      let initial = true;
      let index = 0;
      length += Math.floor(length / 6);
      for (let i = 0; i < length; i++) {
        if (!(i % 6 === 3)) {
          if ((index % 2 === 1 && initial) || (index % 3 === 1 && !initial)) {
            expect(wrapper.children[i].children.length).toBe(4);
            expect(wrapper.children[i].children[3].props.className).toBe(
              'clearfix fw btm-info fb hidden-xs'
            );
            initial = false;
          } else if (index % 3 === 2) {
            expect(wrapper.children[i].children[3].props.className).toBe(
              'clearfix fw btm-info hidden-xs'
            );
          } else {
            expect(wrapper.children[i].children.length).toBe(3);
          }
          index++;
        }
      }
    });

    it('Campaign::Content::Vacation::Checking::Statistics', () => {
      let length = vacations.filteredItineraries.length;
      let element;
      let j = 0;
      for (let i = 0; i < length; i++) {
        if (j % 6 === 3) {
          j++;
        }
        element =
          wrapper.children[j].children[1].children[1].children[2].children[0]
            .children[1].props.className;
        expect(element).toBe('pill-outline bg grey-light');
        j++;
      }
    });
  });
});
