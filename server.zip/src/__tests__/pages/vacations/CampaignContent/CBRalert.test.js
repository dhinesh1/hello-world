import React from 'react';
import { shallow } from 'enzyme';
import CBRSuccessAlert from '../../../../pages/PVCommonComponents/CBRalert';
import {
  getVacationsProps,
  CustomProvider
} from '../../../../__actions__/__services';

import renderer from 'react-test-renderer';
import { createMemoryHistory } from 'history';
const LocalProps = {
  history: createMemoryHistory()
};

describe('Campaign::Content::Render', () => {
  it('CBRsuccess alert renders without crashing', () => {
    shallow(
      <CustomProvider>
        <CBRSuccessAlert {...LocalProps} />
      </CustomProvider>
    );
  });
});
