import React from 'react';
import { shallow } from 'enzyme';
import CampaignLogo from '../../../../pages/PVCommonComponents/CampaignLogo';
import renderer from 'react-test-renderer';

describe('Campaign Logo Component', () => {
  let wrapper;
  it('Campaign-Logo :: Crash', () => {
    shallow(<CampaignLogo />);
  });
  it('Campaign-Logo :: Snapshot :: Without Props', () => {
    wrapper = shallow(<CampaignLogo />);
    const renderedValue = renderer.create(<CampaignLogo />).toJSON();
    expect(renderedValue).toMatchSnapshot();
  });
  const propData = {
    vacations: {
      campaignDetails: {
        region: '',
        logoUrl: ''
      }
    }
  };
  it('Campaign-Logo :: Snapshot :: With Props', () => {
    // Passing parameter is temporary
    const renderedValue = renderer
      .create(<CampaignLogo {...propData} />)
      .toJSON();
    expect(renderedValue).toMatchSnapshot();
  });
  it('Campaign-Logo :: Child-Element', () => {
    wrapper = shallow(<CampaignLogo {...propData} />);
    const tabItem = wrapper.find('.list-inline');
    expect(tabItem.getElement(0).props.children.length).toBe(4);
  });
});
