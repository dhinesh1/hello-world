import React from 'react';
import { shallow } from 'enzyme';
import AboutUs from '../../../pages/about/AboutUs';
import {
    CustomProvider
  } from '../../../__actions__/__services';


it('About us page render without crashing', () => {
  shallow(
    <CustomProvider>
      <AboutUs />
    </CustomProvider>
  );
});
