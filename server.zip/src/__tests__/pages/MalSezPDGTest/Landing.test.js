import React from 'react';
import { shallow } from 'enzyme';
import {
  getMaldivesProps,
  CustomProvider
} from '../../../__actions__/__services';
import maldivesLanding from '../../../pages/pdg/mlesezLanding';
const LocalProps = getMaldivesProps();

it('Maldives root renders without crashing', () => {
  shallow(
    <CustomProvider>
      <mlesezLanding {...LocalProps} />
    </CustomProvider>
  );
});
