import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import GetCostModal from '../../pages/itinerary/get_cost_modal';
import RenderMobileContent from '../../pages/itinerary/components/get_cost_components/costing_mobile_panel';
import { CustomProvider } from '../../__actions__/__services';
import { BrowserRouter } from 'react-router-dom';
import { getDefaultProps } from '../../__fixtures__/getDefaultProps';
const props = getDefaultProps;
/** To Set the service for mock */
const allSuggestions = [
  { cityName: 'Nagpur, IN', airportCode: 'NAG', popular: false, distance: 0 },
  { cityName: 'Jaipur, IN', airportCode: 'JAI', popular: false, distance: 0 },
  {
    cityName: 'Coimbatore, IN',
    airportCode: 'CJB',
    popular: false,
    distance: 0
  },
  { cityName: 'Chennai, IN', airportCode: 'MAA', popular: true, distance: 0 },
  { cityName: 'Kochi, IN', airportCode: 'COK', popular: false, distance: 0 },
  { cityName: 'Bengaluru, IN', airportCode: 'BLR', popular: true, distance: 0 },
  { cityName: 'Mumbai, IN', airportCode: 'BOM', popular: true, distance: 0 },
  { cityName: 'Kolkata, IN', airportCode: 'CCU', popular: true, distance: 0 },
  { cityName: 'Hyderabad, IN', airportCode: 'HYD', popular: true, distance: 0 },
  { cityName: 'Delhi, IN', airportCode: 'DEL', popular: true, distance: 0 },
  { cityName: 'Trichy, IN', airportCode: 'TRZ', popular: false, distance: 0 },
  {
    cityName: 'Ahmedabad, IN',
    airportCode: 'AMD',
    popular: false,
    distance: 0
  },
  { cityName: 'Amritsar, IN', airportCode: 'ATQ', popular: false, distance: 0 },
  {
    cityName: 'Trivandrum, IN',
    airportCode: 'TRV',
    popular: true,
    distance: 0
  },
  { cityName: 'Lucknow, IN', airportCode: 'LKO', popular: false, distance: 0 },
  {
    cityName: 'Bhubaneshwar, IN',
    airportCode: 'BBI',
    popular: false,
    distance: 0
  }
];
const costingConfiguration = {
  bookingPlan_Text: 'YES',
  departureAirport: 'BLR',
  departureAirport_Text: '',
  departureCity: '',
  departureDate: '28/Mar/2019',
  hotelGuestRoomConfigurations: [
    {
      adultCount: 2,
      childAges: []
    },
    {
      adultCount: 2,
      childAges: [1, 2]
    }
  ],
  packageRate: false,
  passengerConfig: 4
};

describe('GCM', () => {
  describe('GCM::Render', () => {
    it('GCM::Crashing', () => {
      shallow(
        <CustomProvider>
          <BrowserRouter>
            <GetCostModal />
          </BrowserRouter>
        </CustomProvider>
      );
    });

    it('GCM::WithoutArguments', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <GetCostModal {...props} isTestKilled={true} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('GCM::LeftSidePanel', () => {
      let props = {
        activities: '135',
        flights: '132',
        hotels: '865',
        image:
          'https://pyt-images.imgix.net/images/get_cost_modal/gcm_bg_4.jpeg',
        regionName: 'Bali',
        transfers: '204'
      };
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <GetCostModal regionStatus={props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('GCM::MobileCompoennt::STEP1', () => {
      let props = {
        currentAction: 'STEP1',
        costingHandler: () => {},
        allSuggestions: allSuggestions,
        costingConfiguration: costingConfiguration,
        setMobileActions: () => {}
      };
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RenderMobileContent {...props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('GCM::MobileCompoennt::STEP2', () => {
      let props = {
        currentAction: 'STEP2',
        costingHandler: () => {},
        allSuggestions: allSuggestions,
        costingConfiguration: costingConfiguration,
        setMobileActions: () => {}
      };
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RenderMobileContent {...props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('GCM::MobileCompoennt::STEP3', () => {
      let props = {
        currentAction: 'STEP3',
        costingHandler: () => {},
        allSuggestions: allSuggestions,
        costingConfiguration: costingConfiguration,
        setMobileActions: () => {},
        costingDate: '28/Mar/2019'
      };
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <RenderMobileContent {...props} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });
  });
});
