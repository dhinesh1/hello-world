import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import PaymentSuccess from '../../pages/payment/PaymentSuccess';
import { CustomProvider } from '../../__actions__/__services';
import { getPayemntUsereResponse } from '../../__fixtures__/getPaymentResponse';
import { BrowserRouter } from 'react-router-dom';
/** To Set the service for mock */

const LocalFailureProps = getPayemntUsereResponse();
describe('Payment Success', () => {
  describe('Payment::Success::Render', () => {
    it('Payment::Success::Crashing', () => {
      shallow(
        <CustomProvider>
          <BrowserRouter>
            <PaymentSuccess />
          </BrowserRouter>
        </CustomProvider>
      );
    });

    it('Payment::Success::Snapshot::WithoutArguments', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <PaymentSuccess />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Payment::Success::Snapshot::WithArguments::Failed::Cancel', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <PaymentSuccess {...LocalFailureProps} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Payment::Success::Snapshot::WithArguments::Success', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <PaymentSuccess {...getPayemntUsereResponse(true, 'SUCCESS')} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Payment::Success::Snapshot::WithArguments::WithoutStatus', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <PaymentSuccess {...getPayemntUsereResponse(false)} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });
  });
});
