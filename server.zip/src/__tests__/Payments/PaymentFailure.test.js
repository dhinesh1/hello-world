import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import PaymentFailure from '../../pages/payment/PaymentFailure';
import { CustomProvider } from '../../__actions__/__services';
import { getPayemntUsereResponse } from '../../__fixtures__/getPaymentResponse';
import { BrowserRouter } from 'react-router-dom';
/** To Set the service for mock */

const LocalFailureProps = getPayemntUsereResponse();
describe('Payment Failure', () => {
  describe('Payment::Failure::Render', () => {
    it('Payment::Failure::Crashing', () => {
      shallow(
        <CustomProvider>
          <BrowserRouter>
            <PaymentFailure />
          </BrowserRouter>
        </CustomProvider>
      );
    });

    it('Payment::Failure::Snapshot::WithoutArguments', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <PaymentFailure />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Payment::Failure::Snapshot::WithArguments::Failed::Cancel', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <PaymentFailure {...LocalFailureProps} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('Payment::Failure::Snapshot::WithArguments::WithoutStatus', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <PaymentFailure {...getPayemntUsereResponse(false)} />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });
  });
});
