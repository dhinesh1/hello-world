import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import { CustomProvider } from '../../__actions__/__services';
import { getLivePriceResponse } from '../../__fixtures__/getLivePrice';
import { BrowserRouter } from 'react-router-dom';
import MakePayment from '../../pages/MakePayment';
/** To Set the service for mock */

describe('Make payment', () => {
  describe('MakePayment::Render', () => {
    it('MakePayment::Crashing', () => {
      shallow(
        <CustomProvider>
          <BrowserRouter>
            <MakePayment />
          </BrowserRouter>
        </CustomProvider>
      );
    });

    it('MakePayment::Snapshot::WithoutArguments', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider>
            <BrowserRouter>
              <MakePayment />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });

    it('MakePayment::Snapshot::WithArguments::Admin', () => {
      const renderedValue = renderer
        .create(
          <CustomProvider state={getLivePriceResponse('ADMIN')}>
            <BrowserRouter>
              <MakePayment />
            </BrowserRouter>
          </CustomProvider>
        )
        .toJSON();
      expect(renderedValue).toMatchSnapshot();
    });
  });
});
