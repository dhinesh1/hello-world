import React from 'react';
import {
  TextBlock,
  TextRow,
  RectShape,
  RoundShape
} from 'react-placeholder/lib/placeholders';

export function SingleBookedItineraryCard() {
  return (
    <div className={'col-xs-3'}>
      <div className={'row'}>
        <div className={'col-xs-12'}>
          <RectShape
            style={{ height: 160 }}
            color="transparent"
            className="animated-background"
          />
        </div>
      </div>

      <div className={'row vmargin-medium mb-0'}>
        <div className={'col-xs-12'}>
          <TextBlock
            rows={2}
            color="transparent"
            className="animated-background"
          />
        </div>
      </div>
      <div className={'row'}>
        <div className={'col-xs-12'}>
          <TextRow color="transparent" className="animated-background" />
        </div>
      </div>
    </div>
  );
}

export function PackagesItineraryCardLoader() {
  return (
    <div className="row">
      <SingleBookedItineraryCard />
      <SingleBookedItineraryCard />
      <SingleBookedItineraryCard />
      <SingleBookedItineraryCard />
    </div>
  );
}

export function SinglePackagesItineraryCard() {
  return (
    <div className={'col-xs-3'}>
      <div className={'row'}>
        <div className={'col-xs-12'}>
          <RectShape
            style={{ height: 280 }}
            color="transparent"
            className="animated-background"
          />
        </div>
      </div>

      <div className={'row vmargin-medium mb-0'}>
        <div className={'col-xs-12'}>
          <TextBlock
            rows={2}
            color="transparent"
            className="animated-background"
          />
        </div>
      </div>
      <div className={'row'}>
        <div className={'col-xs-12'}>
          <TextRow color="transparent" className="animated-background" />
        </div>
      </div>
    </div>
  );
}

export function SingleTestimonialCard() {
  return (
    <div className={'col-xs-3'}>
      <div className={'row'}>
        <div className={'col-xs-12'}>
          <RoundShape
            style={{ height: 180, width: 180, margin: '0 auto' }}
            color="transparent"
            className="animated-background"
          />
        </div>
      </div>

      <div className={'row vmargin-medium mb-0'}>
        <div className={'col-xs-12'}>
          <TextBlock
            rows={2}
            color="transparent"
            className="animated-background"
          />
        </div>
      </div>
      <div className={'row vmargin-medium mb-0'}>
        <div className={'col-xs-12'}>
          <TextBlock
            rows={3}
            color="transparent"
            className="animated-background"
          />
        </div>
      </div>
      <div className={'row'}>
        <div className={'col-xs-12'}>
          <TextRow color="transparent" className="animated-background" />
        </div>
      </div>
    </div>
  );
}

export function ThemedCardLoader({ testimonialPosition }) {
  return (
    <div className="row">
      {!testimonialPosition || testimonialPosition === 0 ? (
        <SingleTestimonialCard />
      ) : null}
      <SinglePackagesItineraryCard />
      {testimonialPosition === 1 ? <SingleTestimonialCard /> : null}
      <SinglePackagesItineraryCard />
      {testimonialPosition === 2 ? <SingleTestimonialCard /> : null}
      <SinglePackagesItineraryCard />
      {testimonialPosition === 3 ? <SingleTestimonialCard /> : null}
    </div>
  );
}

export function SingleBookedItineraryCardMobile() {
  return (
    <div className={'col-xs-10 col-xs-offset-1'}>
      <div className={'row'}>
        <div className={'col-xs-12'}>
          <RectShape
            style={{ height: 120, marginBottom: '15px' }}
            color="transparent"
            className="animated-background"
          />
        </div>
      </div>
    </div>
  );
}

export function RecentlyBookedItinerariesMobile() {
  return (
    <div className="row">
      <SingleBookedItineraryCardMobile />
    </div>
  );
}
