import React, { Component } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import placeHolderUrls from './Image/place_holder_urls';
import ImageGallery from 'react-image-gallery';
import SmartImage from './Image/smart_image';
import StarRating from './StarRating';
import { TripAdvisorRating } from './Components';
import HotelRoomRow from '../common_components/itinerary/hotel_room_row';
import HappinessRating from '../common_components/happiness_rating';
import Slider from 'react-slick';
import { isMobile } from '../helpers/utilsHelper';

class HotelContainer extends Component {
  static propTypes = {
    hotel: PropTypes.object.isRequired,
    itineraryDetail: PropTypes.object.isRequired,
    userDetails: PropTypes.object.isRequired,
    packageRate: PropTypes.number.isRequired,
    itineraryId: PropTypes.number.isRequired,
    hotelGuestRoomConfigurations: PropTypes.object.isRequired,
    allowChangeRoom: PropTypes.bool.isRequired,
    showThisModal: PropTypes.func,
    splitPricing: PropTypes.bool,
    showImages: PropTypes.bool.isRequired
  };

  state = {
    show_Gallery: false,
    gallery_images: []
  };

  viewPhotos = () => {
    let gallery_images = [];
    this.props.hotel.otherImages.map(imglink => {
      gallery_images.push({ original: imglink, thumbnail: imglink });
    });

    this.setState({ show_Gallery: true, gallery_images: gallery_images });
  };

  closeGallery = () => {
    this.setState({ show_Gallery: false, gallery_images: [] });
  };

  renderRoomsHelper = () => {
    const { hotel, makeReadOnly } = this.props;

    if (hotel && hotel.roomsInHotel) {
      let rooms = hotel.roomsInHotel;
      return rooms.map((room, key) => {
        let room_no = key + 1;
        return (
          <HotelRoomRow
            splitPricing={this.props.itineraryDetail.splitPricing}
            itineraryDetail={this.props.itineraryDetail}
            userDetails={this.props.userDetails}
            packageRate={this.props.packageRate}
            itineraryId={this.props.itineraryId}
            isCurrentPick={false}
            onHotelDetails={true}
            room={room}
            room_no={room_no}
            key={Math.random()}
            hotel={hotel}
            allowChangeRoom={makeReadOnly? false : this.props.allowChangeRoom}
            makeReadOnly={makeReadOnly}
            hotelGuestRoomConfigurations={
              this.props.hotelGuestRoomConfigurations
            }
          />
        );
      });
    }
  };

  renderAmenity = (amenity, index) => {
    if (!amenity.strikethrough) {
      return (
        <li key={index}>
          <span className={amenity.iconUrl} />
          <p>{amenity.amenityName}</p>
        </li>
      );
    } else {
      return (
        <li key={index}>
          <s className="amenities-s">{amenity.amenityName}</s>
        </li>
      );
    }
  };

  render() {
    const { hotel, showImages } = this.props;
    const desc_innerHtml = hotel.description;
    let settings = {
      dots: false,
      infinite: true,
      speed: 500,
      slidesToShow: isMobile() ? 1 : 2,
      slidesToScroll: 1
    };
    let hotelReviews = null;
    if (hotel.reviewsList && hotel.reviewsList.length) {
      hotelReviews = hotel.reviewsList.map((review, index) => {
        return (
          <div key={index} className="col-xs-12 col-md-6 cust-feedback">
            <div className="cust-details">
              {/* <div className="dp"><img src="https://scontent.fmaa3-1.fna.fbcdn.net/v/t1.0-1/p64x64/13615280_10154796658955639_5270391872026573490_n.jpg?oh=33db289dc11617709ed10650b16460ee&oe=599A8844" /></div> */}
              <span className="h6 name">{review.reviewerName}</span>
              {/*<time className="small dim">May 2016 <a href="#" title="View on facebook" className="secondary-link">&nbsp;<span className="vehoicon-facebook-square" /></a></time>*/}
            </div>
            <p className="meta-text">{review.reviewText}</p>
            {/* <span className="small micro fade block"><sup>*</sup> Did this activity as part of <a href="#" className="secondary-link underline">Walking tour of Ubud and neighbouring</a></span> */}
          </div>
        );
      });
    }
    return [
      showImages ? (
        <div className="media-shell round-none heightAdjust" key={0}>
          {this.state.show_Gallery ? (
            <div>
              <ImageGallery
                className="animated fadeIn"
                items={this.state.gallery_images}
                showFullscreenButton={false}
                showNav={false}
                showPlayButton={false}
                showIndex={true}
                defaultImage={placeHolderUrls.hotelLarge}
              />
            </div>
          ) : (
            <div className="this">
              <figure className="hd act-img">
                <SmartImage
                  src={hotel.imageURL}
                  alt={hotel.name}
                  defaultImage={placeHolderUrls.hotelLarge}
                />
              </figure>
            </div>
          )}
          {!this.state.show_Gallery ? (
            <button
              className="showGallery btn btn-light btn-sm"
              onClick={this.viewPhotos}
            >
              View Photos
            </button>
          ) : (
            <button
              className=" btn btn-light btn-sm closeGallery"
              onClick={this.closeGallery}
            >
              Close Photos
            </button>
          )}
        </div>
      ) : null,
      <div
        className={classNames('modal-row ', { 'pt-0': !showImages })}
        key={1}
      >
        <div className="item-header">
          <h3>{hotel.name}</h3>
          <span className="p block">
            <span className="bold color-secondary schedule">
              {hotel.checkInMonthDisplay} {hotel.checkInDateDisplay} to{' '}
              {hotel.checkOutMonthDisplay} {hotel.checkOutDateDisplay}{' '}
            </span>{' '}
            —{' ' + hotel.location + ' '}
            <a
              href={`http://maps.google.com/?q=${hotel.lat},${hotel.lon}`}
              className="secondary-link dashed-underline"
              target="_blank"
              rel="noopener noreferrer"
            >
              <i className="vehoicon-map-marker" />
              {' map view'}
            </a>
          </span>
        </div>
        <div className="at-a-glance clearfix">
          <div className="col-xs-6 col-md-3">
            <span className="meta-text dim block">Category</span>
            <StarRating rating={hotel.stars} fillEmpty={false} />
          </div>
          <div className="col-xs-6 col-md-3">
            <span className="meta-text dim block">Duration</span>
            {hotel.numberOfNights} Nights
          </div>
          <div className="col-xs-6 col-md-3">
            <span className="meta-text dim block">Bookings</span>
            {hotel.roomsInHotel && hotel.roomsInHotel.length}{' '}
            {hotel.roomsInHotel && hotel.roomsInHotel.length > 1
              ? 'Rooms'
              : 'Room'}
          </div>
          {hotel.finalPrice ? (
            <div className="col-xs-6 col-md-3">
              <span className="meta-text dim block">Total cost</span>
              <span className="total-price bold opener">
                <span className="WebRupee">Rs.</span> {hotel.finalPrice}
              </span>
            </div>
          ) : null}
        </div>
        <hr className="no-height mute" />
        {/**
         * Todo: ScrollSpy for tab icons
         */}
        <div className="pyt-nav-tab-shell anchor hide">
          <div className="row">
            <div className="col-xs-12 col-sm-9">
              <ul className="nav nav-tabs  tiny-tabs">
                <li role="presentation" className="hotel-modal-tab-list active">
                  <a href="#" id="room-details" className="hotel-modal-tab">
                    Room details
                  </a>
                </li>
                <li role="presentation" className="hotel-modal-tab-list">
                  <a href="#" id="overview" className="hotel-modal-tab">
                    Overview
                  </a>
                </li>
                <li role="presentation" className="hotel-modal-tab-list">
                  <a href="#" id="amenities" className="hotel-modal-tab">
                    Amenities
                  </a>
                </li>
                <li role="presentation" className="hotel-modal-tab-list">
                  <a href="#" id="reviews" className="hotel-modal-tab">
                    Reviews
                  </a>
                </li>
                <li role="presentation" className="hotel-modal-tab-list">
                  <a href="#" id="policy" className="hotel-modal-tab">
                    Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        {/* <h4 className="medium-heading dim">Room details</h4> */}
        <ul
          className="generic-options-list clearfix list-unstyled spacer-bottom"
          id="room-details-area"
        >
          {this.renderRoomsHelper(hotel)}
        </ul>

        <div className="spacer-both feedback">
          <div className="row">
            <h4 className="medium-heading dim col-xs-4" id="reviews-area">
              Reviews
            </h4>
            <div className="col-xs-8 text-right">
              <TripAdvisorRating
                rating={hotel.tripAdvisorRating}
                wrapperClass={'inline-block'}
              />
              {hotel.tripAdvisorReviewCount > 0 ? (
                <span className="dim meta-text">
                  &nbsp;({hotel.tripAdvisorReviewCount})
                </span>
              ) : null}
            </div>
          </div>

          <div className="review-first-sec">
            <div className="row">
              {hotel.customerHappinessScores
                ? hotel.customerHappinessScores.map((score, index) => (
                    <HappinessRating key={index} score={score} />
                  ))
                : null}

              {hotel.customerHappinessScores &&
              hotel.customerHappinessScores.length > 0 ? (
                <div className="col-xs-12 col-md-6 food-sec scored-based">
                  <p>
                    (Scored based on feedback collected from pickyourtrail
                    travellers who stayed at this property recently)
                  </p>
                </div>
              ) : null}
            </div>
          </div>
        </div>

        <div className="row">
          {hotel.reviewsAvailable ? (
            <Slider {...settings} className={'hm-testimonials-slider'}>
              {hotelReviews}
            </Slider>
          ) : (
            <p className="text-center">
              There are not enough reviews for this hotel
            </p>
          )}
        </div>

        {hotel &&
        hotel.amenityDisplayList &&
        hotel.amenityDisplayList.length > 0 ? (
          <div className="new-amenities">
            <div className="row">
              <div className="col-xs-12 col-md-12 new-amenities-inner">
                <hr className="mute" />
                <h4 className="medium-heading dim" id="amenities-area">
                  Hotel Amenities
                </h4>
                <ul className="no-padding">
                  {hotel.amenityDisplayList &&
                  hotel.amenityDisplayList.length > 0
                    ? hotel.amenityDisplayList.map((amenity, index) => {
                        return this.renderAmenity(amenity, index);
                      })
                    : null}
                </ul>
              </div>
            </div>
          </div>
        ) : null}

        <hr className="mute" />

        <hr className="mute hide" />
        <div id="overview-area">
          <h4 className="medium-heading dim">Overview</h4>
        </div>
        <div
          className="spacer-both description"
          dangerouslySetInnerHTML={{ __html: desc_innerHtml }}
        />
        <hr className="mute hide" />
        <div className="spacer-both feedback hide">
          <h4 className="medium-heading dim" id="policy-area">
            Guest policy
          </h4>
          <div className="row">
            <div className="col-xs-12 col-md-6 ">
              <h6>Inclusions</h6>
              <ul className="meta-text">
                <li>Admission to SEA LIFE Melbourne Aquarium</li>
                <li>Animal feedings, presentations and talks</li>
                <li>Guaranteed to skip the line</li>
              </ul>
            </div>
            <div className="col-xs-12 col-md-6">
              <h6>Exclusions</h6>
              <ul className="meta-text">
                <li>Food and drinks</li>
                <li>Optional activities such as shark dives and tours</li>
                <li>Hotel pickup and drop-off</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    ];
  }
}

export default HotelContainer;
