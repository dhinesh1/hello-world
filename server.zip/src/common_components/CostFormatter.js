import React from 'react';
import NumberFormat from 'react-number-format';

/**
 * To format the cost amount
 * @param {cost, prefix} param0
 */
export default function CostFormat({ cost, prefix, enablePrefix }) {
  let prefixValue = prefix || '₹';

  // need to remove "," if its a string value with "," - some places we are getting it that way right now. Will be removed once standardized on API response
  cost =
    typeof cost === 'number'
      ? cost
      : cost && cost.replace(new RegExp(',', 'g'), '');

  return (
    <NumberFormat
      thousandSeparator={true}
      renderText={v => {
        return <React.Fragment>{v}</React.Fragment>;
      }}
      prefix={enablePrefix ? prefixValue : ''}
      displayType="text"
      thousandsGroupStyle="lakh"
      value={isNaN(Math.ceil(cost)) ? 0 : Math.ceil(cost)}
    />
  );
}
