import React from 'react';
import PropTypes from 'prop-types';
import ShenganVisaPanels from '../pages/itinerary/components/costing_screen/panels/shengan_visa_panels';
import NonShenganVisaPanels from '../pages/itinerary/components/costing_screen/panels/non_shengan_visa_panels';

const VisaContainer = ({
  isNonEditable,
  visaDetails,
  allowEditingOptions,
  splitPricing,
  handleCallToActionClick,
  totalVisaCost,
  visaId,
  makeReadOnly=false
}) => {
  const isSchengen = visaDetails ? visaDetails.schengen : null;
  const isOnArrival = visaDetails ? visaDetails.onArrival : null;

  if (isSchengen)
    return (
      <div key={visaId}>
        <ShenganVisaPanels
          allowEditingOptions={allowEditingOptions}
          visaId={visaId}
          isOnArrival={isOnArrival}
          isBooked={isNonEditable}
          splitPricing={splitPricing}
          totalVisaCost={totalVisaCost}
          {...visaDetails}
          handleCallToActionClick={handleCallToActionClick}
        />
        {makeReadOnly? null : <hr className="tear" />}
      </div>
    );
  else if (isOnArrival)
    return (
      <div key={visaId}>
        <NonShenganVisaPanels
          allowEditingOptions={allowEditingOptions}
          isOnArrival={isOnArrival}
          splitPricing={splitPricing}
          visaId={visaId}
          isBooked={isNonEditable}
          {...visaDetails}
        />
        {makeReadOnly? null : <hr className="tear" />}
      </div>
    );
  else
    return (
      <div key={visaId}>
        <NonShenganVisaPanels
          allowEditingOptions={allowEditingOptions}
          visaId={visaId}
          splitPricing={splitPricing}
          isOnArrival={isOnArrival}
          isBooked={isNonEditable}
          totalVisaCost={totalVisaCost}
          {...visaDetails}
          handleCallToActionClick={handleCallToActionClick}
        />
       {makeReadOnly? null : <hr className="tear" />}
      </div>
    );
};

VisaContainer.propTypes = {
  visaDetails: PropTypes.object.isRequired,
  allowEditingOptions: PropTypes.bool.isRequired,
  splitPricing: PropTypes.bool.isRequired,
  handleCallToActionClick: PropTypes.func.isRequired,
  totalVisaCost: PropTypes.string.isRequired,
  visaId: PropTypes.string.isRequired,
  isNonEditable: PropTypes.bool.isRequired
};

export default VisaContainer;
