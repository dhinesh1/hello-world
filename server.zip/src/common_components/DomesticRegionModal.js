import React, { Component } from 'react';
import axios from 'axios';

export default class DomesticRegionsModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      selected_option: null,
      user_name: '',
      user_email: '',
      show: 'FORM'
    };
    this.modalRef = React.createRef();
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
    this.handleSignupSubmit = this.handleSignupSubmit.bind(this);
  }

  closeModal() {
    let _this = this;
    let ele = this.modalRef.current;
    document.querySelector(ele).classList.add('out');

    setTimeout(function() {
      _this.setState({ showModal: false, show: 'FORM' }, () => {
        _this.props.setSearchTermToEmpty();
      });

      document.querySelector('body').classList.remove('modal-open');
    }, 400);
  }

  openModal() {
    let ele = this.modalRef.current;
    this.setState({ showModal: true });

    setTimeout(function() {
      ele.focus();

      document.querySelector('body').classList('modal-open');
    }, 500);
  }

  handleKeyUp(e) {
    if (e.keyCode === 27) this.closeModal();
  }

  componentDidMount() {
    document.addEventListener('keyup', this.handleKeyUp);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  handleSignupSubmit() {
    let _state = this.state;
    let url = `/user/signup/domesticsubscriber`;
    let post_data = {
      email: _state.user_email,
      name: _state.user_name,
      searchText: this.props.searchTerm
    };

    axios
      .post(url, post_data)
      .then(response => {
        if (response.data && response.data.status === 'SUCCESS') {
          this.setState({ show: 'SUCCESS' });
        }
      })
      .catch(error => {
        // console.log(error);
      });
  }

  render() {
    return (
      <div
        tabIndex="0"
        className={
          'modal in domestic-region-modal fade ' +
          (this.state.showModal ? 'in' : '')
        }
        ref={this.modalRef}
      >
        <div className="modal-bg" />
        {/* Modal Header Starts */}
        <div className="modal-detail-header clearfix">
          <div className="header-bar costing">
            <span className="text-uppercase kern-more bolder mute micro hidden" />
          </div>
        </div>
        {/* Modal Header ends */}

        {/* Modal Wrapper Starts */}
        <div className="modal-detail-wrapper with-footer footer-on">
          <div className="modal-detail-content signup">
            <a onClick={this.closeModal} className="modal-close-1">
              <span className="vehoicon-close" />
            </a>
            <div className="modal-row">
              <div className="row">
                {this.state.show === 'FORM' ? (
                  <div className="col-xs-12">
                    <h3>
                      Hey, we are not covering{' '}
                      <span className="highlight">{this.props.searchTerm}</span>{' '}
                      currently.<br />Sign up to stay updated.
                    </h3>
                    <form id="domestic-region-modal-signup-form">
                      <div className="row">
                        <div className="form-grp col-md-6 col-xs-12">
                          <span className="mini mute block input-prompt">
                            Name
                          </span>
                          <input
                            value={this.state.user_name}
                            onChange={event =>
                              this.setState({ user_name: event.target.value })
                            }
                            tabIndex={1}
                            className="branded bold name"
                            name="user_name"
                            type="text"
                            data-msg="Name is required"
                            placeholder="Name"
                            pattern=".*"
                            required
                          />
                        </div>
                        <div className="form-grp col-md-6 col-xs-12">
                          <span className="mini mute block input-prompt">
                            Email ID
                          </span>
                          <input
                            value={this.state.user_email}
                            onChange={event =>
                              this.setState({ user_email: event.target.value })
                            }
                            tabIndex={2}
                            className="branded bold"
                            type="email"
                            name="user_email"
                            placeholder="Email"
                            data-msg="Email ID is required"
                            pattern=".*"
                            required
                          />
                        </div>
                      </div>
                      <button
                        onClick={this.handleSignupSubmit}
                        id="domestic-region-modal-submit"
                        className="btn btn-secondary pull-right"
                      >
                        Get notified
                      </button>
                    </form>
                  </div>
                ) : (
                  <div className="col-xs-12 text-center">
                    <h2>
                      <span className="submit-success">
                        Thank you! You will get notified about the updates on{' '}
                        {this.props.searchTerm}
                      </span>
                    </h2>
                    <br />
                    <br />
                    <button
                      className="btn btn-secondary"
                      onClick={this.closeModal}
                    >
                      Explore other destinations
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
