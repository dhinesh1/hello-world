import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import PaymentForm from './PaymentForm';
import Slider from 'react-slick';
import classNames from 'classnames';
import axios from 'axios';
import _ from 'lodash';
import { is_server, getUserDeviceInfo } from '../helpers/utilsHelper';
import { AppConfig } from '../app-config';
import SweetAlert from 'sweetalert-react';
import {
  trackEvent,
  EVENT_PAYMENT_INITIATED
} from '../helpers/ML/EventsTracker';

const API_URL = AppConfig.api_url;
const SELF_URL = is_server()
  ? ''
  : window.location.protocol + '//' + window.location.hostname;
const USER_TYPE_AGENT = 'AGENT';
const SELF_PORT = is_server()
  ? ''
  : window.location.hostname === 'localhost'
    ? ':' + window.location.port
    : '';

class PaymentOptions extends Component {
  constructor(props) {
    super(props);

    this.state = {
      termsConditionsAccepted: false,
      highlightTerms: false,
      showAlert: false,
      showAgentPaymentModal: false,
      agentPaymentAlertConfig: { title: '', text: '', type: '' },
      alertTitle: '',
      alertMessage: '',
      paymentParams: {},
      paymentSubmitting: false,
      selectedPaymentOption: '',
      activeCard: null
    };

    this.handlePayBtnClick = this.handlePayBtnClick.bind(this);
    this.getEmojiByIndex = this.getEmojiByIndex.bind(this);
    this.setSlickIndex = this.setSlickIndex.bind(this);
  }

  componentDidMount() {
    if (this.state.activeCard === null) {
      this.props.paymentScheduleDetail.paymentOptions.map((payment, index) => {
        if (payment.recommended) {
          this.setState({ activeCard: index });
        }
      });
    }
  }

  handlePayBtnClick(option, index, e) {
    e.preventDefault();

    let { paymentScheduleDetail, userDetails } = this.props;

    if (this.state.activeCard !== index) {
      this.setState({ activeCard: index });
      this.slider.slickGoTo(index);
      return null;
    }
    if (this.props.termsConditionsAccepted) {
      // Url: http://localhost:8080/veho/payment/initiatepayment
      let req_config = {
        itineraryId: paymentScheduleDetail.itineraryId,
        userId: '',
        paymentOptionType: option.paymentOptionType
      };
      let _this = this;
      let paymentParams = _this.state.paymentParams;

      trackEvent(EVENT_PAYMENT_INITIATED, {
        is_agent: userDetails.userType === USER_TYPE_AGENT,
        installment_type: option.percentage,
        amount: option.amountAsFloat
      });
      if (
        userDetails &&
        userDetails.loggedIn &&
        userDetails.userType === USER_TYPE_AGENT
      ) {
        let url = `${API_URL}agent/payment/initiate`;

        this.setState(
          {
            paymentSubmitting: true,
            selectedPaymentOption: option.paymentOptionType
          },
          () => {
            axios
              .post(url, req_config)
              .then(response => {
                // console.log(response);

                if (response.data.status === 'SUCCESS') {
                  // let successText = <span>Your payment of <b><span className={"WebRupee"}>Rs.</span> {response.data.amount}</b> for itinerary <b># {response.data.uniqueIdentifier}</b> is successful. The payment reference number is <b>{response.data.referenceNumber}</b></span>;
                  let amount = response.data.amount;
                  let uniqueIdentifier = response.data.uniqueIdentifier;
                  let referenceNumber = response.data.referenceNumber;
                  let successText =
                    'Your payment of Rs. ' +
                    amount +
                    ' for itinerary #' +
                    uniqueIdentifier +
                    ' is successful. The payment reference number is ' +
                    referenceNumber;
                  _this.setState({
                    paymentSubmitting: false,
                    showAgentPaymentModal: true,
                    agentPaymentAlertConfig: {
                      title: 'Success',
                      text: successText,
                      type: 'success'
                    }
                  });
                } else {
                  _this.setState({
                    paymentSubmitting: false,
                    showAgentPaymentModal: true,
                    agentPaymentAlertConfig: {
                      title: 'Oops!',
                      text:
                        'Looks like your transaction has failed. Please check your balance and try again later',
                      type: 'warning'
                    }
                  });
                }
              })
              .catch(() => {
                _this.setState({
                  paymentSubmitting: false,
                  showAgentPaymentModal: true,
                  agentPaymentAlertConfig: {
                    title: 'Oops!',
                    text:
                      'Looks like your transaction has failed. Please check your balance and try again later',
                    type: 'warning'
                  }
                });
              });
          }
        );
      } else {
        let url = `${API_URL}payment/initiatepayment`;

        axios
          .post(url, req_config, {
            headers: { "Version": "V_2", "user_device": getUserDeviceInfo() }
          })
          .then(response => {
            // console.log('initiatepayment response', response);
            _.assign(paymentParams, response.data.data);
            _this.setState(
              { paymentParams: paymentParams, showAlert: false },
              () => {
                // console.log('Success URL after initiate-payment');
                // console.log(this.state.paymentParams.successUrl);
                const paymentForm = document.forms.paymentForm;
                paymentForm && paymentForm.submit();
              }
            );

          })
          .catch(error => {
            if (error.response && error.response.status === 401) {
              this.setState({
                showAlert: true,
                alertTitle: 'Hey, Sorry!',
                alertMessage:
                  'Looks like you are not authorized to do this action'
              });
            } else if (error.response && error.response.status === 403) {
              this.setState({
                showAlert: true,
                alertTitle: 'Hey, Sorry!',
                alertMessage:
                  "Looks like you haven't shared this itinerary. Not authorized to proceed"
              });
            } else {
              this.setState({
                showAlert: true,
                alertTitle: 'Oops! Sorry',
                alertMessage: 'There seems to be an issue, please try again.'
              });
            }
          });
      }
    } else {
      this.props.addErrorClassToTnC();
      this.setState({ highlightTerms: true });
    }
  }

  setSlickIndex(index) {
    this.setState({ activeCard: index });
  }

  getEmojiByIndex(index) {
    switch (index) {
      case 0:
        return <span>&#128077;</span>;
      case 1:
        return <span>&#128588;</span>;
      case 2:
        return <span>&#128175;</span>;
      default:
    }
  }

  renderPaymentOptions() {
    let { paymentScheduleDetail } = this.props;
    let { paymentSubmitting, selectedPaymentOption } = this.state;

    if (!_.isEmpty(paymentScheduleDetail)) {
      var initialSlide = 0;
      let paymentOptionsDivs = paymentScheduleDetail.paymentOptions.map(
        (paymentOption, inx) => {
          var paymentText = `Pay just ${
            paymentOption.percentage
          }% and confirm your bookings!`;

          if (paymentOption.percentage === '70') {
            paymentText =
              'Complete your 70% payment just like the majority of our customers';
          } else if (paymentOption.percentage === '100') {
            paymentText =
              'Finish your 100% payment at one shot and get packing right-away!';
          }

          let payCardClass = classNames('pay-card n-tracker-paycard', {
            'mid-card': this.state.activeCard === inx,
            disabled: !paymentOption.paymentAllowed
          });

          if (paymentOption.recommended && initialSlide === 0) {
            initialSlide = inx;
          }

          return (
            <div key={paymentOption.paymentOptionType}>
              <div
                className={payCardClass}
                onClick={e =>
                  paymentSubmitting || !paymentOption.paymentAllowed
                    ? null
                    : this.handlePayBtnClick(paymentOption, inx, e)
                }
              >
                <a href="#">
                  <i className="icon">{this.getEmojiByIndex(inx)}</i>
                  {paymentOption.recommended ? (
                    <span className="pill color-white bg-accent-2 bold ourpick-pill">
                      OUR PICK
                    </span>
                  ) : null}
                  <p>{paymentText}</p>
                  <strong>&#8377; {paymentOption.amount}</strong>
                  {paymentOption.paymentAllowed ? (
                    <button
                      type="button"
                      className={classNames(
                        `btn n-tracker-paynow n-tracker-paynow-${
                          paymentOption.percentage
                        }`,
                        {
                          'progress-btn':
                            paymentSubmitting &&
                            selectedPaymentOption ===
                              paymentOption.paymentOptionType
                        }
                      )}
                      disabled={
                        paymentSubmitting &&
                        selectedPaymentOption !==
                          paymentOption.paymentOptionType
                      }
                    >
                      {paymentSubmitting &&
                      selectedPaymentOption ===
                        paymentOption.paymentOptionType ? (
                        <span className={'progress-bg'} />
                      ) : null}
                      <span className={'btn-txt'}>Pay now</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      className={`btn disabled n-tracker-paynow n-tracker-paynow-${
                        paymentOption.percentage
                      }`}
                    >
                      Pay now
                    </button>
                  )}
                </a>
              </div>
            </div>
          );
        }
      );

      let settings = {
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: false,
        initialSlide: initialSlide,
        responsive: [
          {
            breakpoint: 767,
            settings: {
              infinite: false,
              centerMode: true,
              centerPadding: '12%',
              dots: true,
              slidesToShow: 1
            }
          }
        ],
        afterChange: this.setSlickIndex
      };

      if (paymentOptionsDivs && paymentOptionsDivs.length !== 3) {
        settings.slidesToShow = paymentOptionsDivs.length;
      }

      return (
        <div>
          {paymentScheduleDetail.totalPaid != '0.0' &&
          paymentScheduleDetail.totalPaid != '0' ? (
            <div>
              <div className="v-spaced row flex vertical-center">
                <div className="col-xs-7">
                  <p className="h4 clear-margin">Total Paid</p>
                  <p className="txt-size-xs oj-text-light-grey border-bottom sub-tab border-light-grey border-dotted inline-block">
                    View transactions
                  </p>
                </div>
                <div className="col-xs-5 text-right">
                  <p className="txt-size-lg oj-text-black text-no-wrap font-rounded-variant">
                    ₹{' '}
                    {paymentScheduleDetail.totalPaid
                      ? paymentScheduleDetail.totalPaid
                      : 0}
                  </p>
                </div>
              </div>
              <div className="v-spaced row flex vertical-center">
                <div className="col-xs-7">
                  <p className="h4 bold clear-margin">Payment pending</p>
                  <p className="txt-size-xs oj-text-light-grey">
                    Your trip is confirmed only after making the payment in
                    full.
                  </p>
                </div>
                <div className="col-xs-5 text-right">
                  <p className="txt-size-lg  oj-text-black text-no-wrap font-rounded-variant">
                    ₹{' '}
                    {paymentScheduleDetail.totalPending
                      ? paymentScheduleDetail.totalPending
                      : 0}
                  </p>
                </div>
              </div>
            </div>
          ) : null}

          <Slider
            ref={slider => (this.slider = slider)}
            {...settings}
            className="clearfix paycard-slider"
          >
            {paymentOptionsDivs}
          </Slider>
        </div>
      );
    }
  }

  render() {
    let {
      paymentParams,
      showAlert,
      alertMessage,
      alertTitle,
      agentPaymentAlertConfig,
      showAgentPaymentModal
    } = this.state;
    let { history } = this.props;

    return (
      <div>
        {this.renderPaymentOptions()}

        <SweetAlert
          show={showAlert}
          title={alertTitle}
          text={alertMessage}
          animation="pop"
          onConfirm={() => this.setState({ showAlert: false })}
        />

        <SweetAlert
          type={agentPaymentAlertConfig.type}
          show={showAgentPaymentModal}
          title={agentPaymentAlertConfig.title}
          text={agentPaymentAlertConfig.text}
          animation="pop"
          onConfirm={() => {
            this.setState({ showAgentPaymentModal: false }, () => {
              if (agentPaymentAlertConfig.type.toLowerCase() === 'success') {
                history.push('/agent/dashboard');
              }
            });
          }}
        />

        <PaymentForm paymentParams={paymentParams} />
      </div>
    );
  }
}

export default withRouter(PaymentOptions);
