import React from 'react';
import { Link } from 'react-router-dom';
import { getImgIXUrl } from '../../helpers/utilsHelper';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';
import CostFormat from '../CostFormatter';
import { trackEvent, EVENT_PACKAGE_SELECTED } from '../../helpers/ML/EventsTracker';

const packagesCardClick = (data={}, type='') => {
  trackEvent(EVENT_PACKAGE_SELECTED, {
    title: `${data.nights} nights vacation to ${data.destinationString}`,
    region: data.regionName,
    destination: data.destinationString,
    cost: data.itineraryCost,
    card_type: type.replace('n-tracker-', '')
  })
}

export default function HomePagePackagesItineraryCard({ p, tracker }) {
  return (
    <div className="col-xs-3">
      <div className={'holiday-card ' + tracker}>
        <Link to={`${p.slug}`} target="_blank" onClick={() => packagesCardClick(p, tracker)}>
          <LazyLoadComponent>
            <figure
              style={{
                backgroundImage: `url(${getImgIXUrl(p.image, 'w=600')})`
              }}
            >
              <figcaption className="fig-title">
                <span className="tag-tertiary white truncate medium">
                  {p.regionName}
                </span>
                {/* <h6>{p.title}</h6> */}
                {/* <button className="btn btn-primary btn-sm">Customise</button> */}
              </figcaption>
              {/*<span className="holiday-ribbon bg-accent-1">Hurry!</span>*/}
            </figure>
          </LazyLoadComponent>
          <div className="clearfix">
            <p>
              {p.nights} nights vacation to {p.destinationString}
            </p>
            <b>
              <CostFormat cost={p.itineraryCost} enablePrefix={true} />
              <i>/person</i>
            </b>
            <span>Starting price, customisable</span>
          </div>
        </Link>
      </div>
    </div>
  );
}
