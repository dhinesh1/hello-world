import React from 'react';
import _ from 'lodash';
import { AppConfig } from '../../app-config';
import { getImgIXUrl } from '../../helpers/utilsHelper';
import LazyLoadComponent from '../../common_components/LazyLoadComponent';

export default function HomePageTestimonialCard({
  testimonial,
  trackertestimonialcard
}) {
  return (
    <div className="col-xs-3">
      <div className={'testimonial-card ' + trackertestimonialcard}>
        <a href={testimonial.fbLink} target="_blank">
          <LazyLoadComponent>
            {testimonial.coverImage ? (
              <figure
                style={{
                  backgroundImage: `url(${getImgIXUrl(
                    testimonial.coverImage,
                    'w=358'
                  )})`
                }}
              />
            ) : (
              <figure
                style={{
                  backgroundImage: `url(${getImgIXUrl(
                    'https://d3lf10b5gahyby.cloudfront.net/misc/vilina_profile.jpg'
                  )})`
                }}
              />
            )}
          </LazyLoadComponent>
          <p>
            <span className="testimonial-username meta-text color-base">
              {testimonial.fName} {testimonial.lName}
            </span>
            {testimonial.type} to {testimonial.destination}
          </p>
          <h6>{_.truncate(testimonial.shortReview, { length: 70 })}</h6>
          <ul className="clearfix list-unstyled mb-0">
            <li>
              <i className="vehoicon-star" />
            </li>
            <li>
              <i className="vehoicon-star" />
            </li>
            <li>
              <i className="vehoicon-star" />
            </li>
            <li>
              <i className="vehoicon-star" />
            </li>
            <li>
              <i className="vehoicon-star" />
            </li>
          </ul>
        </a>
      </div>
    </div>
  );
}
