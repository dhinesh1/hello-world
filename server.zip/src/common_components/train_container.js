import React from 'react';
import classNames from 'classnames';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';
import PropTypes from 'prop-types';
import { AppConfig } from '../app-config';
import { encodeCostingKeyForURL } from '../helpers/utilsHelper';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  RATE_MATCH_TRAIN
} from '../helpers/routesHelper';

const IMAGE_CDN = AppConfig.imgix_base;
const booking_state_alert = AppConfig.booking_state_alert;

const renderRefundability = refundability => {
  if (refundability)
    return (
      <li>
        <span className="color-success vehoicon-refundable" /> Refundable
      </li>
    );
  else
    return (
      <li>
        <span className="color-danger vehoicon-non-refundable" /> Non Refundable
      </li>
    );
};

const TrainContainer = ({
  train,
  userDetails,
  history,
  onViewDetailsClick,
  onChangeClick,
  isBooked,
  disableEditing,
  insideModal,
  regionCode,
  itineraryId,
  makeReadOnly,
  handleCallToActionClick
}) => {
  // Surrounded with if to check the costing status else showing error screen
  const isAdmin = userDetails &&
    userDetails.loggedIn &&
    userDetails.userType === 'ADMIN';
  const isNonEditable = isBooked && userDetails && userDetails.userType !== 'ADMIN';
  if (train.status === 'SUCCESS') {
    let comoboPricingClasses = '';
    let comboPricingMessageBox = null;

    const onClickDetails = disableEditing
      ? () => null
      : e => onViewDetailsClick(train, e);

    if (train.inCombo) {
      comoboPricingClasses = ' strikethrough dim vmargin-small';
      comboPricingMessageBox = (
        <div className="pointing-box top">
          <span className="meta-text t-5 inline-block">
            Included in combo package!
          </span>
        </div>
      );
    } else if (train.inSwissPass) {
      comoboPricingClasses = ' strikethrough dim vmargin-small';
      comboPricingMessageBox = (
        <div className="pointing-box top">
          <span className="meta-text t-5 inline-block">
            Included in Swiss Pass!
          </span>
        </div>
      );
    }
    let trainPriceBlock = (
      <span className={'price ' + comoboPricingClasses}>
        <span className="WebRupee">Rs.</span>
        {train.totalCost}
        {userDetails &&
        userDetails.loggedIn &&
        !disableEditing &&
        userDetails.userType === 'ADMIN' &&
        !makeReadOnly ? (
          <a
            onClick={e => {
              e.stopPropagation();
              e.nativeEvent.stopImmediatePropagation();

              history.push(
                itineraryModalsRouteHelper({
                  itineraryId,
                  regionCode,
                  parentPage: routingPageType.inclusion,
                  target: RATE_MATCH_TRAIN,
                  customParams: {
                    trainKey: encodeCostingKeyForURL(train.key),
                    called_from: 'TRAIN_PANEL'
                  }
                })
              );
            }}
          >
            {' '}
            <span className={`vehoicon-mode_edit color-secondary dim`} />
          </a>
        ) : null}
      </span>
    );

    const discountAppliedBatch = userDetails && userDetails.userType === 'ADMIN' && train.rateMatches && train.rateMatches.length > 0 ?
            <span className={'pill color-white bg-accent-4'}> Discount Applied </span> : null;

    return (
      <div
        className={classNames({
          'modal-row': insideModal,
          'pt-0': insideModal,
          'cost-container': insideModal
        })}
        onClick={onClickDetails}
      >
        <article
          className={`row-costed-item row ${disableEditing ? '' : 'zoomable'}`}
        >
          <div className="col-xs-9 col-sm-9 col-md-8 spacer">
            <div className="costed-item-head">
              <div className="date-costed">
                <span className="month">{train.mon}</span>
                <span className="date">{train.day}</span>
              </div>
              <h5 className="no-margin semi-bold">Train - {train.text}</h5>
              <span className="small dim">Shared Transfer</span>
              <br />
              {train.stops > 0 ? (
                <span className="small dim">
                  {' '}
                  {train.stops} {train.stops > 1 ? 'stops' : 'stop'} ({
                    train.stopNames
                  })
                </span>
              ) : null}
            </div>
            <div className="costed-item-details clearfix">
              <div className="col-xs-5 col-sm-2 col-md-3 no-padding">
                <div className="media-shell">
                  <figure className="hd">
                    <img src={`${IMAGE_CDN}/images/misc/transfers-train.jpg`} />
                  </figure>
                </div>
              </div>
              <div className="col-xs-7 col-sm-9 col-md-9">
                <span className="fine-text fade color-grey">Includes:</span>
                <div className="circle-list">
                  <ul className="fine-text fade color-grey">
                    <li>
                      Departure {train.departureTime} {train.pickup}
                    </li>
                    <li>
                      Arrival {train.arrivalTime} {train.drop}
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
            <li>
              <span className="vehoicon-ion-android-time" /> {train.duration}{' '}
              duration
            </li>
            {train.stops > 0 ? (
              <li>
                <span className="vehoicon-train" /> {train.stops}{' '}
                {train.stops > 1 ? 'stops' : 'stop'} ({train.stopNames})
              </li>
            ) : null}
            {renderRefundability(train.refundable)}
          </ul>
          <div className="col-xs-3 col-sm-3 col-md-2 spacer">
            <div
              className={
                'action ' +
                (train.totalCost ? ' price-info-center' : ' price-info')
              }
            >
              {train.totalCost ? trainPriceBlock : null}
              {comboPricingMessageBox}
              {discountAppliedBatch}
              {disableEditing || makeReadOnly ? null : isBooked ? (
                <OverlayTrigger
                  id="ot5"
                  placement="top"
                  overlay={
                    <Tooltip id="traintooltip">{booking_state_alert}</Tooltip>
                  }
                >
                  <a
                    onClick={e => (isBooked ? null : onChangeClick(train, e))}
                    className={`btn btn-sm btn-primary disabled`}
                  >
                    Change
                  </a>
                </OverlayTrigger>
              ) : (
                <a
                  onClick={e => (isBooked ? null : onChangeClick(train, e))}
                  className={
                    `btn btn-sm btn-primary ${isBooked ? 'disabled' : ''}}`
                  }
                >
                  Change
                </a>
              )}
              
              {
                isAdmin &&
                !makeReadOnly &&
                !isNonEditable
                ? (
                  <a
                    href=' '
                    onClick={e => { 
                      e && e.stopPropagation();
                      handleCallToActionClick(
                        {
                          itineraryId: itineraryId,
                          key: encodeURI(train.key),
                          transfer: 'train',
                          isRemove: true
                        },
                        e
                      )
                    }}
                    className={
                      'btn btn-sm btn-danger btn-outline fade' +
                      (isNonEditable ? 'disabled' : '')
                    }
                  >
                    Remove
                </a>
                ) : null}

              {/* </div> */}
              {disableEditing ? null : (
                <span className="block">
                  <a
                    href="#"
                    onClick={onClickDetails}
                    className="btn btn-sm btn-link dim normal tracker-transfer-change-train"
                  >
                    More info
                  </a>
                </span>
              )}
            </div>
          </div>
        </article>
        <hr className="tear" />
      </div>
    );
  } else if (train.status === 'ERROR') {
    return (
      <div key={Math.random()}>
        <article className="row-costed-item row danger">
          <div className="col-xs-9 col-sm-9 col-md-8 spacer">
            <div className="costed-item-head">
              <div className="date-costed">
                <span className="month">{train.mon}</span>
                <span className="date">{train.day}</span>
              </div>
              <h5 className="no-margin semi-bold">{train.text}</h5>
              <span className="meta-text color-danger">
                Sorry, Train costing has failed currently. Please try after
                sometime!
              </span>
            </div>
          </div>
          <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
        </article>
        <hr className="tear" />
      </div>
    );
  } else if (isAdmin && train.status === 'USER_REMOVED') {
    return (<div key={Math.random()}>
        <article className="row-costed-item row warning">
          <div className="col-xs-9 col-sm-9 col-md-8 spacer">
            <div className="costed-item-head">
              <div className="date-costed">
                <span className="month">{train.mon}</span>
                <span className="date">{train.day}</span>
              </div>
              <h5 className="no-margin semi-bold">{train.text}</h5>
              <span className="meta-text color-warning">
                You have removed this train from itinerary!
              </span>
            </div>
          </div>
          <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
          <div className="col-xs-3 col-sm-3 col-md-2 spacer">
            <div className="action price-info text-center">
              <div
                data-toggle={isNonEditable ? 'tooltip' : ''}
                data-title="The itinerary has already been booked. Cant make any further changes."
                data-placement="bottom"
                data-container="body"
              >
                <a
                  href=' '
                  onClick={e => { 
                    e && e.preventDefault();
                    onChangeClick(train, e);
                  }}
                  className={
                    'btn btn-sm btn-primary  ' +
                    (isNonEditable ? 'disabled' : '')
                  }
                >
                  Add
                </a>
              </div>
            </div>
          </div>
        </article>
        <hr className="tear" />
      </div>)
  }
  return null;
};

TrainContainer.propTypes = {
  train: PropTypes.object.isRequired,
  userDetails: PropTypes.object.isRequired,
  history: PropTypes.object.isRequired,
  onViewDetailsClick: PropTypes.func,
  onChangeClick: PropTypes.func,
  isBooked: PropTypes.bool.isRequired,
  disableEditing: PropTypes.bool
};

export default TrainContainer;
