import React, { Component } from 'react';
import { connect } from 'react-redux';
import LazyLoad from 'react-lazyload';
import PropTypes from 'prop-types';

class LazyLoadComponent extends Component {
  /**
   * Setting proper prop-type validator
   * isTestCase - boolean which will be used in test-cases to avoid lazyloading in Unit testing
   * offset - this is offset height where the loading will be triggered
   * children - React element, array of elements
   */
  static propTypes = {
    isTestCase: PropTypes.bool,
    offset: PropTypes.number,
    children: PropTypes.oneOfType([PropTypes.element, PropTypes.array]).isRequired
  };

  render() {
    let { isTestCase, children, offset = 100 } = this.props;
    if (isTestCase) {
      return [children];
    } else {
      return (
        <LazyLoad once={true} offset={offset} height={100}>
          {children}
        </LazyLoad>
      );
    }
  }
}

function mapStateToProps(state) {
  return { device: state.app.device };
}

export default connect(mapStateToProps)(LazyLoadComponent);
