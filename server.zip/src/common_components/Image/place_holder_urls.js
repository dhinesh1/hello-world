import { AppConfig } from '../../app-config';

const prefix = AppConfig.images_cdn_misc_url + 'placeholders/';

const placeHolderUrls = {
  activitySmall: prefix + 'Activity1-50x50.png',
  activityMedium: prefix + 'Activity1-125x125.png',
  activityLarge: prefix + 'Activity1-640x360.png',
  activity2Small: prefix + 'Activity2-50x50.png',
  activity2Medium: prefix + 'Activity2-125x125.png',
  activity2Large: prefix + 'Activity2-640x360.png',
  activity3Small: prefix + 'Activity3-50x50.png',
  activity3Medium: prefix + 'Activity3-125x125.png',
  activity3Large: prefix + 'Activity3-640x360.png',
  airLineLogo: prefix + 'Airline-logo.png',
  citySmall: prefix + 'Guides-City-395x360.png',
  cityLarge: prefix + 'Guides-City-790x720.png',
  foodSmall: prefix + 'Guides-Food-120x120.png',
  foodLarge: prefix + 'Guides-Food-240x240.png',
  innerAreasSmall: prefix + 'Guides-InnerAreas-230x140.png',
  innerAreasLarge: prefix + 'Guides-InnerAreas-460x280.png',
  shoppingSmall: prefix + 'Guides-Shopping-150x105.png',
  shoppingLarge: prefix + 'Guides-Shopping-300x210.png',
  hotelSmall: prefix + 'Hotel-50x50.png',
  hotelMedium: prefix + 'Hotel-125x125.png',
  hotelBig: prefix + 'Hotel-200x150.png',
  hotelLarge: prefix + 'Hotel-640x360.png',
  roomsSmall: prefix + 'HotelRooms-120x90.png',
  roomsLarge: prefix + 'HotelRooms-240x180.png'
};

export default placeHolderUrls;
