import React, { PureComponent, Fragment } from 'react';
import PropTypes from 'prop-types';
import LazyLoad from 'react-lazyload';
import { AppConfig } from '../../app-config';
import { getImgIXUrl } from '../../helpers/utilsHelper';
import logClientError from '../../helpers/logClientError';

/**
 * @class SmartImage
 * @extends {PureComponent}
 * This component accepts string/bool props and to avoid rerender for same inputs we are making this as a PureComponent
 * @param {string} src (Url of actual image to be rendered)
 * @param {string} defaultImage (Url of fallback image if actual image url failed to load)
 * @param {string} alt (alt attribute value for image tag)
 * @param {boolean} disableLazyLoad (default=false)
 * @param {element/array} children (single/array of elements)
 */

class SmartImage extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      defaultImage: getImgIXUrl(this.props.defaultImage),
      actualImage: getImgIXUrl(this.props.src) || AppConfig.invalid_image_url,
      isUsingDefaultImage: false
    };
  }

  /**
   * logs error if the actual image url is broken and use the default image
   * log the error with the broken image url for both actual & default images
   *
   * @memberof SmartImage
   */
  loadError = (err) => {
    if (!this.state.isUsingDefaultImage) {
      logClientError({}, {
        title: "Broken Image URL!",
        url: this.state.actualImage
      });
      this.setState({
        actualImage: this.state.defaultImage,
        isUsingDefaultImage: true
      });
    } else {
      logClientError({}, {
        title: "Broken Default Image URL!",
        url: this.state.defaultImage
      });
    }
  }

  /**
   * state need to be re-calculated based on the props passed
   * Here if the prop `src` url changes the state will be recreated
   * returns null if there is no change. (this will not update the state)
   * `oldSrc` value stored in state for conditional check
   *
   * @static
   * @param {*} nextProps (set of new props)
   * @param {*} state (current state object)
   * @returns - new state object if the condition is satisfied, null in other cases
   * @memberof SmartImage
   */
  static getDerivedStateFromProps(nextProps, state) {
    if (state.oldSrc !== nextProps.src) {
      return {
        oldSrc: nextProps.src,
        defaultImage: getImgIXUrl(nextProps.defaultImage || nextProps.src),
        actualImage: getImgIXUrl(nextProps.src) || AppConfig.invalid_image_url,
        isUsingDefaultImage: false
      }
    }
    return null;
  }

  renderImage = ({alt, ...otherProps}) => {
    return <img
      {...otherProps}
      alt={alt || ''}
      src={this.state.actualImage}
      onError={this.loadError}
    />
  }

  render() {
    const {
      defaultImage,
      children,
      disableLazyLoad,
      height=100,
      ...otherProps
    } = this.props;

    if (defaultImage && otherProps.alt) {
      if (!disableLazyLoad) {
        return <Fragment>
          <LazyLoad offset={100} height={height}>
            { this.renderImage(otherProps) }
          </LazyLoad>
          {children ? children : null}
        </Fragment>
      } else {
        return <Fragment>
          { this.renderImage(otherProps) }
          {children ? children : null}
        </Fragment>
      }
    } else {
      console.error('Missing default image source');
      return (
        <p>Smart Image requires a Default image Source and alternate Text!</p>
      );
    }
  }
}

SmartImage.propTypes = {
  src: PropTypes.string.isRequired,
  defaultImage: PropTypes.string.isRequired,
  alt: PropTypes.string.isRequired,
  children: PropTypes.oneOfType([PropTypes.element, PropTypes.array]),
  disableLazyLoad: PropTypes.bool,
  height: PropTypes.number
};

export default SmartImage;
