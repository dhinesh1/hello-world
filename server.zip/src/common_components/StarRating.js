import React, { Component } from 'react';
import _ from 'lodash';

export default class StarRating extends Component {
  render() {
    let {
      rating,
      fillEmpty,
      parentClass,
      insideFigure,
      parentElement,
      addStarClr
    } = this.props;
    let half_star = (
      <span className={`vehoicon-star_half ${addStarClr ? `star-clr` : ``}`} />
    );
    let RootElement = parentElement ? parentElement : 'div';

    let full_ratings = parseInt(rating, 10);
    let half_star_value = rating % full_ratings;

    let full_stars = _.range(0, full_ratings).map((star, key) => {
      return (
        <span
          key={'filled_star_' + key}
          className={`vehoicon-star ${addStarClr ? `star-clr` : ``}`}
        />
      );
    });

    let empty_stars = null;
    if (fillEmpty) {
      let remaining_stars_count = 5 - Math.ceil(rating);

      if (remaining_stars_count >= 1) {
        empty_stars = _.range(0, remaining_stars_count).map((star, key) => {
          return (
            <span
              key={'empty_star_' + key}
              className={`vehoicon-star_border ${addStarClr ? `star-clr` : ``}`}
            />
          );
        });
      }
    }

    if (insideFigure) {
      return (
        <figcaption className="stars inverse text-left">
          {full_stars}
          {half_star_value > 0 ? half_star : null}
          {empty_stars}
        </figcaption>
      );
    } else {
      return (
        <RootElement className={parentClass ? parentClass : ''}>
          {full_stars}
          {half_star_value > 0 ? half_star : null}
          {empty_stars}
        </RootElement>
      );
    }
  }
}
