import React, { Component } from 'react';
import classNames from 'classnames';
import Button from './Button';
import PropTypes from 'prop-types';

/**
 * To render basic mobile number component
 */
export default class MobileNumber extends Component {
  constructor(props) {
    super(props);
    let mobileNumber = (props || {}).mobileNumber || '';
    let extensionNumber = (props || {}).extNumber || '+91';
    this.state = {
      mobileNumber: mobileNumber,
      extensionNumber: extensionNumber,
      showCode: mobileNumber && extensionNumber
    };

    /**<-------------Events------------------> */
    this.onMobileNumberChange = this.onMobileNumberChange.bind(this);
    this.onExtenstionChange = this.onExtenstionChange.bind(this);
    this.onMobileFocus = this.onMobileFocus.bind(this);
    this.onMobileBlur = this.onMobileBlur.bind(this);
  }

  /**
   * Called when click the outside of the elment
   * @param {*} e
   */
  onMobileBlur(e) {
    const { extensionNumber } = this.state;
    const isNonZero = parseInt(extensionNumber.replace('+', '0')) * 1;
    this.setState({
      showCode: e.target.value !== '',
      extensionNumber:
        /^\+{1}\d{1,4}$/.test(extensionNumber) && isNonZero
          ? extensionNumber
          : '+91'
    });
  }

  /**
   * Called to set the mobile numbner
   */
  componentWillReceiveProps(props) {
    if (props.mobileNumber || props.extNumber) {
      let extensionNumber = props.extNumber || this.state.extensionNumber;
      let strippedPhoneNumber =
        props.mobileNumber.indexOf(extensionNumber) >= 0
          ? props.mobileNumber
              .replace(/\D/g, '')
              .substr(extensionNumber.replace('+', '').length)
          : props.mobileNumber;
      this.setState({
        mobileNumber: strippedPhoneNumber,
        extensionNumber: extensionNumber,
        showCode: strippedPhoneNumber && extensionNumber
      });
    }
  }

  /**
   * Called when focus the input element
   */
  onMobileFocus() {
    this.setState({ showCode: true });
  }

  /**
   * This function will trigger when change the mobile number
   * @param {*} e
   */
  onMobileNumberChange(e) {
    if (isNaN(e.target.value)) return false;
    /**
     * Avoid the 0 as a start number when user trying to register
     * @author akbar
     */
    if (this.props.isSignUp) {
      e.target.value = e.target.value.replace(/^0+/, '');
    }
    this.setState({ mobileNumber: e.target.value || '' }, () => {
      this.props.changeCall &&
        this.props.changeCall(
          this.state.extensionNumber + this.state.mobileNumber,
          this.state.extensionNumber,
          this.state.mobileNumber
        );
    });
  }

  /**
   * This function will trigger when change the extension number
   * @param {*} e
   */
  onExtenstionChange(e) {
    let extNum = e.target.value;
    extNum = extNum.replace('+', '');

    if (isNaN(extNum)) return false;
    this.setState({ extensionNumber: '+' + extNum }, () => {
      this.props.changeCall &&
        this.props.changeCall(
          this.state.extensionNumber + this.state.mobileNumber,
          this.state.extensionNumber,
          this.state.mobileNumber
        );
    });
  }

  /**
   * Render method called here
   */
  render() {
    let { mobileNumber, extensionNumber, showCode } = this.state;
    let { isError, disabled, errorResponse, isChange, changeCall } = this.props;
    return (
      <div
        className={classNames('form-group form-group-lg flat mobile-field', {
          'show-code': showCode,
          'has-error': isError
        })}
      >
        <input
          type="text"
          className={classNames('form-control country-code', {
            'cursor-not-allowed': disabled
          })}
          placeholder="+91"
          maxLength={5}
          disabled={disabled}
          onBlur={this.onMobileBlur}
          autoComplete="off"
          onChange={this.onExtenstionChange}
          onFocus={this.onMobileFocus}
          value={extensionNumber}
        />
        <div
          className={classNames('label-animative', {
            'input-link': isChange
          })}
        >
          <input
            type="text"
            className={classNames('form-control', {
              'cursor-not-allowed': disabled
            })}
            placeholder="Mobile Number"
            disabled={disabled}
            value={mobileNumber}
            onChange={this.onMobileNumberChange}
            onBlur={this.onMobileBlur}
            autoComplete="off"
            onFocus={this.onMobileFocus}
          />
          <label className="control-label">Mobile Number</label>
          {isChange ? (
            <Button buttonClass="btn btn-link" clickAction={changeCall}>
              <span className="color-primary-dark">{'Change?'}</span>
            </Button>
          ) : null}
        </div>
        {isError ? <span className="help-block">{errorResponse}</span> : null}
      </div>
    );
  }
}

/**
 * Default proptype
 */
MobileNumber.propTypes = {
  isError: PropTypes.bool,
  disabled: PropTypes.bool,
  errorResponse: PropTypes.string,
  isSignUp: PropTypes.bool
};
