import React, { Component } from 'react';
import classNames from 'classnames';
import Button from './Button';
import PropTypes from 'prop-types';

/**
 * To render basic password component
 * Button Component will refer
 */
export default class Password extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: '',
      disabledResend: true,
      counterText: 20
    };

    /**<-------------Events------------------> */
    this.onInputChange = this.onInputChange.bind(this);

    /**<-------------Internal Functions------------------> */
    this.onResendAction = this.onResendAction.bind(this);
  }

  /**
   * This lifecycle used to iterate the trigger count
   */
  componentDidMount() {
    this.triggerCounter();
  }

  /**
   * Trigger count function called here.
   * The default interval value is 1000 and 20 sec loaded time
   */
  triggerCounter() {
    let _this = this;
    let interval;
    if (_this.state.disabledResend) {
      interval = setInterval(function() {
        if (_this.state.counterText !== 1) {
          _this.setState({ counterText: _this.state.counterText - 1 });
        } else {
          clearInterval(interval);
          _this.setState({ disabledResend: false });
        }
      }, 1000);
    } else {
      clearInterval(interval);
    }
  }

  /**
   * Trigger when change the input field
   * @param {*} e
   */
  onInputChange(e) {
    this.setState({
      value: e.target.value
    });
    this.props.changeCall && this.props.changeCall(e.target.value);
  }

  /**
   * Trigger when click the resend password button
   * @param {*} e
   */
  onResendAction(e) {
    if (!this.state.disabledResend) {
      this.setState(
        {
          disabledResend: true,
          counterText: 20
        },
        () => {
          this.props.forgotAction(e);
          this.triggerCounter();
        }
      );
    }
  }

  /**
   * Render method called here
   * Password element will perform
   */
  render() {
    let {
      enableForgot,
      forgotAction,
      isError,
      errorResponse,
      placeHolder,
      labelText,
      isOTP,
      maxLength
    } = this.props;
    return (
      <div
        className={classNames('form-group form-group-lg flat', {
          'has-error': isError
        })}
      >
        {isOTP ? (
          <p className="bold mb-0 meta-text">OTP Sent to your mobile</p>
        ) : null}
        <div className="label-animative input-link">
          <input
            type="password"
            maxLength={maxLength}
            className="form-control"
            placeholder={placeHolder}
            onChange={this.onInputChange}
            autoComplete="new-password"
          />
          <label className="control-label">{labelText}</label>
          {enableForgot ? (
            <Button
              buttonClass="btn btn-link"
              buttonText="Forgot?"
              clickAction={forgotAction}
            />
          ) : null}
          {isOTP ? (
            <Button
              buttonClass={classNames('btn btn-link', {
                'cursor-not-allowed': this.state.disabledResend
              })}
              clickAction={this.onResendAction}
            >
              <span
                className={classNames('', {
                  'color-grey-medium': this.state.disabledResend,
                  'color-primary-dark': !this.state.disabledResend
                })}
              >
                {'Resend? ' +
                  (this.state.disabledResend
                    ? '(' + this.state.counterText + 's)'
                    : '')}
              </span>
            </Button>
          ) : null}
        </div>
        {isError ? <span className="help-block">{errorResponse}</span> : null}
      </div>
    );
  }
}
/**
 * Default proptype
 */
Password.propTypes = {
  enableForgot: PropTypes.bool,
  forgotAction: PropTypes.func,
  isError: PropTypes.bool,
  errorResponse: PropTypes.string,
  placeHolder: PropTypes.string,
  labelText: PropTypes.string,
  isOTP: PropTypes.bool,
  maxLength: PropTypes.number
};
