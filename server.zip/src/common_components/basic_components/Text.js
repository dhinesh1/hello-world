import React, { Component } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import { isAlphabetsOnly } from '../../helpers/utilsHelper';

/**
 * To render the basic text component
 */
export default class Text extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: ''
    };

    /**<-------------Events------------------> */
    this.onInputChange = this.onInputChange.bind(this);
  }

  /**
   * This function will call when change the input field
   * @param {*} e
   */
  onInputChange(e) {
    if(this.props.nameField && typeof e.target.value === 'string' && e.target.value.length && !isAlphabetsOnly(e.target.value)) {
      return false;
    }
    this.setState(
      {
        value: e.target.value
      },
      () => {
        this.props.changeCall && this.props.changeCall(this.state.value);
      }
    );
  }

  /**
   * Render element called here
   */
  render() {
    let {
      placeHolder,
      labelText,
      isError,
      errorResponse,
      defaultValue
    } = this.props;
    return (
      <div
        className={classNames('form-group form-group-lg flat', {
          'has-error': isError
        })}
      >
        <div className="label-animative">
          <input
            type="text"
            autoComplete="offf"
            onChange={this.onInputChange}
            className="form-control"
            placeholder={placeHolder}
            value={this.state.value}
            defaultValue={defaultValue}
          />
          <label className="control-label">{labelText}</label>
        </div>
        {isError ? <span className="help-block">{errorResponse}</span> : null}
      </div>
    );
  }
}
/**
 * Default proptype
 */
Text.propTypes = {
  placeHolder: PropTypes.string,
  nameField: PropTypes.bool,
  labelText: PropTypes.string,
  errorResponse: PropTypes.string,
  isError: PropTypes.bool
};
