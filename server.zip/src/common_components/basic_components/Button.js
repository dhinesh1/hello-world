import React, { Component } from 'react';
import PropTypes from 'prop-types';

/**
 * To render the basic button component
 */
export default class PYTButton extends Component {
  constructor(props) {
    super(props);

    /**<-------------Events------------------> */
    this.clickAction = this.clickAction.bind(this);
  }

  /**
   * Trigger when click the button
   * @param {*} e
   */
  clickAction(e) {
    if (!this.props.isLoading && this.props.clickAction) {
      this.props.clickAction(e);
    }
  }

  /**
   * Render method called here
   */
  render() {
    let {
      buttonClass,
      buttonText,
      children,
      isLoading,
      isDisabled,
      type = 'button',
      dataDismiss
    } = this.props;
    buttonClass = isLoading
      ? buttonClass + ' progress-btn infinite'
      : buttonClass;
    return (
      <button
        type={type}
        data-dismiss={dataDismiss}
        className={buttonClass}
        onClick={this.clickAction}
        disabled={isDisabled ? 'disabled' : ''}
      >
        {buttonText}
        {children ? children : null}
        {isLoading ? <span className="progress-bg" /> : null}
      </button>
    );
  }
}

/**
 * Default proptype
 */
PYTButton.propTypes = {
  buttonClass: PropTypes.string,
  buttonText: PropTypes.string,
  isLoading: PropTypes.bool,
  type: PropTypes.string
};
