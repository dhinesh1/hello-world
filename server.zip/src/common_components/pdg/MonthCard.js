import React from 'react';
import _ from 'lodash';
import classNames from 'classnames';

export default function MonthCard({
  month,
  season,
  climate,
  maxTemp,
  minTemp,
  recommended,
  shoulder,
  setSelectedMonth,
  i,
  checked
}) {
  let seasonClassNames = classNames({
    season: true,
    'our-pick': season === 'OUR_PICK',
    decent: season === 'DECENT_MUCH',
    high: season === 'TOO_CROWDED' || season === 'PREFERABLY_NOT'
  });

  let pdgCardClassNames = classNames(
    'n-tracker-plantotravel-' + _.toLower(month),
    {
      'pdg-card': true,
      disable: i > 9
    }
  );

  return (
    <div
      className={pdgCardClassNames}
      onClick={i <= 9 ? () => setSelectedMonth(month, season === 'OUR_PICK') : null}
    >
      <input
        type="radio"
        name="pdgMonth"
        disabled={i > 9}
        id={month}
        defaultValue={month}
        defaultChecked={checked}
      />
      <div className="pdg-card-content">
        <label htmlFor={month}>
          <h6>{_.startCase(_.toLower(month)).substring(0, 3)}</h6>
          <span className={seasonClassNames}>
            {season ? season.replace('_', ' ') : null}
          </span>
          <p className="dim-medium">
            <i className={`wi ${climate}`} />{' '}
            <span>
              {minTemp.toString().substring(0, 2)}°/{maxTemp
                .toString()
                .substring(0, 2)}°
            </span>
          </p>
          <i className="tick-icon" />
        </label>
      </div>
    </div>
  );
}
