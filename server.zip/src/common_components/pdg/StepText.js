import React from 'react';
import _ from 'lodash';
import { getStringFromArray } from '../../helpers/commonHelpers';
import { Link } from 'react-router-dom';

export default function StepText({
  mainText,
  mainTextMobile,
  showSentence,
  pdgData,
  selectedThemes,
  params
}) {
  pdgData = pdgData ? pdgData : {};
  let searchRegion = pdgData.region || params.searchRegion;
  let month = pdgData.minDays + '-' + pdgData.maxDays + '-nights';
  let days = 'in-' + (pdgData.preferredMonth || '').toLowerCase();
  return (
    <div className="clearfix pos-r">
      <p className="mb-0">
        <i className="vehoicon-navigation" />
        <b>
          <span className="hidden-xs">{mainText}</span>{' '}
          <span className="hidden-sm hidden-md hidden-lg text-uppercase">
            {mainTextMobile}
          </span>
        </b>
        {showSentence && !_.isEmpty(pdgData) ? (
          <span className="hidden-xs main-para">
            : A vacation in{' '}
            {pdgData.preferredMonth ? (
              <span>
                <Link to={`/customize/${searchRegion}`}>
                  {_.startCase(_.toLower(pdgData.preferredMonth))}
                </Link>
              </span>
            ) : null}{' '}
            {pdgData.minDays && pdgData.maxDays
              ? [
                  'for ',
                  <Link to={`/customize/${searchRegion}/month`}>
                    {pdgData.minDays} - {pdgData.maxDays} days
                  </Link>
                ]
              : null}{' '}
            {pdgData.interests ? (
              <span>
                exploring{' '}
                <Link to={`/customize/${searchRegion}/month/duration`}>
                  {/*getStringFromArray(selectedThemes, ', ', ' & ')*/}
                  {selectedThemes[0]}
                  {selectedThemes.length > 1
                    ? ` and ${selectedThemes.length - 1} more`
                    : null}
                </Link>
              </span>
            ) : null}{' '}
            to...
          </span>
        ) : null}
      </p>
      <Link to={`/`} target="_self">
        <i className="vehoicon-close close-search visible-xs" />
      </Link>
    </div>
  );
}
