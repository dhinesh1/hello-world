import React from 'react';
export default function ActiveStageIndicator({ actives, currentStepIndex }) {
  let active_states = [],
    inactive_states = [];

  let links = ['./', './', '../', '../..', '../../..'];
  let linkIndex = 0;
  for (let i = 1; i <= actives; i++) {
    linkIndex = currentStepIndex - i;

    active_states.push(<li className="active" key={`active_${i}`} />);
  }

  for (let j = 1; j <= 5 - actives; j++) {
    inactive_states.push(<li key={`in_active_${j}`} />);
  }

  return (
    <ul className="clearfix list-unstyled mb-0">
      {active_states}
      {inactive_states}
    </ul>
  );
}
