import React from 'react';
export default function PDGQuestionText({ mainQuestion, subText }) {
  return (
    <div className="clearfix text-center pdg-title hidden-xs">
      <h4>{mainQuestion}</h4>
      {/*<p>{subText}</p>*/}
    </div>
  );
}
