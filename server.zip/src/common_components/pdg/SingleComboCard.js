import React from 'react';
import { getStringFromArray, arrayToLi } from '../../helpers/commonHelpers';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';
import { AppConfig } from '../../app-config';
import {
  getFileNameFromUrl,
  getPathnameFromUrl,
  getImgIXUrl
} from '../../helpers/utilsHelper';
import LazyLoadComponent from '../LazyLoadComponent';

export default function SingleComboCard({
  cityIds,
  cityNames,
  comboId,
  imageUrls,
  interests,
  matchingPercentage,
  maxTemperature,
  minTemperature,
  noOfItinerariesBooked,
  createComboItinerary
}) {
  let tooltip = (
    <Tooltip id={'score-tooltip'} className={`white`}>
      Score matching your best interests
    </Tooltip>
  );

  return (
    <div
      className={`city-card-wrapper n-tracker-choosecombocard`}
      onClick={() => createComboItinerary(comboId)}
    >
      <section className="clearfix city-card">
        <i className="tick-icon visible-xs" />
        <LazyLoadComponent>
          <ComboCityImages images={imageUrls} />
        </LazyLoadComponent>
        <div className="city-info">
          <h5>
            {getStringFromArray(cityNames, ', ')}{' '}
            <span className="visible-xs text-right">100% match</span>
          </h5>
          <p>
            <span>
              {noOfItinerariesBooked} itineraries planned around these cities
            </span>
          </p>
          <ul className="clearfix list-unstyled mb-0 hidden-xs">
            {arrayToLi(interests)}
          </ul>
        </div>
        <div className="right-btns hidden-xs">
          <ul className="clearfix list-unstyled mb-0">
            <li>
              <i className="icon color-grey wi wi-hail" />
              <span>
                {minTemperature}°/{maxTemperature}
              </span>
            </li>
            <li>
              <h6>{matchingPercentage}%</h6>
              <OverlayTrigger
                id={'ot-matching-score-combos'}
                placement="top"
                overlay={tooltip}
              >
                <span className="dashed-underline">Match</span>
              </OverlayTrigger>
            </li>
            {/*<li>
              <button className="btn btn-default btn-outline">Choose</button>
            </li>*/}
          </ul>
        </div>
      </section>
    </div>
  );
}

function ComboCityImages({ images }) {
  switch (images.length) {
    case 2:
      return (
        <figure
          className="hidden-xs"
          style={{
            backgroundImage: `url(${getImgIXUrl(images[0], 'w=192')})`
          }}
        >
          <span
            className="thumbs w-50 brdr-right brdr-btm top-left"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[1], 'w=96')})`
            }}
          />
        </figure>
      );
    case 3:
      return (
        <figure className="hidden-xs">
          <span
            className="thumbs w-50 brdr-right top-left"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[0], 'w=96')})`
            }}
          />
          <span
            className="thumbs w-50 top-right"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[1])})`
            }}
          />
          <span
            className="thumbs w-100 brdr-top bottom-left"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[2])})`
            }}
          />
        </figure>
      );
    case 4:
      return (
        <figure className="hidden-xs">
          <span
            className="thumbs w-50 brdr-btm brdr-right top-left"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[0], 'w=96')})`
            }}
          />
          <span
            className="thumbs w-50 brdr-btm top-right"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[1])})`
            }}
          />
          <span
            className="thumbs w-50 brdr-right bottom-left"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[2])})`
            }}
          />
          <span
            className="thumbs w-50 bottom-right"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[3])})`
            }}
          />
        </figure>
      );
    default:
      return (
        <figure className="hidden-xs">
          <span
            className="thumbs w-50 brdr-btm brdr-right top-left"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[0], 'w=96')})`
            }}
          />
          <span
            className="thumbs w-50 brdr-btm top-right"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[1], 'w=96')})`
            }}
          />
          <span
            className="thumbs w-50 brdr-right bottom-left"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[2], 'w=192')})`
            }}
          />
          <span
            className="thumbs w-50 bottom-right"
            style={{
              backgroundImage: `url(${getImgIXUrl(images[3])})`
            }}
          >
            <i>+2</i>
          </span>
        </figure>
      );
  }
}
