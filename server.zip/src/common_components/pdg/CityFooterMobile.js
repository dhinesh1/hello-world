import React from 'react';
import classNames from 'classnames';
export default function CityFooterMobile({
  show,
  remainingMinDays,
  remainingMaxDays,
  createItinerary,
  selectedCities,
  openSelectedCityListView,
  screenType,
  clearAllCities,
  citiesSelectedForRemoval,
  clearSelectedCities,
  isLoading,
  closeSelectedCityListView
}) {
  let cityBottomOptionsClassNames = classNames(
    'bottom-options-bar text-center',
    {
      'slide-up': show
    }
  );

  let clearSelectedClassNames = classNames(
    'btn btn-primary btn-block tracker-clear-selected-cities-mobile',
    {
      disabled: citiesSelectedForRemoval.length === 0
    }
  );

  if (screenType === 'CHOOSE_CITIES') {
    return (
      <div className={cityBottomOptionsClassNames}>
        <section className="bottom-options-content">
          <div className="clearfix visible-xs xs-btns">
            <div className="btn-col pull-left">
              <button
                onClick={openSelectedCityListView}
                className="btn btn-light btn-block tracker-no-of-cities-selected-mobile"
              >
                {selectedCities.length > 0
                  ? `${selectedCities.length} cities`
                  : `No city`}{' '}
                chosen
              </button>
            </div>
            <div className="btn-col pull-right">
              <button
                onClick={createItinerary}
                disabled={isLoading}
                className={classNames(
                  'btn btn-primary btn-block tracker-done-build-itinerary-mobile',
                  {
                    'progress-btn': isLoading
                  }
                )}
              >
                {isLoading ? <span className={'progress-bg'} /> : null}
                <span className={'btn-txt'}>Build itinerary</span>
              </button>
            </div>
          </div>
        </section>
      </div>
    );
  } else {
    return (
      <div className={cityBottomOptionsClassNames}>
        <section className="bottom-options-content">
          <div className="clearfix visible-xs xs-btns">
            <div className="btn-col pull-left">
              <button
                onClick={closeSelectedCityListView}
                className="btn btn-light btn-block tracker-clear-all-cities-mobile"
              >
                <span className="color-accent-1">Go back</span>
              </button>
            </div>
            <div className="btn-col pull-right">
              <button
                disabled={citiesSelectedForRemoval.length === 0}
                onClick={clearSelectedCities}
                className={clearSelectedClassNames}
              >
                Clear selected
              </button>
            </div>
          </div>
        </section>
      </div>
    );
  }
}
