import React from 'react';
import classNames from 'classnames';
import { Link } from 'react-router-dom';
export default function CityTagsContainer({
  selectedCityNames,
  selectedCityIds,
  removeSelectedCity
}) {
  return (
    <div>
      <div className="clearfix pos-r city-tags hidden-xs">
        <div className="city-tag-inner">
          {arrayToSpan(selectedCityNames, selectedCityIds, removeSelectedCity)}
        </div>
        {/*<i className="vehoicon-ion-more more-icon" />*/}
      </div>
      <Link
        key={'searchCloseBtn'}
        target="_self"
        to={{
          pathname: `/`,
          state: { modal: false }
        }}
      >
        <i className="vehoicon-close close-search hidden-xs" />
      </Link>
    </div>
  );
}

//Has some spefic requirements so moved into component and not as utility
export function arrayToSpan(contents, selectedCityIds, removeSelectedCity) {
  let id = 0;
  return contents.map((content, i) => {
    return (
      <span
        onClick={() => removeSelectedCity(selectedCityIds[i], contents[i])}
        className={`tag active`}
        key={`city-tag-${i}`}
      >
        {content} <i className="vehoicon-close" />
      </span>
    );
  });
}
