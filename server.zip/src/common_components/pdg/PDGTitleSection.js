import React from 'react';
import { Link } from 'react-router-dom';
import _ from 'lodash';

export default function PDGTitleSection({
  showInput,
  showTitle,
  title,
  titleMobile,
  handleBack,
  handleForward,
  isForwardAvailable
}) {
  return (
    <div className="clearfix pos-r input-holder">
      {showInput ? (
        <input
          className="fw"
          type="text"
          placeholder="Search for a city or country"
          value={`Bali`}
        />
      ) : null}

      {showTitle ? (
        <h4 className="input-text-style">
          <span className="visible-sm visible-md visible-lg">{title}</span>
          <span className="visible-xs">{titleMobile}</span>
        </h4>
      ) : null}

      <i className="vehoicon-close close-search hidden-xs" />

      <Link
        key={'searchCloseBtn'}
        target="_self"
        to={{
          pathname: `/`,
          state: { modal: false }
        }}
      >
        <i className="vehoicon-close close-search hidden-xs" />
      </Link>
      <div className="arrows visible-xs">
        <a
          onClick={e => {
            e.preventDefault();
            handleBack();
          }}
          className="pull-left"
          href="#"
        >
          <i className="vehoicon-arrow_downward rotate-90" />
        </a>
        <a
          onClick={handleForward}
          className={`pull-right ${isForwardAvailable ? '' : 'disabled'}`}
          href="#"
        >
          <i className="vehoicon-arrow_downward rotate-minus-90" />
        </a>
      </div>
    </div>
  );
}
