import React from 'react';
import classNames from 'classnames';
export default function InterestCard({
  category,
  interests,
  updateInterestSelect,
  onThemeSelectChange,
  disabled,
  checked
}) {
  let pdgCardClass = classNames(
    'pdg-card n-tracker-seeanddo-' + `${category.id}`,
    {
      disable: disabled
    }
  );

  return (
    <div
      className={pdgCardClass}
      onClick={() => updateInterestSelect(category, interests)}
    >
      <input
        type="checkbox"
        id={category.id}
        defaultValue={category.id}
        disabled={disabled}
        name={'interest-card-input'}
        onClick={e => onThemeSelectChange(e)}
        defaultChecked={checked}
      />
      <div className="pdg-card-content">
        <label htmlFor={category.id}>
          <span className={`img int-img-${category.id}`} />
          <i className="tick-icon" />
          <p>{category.name}</p>
        </label>
      </div>
    </div>
  );
}
