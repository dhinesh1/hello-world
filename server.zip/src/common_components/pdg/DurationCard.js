import React from 'react';
export default function DurationCard({
  minDays,
  maxDays,
  i,
  setSelectedDuration,
  checked
}) {
  return (
    <div
      className={`pdg-card n-tracker-hm-days-${i}`}
      onClick={() => setSelectedDuration(minDays, maxDays)}
    >
      <input
        type="radio"
        name="pdgDuration"
        id={`pdg-duration-${i}`}
        defaultValue={6}
        defaultChecked={checked}
      />
      <div className="pdg-card-content">
        <label htmlFor={`pdg-duration-${i}`}>
          <span className={`img d-img-${i}`} />
          <i className="tick-icon" />
          <p className="vmargin-small mb-0">
            {minDays}-{maxDays} days
          </p>
        </label>
      </div>
    </div>
  );
}
