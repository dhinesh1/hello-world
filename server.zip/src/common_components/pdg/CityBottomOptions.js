import React from 'react';
import classNames from 'classnames';

export default function CityBottomOptions({
  show,
  remainingMinDays,
  remainingMaxDays,
  createItinerary,
  isLoading,
  prefixWord
}) {
  let cityBottomOptionsClassNames = classNames(
    'bottom-options-bar text-center hidden-xs',
    {
      'slide-up': show
    }
  );

  let text = '';
  let prefixTextClass = '';
  if (remainingMaxDays > 3) {
    text = `${remainingMinDays} - ${remainingMaxDays} days left, keep adding`;
    prefixTextClass = 'color-white';
  } else if (remainingMaxDays > 1 && remainingMaxDays <= 3) {
    text = `Just about the right travel time.`;
    prefixTextClass = 'color-accent-2';
  } else if (remainingMaxDays > -2 && remainingMaxDays <= 1) {
    text = `Too much to see, Too little time`;
    prefixTextClass = 'color-accent-4';
  } else {
    text = `Itinerary could overshoot by ${Math.abs(remainingMaxDays)} days`;
    prefixTextClass = 'color-accent-7';
  }

  return (
    <div className={cityBottomOptionsClassNames}>
      <section className="bottom-options-content">
        <div className="clearfix sm-text">
          <p className="pull-left">
            <b className={prefixTextClass}>{prefixWord} </b> {text}
          </p>
          <button
            className={classNames(
              'pull-right btn btn-primary tracker-done-build-itinerary',
              {
                'progress-btn': isLoading
              }
            )}
            disabled={isLoading}
            onClick={createItinerary}
          >
            {isLoading ? <span className={'progress-bg'} /> : null}
            <span className={'btn-txt'}>Done! Build itinerary</span>
          </button>
        </div>
      </section>
    </div>
  );
}
