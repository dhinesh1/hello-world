import React from 'react';
import classNames from 'classnames';
import _ from 'lodash';
import { arrayToLi } from '../../helpers/commonHelpers';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';
import { getImgIXUrl } from '../../helpers/utilsHelper';
import { AppConfig } from '../../app-config';
import LazyLoadComponent from '../LazyLoadComponent';

export default function CityCard({
  city,
  addSelectedCity,
  containerName,
  addToRemoveCityList,
  citiesSelectedForRemoval,
  currentTab
}) {
  let containerClassName = classNames('n-tracker-addcitiescard', {
    'city-card-wrapper': !containerName,
    'selected-city-card-wrapper': containerName,
    checked: _.includes(citiesSelectedForRemoval, city.id)
  });

  let iconClassName = classNames('icon', {
    'color-accent-6 vehoicon-diamond': city.hiddenGem,
    'color-accent-1 vehoicon-flame': !city.hiddenGem
  });

  let tooltip = (
    <Tooltip id={'score-tooltip'} className={`white`}>
      Score matching your best interests
    </Tooltip>
  );

  let tooltipTrendingHiddenGem = (
    <Tooltip id={'score-tooltip'} className={`white`}>
      {city.hiddenGem ? `Hidden gem` : `Trending`}
    </Tooltip>
  );

  return (
    <div
      id={`city-${city.id}`}
      className={containerClassName}
      onClick={
        addSelectedCity
          ? e => addSelectedCity(city, city.name, e)
          : e => addToRemoveCityList(city, e)
      }
    >
      <section className={`clearfix city-card`}>
        <i className="tick-icon visible-xs" />
        <LazyLoadComponent>
          <figure
            className="hidden-xs"
            style={{
              backgroundImage: `url(${getImgIXUrl(city.image, 'w=196')})`
            }}
          />
        </LazyLoadComponent>
        <div className="city-info">
          <h5>
            {city.name}{`, ${city.country}`}
            <span className="visible-xs text-right">
              {city.matchingPercentage}% match
            </span>
          </h5>
          <p>
            {city.text}
            <span>
              Ideal for {city.idealStay} stay .{' '}
              {getBudgetIndicator(city.budget)}
            </span>
          </p>
          <ul className="clearfix list-unstyled mb-0 hidden-xs">
            {arrayToLi(city.matchingInterests)}
          </ul>
        </div>
        <div className="right-btns hidden-xs">
          <ul className="clearfix list-unstyled mb-0">
            <li>
              <h6>{city.matchingPercentage}%</h6>
              <OverlayTrigger
                id={'ot-matching-score'}
                placement="top"
                overlay={tooltip}
              >
                <span className="dashed-underline">Match</span>
              </OverlayTrigger>
            </li>

            <li>
              {currentTab !== 'HIDDEN_GEMS' ? (
                <OverlayTrigger
                  id={'ot-matching-score'}
                  placement="top"
                  overlay={tooltipTrendingHiddenGem}
                >
                  <i className={iconClassName} />
                </OverlayTrigger>
              ) : (
                <i className={iconClassName} />
              )}
              {!city.hiddenGem && parseInt(city.trendingRank) < 6 ? (
                <span>#{city.trendingRank}</span>
              ) : null}
            </li>

            <li>
              <i className="icon color-grey wi wi-hail" />
              <span>
                {city.minTemp}&deg;/{city.maxTemp}&deg;
              </span>
            </li>
            {/*<li>
              <button className="btn btn-default btn-outline add">
                <i className="vehoicon-plus3" /> Add
              </button>
            </li>*/}
          </ul>
        </div>
      </section>
    </div>
  );
}

function getBudgetIndicator(budgetType) {
  switch (budgetType) {
    case 'High':
      return <i className="color-accent-1">&#8377;&#8377;&#8377;&#8377;</i>;
      break;
    case 'Medium':
      return <i className="color-accent-1">&#8377;&#8377;&#8377;</i>;
      break;
    case 'Low':
      return <i className="color-accent-1">&#8377;&#8377;</i>;
      break;
    default:
      return <i className="color-accent-1">&#8377;&#8377;&#8377;</i>;
  }
}
