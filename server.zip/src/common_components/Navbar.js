import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router-dom';
import { withLastLocation } from 'react-router-last-location';

import classnames from 'classnames';
import DropDownMenu from './DropDownMenu';
import { Link } from 'react-router-dom';
import _ from 'lodash';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { logout } from '../actions/actions_login_app';
import { getUserDetails } from '../actions/actions_app';
import { openOffCanvasMenu } from '../helpers/utilsHelper';
import { AppConfig } from '../app-config';
import { trackEvent, EVENT_TESTIMONIAL_VIEWED, EVENT_BLOG_VIEWED } from '../helpers/ML/EventsTracker';

const CONTACT_NUMBER = AppConfig.website_contact_number;

const scrollTop = () => {
  window.scroll(0, 0);
};

class Navbar extends Component {
  constructor(props) {
    super(props);

    this.closeDropDownIfOpened = this.closeDropDownIfOpened.bind(this);
  }

  componentDidMount() {
    this.props.actions.getUserDetails();
  }

  testimonialsClick = () => {
    trackEvent(EVENT_TESTIMONIAL_VIEWED);
    scrollTop();
  };

  closeDropDownIfOpened() {
    this.drowDownMenu && this.drowDownMenu.closeDropDown();
    this.drowDownLoggedInMenu && this.drowDownLoggedInMenu.closeDropDown();
  }

  render() {
    let { user_details, isBookingReview } = this.props;
    const ENABLE_CONTACT_NUMBER =
      parseInt(this.props.showContactNumber) || AppConfig.enable_Contact_Number;
    return (
      <header className="navbar-outer">
        {/* notification starts */}
        {/*notification ends */}

        {/* Booking review countdown timer */}
        {isBookingReview ? (
          <span className="countdown-timer hidden-xs hide" id={'desktop-timer'}>
            <i className="vehoicon-ion-android-time color-accent-1" />
            <span id={'countdown-timer-desktop'}>10:00</span>
          </span>
        ) : null}

        <nav className="navbar navbar-default mb-0">
          <div className="container">
            <div className="row">
              <div className="col-xs-6 col-sm-3 col-md-4">
                <a className="logo n-tracker-pytlogo" href="/">
                  <img
                    src="https://pyt-images.imgix.net/images/web_app/logo/pickyourtrail-logo.svg"
                    alt="PickYourTrail.com - Build, Customize and Book personalized vacations!"
                  />
                </a>
              </div>
              <div className="col-xs-6 col-sm-9 col-md-8">
                <div className="pull-right">
                  <ul
                    className="list-unstyled right-links mb-0 hidden-xs"
                    onMouseLeave={this.closeDropDownIfOpened}
                  >
                    <li>
                      <Link
                        key={'navTestimonialsBtn'}
                        to={{
                          pathname: `/testimonials`
                        }}
                        className="n-tracker-header-testimonial"
                        onClick={this.testimonialsClick}
                      >
                        {' '}
                        Testimonials{' '}
                      </Link>
                    </li>
                    <li>
                      <a
                        href="/guides"
                        target={'_blank'}
                        className="n-tracker-header-guides"
                      >
                        Guides
                      </a>
                    </li>
                    <li>
                      <Link
                        key={'navAboutBtn'}
                        to={{
                          pathname: `/about-us`
                        }}
                        className="n-tracker-header-about"
                        onClick={scrollTop}
                      >
                        About us
                      </Link>
                    </li>
                    <li>
                      <Link
                        key={'navCareersBtn'}
                        to={{
                          pathname: `/careers`
                        }}
                        className="n-tracker-header-careers"
                        onClick={scrollTop}
                      >
                        Careers
                      </Link>
                    </li>
                    <li>
                      <a
                        href="https://blog.pickyourtrail.com"
                        target={'_blank'}
                        className="n-tracker-header-blog"
                        onClick={() => {
                          trackEvent(EVENT_BLOG_VIEWED);
                        }}
                      >
                        Blog
                      </a>
                    </li>
                    <DropDownMenu
                      trigger={'click'}
                      wrapperClassName={'hidden-xs'}
                      ref={instance => {
                        this.drowDownMenu = instance;
                      }}
                    >
                      <li>
                        <a
                          href="https://visa.pickyourtrail.com"
                          target={'_blank'}
                          className="n-tracker-header-visa"
                        >
                          Visa
                        </a>
                      </li>
                      <li>
                        <Link
                          key={'navFaqsBtn'}
                          to={{
                            pathname: `/faq`
                          }}
                          className="n-tracker-header-faq"
                          onClick={scrollTop}
                        >
                          FAQ
                        </Link>
                      </li>
                      <li>
                        <Link
                          key={'navContactBtn'}
                          to={{
                            pathname: `/contact-us`
                          }}
                          className="n-tracker-header-contactus"
                          onClick={scrollTop}
                        >
                          Contact us
                        </Link>
                      </li>
                      <li className="divider" />
                      <li className="clearfix dd-contact">
                        <span className="pull-left">
                          {ENABLE_CONTACT_NUMBER ? (
                            <a
                              href={`tel:+91${CONTACT_NUMBER}`}
                              className="n-tracker-header-phoneno"
                            >
                              +91 {CONTACT_NUMBER}
                            </a>
                          ) : null}
                        </span>
                        <span
                          className={classnames('pull-right', {
                            'hidden-number': !ENABLE_CONTACT_NUMBER
                          })}
                        >
                          <a
                            href="https://www.facebook.com/pickyourtrail"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="n-tracker-header-facebookicon"
                          >
                            <i className="vehoicon-facebook-square" />
                          </a>
                          <a
                            href="https://twitter.com/@pickyourtrail"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="n-tracker-header-twittericon"
                          >
                            <i className="vehoicon-twitter" />
                          </a>
                          <a
                            href="https://www.instagram.com/pickyourtrail/"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="n-tracker-header-instagramicon"
                          >
                            <i className="vehoicon-instagram" />
                          </a>
                        </span>
                      </li>
                    </DropDownMenu>
                  </ul>

                  <ul
                    onMouseLeave={this.closeDropDownIfOpened}
                    className="list-unstyled right-links mb-0"
                  >
                    {user_details && user_details.loggedIn ? (
                      <DropDownMenu
                        ref={instance => {
                          this.drowDownLoggedInMenu = instance;
                        }}
                        trigger={'click'}
                        wrapperClassName={'logged-in'}
                        wrapperDropdownClassName={'hidden-xs'}
                        triggerElement={
                          <span>
                            <span className="user-initials">
                              {_.toUpper(
                                _.map(
                                  user_details.name.split(' ').splice(0, 2),
                                  el => el[0]
                                ).join('')
                              )}
                            </span>
                            &nbsp;<i className="caret hidden-xs" />
                          </span>
                        }
                      >
                        <li>
                          <span>{user_details.name}</span>
                        </li>
                        <li className="divider" />
                        {user_details && user_details.userType === 'AGENT' ? (
                          <li>
                            <Link
                              to={{
                                pathname: `/agent/dashboard`
                              }}
                              className="n-tracker-youraccount"
                              onClick={scrollTop}
                            >
                              Your dashboard
                            </Link>
                          </li>
                        ) : (
                          <Fragment>
                            <li key={'user_actions_0'}>
                              <Link
                                to={{
                                  pathname: `/your-vacations`
                                }}
                                className="n-tracker-yourvacations"
                                onClick={scrollTop}
                              >
                                Your vacations
                              </Link>
                            </li>
                            <li key={'user_actions_1'}>
                              <Link
                                to={{
                                  pathname: `/account`
                                }}
                                className="n-tracker-youraccount"
                                onClick={scrollTop}
                              >
                                Your account
                              </Link>
                            </li>
                          </Fragment>
                        )}
                        <li>
                          <a
                            href={'#'}
                            onClick={e => {
                              e.preventDefault();
                              this.props.actions.logout({
                                history: this.props.history,
                                userType: user_details.userType,
                                location: this.props.location
                              });
                            }}
                          >
                            Logout
                          </a>
                        </li>
                      </DropDownMenu>
                    ) : (
                      <li>
                        <a
                          href={'/login'}
                          onClick={e => {
                            e.preventDefault();

                            this.props.history.push('/login');
                          }}
                          className={'btn btn-default btn-outline btn-sm'}
                        >
                          Login
                        </a>
                      </li>
                    )}
                    <li
                      id="menuBtn"
                      className="hamburger-menu cursor-pointer n-tracker-mbl-hamburgermenu"
                      onClick={openOffCanvasMenu}
                    >
                      <i />
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </nav>
      </header>
    );
  }
}

function mapStateToProps(state) {
  return state.app;
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      getUserDetails: bindActionCreators(getUserDetails, dispatch),
      logout: bindActionCreators(logout, dispatch)
    }
  };
}

export default withLastLocation(
  withRouter(connect(mapStateToProps, mapDispatchToProps)(Navbar))
);
