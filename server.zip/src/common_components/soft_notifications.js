import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { manageSoftNotification, undo } from '../actions/actions_app';
import classNames from 'classnames';

class SoftNotification extends Component {
  constructor(props) {
    super(props);
    this.state = { duration: 12000, showClass: '', initialDelay: 500 };
    this.show = this.show.bind(this);
    this.hide = this.hide.bind(this);
    this.onClickHandler = this.onClickHandler.bind(this);
  }

  show() {
    let _this = this;
    if (
      _this.props.action_name === 'REMOVE_ACTIVITY' ||
      _this.props.action_name === 'REMOVE_HOTEL' ||
      _this.props.action_name === 'REMOVE_FLIGHT' ||
      _this.props.action_name === 'REMOVE_CITY' ||
      _this.props.action_name === 'REMOVE_DAY_IN_CITY'
    ) {
      //setTimeout(()=>{_this.hide()},this.state.duration);
      //setTimeout(()=>{_this.setState({showClass:"slide-in"})},this.state.initialDelay); //Showing after inital delay
    }
  }

  hide() {
    this.props.actions.manageSoftNotification({
      show_notification: false,
      message: '',
      show_undo: false
    });
  }

  onClickHandler(e) {
    e && e.preventDefault();

    this.props.actions
      .undo(this.props.itineraryInfo.itinerary.itineraryId)
      .then(() => {
        this.hide();
      });
  }

  render() {
    return (
      <div
        className={classNames('soft-notifications', {
          'slide-in': this.props.show_notification
        })}
        id="soft-notification"
      >
        <p className="opener bold">
          <span id="soft-notification-text">{this.props.message}</span>{' '}
          {this.props.show_undo ? (
            <a
              href="#"
              className="color-warning underline warning"
              id="soft-notification-undo"
              onClick={this.onClickHandler}
            >
              Undo<span className="hidden-xs"> action</span>?
            </a>
          ) : null}
        </p>
        <a onClick={this.hide} className="close-btn">
          <span className="vehoicon-close" />
        </a>
      </div>
    );
  }
}

const mapStateToProps = state => {
  let app = state.app;

  return {
    itineraryInfo: app.itineraryInfo.itineraryDetails,
    user_details: app.user_details,
    ...app.soft_notification
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: {
      manageSoftNotification: bindActionCreators(
        manageSoftNotification,
        dispatch
      ),
      undo: bindActionCreators(undo, dispatch)
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SoftNotification);
