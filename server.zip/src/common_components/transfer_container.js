import React from 'react';
import _ from 'lodash';
import placeHolderUrls from './Image/place_holder_urls';
import SmartImage from './Image/smart_image';
import { DropdownButton, MenuItem, OverlayTrigger, Tooltip } from 'react-bootstrap';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { getImgIXUrl } from '../helpers/utilsHelper';
import { AppConfig } from '../app-config';

const misc_url = AppConfig.images_cdn_misc_url;
const booking_state_alert = AppConfig.booking_state_alert;

const getImageSrc = (vehicle, type) => {
  let upperCaseVehicle = _.toUpper(vehicle);
  switch (upperCaseVehicle) {
    case 'BOAT':
      return getImgIXUrl(misc_url + `venice_speed_boat.jpg`);
    case 'FERRY':
      return getImgIXUrl(misc_url + `ferry.jpg`);
    case 'TRAIN':
      return getImgIXUrl(misc_url + `transfers-train.jpg`);
    case 'BUS':
      return getImgIXUrl(misc_url + `transfers-bus.jpg`);
    case 'SHUTTLE':
      return getImgIXUrl(misc_url + `transfers-shuttle.jpg`);
    case 'CAR':
      if (type === 'PRIVATE') {
        return getImgIXUrl(misc_url + `honda_accord.jpg`);
      } else {
        return getImgIXUrl(misc_url + `transfers-shuttle.jpg`);
      }
    default:
      return getImgIXUrl(misc_url + `honda_accord.jpg`);
  }
};

const TransferContainer = ({
  userDetails,
  transfer,
  is_hidden,
  transferTypeChangeText,
  isNonEditable,
  adult_count,
  child_count,
  itineraryId,
  changeTransferTypeHandler,
  handleInterCityActionClick,
  insideModal,
  regionCode,
  onChangeBusClick,
  isBooked,
  makeReadOnly
}) => {
  let transferIcon = null;
  switch (transfer.vehicle) {
    case 'CAR':
      transferIcon = 'vehoicon-car';
      break;
    case 'TRAIN':
      transferIcon = 'vehoicon-train';
      break;
    case 'FERRY':
      transferIcon = 'vehoicon-directions_boat';
      break;
    default:
      transferIcon = 'vehoicon-car';
      break;
  }

  let comoboPricingClasses = '';
  let comboPricingMessageBox = null;

  if (transfer.inCombo) {
    comoboPricingClasses = ' strikethrough dim vmargin-small';
    comboPricingMessageBox = (
      <div className="pointing-box top">
        <span className="meta-text t-5 inline-block">
          Included in combo package!
        </span>
      </div>
    );
  } else if (transfer.inSwissPass) {
    comoboPricingClasses = ' strikethrough dim vmargin-small';
    comboPricingMessageBox = (
      <div className="pointing-box top">
        <span className="meta-text t-5 inline-block">
          Included in Swiss Pass!
        </span>
      </div>
    );
  }
  // Surrounded with if to check the costing status else showing error screen
  if (transfer.status === 'SUCCESS') {
    return (
      <div
        className={classNames({
          'modal-row': insideModal,
          'pt-0': insideModal,
          'cost-container': insideModal
        })}
      >
        <article className="row-costed-item row">
          <div className="col-xs-9 col-sm-9 col-md-8 spacer">
            <div className="costed-item-head">
              <div className="date-costed">
                <span className="month">{transfer.mon}</span>
                <span className="date">{transfer.day}</span>
              </div>
              <h5 className="no-margin semi-bold">{transfer.text}</h5>
              <span className="small dim">
                {_.capitalize(transfer.type)} Transfer
              </span>
            </div>
            <div className="costed-item-details clearfix">
              <div className="col-xs-5 col-sm-2 col-md-3 no-padding">
                <div className="media-shell">
                  <figure className="sd">
                    <SmartImage
                      defaultImage={placeHolderUrls.activity2Medium}
                      src={getImageSrc(transfer.vehicle, transfer.type)}
                      alt={transfer.type + '_' + transfer.text}
                    />
                  </figure>
                </div>
              </div>
              <div className="col-xs-7 col-sm-9 col-md-9">
                {transfer.vehicle !== 'TRAIN' ? (
                  <span className="fine-text fade color-grey">Includes:</span>
                ) : null}
                {transfer.vehicle !== 'TRAIN' ? (
                  <div className="circle-list">
                    <ul className="fine-text fade color-grey">
                      <li>
                        {transfer.departureTime && transfer.departureTime !== ''
                          ? `Departure ${transfer.departureTime} ${
                          transfer.pickup
                          }`
                          : `Pickup from ${transfer.pickup}`}
                      </li>
                      <li>
                        {transfer.arrivalTime && transfer.arrivalTime !== ''
                          ? `Arrival ${transfer.arrivalTime} ${transfer.drop}`
                          : `Drop at ${transfer.drop}`}
                      </li>
                    </ul>
                  </div>
                ) : null}
              </div>
            </div>
          </div>

          <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
            <li>
              <span className={transferIcon} />
              {transfer.vehicle !== 'TRAIN'
                ? transfer.numberOfVehicles
                : null}{' '}
              {transfer.vehicle !== 'TRAIN'
                ? _.capitalize(transfer.type)
                : null}{' '}
              {_.capitalize(transfer.vehicle)}
            </li>
            <li>
              <span className="vehoicon-ion-android-time" />
              {transfer.duration} duration
            </li>
            <li>
              <span className="vehoicon-seats" />
              {child_count + adult_count}{' '}
              {child_count + adult_count > 1 ? 'Passengers' : 'Passenger'}
              {transfer.vehicle !== 'TRAIN' ? (
                <span>
                  {' '}
                  in {transfer.numberOfVehicles}{' '}
                  {transfer.numberOfVehicles > 1 ? 'vehicles' : 'vehicle'}
                </span>
              ) : null}
            </li>
          </ul>
          <div className="col-xs-3 col-sm-3 col-md-2 spacer">
            <div
              className={
                'action text-center ' +
                (transfer.publishedCost ? ' price-info-center' : ' price-info')
              }
            >
              {transfer.publishedCost ? (
                <span className="price block">
                  <span className={'price ' + comoboPricingClasses}>
                    <span className="WebRupee">Rs.</span>
                    {transfer.publishedCost}
                  </span>
                </span>
              ) : null}
              {transfer.publishedCost ? comboPricingMessageBox : null}
              {transfer.alternateAvailable && !makeReadOnly ? (
                transfer.vehicle && transfer.vehicle.toUpperCase() !== 'BUS' ? (

                  <DropdownButton
                    disabled={isNonEditable}
                    title="Change"
                    bsSize="small"
                    bsStyle="primary"
                    pullRight={true}
                  >
                    <MenuItem
                      eventKey="3"
                      onClick={e => changeTransferTypeHandler(transfer, e)}
                      className={
                        'change-transfer-type-ga sm-padding ' + is_hidden
                      }
                    >
                      {transferTypeChangeText}
                    </MenuItem>
                  </DropdownButton>
                ) : isBooked ? (
                  <OverlayTrigger
                    id="ot5"
                    placement="top"
                    overlay={
                      <Tooltip id="traintooltip">{booking_state_alert}</Tooltip>
                    }
                  >
                    <a
                      onClick={e =>
                        isBooked ? null : onChangeBusClick(transfer, e)
                      }
                      className={`btn btn-sm btn-primary disabled`}
                    >
                      Change
                    </a>
                  </OverlayTrigger>
                ) : (
                      <a
                        onClick={e =>
                          isBooked ? null : onChangeBusClick(transfer, e)
                        }
                        className={
                          `btn btn-sm btn-primary ${isBooked ? 'disabled' : ''}}`
                        }
                      >
                        Change
                  </a>
                    )
              ) : null}
              {userDetails &&
                userDetails.loggedIn &&
                userDetails.userType === 'ADMIN' &&
                !makeReadOnly &&
                !isNonEditable ? (
                  <a
                    href=' '
                    onClick={e => {
                      e && e.preventDefault(); e.stopPropagation();
                      handleInterCityActionClick(
                        {
                          itineraryId: itineraryId,
                          key: encodeURI(transfer.key),
                          isRemove: true,
                          transfer: 'transfer'
                        },
                        e
                      )
                    }
                    }
                    className={
                      'btn btn-sm btn-danger btn-outline fade' +
                      (isNonEditable ? 'disabled' : '')
                    }
                  >
                    Remove
                </a>
                ) : null}
            </div>
          </div>

          {regionCode === 'eur' && transfer.vehicle.toUpperCase() === 'CAR' ? (
            <div className="col-sm-12" style={{ pointerEvents: 'none' }}>
              <p className="light fine-text">
                <strong>Note:</strong> These transfers have a strict no. of
                luggage and dimension restriction - Baggage allowed per person
                is one handbag + medium size baggage (158cm)
              </p>
            </div>
          ) : null}
          {regionCode === 'aus' && transfer.type === 'SHARED' ? (
            <div className="col-sm-12">
              <p className="light fine-text">
                <strong>Note:</strong> Shared shuttle timings vary depending on the number of travellers - transfer departures are usually on an hourly basis
              </p>
            </div>
          ) : null}
        </article>
        <hr className="tear" />
      </div>
    );
  } else if (transfer.status === 'ERROR') {
    return (
      <div key={Math.random()}>
        <article className="row-costed-item row danger">
          <div className="col-xs-9 col-sm-9 col-md-8 spacer">
            <div className="costed-item-head">
              <div className="date-costed">
                <span className="month">{transfer.mon}</span>
                <span className="date">{transfer.day}</span>
              </div>
              <h5 className="no-margin semi-bold">{transfer.text}</h5>
              <span className="meta-text color-danger">
                Sorry, Transfer costing has failed currently. Please try after
                sometime!
              </span>
            </div>
          </div>
          <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
        </article>
        <hr className="tear" />
      </div>
    );
  } else if (
    !insideModal &&
    userDetails &&
    userDetails.loggedIn &&
    !makeReadOnly &&
    userDetails.userType === 'ADMIN'
  ) {
    return (
      <div key={Math.random()}>
        <article className="row-costed-item row warning">
          <div className="col-xs-9 col-sm-9 col-md-8 spacer">
            <div className="costed-item-head">
              <div className="date-costed">
                <span className="month">{transfer.mon}</span>
                <span className="date">{transfer.day}</span>
              </div>
              <h5 className="no-margin semi-bold">{transfer.text}</h5>
              <span className="meta-text color-warning">
                You have removed this transfer from itinerary!
              </span>
            </div>
          </div>
          <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
          <div className="col-xs-3 col-sm-3 col-md-2 spacer">
            <div className="action price-info text-center">
              <div
                data-toggle={isNonEditable ? 'tooltip' : ''}
                data-title="The itinerary has already been booked. Cant make any further changes."
                data-placement="bottom"
                data-container="body"
              >
                {makeReadOnly? null : <a
                  onClick={(e) =>
                    isNonEditable
                      ? null
                      : handleInterCityActionClick(
                        {
                          itineraryId: itineraryId,
                          key: encodeURI(transfer.key),
                          isRemove: false,
                          transfer: 'transfer'
                        },
                        e
                      )
                  }
                  className={
                    'btn btn-sm btn-primary  ' +
                    (isNonEditable ? 'disabled' : '')
                  }
                >
                  Add
                </a>}
              </div>
            </div>
          </div>
        </article>
        <hr className="tear" />
      </div>
    );
  }

  return null;
};

TransferContainer.propTypes = {
  userDetails: PropTypes.object.isRequired,
  transfer: PropTypes.object.isRequired,
  is_hidden: PropTypes.bool.isRequired,
  transferTypeChangeText: PropTypes.string.isRequired,
  isNonEditable: PropTypes.bool.isRequired,
  adult_count: PropTypes.number.isRequired,
  child_count: PropTypes.number.isRequired,
  itineraryId: PropTypes.string.isRequired,
  changeTransferTypeHandler: PropTypes.func,
  handleInterCityActionClick: PropTypes.func
};

export default TransferContainer;
