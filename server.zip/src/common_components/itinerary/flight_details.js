import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

import FlightInfoTabs from './flight_info_tabs';
import {
  encodeCostingKeyForURL,
  getAirlineLogo,
  getConnectionDuration
} from '../../helpers/utilsHelper';
import FlightContainer from '../flight_container';
import SmartImage from '../Image/smart_image';
import {
  itineraryModalsRouteHelper,
  routingPageType,
  FLIGHT_ALTERNATES
} from '../../helpers/routesHelper';

class FlightDetails extends Component {
  constructor(props) {
    super(props);

    this.deleteFlightHandler = this.deleteFlightHandler.bind(this);
    this.changeButtonClickHandler = this.changeButtonClickHandler.bind(this);
    this.getFlightTripTitle = this.getFlightTripTitle.bind(this);
    this.renderRefundability = this.renderRefundability.bind(this);
    this.renderTrips = this.renderTrips.bind(this);
    this.HeaderRenderHelper = this.HeaderRenderHelper.bind(this);
    this.closeButtonRenderHelper = this.closeButtonRenderHelper.bind(this);
    this.getTripStartAndEndDate = this.getTripStartAndEndDate.bind(this);
    this.handleCallToActionClick = this.handleCallToActionClick.bind(this);
    this.state = {
      backgroundHeight: '100vh'
    };
  }

  closeButtonRenderHelper() {
    return (
      <button
        type="button"
        className="close white margin-top-5"
        onClick={this.props.onCloseModal}
        aria-label="Close"
      >
        <span className="vehoicon-close" aria-hidden="true" />
      </button>
    );
  }

  getConnectionDurationAndStopsCount(duration, r) {
    let stops = '';
    if (r !== undefined) {
      if (r.length - 1 === 0) stops = 'Direct';
      else if (r.length - 1 === 0) stops = `${r.length - 1} stop`;
      else stops = `${r.length - 1} stops`;
    }
    let durHours = Math.floor(duration / 60);
    let durMinutes = duration % 60;

    if (durHours !== 0)
      if (durMinutes > 0) {
        return { stops: stops, duration: `${durHours}h ${durMinutes}m` };
      } else {
        if (durHours > 1)
          return { stops: stops, duration: `${durHours} hours` };
        else return { stops: stops, duration: `${durHours} hour` };
      }
    else return { stops: stops, duration: `${durMinutes}m` };
  }

  getFlightTripTitle(flight) {
    let allTrips = flight.allTrips;
    let lastTrip = allTrips.length - 1;
    return allTrips.map((trip, i) => {
      let connector =
        i === lastTrip - 1 && i !== lastTrip ? (
          <span>&nbsp;&nbsp; - &nbsp;&nbsp;</span>
        ) : null;
      let lastRoute = flight.trips[trip].routes.length - 1;
      return (
        <span key={'title_' + i} className="regular medium-bold">
          {flight.trips[trip].routes[0].departureCity} to{' '}
          {flight.trips[trip].routes[lastRoute].arrivalCity} {connector}
        </span>
      );
    });
  }

  deleteFlightHandler(e) {
    e.preventDefault();

    this.props.deleteFlight(this.props.flightData);
  }

  changeButtonClickHandler(e) {
    e.preventDefault();
    let { history, flightData, itineraryDetail } = this.props;
    const flightKey = encodeCostingKeyForURL(flightData.key);
    history.push(
      itineraryModalsRouteHelper({
        itineraryId: itineraryDetail.itineraryId,
        regionCode: itineraryDetail.regionCode,
        parentPage: routingPageType.inclusion,
        target: FLIGHT_ALTERNATES,
        customParams: { flightKey }
      })
    );
  }
  /**
   * To handle action for the remove intercity flight 
   */
  handleCallToActionClick = (e) => {
    e && e.stopPropagation();
    this.props.handleCallToActionClick(
      {
        itineraryId: this.props.itineraryDetail.itineraryId,
        key: encodeURI(this.props.flightData.key),
        transfer: 'flight',
        isRemove: true
      },
      e
    )
  }
  
  HeaderRenderHelper() {
    let { itineraryDetail, flightData, user_details } = this.props;
    let { booking, frozen, flightsBlocked } = itineraryDetail;
    const isInterCityTransfer = Object.keys(flightData.trips).length === 1;
    let isBooked =
      booking || frozen || (flightsBlocked && flightData.status === 'BLOCKED');
    let removeBtn = null;
    if ((flightData.canRemoveCost && user_details.userType !== 'USER') || isInterCityTransfer) {
      removeBtn = (
        <button
          onClick={e => (isBooked ? null : isInterCityTransfer ?  this.handleCallToActionClick(e) :  this.deleteFlightHandler(e))}
          className={
            'btn btn-sm btn-default btn-outline remove-cta ' +
            (isBooked ? 'disabled' : '')
          }
        >
          <span className="vehoicon-delete text-xs-only" />
          <span className="text-md-only">Remove</span>
        </button>
      );
    }

    return (
      <div className="modal-header clearfix with-bg">
        <button
          type="button"
          onClick={this.props.onCloseModal}
          className="pull-left close"
          data-dismiss="modal"
        >
          <i className="vehoicon-close" />
        </button>
        <span className="caps-text semi-bold kern-more fade">flight</span>
        <div className="modal-actions pull-right">
          {removeBtn}{' '}
          <button
            type="button"
            className={
              'pull-right btn btn-sm btn-primary change-cta ' +
              (isBooked ? 'disabled' : '')
            }
            onClick={e => (isBooked ? null : this.changeButtonClickHandler(e))}
          >
            Change
          </button>
        </div>
      </div>
    );
  }

  renderRefundability(refundability) {
    return refundability ? (
      <span>
        <span className="vehoicon-refundable color-success" />{' '}
        <span className="small underline v-middle">Refundable</span>
      </span>
    ) : (
      <span>
        <span className="vehoicon-non-refundable color-danger" />{' '}
        <span className="small underline v-middle">Non Refundable</span>
      </span>
    );
  }

  renderTrips(flight) {
    return flight.allTrips.map(tripId => {
      let trip = flight.trips[tripId];

      let duration = getConnectionDuration(trip.duration);

      let layover_count = '';
      if (trip.routes.length - 2 > 0) {
        if (trip.routes.length - 2 === 1) {
          layover_count = '1 Layover';
        } else {
          layover_count = trip.routes.length - 2 + ' Layovers';
        }
      }
      const airlineImg = getAirlineLogo(flight.airlineCode);
      return (
        <div className="flight-info spacer-both" key={tripId}>
          <div className="row">
            <div className="col-xs-8 col-sm-12">
              <h5 className="no-margin">
                {trip.mon} {trip.day}
              </h5>
              <span className="small">
                {duration} flight, {layover_count}{' '}
                {!trip.landSameDay ? (
                  <span className="pill warning">Arrives next day</span>
                ) : null}
              </span>
            </div>
            <div className="hidden-xs col-xs-4 no-padding hidden-sm hidden-md hidden-lg">
              <div className="airline-logo-fit right">
                <SmartImage
                  disableLazyLoad
                  src={airlineImg.url}
                  alt={airlineImg.name}
                  defaultImage={airlineImg.default}
                />
              </div>
            </div>
          </div>
          {this.SingleFlightTripRow(trip, flight.airlineCode)}
          <FlightInfoTabs trip={trip} />
        </div>
      );
    });
  }

  SingleFlightTripRow(trip, airlineCode) {
    let layover_row = null;
    return trip.routes.map((route, inx) => {
      if (route.connectionDuration > 0)
        layover_row = (
          <span className="layover-bar mini fade">
            {getConnectionDuration(route.connectionDuration)} layover in{' '}
            {route.arrivalCity}
          </span>
        );
      else layover_row = null;

      let flightNumber = '';
      let carrierCode = '';
      if (trip.routes) {
        flightNumber = trip.routes[inx].flightNumber;
        carrierCode = trip.routes[inx].carrierCode;
      }
      const airlineImg = getAirlineLogo(airlineCode);
      return (
        <div key={'single_route_' + inx} className="clearfix spacer">
          <div className="col-sm-3 no-padding text-center">
            <div className="airline-logo-fit">
              <SmartImage
                disableLazyLoad
                src={airlineImg.url}
                alt={airlineImg.name}
                defaultImage={airlineImg.default}
              />
            </div>
            <span className="mini">{`${carrierCode}  ${flightNumber}`}</span>
          </div>
          <div className="col-xs-12 col-sm-9 no-padding">
            <div className="col-xs-5 no-padding">
              <span className="vehoicon-flight_takeoff" />&nbsp;{route.departureTime.substring(
                0,
                5
              )}
              <span className="block mini dim">
                {route.departureAirportCode}, {route.departureCity}
              </span>
            </div>
            <div className="col-xs-2 no-padding text-center dim">
              ⟶
              <span className="block mini ">
                {route.travelDuration > 0
                  ? this.getConnectionDurationAndStopsCount(
                      route.travelDuration
                    ).duration
                  : null}
              </span>
            </div>
            <div className="col-xs-5 no-padding text-right">
              {route.arrivalTime.substring(0, 5)}&nbsp;<span className="vehoicon-flight_land" />
              <span className="block mini dim">
                {route.arrivalAirportCode}, {route.arrivalCity}
              </span>
            </div>
            {layover_row}
          </div>
        </div>
      );
    });
  }

  getTripStartAndEndDate(flight) {
    let tripStartAndEndDate = null;
    if (flight.allTrips.length === 2) {
      let trip1 = flight.trips[flight.allTrips[0]];
      let trip2 = flight.trips[flight.allTrips[1]];
      let trip1RoutesLastIndex = trip1.routes.length - 1;
      let trip2RoutesLastIndex = trip2.routes.length - 1;
      let trip1DisplayText = `${trip1.routes[0].depMonth} ${
        trip1.routes[trip1RoutesLastIndex].depDateOfMonth
      }`;
      let trip2DisplayText = `${trip2.routes[0].arrMonth} ${
        trip2.routes[trip2RoutesLastIndex].arrDateOfMonth
      }`;
      tripStartAndEndDate = `${trip1DisplayText} - ${trip2DisplayText}`;
    } else {
      let trip1 = flight.trips[flight.allTrips[0]];
      let trip1RoutesLastIndex = trip1.routes.length - 1;
      let trip1DisplayText = `${trip1.routes[0].depMonth} - ${
        trip1.routes[trip1RoutesLastIndex].depDateOfMonth
      }`;
      tripStartAndEndDate = `${trip1DisplayText}`;
    }

    return tripStartAndEndDate;
  }

  render() {
    let { adult_count, child_count, flightData } = this.props;
    let roundTripLabel =
      flightData.allTrips.length === 2 ? '(Round trip)' : null;
    let childCountMarkup = '';
    if (child_count > 0) {
      childCountMarkup = ' + ' + child_count;
    }
    const splitPricing = this.props.itineraryDetail.splitPricing;

    return (
      <div className={`modal-dialog`}>
        <div className={'modal-content with-header'}>
          {this.HeaderRenderHelper()}
          <div className={'modal-body'}>
            <FlightContainer
              flightData={flightData}
              roundTripLabel={roundTripLabel}
              childCountMarkup={childCountMarkup}
              adult_count={adult_count}
              splitPricing={splitPricing}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(FlightDetails);
