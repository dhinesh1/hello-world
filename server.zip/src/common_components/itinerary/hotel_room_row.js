import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import _ from 'lodash';
import { Tooltip, OverlayTrigger } from 'react-bootstrap';

import SmartImage from '../Image/smart_image';
import placeHolderUrls from '../Image/place_holder_urls';
import PriceDiff from '../price_diff';
import {
  encodeCostingKeyForURL,
  getImgIXUrl,
  getMealType
} from '../../helpers/utilsHelper';
import { AppConfig } from '../../app-config';
import {
  trackEvent,
  EVENT_ITINERARY_MODIFIED,
  EVENT_INCLUSIONS_MODIFIED
} from '../../helpers/ML/EventsTracker';
import {
  itineraryModalsRouteHelper,
  HOTEL_ALTERNATE_ROOMS,
  RATE_MATCH_HOTEL_ROOM
} from '../../helpers/routesHelper';
const booking_state_alert = AppConfig.booking_state_alert;

class HotelRoomRow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      canShowExtraInclusions: false
    };
    this.handleChangeRoomClick = this.handleChangeRoomClick.bind(this);
    this.showExtraInclusions = this.showExtraInclusions.bind(this);
  }

  handleChangeRoomClick(e) {
    e && e.stopPropagation();
    e && e.nativeEvent.stopImmediatePropagation();
    e && e.preventDefault();

    //This is to show alternates rooms of a given room
    let { hotel, room, history, location, itineraryDetail } = this.props;

    let hotelKey = encodeCostingKeyForURL(hotel.costingKey);
    let hotelRoomKey = encodeCostingKeyForURL(room.roomTypeId);

    if (location.pathname.indexOf('view') > 0) {
      trackEvent(EVENT_ITINERARY_MODIFIED, {	
        room_changed: true
      });
    } else {
      trackEvent(EVENT_INCLUSIONS_MODIFIED, {
        room_changed: true
      });
    }

    history.push(
      itineraryModalsRouteHelper({
        itineraryId: itineraryDetail.itineraryId,
        location,
        regionCode: itineraryDetail.regionCode,
        customParams: { hotelKey, hotelRoomKey },
        target: HOTEL_ALTERNATE_ROOMS
      })
    );
  }

  getExtraInclusionsText(room) {
    let data = `<ul>
    ${room.extraInclusions.reduce(
      (result, item, inx) =>
        result +
        `<li key="extra_inclusions_${inx}">
          ${item}
        </li>`,
      ''
    )}
    </ul>`;

    return data;
  }

  showExtraInclusions(e) {
    e.preventDefault();
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();

    this.setState({
      canShowExtraInclusions: !this.state.canShowExtraInclusions
    });
  }

  render() {
    if (this.props.room !== undefined) {
      let {
        hotel,
        room,
        userDetails,
        onHotelDetails,
        itineraryDetail,
        history,
        location,
        makeReadOnly
      } = this.props;

      // Island hopper change - by jothi
      let is_islandHopper = hotel && hotel.sourceProvider === 'ISLANDHOPPER';
      const discountAppliedBatch = room.discountApplied ? <span className={'pill color-white bg-accent-3 v-spaced'}> Discount Applied </span> : null;

      let room_label = '';
      let change_btn = '';
      let change_room_btn = '';
      let roomPrice = null;
      let room_with_view = room.roomWithView ? (
        <span className="pill success">Room with view!</span>
      ) : null;

      let honeymoon_special = room.extraInclusions ? (
        <span className="pill success">Honeymoon Spl</span>
      ) : null;

      let discountBadge = null;
      let strikeOffPrice = null;
      let discountBadgeShownClass = '';
      if (
        room.discountPercentage > 0 &&
        this.props.packageRate != undefined &&
        !this.props.packageRate
      ) {
        discountBadge = (
          <div className="discount-badge push-up">
            <span className="percentage">{room.discountPercentage}%</span>
            <span className="off-text">OFF</span>
          </div>
        );
        discountBadgeShownClass = ' inline-block';
        strikeOffPrice = (
          <span className="strikethrough">
            <span className="price fade striked-price">
              <span className="WebRupee">Rs.</span>
              {room.basePrice}
            </span>
          </span>
        );
      }

      let discountType = null;
      if (room.memberOnlyDeal && room.salePrice) {
        discountType = (
          <span className="meta-text fade block v-spaced">Promo Price!</span>
        );
      } else {
        if (room.memberOnlyDeal) {
          discountType = (
            <span className="meta-text fade block v-spaced">
              Member Discount!
            </span>
          );
        } else if (room.salePrice) {
          discountType = (
            <span className="meta-text fade block v-spaced">Promo Price!</span>
          );
        }
      }

      let room_image =
        room.roomImages && room.roomImages.length > 0
          ? room.roomImages[0]
          : AppConfig.invalid_image_url;

      let edit_price_icon =
        onHotelDetails &&
        hotel.called_from !== 'ALTERNATE_HOTELS' &&
        userDetails &&
        userDetails.loggedIn &&
        this.props.allowChangeRoom &&
        userDetails.userType === 'ADMIN' 
        && !makeReadOnly? (
          <a
            onClick={e => {
              e.stopPropagation();
              e.nativeEvent.stopImmediatePropagation();

              let hotelKey = encodeCostingKeyForURL(hotel.costingKey);
              let roomTypeId = encodeCostingKeyForURL(room.roomTypeId);

              history.push(
                itineraryModalsRouteHelper({
                  itineraryId: itineraryDetail.itineraryId,
                  regionCode: itineraryDetail.regionCode,
                  location,
                  target: RATE_MATCH_HOTEL_ROOM,
                  customParams: {
                    hotelKey,
                    roomTypeId,
                    called_from: 'HOTEL_ROOM_ROW'
                  }
                })
              );
            }}
          >
            {' '}
            <span className="vehoicon-mode_edit" />
          </a>
        ) : null;

      if (this.props.isCurrentPick) {
        room_label = (
          <span className="no-v-margin block text-grey">{hotel.name}</span>
        );

        if (room.finalPrice) {
          roomPrice = (
            <p className={'h6 price ' + discountBadgeShownClass}>
              <span className="block">
                <span className="WebRupee">Rs.</span>
                {room.finalPrice} {edit_price_icon}
              </span>{' '}
              {strikeOffPrice}
            </p>
          );
        }
      } else {
        if (this.props.onHotelDetails) {
          room_label = (
            <span className="index-no">#{this.props.room_no} –</span>
          );

          if (room.finalPrice) {
            roomPrice = (
              <p className={'h6 price ' + discountBadgeShownClass}>
                <span className="block">
                  <span className="WebRupee">Rs.</span>
                  {room.finalPrice} {edit_price_icon}
                </span>{' '}
                {strikeOffPrice}
              </p>
            );
          }

          //Details modal shown when view details icon of an alternate hotel card is clicked
          if (hotel.called_from !== 'ALTERNATE_HOTELS') {
            //Details modal shown when view details is clicked from Itinerary view and costing view
            {
              change_room_btn =
                itineraryDetail && itineraryDetail.booking ? (
                  // <span data-toggle="tooltip" data-title={booking_state_alert}>
                  //   <a
                  //     href="javascript:void(0)"
                  //     className="btn btn-xs btn-primary-dark btn-outline disabled"
                  //   >
                  //     Change <span className="text-md-only">room</span>
                  //   </a>
                  // </span>

                  <OverlayTrigger
                    id="ot2"
                    placement="top"
                    overlay={
                      <Tooltip id="roomtooltip1">{booking_state_alert}</Tooltip>
                    }
                  >
                    <a
                      href="javascript:void(0)"
                      className="btn btn-xs btn-primary-dark btn-outline disabled"
                    >
                      Change <span className="text-md-only">room</span>
                    </a>
                  </OverlayTrigger>
                ) : (
                  <a
                    onClick={this.handleChangeRoomClick}
                    className="btn btn-xs btn-primary-dark btn-outline"
                  >
                    Change <span className="text-md-only">room</span>
                  </a>
                );
            }
          }
        } else if (this.props.onCostingPage) {
          change_room_btn =
            makeReadOnly ? null : itineraryDetail && itineraryDetail.booking ? (
              <OverlayTrigger
                id="ot3"
                placement="top"
                overlay={
                  <Tooltip id="roomtooltip2">
                    {<Tooltip id="tooltip">{booking_state_alert}</Tooltip>}
                  </Tooltip>
                }
              >
                <a
                  href="javascript:void(0)"
                  className={`btn btn-xs btn-primary btn-outline disabled`}
                >
                  Change room
                </a>
              </OverlayTrigger>
            ) : (
              <a
                onClick={this.handleChangeRoomClick}
                className={`btn btn-xs btn-primary btn-outline`}
              >
                Change room
              </a>
            );
        } else {
          if (this.props.packageRate) {
            let currentPickPriceValue = _.toNumber(
              this.props.currentPickPrice.replace(/,/g, '')
            );
            let roomFinalPrice = _.toNumber(room.finalPrice.replace(/,/g, ''));
            let diffPrice = roomFinalPrice - currentPickPriceValue;

            if (diffPrice > 0) {
              roomPrice = (
                <p className={'h6 price ' + discountBadgeShownClass}>
                  <span className="block">
                    <span className="WebRupee">Rs.</span> {diffPrice}
                  </span>
                  <span className="text-danger">&#8679;</span> {edit_price_icon}{' '}
                  {strikeOffPrice}
                </p>
              );
            } else {
              roomPrice = (
                <p className={'h6 price ' + discountBadgeShownClass}>
                  <span className="block">
                    <span className="WebRupee">Rs.</span> {diffPrice}
                    <span className="text-danger">&#8681;</span>{' '}
                    {edit_price_icon}
                  </span>{' '}
                  {strikeOffPrice}
                </p>
              );
            }
          } else {
            roomPrice = (
              <p className={'h6 price ' + discountBadgeShownClass}>
                <span className="block">
                  <span className="WebRupee">Rs.</span> {room.finalPrice}{' '}
                  {edit_price_icon}
                </span>{' '}
                {strikeOffPrice}
              </p>
            );
          }

          change_btn = (
            <a
              onClick={() => {
                this.props.updateSelectedRoom(room);
              }}
              className="btn btn-xs btn-primary"
            >
              Change
            </a>
          );
        }
      }

      const hasOffer = room.discountPercentage > 0 && !this.props.packageRate;

      return (
        <li className="col-xs-12 option">
          <div
            className={'row ' + (this.props.onCostingPage ? 'hidden-xs' : '')}
          >
            <div
              className={
                this.props.onCostingPage
                  ? 'col-xs-12 col-md-12'
                  : 'col-xs-9 col-md-9'
              }
            >
              <div className="display-table">
                <div className="table-cell pic">
                  <span className="room-with-view-container">
                    {room_with_view}
                  </span>
                  <div className="media-shell with-view-label">
                    <figure className="sd">
                      <SmartImage
                        src={room_image}
                        disableLazyLoad={true}
                        defaultImage={placeHolderUrls.roomsLarge}
                        alt={room.name}
                      />
                    </figure>
                  </div>
                </div>
                <div className="table-cell">
                  <div className="row">
                    <div
                      className={
                        this.props.onCostingPage ? 'col-xs-8' : 'col-xs-12'
                      }
                    >
                      <span className="meta-text semi-bold block">
                        {room_label} {room.name}
                      </span>
                      <span className="dim fine-text light">
                        Accomodates {room.maxRoomOccupancy}{' '}
                        {room.maxRoomOccupancy > 1 ? 'adults' : 'adult'}
                      </span>
                      <br />
                      <span className="dim fine-text light">
                        {room.bedTypes.join(', ')}
                      </span>
                    </div>
                    {this.props.onCostingPage && this.props.allowChangeRoom ? (
                      <div className="col-xs-4 text-right">
                        {change_room_btn}
                      </div>
                    ) : null}
                  </div>

                  {is_islandHopper ? (
                    <IslandHopperRoomAmenities room={room} />
                  ) : (
                    <RoomAmenitiesComponent
                      onCostingPage={this.props.onCostingPage}
                      showExtraInclusions={this.showExtraInclusions}
                      {...this.state}
                      room={room}
                      getExtraInclusionsText={this.getExtraInclusionsText}
                    />
                  )}
                </div>
              </div>
            </div>
            {this.props.onCostingPage ? null : (
              <div className={'text-center col-xs-3 col-md-3'}>
                {room.finalPrice ? discountBadge : null}
                {room.finalPrice ? roomPrice : null}
                {room.finalPrice ? discountType : null}
                {discountAppliedBatch}
                {room.diffDetail && room.diffDetail.diffCost >= 0 ? (
                  <PriceDiff
                    classNames="h6 price block"
                    diff={room.diffDetail}
                  />
                ) : null}
                {change_btn}
                {this.props.allowChangeRoom ? change_room_btn : null}
              </div>
            )}
          </div>

          {this.props.onCostingPage ? (
            <div className="row visible-xs">
              <div className="col-xs-8">
                <span className="meta-text name">
                  {room_label} {room.name}
                </span>
                <span className="dim meta-text">
                  Accomodates {room.maxRoomOccupancy}{' '}
                  {room.maxRoomOccupancy > 1 ? 'adults' : 'adult'}
                </span>
                <br />
                <span className="dim fine-text light">
                  {room.bedTypes.join(', ')}
                </span>
              </div>
              {this.props.allowChangeRoom ? (
                <div className="col-xs-4">{change_room_btn}</div>
              ) : null}
              <div className="col-xs-12">
                <div className="costed-item-details clearfix">
                  <div className="col-xs-5 col-sm-2 col-md-3 no-padding">
                    <span className="room-with-view-container">
                      {room_with_view}
                    </span>
                    {room.extraInclusions ? (
                      <span className="room-with-view-container">
                        {honeymoon_special}
                      </span>
                    ) : null}
                    <div className="media-shell with-view-label">
                      <figure
                        className="sd"
                        style={{
                          backgroundImage:
                            'url(' + getImgIXUrl(room_image) + ')'
                        }}
                      />
                    </div>
                  </div>
                  <div className="col-xs-7 col-sm-9 col-md-9">
                    {is_islandHopper ? (
                      <IslandHopperRoomAmenities room={room} />
                    ) : (
                      <RoomAmenitiesComponent
                        onCostingPage={this.props.onCostingPage}
                        showExtraInclusions={this.showExtraInclusions}
                        {...this.state}
                        room={room}
                        getExtraInclusionsText={this.getExtraInclusionsText}
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          ) : null}

          {this.props.onCostingPage ? (
            <div className="row">
              <div className={'col-xs-12 spacer-bottom-half'}>
                <hr className="tear" />
              </div>
            </div>
          ) : null}
        </li>
      );
    } else {
      return null;
    }
  }
}

const RoomAmenitiesComponent = props => (
  <div className="new-room-amenities">
    <div className="row">
      <div className="col-xs-12 col-md-12 new-amenities-inner spacer-half">
        <ul className="clearfix no-padding">
          {props.room.refundable ? (
            <li>
              <span className="vehoicon-refundable color-primary-dark" />
              <p>Refundable</p>
            </li>
          ) : (
            <li>
              <span className="vehoicon-non-refundable color-accent-7" />
              <p>Non Refundable</p>
            </li>
          )}
          {props.room.freeWireless ? (
            <li>
              <span className="vehoicon-wifi" />
              <p>Free Wifi</p>
            </li>
          ) : (
            <li className="dim-medium">
              <span className="vehoicon-wifi" />
              <p>
                <span className="strikethrough">
                  <span>Free Wifi</span>
                </span>
              </p>
            </li>
          )}
          {props.room.roomSize ? (
            <li>
              <span className="vehoicon-length_square">
                <span className="path1" />
                <span className="path2" />
                <span className="path3" />
                <span className="path4" />
              </span>
              <p>{props.room.roomSize}</p>
            </li>
          ) : null}
          {props.room.freeBreakfast ? (
            <li>
              <span className="vehoicon-restaurant_menu" />
              <p>Free Breakfast</p>
            </li>
          ) : (
            <li className="dim-medium">
              <span className="vehoicon-restaurant_menu" />
              <p>
                <span className="strikethrough">
                  <span>Free Breakfast</span>
                </span>
              </p>
            </li>
          )}
        </ul>
      </div>
      {props.room.extraInclusions ? (
        <div
          className={
            'col-xs-12 spacer-half ' + (props.onCostingPage ? 'hidden-xs' : '')
          }
        >
          <p onClick={props.showExtraInclusions}>
            <span
              className={
                'color-primary dashed-underline cursor-pointer has-dropdown ' +
                (props.canShowExtraInclusions ? 'open' : '')
              }
            >
              Honeymoon special
            </span>
          </p>
          {props.canShowExtraInclusions ? (
            <div>
              <ul>
                {props.room.extraInclusions.map((item, inx) => (
                  <li key={`extra_inclusions_${inx}`}>{item}</li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  </div>
);

const IslandHopperRoomAmenities = props => {
  const mealType = getMealType(props.room.mealType); //return the mealType text.
  let rateIncludesSplits =
    (props.room.rateIncludes && props.room.rateIncludes.split('. ')) || [];

  // if(!rateIncludesSplits){
  //   rateIncludesSplits = [
  //     "Point 1",
  //     "Point 2",
  //     "Point 3",
  //     "Point 4",
  //     "Point 5",
  //   ]
  // }

  return (
    <div className="new-room-amenities">
      <div className="row">
        <div className="col-xs-12 col-md-12 new-amenities-inner spacer-half">
          <ul className="clearfix no-padding">
            {/*props.room.freeBreakfast ?
            <li>
              <span className="vehoicon-restaurant_menu"/>
              <p>Free Breakfast</p>
            </li>
            : <li className="dim">
              <span className="vehoicon-restaurant_menu"/>
              <p><span className="strikethrough"><span>Free Breakfast</span></span></p>
            </li>*/}

            <li>
              <span className={'vehoicon-restaurant_menu'} />
              <p>{mealType}</p>
            </li>

            {props.room.refundable ? (
              <li>
                <span className="vehoicon-refundable color-primary-dark" />
                <p>Refundable</p>
              </li>
            ) : (
              <li>
                <span className="vehoicon-non-refundable color-accent-7" />
                <p>Non Refundable</p>
              </li>
            )}

            {props.room.availCode === 'RQ' ? (
              <li className={'color-accent-7'}>
                <span className={'vehoicon-ticket'} />
                <p>On Request*</p>
              </li>
            ) : null}
          </ul>
        </div>
      </div>

      {props.room.roomOffer && props.room.roomOffer.freeNights ? (
        <div className={'row'}>
          <div className={'col-xs-12'}>
            <span className={'small block hotel-room-offers-wrapper'}>
              <span className={'vehoicon-bell bolder icon'} />
              <span>{props.room.roomOffer.freeNights.description}!</span>
            </span>
          </div>
        </div>
      ) : null}

      {rateIncludesSplits && rateIncludesSplits.length ? (
        <div className={'row'}>
          <div className={'col-xs-12'}>
            <div className={'hotel-room-inclusions-wrapper vmargin-small'}>
              <span className={'color-accent-8 block fine-text semi-bold'}>
                INCLUSIONS
              </span>
              <ul className={'fine-text fade list-unstyled vmargin-small mb-0'}>
                {rateIncludesSplits.map((item, inx) => (
                  <li
                    key={
                      'room_inclusions_' + props.room.roomIdenfier + '_' + inx
                    }
                  >
                    {item.trim()}.
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default withRouter(HotelRoomRow);
