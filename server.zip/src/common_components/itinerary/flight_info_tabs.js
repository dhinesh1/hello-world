import React, { Component } from 'react';
import { Collapse } from 'react-bootstrap';

export default class FlightInfoTabs extends Component {
  constructor(props) {
    super(props);
    this.state = { open: true };
    this.renderBaggageInfo = this.renderBaggageInfo.bind(this);
  }

  renderBaggageInfo(trip, excessBaggageInfo) {
    let extraBaggageText = '';
    let weight = 0;
    if (excessBaggageInfo && excessBaggageInfo.excessBaggages) {
      let excessBaggage = excessBaggageInfo.excessBaggages;

      excessBaggage.map(i => {
        let input = trip.key;
        let splits = input.split('_');
        let finalkey = splits.join('-');

        if (i.originDestinationKey === finalkey) {
          i.baggageOptions.map(j => {
            if (j.selected === true && j.selectedQuantity > 0) {
              weight += j.weight * j.selectedQuantity;
              extraBaggageText = (
                <p className=" medium-bold ">
                  Extra baggage {weight} KG has been added.
                  {/*
                    excessBaggageInfo.cost ?
                      <span>for <span className="WebRupee">Rs.</span>{excessBaggageInfo.cost}</span>: null */}
                </p>
              );
            }
          });
        }
      });
    }

    return trip.routes.map(route => {
      return (
        <div className="row" key={Math.random()}>
          <div className="col-xs-12 col-md-6 spacer">
            <span className="meta-text bold block no-margin">
              {route.departureCity} - {route.arrivalCity}
            </span>
            <span className="meta-text">{route.carrierName}</span>
          </div>
          <div className="col-xs-12 col-md-6 spacer">
            <div className="table meta-text">
              <div className="table-row">
                <div className="table-cell">Check in</div>
                <div className="table-cell text-right">
                  {route.freeCheckInBaggage === ''
                    ? weight
                    : route.freeCheckInBaggage}
                  /person
                </div>
              </div>
              <div className="table-row">
                <div className="table-cell">Cabin</div>
                <div className="table-cell text-right">7 Kg/person</div>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-12">{extraBaggageText}</div>
        </div>
      );
    });
  }

  render() {
    let { trip, excessBaggageInfo } = this.props;

    return (
      <div className="more-info clearfix" key={Math.random()}>
        <div className="pyt-nav-tab-shell">
          <div className="row">
            <div className="col-xs-12">
              <ul className="clearfix list-unstyled tab-links flight-tab-links">
                <li role="presentation">
                  <a
                    href="javascript:void(0)"
                    onClick={() => this.setState({ open: !this.state.open })}
                  >
                    Baggage Info
                  </a>
                </li>
                {/* <li role="presentation"><a href="#">Cancellation</a></li> */}
              </ul>
            </div>
          </div>
        </div>
        <Collapse in={this.state.open}>
          <div className="info-container">
            {this.renderBaggageInfo(trip, excessBaggageInfo)}
          </div>
        </Collapse>
      </div>
    );
  }
}
