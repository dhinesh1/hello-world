import React from 'react';
import { AppConfig } from '../app-config';

const HappinessRating = ({ score }) => {
  let displayName = score.scoreType.replace(/_/g, ' ');

  displayName = displayName[0] + displayName.substring(1).toLowerCase();

  let percentage = score.score * 10;

  let review_color_class = 'review-feedback-great';
  let progressbarColor = '';
  if (percentage <= 60) {
    review_color_class = 'review-feedback-good';
    progressbarColor = 'good';
  }
  if (percentage > 90) {
    review_color_class = 'review-feedback-excellent';
    progressbarColor = 'excellent';
  }

  let icon;
  switch (score.scoreType) {
    case 'ROOM':
      icon = AppConfig.imgix_base + '/images/icons/hotel-reviews/room.svg';
      break;
    case 'SERVICE_QUALITY':
      icon = AppConfig.imgix_base + '/images/icons/hotel-reviews/service.svg';
      break;
    case 'LOCATION':
      icon = AppConfig.imgix_base + '/images/icons/hotel-reviews/location.svg';
      break;
    case 'FOOD':
      icon = AppConfig.imgix_base + '/images/icons/hotel-reviews/food.svg';
      break;
    case 'VALUE':
      icon =
        AppConfig.imgix_base + '/images/icons/hotel-reviews/value-rupee.png';
      break;
    default:
      icon = AppConfig.imgix_base + '/images/icons/hotel-reviews/service.svg';
      break;
  }

  return (
    <div className="col-xs-12 col-md-6 review-first">
      <div className="review-inner-left">
        <div className="review-img-left">
          <img src={icon} alt={score.scoreType} />
        </div>
        <div className="review-right">
          <span className="review-right-title">{displayName}</span>
          <div className="review-right-inner">
            <span className={review_color_class}>{score.scoreLabel}!</span>
            <span className="review-right-score">
              {(Math.round(percentage) / 10).toFixed(1)}
            </span>
          </div>

          <div className="progress">
            <div
              className={`progress-bar ${progressbarColor}`}
              style={{ width: `${percentage}%` }}
              role="progressbar"
              aria-valuenow="70"
              aria-valuemin="0"
              aria-valuemax="100"
            >
              <span className="sr-only">{`${percentage}% Complete`}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HappinessRating;
