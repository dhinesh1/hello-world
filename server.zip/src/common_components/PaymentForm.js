import React from 'react';
import PropTypes from 'prop-types';
/**
 * Payment params will have key value pairs that is used to generate payment form.
 * If value is an object(another set of key:value pair) then update the input key accordingly
 * key - input name/id
 * value - input value
 * @param {paymentParams} param0 object
 */
const PaymentForm = ({ paymentParams={} }) => {
  let _rows = [];
  let url = '';
  
  if(Object.keys(paymentParams).length) {
    url = paymentParams.url;
    delete paymentParams.url; // we can delete `url` since we dont need to pass form_post_url in the form data

    /**
     * sample input: paymentParams
     *  `{
     *    amount: 23000,
     *    name: "Vacation Title",
     *    description: "Vacation Details"
     *    prefil: {
     *      email: "test@domain.com"
     *      mobile: "9000000000"
     *    }
     *  }`
     *  ------
     *  Loop: check each keys
     *  Step 1: check if the value is of type 'object' or not
     *  Step 2:   
     *    IF object(prefil is an object): Run another loop to create inputs
     *      input names should have actual object key and current Object Key - `prefil[email]`, `prefil[mobile]`
     *  Step 3:   
     *    ELSE
     *      create inputs directly from key-value pairs - `name`, `amount`, `description`
     *  Sample Input 1: <input key="name" type="hidden" name="name" value="Vacation Title" />
     *  Sample Input 2: <input key="prefil[email]" type="hidden" name="prefil[email]" value="test@domain.com" />
     */
    for (const key in paymentParams) {
      if (paymentParams.hasOwnProperty(key)) {
        if(typeof paymentParams[key] === 'object') {
          const innerObject = paymentParams[key];
          for (const innerKey in innerObject) {
            if (innerObject.hasOwnProperty(innerKey)) {
              _rows.push(
                <input
                  key={`${key}_${innerKey}`}
                  type="hidden"
                  name={`${key}[${innerKey}]`}
                  id={`${key}_${innerKey}`}
                  value={innerObject[innerKey]}
                />
              );
            }
          }
        } else {
          _rows.push(
            <input
              key={key}
              type="hidden"
              name={key}
              id={key}
              value={paymentParams[key] || ''}
            />
          );
        }
      }
    }
  }

  return (
    <form
      id="paymentForm"
      action={url}
      method="post"
      name="paymentForm"
      className="hidden"
    >
      {_rows}
      <input type="submit" value="Submit" />
    </form>
  );
}

PaymentForm.propTypes = {
  paymentParams: PropTypes.object.isRequired
}

export default PaymentForm;