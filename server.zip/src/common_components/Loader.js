import React from 'react';
import { CircleLoader } from '../helpers/loaderHelper';

export default function Loader(props) {
  if (props.pastDelay || props.showLoading) {
    return (
      <div className="loader-wrapper bg-white">
        <CircleLoader />
      </div>
    );
  } else {
    return null;
  }
}
