import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import _ from 'lodash';
export default function PackageFilterPills({
  region,
  theme,
  selectedDurations,
  selectedBudgets,
  selectedStarRatings,
  selectedDepcity,
  removeRegion,
  removeTheme,
  removeDuration,
  removeBudget,
  removeDepcity,
  removeHotelStarRating
}) {
  let selectedDurationsArray = _.isArray(selectedDurations)
    ? selectedDurations
    : [selectedDurations];
  let selectedBudgetsArray = _.isArray(selectedBudgets)
    ? selectedBudgets
    : [selectedBudgets];
  let selectedStarRatingsArray = _.isArray(selectedStarRatings)
    ? selectedStarRatings
    : [selectedStarRatings];
  if (
    region ||
    theme ||
    selectedDurations ||
    selectedBudgets ||
    selectedStarRatings ||
    selectedDepcity
  ) {
    return (
      <section className="row filter-pills hidden-xs hidden-sm">
        <ul className="col-md-12 list-unstyled" id="active-filters-container">
          {region && region !== 'all' ? (
            <li>
              {_.startCase(_.replace(region, '-', ' '))}
              <i
                className="vehoicon-close uncheck-active-filter"
                onClick={() => removeRegion(region)}
              />
            </li>
          ) : null}
          {theme && theme !== 'packages' ? (
            <li>
              {_.startCase(_.replace(theme, '-packages', ''))}
              <i
                className="vehoicon-close uncheck-active-filter"
                onClick={() => removeTheme(theme)}
              />
            </li>
          ) : null}
          {selectedDurations && selectedDurationsArray.length > 0
            ? renderDurationPills(selectedDurationsArray, removeDuration)
            : null}
          {selectedBudgets && selectedBudgetsArray.length > 0
            ? renderBudgetPills(selectedBudgetsArray, removeBudget)
            : null}
          {selectedDepcity
            ? renderDepcityPill(selectedDepcity, removeDepcity)
            : null}
          {selectedStarRatings && selectedStarRatingsArray.length > 0
            ? renderHotelStarRatingPills(
                selectedStarRatingsArray,
                removeHotelStarRating
              )
            : null}
          <li>
            <a className="caps-text-small" href="/packages">
              CLEAR ALL
            </a>
          </li>
        </ul>
      </section>
    );
  } else {
    return null;
  }
}

function renderDurationPills(duration, removeDuration) {
  let textMap = {
    '4_8': '4-8 days',
    '9_12': '9-12 days',
    '13_16': '13-16 days',
    '16_99': '16 days and above'
  };
  return duration.map(d => {
    return (
      <li>
        {textMap[d]}
        <i
          className="vehoicon-close uncheck-active-filter"
          onClick={() => removeDuration(d)}
        />
      </li>
    );
  });
}

function renderBudgetPills(budgets, removeBudget) {
  let textMap = {
    '0_50000': 'Below ₹50,000',
    '50000_75000': '₹50,000 - ₹75,000',
    '75000_100000': '₹70,000 - ₹1,00,000',
    '100000_150000': '₹10,0000 - ₹1,50,000',
    '150000_200000': '₹1,50,000 - ₹2,00,000',
    '200000_9999999': 'Above ₹2,00,000'
  };
  return budgets.map(b => {
    return (
      <li>
        {textMap[b]}
        <i
          onClick={() => removeBudget(b)}
          className="vehoicon-close uncheck-active-filter"
        />
      </li>
    );
  });
}

function renderDepcityPill(depcity, removeDepcity) {
  let textMap = {
    DEL: 'Delhi',
    BOM: 'Mumbai',
    MAA: 'Chennai',
    CCU: 'Kolkata',
    BLR: 'Bengalore',
    HYD: 'Hyderabad',
    COK: 'Kochi',
    TRZ: 'Trichy',
    NAG: 'Nagpur',
    $$$: 'Outside India'
  };
  return (
    <li>
      {textMap[depcity]}
      <i
        className="vehoicon-close uncheck-active-filter"
        onClick={removeDepcity}
      />
    </li>
  );
}

function renderHotelStarRatingPills(hotelStarRatings, removeHotelStarRating) {
  let textMap = {
    '3': '3 Star',
    '4': '4 Star',
    '5': '5 Star'
  };
  return hotelStarRatings.map(r => {
    return (
      <li>
        {textMap[r]}
        <i
          className="vehoicon-close uncheck-active-filter"
          onClick={() => removeHotelStarRating(r)}
        />
      </li>
    );
  });
}
