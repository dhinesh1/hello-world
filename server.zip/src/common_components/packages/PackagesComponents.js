import React from 'react';
import Collapsible from 'react-collapsible';
import { isFaqMobile, getImgIXUrl } from '../../helpers/utilsHelper';
import classNames from 'classnames';

export function PackagesTrustBlock({
  trustModuleClass,
  history,
  openCBR,
  toggleTrustModuleStatus,
  newpackages, isPaid
}) {
  if (history) {
    if (trustModuleClass && !isPaid) {
      return (
        <section
          className={classNames('trust-footer', {
            'xs-slide-up': trustModuleClass
          })}
        >
          <div className="container lg-container">
            <div className="xs-slideup-hdr hidden-md hidden-lg">
              <span className="medium-heading bold">Why Pickyourtrail?</span>
              <button
                type="button"
                className="btn btn-link-grey close-trust-footer"
                onClick={toggleTrustModuleStatus}
              >
                <i className="vehoicon-close" />
              </button>
            </div>
            <div className="row trust-footer-content">
              <div className="col-md-3 text-center">
                {newpackages &&
                newpackages.campaignDetails &&
                newpackages.campaignDetails.logoUrl ? (
                  <img
                    src={getImgIXUrl(newpackages.campaignDetails.logoUrl)}
                    alt="Tourism"
                  />
                ) : (
                  <img
                    src={
                      'https://pyt-images.imgix.net/images/campaign_paid/partner.png'
                    }
                    alt="Tourism"
                  />
                )}
                <strong className="small-heading">
                  Certified Travel Consultants
                </strong>
                <p className="meta-text light">
                  Tied up with Australia’s travel consultants to provide a
                  hassle-free experience during your Oz travel
                </p>
              </div>
              <div className="col-md-3 text-center">
                <i className="ico_img ico_2" />
                <strong className="small-heading bold">
                  Customized Packages
                </strong>
                <p className="meta-text light">
                  Customize your trip itinerary suiting your best needs with the
                  help of our consultants
                </p>
              </div>
              <div className="col-md-3 text-center">
                <i className="ico_img ico_3" />
                <strong className="small-heading">Best Price Guaranteed</strong>
                <p className="meta-text light">
                  Hand-picked itineraries to let you travel around the world
                  with reasonable deals
                </p>
              </div>
              <div className="col-md-3 text-center">
                <i className="ico_img ico_1" />
                <strong className="small-heading">On Trip Support</strong>
                <p className="meta-text light">
                  Backed by our travel consultants during vacations to ensure a
                  memorable travel
                </p>
              </div>
            </div>
            <div className="xs-slideup-ftr no-bg hidden-md hidden-lg">
              <button
                type="button"
                className="btn btn-primary btn-block"
                onClick={openCBR}
              >
                Need help? Talk to our travel consultants
              </button>
            </div>
          </div>
        </section>
      );
    } else {
      return (
        <section className="trust-footer">
          <div className="container lg-container">
            <div className="row trust-footer-content">
              {isPaid ? (
                <div className="col-md-3 text-center">
                  {newpackages &&
                  newpackages.campaignDetails &&
                  newpackages.campaignDetails.logoUrl ? (
                    <img
                      src={getImgIXUrl(newpackages.campaignDetails.logoUrl)}
                      alt="Tourism"
                    />
                  ) : (
                    <img
                      src="https://pyt-images.imgix.net/images/campaign_paid/partner.png"
                      alt="Tourism"
                    />
                  )}
                  <strong className="small-heading">
                    Certified Travel Consultants
                  </strong>
                  <p className="meta-text light">
                    Tied up with tourism boards around the world to provide a
                    hassle-free experience during your vacation
                  </p>
                </div>
              ) : (
                <div className="col-md-3 text-center">
                  <i className="ico_img ico_4" />
                  <strong className="small-heading">Certified Partners</strong>
                  <p className="meta-text light">
                    Tied up with all the top partners and tourism boards to
                    provide a hassle-free experience during your vacation
                  </p>
                </div>
              )}
              <div className="col-md-3 text-center">
                <i className="ico_img ico_2" />
                <strong className="small-heading bold">
                  Customized Packages
                </strong>
                <p className="meta-text light">
                  Customize your trip itinerary suiting your best needs with the
                  help of our consultants
                </p>
              </div>
              <div className="col-md-3 text-center">
                <i className="ico_img ico_3" />
                <strong className="small-heading">Best Price Guaranteed</strong>
                <p className="meta-text light">
                  Hand-picked itineraries to let you travel around the world
                  with reasonable deals
                </p>
              </div>
              <div className="col-md-3 text-center">
                <i className="ico_img ico_1" />
                <strong className="small-heading">On-Trip Support</strong>
                <p className="meta-text light">
                  Backed by our travel consultants during vacations to ensure a
                  memorable travel
                </p>
              </div>
            </div>
          </div>
        </section>
      );
    }
  } else {
    return (
      <section className="clearfix meta-list sm-clear-gutters">
        <div className="row row-eq-hgt">
          <div className="col-xs-12 col-sm-4">
            <div className="meta-col">
              <i className="icon-img ico-1" />
              <span>
                <h2 className="small-heading bold">Personalised vacations</h2>
                <p className="meta-text color-grey">
                  Everything on your itinerary is customizable. No more packaged
                  tours!
                </p>
              </span>
            </div>
          </div>
          <div className="col-xs-12 col-sm-4">
            <div className="meta-col">
              <i className="icon-img ico-2" />
              <span>
                <h2 className="small-heading bold">Live travel concierge</h2>
                <p className="meta-text color-grey">
                  Our set of travel consultants will shadow travel with you to
                  ensure a seamless vacation.
                </p>
              </span>
            </div>
          </div>
          <div className="col-xs-12 col-sm-4">
            <div className="meta-col">
              <i className="icon-img ico-3" />
              <span>
                <h2 className="small-heading bold">Unpackaged Itineraries</h2>
                <p className="meta-text color-grey">
                  Unpackage your spends - choose where you want to spend between
                  flights, hotels and activities.
                </p>
              </span>
            </div>
          </div>
        </div>
      </section>
    );
  }
}

export class PackagesFAQBlock extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      expanded: ''
    };

    this.onTriggerClick = this.onTriggerClick.bind(this);
  }

  onTriggerClick(index) {
    this.setState({ expanded: index === this.state.expanded ? '' : index });
  }

  render() {
    let { faqDetails, history } = this.props;

    if (
      history &&
      (history.location.pathname.indexOf('vacations') > 0 ||
        history.location.pathname.indexOf('packages') > 0)
    ) {
      return (
        <div className="col-md-12">
          <section className={'clearfix fw faq'}>
            <h2 className="medium-heading bold">Frequently asked questions</h2>
            <div className={'panel-group'} id="faq">
              <section className="panel panel-default">
                {faqDetails &&
                  faqDetails.map((faq, index) => {
                    return (
                      <Collapsible
                        key={'panel_inx_' + index}
                        // classParentString={'panel-heading'}
                        className={'panel-default tracker-faq'}
                        open={this.state.expanded === index}
                        triggerTagName={'div'}
                        triggerClassName={'panel-heading accordion-toggle'}
                        triggerOpenedClassName={
                          'panel-heading accordion-toggle'
                        }
                        contentOuterClassName={'panel-collapse'}
                        contentInnerClassName={'panel-body'}
                        handleTriggerClick={e => this.onTriggerClick(index)}
                        trigger={
                          <span className="panel-title">{faq.question}</span>
                        }
                      >
                        {faq.answer}
                      </Collapsible>
                    );
                  })}
              </section>
            </div>
          </section>
        </div>
      );
    } else {
      return (
        <section className={'clearfix sm-clear-gutters faq mbottom-large'}>
          <h2 className="medium-heading bold">Frequently asked questions</h2>
          <div className={'row'}>
            <div className={'col-md-12'}>
              <div className={'panel-group'} id={'faq'}>
                {faqDetails.map((faq, index) => {
                  return (
                    <Collapsible
                      key={'panel_inx_' + index}
                      classParentString={'panel'}
                      className={'panel-default'}
                      open={this.state.expanded === index}
                      triggerTagName={'div'}
                      triggerClassName={'panel-heading accordion-toggle'}
                      triggerOpenedClassName={'panel-heading accordion-toggle'}
                      contentOuterClassName={'panel-collapse'}
                      contentInnerClassName={'panel-body'}
                      handleTriggerClick={e => this.onTriggerClick(index)}
                      trigger={
                        <span className="panel-title">{faq.question}</span>
                      }
                    >
                      {faq.answer}
                    </Collapsible>
                  );
                })}
              </div>
            </div>
          </div>
        </section>
      );
    }
  }
}
