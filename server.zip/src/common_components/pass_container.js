import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

const PassContainter = ({
  pass,
  isLast,
  costedItinerary,
  splitPricing,
  hideDetails,
  handleDetailsClick
}) => {
  const renderSingleActivityInclusion = activity => {
    let ac = costedItinerary.activityCostings.activityCostingById[activity];
    let a = costedItinerary.activityById[ac.activityId];

    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-8 spacer">
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{ac.mon}</span>
              <span className="date">{ac.day}</span>
            </div>
            <h5 className="no-margin">{a.title}</h5>
            <span className="small bold dim">
              {_.startCase(a.selectedTourGrade.durationType.toLowerCase())} day
              activity in {ac.cityText}
            </span>
          </div>
        </div>
        {hideDetails ? null : (
          <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
            <a
              href="javascript:void(0)"
              className="btn btn-sm btn-link dim normal"
              onClick={e => handleDetailsClick(a, 'VIEW', e)}
            >
              View Details
            </a>
          </div>
        )}
      </div>
    );
  };

  const renderActivityInclusions = activities => {
    return activities.map(activity => {
      return renderSingleActivityInclusion(activity.activityKey);
    });
  };

  const renderSingleTransferInclusion = transferId => {
    let t = costedItinerary.transferCostings.transferCostingById[transferId];

    let t_type = null;
    if (t.type) {
      t_type = _.startCase(t.type.toLowerCase());
    }
    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-8 spacer">
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{t.mon}</span>
              <span className="date">{t.day}</span>
            </div>
            <h5 className="no-margin">{t.text}</h5>
            <span className="small bold dim">{t_type} transfer</span>
          </div>
        </div>
        <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
      </div>
    );
  };

  const renderTransferInclusions = transfers => {
    return transfers.map(transfer => {
      return renderSingleTransferInclusion(transfer.transferKey);
    });
  };

  const renderSingleTrainInclusion = trainId => {
    let tr = costedItinerary.trainCostings.trainCostingById[trainId];

    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-8 spacer">
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{tr.mon}</span>
              <span className="date">{tr.day}</span>
            </div>
            <h5 className="no-margin">Train - {tr.text}</h5>
            <span className="small bold dim">Shared transfer</span>
          </div>
        </div>
        <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
      </div>
    );
  };

  const renderTrainInclusions = trains => {
    return trains.map(train => {
      return renderSingleTrainInclusion(train.transferKey);
    });
  };

  const renderSingleFerryInclusion = ferry => {
    let f = costedItinerary.ferryCostings.ferryCostingById[ferry];

    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-8 spacer">
          <div className="costed-item-head">
            <div className="date-costed">
              <span className="month">{f.mon}</span>
              <span className="date">{f.day}</span>
            </div>
            <h5>Ferry - {f.text}</h5>
            <span className="small bold dim">Shared transfer</span>
          </div>
        </div>
        <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
      </div>
    );
  };

  const renderFerryInclusions = ferries => {
    return ferries.map(ferry => {
      return renderSingleFerryInclusion(ferry.transferKey);
    });
  };

  return (
    <article className="row-costed-item row">
      <div className="col-xs-9 col-sm-9 col-md-10">
        <h4 className="small-heading dim">{pass.name}</h4>
        <p className="meta-text dim">{pass.description}</p>

        {pass.inclusions.activities && splitPricing
          ? renderActivityInclusions(pass.inclusions.activities)
          : null}
        {pass.inclusions.transfers && splitPricing
          ? renderTransferInclusions(pass.inclusions.transfers)
          : null}
        {pass.inclusions.ferries && splitPricing
          ? renderFerryInclusions(pass.inclusions.ferries)
          : null}
        {pass.inclusions.trains && splitPricing
          ? renderTrainInclusions(pass.inclusions.trains)
          : null}
        {pass.inclusions.otherInclusions ? (
          <div>
            <h5>Other inclusions</h5>
            {pass.inclusions.otherInclusions.map((other, i) => {
              return (
                <div key={i} className="row">
                  <div className="col-xs-12 col-sm-12 col-md-10 spacer-bottom-half">
                    <div className="">
                      <p className="mbottom-small small dim">{other}</p>
                    </div>
                  </div>
                  <div className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
                </div>
              );
            })}
          </div>
        ) : null}
      </div>

      <div className="col-xs-3 col-sm-3 col-md-2">
        {pass.totalCost || pass.savings ? (
          <div className="action price-info-center">
            {/*<span type="pill" className="pill pill-lg success">{pass.savingsPercentage}% Savings</span>*/}
            <span
              className="price block v-spaced"
              style={{ marginBottom: '10px' }}
            >
              <span className="block">
                <span className="WebRupee">Rs.</span>
                {pass.totalCost}
                {/*<span className="dim small normal block">You save : {' '} &nbsp; <span className="WebRupee">Rs.</span> {pass.savings}</span>*/}
              </span>
            </span>
            {
              <div className="pointing-box top box-success">
                <span className="block">{pass.savingsPercentage}% Savings</span>
                <span className="fade normal fine-text block half-spaced-top">
                  Saved: &nbsp;<span className="WebRupee">Rs.</span>
                  {pass.savings}
                </span>
              </div>
            }
          </div>
        ) : null}
      </div>

      {pass.disclaimer ? (
        <div className="col-xs-12 spacer-half">
          <p className="no-margin mini">
            <em>{pass.disclaimer}</em>
          </p>
        </div>
      ) : null}

      {!isLast ? <hr className="tear" /> : null}
    </article>
  );
};

PassContainter.propTypes = {
  pass: PropTypes.object.isRequired,
  isLast: PropTypes.bool.isRequired,
  costedItinerary: PropTypes.object.isRequired,
  splitPricing: PropTypes.bool.isRequired,
  hideDetails: PropTypes.bool.isRequired,
  handleDetailsClick: PropTypes.func.isRequired
};

export default PassContainter;
