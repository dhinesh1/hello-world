import React, { Component } from 'react';

export default class PriceDiff extends Component {
  render() {
    let diff = this.props.diff;

    return (
      <span className={this.props.classNames}>
        {diff.diffChangeType === 'PRICEINCREASE' ? (
          <span className="vehoicon-arrow-up color-danger" />
        ) : null}
        {diff.diffChangeType === 'PRICEDECREASE' ? (
          <span className="vehoicon-arrow-down color-success" />
        ) : null}
        &nbsp; <span className="WebRupee">Rs.</span> {diff.diffCost}
      </span>
    );
  }
}
