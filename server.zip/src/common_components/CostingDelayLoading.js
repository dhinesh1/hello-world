import React, { Component } from 'react';
import _ from 'lodash';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { checkCostingStatus, getItinerary } from '../actions/actions_app';

import {
  onceModalOpened,
  onceModalClosed,
  clearAllTimeouts,
  checkIndexOf
} from '../helpers/utilsHelper';
import { AppConfig } from '../app-config';
import moment from 'moment';
import { getImgIXUrl } from '../helpers/utilsHelper';
import { itineraryModalsRouteHelper, routingPageType } from '../helpers/routesHelper';
const CDN_MISC_URL = AppConfig.imgix_base;

class CostingDelayScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      isLoading: false,
      current_testimonial: {},
      testimonials: [],
      used_testimonial: [],
      config: [
        {
          interval: 500,
          target: 'video',
          title: 'Hold on...',
          message:
            'Connecting with our booking partners for best rates on your travel dates. This may take a while. Please be patient!'
        },
        { interval: 4000, target: 'get-testimonial' },
        { interval: 8000, target: 'show-testimonial' },
        {
          interval: 14000,
          target: 'message',
          image: 'flexi-pay.png',
          title: 'Flexible payments',
          message:
            'Pay an advance and block your trip. Airline and hotel prices could change significantly if you delay your bookings!'
        },
        {
          interval: 18000,
          target: 'message',
          image: 'concierge_v2.png',
          title: 'Free concierge included!',
          message:
            'You get a travel co-ordinator to assist you during your trip. Get help with real time tips, change requests and more...'
        },
        { interval: 20000, target: 'get-testimonial' },
        { interval: 22000, target: 'show-testimonial' },
        {
          interval: 27000,
          target: 'message',
          image: 'change-options.png',
          title: 'Tune in to find the best...',
          message:
            'We recommend and cost for the best options. But feel free to optimise further. Flights, rooms, transfers - everything is customisable!'
        },
        {
          interval: 31000,
          target: 'message',
          image: 'flight-search.png',
          title: 'Checking flights...',
          message:
            'Finding the best routes and prices from 100+ airline services for your travel dates.'
        },
        {
          interval: 35000,
          target: 'message',
          image: 'hotel-search_v2.png',
          title: 'Scanning the best hotels...',
          message:
            'Finding the best hotels now. We will recommend those which are conveniently located to the things you plan to do.'
        }
      ],
      current_delay_content: {}
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.randomNo = this.randomNo.bind(this);
    this.getTestimonial = this.getTestimonial.bind(this);

    this.manageDelayGraphics = this.manageDelayGraphics.bind(this);
  }

  componentDidMount() {
    this.openModal();

    let { actions, match } = this.props;
    actions.checkCostingStatus(match.params.itineraryId);
  }

  componentWillReceiveProps(nextProps) {
    let { costingStatus, history, match, location } = nextProps;

    if (costingStatus) {
      const {itineraryId, searchRegion} = match.params;

      switch (costingStatus.data) {
        case 'COMPLETE':
          clearAllTimeouts();
          onceModalClosed();

          history.replace(
            itineraryModalsRouteHelper({
              itineraryId,
              regionCode: searchRegion ? searchRegion : 'region',
              parentPage: routingPageType.inclusion
            })
          )
          break;
        case 'NOT_COSTED':
        case 'INTL_FLIGHTS_INPROGRESS':
        case 'REMAINING_COST_INPROGRESS':
        case 'PACKAGE_COST_INPROGRESS':
          setTimeout(() => {
            this.props.actions.checkCostingStatus(itineraryId);
          }, 5000);
          break;
        default:
          this.props.actions.checkCostingStatus(itineraryId);
          break;
      }
    }
  }

  getTestimonial() {
    let { delayTestimonials } = this.props;
    let { used_testimonial } = this.state;

    let target_testimonials = null;
    if (
      delayTestimonials &&
      delayTestimonials.destinationTestimonials &&
      delayTestimonials.destinationTestimonials.length > 0 &&
      delayTestimonials.destinationTestimonials.length > used_testimonial.length
    ) {
      target_testimonials = delayTestimonials.destinationTestimonials;
    } else {
      target_testimonials = delayTestimonials.otherTestimonials;
    }

    if (target_testimonials && target_testimonials.length) {
      let random_testi = this.getRandom(target_testimonials, used_testimonial);
      if (random_testi) {
        if (random_testi.testimonialId) {
          used_testimonial.push(random_testi.testimonialId);
        }

        this.setState({
          current_testimonial: random_testi,
          used_testimonial: used_testimonial
        });
      }
    }
  }

  getRandom(target, used_testimonial) {
    let random = _.sample(target);
    if (!random) return random;

    if (_.indexOf(used_testimonial, random.testimonialId) !== -1) {
      return this.getRandom(target, used_testimonial);
    } else {
      return random;
    }
  }

  randomNo() {
    let testimonials_length = this.props.testimonials.length;
    let { used_testimonial } = this.state;

    if (testimonials_length > 1) {
      let rNo = Math.floor(Math.random() * testimonials_length);

      if (used_testimonial.length === 0) {
        return rNo;
      } else {
        let new_idd = this.props.testimonials[rNo].testimonialId;

        if (_.findIndex(used_testimonial, new_idd) !== -1) {
          this.randomNo();
        } else {
          return rNo;
        }
      }
    } else {
      return testimonials_length;
    }
  }

  closeModal() {
    onceModalClosed();

    this.setState({ showModal: false });
  }

  manageDelayGraphics() {
    let { config } = this.state;

    config.map(item => {
      setTimeout(() => {
        if (item.target === 'get-testimonial') {
          this.getTestimonial();
        } else {
          this.setState({
            current_delay_content: item
          });
        }
      }, item.interval);
    });
  }

  openModal() {
    if (!this.state.showModal) {
      this.setState({ showModal: true }, () => {
        this.manageDelayGraphics();
      });

      onceModalOpened();
    }
  }

  onExit() {
    this.setState({
      isLoading: false,
      otp_value: ''
    });
  }

  render() {
    let { current_testimonial, current_delay_content } = this.state;

    return (
      <div className={'modal fade ' + (this.state.showModal ? 'in' : '')}>
        <div className="container delay-screen-container">
          <div className="row">
            <div className="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3">
              <div className="sticky-top alert-notification info show-notification no-margin text-center">
                <span className="bold">Best price guarantee</span> — Find better
                prices elsewhere, we will give you a cash back of Rs
                2,000!&nbsp;&nbsp;<i className="em em-tada" />
              </div>
              <div className="message-holder text-center">
                <div className="delay-graphic-shell">
                  <div className="delay-graphic">
                    {current_delay_content.target === 'video' ? (
                      <video id="bgvid" playsInline muted autoPlay>
                        <source
                          src={`${CDN_MISC_URL}/images/misc/animate.mp4`}
                          type="video/mp4"
                        />
                      </video>
                    ) : null}

                    {current_delay_content.target === 'video' ? (
                      <div className="loop-animation">
                        <div className="clouds" />
                        <div className="plane" />
                      </div>
                    ) : null}

                    {current_delay_content.target === 'show-testimonial' &&
                    current_testimonial ? (
                      <img
                        alt={'img1'}
                        className="testimonial-profile-image current_testimonial"
                        src={getImgIXUrl(current_testimonial.profileImage)}
                      />
                    ) : current_delay_content.target === 'message' ? (
                      <img
                        alt={'img2'}
                        className="flexi-pay"
                        src={`${CDN_MISC_URL}/images/misc/${
                          current_delay_content.image
                        }`}
                      />
                    ) : null}
                  </div>
                </div>

                {current_delay_content.target === 'video' ||
                current_delay_content.target === 'message' ? (
                  <div className="messages hold-on">
                    <h3 className="no-margin-top">
                      {current_delay_content.title}
                    </h3>
                    <p className="big block dim">
                      {current_delay_content.message}
                    </p>
                  </div>
                ) : null}

                {current_delay_content.target === 'show-testimonial' &&
                current_testimonial ? (
                  <div className="messages dialogue">
                    <p className="base">{current_testimonial.shortReview}</p>
                    <div className="col-xs-12 col-sm-8 fade no-padding">
                      <span className="h5">{`${current_testimonial.fName} ${
                        current_testimonial.lName
                      }`}</span>
                      <span className="small clearfix">
                        {current_testimonial.region}, {current_testimonial.type}
                      </span>
                    </div>
                    <div className="rating-wrap col-xs-12 col-sm-4 no-padding fade">
                      <span className="vehoicon-star active color-accent-1" />
                      <span className="vehoicon-star active color-accent-1" />
                      <span className="vehoicon-star active color-accent-1" />
                      <span className="vehoicon-star active color-accent-1" />
                      <span className="vehoicon-star active color-accent-1" />
                      {current_testimonial.dateOfDeparture !== 0 ? (
                        <span className="small clearfix">{`${moment(
                          current_testimonial.dateOfDeparture
                        ).format('MMM YYYY')}`}</span>
                      ) : null}
                    </div>
                  </div>
                ) : null}

                <div className="messages hide">
                  <h3 className="no-margin-top">Best price guarantee!</h3>
                  <p className="big block dim">
                    We can ensure you the best rates out there. If you find a
                    cheaper rate for the same itinerary, get a cash back upto{' '}
                    <span className="WebRupee">Rs</span>2,000
                  </p>
                </div>

                {/*<div className="messages alert hide">
                  <h3 className="no-margin-top">Still working...</h3>
                  <p className="big block dim">This is taking longer than usual. We could notify you when the costing is completed.</p>
                  <a className="btn btn-dark" href="javascript:void(0)">No sweat, I'll wait</a>
                  <a className="btn btn-secondary" href="javascript:void(0)">Notify me!</a>
                </div>*/}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details,
      costingStatus: app.costingStatus,
      delayTestimonials: app.delayTestimonials,
      campaignItineraryId: app.itineraryInfo.campaignItineraryId,
      destination: app.pdgSelections.region
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details,
      costingStatus: app.costingStatus,
      delayTestimonials: app.delayTestimonials,
      campaignItineraryId: ''
    };
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      checkCostingStatus: bindActionCreators(checkCostingStatus, dispatch),
      getItinerary: bindActionCreators(getItinerary, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(CostingDelayScreen);
