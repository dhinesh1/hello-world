import React from 'react';

export default function CitySearchError({ type }) {
  if (type === 'COMBO') {
    return (
      <section className="clearfix search-error text-center vmargin-large">
        <p className="mbottom-small">Oops! No more matching combos</p>
        <span>
          Hey, sorry we can't seem to find any matching destination according to
          your search criteria. Please try "All Cities"
        </span>
      </section>
    );
  } else if (type === 'HIDDEN_GEMS') {
    return (
      <section className="clearfix search-error text-center vmargin-large">
        <p className="mbottom-small">
          Oops! No more matching hidden gem cities
        </p>
        <span>
          There are no matching hidden gem cities connected to the ones you
          chose. Please try "All Cities"
        </span>
        {/*<button onClick={switchToAllCitiesTab}  className="btn btn-primary">Continue browsing "All Cities"</button>*/}
      </section>
    );
  } else {
    return (
      <section className="clearfix search-error text-center vmargin-large">
        <p className="mbottom-small">Oops! No more matching cities</p>
        <span>
          There are no matching cities connected to the ones you chose.
        </span>
        {/*<button onClick={switchToAllCitiesTab}  className="btn btn-primary">Continue browsing "All Cities"</button>*/}
      </section>
    );
  }
}
