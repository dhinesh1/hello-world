import React from 'react';
import StarRating from './StarRating';

import { AppConfig } from '../app-config';
import _ from 'lodash';
import SweetAlert from 'sweetalert-react';
import { getImgIXUrl } from '../helpers/utilsHelper';
const icons3Url = AppConfig.images_cdn_icons_url;

export function RatingBadge({ rating }) {
  return (
    <div className="rating-badge">
      <p>
        <span className="rating-per">4.8</span>
        <StarRating
          rating={rating}
          fillEmpty={true}
          parentClass="rating-star"
          parentElement="span"
          insideFigure={false}
        />
        <span className="rating-desc">
          Based on the opinions of 1000+ people on Facebook
        </span>
      </p>
    </div>
  );
}

export function TripAdvisorRating({
  rating,
  wrapperClass,
  logoAsImage,
  fillEmptyCircle
}) {
  let trip_advisor_logo = getImgIXUrl(`${icons3Url}tripadvisor-owl.png`);
  let half_star = (
    <div>
      <span className="vehoicon-half-checked" />
    </div>
  );

  let full_ratings = parseInt(rating, 10);
  let half_star_value = rating % full_ratings;

  let full_stars = _.range(0, full_ratings).map((star, key) => {
    return (
      <div key={'full_star_' + key + Math.random()}>
        <span
          key={'filled_star_' + key}
          className="vehoicon-radio_button_checked"
        />
      </div>
    );
  });

  let empty_stars = null;
  if (fillEmptyCircle) {
    let remaining_stars_count = 5 - Math.ceil(rating);

    if (remaining_stars_count >= 1) {
      empty_stars = _.range(0, remaining_stars_count).map((star, key) => {
        return (
          <div key={'empty_star_' + key + Math.random()}>
            <span
              key={'empty_star_' + key}
              className="vehoicon-radio_button_unchecked"
            />
          </div>
        );
      });
    }
  }

  return (
    <div className={'rating owl ' + (wrapperClass ? wrapperClass : '')}>
      {logoAsImage ? (
        <div className="tripadvisor-logo">
          <img src={trip_advisor_logo} alt={'ta'} />
        </div>
      ) : (
        <div>
          <span className={'vehoicon-tripadvisor'} />
        </div>
      )}
      {full_stars}
      {half_star_value > 0 ? half_star : null}
      {empty_stars}
    </div>
  );
}

export function BreadcrumbNavBar({ itineraryDetails, campaignDetail }) {
  // Removing reading region name from itinerary object as its not required.
  // Added fallback to empty as we are doing some string operartions on the next line.
  let rowRegionName = campaignDetail ? campaignDetail.region : '';
  let regionNameForUrl = _.split(rowRegionName, ' + ').join(' ');

  return (
    <ol
      vocab={'http://schema.org/'}
      typeof={'BreadcrumbList'}
      className="breadcrumb"
    >
      <li property={'itemListElement'} typeof={'ListItem'}>
        <i className="home-icon " />
        <a
          href={`https://pickyourtrail.com/`}
          property={'item'}
          typeof={'WebPage'}
        >
          <span property={'name'}>Home</span>
        </a>
        <meta property={'position'} content={'1'} />
      </li>
      <li property={'itemListElement'} typeof={'ListItem'}>
        <a
          href={`https://pickyourtrail.com/packages`}
          property={'item'}
          typeof={'WebPage'}
        >
          <span property={'name'}>Packages</span>
        </a>
        <meta property={'position'} content={'2'} />
      </li>
      {/* We don't have to add this in breadcrumb if the rowRegionName is empty */
      rowRegionName && rowRegionName.length > 0 ? (
        <li property={'itemListElement'} typeof={'ListItem'}>
          <a
            href={`https://pickyourtrail.com/packages/${_.toLower(
              regionNameForUrl
            ).replace(/ /g, '-')}`}
            property={'item'}
            typeof={'WebPage'}
          >
            <span className="text-capitalize" property={'name'}>
              {rowRegionName}
            </span>
          </a>
          <meta property={'position'} content={'3'} />
        </li>
      ) : null}
      <li>
        <span>{itineraryDetails.itinerary.specialTitle}</span>
      </li>
    </ol>
  );
}

export function UnAuthAlert({ show, title, message, callback }) {
  return (
    <SweetAlert
      show={show}
      title={title ? title : 'Oops!!!'}
      text={
        message
          ? message
          : `You don't have permission to change other users itinerary`
      }
      onConfirm={callback}
      animation="pop"
      confirmButtonText="Okay! Go to Homepage"
    />
  );
}
