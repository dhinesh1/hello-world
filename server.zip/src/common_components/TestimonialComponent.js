import React, { Component } from 'react';
import Slider from 'react-slick';
import { AppConfig } from '../app-config.js';
import { getImgIXUrl } from '../helpers/utilsHelper';
const { images_cdn_misc_url } = AppConfig;
export default class TestimonialsComponent extends Component {
  render() {
    let { t, assignUser } = this.props;
    var settings = {
      dots: false,
      infinite: true,
      speed: 500,
      slidesToShow: 2,
      slidesToScroll: 1
    };

    let testimonailPhotos = [];

    if (t.testimonialPhotos) {
      testimonailPhotos = t.testimonialPhotos.map((photos, i) => {
        return (
          <div key={i} className="item">
            <img
              src={getImgIXUrl(photos, 'auto=compress&w=205&h=184')}
              alt={2}
            />
          </div>
        );
      });
    }

    return (
      <div className="clearfix sm-clear-gutters testimonials">
        <section className="clearfix customer-rating">
          <div className="pull-left pill-img bg-accent-6 color-white">
            <i>{t.star}</i>{' '}
            <img
              src={
                t.coverImage
                  ? getImgIXUrl(t.coverImage)
                  : `${images_cdn_misc_url}default-profile.png`
              }
              alt
            />
          </div>
          <aside>
            <p>
              <b>{t.fName}</b> rated Pickyourtrail
            </p>
            <span className="meta-text color-grey">
              Travelled to {t.region} in 20 July,2016
            </span>
          </aside>
          <p className="main-text semi-bold fade hidden-xs">{t.shortReview}</p>
        </section>
        <Slider {...settings} className={'testimonials-slider'}>
          {testimonailPhotos}
        </Slider>
        <section className="clearfix text-center btm-btns">
          {t.itineraryId ? (
            <a
              target="_blank"
              rel="noopener noreferrer"
              href={`/view/${t.itineraryId}/assignUser`}
              onClick={e => {
                e.preventDefault();

                assignUser(t.itineraryId, true, false, 'testimonialItinerary/');
              }}
              className="btn btn-primary btn-outline tracker-packages-view-itinerary"
            >
              View itinerary
            </a>
          ) : null}
          {t.journalLinks && t.journalLinks[0] ? (
            <a
              target="_blank"
              rel="noopener noreferrer"
              href={t.journalLinks[0]}
              className="btn btn-primary btn-outline tracker-packages-view-journals"
            >
              View Journal
            </a>
          ) : null}
        </section>
      </div>
    );
  }
}
