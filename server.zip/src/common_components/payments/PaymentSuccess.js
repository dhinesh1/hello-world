import React from 'react';

export default function PaymentSuccess({ amount, regionName, txnId }) {
  return (
    <div>
      <div className="container">
        <section className="row payment-success mbottom-large">
          <div className="col-xs-12 col-sm-4 col-md-4 text-center">
            <span className="happy-vacations" />
          </div>
          <div className="col-xs-12 col-sm-8 col-md-8">
            <h2 className="xs-text-center">
              Your payment of &#8377;{amount} towards the booking of your
              vacation to {regionName} is successful.
            </h2>
            <ul className="list-unstyled mb-0">
              <li>
                Please note your transaction ID - <b>{txnId}</b>
              </li>
              <li>Your vouchers will be emailed to you shortly</li>
              <li>
                Visit{' '}
                <a href="/your-vacations" target="_blank">
                  Your Vacations
                </a>{' '}
                for Visa guidelines, packing checklists, destination guides and
                more.
              </li>
            </ul>
          </div>
        </section>
      </div>

      <div className="balloon-wrapper fly-fully hidden-xs">
        <div className="balloon">
          <span className="balloon-inner">
            <i className="vehoicon-directions_car" />
          </span>
        </div>
        <div className="balloon">
          <span className="balloon-inner">
            <i className="vehoicon-local_play" />
          </span>
        </div>
        <div className="balloon">
          <span className="balloon-inner">
            <i className="vehoicon-flight" />
          </span>
        </div>
        <div className="balloon">
          <span className="balloon-inner">
            <i className="vehoicon-airline_seat_individual_suite" />
          </span>
        </div>
      </div>

      <div className="balloon-wrapper fly-fully hidden-xs">
        <div className="balloon">
          <span className="balloon-inner">
            <i className="vehoicon-directions_car" />
          </span>
        </div>
        <div className="balloon">
          <span className="balloon-inner">
            <i className="vehoicon-local_play" />
          </span>
        </div>
        <div className="balloon">
          <span className="balloon-inner">
            <i className="vehoicon-flight" />
          </span>
        </div>
        <div className="balloon">
          <span className="balloon-inner">
            <i className="vehoicon-airline_seat_individual_suite" />
          </span>
        </div>
      </div>
    </div>
  );
}
