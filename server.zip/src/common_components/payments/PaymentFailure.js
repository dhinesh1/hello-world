import React from 'react';

export default function PaymentFailure({
  amount,
  tripId,
  virtualAccountNumber
}) {
  return (
    <section className="payment-failure">
      <div className="container xs-full-width">
        <div className="row">
          <div className="col-xs-12 text-center">
            <div className="failure-container">
              <span className="paymentfailure-img" />
              <h2 className="large-heading">
                Oops! Your transaction didn’t go through.
              </h2>
              <p className="payment-gateway">
                This usually happens when the payment gateway encounters a
                problem while processing your payment. Please click here to
                <a href="#">Go back and retry payment</a>
              </p>
              <div className="payment-failure-table vmargin-medium">
                <p className="imps-txt">
                  Alternatively you can make an IMPS transfer for{' '}
                  <span className="semi-bold">{amount}</span> &amp; mention the
                  trip ID <span className="semi-bold">{tripId}</span> as
                  transaction remark
                </p>
                <table className="table">
                  <tbody>
                    <tr>
                      <td>Bank Name</td>
                      <td>HSBC Bank</td>
                    </tr>
                    <tr>
                      <td>Branch</td>
                      <td>Chennai Main Branch</td>
                    </tr>
                    <tr>
                      <td>IFSC Code</td>
                      <td>HSBC0600002</td>
                    </tr>
                    <tr>
                      <td>Account Type</td>
                      <td>Current Account</td>
                    </tr>
                    <tr>
                      <td>Swift Code</td>
                      <td>HSBCINBB</td>
                    </tr>
                    <tr>
                      <td>Beneficiary Name</td>
                      <td>Travel Troops Global Pvt Ltd</td>
                    </tr>
                    <tr>
                      <td>Beneficiary Account Number</td>
                      <td>{virtualAccountNumber}</td>
                    </tr>
                    {/*
                    <tr>
                      <td>UPI Id</td>
                      <td>
                        <span>pickyourtrail@hdfcbank</span>
                      </td>
                    </tr>*/}
                  </tbody>
                </table>
              </div>
              <p className="vmargin-small footer-txt">
                For questions regarding this booking, email{' '}
                <a href="mailto:ops@pickyourtrail.com">ops@pickyourtrail.com</a>{' '}
                or call us on <span className="semi-bold">+91 7358154141</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
