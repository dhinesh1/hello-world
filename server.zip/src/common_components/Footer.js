import React, { Component, Fragment } from 'react';
import Collapsible from 'react-collapsible';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { AppConfig } from '../app-config';
import { fetchFooterData } from '../actions/actions_app';
import { trackEvent, EVENT_CHAT_REQUESTED } from '../helpers/ML/EventsTracker';
const CONTACT_NUMBER = AppConfig.website_contact_number;

const scrollTop = () => {
  window.scroll(0, 0);
};

function validateEmail(email) {
  var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}

class Footer extends Component {
  state = {
    expanded: 0,
    email_id: ''
  };

  componentDidMount() {
    const { footerData = [], actions } = this.props;
    // if footer data is not avaible the hitting the api to get the data
    !footerData.length && actions.fetchFooterData();
  }

  onTriggerClick = index => {
    if (this.state.expanded === index) {
      index = '';
    }

    this.setState({ expanded: index });
  };
  handleChange = event => {
    this.setState({ email_id: event.target.value });
  };
  handleEmailSubmit = e => {
    let apiUrl = 'https://pickyourtrail.com/user/subscribe';
    const headers = new Headers({
      'Content-Type': 'application/json'
    });
    let requestDetails = {
      method: 'POST',
      headers,
      mode: 'cors'
    };
    e.preventDefault();
    const email_id = this.state.email_id;
    const data_str = { email: email_id };
    const $signupBox = document.querySelector('.ftr-tbox');
    const $signupSuccess = document.querySelector('.ftr-success');
    const $signupEmailInput = document.querySelector('#ftrEmailInput');

    if (email_id === '') {
      $signupBox.classList.add('has-error');
    } else {
      if (validateEmail(email_id)) {
        $signupBox.classList.remove('has-error');
        requestDetails.body = data_str;
        fetch(apiUrl, requestDetails)
          .then(() => {
            $signupEmailInput.value = '';
            $signupSuccess.style.opacity = '1';
            setTimeout(function() {
              $signupSuccess.style.opacity = '0';
            }, 10 * 1000);
          })
          .catch(() => {
            $signupEmailInput.value = '';
            $signupSuccess.text =
              'Hey thank you but seems like you are already on our list!';
            $signupSuccess.style.opacity = '1';
            setTimeout(function() {
              $signupSuccess.style.opacity = '0';
            }, 10 * 1000);
          });
      } else {
        $signupBox.classList.add('has-error');
      }
    }
  };

  onChatClick = () => {
    trackEvent(EVENT_CHAT_REQUESTED, {
      element_type: 'button',
      element_name: 'btn_chat_requested_footer'
    })
    this.props.openChatWidget();
  }

  render() {
    let { expanded } = this.state;
    const ENABLE_CONTACT_NUMBER =
      this.props.showContactNumber || AppConfig.enable_Contact_Number;
    let { openChatWidget, footerData = [], randomBannerImage } = this.props;
    return (
      <footer className="clearfix site-footer">
        <div className="container">
          <section className="row">
            <div className="col-md-12">
              <hr className="mt-0" />
            </div>
          </section>
          <section className="row hidden-xs hidden-sm">
            {/* itierating each category to provide the row of categories */}
            {footerData.map((categoryItem, ca_index) => {
              return (
                <div className="ftr-col" key={`category_key_${ca_index}`}>
                  <h6 className="caps-text-tiny bold mb-0">
                    {categoryItem.category}
                  </h6>
                  <FooterDestinationsList
                    destinations={categoryItem.destinations}
                    ca_index={ca_index}
                  />
                </div>
              );
            })}
            <div className="ftr-col">
              <h6 className="caps-text-tiny bold mb-0">
                SIGN UP FOR TRAVEL IDEAS!
              </h6>
              <div className="ftr-tbox">
                <form>
                  <input
                    onChange={this.handleChange}
                    id="ftrEmailInput"
                    type="email"
                    placeholder="Your email"
                  />
                  <button
                    type="submit"
                    className="btn btn-primary"
                    onClick={e => this.handleEmailSubmit(e)}
                    id="ftrEmailBtn"
                  >
                    <i className="vehoicon-ion-checkmark" />
                  </button>
                </form>
                <span className="fine-text ftr-success">
                  Thank you! We will keep you posted
                </span>
              </div>
              <h6 className="caps-text-tiny bold">
                {' '}
                TALK TO OUR TRAVEL CONSULTANTS
              </h6>
              <ul className="icon-links list-unstyled mb-0 n-tracker-talktoanexpert">
                <li>
                  <a href="mailto:planners@pickyourtrail.com">
                    <i className="vehoicon-envelope" />planners@pickyourtrail.com
                  </a>
                </li>
                <li>
                  <a href="javascript:void(0);" onClick={this.onChatClick}>
                    <i className="vehoicon-chat_bubble" />Chat with our travel
                    consultant
                  </a>
                </li>
                {ENABLE_CONTACT_NUMBER ? (
                  <li>
                    <a href={`tel: +91${CONTACT_NUMBER}`}>
                      <i className="vehoicon-phone2" />+91 {CONTACT_NUMBER}
                    </a>
                  </li>
                ) : null}
              </ul>
            </div>
          </section>
          <section className="row hidden-xs hidden-sm">
            <div className="col-md-12">
              <hr />
            </div>
          </section>
          <section className="row hidden-xs hidden-sm">
            <div className="col-md-8">
              <ul className="list-unstyled list-inline mb-0">
                <li>
                  <Link
                    key={'footerAboutBtn'}
                    to={{
                      pathname: `/about-us`
                    }}
                    className="n-tracker-footer-about"
                    onClick={scrollTop}
                  >
                    About
                  </Link>
                </li>
                <li>
                  <Link
                    key={'footerTestimonialsBtn'}
                    to={{
                      pathname: `/testimonials`
                    }}
                    className="n-tracker-footer-testimonials"
                    onClick={scrollTop}
                  >
                    Testimonials
                  </Link>
                </li>
                <li>
                  <Link
                    key={'footerTermsBtn'}
                    to={{
                      pathname: `/terms-and-conditions`
                    }}
                    onClick={scrollTop}
                    className="n-tracker-footer-terms"
                  >
                    Terms &amp; Conditions
                  </Link>
                </li>
                <li>
                  <Link
                    key={'footerPrivacyBtn'}
                    to={{
                      pathname: `/privacy-policy`
                    }}
                    className="n-tracker-footer-privacy"
                    onClick={scrollTop}
                  >
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link
                    key={'footerCancellationBtn'}
                    to={{
                      pathname: `/cancellation-policy`
                    }}
                    className="n-tracker-footer-cancellations"
                    onClick={scrollTop}
                  >
                    Cancellations
                  </Link>
                </li>
                <li>
                  <Link
                    key={'footerContactBtn'}
                    to={{
                      pathname: `/contact-us`
                    }}
                    className="n-tracker-footer-contactus"
                    onClick={scrollTop}
                  >
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link
                    key={'footerCareersBtn'}
                    to={{
                      pathname: `/careers`
                    }}
                    className="n-tracker-footer-careers"
                    onClick={scrollTop}
                  >
                    Careers
                  </Link>
                </li>
                <li>
                  <Link
                    key={'footerSitemapBtn'}
                    target={'_blank'}
                    to={{
                      pathname: `/all`
                    }}
                    className="n-tracker-footer-sitemap"
                    onClick={scrollTop}
                  >
                    Sitemap
                  </Link>
                </li>
                {this.props.pathname === '/' ? (
                  <li>
                    <a href={randomBannerImage.link} target={'_blank'}>
                      Unwrapped by {randomBannerImage.name}
                    </a>
                  </li>
                ) : null}
              </ul>
            </div>
            <div className="col-md-4">
              <ul className="list-unstyled list-inline text-right mb-0">
                <li>
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    href="https://blog.pickyourtrail.com/?cpid=footer"
                    className="n-tracker-footer-blog"
                  >
                    Blog
                  </a>
                </li>
                <li>
                  <a
                    href="/guides"
                    target={'_blank'}
                    className="n-tracker-footer-guides"
                  >
                    Guides
                  </a>
                </li>
                <li>
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    href="http://visa.pickyourtrail.com/"
                    className="n-tracker-footer-visa"
                  >
                    Visa
                  </a>
                </li>
                <li>
                  <Link
                    key={'footerFaqBtn'}
                    to={{
                      pathname: `/faq`
                    }}
                    onClick={scrollTop}
                    className="n-tracker-footer-faq"
                  >
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
          </section>
          <section className="row visible-xs visible-sm footer-meta mbottom-large">
            <div className="col-md-12">
              <div className="panel-group" id="footer-accordion">
                {/* itierating each category to provide the row of categories */}
                {footerData.map((categoryItem, ca_index) => {
                  return (
                    <FooterAccordion
                      index={ca_index}
                      expanded={expanded}
                      onTriggerClick={this.onTriggerClick}
                      trigger={
                        <span className="panel-title">
                          {categoryItem.category}
                        </span>
                      }
                      key={`category_key_${ca_index}`}
                    >
                      <FooterDestinationsList
                        destinations={categoryItem.destinations}
                        ca_index={ca_index}
                      />
                    </FooterAccordion>
                  );
                })}
              </div>
            </div>
          </section>
          <section className="row visible-xs visible-sm">
            <div className="col-md-12 text-center">
              <Link
                key={'footerAboutBtn'}
                to={`/about-us`}
                className="n-tracker-mbl-footer-about"
                onClick={scrollTop}
              >
                About
              </Link>
              <span className="dim"> . </span>
              <a
                href="/guides"
                target={'_blank'}
                className="n-tracker-mbl-footer-guides"
              >
                Guides
              </a>
              <span className="dim"> . </span>
              <Link
                key={'footerTermsBtn'}
                to={`/terms-and-conditions`}
                onClick={scrollTop}
                className="n-tracker-mbl-footer-terms"
              >
                Terms &amp; Conditions
              </Link>
              <br />
              <Link
                key={'footerCancellationBtn'}
                to={`/cancellation-policy`}
                className="n-tracker-mbl-footer-cancellations"
                onClick={scrollTop}
              >
                Cancellations
              </Link>
              <span className="dim"> . </span>
              <Link
                key={'footerCareersBtn'}
                to={`/careers`}
                className="n-tracker-mbl-footer-careers"
                onClick={scrollTop}
              >
                Careers
              </Link>
              <span className="dim"> . </span>
              <Link
                key={'footerContactBtn'}
                to={`/contact-us`}
                className="n-tracker-mbl-footer-contactus"
                onClick={scrollTop}
              >
                Contact Us
              </Link>
              <span className="dim"> . </span>
              <Link
                key={'footerSitemapBtn'}
                to={`/all`}
                className="n-tracker-mbl-footer-sitemap"
                target={'_blank'}
                onClick={scrollTop}
              >
                Sitemap
              </Link>
              {this.props.pathname === '/' ? (
                <Fragment>
                  <span className="dim"> . </span>
                  <a href={randomBannerImage.link} target={'_blank'}>
                    Unwrapped by {randomBannerImage.name}
                  </a>
                </Fragment>
              ) : null}
            </div>
          </section>
          <section className="row">
            <div className="col-md-12 text-center">
              <div className="socials">
                <span itemScope itemType="http://schema.org/Organization">
                  <a
                    itemProp="sameAs"
                    href="https://www.facebook.com/pg/Pickyourtrail/reviews/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="n-tracker-footer-facebookicon"
                  >
                    <i className="vehoicon-facebook-square" />
                  </a>
                  <a
                    itemProp="sameAs"
                    href="https://twitter.com/@pickyourtrail"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="n-tracker-footer-twittericon"
                  >
                    <i className="vehoicon-twitter" />
                  </a>
                  <a
                    itemProp="sameAs"
                    href="https://www.instagram.com/pickyourtrail/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="n-tracker-footer-instagramicon"
                  >
                    <i className="vehoicon-instagram" />
                  </a>
                </span>
                <p>
                  Travel Troops Global Private Ltd. © {new Date().getFullYear()}{' '}
                  all rights reserved.
                </p>
              </div>
            </div>
          </section>
        </div>
      </footer>
    );
  }
}

const FooterAccordion = props => (
  <section className="panel panel-default">
    <Collapsible
      open={props.expanded === props.index}
      triggerTagName={'div'}
      triggerClassName={'panel-heading accordion-toggle'}
      triggerOpenedClassName={'panel-heading accordion-toggle'}
      contentInnerClassName={'panel-body'}
      handleTriggerClick={() => props.onTriggerClick(props.index)}
      trigger={props.trigger}
    >
      {props.children}
    </Collapsible>
  </section>
);

const FooterDestinationsList = ({ destinations, ca_index }) => (
  <React.Fragment>
    <ul className="list-unstyled mb-0">
      {/* itierating each destination to provide the column of destination links */}
      {destinations
        ? destinations.map((destination, des_index) => {
            return (
              <li key={`des_key_${ca_index}_${des_index}`}>
                <Link
                  to={
                    destination.url
                      ? destination.url.replace(AppConfig.socket_url, '')
                      : '/'
                  }
                  className="n-tracker-destination"
                  onClick={scrollTop}
                  target="_blank"
                >
                  {destination.name}
                </Link>
              </li>
            );
          })
        : null}
    </ul>
  </React.Fragment>
);

function mapStateToProps(state) {
  return {
    footerData: state.app.footerData,
    randomBannerImage: state.app.randomBannerImage,
    showContactNumber: parseInt(state.app.showContactNumber)
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      fetchFooterData: bindActionCreators(fetchFooterData, dispatch)
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Footer);
