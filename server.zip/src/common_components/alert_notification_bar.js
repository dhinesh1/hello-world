import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { manageSoftNotification, undo } from '../actions/actions_app';
import { connect } from 'react-redux';
import classNames from 'classnames';

class AlertNotificationBar extends Component {
  constructor(props) {
    super(props);

    this.state = {
      show: false,
      startProgress: false
    };

    this.onClickHandler = this.onClickHandler.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.show_notification && this.state.show) {
      window.clearTimeout(this.activeTimer);

      this.setState({ show: false, startProgress: false });
    }

    if (nextProps.show_notification && !this.state.show) {
      this.setState({ show: true }, () => {
        setTimeout(() => {
          this.setState({ startProgress: true }, () => {
            this.activeTimer = setTimeout(() => {
              this.hide();
            }, 7900);
          });
        }, 300);
      });
    }
  }

  hide() {
    this.props.actions
      .manageSoftNotification({
        show_notification: false,
        message: '',
        show_undo: false
      })
      .then(() => {
        this.setState({ show: false });
      })
      .catch(() => {
        this.setState({ show: false });
      });
  }

  onClickHandler(e) {
    e && e.preventDefault();

    this.props.actions
      .undo(this.props.itineraryInfo.itinerary.itineraryId)
      .then(() => {
        this.hide();
      });
  }

  render() {
    let { showNewPop } = this.props;
    if (showNewPop) {
      return (
        <div
          className={classNames('msg-notification text-center', {
            show: this.state.show
          })}
        >
          <p>{this.props.message}</p>
        </div>
      );
    } else {
      return (
        <div
          className={classNames('bottom-options-bar text-center', {
            'slide-up': this.state.show
          })}
          style={{ zIndex: 1002 }}
        >
          <section className="bottom-options-content">
            <div className="clearfix hidden-xs sm-text">
              <p className="pull-left">{this.props.message}</p>
              {this.props.show_undo ? (
                <button
                  onClick={this.onClickHandler}
                  className={classNames('pull-right btn btn-primary', {
                    'progress-btn': this.state.startProgress
                  })}
                >
                  {this.state.startProgress ? (
                    <span className="progress-bg" />
                  ) : null}
                  <span className={'btn-txt'}>Undo action</span>
                </button>
              ) : null}
            </div>
            <div className="clearfix visible-xs xs-btns">
              <p className="text-center">{this.props.message}</p>

              <div className="clearfix visible-xs xs-btns">
                {/*<div className="btn-col pull-left">*/}
                {/*<button onClick={this.hide} className="btn btn-default btn-outline btn-outline-bg btn-block btn-sm">Close</button>*/}
                {/*</div>*/}

                {this.props.show_undo ? (
                  <div className="btn-col pull-right">
                    <button
                      onClick={this.onClickHandler}
                      className={classNames(
                        'btn btn-primary-dark btn-block btn-sm',
                        {
                          'progress-btn': this.state.startProgress
                        }
                      )}
                    >
                      {this.state.startProgress ? (
                        <span className="progress-bg" />
                      ) : null}
                      <span className={'btn-txt'}>Undo</span>
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
          </section>
        </div>
      );
    }
  }
}

const mapStateToProps = state => {
  let app = state.app;

  return {
    itineraryInfo: app.itineraryInfo.itineraryDetails,
    user_details: app.user_details,
    ...app.soft_notification
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: {
      manageSoftNotification: bindActionCreators(
        manageSoftNotification,
        dispatch
      ),
      undo: bindActionCreators(undo, dispatch)
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(
  AlertNotificationBar
);
