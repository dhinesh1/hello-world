import React from 'react';

const ModalLoadingIndicator = () => (
  <div className={`modal-dialog`}>
    <div className={'modal-content with-header'}>
      <div className={'row'}>
        <div className={'col-xs-12 text-center'} style={{ height: '200px' }}>
          <div className="clearfix">
            <div className="loading-dots" />
            <div className="loading-dots" />
            <div className="loading-dots" />
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default ModalLoadingIndicator;
