import React, { Component } from 'react';
import classNames from 'classnames';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { logout } from '../actions/actions_login_app';
import { closeOffCanvasMenu } from '../helpers/utilsHelper';
import { AppConfig } from '../app-config';
const CONTACT_NUMBER = AppConfig.website_contact_number;

class OffCanvasMenu extends Component {
  constructor(props) {
    super(props);

    this.state = {
      opened: false
    };
    this.triggerLogout = this.triggerLogout.bind(this);
  }

  triggerLogout(e) {
    e && e.preventDefault();
    this.props.logout({
      history: this.props.history,
      userType: this.props.user_details.userType,
      location: this.props.history.location
    });
    closeOffCanvasMenu();
  }

  render() {
    const { user_details } = this.props;
    const ENABLE_CONTACT_NUMBER =
      this.props.showContactNumber || AppConfig.enable_Contact_Number;
    return (
      <div>
        <div
          onClick={closeOffCanvasMenu}
          className={classNames({
            'offcanvas-bg': true,
            in: this.state.opened
          })}
        />
        <aside
          className={classNames({
            'offcanvas-menu': true,
            'open-menu': this.state.opened
          })}
        >
          <div className="clearfix hdr">
            {user_details && user_details.loggedIn ? (
              <p>{user_details.name}</p>
            ) : (
              <p>Hello Guest,</p>
            )}
            <span className="pull-right" onClick={closeOffCanvasMenu}>
              <i id="menuClose" className="vehoicon-close" />
            </span>
          </div>
          {user_details && user_details.loggedIn ? (
            <ul className="clearfix list-unstyled">
              <li>
                <Link
                  to={`/your-vacations`}
                  onClick={closeOffCanvasMenu}
                  className="n-tracker-offcanvas-yourvacations"
                >
                  Your vacations
                </Link>
              </li>
              <li>
                <Link
                  to={`/account`}
                  className="n-tracker-offcanvas-youraccount"
                  onClick={closeOffCanvasMenu}
                >
                  Your account
                </Link>
              </li>
              <li>
                <a className="logout" onClick={this.triggerLogout}>
                  Logout
                </a>
              </li>
            </ul>
          ) : null}
          <ul className="clearfix list-unstyled">
            <li>
              <Link
                key={'offcanvasAboutBtn'}
                to={`/about-us`}
                onClick={closeOffCanvasMenu}
                className="n-tracker-offcanvas-about"
              >
                About
              </Link>
            </li>
            <li>
              <Link
                key={'offcanvasTestimonialsBtn'}
                to={`/testimonials`}
                onClick={closeOffCanvasMenu}
                className="n-tracker-offcanvas-testimonials"
              >
                {' '}
                Testimonials{' '}
              </Link>
            </li>
            <li>
              <Link
                key={'offcanvasFaqsBtn'}
                to={`/faq`}
                onClick={closeOffCanvasMenu}
                className="n-tracker-offcanvas-faq"
              >
                FAQ
              </Link>
            </li>
            <li>
              <a
                href="/guides"
                onClick={closeOffCanvasMenu}
                className="n-tracker-offcanvas-guides"
              >
                Guides
              </a>
            </li>
            <li>
              <a
                href="http://visa.pickyourtrail.com/"
                onClick={closeOffCanvasMenu}
                className="n-tracker-offcanvas-visa"
              >
                Visa
              </a>
            </li>
            <li>
              <a
                href="https://blog.pickyourtrail.com/?cpid=header"
                onClick={closeOffCanvasMenu}
                className="n-tracker-offcanvas-blog"
              >
                Blog
              </a>
            </li>
            <li>
              <Link
                key={'offcanvasPrivacyBtn'}
                to={`/privacy-policy`}
                onClick={closeOffCanvasMenu}
                className="n-tracker-offcanvas-privacy"
              >
                Privacy
              </Link>
            </li>
          </ul>
          <div className="clearfix ftr">
            {ENABLE_CONTACT_NUMBER ? (
              <span className="pull-left">
                <a
                  href={`tel:+91${CONTACT_NUMBER}`}
                  className="n-tracker-offcanvas-phoneno"
                >
                  +91 {CONTACT_NUMBER}
                </a>
              </span>
            ) : null}
            <span className={classNames('pull-right', {'hidden-number' : !ENABLE_CONTACT_NUMBER})}>
              <a
                href="https://www.facebook.com/pg/Pickyourtrail/reviews/"
                target="_blank"
                rel="noopener noreferrer"
                className="n-tracker-offcanvas-facebookicon"
              >
                <i className="vehoicon-facebook-square" />
              </a>
              <a
                href="https://twitter.com/@pickyourtrail"
                target="_blank"
                rel="noopener noreferrer"
                className="n-tracker-offcanvas-twittericon"
              >
                <i className="vehoicon-twitter" />
              </a>
              <a
                href="https://www.instagram.com/pickyourtrail/"
                target="_blank"
                rel="noopener noreferrer"
                className="n-tracker-offcanvas-instagramicon"
              >
                <i className="vehoicon-instagram" />
              </a>
            </span>
          </div>
        </aside>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    user_details: state.app.user_details,
    showContactNumber: parseInt(state.app.showContactNumber)
  };
}

function mapDispatchToProps(dispatch) {
  return {
    logout: bindActionCreators(logout, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(OffCanvasMenu);
