import React from 'react';
/**
 * TODO: Re-organize folder
 */
// import FlightInfoTabs from '../pages/itinerary/components/flight_info_tabs';
import PropTypes from 'prop-types';
import FlightInfoTabs from './itinerary/flight_info_tabs';
import { getAirlineLogo, getConnectionDuration } from '../helpers/utilsHelper';
import SmartImage from './Image/smart_image';

const FlightContainer = ({
  flightData,
  roundTripLabel,
  childCountMarkup,
  adult_count
}) => {
  return (
    <div className="row">
      <div className="col-md-12">
        <div className="item-header">
          <h3>{getFlightTripTitle(flightData)}</h3>
          <span className="p block">
            <span className="bold color-secondary schedule">
              {getTripStartAndEndDate(flightData)}
            </span>{' '}
            {roundTripLabel}
          </span>
        </div>
        <div className="at-a-glance clearfix">
          <div className="col-xs-6 col-md-3">
            <span className="meta-text dim block mb-4">No. of travellers</span>
            {adult_count} {adult_count > 1 ? 'Adults' : 'Adult'}{' '}
            {childCountMarkup}
          </div>
          <div className="col-xs-6 col-md-3">
            <span className="meta-text dim block mb-4">Refundable?</span>
            <span
              className={
                flightData.refundable
                  ? 'vehoicon-refundable color-success'
                  : 'vehoicon-non-refundable color-danger'
              }
            />{' '}
            {flightData.refundable ? 'Yes' : 'No'}
          </div>
          <div className="col-xs-6 col-md-3">
            <span className="meta-text dim block mb-4">Availability</span>
            {flightData.noOfSeatAvailable}{' '}
            {flightData.noOfSeatAvailable > 0 ? 'Seats' : 'Seat'} left
          </div>
          {flightData.price ? (
            <div className="col-xs-6 col-md-3">
              <span className="meta-text dim block mb-4">Total cost</span>
              <span className="total-price bold opener">
                <span className="WebRupee">Rs.</span> {flightData.price}
              </span>
            </div>
          ) : null}
        </div>
        <hr className="no-height mute" />
        {renderTrips(flightData)}
      </div>
    </div>
  );
};

FlightContainer.propTypes = {
  flightData: PropTypes.object.isRequired,
  roundTripLabel: PropTypes.string.isRequired,
  childCountMarkup: PropTypes.string.isRequired,
  adult_count: PropTypes.number.isRequired
};

const getFlightTripTitle = flight => {
  let allTrips = flight.allTrips;
  let lastTrip = allTrips.length - 1;
  return allTrips.map((trip, i) => {
    let connector =
      i === lastTrip - 1 && i !== lastTrip ? (
        <span>&nbsp;&nbsp; - &nbsp;&nbsp;</span>
      ) : null;
    let lastRoute = flight.trips[trip].routes.length - 1;
    return (
      <span key={'title_' + i} className="regular">
        {flight.trips[trip].routes[0].departureCity} to{' '}
        {flight.trips[trip].routes[lastRoute].arrivalCity} {connector}
      </span>
    );
  });
};

const getTripStartAndEndDate = flight => {
  let tripStartAndEndDate = null;
  if (flight.allTrips.length === 2) {
    let trip1 = flight.trips[flight.allTrips[0]];
    let trip2 = flight.trips[flight.allTrips[1]];
    let trip1RoutesLastIndex = trip1.routes.length - 1;
    let trip2RoutesLastIndex = trip2.routes.length - 1;
    let trip1DisplayText = `${trip1.routes[0].depMonth} ${
      trip1.routes[trip1RoutesLastIndex].depDateOfMonth
    }`;
    let trip2DisplayText = `${trip2.routes[0].arrMonth} ${
      trip2.routes[trip2RoutesLastIndex].arrDateOfMonth
    }`;
    tripStartAndEndDate = `${trip1DisplayText} - ${trip2DisplayText}`;
  } else {
    let trip1 = flight.trips[flight.allTrips[0]];
    let trip1RoutesLastIndex = trip1.routes.length - 1;
    let trip1DisplayText = `${trip1.routes[0].depMonth} - ${
      trip1.routes[trip1RoutesLastIndex].depDateOfMonth
    }`;
    tripStartAndEndDate = `${trip1DisplayText}`;
  }

  return tripStartAndEndDate;
};

const getConnectionDurationAndStopsCount = (duration, r) => {
  let stops = '';
  if (r !== undefined) {
    if (r.length - 1 === 0) stops = 'Direct';
    else if (r.length - 1 === 0) stops = `${r.length - 1} stop`;
    else stops = `${r.length - 1} stops`;
  }
  let durHours = Math.floor(duration / 60);
  let durMinutes = duration % 60;

  if (durHours !== 0)
    if (durMinutes > 0) {
      return { stops: stops, duration: `${durHours}h ${durMinutes}m` };
    } else {
      if (durHours > 1) return { stops: stops, duration: `${durHours} hours` };
      else return { stops: stops, duration: `${durHours} hour` };
    }
  else return { stops: stops, duration: `${durMinutes}m` };
};

const SingleFlightTripRow = (trip, airlineCode) => {
  let layover_row = null;
  return trip.routes.map((route, inx) => {
    if (route.connectionDuration > 0)
      layover_row = (
        <span className="fw text-center inline-block layover-bar fade">
          {getConnectionDuration(route.connectionDuration)} layover in{' '}
          {route.arrivalCity}
        </span>
      );
    else layover_row = null;

    let flightNumber = '';
    let carrierCode = '';
    if (trip.routes) {
      flightNumber = trip.routes[inx].flightNumber;
      carrierCode = trip.routes[inx].carrierCode;
    }
    const airlineImg = getAirlineLogo(airlineCode);
    return (
      <div
        key={'single_route_' + inx}
        className="clearfix vmargin-medium meta-text"
      >
        <div className="col-sm-3 no-padding text-center airline-logo">
          <div className="airline-logo-fit">
            <SmartImage
              disableLazyLoad
              src={airlineImg.url}
              defaultImage={airlineImg.default}
              alt={airlineImg.name}
            />
          </div>
          <span className="main-para">{`${carrierCode}  ${flightNumber}`}</span>
        </div>
        <div className="col-xs-12 col-sm-9 no-padding">
          <div className="col-xs-5 no-padding mb-4">
            <span className="vehoicon-flight_takeoff" />&nbsp;{route.departureTime.substring(
              0,
              5
            )}
            <span className="block dim">
              {route.departureAirportCode}, {route.departureCity}
            </span>
          </div>
          <div className="col-xs-2 no-padding text-center dim mb-4">
            ⟶
            <span className="block">
              {route.travelDuration > 0
                ? getConnectionDurationAndStopsCount(route.travelDuration)
                    .duration
                : null}
            </span>
          </div>
          <div className="col-xs-5 no-padding text-right mb-4">
            {route.arrivalTime.substring(0, 5)}&nbsp;<span className="vehoicon-flight_land" />
            <span className="block dim">
              {route.arrivalAirportCode}, {route.arrivalCity}
            </span>
          </div>
          {layover_row}
        </div>
      </div>
    );
  });
};

const renderTrips = flight => {
  return flight.allTrips.map(tripId => {
    let trip = flight.trips[tripId];

    let duration = getConnectionDuration(trip.duration);

    let layover_count = '';
    if (trip.routes.length - 2 > 0) {
      if (trip.routes.length - 2 === 1) {
        layover_count = '1 Layover';
      } else {
        layover_count = trip.routes.length - 2 + ' Layovers';
      }
    }
    const airlineImg = getAirlineLogo(flight.airlineCode);
    return (
      <div className="flight-info vmargin-medium" key={tripId}>
        <div className="row">
          <div className="col-xs-8 col-sm-12">
            <h5 className="mt-0 mb-4">
              {trip.mon} {trip.day}
            </h5>
            <span className="small">
              {duration} flight, {layover_count}{' '}
              {!trip.landSameDay ? (
                <span className="pill warning">Arrives next day</span>
              ) : null}
            </span>
          </div>
          <div className="hidden-xs col-xs-4 no-padding hidden-sm hidden-md hidden-lg">
            <div className="airline-logo-fit right">
              <SmartImage
                disableLazyLoad
                src={airlineImg.url}
                defaultImage={airlineImg.default}
                alt={airlineImg.name}
              />
            </div>
          </div>
        </div>
        {SingleFlightTripRow(trip, flight.airlineCode)}
        <FlightInfoTabs
          trip={trip}
          excessBaggageInfo={flight.excessBaggageInfo}
        />
      </div>
    );
  });
};

export default FlightContainer;
