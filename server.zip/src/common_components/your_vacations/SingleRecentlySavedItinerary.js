import React from 'react';
import {
  adultsChildrenString,
  redirector,
  getWeatherIcon,
  renderList
} from '../../helpers/utilsHelper';
import { getStringFromArray } from '../../helpers/commonHelpers';
import moment from 'moment';
import { AppConfig } from '../../app-config';
import { getImgIXUrl } from '../../helpers/utilsHelper';
import { itineraryModalsRouteHelper } from '../../helpers/routesHelper';
const { website_contact_number } = AppConfig;

export const SingleRecentlySavedItinerary = props => {
  const itineraryPath = itineraryModalsRouteHelper({
    itineraryId: props.itineraryId,
    regionCode: 'region'
  });

  return (
    <section className="row saved-card">
      <a target={`_blank`} href={`${itineraryPath}`}>
        <div className="col-xs-12 col-sm-12 col-md-9">
          <figure
            style={{
              backgroundImage: `url(${getImgIXUrl(props.image, 'w=180')})`
            }}
          />
          <aside>
            <h6 className="small-heading semi-bold">{props.title}</h6>
            <p className="meta-text color-grey">
              {props.days} day itinerary to {props.cities}
            </p>
            <span className="caps-text-tiny color-grey-medium semi-bold">
              Recently {props.lastEdited}
            </span>
          </aside>
        </div>
        <div className="col-md-3 visible-md visible-lg text-right">
          <span className="color-accent-6 caps-text-small semi-bold pr-8">
            View Itinerary
          </span>
        </div>
      </a>
    </section>
  );
};

export const SingleSimilarItinerary = props => {
  const itineraryPath = itineraryModalsRouteHelper({
    itineraryId: props.itineraryId,
    regionCode: 'region'
  });

  return (
    <div className="col-sm-6 col-xs-12">
      <div className="itinerary-card">
        <a
          target={'_blank'}
          href={`${itineraryPath}`}
          onClick={e => {
            e.preventDefault();

            props.assignUser(props.itineraryId, true);
          }}
        >
          <figure
            style={{
              backgroundImage: `url(${getImgIXUrl(props.image)})`
            }}
          >
            {props.travellingOn === -1 || props.travellingOn === '-1' ? null : (
              <figcaption className="caps-text-small">
                {moment(props.travellingOn).format('MMMM DD')}
              </figcaption>
            )}
          </figure>
          <div className="clearfix card-text">
            <h6 className="small-heading semi-bold fade color-base">
              {props.countriesList.join(', ')}
            </h6>
            <p className="fine-text color-grey">
              {props.duration} itinerary to {props.listOfCitiesFormatted} from{' '}
              {props.departueAirport === '$$$'
                ? 'Outside India'
                : props.departueAirport}
            </p>
            <div className="clearfix">
              <span className="color-accent-6 main-text">
                &#8377; {props.cost}
              </span>
              <i className="caps-text-tiny semi-bold color-grey-medium">
                {' '}
                Quoted {props.bookingDetails}
              </i>
            </div>
          </div>
        </a>
      </div>
    </div>
  );
};

export const DealBox = props => {
  let tagColor = props.dealType === 'RARE_FIND' ? `green` : `orange`;
  return (
    <div className="deal-card">
      <a
        href={`/view/${props.itineraryId}`}
        target="_blank"
        onClick={e => {
          e.preventDefault();

          props.itineraryAssignUser(props.itineraryId, true);
        }}
      >
        <figure
          style={{
            backgroundImage: `url(${getImgIXUrl(props.image, 'w=180')})`
          }}
        />
        <aside className={`pull-left card-text`}>
          <span className={`card-tag ${tagColor}`}>{props.dealTitle}</span>
          <h6 className="small-heading semi-bold fade color-base">
            {props.countriesList.join(', ')}
          </h6>
          <p className="fine-text color-grey">
            {props.nights} nights itinerary to{' '}
            {getStringFromArray(props.cities, ', ')} from{' '}
            {props.departureCity !== '' ? props.departureCity : null}
          </p>
          <div className="clearfix">
            <span className="color-accent-6 main-text">₹ {props.cost}</span>
            {/*<i className="caps-text-tiny semi-bold color-grey-medium">For Mar 12, 15, 17</i>*/}
          </div>
        </aside>
      </a>
    </div>
  );
};

export const BookedItineraryCard = props => {
  let url = `/yourtrips/${props.itineraryId}`;
  return (
    <section
      className="clearfix trip-details cursor-pointer mbottom-large"
      onClick={() => {
        redirector(url, '_blank');
      }}
    >
      <p className="color-grey-medium caps-text-small visible-xs">
        TRIP ID {props.uniqueIdentifier}
      </p>
      <aside className="pull-left">
        {!props.bookingProcessed ? (
          <b className="color-accent-6 caps-text-small hidden-xs">
            <i className="vehoicon-cached spin" /> Processing
          </b>
        ) : null}
        <h4 className="small-heading semi-bold">{props.itineraryName}</h4>
        <ul className="list-unstyled">
          <li>
            <span className="color-grey">Departure:</span> {props.departureDate}{' '}
            from {props.departureCity}
          </li>
          <li>
            <span className="color-grey">Booked for:</span>{' '}
            {adultsChildrenString(props.adults, props.children)}
          </li>
          <li>
            <span className="color-grey">Booked on:</span>{' '}
            {moment(props.bookedOnDateMillis).format('DD/MM/YYYY')}
          </li>
        </ul>
        <a
          target="_blank"
          href={url}
          className="btn btn-primary btn-xs btn-outline"
        >
          View booking
        </a>
      </aside>
      <figure className="pull-left">
        <img src={`${getImgIXUrl(props.image, 'w=180&h=180')}`} alt="Bali" />
        <figcaption className="text-center">
          {props.daysToGo}{' '}
          {props.daysToGo === 0
            ? `Today`
            : props.daysToGo === 1
              ? `day to go`
              : `days to go`}
        </figcaption>
      </figure>
      {props.offlinePayment ? null : (
        <p className="pull-left text-center hidden-xs next-pay">
          {!props.paidFull ? (
            <span className="dim">
              Your next payment is{' '}
              {props.paymentPendingIn === 0
                ? `due today`
                : props.paymentPendingIn > 0
                  ? `due in ${props.paymentPendingIn} days`
                  : `overdue`}.
            </span>
          ) : (
            <span className="dim">100% payment made</span>
          )}
        </p>
      )}
    </section>
  );
};

export const Stories = props => {
  let storiesList = props.stories.map((story, i) => {
    return (
      <li key={`stories-${i}`}>
        <a target="_blank" href={story.storyLink}>
          {story.displayText}
        </a>
      </li>
    );
  });
  return (
    <section className="clearfix stories mbottom-large">
      <h4 className="medium-heading semi-bold mt-0 xs-text-center">
        Stories from our blog
      </h4>
      <ul className="list-unstyled">{storiesList}</ul>
    </section>
  );
};

export const SingleWeatherBox = props => {
  return (
    <div className="item">
      <div className="weather-card text-center">
        <h6 className="caps-text-small bold color-accent-6">
          {props.dayFormatted} {props.dateFormatted}
        </h6>
        <p className="fine-text">{props.cityName}</p>
        <i className={'wi ' + getWeatherIcon(props.iconName)} />
        <h5 className="small-heading">
          {props.tempratureLow}°{' '}
          <span className="color-grey-medium">{props.tempratureHigh}°</span>
        </h5>
        <p className="fine-text color-grey-medium">{props.climateSummary}</p>
      </div>
    </div>
  );
};

export const SingleWeatherBoxMobile = props => {
  return (
    <div className="weather-card text-center">
      <h6 className="caps-text-small bold color-accent-6">
        {props.dayFormatted} {props.dateFormatted}
      </h6>
      <p className="fine-text">{props.cityName}</p>
      <i className={'wi ' + getWeatherIcon(props.iconName)} />
      <h5 className="small-heading">
        {props.tempratureLow}°{' '}
        <span className="color-grey-medium">{props.tempratureHigh}°</span>
      </h5>
      <p className="fine-text color-grey-medium">{props.climateSummary}</p>
    </div>
  );
};

export const GuidesSectionCard = props => {
  return (
    <div className="col-xs-12 col-sm-6">
      <div className="guides-card mbottom-large">
        <a href={props.guidesUrl} target="_blank">
          <div className="clearfix guides-img">
            <img
              className="img-responsive"
              src={props.imageUrl}
              alt={props.heading}
            />
          </div>
          <div className="guides-card-block">
            <h4 className="medium-heading">
              <span className="caps-text-small color-accent-6">
                {props.countryName}
              </span>
              {props.heading}
            </h4>
            <p className="fine-text color-grey">{props.description}</p>
          </div>
        </a>
      </div>
    </div>
  );
};

export const RecommendedApps = props => {
  return (
    <section className="clearfix recommended-apps">
      <div className="text-center">
        <span className="illustrate-img" />
        <h5 className="medium-heading regular text-center">
          {props.appBoxTitle}
        </h5>
        <p className="color-grey text-center meta-text">
          {props.appBoxDescription}
        </p>
      </div>
      <hr />
      <ul className="clearfix list-unstyled">
        {renderList(props.apps, SingleAppItem)}
      </ul>
    </section>
  );
};

export const SingleAppItem = props => {
  return (
    <li>
      <a href={props.appUrl} target="_blank">
        <span>
          <img src={props.appImage} alt={props.appName} />
        </span>
        <p>
          <b>{props.appName}</b>
          {props.appDescription}
        </p>
      </a>
    </li>
  );
};

export const BookedMetaBox = props => {
  return (
    <section className="clearfix payment-details mbottom-large">
      {props.alertMetaBox ? (
        <BookedMetaAlertBox {...props.alertMetaBox} />
      ) : null}
      {props.visaMetaBox && props.visaMetaBox.length > 0 ? (
        <BookedVisaBox {...props.visaMetaBox} />
      ) : null}
    </section>
  );
};

export const BookedMetaAlertBox = props => {
  let alertBgColorClass = '';
  switch (props.alterType) {
    case 'PAYMENT_PENDING':
      alertBgColorClass = 'second-payment';
      break;
    case 'PACKING_CHECKLIST':
      alertBgColorClass = 'success';
      break;
    case 'OVERDUE':
      alertBgColorClass = 'cancel';
      break;
    default:
      alertBgColorClass = 'second-payment';
      break;
  }

  return (
    <div className={`pull-left pay-status second-payment ${alertBgColorClass}`}>
      {props.alterType === 'PAYMENT_PENDING' ? (
        <div>
          <p className="fine-text semi-bold">
            Your next payment for the booking ID-{props.uniqueIdentifier} is due{' '}
            {props.dueInDays === '0'
              ? `today`
              : props.dueInDays > 0
                ? `in ${props.dueInDays} days`
                : `overdue`}. Please make the payment to keep your bookings
            active.
          </p>
          <a
            href={`yourtrips/${props.itineraryId}?activetab=pay`}
            className="btn btn-primary btn-xs pull-right"
          >
            Make payment
          </a>
        </div>
      ) : null}

      {props.alterType === 'PACKING_CHECKLIST' ? (
        <div>
          <p className="fine-text semi-bold">
            Woohoo!{' '}
            {props.noOfDaysToGo === '0'
              ? `Today is`
              : `${props.noOfDaysToGo} days to go for`}{' '}
            your flight to {props.arrivalCityName}, {props.regionName}. Keep our
            checklist handy while you pack your bags.
          </p>
          <a
            target="_blank"
            href={`https://d3lf10b5gahyby.cloudfront.net/pdf-assets/packing-checklist.pdf`}
            className="btn btn-primary btn-xs pull-right"
          >
            Packing checklist
          </a>
        </div>
      ) : null}

      {props.alterType === 'OVERDUE' ? (
        <div>
          <p className="fine-text semi-bold">
            Your payment for trip ID-{props.uniqueIdentifier} is overdue and the
            bookings may be on hold. Please contact us on +91{' '}
            {website_contact_number} to resume your bookings.
          </p>
          {/*<a target="_blank" href={`https://d3lf10b5gahyby.cloudfront.net/pdf-assets/packing-checklist.pdf`} className="btn btn-primary btn-xs pull-right">Packing checklist</a>*/}
        </div>
      ) : null}
    </div>
  );
};

export const BookedVisaBox = props => {
  return (
    <div className="pull-left process-text">
      {props[0] && props[0].onArrival ? (
        <i className="vehoicon-fingerprint2 " />
      ) : (
        <i className="vehoicon-warning" />
      )}
      <h5 className="main-text bold">
        {props[0].visaName}, {props[0].regionName}
      </h5>
      {props[0].onArrival ? null : (
        <p className="fine-text color-grey">
          Apply latest by {props[0].applyByDate}. Processing takes{' '}
          {props[0].processingTime}.{' '}
          <a
            href={`yourtrips/${props[0].itineraryId}?activetab=visa`}
            className="underline"
          >
            Learn more
          </a>
        </p>
      )}
    </div>
  );
};
