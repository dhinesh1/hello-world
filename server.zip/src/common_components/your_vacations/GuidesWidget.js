import React, { Component } from 'react';
import _ from 'lodash';
import { renderList } from '../../helpers/utilsHelper';
import { AppConfig } from '../../app-config';
import { getImgIXUrl } from '../../helpers/utilsHelper';
const { images_cdn_url_s3 } = AppConfig;

export default class GuidesWidget extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    let {
      savedItineraries,
      relatedItineraries,
      testimonails,
      guidesContent,
      dealItinerary
    } = this.props;
    let firstThreeGuidesCities = _.slice(guidesContent.otherGuides, 0, 3);
    let truncated_desc = _.truncate(
      guidesContent.featuredGuides.guidesDescription,
      { length: 245 }
    );

    return (
      <section
        className="explore-card mbottom-large"
        style={{
          backgroundImage: `url(${getImgIXUrl(
            guidesContent.featuredGuides.guidesCityImage,
            'w=960'
          )})`
        }}
      >
        <div className="explore-content">
          <a
            className="fw"
            href={guidesContent.featuredGuides.guidesUrl}
            target="_blank"
          >
            <span className="caps-text-small bold fade">EXPLORE</span>
            <h4 className="large-heading bold">
              {guidesContent.featuredGuides.guidesCityName}
            </h4>
            <p className="fine-text">
              <span className="fade">{truncated_desc}</span>{' '}
              <i className="vehoicon-arrow_downward hidden-xs" />
            </p>
          </a>
          {guidesContent.otherGuides && guidesContent.otherGuides.length > 1 ? (
            <ul className="list-unstyled">
              <li>
                <span className="caps-text-small bold fade">MORE GUIDES</span>
              </li>
              {renderList(firstThreeGuidesCities, OtherGuidesList)}
            </ul>
          ) : null}
        </div>
      </section>
    );
  }
}

const OtherGuidesList = props => {
  return (
    <li key={`other-guides-city-${props.guidesCityName}`}>
      <a target="_blank" href={props.guidesUrl}>
        {props.guidesCityName}
      </a>
    </li>
  );
};
