import React, { Component, Fragment } from 'react';
import {ReactComponent as BannerDesktop} from './banner-desktop.svg';
import {ReactComponent as BannerMobile} from './banner-mobile.svg';
import {is_server} from "../../helpers/utilsHelper";

const BannerSVG = () => {
  if(is_server()) return null;

  return (
    <Fragment>
      <BannerDesktop className="hidden-xs" />
      <BannerMobile className="visible-xs" />
    </Fragment>
  );
};

export default BannerSVG;
