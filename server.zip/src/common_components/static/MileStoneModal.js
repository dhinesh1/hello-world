import React, { Component } from 'react';
import classNames from 'classnames';
import {
  getFileNameFromUrl,
  getPathnameFromUrl,
  hideChatHead,
  hideChatDesktop,
  onceModalClosed,
  onceModalOpened,
  resetChatHead
} from '../../helpers/utilsHelper';
import { AppConfig } from '../../app-config';

class MileStoneModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      skip: props.index
    };
  }

  /**
   * This lifecycle method will be triggered once on DOM mounting
   */
  componentDidMount() {
    onceModalOpened();
    document.addEventListener('keyup', this.handleKeyUp);
    hideChatHead();
    hideChatDesktop();
  }

  /**
   * This lifecycle method will be triggered once on Component Unmounting
   */
  componentWillUnmount() {
    onceModalClosed();
    resetChatHead();
    document.removeEventListener('keyup', this.handleKeyUp);
  }

  /**
   * This method will be triggered when clicking the previous button when the modal is opened
   */
  previousModal = () => {
    if (!this.state.skip) return;

    this.setState({
      skip: this.state.skip - 1
    });
  };

  /**
   * This method will be triggered when clicking the next button when the modal is opened
   */
  nextModal = () => {
    if (this.state.skip === this.props.dataSource.length - 1) return;

    this.setState({
      skip: this.state.skip + 1
    });
  };

  handleKeyUp = e => {
    if (e.keyCode === 27) this.props.closeModal();
  };

  render() {
    let { isOpen, dataSource, index } = this.props;
    let data = dataSource[this.state.skip];
    return (
      <div
        className={classNames(
          'modal fade modal-sticky-header milestone-modal',
          {
            in: isOpen
          }
        )}
      >
        <div className="modal-dialog">
          <button
            type="button"
            className={`btn btn-lg hidden-xs ${
              !this.state.skip ? 'disabled' : ''
            }`}
            onClick={this.previousModal}
          >
            <i className="vehoicon-keyboard_arrow_left" />
          </button>
          <button
            type="button"
            className={`btn btn-lg hidden-xs ${
              this.state.skip === this.props.dataSource.length - 1
                ? 'disabled'
                : ''
            }`}
            onClick={this.nextModal}
          >
            <i className="vehoicon-keyboard_arrow_right" />
          </button>
          <div className="modal-content with-header">
            <div className="modal-header">
              <span>Our Story</span>
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                onClick={e => this.props.closeModal(e)}
              >
                <i className="vehoicon-close" />
              </button>
              <div className="progress">
                <div
                  className="progress-bar"
                  role="progressbar"
                  style={{
                    width:
                      100 / this.props.dataSource.length +
                      100 / this.props.dataSource.length * this.state.skip +
                      `%`
                  }}
                />
              </div>
            </div>

            <div className="modal-body">
              <div className="row vertical-center">
                <div className="col-xs-8 col-sm-5">
                  <img src={data.imageUrl} alt="Our Story" />
                  <img src={data.iconUrl} alt="Story Icon" />
                </div>
                <div className="col-xs-12 col-sm-7">
                  <span>{data.period}</span>
                  <h2>{data.title}</h2>
                  <p>{data.description}</p>
                </div>
              </div>
            </div>

            <div className="modal-footer visible-xs">
              <button
                type="button"
                className={`btn btn-light ${
                  !this.state.skip ? 'disabled' : ''
                }`}
                onClick={this.previousModal}
              >
                <i className="vehoicon-arrow-left" />
              </button>
              <button
                type="button"
                className={`btn btn-light ${
                  this.state.skip === this.props.dataSource.length - 1
                    ? 'disabled'
                    : ''
                }`}
                onClick={this.nextModal}
              >
                <i className="vehoicon-arrow-left rotate-180" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default MileStoneModal;
