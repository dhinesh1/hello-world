import React, { PureComponent } from 'react';
import { Link } from 'react-router-dom';
import { getImgIXUrl } from '../../helpers/utilsHelper';

class LifeAt extends PureComponent {
  render() {
    const { showHiring = false } = this.props;
    return (
      <section className="life-wrapper">
        <div className="container">
          <div className="clearfix">
            <h4 className="pull-left">Life at Pickyourtrail</h4>
            {showHiring ? (
              <Link
                to="/careers"
                className="btn btn-primary btn-sm pull-right hidden-xs"
              >
                We are hiring!
              </Link>
            ) : null}
          </div>
        </div>
        <div className="container xs-full-width">
          <ul className="list-unstyled">
            <li className="small-card">
              <a
                href="https://photos.google.com/share/AF1QipOJWlY1vzCGKFN8kyRwEIFtuZ6s9wD75Dtz8mkI_lqI-6AlGMpCV5cwtprBqzr2Tw?key=MThVUUdraEJ5eHNfeXFNc1lYVlZNUHNjZHFGV0Z3"
                target="_blank"
              >
                <figure
                  style={{
                    backgroundImage: `url(${getImgIXUrl(
                      'https://d3lf10b5gahyby.cloudfront.net/web_app/about/life/superhero.jpg'
                    )}`
                  }}
                >
                  <figcaption>Our Superheroes</figcaption>
                </figure>
              </a>
            </li>
            <li className="small-card">
              <a
                href="https://photos.google.com/share/AF1QipMG9qKWas1zNY4mGn_d9JtZrWiE4Elf0Jpp3T6bJK468O4xLcLiyEEKFw2GVSsIsQ?key=Rm1vMDhwc1IxdURGdS02SUpJT2xvU2xQNFRodmt3"
                target="_blank"
              >
                <figure
                  style={{
                    backgroundImage: `url(${getImgIXUrl(
                      'https://d3lf10b5gahyby.cloudfront.net/web_app/about/life/party.jpg'
                    )}`
                  }}
                >
                  <figcaption>Parties & Fun Events</figcaption>
                </figure>
              </a>
            </li>
            <li className="small-card">
              <a
                href="https://photos.app.goo.gl/MfAgozjk4YSPkb3T9"
                target="_blank"
              >
                <figure
                  style={{
                    backgroundImage: `url(${getImgIXUrl(
                      'https://d3lf10b5gahyby.cloudfront.net/web_app/about/life/sports.jpg'
                    )}`
                  }}
                >
                  <figcaption>Sports Day</figcaption>
                </figure>
              </a>
            </li>
            <li className="small-card">
              <a
                href="https://photos.app.goo.gl/eeLbmyTk1mWQJEM69"
                target="_blank"
              >
                <figure
                  style={{
                    backgroundImage: `url(${getImgIXUrl(
                      'https://d3lf10b5gahyby.cloudfront.net/web_app/about/life/festival.jpg'
                    )}`
                  }}
                >
                  <figcaption>Festivals</figcaption>
                </figure>
              </a>
            </li>
          </ul>
          <ul className="list-unstyled">
            <li>
              <a
                href="https://photos.google.com/share/AF1QipOI4DdDj_jLlEjyfp-_6QhktL_7Q-35KpIdKZ1fmzvSuzGZNJtz48gbtoUqFCRmfQ?key=QVVobnJ1WDFnNkExVWtETHpvZjVCMkJ3YVFiQmV3"
                target="_blank"
              >
                <figure
                  style={{
                    backgroundImage: `url(${getImgIXUrl(
                      'https://d3lf10b5gahyby.cloudfront.net/web_app/about/life/workspace.jpg'
                    )}`
                  }}
                >
                  <figcaption>Workspace</figcaption>
                </figure>
              </a>
            </li>
            <li>
              <a
                href="https://photos.google.com/share/AF1QipO1tnq0mVWJAihWuh0DnvJwsE1jBFYXjIpodcUSp5BGqMomtsDUw3JllY6G61a3JA?key=MUl5a3RRczFfc3kySW9QVk8xS0Y3am51cTRZbm5B"
                target="_blank"
              >
                <figure
                  style={{
                    backgroundImage: `url(${getImgIXUrl(
                      'https://d3lf10b5gahyby.cloudfront.net/web_app/about/life/customer-stories.jpg'
                    )}`
                  }}
                >
                  <figcaption>Customer Stories</figcaption>
                </figure>
              </a>
            </li>
          </ul>
        </div>
        <div className="container">
          {showHiring ? (
            <Link
              to="/careers"
              className="btn btn-primary btn-sm btn-block visible-xs"
            >
              We are hiring. Check out open positions!
            </Link>
          ) : null}
        </div>
      </section>
    );
  }
}

export default LifeAt;
