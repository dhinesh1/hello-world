import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import _ from 'lodash';
import classNames from 'classnames';
import moment from 'moment';
import { getImgIXUrl, encodeCostingKeyForURL } from '../helpers/utilsHelper';

import {itineraryModalsRouteHelper, RATE_MATCH_ACTIVITY} from '../helpers/routesHelper';

class ActivityContainer extends Component {
  static propTypes = {
    activeActivity: PropTypes.object.isRequired,
    splitPricing: PropTypes.bool,
    showThisModal: PropTypes.func,
    allowEditOptions: PropTypes.bool.isRequired,
    showImages: PropTypes.bool.isRequired
  };

  createMarkup = data => {
    if (_.isEmpty(data)) {
      data = "<p class='small'> - NA - </p>";
    }

    return { __html: data };
  };

  render() {
    if (_.isEmpty(this.props.itineraryDetail)) return null;

    const {
      activeActivity,
      itineraryDetail,
      user_details: userDetails,
      allowEditOptions,
      showImages,
      itineraryInfo,
      location
    } = this.props;
    const selectedTourGrade =
      activeActivity.activitySlotDetail.selectedTourGrade;
    const dep_slot = selectedTourGrade.startSlot;

    // Departure time - We will get the value as string 1600 for 16:00 or 04:00 pm
    // This is being used in PLATO for vouchers and other purposes 
    const dep_time = selectedTourGrade.departureTime && moment(selectedTourGrade.departureTime, "HHmm").format("hh:mm a");

    let passCostingClasses = '';
    let inComboPill = null;
    let isBooked = itineraryDetail.booking || itineraryDetail.frozen;

    let isViatorActivity =
      activeActivity.activitySlotDetail &&
      activeActivity.activitySlotDetail.selectedTourGrade.ourSourceProvider ===
        'VIATOR';
    let isCancelled =
      isViatorActivity &&
      activeActivity.activitySlotDetail.costingInfo &&
      activeActivity.activitySlotDetail.costingInfo.cancelled;

    let cancellationSpan = (
      <p>
        <span className="in-combo act-modal-position-fix">CANCELLED</span>
      </p>
    );

    if (activeActivity.activitySlotDetail.costingInfo !== undefined) {
      if (activeActivity.activitySlotDetail.costingInfo.inCombo) {
        passCostingClasses = ' strikethrough dim vmargin-small ';
        inComboPill = (
          <p>
            <span className="in-combo act-modal-position-fix">IN COMBO</span>
          </p>
        );
      } else if (activeActivity.activitySlotDetail.costingInfo.inSwissPass) {
        passCostingClasses = ' strikethrough dim vmargin-small ';
        inComboPill = (
          <p>
            <span className="in-combo act-modal-position-fix">
              IN SWISS PASS
            </span>
          </p>
        );
      }
    }

    let long_desc_innerHtml = this.createMarkup(
      activeActivity.activitySlotDetail.longDesc
    );
    let inclusion_txt = this.createMarkup(selectedTourGrade.inclusion);
    let exclusion_txt = this.createMarkup(selectedTourGrade.exclusion);

    // slot information
    let { iterDayByKey, itinerary } = itineraryInfo;
    const {itineraryId, regionCode} = itinerary;

    let activeSlot = _.find(
      iterDayByKey,
      o => _.indexOf(o.allSlotKeys, activeActivity.slotIdentifier) !== -1
    );

    const disclaimerNote = regionCode === 'mus' ? "Note: The activity date will be decided by the resort based on the number of people available. This will be informed during your check-in." : 
    (regionCode !== "eur" && regionCode !== 'mle' &&
    regionCode !== 'sey') ? 
      "Note: The starting time/activity slot timings are tentative. The final timing is allocated by the provider 24-48 hoursprior to your activity." : null

    
    return [showImages ? <div className="media-shell round-none" key={0}>
          <figure className="hd act-img" style={{ backgroundImage: `url(${getImgIXUrl(activeActivity.activitySlotDetail.mainPhoto)})` }} />
        </div> : null, <div className={classNames("modal-row ", {
          "pt-0": !showImages
        })} key={1}>
        <div className="item-header">
          <h3>{activeActivity.activitySlotDetail.title}</h3>
          <span className="p block">
            <span className="bold color-secondary schedule">
              {activeSlot ? (itineraryDetail.costed && !itineraryDetail.staleCost ? `${activeSlot.mon} ${activeSlot.day}` : `Day ${activeSlot.dayNum}`) : null}, {dep_slot}
            </span> — {selectedTourGrade.transferType === "NOTRANSFER" ? `Starts from` : `Pick up from`} {selectedTourGrade.pickupType} {dep_time && `at ${dep_time}`}
          </span>
          <p className="fs-12 color-grey meta-text">{disclaimerNote}</p>
          {/* <span className='p meta-text'></span> */}
        </div>
        <div className="at-a-glance clearfix">
          <div className="col-xs-6 col-md-3">
            <span className="meta-text dim block">Duration</span>
            {selectedTourGrade.duration}
          </div>
          <div className={"col-xs-6 " + (!(activeActivity.activitySlotDetail.costingInfo && activeActivity.activitySlotDetail.costingInfo.viator) ? "col-md-3" : "col-md-2")}>
            <span className="meta-text dim block">Transfer</span>
            {activeActivity.activitySlotDetail.transferIncluded ? "Included" : "Not included"}
          </div>
          <div className={"col-xs-6 " + (!(activeActivity.activitySlotDetail.costingInfo && activeActivity.activitySlotDetail.costingInfo.viator) ? "col-md-3" : "col-md-2")}>
            <span className="meta-text dim block">Activity type</span>
            {activeActivity.activitySlotDetail.privateTour ? "Private tour" : "Shared"}
          </div>
          {activeActivity.activitySlotDetail.costingInfo && activeActivity.activitySlotDetail.costingInfo.viator ? <div className={"col-xs-6 " + (this.props.splitPricing ? "col-md-3" : "col-md-2")}>
              <span className="meta-text dim block">Refundable?</span>
              {activeActivity.activitySlotDetail.costingInfo.refundable ? <span>
                  <span className="vehoicon-refundable color-success" /> Yes
                </span> : <span>
                  <span className="vehoicon-non-refundable color-danger" /> No
                </span>}
            </div> : null}

          {isCancelled ? <div className="col-xs-6 col-md-3">
              {cancellationSpan}
            </div> : null}

          {activeActivity.totalCost || selectedTourGrade.cost ? <div className="col-xs-6 col-md-3">
              <span className="meta-text dim block">Total cost</span>
              {/* isCancelled ? cancellationSpan : null */}
              {activeActivity.activitySlotDetail.free ? <span>
                  Self exploration
                </span> : <span className={"total-price bold opener " + passCostingClasses}>
                  <span className="WebRupee">Rs.</span> {itineraryDetail.costed && !activeActivity.isFromAlternateList ? activeActivity.totalCost : selectedTourGrade.cost}
                </span>}

              {allowEditOptions && userDetails && userDetails.loggedIn && userDetails.userType === "ADMIN" && itineraryDetail.costed && !itineraryDetail.staleCost && activeActivity.activitySlotDetail.costingInfo && !isBooked && activeActivity.activitySlotDetail.costingInfo.viator ? 
                  <a href="#" onClick={() => 
                    itineraryModalsRouteHelper({
                            itineraryId,
                            regionCode,
                            location,
                            target: RATE_MATCH_ACTIVITY,
                            customParams: {
                              activityKey: encodeCostingKeyForURL(activeActivity.activitySlotDetail.costingInfo.key),
                              called_from: 'ACTIVITY_PANEL'
                            }
                          })
                  }>
                  {" "}
                  <span className="vehoicon-mode_edit" />
                </a> : null}

              {inComboPill}
            </div> : null}
        </div>
        <hr className="no-height mute" />
        {/* <div className="pyt-nav-tab-shell anchor">
                <div className="row">
                  <div className="col-xs-12 col-sm-9">
                    <ul className="nav nav-tabs tiny-tabs">
                      <li role="presentation" className="active"><a href="#">Overview</a></li>
                      <li role="presentation"><a href="#">Feedback</a></li>
                      <li role="presentation"><a href="#">Fine Print</a></li>
                      <li role="presentation"><a href="#">Instructions</a></li>
                    </ul>
                  </div>
                </div>
              </div> */}
        <div className="spacer-both feedback">
          <h4 className="medium-heading dim">Overview</h4>
          <div className="row">
            <div className="col-xs-12 meta-text" dangerouslySetInnerHTML={long_desc_innerHtml} />
          </div>
        </div>
        <hr className="mute hide" />
        {/*<div className="spacer-both feedback hide">
                <div className="row">
                  <h4 className="dim col-xs-6">Feedback</h4>
                  <div className="col-xs-6 rating activity text-right">
                    <div><span className="vehoicon-happy2" />40%</div>
                    <div><span className="vehoicon-smile2" />20%</div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-xs-12 col-md-6 cust-feedback ">
                    <div className="cust-details">
                      <div className="dp"><img src="https://scontent.fmaa3-1.fna.fbcdn.net/v/t1.0-1/p64x64/13615280_10154796658955639_5270391872026573490_n.jpg?oh=33db289dc11617709ed10650b16460ee&oe=599A8844" /></div>
                      <span className="h6 name">Shashank Deshpande</span>
                      <time className="small dim">May 2016</time>
                    </div>
                    <p className="meta-text">Aristocrat Sailing cruise was one of the highlight experience in our trip. The cruise was really amazing and we enjoyed the water sports during the cruise.</p>
                  </div>
                  <div className="col-xs-12 col-md-6 cust-feedback">
                    <div className="cust-details">
                      <div className="dp"><img src="https://scontent.fmaa3-1.fna.fbcdn.net/v/t1.0-1/p64x64/13615280_10154796658955639_5270391872026573490_n.jpg?oh=33db289dc11617709ed10650b16460ee&oe=599A8844" /></div>
                      <span className="h6 name">Shashank Deshpande</span>
                      <time className="small dim">May 2016 <a href="#" title="View on facebook" className="secondary-link">&nbsp;<span className="vehoicon-facebook-square" /></a></time>
                    </div>
                    <p className="meta-text">Adventure Felt the water was not clear enough at Ceningan Islands. Would have preferred doing this activity on Nusa Dua beach itself instead of doing them here</p>
                    <span className="small micro fade block"><sup>*</sup> Did this activity as part of <a className="secondary-link underline">Walking tour of Ubud and neighbouring</a></span>
                  </div>
                </div>
              </div>*/}
        {activeActivity.activitySlotDetail.free ? null : <hr className="mute" />}
        {activeActivity.activitySlotDetail.free ? null : <div className="spacer-both feedback">
            <h4 className="medium-heading dim">Fine Print</h4>
            <div className="row">
              <div className="col-xs-12 col-md-6 ">
                <h6 className="main-text">Inclusions</h6>
                <div className="meta-text" dangerouslySetInnerHTML={inclusion_txt} />
              </div>
              <div className="col-xs-12 col-md-6">
                <h6 className="main-text">Exclusions</h6>
                <div className="meta-text" dangerouslySetInnerHTML={exclusion_txt} />
              </div>
            </div>
          </div>}
        <hr className="mute hide" />
        <div className="spacer-both feedback hide">
          <h4 className="medium-heading dim">Instructions</h4>
          <div className="row">
            <div className="col-xs-12 col-md-6 ">
              <p className="meta-text">- NA -</p>
              {/* <ul className="meta-text">
                      <li> - NA - </li>
                    </ul> */}
            </div>
            <div className="col-xs-12 col-md-6 ">
              {selectedTourGrade.meetingPoint !== "" ? <p className="meta-text">
                  <strong className="bold">Meeting point —</strong> {selectedTourGrade.meetingPoint}
                </p> : null}
              {/* <a href="#" className="secondary-link underline">View on map</a> */}
            </div>
          </div>
        </div>
      </div>];
  }
}

function mapStateToProps(state) {
  let app = state.app;

  if (
    app.itineraryInfo.itineraryDetails &&
    Object.keys(app.itineraryInfo.itineraryDetails).length
  ) {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: app.itineraryInfo.itineraryDetails.itinerary,
      user_details: app.user_details
    };
  } else {
    return {
      itineraryInfo: app.itineraryInfo.itineraryDetails,
      itineraryDetail: {},
      user_details: app.user_details
    };
  }
}

export default connect(mapStateToProps)(ActivityContainer);
