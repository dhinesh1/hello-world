import React, { Component } from 'react';
import classNames from 'classnames';

export default class DropDownMenu extends Component {
  constructor(props) {
    super(props);

    this.state = {
      expanded: false
    };

    this.openDropDown = this.openDropDown.bind(this);
    this.toggleDropDown = this.toggleDropDown.bind(this);
    this.closeDropDown = this.closeDropDown.bind(this);
  }

  openDropDown(e) {
    e && e.preventDefault();

    this.setState({ expanded: true });
  }

  toggleDropDown(e) {
    e && e.preventDefault();
    if (
      this.props.isCampaignPage
    ) {
      let ele = this.findParentClass(e.target, 'dropdown-menu');
      this.props.toggleFilterOpen(e, this.props.currentValue);
      if (!ele) {
        this.setState({ expanded: !this.state.expanded });
      }
    } else {
      this.setState({ expanded: !this.state.expanded });
    }
  }

  closeDropDown(e) {
    e && e.preventDefault();

    this.setState({ expanded: false });
  }

  findParentClass(el) {
    if (el.classList.contains('dropdown-menu')) {
      return true;
    } else {
      while ((el = el.parentElement)) {
        if (el.classList.contains('dropdown-menu')) {
          return true;
        }
      }
    }
  }

  render() {
    let { expanded } = this.state;
    let {
      trigger,
      triggerElement,
      history,
      showBackDrop,
      wrapperElement,
      children,
      isCampaignPage
    } = this.props;

    if (!triggerElement) {
      triggerElement = <i className="vehoicon-ion-more" />;
    }
    let TempWrapperElement = wrapperElement ? wrapperElement : 'li';
    if (isCampaignPage) {
      return (
        <TempWrapperElement
          className={classNames(this.props.wrapperClassName, {
            open: this.props.expand
          })}
          onClick={e => this.toggleDropDown(e)}
        >
          {/* {showBackDrop && expanded ? (
        <div className={'drop-down-backdrop'} onClick={this.closeDropDown} />
      ) : null} */}

          {triggerElement}
          <ul
            className={classNames({
              'dropdown-menu': true
            })}
          >
            {this.props.children}
          </ul>
        </TempWrapperElement>
      );
    } else {
      return (
        <TempWrapperElement
          className={classNames(
            {
              'pos-r': true,
              open:
                this.props.expand != undefined && this.props.expand !== expanded
                  ? this.props.expand
                  : expanded
            },
            this.props.wrapperClassName
          )}
        >
          {showBackDrop && expanded ? (
            <div
              className={'drop-down-backdrop'}
              onClick={this.closeDropDown}
            />
          ) : null}
          <a
            href="#"
            className="dropdown-toggle"
            data-toggle="dropdown"
            onClick={e => this.toggleDropDown(e)}
            onMouseEnter={e =>
              trigger && trigger === 'hover' ? this.openDropDown(e) : null
            }
          >
            {triggerElement}
          </a>
          <ul
            className={classNames(
              {
                'dropdown-menu': true,
                'dropdown-menu-right': true
              },
              this.props.wrapperDropdownClassName
            )}
          >
            {this.props.children}
          </ul>
        </TempWrapperElement>
      );
    }
  }
}
