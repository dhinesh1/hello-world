import React from 'react';
import PropTypes from 'prop-types';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';


import { AppConfig } from '../app-config';

const booking_state_alert = AppConfig.booking_state_alert;

const renderRefundability = refundability => {
  if (refundability)
    return (
      <span>
        <span className="color-success vehoicon-refundable" /> Refundable
      </span>
    );
  else
    return (
      <span>
        <span className="color-danger vehoicon-non-refundable" /> Non Refundable
      </span>
    );
};

const FerryContainer = ({ ferry, disableEditing, isBooked, onChangeClick, makeReadOnly }) => {
  // Surrounded with if to check the costing status else showing error screen
  if (ferry.status === 'SUCCESS') {
    let comboPricingMessageBox = null;
    if (ferry.inCombo) {
      comboPricingMessageBox = (
        <div className="pointing-box top">
          <span className="mini t-5 inline-block">
            Included in combo package!
          </span>
        </div>
      );
    } else if (ferry.inSwissPass) {
      comboPricingMessageBox = (
        <div className="pointing-box top">
          <span className="mini t-5 inline-block">Included in Swiss Pass!</span>
        </div>
      );
    }

    return (
      <div className="modal-row pt-0">
        <article className="row-costed-item row">
          <div className="col-xs-9 col-sm-9 col-md-8 spacer">
            <div className="costed-item-head">
              <div className="date-costed">
                <span className="month">{ferry ? ferry.mon : ''}</span>
                <span className="date">{ferry ? ferry.day : ''}</span>
              </div>
              <h5 className="no-margin semi-bold">Ferry - {ferry.text}</h5>
              <span className="small dim">{/*transfer.carTitle*/}</span>
            </div>
            <div className="costed-item-details clearfix">
              <div className="col-xs-5 col-sm-2 col-md-3 no-padding">
                <div className="media-shell">
                  <figure className="sd">
                    <img
                      src="https://pyt-images.imgix.net/images/misc/ferry.jpg"
                      alt={'ferry'}
                    />
                  </figure>
                </div>
              </div>
              <div className="col-xs-7 col-sm-9 col-md-9">
                <span className="fine-text fade color-grey">Includes:</span>
                <div className="circle-list">
                  <ul className="fine-text fade color-grey">
                    <li>
                      {ferry.departureTime && ferry.departureTime !== '' ? `Departure ${ferry.departureTime} ${ferry.pickup}` : `Pickup from ${ferry.fromCity} ${ferry.pickup}`}
                    </li>
                    <li>
                      {ferry.arrivalTime && ferry.arrivalTime !== '' ? `Arrival ${ferry.arrivalTime} ${ferry.drop}` : `Drop at ${ferry.toCity} ${ferry.drop}`}
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding">
            <li>
              <span className="vehoicon-directions_boat" /> Shared
            </li>
            <li>
              <span className="vehoicon-ion-android-time" />
              {ferry.duration} duration
            </li>
            <li> {renderRefundability(ferry.refundable)} </li>
          </ul>
          <div className="col-xs-3 col-sm-3 col-md-2 spacer">
            <div
              className={
                'action text-center ' +
                (ferry.totalCost ? ' price-info-center' : ' price-info')
              }
            >
              <span
                className={
                  'price ' +
                  (ferry.totalCost && (ferry.inCombo || ferry.inSwissPass)
                    ? ' strikethrough dim vmargin-small'
                    : '')
                }
              >
                {ferry.totalCost ? (
                  <span>
                    <span className="WebRupee">Rs.</span>
                    {ferry.totalCost}
                  </span>
                ) : null}
              </span>
              {comboPricingMessageBox}
              {disableEditing || makeReadOnly ? null : isBooked ? (
                <OverlayTrigger
                  id="ot5"
                  placement="top"
                  overlay={
                    <Tooltip id="traintooltip">{booking_state_alert}</Tooltip>
                  }
                >
                  <a
                    onClick={e => (isBooked ? null : onChangeClick(ferry, e))}
                    className={`btn btn-sm btn-primary disabled`}
                  >
                    Change
                  </a>
                </OverlayTrigger>
              ) : (
                  <a
                    onClick={e => (isBooked ? null : onChangeClick(ferry, e))}
                    className={`btn btn-sm btn-primary`}
                  >
                    Change
                </a>
                )}
            </div>
          </div>
        </article>
        <hr className="tear" />
      </div>
    );
  } else if (ferry.status === 'ERROR') {
    return (
      <div key={Math.random()}>
        <article className="row-costed-item row danger">
          <div className="col-xs-9 col-sm-9 col-md-8 spacer">
            <div className="costed-item-head">
              <div className="date-costed">
                <span className="month">{ferry.mon}</span>
                <span className="date">{ferry.day}</span>
              </div>
              <h5 className="no-margin semi-bold">{ferry.text}</h5>
              <span className="meta-text color-danger">
                Sorry, Ferry costing has failed currently. Please try after
                sometime!
              </span>
            </div>
          </div>
          <ul className="hidden-xs hidden-sm col-md-2 spacer icon-list-costing no-padding" />
        </article>
        <hr className="tear" />
      </div>
    );
  } else {
    return null;
  }
};

FerryContainer.propTypes = {
  ferry: PropTypes.object.isRequired
};

export default FerryContainer;
