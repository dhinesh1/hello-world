import { AppConfig } from '../app-config';
import _ from 'lodash';
import { triggerSimpleAjax } from '../helpers/httpHelper';
import { getCost, getUserDetails } from './actions_app';
import { USER_LOGIN_GETCOST, USER_LOGIN, trackEvent, EVENT_LOGOUT } from '../helpers/ML/EventsTracker';
import {checkIndexOf} from "../helpers/utilsHelper";

const API_URL = AppConfig.api_url;
export function login({
  req_data = {},
  isItineraryView = false,
  getCostObject = {},
  history = {},
  loginType = 'USER',
  location,
  lastLocation,
  campaignItineraryId,
  match
}) {
  let document = window.document;
  if (loginType === 'USER') {
    return dispatch =>
      new Promise((res, rej) => {
        let url = `${API_URL}user/login`;
        if (req_data.otp && !_.isEmpty(req_data.otp)) {
          url = `${API_URL}user/forgetpassword/verifyotp`;
        }

        triggerSimpleAjax(
          url,
          'POST',
          req_data,
          response => {
            if (response.status === 'SUCCESS') {
              dispatch({
                type: 'LOGIN_SUCCESS',
                payload: response.message
              });

              if(!isItineraryView){
                // General login form

                dispatch(getUserDetails({}, USER_LOGIN))
                  .then(res => {
                    let lastPathName = (
                      lastLocation || location
                    ).pathname.split('/')[1];
                    switch (lastPathName) {
                      case '':
                      case 'login':
                        if (res.userType === 'ADMIN') {
                          document.location = '/';
                        } else {
                          document.location = `/your-vacations`;
                        }
                        break;
                      default:
                        history.goBack();
                        break;
                    }
                  })
                  .catch(err => console.log(err));
              }else{
                // Login form submitted as part of get-cost process
                
                dispatch(getUserDetails({}, USER_LOGIN_GETCOST));

                if(campaignItineraryId){
                  let url = `${API_URL}itinerary/campaign/${campaignItineraryId}/assignUser`;
                  triggerSimpleAjax(
                    url,
                    'POST',
                    {},
                    response => {
                      getCostObject.itineraryId = response.data;
                      dispatch(
                        getCost({
                          itineraryId: response.data,
                          req_data: getCostObject,
                          regionCode: match && match.params.searchRegion ? match.params.searchRegion : 'region',
                          history,
                          location,
                          match,
                          lastLocation,
                          campaign: true
                        })
                      );
                    },
                    error => {
                      console.error('Got error: ', error);
                    }
                  );
                } else {
                  dispatch(
                    getCost({
                      itineraryId: getCostObject.itineraryId,
                      req_data: getCostObject,
                      regionCode: match && match.params.searchRegion ? match.params.searchRegion : 'region',
                      history,
                      location,
                      match,
                      lastLocation
                    })
                  );
                }
              }

              res('Login done');
            } else {
              dispatch({
                type: 'LOGIN_ERROR',
                payload: response.message
              });

              rej('Failed - user login');
            }
          },
          error => {
            dispatch({
              type: 'LOGIN_ERROR',
              payload: error
            });

            rej('Failed - user login');
          }
        );
      });
  } else if (loginType === 'AGENT') {
    return dispatch =>
      new Promise((res, rej) => {
        let url = `${API_URL}agent/login`;
        triggerSimpleAjax(
          url,
          'POST',
          req_data,
          response => {
            if (response.status === 'SUCCESS') {
              dispatch(getUserDetails());
              window.location = '/agent/dashboard';
            } else if (response.status === 'NOT_FOUND') {
              dispatch({
                type: 'NOT_FOUND',
                payload: response.message
              });
            } else {
              dispatch({
                type: 'LOGIN_ERROR',
                payload: response.message
              });
            }
          },
          error => {
            dispatch({
              type: 'LOGIN_ERROR',
              payload: error
            });
            rej('Failed - agent login');
          }
        );
      });
  } else {
    // console.log('check where request came from');
  }
}

export function logout({ userType, location }) {
  let document = window.document;
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}user/logout`;
      trackEvent(EVENT_LOGOUT);
      triggerSimpleAjax(
        url,
        'GET',
        {},
        () => {
          dispatch(getUserDetails());
          let root = location.pathname.split('/')[1];

          switch (userType) {
            case 'AGENT':
              document.location = `/agents/login`;
              break;
            case 'ADMIN':
              if (
                root === 'your-vacations' ||
                root === 'your-trips' ||
                root === 'account' ||
                root === 'booking-travellers' ||
                root === 'booking-review' ||
                root === 'make-payment'
              ) {
                document.location = `/`;
              } else {
                document.location.reload();
              }
              break;
            default:
              if (
                !(
                  root === 'testimonials' ||
                  root === 'about-us' ||
                  root === 'careers' ||
                  root === 'packages'
                )
              ) {
                document.location = '/';
              } else {
                document.location.reload();
              }
              break;
          }
          res('done');
        },
        error => {
          dispatch({
            type: 'LOGIN_ERROR',
            payload: error
          });

          rej('Failed - user login');
        }
      );
    });
}

export function getOTP(req_data = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}user/forgetpassword`;
      triggerSimpleAjax(
        url,
        'POST',
        req_data,
        response => {
          if (response.status === 'VERIFICATIONFAILED') {
            dispatch({
              type: 'GET_OTP_FAILED',
              payload: response
            });
          } else {
            dispatch({
              type: 'GET_OTP_SUCCESS',
              payload: response
            });
          }
          res('Promised resolved from fetch - user login');
        },
        error => {
          dispatch({
            type: 'GET_OTP_ERROR',
            payload: error
          });

          rej('Failed - user login');
        }
      );
    });
}

export function loginWithOTP(req_data = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}user/forgetpassword/verifyotp`;
      triggerSimpleAjax(
        url,
        'POST',
        req_data,
        () => {
          window.location = '/your-vacations';
        },
        error => {
          dispatch({
            type: 'VERIFY_OTP_ERROR',
            payload: error
          });

          rej('Failed - user login');
        }
      );
    });
}
