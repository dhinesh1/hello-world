import { AppConfig } from '../app-config';
import { triggerSimpleAjax } from '../helpers/httpHelper';

const API_URL = AppConfig.api_url;

// Get careers page details - Josan
export function getCareersContent(req_data = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}misc/career/page`;
      triggerSimpleAjax(
        url,
        'GET',
        req_data,
        response => {
          if(response.status === "SUCCESS"){
            dispatch({
              type: 'FETCH_CAREERS_PAGE_DETAILS',
              payload: response.data
            });
            res(response.data);
          }else{
            dispatch({
              type: 'FETCH_CAREERS_PAGE_DETAILS_ERROR',
              payload: {}
            });
            rej('Failed - careers page details');
          }
        },
        error => {
          dispatch({
            type: 'FETCH_CAREERS_PAGE_DETAILS_ERROR',
            payload: error
          });
          rej('Failed - careers page details');
        }
      );
    });
}
