import { AppConfig } from '../app-config';
import _ from 'lodash';
import { triggerSimpleAjax } from '../helpers/httpHelper';
import { is_server, getRandomValue } from '../helpers/utilsHelper';
import {
  getLeadSource,
  updateItinerarySourcePage
} from '../helpers/leadSourceHelper';
import {
  trackProfile,
  trackEvent,
  EVENT_PDG_ITINERARY_CREATED,
  EVENT_POSTCARD
} from '../helpers/ML/EventsTracker';

import {
  getGetCostingHelperRoute,
  ITINERARY_VIEW,
  itineraryModalsRouteHelper,
  INCLUSIONS_VIEW,
  ACTIVITY_ALTERNATES_DETAILS,
  COSTING_IN_PROGRESS,
  LOGIN,
  HOTEL_ALTERNATES_DETAILS,
  SIGNUP
} from '../helpers/routesHelper';
const API_URL = AppConfig.api_url;


/**
 * To check the 401 status for error
 * @param {*} error
 * @param {*} dispatch
 * @param {*} message
 */
export function check401Status(error = {}, dispatch, message) {
  if (error.response && error.response.status === 401) {
    const alerts = {
      show: true
    }
    if (message) {
      alerts.message = message
    }
    dispatch(
      manageUnAuthAlert(alerts)
    );
  }
}
/**
 * To dispatch the costing progress error
 * @param {*} error
 * @param {*} dispatch
 */
export function dispatchCostingProgressError(error, dispatch) {
  dispatch({
    type: 'COSTING_PROGRESS_ERROR',
    payload: error
  });
}
/**
 * To dispatch the costing progrss error
 * @param {*} dispatch
 * @param {*} data
 */
export function dispatchFetchItinerary(dispatch, data) {
  dispatch({
    type: 'FETCH_ITINERARY',
    payload: { itineraryDetails: data }
  })
}
// Get user details - Josan
export function getUserDetails(req_data = {}, authType = null) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}user/getUserDetails`;
      triggerSimpleAjax(
        url,
        'GET',
        req_data,
        response => {
          dispatch({
            type: 'FETCH_USER_DETAILS',
            payload: response.data
          });

          // track profile if valid auth type is passed
          authType && trackProfile(authType, response.data);

          // Set crisp chat username and email if logged in (& only crisp chat is already initialized) - Sriram
          // if (response.data.loggedIn && window.$crisp) {
          //   if (!window.$crisp.get('user:email')) {
          //     window.$crisp.push(['set', 'user:nickname', response.data.name]);
          //     window.$crisp.push(['set', 'user:email', response.data.email]);
          //   }
          // }

          res(response.data);
        },
        error => {
          dispatch({
            type: 'FETCH_USER_DETAILS_ERROR',
            payload: error
          });

          rej('Failed - user details');
        }
      );
    });
}

export function manageRegionStats(regionCode, regionName, image) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}region/stats/${regionCode}`;
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          response.data.regionName = regionName;
          response.data.image = image;
          dispatch({
            type: 'GET_COST_STATS',
            payload: response.data
          });
          res(response.data);
        },
        error => {
          // console.log(error);
          rej('Failed - stats');
        }
      );
    });
}

export function manageUnAuthAlert(newDetails) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'MANAGE_UN_AUTH',
        payload: newDetails
      });

      res('Promised resolved from fetch');
    });
}

export function manageCREDAlert(status) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'MANAGE_CRED_ALERT',
        payload: status
      });

      res('Promised resolved from fetch');
    });
}

export function fetchTestimonials(req_data) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}testimonial/getTestimonials`;
      triggerSimpleAjax(
        url,
        'POST',
        req_data,
        response => {
          dispatch({
            type: 'FETCH_TESTIMONIALS',
            payload: response.data
          });
          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_TESTIMONIALS_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function fetchDataForPDF(itineraryId) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/${itineraryId}/pdf`;
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          dispatch({
            type: 'FETCH_PDF_DATA',
            payload: response.data
          });

          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_PDF_DATA_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function fetchSearchRegions(req_data = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      dispatch({
        type: 'FETCH_SEARCH_REGIONS',
        payload: []
      });

      let url = `${API_URL}region/search`;
      triggerSimpleAjax(
        url,
        'GET',
        req_data,
        response => {
          if (response.status === 'SUCCESS') {
            dispatch({
              type: 'FETCH_SEARCH_REGIONS',
              payload: response.data
            });
          } else {
            dispatch({
              type: 'FETCH_SEARCH_REGIONS_ERROR',
              payload: [],
              message: response.message
            });
          }

          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_SEARCH_REGIONS_ERROR',
            payload: error
          });

          rej('Failed');
        }
      );
    });
}

export function getRegionDetails(regionCode) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}region/${regionCode}/info`;
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          if (response.status === 'SUCCESS') {
            dispatch({
              type: 'FETCH_REGION_DETAILS',
              payload: {
                data: response.data,
                regionCode: regionCode
              }
            });
          } else {
            dispatch({
              type: 'FETCH_REGION_DETAILS_ERROR',
              payload: [],
              message: response.message
            });
          }
          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_REGION_DETAILS_ERROR',
            payload: error
          });

          rej('Failed');
        }
      );
    });
}

export function getTopCities(pdgSelections) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}misc/getTopCities`;
      triggerSimpleAjax(
        url,
        'POST',
        pdgSelections,
        response => {
          if (response.status === 'SUCCESS') {
            dispatch({
              type: 'FETCH_TOP_CITIES',
              payload: response.data
            });
          } else {
            dispatch({
              type: 'FETCH_TOP_CITIES_ERROR',
              payload: [],
              message: response.message
            });
          }
          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_TOP_CITIES_ERROR',
            payload: error
          });

          rej('Failed');
        }
      );
    });
}

export function getThemes() {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}misc/getCategoryInterestMapping`;
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          dispatch({
            type: 'FETCH_THEMES',
            payload: response
          });

          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_THEMES_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function createItinerary(request, history) {
  return dispatch =>
    new Promise((res, rej) => {
      const {
        minDays,
        maxDays,
        buildPytItinerary = false,
        preferredMonth: month,
        region: destination_code,
        themes
      } = request;

      trackEvent(EVENT_PDG_ITINERARY_CREATED, {
        duration: minDays + ' - ' + maxDays,
        month,
        destination_code,
        is_pyt_itinerary: buildPytItinerary,
        themes
      });

      let url = `${API_URL}itinerary/create`;
      triggerSimpleAjax(
        url,
        'POST',
        request,
        response => {
          if (response.status === 'SUCCESS') {
            let itineraryId = response.data.itineraryId;
            updateItinerarySourcePage({
              page: 'PDG',
              itineraryId: itineraryId
            });

            let reUrl = itineraryModalsRouteHelper({
              itineraryId,
              regionCode: request.region
            });
            if (history) {
              history.push(reUrl);
            } else {
              window.location = reUrl;
            }
            dispatch({
              type: 'RESET_PACKAGES',
              payload: null
            });
            res('Promised resolved from fetch');
          } else {
            dispatch({
              type: 'CREATE_ITINERARY_ERROR',
              payload: response.data.response
            });
            rej('Failed');
          }
        },
        error => {
          dispatch({
            type: 'CREATE_ITINERARY_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function setMinMaxDays(minDays, maxDays) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_MIN_MAX_DAYS',
        payload: {
          cities: [],
          interests: [],
          maxDays: maxDays,
          minDays: minDays,
          preferredMonth: '',
          region: '',
          new_activities: []
        }
      });

      res('done');
    });
}

export function setMonth(month) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_MONTH',
        payload: month
      });

      res('done');
    });
}

export function setInterestIds(interestIds) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_INTEREST_IDS',
        payload: interestIds
      });

      res('done');
    });
}

export function setThemeNames(themeNames) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_THEME_NAMES',
        payload: themeNames
      });

      res('done');
    });
}

export function setThemeIds(themeIds) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_THEME_IDS',
        payload: themeIds
      });

      res('done');
    });
}

export function setRegion(region) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_REGION',
        payload: region
      });

      res('done');
    });
}

export function addCityId(cityId, cityName) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'ADD_CITY_ID_PDG',
        payload: { cityId: cityId, cityName: cityName }
      });

      res('done');
    });
}

export function removeCityId(cityId, cityName) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'REMOVE_CITY_ID_PDG',
        payload: { cityId: cityId, cityName: cityName }
      });

      res('done');
    });
}

export function removeAllCityIds() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'REMOVE_ALL_CITY_IDS_PDG',
        payload: []
      });

      res('done');
    });
}

export function setSelectedPDGCities(selectedCityIds, selectedCityNames) {
  //Used for clearing selected cities - the logic lies in the component itself
  //The component removes the selected cities and this action just sets in redux state
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_PDG_CITIES',
        payload: {
          selectedCityIds: selectedCityIds,
          selectedCityNames: selectedCityNames
        }
      });

      res('done');
    });
}

export function clearPDGSelections() {
  let initialStateObject = {
    themeNames: null,
    selectedCityNames: [],
    pdgSelections: {
      cities: [],
      interests: null,
      maxDays: null,
      minDays: null,
      preferredMonth: null,
      region: null,
      new_activities: null,
      comboId: null,
      buildPytItinerary: false
    }
  };
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'RESET_PDG_SELECTIONS',
        payload: initialStateObject
      });

      res('done');
    });
}
export function clearMLESEZ() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'FETCH_MALSEZ_HOTELS',
        payload: null
      });

      res('done');
    });
}

export function setRegionObject(region) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_REGION_OBJECT',
        payload: region
      });

      res('done');
    });
}

export function getMalSezHotel(requestObj) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/getIslandResorts`;
      dispatch({
        type: 'FETCH_MALSEZ_HOTELS',
        payload: null
      });
      triggerSimpleAjax(
        url,
        'POST',
        requestObj,
        response => {
          if (response.status === 'SUCCESS') {
            dispatch({
              type: 'FETCH_MALSEZ_HOTELS',
              payload: response.data
            });

            res('Promised resolved from fetch');
          } else {
            dispatch({
              type: 'FETCH_MALSEZ_HOTELS_ERROR',
              payload: response
            });
            rej('Failed');
          }
        },
        error => {
          dispatch({
            type: 'FETCH_MALSEZ_HOTELS_ERROR',
            payload: { status: error.response && error.response.status }
          });
          rej('Failed');
        }
      );
    });
}

export function resetItineraryDetails() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'RESET_ITINERARY',
        payload: null
      });

      res('done');
    });
}

export function getPackages(requestObj) {
  console.time('getPackages');

  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}packages`;

      triggerSimpleAjax(
        url,
        'POST',
        requestObj,
        response => {
          if (response.status === 'SUCCESS') {
            if (
              response.data &&
              !response.data.filteredItineraries &&
              !_.isEmpty(response.data.campaignItinerary)
            ) {
              dispatch({
                type: 'PACKAGE_ITINERARY',
                payload: response.data
              });
            } else {
              dispatch({
                type: 'FETCH_PACKAGES',
                payload: response.data
              });
            }

            res('Promised resolved from fetch');
          } else {
            dispatch({
              type: 'FETCH_PACKAGES_ERROR',
              payload: response
            });

            rej(response);
          }
          console.timeEnd('getPackages');
        },
        error => {
          dispatch({
            type: 'FETCH_PACKAGES_ERROR',
            payload: { status: error && error.response ?error.response.status : null }
          });
          rej(error);

          console.timeEnd('getPackages');
        }
      );
    });
}

export function getPackagesForHomePage(requestObj) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}packages/itineraries`;
      dispatch({
        type: 'FETCH_PACKAGES',
        payload: null
      });
      triggerSimpleAjax(
        url,
        'POST',
        requestObj,
        response => {
          // console.log(response.data);
          dispatch({
            type: 'FETCH_PACKAGES',
            payload: response.data
          });
          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_PACKAGES_ERROR',
            payload: error.response ? error.response.status : 'Failed'
          });
          rej('Failed');
        }
      );
    });
}

// Itinerary page actions
export function getItinerary(itineraryId, qs = null) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/${itineraryId}/details`;
      if (qs) {
        url += qs;
      }
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          if (qs) {
            dispatch(getUserDetails());
          }

          dispatchFetchItinerary(dispatch, response.data);

          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_ITINERARY_ERROR',
            payload: { status: error.response && error.response.status }
          });
          rej('Failed');
        }
      );
    });
}
export function undo(itineraryId) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/${itineraryId}/undo`;
      let data = { itineraryId: itineraryId };

      triggerSimpleAjax(
        url,
        'POST',
        data,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'FETCH_ITINERARY_ERROR',
            payload: { status: error.response && error.response.status }
          });

          rej('Failed');
        }
      );
    });
}

export function editCityModalApplyChanges(itineraryId, reqData) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/${itineraryId}/edit`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'FETCH_ITINERARY_ERROR',
            payload: { status: error.response && error.response.status }
          });
          rej('Failed');
        }
      );
    });
}

export function getCost({itineraryId, regionCode, req_data, history, lastLocation, campaign = false}) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/${itineraryId}/calculateCost`;
      req_data.leadSource = getLeadSource({
        history: history,
        lastLocation: lastLocation,
        itineraryId: itineraryId
      });

      triggerSimpleAjax(
        url,
        'POST',
        req_data,
        response => {
          dispatch({
            type: 'GET_COST_SUCCESS',
            payload: response.data
          });

          /* Google analytics event triggering starts */
          if (!is_server() && window.gtag) {
            window.gtag('event', 'get_trip_cost', {
              event_category: 'engagement',
              event_label: 'method',
              value: '0'
            });
          }
          /* Google analytics event triggering ends */

          if(campaign){
            history.push(
              getGetCostingHelperRoute({
                pathname: history.location.pathname,
                itineraryId: itineraryId,
                target: 'costing-delay'
              })
            );
          } else {
            history.push(
              itineraryModalsRouteHelper(
                {
                  itineraryId,
                  regionCode,
                  location: history.location,
                  target: COSTING_IN_PROGRESS
                }
              )
            );
          }

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch, error.response.data.message);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function checkCostingStatus(itineraryId, reqData) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/${itineraryId}/checkCostingStatus`;
      triggerSimpleAjax(
        url,
        'GET',
        reqData,
        response => {
          let comPayload = { ...response, timestamp: 1 };

          if (response.data === 'COMPLETE') {
            dispatch(getItinerary(itineraryId)).then(() => {
              dispatch({
                type: 'COSTING_PROGRESS_STATUS',
                payload: comPayload
              });

              dispatch({ type: 'RESET_PACKAGES' });
            });
          } else {
            dispatch({
              type: 'COSTING_PROGRESS_STATUS',
              payload: comPayload
            });
          }

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function changeTransferType(itineraryId, transferKey) {
  return dispatch =>
    new Promise((res, rej) => {
      let reqData = {
        itineraryId: itineraryId,
        transferKey: transferKey
      };
      let url = `${API_URL}itinerary/changetransfer`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Modified transfer in your itinerary',
          //     show_undo: true
          //   })
          // );
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function manageInterCityTransfer(reqData) {
  const { itineraryId, key, transfer, isRemove } = reqData;
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}${transfer}/${itineraryId}/${encodeURIComponent(key)}`;
      triggerSimpleAjax(
        url,
        `${isRemove ? 'DELETE' : 'PUT'}`,
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });

}

export function manageAirportTransfer(reqData) {

  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/transfer/edit`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          //if (reqData.include) {
          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Updated airport transfer in itinerary',
          //     show_undo: true
          //   })
          // );
          //}

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function updateEditableDetails(newDetails) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'REMOVE_CITY_INFO',
        payload: newDetails
      });

      res('Promised resolved from fetch');
    });
}

//Get User Profile Details for BookingTravellers Screen
export function getUserProfileDetails({ itineraryId, userType = 'USER' }) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}user/getUserProfileDetails`;
      if (userType === 'ADMIN') {
        url = `${API_URL}itinerary/${itineraryId}/getPassengerDetails`;
      }

      triggerSimpleAjax(
        url,
        userType === 'ADMIN' ? 'POST' : 'GET',
        {},
        response => {
          dispatch({
            type: 'FETCH_USER_PROFILE_DETAILS',
            payload: response.data
          });
          res('Promised resolved from fetch - user details');
        },
        error => {
          dispatch({
            type: 'FETCH_USER_PROFILE_DETAILS_ERROR',
            payload: error
          });

          rej('Failed - user details');
        }
      );
    });
}

// Reset fetched user profile details once the route change / component unmount
export function resetFetchedPassengersList() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'RESET_USER_PROFILE_DETAILS',
        payload: null
      });

      res('Promised resolved from fetch');
    });
}

//SavePassengers on Booking screen
export function savePassengers(req_data = {}, history) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}booking/savepassengers`;
      triggerSimpleAjax(
        url,
        'POST',
        req_data,
        response => {
          dispatch({
            type: 'SAVE_PASSENGERS_SUCCESS',
            payload: response
          });

          res('Promised resolved from fetch - user details');
          if (response.status === 'SUCCESS') {
            history.push(`/booking-review/${req_data.itineraryId}`);
          }
        },
        () => {
          dispatch({
            type: 'FETCH_SAVE_PASSENGERS_ERROR',
            payload: { error: 'FAILURE' }
          });

          rej('Failed - user details');
        }
      );
    });
}

export function dissolvePassengersSaved() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'DISSOLVE_PASSENGERS_SAVED',
        payload: {}
      });

      res('Promised resolved from fetch');
    });
}
export function setCounterAlert(isSweetAlert) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'SET_COUNTER_ALERT',
        payload: isSweetAlert
      });
      res('Promised resolved from fetch');
    });
}
export function getLivePrice(itineraryId) {
  return dispatch => {
    dispatch({
      type: 'CLEAR_FETCH_LIVE_ITINERARY_ERROR',
      payload: {}
    });
    let url = `${API_URL}booking/liveprice`;
    triggerSimpleAjax(
      url,
      'POST',
      { itineraryId },
      response => {
        if (response.status && response.status === 'SUCCESS') {
          response.data.livePrice = true;
          response.data.livePriceUpdated = true;
          dispatchFetchItinerary(dispatch, response.data);
        }
      },
      error => {
        dispatch({
          type: 'FETCH_LIVE_ITINERARY_ERROR',
          payload: error
        });
      }
    );
  };
}

export function resetLivePriceFlag() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'RESET_LIVE_PRICE_FLAG',
        payload: false
      });
      res('Promised resolved from fetch');
    });
}

export function generateAndSentOTP(requestObj) {
  return dispatch => {
    dispatch({
      type: 'GENERATE_ADMIN_BOOKING_OTP',
      payload: {}
    });
    let url = `${API_URL}user/admin/generateOTP/offlineBooking`;
    triggerSimpleAjax(
      url,
      'POST',
      requestObj,
      response => {
        if (response.status && response.status === 'SUCCESS') {
          dispatch({
            type: 'GENERATE_ADMIN_BOOKING_OTP_SUCCESS',
            payload: { itineraryDetails: response.data }
          });
        }
      },
      error => {
        dispatch({
          type: 'GENERATE_ADMIN_BOOKING_OTP_ERROR',
          payload: error.response.data
        });
      }
    );
  };
}

export function verifyAdminBookingOTP(requestObj) {
  return dispatch => {
    dispatch({
      type: 'VERIFY_ADMIN_BOOKING_OTP',
      payload: {}
    });
    let url = `${API_URL}user/admin/verifyOTP/offlineBooking`;
    triggerSimpleAjax(
      url,
      'POST',
      requestObj,
      response => {
        if (response.status && response.status === 'VERIFIED') {
          dispatch({
            type: 'VERIFY_ADMIN_BOOKING_OTP_SUCCESS',
            payload: response
          });
        } else {
          dispatch({
            type: 'VERIFY_ADMIN_BOOKING_OTP_ERROR',
            payload: response
          });
        }
      },
      () => {
        dispatch({
          type: 'VERIFY_ADMIN_BOOKING_OTP_ERROR',
          payload: {
            status: 'UNKNOWN_ERROR',
            message: 'Unknown error occured.'
          }
        });
      }
    );
  };
}

export function proceedWithoutBooking(requestObj) {
  return dispatch => {
    dispatch({
      type: 'ADMIN_MOVE_TO_BOOKING',
      payload: {}
    });
    let url = `${API_URL}itinerary/${
      requestObj.itineraryId
    }/changeBookingStatus`;
    triggerSimpleAjax(
      url,
      'POST',
      requestObj,
      response => {
        if (response.status && response.status === 'SUCCESS') {
          dispatch({
            type: 'ADMIN_MOVE_TO_BOOKING_SUCCESS',
            payload: response
          });
        } else {
          dispatch({
            type: 'ADMIN_MOVE_TO_BOOKING_ERROR',
            payload: response
          });
        }
      },
      () => {
        dispatch({
          type: 'ADMIN_MOVE_TO_BOOKING_ERROR',
          payload: {
            status: 'UNKNOWN_ERROR',
            message: 'Unknown error occured.'
          }
        });
      }
    );
  };
}

export function manageSoftNotification(newDetails) {
  return dispatch =>
    new Promise(res => {
      setTimeout(() => {
        dispatch({
          type: 'MANAGE_SOFT_NOTIFICATION',
          payload: newDetails
        });

        res('Promised resolved from fetch');
      }, 300);
    });
}

export function changeDeviceType(device_type) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'DEVICE_TYPE_DETECT',
        payload: device_type
      });

      res('Device type updated');
    });
}

export const updateHotel = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/hotel/updatehotel`;

      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          res('Promised resolved from fetch');

          // setTimeout(() => {
          //   dispatch(
          //     manageSoftNotification({
          //       show_notification: true,
          //       message: 'Updated hotel in itinerary',
          //       show_undo: true
          //     })
          //   );
          // }, 400);
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export const removeHotel = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/hotel/removehotel`;

      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          /**
           * TODO: Need to change the implementation
           */
          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Hotel removed from the itinerary',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export function openHotelsFromAlternates(newDetails) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'OPEN_HOTEL_DETAILS_FROM_ALTERNATES',
        payload: newDetails
      });

      newDetails.history.push(
        itineraryModalsRouteHelper({
          itineraryId: newDetails.itineraryId,
          regionCode: newDetails.regionCode,
          location: newDetails.location,
          target: HOTEL_ALTERNATES_DETAILS,
          customParams: {
            hotelCode: newDetails.selectedHotel.hotelCode,
            hotelKey: newDetails.hotelKey
          }
        })
      );

      res('Promised resolved from fetch');
    });
}

export function openActivityFromAlternates(newDetails) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'OPEN_ACTIVITY_DETAILS_FROM_ALTERNATES',
        payload: newDetails
      });

      newDetails.history.push(
        itineraryModalsRouteHelper({
          itineraryId: newDetails.itineraryId,
          regionCode: newDetails.regionCode,
          parentPage:
            newDetails.location.pathname.indexOf(ITINERARY_VIEW) > 0
              ? ITINERARY_VIEW
              : INCLUSIONS_VIEW,
          target: ACTIVITY_ALTERNATES_DETAILS,
          customParams: {
            activityKey: newDetails.activityKey,
            activityCode:
              newDetails.selectedActivity.activitySlotDetail.planningToolId
          }
        })
      );
      // `${newDetails.location.pathname}/details/${
      //   newDetails.selectedActivity.activitySlotDetail.planningToolId
      // }`

      res('Promised resolved from fetch');
    });
}

export const updateRoom = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/hotel/updateroom`;

      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          /*
           * TODO: Need to change the implementation
           */
          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Updated room in your hotel',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export function manageActivity(options) {
  // let type = options.action === 'REMOVE' ? 'REMOVE_ACTIVITY' : 'UPDATE_ACTIVITY';

  return dispatch =>
    new Promise((res, rej) => {
      let data = {
        itineraryId: options.itineraryId,
        newActivityId: options.activitySlot.activitySlotDetail.planningToolId,
        slotIdentifier: options.activitySlot.slotIdentifier,
        activityWithTransfer: options.activityWithTransfer,
        modifyType: options.action,
        fromCityId: options.fromCityId,
        toCityId: options.toCityId,
        cancelled: options.cancelled
      };

      let url = `${API_URL}itinerary/activity/remove`;
      // let notificationText = 'Removed activity from your itinerary';
      if (options.action === 'ADD') {
        url = `${API_URL}itinerary/activity/add`;
        // notificationText = 'Activity added to your itinerary';
      } else if (options.action === 'CHANGE') {
        url = `${API_URL}itinerary/activity/replace`;
        // notificationText = 'Activity updated in your itinerary';
      }

      triggerSimpleAjax(
        url,
        'POST',
        data,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: notificationText,
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function setSurnameDetails(data) {
  return dispatch =>
    dispatch({
      type: 'SET_SURNAME_DETAILS',
      payload: data
    });
}

// Visa actions
export const addVisa = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/visa/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Visa added to your itinerary',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export const removeVisa = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/visa/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Removed visa from itinerary',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export const changeVisa = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/visa/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Updated visa in itinerary',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};
// Insurance actions
export const addInsurance = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/insurance/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Added traveller insurance to your itinerary',
          //     show_undo: true
          //   })
          // );

          res('done');
        },
        error => {
          check401Status(error, dispatch);

          rej('rejected');
        }
      );
    });
};

export const removeInsurance = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/insurance/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          /*
          dispatch(
            manageSoftNotification({
              show_notification: true,
              message: 'Removed traveller insurance from itinerary',
              show_undo: true
            })
          );
          */

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export const changeInsurance = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/insurance/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Updated traveller insurance in itinerary',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export const changeRentalCar = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/${reqData.itineraryId}/changeCar`;
      delete reqData.itineraryId;

      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          /*
          dispatch(
            manageSoftNotification({
              show_notification: true,
              message: 'Updated rental car option',
              show_undo: true
            })
          );
          */

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export const changeRentalCarInsurance = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/${
        reqData.itineraryId
      }/update/carinsurance`;
      delete reqData.itineraryId;

      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Updated rental car insurance',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
};

export function getLandingPageData(packagesReqObj = null) {
  return dispatch =>
    new Promise(res => {
      if (!packagesReqObj) {
        packagesReqObj = {
          region: null,
          theme: null,
          testimonials: 10,
          journalTestimonials: true
        };
      }

      Promise.all([
        dispatch(getRecentlyBooked()),
        dispatch(getPackages(packagesReqObj))
      ]).then(function() {
        res('Promised resolved from fetch');
      });
    });
}

export function getRecentlyBooked() {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/recentlyBookedItineraries/fetch`;
      dispatch({
        type: 'FETCH_RECENTLY_BOOKED',
        payload: null
      });
      triggerSimpleAjax(
        url,
        'POST',
        {},
        response => {
          dispatch({
            type: 'FETCH_RECENTLY_BOOKED',
            payload: response.data
          });
          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'FETCH_RECENTLY_BOOKED_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function loadPaymentResponse(paymentResponse) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'PAYMENT_RESPONSE',
        payload: paymentResponse
      });
      res('Promise Resolved');
    });
}

export function processPaymentSuccess(requestObj, params={}) {
  /**
   * Extract payment type, itinerary id, transaction id from the req object params
   * Use these values to construct(join the values by '/') part of API url.
   * url value will be `/payment/verify` if no there is no req params
   */
  const { type='', itineraryid = '', transid='' } = params;
  let urlParams = [type, itineraryid, transid].join('/').replace(/\/{1,}/g, '/');
  urlParams = urlParams.length > 1 ? '/'+urlParams : '';
  return dispatch =>
    new Promise((res, rej) => {
      dispatch({
        type: 'PAYMENT_PROCESSING',
        payload: null
      });
      triggerSimpleAjax(
        `${API_URL}payment/verify${urlParams}`,
        'POST',
        requestObj,
        response => {
          dispatch({
            type: 'PAYMENT_PROCESSING',
            payload: response.data
          });

          res(response.data);
        },
        error => {
          dispatch({
            type: 'PAYMENT_PROCESSING_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function checkPaymentStatus(reqObj) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}payment/status`;
      triggerSimpleAjax(
        url,
        'POST',
        reqObj,
        response => {
          // let comPayload = { ...response };
          // console.log('Payment status res: ', response);

          // if (response.data === 'COMPLETE') {
          dispatch({
            type: 'PAYMENT_STATUS',
            payload: response
          });
          // } else {
          //   dispatch({
          //     type: 'PAYMENT_STATUS',
          //     payload: comPayload
          //   });
          // }

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function paymentFailure(requestObj) {
  // console.log('Inside paymentFailure action');
  return dispatch =>
    new Promise((res, rej) => {
      // console.log('Inside promise');
      let url = `${API_URL}payment/failure`;
      dispatch({
        type: 'PAYMENT_FAILURE',
        payload: null
      });
      triggerSimpleAjax(
        url,
        'POST',
        requestObj,
        response => {
          dispatch({
            type: 'PAYMENT_FAILURE',
            payload: response.data
          });

          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'PAYMENT_PROCESSING_ERROR',
            payload: error
          });
          // console.log(error);
          rej('Failed');
        }
      );
    });
}

export const updateTrain = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/train/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Updated your train option',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'MODIFY_TRAIN_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
};

export const changeTransferMode = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/transfer/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Updated transfer mode in itinerary',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'MODIFY_TRANSFER_MODE_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
};

export const updateFlight = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}flight/updateflight`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          res('Promised resolved from fetch');

          setTimeout(() => {
            dispatchFetchItinerary(dispatch, response.data);
          }, 300);

          /**
           * TODO: Need to change the implementation
           */
          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Updated flight in itinerary',
          //     show_undo: true
          //   })
          // );
        },
        error => {
          // console.log(error.response);

          check401Status(error, dispatch);

          dispatch({
            type: 'MODIFY_TRANSFER_MODE_ERROR',
            payload: error
          });

          rej('Failed');
        }
      );
    });
};

export const deleteFlight = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}flight/removeflight`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          /**
           * TODO: Need to change the implementation
           */
          // dispatch(
          //   manageSoftNotification({
          //     show_notification: true,
          //     message: 'Flight removed from your itinerary',
          //     show_undo: true
          //   })
          // );

          res('Promised resolved from fetch');
        },
        error => {
          // console.log(error);
          // console.log(error.response);

          check401Status(error, dispatch);

          dispatch({
            type: 'MODIFY_TRANSFER_MODE_ERROR',
            payload: error
          });

          rej(error);
        }
      );
    });
};

//RateMatch Modal Actions
export const applyHotelDiscount = requestPayload => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/${
        requestPayload.itineraryId
      }/hotel/applyRateMatch`;
      delete requestPayload.called_from;

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatch({
            type: 'APPLY_RATE_MATCH',
            payload: { itineraryDetails: response.data }
          });
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export const applyRentalCarDiscount = requestPayload => {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = requestPayload.itineraryId;
      const url = `${API_URL}itinerary/${itineraryId}/rentalCar/applyRateMatch`;

      delete requestPayload.called_from;

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatch({
            type: 'APPLY_RATE_MATCH',
            payload: { itineraryDetails: response.data }
          });
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export const applyFlightDiscount = requestPayload => {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = requestPayload.itineraryId;
      const url = `${API_URL}itinerary/${itineraryId}/flights/applyRateMatch`;
      delete requestPayload.called_from;

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatch({
            type: 'APPLY_RATE_MATCH',
            payload: { itineraryDetails: response.data }
          });
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export const updatePnrValidity = requestPayload => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}cost/flight/updatePnrValidity`;
      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatch({
            type: 'APPLY_RATE_MATCH',
            payload: { itineraryDetails: response.data }
          });
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export const applyOverallDiscount = requestPayload => {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = requestPayload.itineraryId;
      const url = `${API_URL}itinerary/${itineraryId}/applyOverallDiscount`;

      //		let newPayload = {
      //			itineraryId: itineraryId,
      //			discount: requestPayload.newPrice
      //		};

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatch({
            type: 'APPLY_RATE_MATCH',
            payload: { itineraryDetails: response.data }
          });
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export const applyActivityDiscount = requestPayload => {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = requestPayload.itineraryId;
      const url = `${API_URL}itinerary/${itineraryId}/activity/applyRateMatch`;
      delete requestPayload.called_from;

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatch({
            type: 'APPLY_RATE_MATCH',
            payload: { itineraryDetails: response.data }
          });
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export const applyAgentNetCostDiscount = requestPayload => {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = requestPayload.itineraryId;
      const url = `${API_URL}itinerary/${itineraryId}/applyAgentDiscount`;

      // let newPayload = {
      //   itineraryId: itineraryId,
      //   discount: requestPayload.discount
      // };

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatch({
            type: 'APPLY_RATE_MATCH',
            payload: { itineraryDetails: response.data }
          });
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export const changeToBooking = (action, requestPayload) => {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = requestPayload.itineraryId;
      let url = `${API_URL}itinerary/${itineraryId}/freezeItinerary`;
      if (action === 'booking') {
        url = `${API_URL}itinerary/${itineraryId}/changeBookingStatus`;
      }

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatchFetchItinerary(dispatch, response.data);
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export const applyTrainDiscount = requestPayload => {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = requestPayload.itineraryId;
      const url = `${API_URL}itinerary/${itineraryId}/train/applyRateMatch`;
      delete requestPayload.called_from;

      // let newPayload = {
      //   itineraryId: itineraryId,
      //   discount: requestPayload.discount
      // };

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatchFetchItinerary(dispatch, response.data);
          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'APPLY_RATE_MATCH_ERROR',
            payload: { error: 'failure' }
          });
          rej('Failed');
        }
      );
    });
};

export function dissolveDiscount() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'DISSOLVE_DISCOUNT',
        payload: {}
      });

      res('Promised resolved from fetch');
    });
}

export function sendEmailQuote(req_data = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = req_data.itineraryId;
      let url = `${API_URL}cost/${itineraryId}/emailQuote`;
      triggerSimpleAjax(
        url,
        'POST',
        req_data,
        response => {
          // console.log('repo, ', response);

          dispatch({
            type: 'EMAIL_QUOTE_SENT',
            payload: response
          });

          res('Promised resolved from fetch - user details');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'SEND_EMAIL_ERROR',
            payload: { error: 'fsilure' }
          });

          rej('Failed - user details');
        }
      );
    });
}

export function dissolveEmailSent() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'DISSOLVE_EMAIL_SENT',
        payload: {}
      });

      res('Promised resolved from fetch');
    });
}

export function shareItinerary(req_data = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      let itineraryId = req_data.itineraryId;
      let url = `${API_URL}itinerary/${itineraryId}/share`;
      triggerSimpleAjax(
        url,
        'POST',
        req_data,
        response => {
          dispatchFetchItinerary(dispatch, response.data);
          res('Promised resolved from fetch - user details');
        },
        error => {
          check401Status(error, dispatch);

          dispatch({
            type: 'FETCH_SHAREITINERARY_ERROR',
            payload: { error: 'failure' }
          });

          rej('Failed - user details');
        }
      );
    });
}

export function dissolveItineraryShared() {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'DISSOLVE_ITINERARY_SHARED',
        payload: {}
      });

      res('Promised resolved from fetch');
    });
}

export const loadModalLinks = modalLink => {
  return {
    type: 'LOAD_MODAL_LIST',
    payload: modalLink
  };
};

export const loadAllModalLinks = modalLinks => {
  return {
    type: 'LOAD_ALL_MODALS_LIST',
    payload: modalLinks
  };
};

export function toggleSplitPricing(requestPayload) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/${
        requestPayload.itineraryId
      }/splitpricing`;
      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function sendPostCard(req_data = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      const {
        name,
        email,
        phone,
        destination,
        date,
        adults,
        departureCity: departure_city,
        budget,
        notes
      } = req_data;
      trackEvent(EVENT_POSTCARD, {
        name,
        email,
        phone,
        destination,
        month: date,
        adults,
        departure_city,
        budget,
        notes
      });

      let url = `${API_URL}misc/getPacking`;
      triggerSimpleAjax(
        url,
        'POST',
        req_data,
        () => {
          res('Promised resolved from fetch - user details');
        },
        error => {
          dispatch({
            type: 'SEND_POSTCARD_ERROR',
            payload: error
          });

          rej('Failed - user details');
        }
      );
    });
}

export function addDayInCity(requestPayload) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/day/add`;

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          /*
          dispatch(
            manageSoftNotification({
              show_notification: true,
              message: 'Added 1 night to itinerary',
              show_undo: true
            })
          );
          */

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function removeDayInCity(requestPayload) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/day/remove`;

      triggerSimpleAjax(
        url,
        'POST',
        requestPayload,
        response => {
          dispatchFetchItinerary(dispatch, response.data);

          /*
          dispatch(
            manageSoftNotification({
              show_notification: true,
              message: 'Removed 1 night from itinerary',
              show_undo: true
            })
          );
          */

          res('Promised resolved from fetch');
        },
        error => {
          check401Status(error, dispatch);
          dispatchCostingProgressError(error, dispatch);
          rej('Failed');
        }
      );
    });
}

export function showLoginForm({requestPayload, history, preState = {}, campaign, regionCode = "region"}) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'GET_COST_LOGIN',
        payload: requestPayload
      });

      let loc = itineraryModalsRouteHelper(
        {
          itineraryId: requestPayload.itineraryId,
          regionCode,
          location: history.location,
          target: LOGIN
        }
      );

      if(campaign){
        loc = getGetCostingHelperRoute({
          pathname: history.location.pathname,
          itineraryId: requestPayload.itineraryId,
          target: LOGIN
        });
      }

      history.push({
        pathname: loc,
        state: preState
      });

      res('Promised resolved from fetch');
    });
}

export function showSignUpForm({req_data, history, campaign, regionCode = 'region'}) {
  return dispatch =>
    new Promise(res => {
      dispatch({
        type: 'GET_COST_LOGIN',
        payload: req_data
      });

      let loc = itineraryModalsRouteHelper(
        {
          itineraryId: req_data.itineraryId,
          regionCode,
          location: history.location,
          target: SIGNUP
        }
      );

      if(campaign){
        loc = getGetCostingHelperRoute({
          pathname: history.location.pathname,
          itineraryId: req_data.itineraryId,
          target: SIGNUP
        });
      }

      history.push({
        pathname: loc
      });

      res('Promised resolved from fetch');
    });
}

// Fetch call action to get career openings list
export function fetchCareers(req_payload = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}misc/careers`;
      triggerSimpleAjax(
        url,
        'GET',
        req_payload,
        response => {
          // dispatching the data got from the fetch call if only status is success
          if (response.status === 'SUCCESS') {
            dispatch({
              type: 'FETCH_CAREERS',
              payload: response.data
            });
            res(response.message);
          } else if (response.status === 'EXCEPTION') {
            rej(response.message);
          }
        },
        error => {
          rej(error.message);
        }
      );
    });
}

// Fetch call action to get career position details
export function fetchJobDetail(openingsKey = '') {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}misc/careers/${openingsKey}/details`;
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          // dispatching the data got from the fetch call if only status is success
          if (response.status === 'SUCCESS') {
            dispatch({
              type: 'FETCH_CAREERS_DETAIL',
              payload: response.data
            });
            res(response.message);
          } else if (response.status === 'EXCEPTION') {
            rej(response.message);
          }
        },
        error => {
          rej(error.message);
        }
      );
    });
}

export function itineraryAssignUser(
  itineraryId,
  newTab = false,
  preventRedirection = false,
  targetController = ''
) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}itinerary/${targetController}${itineraryId}/assignUser`;

      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          if (preventRedirection) {
            dispatch({});
            // console.log(response);
            res(response.data);
          } else {
            const reUrl = itineraryModalsRouteHelper({
              itineraryId: response.data,
              regionCode: "region"
            });

            if (newTab) {
              window.open(reUrl, '_blank');
            } else {
              window.location = reUrl;
            }

            dispatch({
              type: 'GET_USER_ASSIGNED_ITINERARY',
              payload: response.data
            });

            res('Promised resolved from fetch');
          }
        },
        error => {
          // console.log(error);
          dispatch({
            type: 'GET_USER_ASSIGNED_ITINERARY_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function updateExceesBaggageInfo(req_payload) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}flight/updatebaggageinfo`;
      triggerSimpleAjax(
        url,
        'POST',
        req_payload,
        response => {
          // console.log(response);
          response.itineraryDetails.livePrice = true;
          response.itineraryDetails.livePriceUpdated = true;
          dispatchFetchItinerary(dispatch, response.itineraryDetails);

          res('Promised resolved from fetch');
        },
        error => {
          // console.log(error);
          dispatch({
            type: 'GET_USER_ASSIGNED_ITINERARY_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function blockFlight(req_payload) {
  // console.log('Inside blockFlight function');
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}flight/${req_payload.itineraryId}/block`;
      triggerSimpleAjax(
        url,
        'POST',
        req_payload,
        response => {
          // console.log('Inside blockFlight function response: ', response);
          response.data.livePrice = true;
          response.data.livePriceUpdated = true;
          dispatchFetchItinerary(dispatch, response.data);

          res('Promised resolved from fetch');
        },
        error => {
          // console.log('Inside blockFlight function error');
          dispatch({
            type: 'GET_USER_ASSIGNED_ITINERARY_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function submitDomesticSubscriber(req_payload) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}user/signup/domesticsubscriber`;
      triggerSimpleAjax(
        url,
        'POST',
        req_payload,
        response => {
          dispatch({
            type: 'DOMESTIC_SUBSCRIBER_SUBMIT',
            payload: response.status
          });
          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'DOMESTIC_SUBSCRIBER_SUBMIT_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

/**
 * The fetchBannerImage() function returning the the promise to the redux
 * Json Endpoint is used to shown the banner images using random value.
 */
export function fetchBannerImage(req_payload) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `https://s3.ap-south-1.amazonaws.com/oceanjar-new/ui/json_static/landingImage.json`;
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          //setting and passing the random object.
          let totalLength = response.data.length;
          let index = getRandomValue(0, totalLength);
          let singleData = response.data[index];
          dispatch({
            type: 'SEO_LANDING_BANNER_IMAGE',
            payload: singleData
          });
          res('Promised resolved from fetch');
        },
        error => {
          dispatch({
            type: 'SEO_LANDING_BANNER_IMAGE_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}

export function fetchSEOMetaInfo(req_payload) {
  return dispatch =>
    new Promise((res, rej) => {
      let requestParams = req_payload || {};
      let url =
        `${API_URL}seo/mapping/fetch?seoId=` +
        requestParams.seoId +
        '&term=' +
        requestParams.term;

      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          if (req_payload.device) {
            dispatch({
              type: 'DEVICE_TYPE_DETECT',
              payload: req_payload.device
            });
          }

          // console.log(response);
          if (response.status === 'SUCCESS') {
            dispatch({
              type: 'SEO_META_DATA',
              payload: response.data
            });

            res('Promised resolved from fetch');
          } else {
            dispatch({
              type: 'SEO_META_DATA_ERROR',
              payload: response
            });

            rej('Promised resolved from fetch');
          }
        },
        error => {
          dispatch({
            type: 'SEO_META_DATA_ERROR',
            payload: error
          });
          rej('Failed');
        }
      );
    });
}
/**
 * The fetchFooterData() function returning the the promise to the redux
 * thunk that it can be used with bind action creaters.
 * It makes the api call to fetch the footers necessary data from the backed
 */
export const fetchFooterData = () => {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}misc/footer`;
      triggerSimpleAjax(
        url,
        'GET',
        {},
        response => {
          if (response.status.toUpperCase() === 'SUCCESS') {
            dispatch({
              type: 'FETCH_FOOTER_DATA',
              payload: response.data
            });
            return res();
          }
          return rej();
        },
        () => {
          rej();
        }
      );
    });
};
/**
 * Sends the update reques to change the bus transfer in inclusions
 */
export const updateBus = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/bus/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);
          res();
        },
        error => {
          check401Status(error, dispatch);
          rej();
        }
      );
    });
};
/**
 * Sends the update reques to change the ferry transfer in inclusions
 */
export const updateFerry = reqData => {
  return dispatch =>
    new Promise((res, rej) => {
      const url = `${API_URL}itinerary/ferry/modify`;
      triggerSimpleAjax(
        url,
        'POST',
        reqData,
        response => {
          dispatchFetchItinerary(dispatch, response.data);
          res();
        },
        error => {
          check401Status(error, dispatch);
          rej();
        }
      );
    });
};

export const fetchItinerary = response => {
  return dispatch => {
    response.data.livePrice = true;
    response.data.livePriceUpdated = true;
    dispatchFetchItinerary(dispatch, response.data);
  };
}

export const getPreferencesContent = reqData => {
  return dispatch => new Promise((res, rej) => {
    triggerSimpleAjax(
      `${API_URL}user/preferences?hash=${reqData}`,
      'GET',
      reqData,
      response => {
        if(response.status === 'SUCCESS') {
          dispatch({
            type: 'UPDATE_UNSUBSCRIBE_DATA',
            payload: response.data
          });
        }
        res(response.data);
      },
      error => {
        check401Status(error, dispatch);
        rej(error);
      }
    );
  });
}
