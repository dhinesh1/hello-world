import { AppConfig } from '../app-config';
import { triggerSimpleAjax } from '../helpers/httpHelper';

const API_URL = AppConfig.api_url;

// Get user details - Josan
export function getSitemapData(req_data = {}) {
  return dispatch =>
    new Promise((res, rej) => {
      let url = `${API_URL}misc/getSiteMap`;
      triggerSimpleAjax(
        url,
        'GET',
        req_data,
        response => {
          dispatch({
            type: 'FETCH_SITEMAP_DETAILS',
            payload: response.data
          });
          res(response.data);
        },
        error => {
          dispatch({
            type: 'FETCH_SITEMAP_DETAILS_ERROR',
            payload: error
          });
          rej('Failed - sitemap details');
        }
      );
    });
}
