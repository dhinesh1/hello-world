import React from 'react';
import ReactDOM from 'react-dom';
import { LastLocationProvider } from 'react-router-last-location';

import 'react-datepicker/dist/react-datepicker.css';
import 'react-select/dist/react-select.css';
import 'sweetalert/dist/sweetalert.css';

import 'react-phone-number-input/rrui.css';
import 'react-phone-number-input/style.css';
import './App.css';

import App from './App';

import registerServiceWorker from './registerServiceWorker';
import Loadable from 'react-loadable';
import { Provider as ReduxProvider } from 'react-redux';
import { store, history } from './store/configureStore';
import { ConnectedRouter } from "connected-react-router";

// Create store object
// const {store, history} = configureStore();

// const context = {};
const AppBundle = (
  <ReduxProvider store={store}>
    <ConnectedRouter history={history}>
      <LastLocationProvider>
        <App />
      </LastLocationProvider>
    </ConnectedRouter>
  </ReduxProvider>
);

window.onload = () => {
  Loadable.preloadReady().then(() => {
    ReactDOM.hydrate(AppBundle, document.getElementById('root'));
  });
};

registerServiceWorker();
