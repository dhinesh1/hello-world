export const getPayemntUsereResponse = (
  status = true,
  currentStatus = 'FAILURE'
) => {
  return {
    match: {
      path: '/payment/processing',
      url: '/payment/processing',
      isExact: true,
      params: {}
    },
    location: {
      pathname: '/payment/processing',
      search: '',
      hash: ''
    },
    history: {
      length: 33,
      action: 'POP',
      location: {
        pathname: '/payment/processing',
        search: '',
        hash: ''
      }
    },
    isFetching: false,
    hasError: false,
    error: {},
    paymentResponse: {},
    paymentProcessing: {
      txnId: '311216450',
      itinerary: null,
      status: null,
      amount: '266731.00',
      itineraryId: '5bf3bcab54ba0135b2acdb0e',
      paymentCurrency: 'INR',
      regionName: null
    },
    paymentStatus: status
      ? {
          status: 'SUCCESS',
          message: 'Unexpected source',
          paymentStatus: currentStatus,
          paidAmount: 1000000,
          timestamp: 1542700364467,
          regionCode: 'aus',
          transactionId: 'OCEANJAR_ay9zM0YWch',
          itineraryId: '5bf3bcab54ba0135b2acdb0e'
        }
      : null,
    actions: {}
  };
};
