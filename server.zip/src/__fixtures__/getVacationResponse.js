const getVacation = {
  campaignDetails: {
    key: 'vacations/australia',
    region: 'australia',
    regionCode: 'aus',
    bannerText:
      'Customize your Australia package aligned with your best interests',
    image:
      'https://d3lf10b5gahyby.cloudfront.net/campaign_paid/banner/australia-1.jpg',
    logoUrl:
      'https://d3lf10b5gahyby.cloudfront.net/campaign_paid/aus_logo_v2.png',
    seoDetails: {
      _id: '5ac76c64914130449465d5fd',
      seoId: 'AUSTRALIA_DESTINATION',
      metaTitle:
        'Australia Packages, Australia Tour Packages, Holidays in Australia',
      metaDescription:
        'Australia tour packages - Experience Australia with amazing and budget friendly tour packages. Great deals available on Australian land packages, family tours, honeymoon tours and Australia adventure packages.',
      h1Title: 'Amazing Australia Holiday & Honeymoon Packages - Book now!',
      seoContent:
        '<h3>Australia Vacation & Tours</h3>\n<p>The land of kangaroos and the vast outbacks, Australia has been romanticized by travellers across the world. Surrounded by the Indian and the Pacific ocean, Australia\'s iconic cities such as Sydney, Melbourne and Adelaide have left vivid imagery in the minds of travellers. The country\'s famed Great Barrier Reef and vast Outbacks top the list of <a href="https://pickyourtrail.com/guides/australia/activities">Australia\'s tourist attractions</a>. Australia has it all - adventure, leisure, romantic spots. Book an awesome Australia tour package for yourself!</p>\n\n<h3>Australia Tour Packages</h3>\n<p>Australia is the heartland of adventure and is a great place to explore nature, cuisines, watersports, drive through holidays, hikes, star-gazing, skiing, food and wine, you name it and Australia has it. It\'s not surprising that this country is the <a href="https://blog.pickyourtrail.com/destinations/">most popular tourist destination</a>. \nThe country is awesome in so many different ways. To start with, did you know there are more than 10,000 <a href="https://blog.pickyourtrail.com/10-best-australian-beaches/">beaches in Australia</a>? Start with Bondi beach and go on to the 75 mile long beach, tick off leisure on your Australia tour package. The Sydney Opera House, Melbourne Cricket Stadium and the Sydney Harbour are must-visit iconic places. A most popular to-do that is an essential on all Australia tour packages are the food and wine tours to popular vineyards like Barossa.</p>\n\n<h3>Best time to go to Australia</h3>\n<p>Australia is a huge country and the weather varies across different states. However on the whole, December to February is summer while June to August is Winter in Australia. Cities like <a href="https://pickyourtrail.com/guides/adelaide">Adelaide</a> experience a spike in temperature in the summer months, but can be visited for most part of the year. <a href="https://pickyourtrail.com/guides/melbourne">Melbourne</a> on the other hand experiences extreme cold weather, but can be visited if you are armed with winter clothing. Australia is a year long destination as long as you plan the right cities at the right time. </p>\n\n<h3>What you should know about planning a trip to Australia?</h3>\n<p>From the wild outbacks, Australian Fashion Week to Ashes test matches at Melbourne, Australia is a study in contrast and has a lot to offer. If that\'s where you are headed to next, there are a few points that must be kept in mind. It is always advisable to do a bit of research to be sure of what is to be expected from the trip. Highlighting some of the crucial points that will be helpful for a hassle-free Australian trip planning.</p>\n\n<h6>Getting a Visa for Australia</h6>\n<p>Tourists who are from New-Zealand do not require a visa for the Australian travel. Apart from that, every traveler should avail the visa for the trip. It is advisable to get the visa process started atleast a month in advance in anticipation of processing delays.</p>\n\n<h6>Best suggested timing & places</h6>\n<p>\n* <a href="https://pickyourtrail.com/guides/sydney">Sydney</a> and Melbourne can be covered from December-February where, the weather conditions are warm.</br>\n* Queensland is best suggested for a visit in the months of June-August</br>\n* The hot desert regions of <a href="https://pickyourtrail.com/guides/uluru">Uluru</a> can be visited in the winter time, i.e from June-August.</p>\n\n<h6>Know where to go</h6>\n<p>Australia has ample number of spots exhibiting awesomeness of their own kind. Some of the spots the travellers can check out during the visit.</br></br>\n* Travellers who enjoy good coffee, lively pubs, artistic galleries and bookshops should head straight to Melbourne.</br>\n* Sydney stands out for the surf beaches, top-rated restaurants, trendy bars and much more.</br>\n* Nature addicts will enjoy a visit to Australia\'s national parks; Kakadu, Northern Territory at Uluru-Kata Tjuta, Central Australia.</br>\n* A bit of snorkelling in the outer region of Great Barrier Reef in Queensland would be grand.</br>\n</p>\n\n<p>Follow the above mentioned know-hows related to your Aussie trip and have a legendary one by booking your trip with Pickyourtrail.</p>\n\n<h3>Also read-</h3>\n<p><a href="https://pickyourtrail.com/guides/australia">Smart traveller\'s guide to Australia</a></p>\n<p><a href="https://blog.pickyourtrail.com/top-8-australian-wine-trails/">Top 8 Australian wine trails</a></p>\n<p><a href="https://blog.pickyourtrail.com/australian-visa-online-application-for-indians/">Australia Announces Online Visa Application for Indians</a></p>\n<p><a href="https://blog.pickyourtrail.com/10-lifesaving-phone-apps-while-in-australia/">10 Lifesaving phone apps while in Australia</a></p>',
      pageUrl: 'https://pickyourtrail.com/packages/australia',
      addMetaNoFollow: false,
      h1TitleDisplay: 'Australia Packages'
    },
    faqDetails: [
      {
        questionNo: 1,
        question: 'When is the best time to travel to Australia?',
        answer:
          'Australia is good to visit all year round, if you choose the cities well. Being a vast continent, different cities have varied weather conditions. June to August is when winter hits Australia, while the summer months are December to February. Some cities such as Adelaide are quite hot during summer, yet can be visited in the rest of the months.Melbourne experiences extreme cold weather during the winter months, so remember to take winter clothing along. '
      },
      {
        questionNo: 2,
        question: 'What is the ideal duration of stay here?',
        answer:
          "Australia is a vast continent that needs time to do justice to. A 9 day vacation would let you cover atleast 3 cities and is the minimum time you should spend on an Aussie vacation. A 12 day vacation would ideally be one that would let you explore a bit of the outbacks and maybe even the Great Barrier Reef. It's once in a lifetime, so go on and take that vacation!"
      },
      {
        questionNo: 3,
        question: 'What is the Visa process for Indians?',
        answer:
          'The best part of taking an Australia vacation? An easy online visa application! But do take care and keep aside a month, as the Visa processing time may vary anywhere between 16 - 30 working days. '
      },
      {
        questionNo: 4,
        question: 'Do I need insurance while travelling to Australia?',
        answer:
          'Yes. You will need insurance if you are to visit Australia. Ensure, you have the needful medical and travel insurance in hand. Our Australian experts will give you more insights on the same. Contact them at +91 9731940739.'
      },
      {
        questionNo: 5,
        question: 'What credit cards can I use in Australia?',
        answer:
          'You can make use of the commonly accepted credit cards such as - American Express, Bankcard, Diners Club, MasterCard, Visa and JCB.'
      }
    ],
    paid: true
  },
  filteredItineraries: [
    {
      campaignItineraryId: '5c39c87aa4c6667e275be4a6',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/cityImages/330/queenstown-1.jpg',
      title: '16 nights in queenstown',
      destinationString: 'Queenstown, Auckland, Sydney and Gold Coast',
      departureCity: 'Outside India',
      departureAirport: '$$$',
      itineraryCost: 222572.25,
      hotelStarRating: 3.0,
      nights: 16,
      slug: 'packages/16-nights-in-queenstown',
      metadata: { title: '', description: '' },
      themes: ['LEISURE', 'ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia New Zealand',
      regionCode: 'anz',
      activities: [
        'Best of Auckland City Highlights with visits to Queen Street and other places',
        'Exploring the beauty of fiord and surrounding arenas during Milford Sound Cruise - Admissions included',
        'Exciting skyline gondola with admissions included',
        'Experience Waitomo Glowworm Caves on the way to Taupo - Admissions included',
        'Queenstown Mall and dining at Fergburger',
        'A dig into the history of rocks and pubs via walking tour',
        'Sandy memories at Karekare Beach Auckland',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Indoor Skydiving - Gold Coast',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Self Exploration - Visiting the charming and quaint towns of Arrowtown and Queenstown',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Visit to Auckland Botanic Gardens',
        'Queenstown Free Walking Tour',
        'Explore Auckland Sky tower by Evening - Admission Tickets',
        'Sydney Twilight Tour by Helicopter',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Taronga Zoo Sydney Admissions',
        'Morning Whale Watching Cruise'
      ],
      cityHotelStay: [
        { cityId: 330, cityName: 'Queenstown', hotelIds: [15106], nights: 4 },
        { cityId: 4, cityName: 'Auckland', hotelIds: [15106], nights: 4 },
        { cityId: 104, cityName: 'Sydney', hotelIds: [46321], nights: 4 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: [46321], nights: 4 }
      ],
      flightsIncluded: false,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bd95228ecd3d728f8aeaa6e',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648733-4.jpg',
      title:
        'Enjoy the scenic and wild-side of Australia with family fantastic',
      destinationString: 'Brisbane, Cairns, Adelaide and Gold Coast',
      departureCity: 'Ahmedabad',
      departureAirport: 'AMD',
      itineraryCost: 222572.25,
      hotelStarRating: 4.0,
      nights: 8,
      slug:
        'packages/enjoy-the-scenic-and-wild-side-of-australia-with-family-fantastic',
      metadata: { title: '', description: '' },
      themes: ['LEISURE', 'KID_FRIENDLY'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Happy day out at the Kangaroo Island with a fun tour amidst natural highlights ',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Cairns Jet Boat Ride',
        'Cairns by Night Walking Tour including Cairns Wildlife Dome and Cairns Night Markets',
        'Brisbane City Sightseeing Afternoon Tour',
        'Brilliant views from the wheel of Brisbane exposed to the best arenas and vistas of Brisbane'
      ],
      cityHotelStay: [
        { cityId: 115, cityName: 'Brisbane', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 2 },
        { cityId: 259, cityName: 'Adelaide', hotelIds: null, nights: 2 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 1 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb3052ecd3d7235f88046e',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/643370-57.jpg',
      title: 'Leisure vacation to Australia with family',
      destinationString: 'Sydney, Gold Coast, Cairns and Melbourne',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 211764.0,
      hotelStarRating: 4.5,
      nights: 13,
      slug: 'packages/leisure-vacation-to-australia-with-family',
      metadata: { title: '', description: '' },
      themes: ['KID_FRIENDLY'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Green Island Reef Cruise with Semi Submarine tour',
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Blue Mountains Scenic Tour & River Cruise',
        'Gold Coast 3 Day Theme Park Pass with transfers',
        'Car hire for Great Ocean Road'
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 4 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb2cccecd3d7235f880372',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/645302-4.jpg',
      title: 'Classic Australian itinerary to explore with family',
      destinationString: 'Melbourne, Gold Coast, Cairns and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 243058.5,
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'packages/classic-australian-itinerary-to-explore-with-family',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION', 'KID_FRIENDLY'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Admissions for Dreamworld and WhiteWater World',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Great Barrier Reef Experience',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park '
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb07c0ecd3d7235f87f435',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/634832-4.jpg',
      title: 'Romance reloaded: Australian honeymoon getaway',
      destinationString: 'Sydney, Melbourne, Cairns and Gold Coast',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 184281.5,
      hotelStarRating: 4.5,
      nights: 12,
      slug: 'packages/romance-filled-australian-honeymoon-break',
      metadata: { title: '', description: '' },
      themes: ['NATURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Flecker Botanical Gardens',
        'Green Island Reef Cruise with Semi Submarine tour',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Scenic flight experience at Gold Coast',
        'Blue Mountains Scenic Tour & River Cruise',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb059becd3d7235f87f35c',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/634441-4.jpg',
      title: 'Blissfully yours: Romantic Australian vacation',
      destinationString: 'Sydney, Cairns and Melbourne',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 162574.5,
      hotelStarRating: 4.0,
      nights: 9,
      slug: 'packages/blissfully-yours-romantic-australian-vacation',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Big Cat Green Island with Semi Submarine',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park '
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcabab1ecd3d7235f87c640',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/645920-4.jpg',
      title: 'Adventure bound Australian venture',
      destinationString: 'Sydney, Cairns and Gold Coast',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 218913.5,
      hotelStarRating: 4.0,
      nights: 9,
      slug: 'packages/adventure-bound-australian-venture',
      metadata: { title: '', description: '' },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Jet Boat Ride from Main Beach',
        'Bungy jumping from 165 ft distance at Cairns',
        'Great Barrier Reef Experience',
        'Sydney Harbour Jet Boat Thrill Ride: 30 Minutes',
        'Byron Bay Tandem Skydiving',
        'Sydney Harbour Bridge Climb - Sampler'
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e8f5ecd3d7235f879401',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648751-4.jpg',
      title: 'Explore the best of Australia with your soulmate',
      destinationString: 'Gold Coast and Melbourne',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 126168.0,
      hotelStarRating: 3.0,
      nights: 7,
      slug: 'packages/the-ultimate-australian-adventure-itinerary',
      metadata: { title: '', description: '' },
      themes: ['LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Grand Barossa Valley Day Tour',
        'Happy day out at the Kangaroo Island with a fun tour amidst natural highlights ',
        'Eureka Skydeck 88',
        'Sydney Harbour Jet Boat Thrill Ride: 30 Minutes',
        'Melbourne scenic helicopter tour with views of St. Kilda beach and Eureka Tower',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney City Sights and Bondi Beach Afternoon Tour'
      ],
      cityHotelStay: [
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 4 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e825ecd3d7235f879378',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/643368-57.jpg',
      title: 'Best of Australian adventure for all age groups',
      destinationString: 'Cairns and Gold Coast',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 160550.5,
      hotelStarRating: 4.0,
      nights: 6,
      slug: 'packages/best-of-australian-adventure',
      metadata: { title: '', description: '' },
      themes: ['ADVENTURE', 'KID_FRIENDLY'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Admissions for Dreamworld and WhiteWater World',
        'Natural Bridge and World Heritage Springbrook National Park Tour',
        'Currumbin Wildlife Sanctuary',
        'Big Cat Green Island with Semi Submarine',
        "Hartley's Crocodile Adventure Half-Day Tour",
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park'
      ],
      cityHotelStay: [
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e808ecd3d7235f87936f',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/wormcave.jpg',
      title: 'The perfect Australian honeymoon itinerary to fall in love with',
      destinationString:
        'Melbourne, Apollo Bay, Melbourne, Cairns, Port Douglas, Gold Coast and Sydney',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 170534.5,
      hotelStarRating: 4.0,
      nights: 15,
      slug:
        'packages/the-perfect-australian-honeymoon-itinerary-to-fall-in-love-with',
      metadata: { title: '', description: '' },
      themes: ['LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Eureka Skydeck 88',
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Great Barrier Reef Experience',
        'Gold Coast glow worm tour exposed to the ever beautiful glow worms and other natural works',
        'Kuranda Scenic Railway Up and Skyrail Rainforest Cableway Down'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 793, cityName: 'Apollo Bay', hotelIds: null, nights: 1 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 1 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 2 },
        { cityId: 779, cityName: 'Port Douglas', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 2 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e454ecd3d7235f87914a',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648930-4.jpg',
      title: 'Discover the adventurous side of Australia with your better half',
      destinationString: 'Cairns, Sydney and Melbourne',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 203324.5,
      hotelStarRating: 4.0,
      nights: 9,
      slug:
        'packages/discover-the-adventurous-side-of-australia-with-your-better-half',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        ' Good views of Opera House during dinner cruise in Sydney showboat',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney Harbour Bridge Climb - Sampler'
      ],
      cityHotelStay: [
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9b875ecd3d7235f8776eb',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/penguins_99177-1600x1200.jpg',
      title: 'Celebrate friendship: An exciting Australian adventure',
      destinationString: 'Melbourne, Cairns, Gold Coast and Sydney',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 264455.5,
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'packages/celebrate-friendship-an-exciting-australian-adventure',
      metadata: { title: '', description: '' },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Hot Air Ballooning from the Gold Coast',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Bungy jumping from 165 ft distance at Cairns',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Big Cat Green Island with Semi Submarine',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Gold Coast 3 Day Theme Park Pass',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb7119462ab876e1575be98',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632549-4.jpg',
      title: 'Refresh and rejoice: Tour Australia the stylish way',
      destinationString:
        'Hobart, Melbourne, Brisbane, Gold Coast, Sydney and Adelaide',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 257383.5,
      hotelStarRating: 3.5,
      nights: 15,
      slug:
        'packages/rejunavation-time-15-nights-itinerary-to-hobart-melbourne-brisbane-gold-coast-sydney-and-adelaide',
      metadata: { title: '', description: '' },
      themes: ['ADVENTURE', 'LEISURE'],
      tripType: 'Friends',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Adelaide Hills Tour and Murray River Cruise',
        'A dig into the history of rocks and pubs via walking tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Gold Coast Sightseeing Cruise - Palazzo Versace, Sea World and the Marina Mirage resort complex',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Sydney Twilight Tour by Helicopter',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Taronga Zoo Sydney Admissions',
        'Morning Whale Watching Cruise',
        'Brilliant views from the wheel of Brisbane exposed to the best arenas and vistas of Brisbane',
        'Hop On Hop Off Hobart City Sightseeing Tour'
      ],
      cityHotelStay: [
        { cityId: 140, cityName: 'Hobart', hotelIds: null, nights: 2 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 115, cityName: 'Brisbane', hotelIds: null, nights: 2 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 259, cityName: 'Adelaide', hotelIds: null, nights: 2 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb7109d62ab876e1575bd93',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632546-4.jpg',
      title: '12 nights itinerary covering top attractions in Australia',
      destinationString:
        'Hobart, Melbourne, Sydney, Airlie Beach and Gold Coast',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 276183.0,
      hotelStarRating: 3.5,
      nights: 12,
      slug:
        'packages/12-nights-itinerary-covering-top-attractions-in-hobart-melbourne-sydney-airlie-beach-and-gold-coast',
      metadata: { title: '', description: '' },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'A dig into the history of rocks and pubs via walking tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Natural Bridge and World Heritage Springbrook National Park Tour',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Sydney Twilight Tour by Helicopter',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Taronga Zoo Sydney Admissions',
        'Morning Whale Watching Cruise',
        'Ripleys Believe It Or Not Surfers Paradise Tickets',
        'Hop On Hop Off Hobart City Sightseeing Tour'
      ],
      cityHotelStay: [
        { cityId: 140, cityName: 'Hobart', hotelIds: null, nights: 2 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 840, cityName: 'Airlie Beach', hotelIds: null, nights: 1 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb70e1d62ab876e1575bb9b',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632548-4.jpg',
      title:
        "Happy Oz memories: Australia's ultimate adventure and leisure itinerary",
      destinationString:
        'Hobart, Melbourne, Brisbane, Gold Coast, Sydney and Adelaide',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 257651.5,
      hotelStarRating: 3.5,
      nights: 15,
      slug:
        'packages/make-happy-memories-15-nights-itinerary-to-hobart-melbourne-brisbane-gold-coast-sydney-and-adelaide',
      metadata: { title: '', description: '' },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Adelaide Hills Tour and Murray River Cruise',
        'A dig into the history of rocks and pubs via walking tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Gold Coast Sightseeing Cruise - Palazzo Versace, Sea World and the Marina Mirage resort complex',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Sydney Twilight Tour by Helicopter',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Taronga Zoo Sydney Admissions',
        'Morning Whale Watching Cruise',
        'Brilliant views from the wheel of Brisbane exposed to the best arenas and vistas of Brisbane',
        'Hop On Hop Off Hobart City Sightseeing Tour'
      ],
      cityHotelStay: [
        { cityId: 140, cityName: 'Hobart', hotelIds: null, nights: 2 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 115, cityName: 'Brisbane', hotelIds: null, nights: 2 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 259, cityName: 'Adelaide', hotelIds: null, nights: 2 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb70c3f62ab876e1575baab',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/643901-57.jpg',
      title: 'Magical 11 nights itinerary to the amazing parts of Australia',
      destinationString: 'Melbourne, Cairns, Adelaide and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 206753.5,
      hotelStarRating: 4.5,
      nights: 11,
      slug:
        'packages/magical-11-nights-itinerary-to-melbourne-cairns-adelaide-and-sydney',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Happy day out at the Kangaroo Island with a fun tour amidst natural highlights ',
        'Eureka Skydeck 88',
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Scenic Hot Air Balloon Flight',
        'Melbourne cricket ground tour - Admissions',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Blue Mountains Scenic Tour & River Cruise',
        'Sydney Harbour Highlights Cruise',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        'Car hire for Great Ocean Road',
        'Cairns 7,000ft Tandem Skydive'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 259, cityName: 'Adelaide', hotelIds: null, nights: 2 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb6f5ed62ab876e1575a7cd',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/philipislands.jpg',
      title: "UnDiscover the all time enchanting Australia's artistic side",
      destinationString: 'Melbourne, Cairns, Gold Coast and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 211454.5,
      hotelStarRating: 4.0,
      nights: 12,
      slug:
        'packages/undiscover-the-all-time-enchanting-australias-artistic-side-a-12-nights-itinerary-for-your-ultimate-break',
      metadata: { title: '', description: '' },
      themes: ['ART_AND_CULTURE'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Big Cat Green Island with Semi Submarine',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb6f08662ab876e1575a54e',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/634441-4.jpg',
      title: 'Get dazzled with the 14 nights Australian Outback itinerary',
      destinationString:
        'Cairns, Gold Coast, Byron Bay, Sydney, Leura, Sydney and Hobart',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 232627.0,
      hotelStarRating: 4.0,
      nights: 14,
      slug:
        'packages/get-dazzled-with-the-14-nights-australian-outback-itinerary-get-dazzled-with-the-14-nights-australian-outback-itinerary',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'A dig into the history of rocks and pubs via walking tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Hot Air Ballooning from the Gold Coast',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Australian Outback Spectacular show',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 841, cityName: 'Byron Bay', hotelIds: null, nights: 1 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 831, cityName: 'Leura', hotelIds: null, nights: 1 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 1 },
        { cityId: 140, cityName: 'Hobart', hotelIds: null, nights: 2 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb6eeaa62ab876e1575a3ec',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/611239.jpg',
      title: '13 night Australian wildlife itinerary for exciting travels',
      destinationString:
        'Melbourne, Cairns, Port Douglas, Gold Coast and Adelaide',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 284425.0,
      hotelStarRating: 4.5,
      nights: 13,
      slug:
        'packages/wildlife-infested-13-night-australian-itinerary-for-happy-travels',
      metadata: { title: '', description: '' },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Visit the 2,500 rare animals and lush green locations at Adelaide Zoo - Admission',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Learn about Atherton Tablelands Wildlife Tour amidst tropical rainforest',
        'Savannah Walkabout Australian Animals Eco Tour',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Cairns Sunset Cruise along Trinity Inlet exposed to mesmerising views of sea and land arenas',
        'Kuranda Scenic Railway Up and Skyrail Rainforest Cableway Down'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 779, cityName: 'Port Douglas', hotelIds: null, nights: 2 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 2 },
        { cityId: 259, cityName: 'Adelaide', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb6243462ab876e15756dae',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632762-57.jpg',
      title:
        ' Australian tales: Your best pick for culinary, wildlife and nature must visits',
      destinationString: 'Perth, Uluru, Sydney and Hobart',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 188723.0,
      hotelStarRating: 3.0,
      nights: 11,
      slug:
        'packages/venture-out-of-the-ordinary-with-the-perfect-11-day-australian-itinerary',
      metadata: { title: '', description: '' },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Port Arthur, Richmond and Tasman Peninsula Day Trip from Hobart',
        'Tour of Uluru to embrace its cultural side and venturing into Mutitjulu Waterhole ',
        'Hunter Valley Wine and Cheese Tasting Tour',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Mountain, National Park & Waterfalls Full-Day Tour',
        'Rottnest Island Ferry Transfers',
        'Peel Zoo Entry'
      ],
      cityHotelStay: [
        { cityId: 168, cityName: 'Perth', hotelIds: null, nights: 3 },
        { cityId: 631, cityName: 'Uluru', hotelIds: null, nights: 2 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 140, cityName: 'Hobart', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b81615262ab875a6cef81ea',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632545-4.jpg',
      title:
        'Kindling the romantic side of you : Your perfect Australia itinerary',
      destinationString: 'Brisbane, Gold Coast, Melbourne and Sydney',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 202238.0,
      hotelStarRating: 4.0,
      nights: 8,
      slug: 'packages/kindling-the-lovely-in-you-a-perfect-australia-itinerary',
      metadata: { title: '', description: '' },
      bookedString: 'Someone from Delhi booked this 149 days ago',
      themes: ['ATTRACTION', 'KID_FRIENDLY'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        ' Good views of Opera House during dinner cruise in Sydney showboat',
        'Gold Coast 3 Day Theme Park Pass'
      ],
      cityHotelStay: [
        { cityId: 115, cityName: 'Brisbane', hotelIds: null, nights: 1 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 2 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 2 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b56ff6862ab874b9bdff70b',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/646438-4.jpg',
      title: 'Celebrate love in the Australian lands',
      destinationString: 'Sydney, Gold Coast and Melbourne',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 160122.5,
      hotelStarRating: 4.0,
      nights: 7,
      slug:
        'packages/an-ideal-7-night-australia-itinerary-for-a-honeymoon-getaway',
      metadata: { title: '', description: '' },
      bookedString: 'Someone from Delhi booked this 181 days ago',
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Delicious dinner cruise during sunset at Sydney Harbour exposed to amazing vistas and views around the arena ',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Morning Whale Watching Cruise',
        'Car hire for Great Ocean Road'
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 2 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 2 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b518ad262ab8740da52086f',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/645918-4.jpg',
      title: 'An awesome 12 day Australia itinerary for honeymooners',
      destinationString: 'Melbourne, Gold Coast, Cairns and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 174412.0,
      hotelStarRating: 4.0,
      nights: 11,
      slug:
        'packages/the-perfect-12-day-australia-itinerary-for-the-adventure-lovers',
      metadata: { title: '', description: '' },
      bookedString: 'Someone from Bengaluru booked this 185 days ago',
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Great Barrier Reef Experience',
        'Sydney Harbour Tall Ship Twilight Dinner Cruise',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Car hire for Great Ocean Road'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 2 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b35fc0562ab872750c346b4',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/642691-57.jpg',
      title: "Art lover's holiday: Lose yourself in amazing Australia",
      destinationString: 'Melbourne, Cairns and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 240843.0,
      hotelStarRating: 4.0,
      nights: 7,
      slug: 'packages/art-lovers-holiday-lose-yourself-in-amazing-australia',
      metadata: { title: '', description: '' },
      bookedString: 'Someone from Bengaluru booked this 206 days ago',
      themes: ['LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Green Island Reef Cruise with Semi Submarine tour',
        'Great Ocean Road Sunset Tour',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 2 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 2 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b03eb9262ab873c5565ea38',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/cityImages/100/melbourne-1.jpg',
      title: 'Australian itinerary to explore, rejuvenate and relax',
      destinationString: 'Melbourne, Cairns, Gold Coast and Sydney',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 224129.5,
      hotelStarRating: 4.0,
      nights: 11,
      slug:
        'packages/an-epic-11-night-australia-itinerary-for-the-rejuvenating',
      metadata: { title: '', description: '' },
      bookedString: 'Someone from Delhi booked this 244 days ago',
      themes: ['ART_AND_CULTURE'],
      tripType: 'Friends',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Big Cat Green Island with Semi Submarine',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 2 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5aeaf6c762ab87274517d407',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/636120-4.jpg',
      title: 'Solo special: A classic 11 night trip to Australia',
      destinationString: 'Sydney, Gold Coast and Melbourne',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 231038.5,
      hotelStarRating: 3.0,
      nights: 11,
      slug: 'packages/solo-special-classic-11-night-trip-to-australia',
      metadata: { title: '', description: '' },
      bookedString: 'Someone from Chennai booked this 263 days ago',
      themes: ['ADVENTURE'],
      tripType: 'Solo',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Ku-ring-gai Chase National Park Day Trip',
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Gold Coast Theme Park Pass : A happy time out at Movie World and other exciting theme worlds',
        'Great Ocean Road Day Trip Adventure',
        'Delicious dinner cruise during sunset at Sydney Harbour exposed to amazing vistas and views around the arena ',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Hop-On Hop-Off Bus Tour in Sydney',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park '
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 4 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 4 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5ae331b262ab872f3608fca6',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648920-4.jpg',
      title: 'Nature, adventure and other wonders of Australia',
      destinationString: 'Sydney, Cairns, Gold Coast and Melbourne',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 316449.5,
      hotelStarRating: 4.0,
      nights: 16,
      slug: 'packages/a-16-night-trip-to-classic-australia',
      metadata: { title: '', description: '' },
      bookedString: 'Someone from Delhi booked this 269 days ago',
      themes: ['KID_FRIENDLY'],
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Getting the best of Wet N Wild world with admissions and round trip transportation',
        'Phillip Island Nature Park and Wildlife Seals Cruise',
        'Enjoy Dolphin spotting at Port Stephens & Sandboarding Tour',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Great Barrier Reef Experience',
        'Great Ocean Road Day Trip Adventure',
        'Cairns Horse Riding and ATV quad bike riding tour from Cairns through rainforest and sugarcane fields',
        'Savannah Walkabout Australian Animals Eco Tour',
        'Moonlit Sanctuary Wildlife Conservation Park Evening Tour',
        'Tandem Skydive Experience',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Glide effortlessly or embark on any adventure activities like skiing and wake-boarding at Gold Coast Wake Park. ',
        'Sydney BridgeClimb - Evening',
        'Gold Coast Jet Ski Safari'
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 4 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 5 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 4 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5abb926862ab872dfa3ddf51',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648923-4.jpg',
      title: "Get astounded with Australia's beauty",
      destinationString: 'Melbourne, Cairns and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 216768.5,
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'packages/a-12-night-trip-to-classic-australia',
      metadata: { title: '', description: '' },
      themes: ['ART_AND_CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Ocean Road Sunset Tour',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Blue Mountains & Jenolan Caves Day Tour',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Sydney BridgeClimb',
        'Yarra Valley Cider and Beer Tour'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 5 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 4 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5ab8e05862ab87717b213ea0',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/642868-57.jpg',
      title:
        'Your perfect 6 night itinerary to Australia with family fantastic',
      destinationString: 'Sydney and Gold Coast',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 151934.0,
      hotelStarRating: 4.0,
      nights: 6,
      slug: 'packages/a-6-night-trip-to-classic-australia',
      metadata: { title: '', description: '' },
      themes: ['ART_AND_CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast Theme Park Pass : A happy time out at Movie World and other exciting theme worlds',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5ab7529762ab877535412fb5',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/643370-57.jpg',
      title: 'A 8 night trip to the adventurous side of Australia with family',
      destinationString: 'Cairns and Melbourne',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 140725.5,
      hotelStarRating: 4.0,
      nights: 8,
      slug: 'packages/a-8-night-trip-to-classic-australia',
      metadata: { title: '', description: '' },
      themes: ['ART_AND_CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Barrier Reef Experience',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure'
      ],
      cityHotelStay: [
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 4 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 4 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5ab5d42c62ab872fa7d091a8',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648820.jpg',
      title: 'A 11 night trip to classic Australia',
      destinationString: 'Sydney, Cairns and Melbourne',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 213589.0,
      hotelStarRating: 4.0,
      nights: 11,
      slug: 'packages/a-11-night-trip-to-classic-australia',
      metadata: { title: '', description: '' },
      themes: ['ART_AND_CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Barrier Reef Experience',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure'
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 4 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 4 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a8bf21562ab8744fad28eb4',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/645354-4.jpg',
      title:
        "A relaxing 10 night itinerary to unravel Australia's charming side",
      destinationString: 'Melbourne, Cairns and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 199960.5,
      hotelStarRating: 4.0,
      nights: 10,
      slug:
        'packages/unforgettable-10-night-itinerary-to-melbourne-cairns-and-sydney',
      metadata: {
        title:
          'Unforgettable 11 Days 10 Nights Australian itinerary to Melbourne, Cairns & Sydney - Book Now!',
        description:
          'Book unforgettable 11 Days 10 Nights Australian itinerary to Melbourne, Cairns & Sydney. Enjoy the Australian culture, places, activities and hotels to make your honeymoon most memorable.'
      },
      themes: ['LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'A bit of self exploration around Queen Victoria Market, Federation Square and other places',
        'Melbourne City and Williamstown Ferry Cruise',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Aboriginal Cultural Tjapukai by Night',
        'Sydney Twilight Tour by Helicopter',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 4 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a8a6be562ab8744fad2220f',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/tandem-skydive-home.jpg',
      title: 'Your best itinerary for reefs, scenic flight and more actions',
      destinationString: 'Gold Coast, Hamilton Island and Sydney',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 268463.0,
      hotelStarRating: 4.0,
      nights: 10,
      slug:
        'packages/tantalizing-10-night-itinerary-to-gold-coast-hamilton-island-sydney',
      metadata: {
        title:
          'Book Tantalizing 10 nights 11 days itinerary to Australia for Gold Coast, Hamilton Island & Sydney!',
        description:
          'Book a tantalizing 10N/11D Australian holiday itinerary to Gold Coast, Hamilton Island and Sydney. Customize your Australia itinerary, add/remove activities, places and hotels. Book today at the best price!'
      },
      themes: ['ATTRACTION'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Sydney Opera House Guided Backstage Tour',
        'Great Barrier Reef Adventures from Hamilton Islands',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Currumbin Wildlife Sanctuary',
        'Scenic flight experience at Gold Coast',
        'Blue Mountains & Jenolan Caves Day Tour',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Wollongong Tandem Skydiving',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        {
          cityId: 283,
          cityName: 'Hamilton Island',
          hotelIds: null,
          nights: 3
        },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 4 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a8826f662ab8744fad19bb7',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648573-4.jpg',
      title: 'Australian hearts: Perfect itinerary for nature lovers',
      destinationString: 'Melbourne, Hamilton Island and Sydney',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 202710.0,
      hotelStarRating: 4.0,
      nights: 10,
      slug:
        'packages/romantic-10-nights-itinerary-to-melbourne-hamilton-island-sydney',
      metadata: {
        title:
          'Book Romantic 11 Days & 10 Nights Honeymoon Itinerary to Australia Online!',
        description:
          'Customise this romantic 11 days & 10 nights honeymoon itinerary to Australia including Melbourne, Hamilton Island and Sydney. Book an Australia Honeymoon Package now as a wonderful wedding gift. Get the best price.'
      },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'A bit of self exploration around Queen Victoria Market, Federation Square and other places',
        'Melbourne City and Williamstown Ferry Cruise',
        'Great Barrier Reef Adventures from Hamilton Islands',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Scenic helicopter flight with Sydney views lasting for a lifetime',
        'Sydney Historic Pub Crawl Walking Tour',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 4 },
        {
          cityId: 283,
          cityName: 'Hamilton Island',
          hotelIds: null,
          nights: 3
        },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378ee2b58ce008e806b31f',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/hotair.jpg',
      title: 'An ideal 13 day holiday itinerary for family outings',
      destinationString: 'Melbourne, Gold Coast, Cairns and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 248185.0,
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'packages/a-13-day-holiday-itinerary-for-ideal-family-outings',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Melbourne Hop-on Hop-off Tour + Admission to Melbourne Zoo',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Hot Air Ballooning from the Gold Coast',
        'Great Ocean Road Day Trip Adventure',
        'Exploration of the beautiful Gold Coast Infinity arena - Admissions included',
        'Gold Coast Helicopter Flight and Jet Boat Ride',
        'Rip-roaring Sydney whale-watching cruise and timeout with the natural habitats and up-close encounters',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        "Hartley's Crocodile Adventure Half-Day Tour",
        "Gold Coast Mega Pass - Film World, Sea World Gold Coast, Wet'n'Wild Gold Coast, and Paradise Country"
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 4 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 2 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378eb6b58ce008e806b2cd',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/646098-4.jpg',
      title: 'Your perfect Australia vacation itinerary for family vacations',
      destinationString: 'Sydney and Gold Coast',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 185752.0,
      hotelStarRating: 4.0,
      nights: 9,
      slug:
        'packages/the-perfect-australia-vacation-itinerary-for-epic-family-vacations',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Informative walking tour amidst nocturnal rainforest arena and exposure to glow worms at the Mt Tamborine National Park',
        'Hop-On Hop-Off Bus Tour in Sydney',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        "Gold Coast Mega Pass - Film World, Sea World Gold Coast, Wet'n'Wild Gold Coast, and Paradise Country"
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 4 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 5 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378eb4b58ce008e806b2c9',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/621152-4.jpg',
      title: 'An impressive family itinerary for a cool Australian vacation',
      destinationString: 'Gold Coast, Cairns, Sydney and Melbourne',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 230857.0,
      hotelStarRating: 4.0,
      nights: 12,
      slug:
        'packages/an-impressive-family-itinerary-for-a-cool-australian-vacation',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Time out with family whilst making memories at Sea World - Admissions',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Adventure infested Big Cat Green Island Cruise tour from Cairns with buffet lunch ',
        'Hop-On Hop-Off Bus Tour in Sydney',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378e95b58ce008e806b295',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632762-57.jpg',
      title: 'The best ever Australia honeymoon itinerary for romantics',
      destinationString: 'Sydney, Hamilton Island, Melbourne and Gold Coast',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 221765.5,
      hotelStarRating: 3.5,
      nights: 10,
      slug:
        'packages/the-best-ever-australia-honeymoon-itinerary-for-romantics',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION', 'KID_FRIENDLY'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Great Ocean Road Sunset Tour',
        'Eureka Skydeck 88',
        'Melbourne City and Williamstown Ferry Cruise',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Hot Air Ballooning from the Gold Coast',
        'Informative walking tour amidst nocturnal rainforest arena and exposure to glow worms at the Mt Tamborine National Park',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 2 },
        {
          cityId: 283,
          cityName: 'Hamilton Island',
          hotelIds: null,
          nights: 2
        },
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378e88b58ce008e806b27f',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648812-4.jpg',
      title: ' An 8 day Australia itinerary for memorable family vacations',
      destinationString: 'Gold Coast and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 141114.0,
      hotelStarRating: 3.5,
      nights: 7,
      slug: 'packages/for-epic-family-vacations-an-8-day-australia-itinerary',
      metadata: { title: '', description: '' },
      themes: ['LEISURE', 'KID_FRIENDLY'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Blue Mountains Scenic Tour & River Cruise',
        "Gold Coast Mega Pass - Film World, Sea World Gold Coast, Wet'n'Wild Gold Coast, and Paradise Country"
      ],
      cityHotelStay: [
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 4 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378e6ab58ce008e806b24c',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/flecker2.jpg',
      title: 'The 13 day Australia family adventure vacation',
      destinationString: 'Melbourne, Cairns, Gold Coast and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 180900.5,
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'packages/the-13-day-australia-family-adventure-vacation',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        ' A bit of Cairns tour with visits to Flecker Botanical Garden and other top places',
        'Time out with family whilst making memories at Sea World - Admissions',
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Ocean Road Sunset Tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Currumbin Wildlife Sanctuary',
        'Exploration of the beautiful Gold Coast Infinity arena - Admissions included',
        'Big Cat Green Island with Semi Submarine',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park '
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 3 },
        { cityId: 101, cityName: 'Cairns', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378e69b58ce008e806b24b',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/647862-4.jpg',
      title: 'Romance and fun: An utterly captivating Australian itinerary',
      destinationString: 'Melbourne, Sydney and Gold Coast',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 173899.5,
      hotelStarRating: 4.0,
      nights: 10,
      slug: 'packages/the-exciting-11-day-australia-honeymoon-itinerary',
      metadata: { title: '', description: '' },
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      regionCode: 'aus',
      activities: [
        'A bit of self exploration around Queen Victoria Market, Federation Square and other places',
        'Scenic ride on the Melbourne Star Observation Wheel with brilliant views of Melbourne ',
        'Highlights of Melbourne Cruise',
        'Sydney Tower Restaurant Buffet',
        'Natural Bridge and World Heritage Springbrook National Park Tour',
        'Currumbin Wildlife Sanctuary',
        'Scenic helicopter flight with Sydney views lasting for a lifetime',
        'Yarra Valley Balloon Flight at Sunrise',
        'Sydney Tower Eye'
      ],
      cityHotelStay: [
        { cityId: 100, cityName: 'Melbourne', hotelIds: null, nights: 4 },
        { cityId: 104, cityName: 'Sydney', hotelIds: null, nights: 3 },
        { cityId: 103, cityName: 'Gold Coast', hotelIds: null, nights: 3 }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    }
  ],
  testimonials: [
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Australia',
      fName: 'Nikisha Jain',
      mName: '',
      lName: '',
      cityOfDeparture: 'Mumbai',
      dateOfDeparture: 1501632000000,
      destination: 'Melbourne',
      ttype: 'Honeymoon',
      review:
        'Had a lovely trip to australia....Pickurtrail were quick and helpful most of the times....Well planned and executed....Had a beautiful vacation....Thank you....',
      fbLink: 'https://www.facebook.com/nikijjain/posts/10214040664000756:0',
      profileImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/221/other/800xh/others1.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/16098/others1.jpg',
      itineraryId: '59533c9c62ab872110ac8d45',
      journalLinks: [
        'https://blog.pickyourtrail.com/a-couples-guide-to-the-perfect-australian-vacation/'
      ],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/221/other/800xh/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/221/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/221/other/800xh/others4.jpg'
      ],
      testimonialId: 221,
      shortReview:
        'Pickyourtrail team was quick and helpful throughout the trip, with their conciege assistance!',
      shortestReview: 'Every bit of our tour was well planned and executed.',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Australia and New Zealand',
      fName: 'Tanveer Fatima',
      mName: '',
      lName: '',
      cityOfDeparture: 'Mumbai',
      dateOfDeparture: 1518912000000,
      destination: 'Sydney',
      ttype: 'Solo',
      review:
        'I was referred to PYT by my nephew. I ve to mention i had an awesome trip to Australia. It was a great experience where i had a hassle free vacation,thanks to d well planned accomodation & sightseeing organised by PYT. Special mention for Mr. Krish who managed everything perfectly. Worth d money!',
      fbLink:
        'https://www.facebook.com/tanveer.fatima.7/posts/10214491831142430:0',
      profileImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/fbProfile/800xh/profile.jpg',
      coverImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/fbCover/800xh/20180304_095644.jpg',
      itineraryId: '5a2b92b94065d117076a2d3e',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180304_103138.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180304_131548.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180304_132031.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180321_072045.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180325_183559.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180325_190036.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180326_121610.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180326_121655.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/cover.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/others1.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/others2.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/25065/others3.jpg'
      ],
      testimonialId: 56,
      shortReview:
        'Was referred to PYT by my nephew. Had an amazing trip for real. Thanks guys',
      shortestReview:
        'Special cheers to the teams who managed my Australia trip perfectly end to end!',
      type: 'Solo'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Europe',
      fName: 'Gaurav Prabhu',
      mName: '',
      lName: '',
      cityOfDeparture: 'Mumbai',
      dateOfDeparture: 1519862400000,
      destination: 'Prague',
      ttype: 'Honeymoon',
      review:
        'Prague- Vienna-Budapest trip review\nWe were discussing our honeymoon in the month of August just when our wedding date was finalized and we zeroed on Prague- Vienna- Budapest as we both wanted a historic but serene destination. While our research was on we came across Pick your trail. The fact that you can customize your travel as per your plan was the cynosure of their portal for us cause that was our prerogative. We decided to go with them. The interaction we had with their executives for visa, itenery and during the trip was very helpful and to the point. They suggested we add Bratislava in Slovakia to our 9 day trip turned out to be a blessing in disguise as it is a beautiful capital city. All the day and night trips planned in all the cities were interesting and the guides were also very friendly. We loved the fact that we could interact with people from other countries during our trip in Budapest. The highlights of the trip were the Cesky Krumlov walking trip while in Prague, the inside visit to Schonbrun palace in Vienna was breathtaking and Danube evening River Cruise in Budapest. \nComing to the hotels selected by them, all the three were well located and easily accessible from the nearest metro/subway station which made travelling easier for us. Special mention to the hotel in Budapest, the Burg hotel. The hotel was right outside a beautiful tourist location called St. Matthias church. This was an incing on the cake as the location was truly mesmerizing at all times of the day.To sum it up we were extremely happy with the planning and execution of Pick your trail. Appreciate the fact that they are open to suggestions and feedback (special thanks to Shashikant , Lony and Sunil from Pickyourtrail team ). We look forward to some more trips with them. Highly recommended for people who love to explore new places with their help.',
      fbLink: 'https://www.facebook.com/prgaurav/posts/10213644932109232:0',
      profileImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/fbProfile/800xh/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/19381/cover.jpg',
      itineraryId: '59aa54444065d16cc4c0730c',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/others1.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/19381/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/others4.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284382.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284385.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284386.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284388.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284391.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284392.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284393%20%281%29.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284394.jpg'
      ],
      testimonialId: 58,
      shortReview:
        'The interaction we had with their executives was very helpful and to the point.',
      shortestReview:
        'Great team with so much destination knowledge! Thanks PYT!',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'New Zealand',
      fName: 'Abilash Ramanathan V',
      mName: '',
      lName: '',
      cityOfDeparture: 'Chennai',
      dateOfDeparture: 1518307200000,
      destination: 'Auckland',
      ttype: 'Honeymoon',
      review:
        'Our New-zealand trio with them is awesome to de core!!!!!.. The best place to keep you guided through the tour 24/7. It’s awesome to take Care the passengers all the way and make them stop worrying and they will take care of things and what u need. Pleasure being a customer with Pickyourtrail...\n\nThanks guys and your doing a great job and keep it up. Was a nice honeymoon and a peaceful trip ever. Love the way you take and guide with the customer through calls and support them. Packages are very open to suggestions and free to call out.\n\nEven through midnights and their work schedule they support the customer without hesitation with no time schedule and help them through their queries. I LOVE IT SERIOUSLY.',
      fbLink:
        'https://www.facebook.com/abilashramanathan.v/posts/2079876365362046:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/21137/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/21137/cover.jpg',
      itineraryId: '59d89dc34065d12b84bfa539',
      journalLinks: [],
      testimonialId: 60,
      shortReview:
        'Thanks for planning my NZ trip with such perfection. Had a peaceful trip!',
      shortestReview:
        "PYT's work schedule and support all day long is amazing!",
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Bali',
      fName: 'Naren Mohandoss',
      mName: '',
      lName: '',
      cityOfDeparture: 'Chennai',
      dateOfDeparture: 1509840000000,
      destination: 'Kuta',
      ttype: 'Honeymoon',
      review:
        'One of the best trip I have ever went on through an agencies. Team took an keen interest in making sure I reach each and every destinations of mine on time. I would get a message about my itinerary and on my flight timings. The guides where so polite and humble. Overall it was an safest trip. I would recommend them blindly.',
      fbLink:
        'https://www.facebook.com/naren.mohandoss/posts/10215397091143467:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/22028/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/22028/cover.jpg',
      itineraryId: '59e4c5c04065d15cd166ea34',
      journalLinks: [],
      testimonialPhotos: [
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/22028/others1.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/22028/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/others4.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218059.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218060.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218062.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218063.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218064.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218066.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218067.jpg'
      ],
      testimonialId: 63,
      shortReview:
        'Customized vacation planning done at the best possible manner. Kudos guys!',
      shortestReview:
        'It was a great trip. I would recommend PYT blindly to all',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Bali',
      fName: 'Kuzhali Karthikeyan',
      mName: '',
      lName: '',
      cityOfDeparture: 'Chennai',
      dateOfDeparture: 1509926400000,
      destination: 'Kuta',
      ttype: 'Honeymoon',
      review:
        'It was a memorable trip to both of us and pick your trial just made everything easy :) Adharsh being a known person to me understood my needs and crafted the itenary just the way I expected!!! Shailesh who constantly kept in touch with us in our entire trip thru telegram and updates us on the daily schedule :) thanks a lot team for giving us wonderful experience overall ?',
      fbLink: 'https://www.facebook.com/KuzhaliSS/posts/1640654812717642:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/20563/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/20563/cover.jpg',
      itineraryId: '59e4bb2f4065d15cd166e523',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/0ba73d2f-8e97-4758-8186-a33a2254db98.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/2f02577e-3e76-442a-b468-9502aa63b3aa.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/45be5716-bea5-4e5b-8f12-c9d4d559ff35.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/64df0fcc-c80b-4613-942c-9297daa385c2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/6ba730a3-5b38-4a75-8a1d-3b2215425140.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/94910ecc-aedf-475a-9c8d-7d0e171df00e.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/dd.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/ddd0a6eb-4772-461b-a254-a7c3fec101ce.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/others1.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/others4.jpg'
      ],
      testimonialId: 65,
      shortReview:
        'Itineraries crafted with perfection and maximum support provided! Good job PYT!',
      shortestReview:
        'Thanks a lot team for giving us wonderful experience overall ',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Europe',
      fName: 'Vandana Sekhar',
      mName: '',
      lName: '',
      cityOfDeparture: 'Outside India',
      dateOfDeparture: 1507334400000,
      destination: 'Paris',
      ttype: 'Honeymoon',
      review:
        'We planned our first Anniversary celebration to Amesterdam and Paris with Pick Your Tail. Since this was our first time to Europe we had a lot of doubts and difficulties on how to go about things but Pick your Trail helped us in every way possible. From forming the complete itenary by Agny according to our requirement to providing complete support during our trip there and helping us whenever we had an issue by Lony. We will definitely be looking forward to plan our next trip with them',
      fbLink:
        'https://www.facebook.com/vandana.sekhar.33/posts/10154736266751268:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/cover.jpg',
      itineraryId: '59899a8762ab8766242841c7',
      journalLinks: [],
      testimonialPhotos: [
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/others1.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/67/other/800xh/others3.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/others4.jpg'
      ],
      testimonialId: 67,
      shortReview:
        'Extensive support during travel adhering to our queries throughout the vacation!',
      shortestReview: 'Good support and great planning guys. Thanks PYT team!',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Europe',
      fName: 'Harikrishnan Ravindran',
      mName: '',
      lName: '',
      cityOfDeparture: 'Bengaluru',
      dateOfDeparture: 1508371200000,
      destination: 'Paris',
      ttype: 'Family',
      review:
        "Recently made a 10 day Paris and Italy vacation with family with the help of Pickyourtrail.The team support and service was fantastic right from the initial planning stages with lot of useful inputs which really helped optimise our trail. They have a superb website with almost all information that one would need while planning a vacation readily available with multiple options based on your interests, budget etc. User interface of the website is just too good.There wasn't even a spot of bother when it came to execution and all the arrangements made all through the 10 days were 100% hassle or tension free.\nThe 24X7 concierge service during the trail is another attraction where help or suggestions will be available for you at short notice and you feel the virtual presence of a guide, in case of queries.You are doing a great job guys. Keep making trails memorable. All the Best! ?",
      fbLink:
        'https://www.facebook.com/harikrishnan.ravindran.9/posts/10159488410220032:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18179/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18179/cover.jpg',
      itineraryId: '59859b9862ab8707112ad0fc',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/69/other/800xh/others1.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/69/other/800xh/others2.jpg'
      ],
      testimonialId: 69,
      shortReview:
        'The support and services were fantastic right from the initial stages with useful inputs ',
      shortestReview:
        'Super work by the team in organising my trip! Kudos PYT!',
      type: 'Family'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Bali',
      fName: 'Akshi Pandita',
      mName: '',
      lName: '',
      cityOfDeparture: 'Delhi',
      dateOfDeparture: 1507939200000,
      destination: 'Kuta',
      ttype: 'Honeymoon',
      review: 'Stephy is extremely courteous ?? kudos to the entire team',
      fbLink: 'https://www.facebook.com/akshi.pandita/posts/1666385180080413:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/17958/profile.jpg',
      coverImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/72/fbCover/800xh/others1.jpg',
      itineraryId: '597e02c962ab873134a863d3',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/72/other/800xh/cover.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/72/other/800xh/others2.jpg'
      ],
      testimonialId: 72,
      shortReview:
        'Wonderful support and brilliant services offered. Great work team!',
      shortestReview: 'Courteous staffs helping us throughout the trip. Kudos!',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Europe',
      fName: 'Sreekhanth Vankineni',
      mName: '',
      lName: '',
      cityOfDeparture: 'Mumbai',
      dateOfDeparture: 1506038400000,
      destination: 'Lucerne',
      ttype: 'Honeymoon',
      review:
        'We jus got back from our honeymoon trip to switzerland and italy. Our experience with Pickyourtrail was totally amazing. Special thanks to Agni, Sanjay and Jaideep. Their meticulous planning, precise timings and attention to every small detail in our itinerary ensured that we had an amazing trip without any hassle. We would definitely choose them for our future trips. Thank you for everything.',
      fbLink:
        'https://www.facebook.com/srikanth.vankineni/posts/1540537426007574:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18258/profile.jpg',
      coverImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/fbCover/800xh/cover.jpg',
      itineraryId: '59847f604065d139a6ff289b',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170923_142051.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170923_214947.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170925_175952.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170925_180854.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170925_191439.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170926_100056.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170927_112051.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170927_124533.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170927_124708.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170927_142256.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170928_110807.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170930_095103.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170930_142817.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170930_142830.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_113235.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18258/20171002_113838.mp4',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_114721.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_115640.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_123827.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_125634.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_125833.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18258/20171003_204540.mp4',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others1.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others4.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others5.jpg'
      ],
      testimonialId: 78,
      shortReview:
        'An amazing trip due to the constant support and services offered by the PYT team!',
      shortestReview: 'Every bit of our Italy- Swiss vacay was delightful!',
      type: 'Honeymoon'
    }
  ]
};

export default getVacation;
