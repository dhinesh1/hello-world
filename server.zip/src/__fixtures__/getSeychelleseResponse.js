const getSeychellesHotel = {
  hotelDetails: [
    {
      planningToolId: 53526,
      name: 'Lemuria Resort',
      description:
        'Nestled on the northwest shore of the idyllic island of Praslin with the Indian Ocean lapping gently at the shores of its 3 perfect white sand beaches, the 6* Lémuria Resort is at the heart of a luxury Seychelles experience.\n\n<p>If you’ve ever dreamed of paradise, you’ll find it here. From the elegant, secluded suites with ocean views to the regal villas thoughtfully designed to compliment their stunning environment. Even the swimming pools seem crafted by nature, and Lémuria’s refined elegance is everywhere.\n\n<p>At Lémuria there’s something for everyone. From rest and relaxation on our beautiful beaches and at the soothing Spa de Constance, to the challenging 18-hole golf course and stunning underwater world around our granite reef.\n\n<p>Come on a culinary adventure across our 3 world-class restaurants which combine the fresh, exotic fruits, seafood and spices of the island with European styles and techniques.\n\nAt Lémuria we dont forget the kids, and at our Turtle Club they will have a holiday as finely tailored to them as yours is to you.\n\n<p>From turtle spotting at Anse Kerlan where turtles lay their eggs and games organised on the beach, the only difficulty for you will be persuading them to leave.\n\n<p>At the heart of the Seychelles experience Lémuria Resort is in an extraordinary location, unique in its beauty and environment.\n\n<p>We look forward to welcoming you soon.',
      stars: 0.0,
      imageURL:
        'https://i.travelapi.com/hotels/1000000/860000/859800/859709/859709_425_z.jpg',
      otherImages: [
        'https://i.travelapi.com/hotels/1000000/860000/859800/859709/3440142f_z.jpg',
        'https://i.travelapi.com/hotels/1000000/860000/859800/859709/b4e14952_z.jpg',
        'https://i.travelapi.com/hotels/1000000/860000/859800/859709/b6f94c7b_z.jpg',
        'https://i.travelapi.com/hotels/1000000/860000/859800/859709/e8ee1142_z.jpg',
        'https://i.travelapi.com/hotels/1000000/860000/859800/859709/859709_167_z.jpg'
      ],
      amenityDisplayList: [
        {
          strikethrough: false,
          iconUrl: 'vehoicon-pool-chair',
          amenityName: 'Swimming Pool'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-shuttle-services',
          amenityName: 'Shuttle Service'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-washing-machine',
          amenityName: 'Laundry facility'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-spa-flower',
          amenityName: 'Spa facility'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-bar-cocktail',
          amenityName: 'Poolside bar'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-gym',
          amenityName: 'Gym/Fitness Centre'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-safe-lock',
          amenityName: 'Locker Facility'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-concierge-bell',
          amenityName: 'Concierge Service'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-beach-view',
          amenityName: 'On Private Beach'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-pool-chair',
          amenityName: 'Pool accessories'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-indoor-activities',
          amenityName: 'Indoor Recreational Activities'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-outdoor-activities',
          amenityName: 'Outdoor Recreational Activities'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-bar-cocktail',
          amenityName: 'Bar'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-parking',
          amenityName: 'Parking Facility'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-child-care',
          amenityName: 'Childcare Supervision'
        }
      ],
      specialities: null,
      topResort: false
    }
  ],
  price: '1,09,227',
  campaignItineraryId: '59ccfb1c05f42b07367d4ba8',
  cityNightsMap: { Mahe: 3 }
};
