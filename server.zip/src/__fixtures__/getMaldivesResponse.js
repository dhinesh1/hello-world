const getMaldivesHotel = {
  hotelDetail: [
    {
      planningToolId: 1052386,
      name:
        'Paradise Island Resort (All Markets Except CIS, Russia, Lithuania)',
      description:
        'This five star resort called Paradise Island has the local name Lankanfinolhu. Paradise Island, opened in 1994 is located in North Male Atoll, which is 9.6km from the Airport. Paradise Island is 1km long and 230 meters wide and has beach all around with an excellent marine life around.<P>Paradise Island Resort is one of the most striking features in Maldives. The islands attraction lies in its first class service with a variety of stragically located restaurants and the widest possible range of sports both on land and on the sea.<P>Transfer by Speed boat: 20 Mins<P> Number of Rooms: 282 rooms<P>Upgrade to Full Board Meal Plan for Beach Bungalows- USD 25 Per Adult Per Day and USD 13 Per Child Per Day.<P>Upgrade to Half Board Meal Plan in Water & Haven Water Villa- USD 40 Per Adult Per Day<P>Upgrade to Full Board Meal Plan in Water & Haven Water Villa- USD 80 Per Adult Per Day<P>Upgrade to All Inclusive Meal Plan- USD 70 Per Adult Per Day and USD 35 Per Child Per Day for Superior Beach Bungalow and USD 130 per Adult Per Day For Water Villa & Haven Water Villa.<P> All Inclusive Supplements on FB - Beach: USD 45 Per Person Per Day/ Overwater: USD 90 Per Person Per Day. From 1 April 2018 to 31 Oct 2018. Book by date 30th Jun 2018. \n',
      stars: 0.0,
      imageURL:
        'https://i.travelapi.com/hotels/2000000/1940000/1932500/1932406/b831bc9d_z.jpg',
      otherImages: [
        'https://i.travelapi.com/hotels/2000000/1940000/1932500/1932406/98946279_z.jpg',
        'https://i.travelapi.com/hotels/2000000/1940000/1932500/1932406/dc00bcb2_z.jpg',
        'https://i.travelapi.com/hotels/2000000/1940000/1932500/1932406/1932406_386_z.jpg',
        'https://i.travelapi.com/hotels/2000000/1940000/1932500/1932406/1932406_395_z.jpg',
        'https://i.travelapi.com/hotels/2000000/1940000/1932500/1932406/1932406_397_z.jpg'
      ],
      amenityDisplayList: [
        {
          strikethrough: false,
          iconUrl: 'vehoicon-gym',
          amenityName: 'Gym/Fitness Centre'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-pool-chair',
          amenityName: 'Swimming Pool'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-concierge-bell',
          amenityName: 'Concierge Service'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-shuttle-services',
          amenityName: 'Shuttle Service'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-washing-machine',
          amenityName: 'Laundry facility'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-spa-flower',
          amenityName: 'Spa facility'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-bar-cocktail',
          amenityName: 'Poolside bar'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-safe-lock',
          amenityName: 'Locker Facility'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-pool-chair',
          amenityName: 'Pool accessories'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-indoor-activities',
          amenityName: 'Indoor Recreational Activities'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-outdoor-activities',
          amenityName: 'Outdoor Recreational Activities'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-bar-cocktail',
          amenityName: 'Bar'
        },
        {
          strikethrough: false,
          iconUrl: 'vehoicon-storage',
          amenityName: 'Common storage facility'
        }
      ],
      specialities: null,
      topResort: false
    }
  ],
  price: '1,48,200',
  campaignItineraryId: '59ccfb0505f42b07367d4b88',
  cityNightsMap: { Maldives: 3 }
};
