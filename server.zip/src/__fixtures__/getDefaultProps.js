import { getVacation } from './getVacationResponse.js';

export const getDefaultProps = {
  match: {
    path: '/vacations/:destination/request-callback',
    url: '/vacations/australia/request-callback',
    isExact: true,
    params: {
      destination: 'australia'
    }
  },
  location: {
    pathname: '/vacations/australia/request-callback',
    search: '',
    hash: '',
    key: 'wsgft8'
  },
  history: {
    length: 28,
    action: 'PUSH',
    location: {
      pathname: '/vacations/australia/request-callback',
      search: '',
      hash: '',
      key: 'wsgft8'
    }
  },
  vacations: {
    isFetching: false,
    hasError: false,
    error: {},
    content: getVacation
  },
  user_details: {
    loggedIn: true,
    userType: 'ADMIN',
    email: 'narendra@pickyourtrail.com',
    countryPhoneCode: '+91',
    mobileNumber: '9884031872',
    name: 'Naren',
    uniqueHash: '32322f4d61792f323031387c39383834303331383732',
    availableItineraries: 0
  },
  actions: {}
};
