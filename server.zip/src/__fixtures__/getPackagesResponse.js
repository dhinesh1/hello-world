const getPackages = {
  filteredItineraries: [
    {
      campaignItineraryId: '5abb926862ab872dfa3ddf51',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648923-4.jpg',
      title: "Get astounded with Australia's beauty",
      destinationString: 'Melbourne, Cairns and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 216768.5,
      itineraryCostDisplay: '2,16,769',
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'a-12-night-trip-to-classic-australia',
      bookedString: 'Someone booked this 6 days ago',
      themes: ['ART_AND_CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Ocean Road Sunset Tour',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Blue Mountains & Jenolan Caves Day Tour',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Sydney BridgeClimb',
        'Yarra Valley Cider and Beer Tour'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 5
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 4
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb6f5ed62ab876e1575a7cd',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/philipislands.jpg',
      title: "UnDiscover the all time enchanting Australia's artistic side",
      destinationString: 'Melbourne, Cairns, Gold Coast and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 211454.5,
      itineraryCostDisplay: '2,11,455',
      hotelStarRating: 4.0,
      nights: 12,
      slug:
        'undiscover-the-all-time-enchanting-australias-artistic-side-a-12-nights-itinerary-for-your-ultimate-break',
      bookedString: 'Someone booked this 7 days ago',
      themes: ['ART_AND_CULTURE'],
      regionName: 'Australia',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Big Cat Green Island with Semi Submarine',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb7109d62ab876e1575bd93',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632546-4.jpg',
      title: '12 nights itinerary covering top attractions in Australia',
      destinationString:
        'Hobart, Melbourne, Sydney, Airlie Beach and Gold Coast',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 276183.0,
      itineraryCostDisplay: '2,76,183',
      hotelStarRating: 3.5,
      nights: 12,
      slug:
        '12-nights-itinerary-covering-top-attractions-in-hobart-melbourne-sydney-airlie-beach-and-gold-coast',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      activities: [
        'A dig into the history of rocks and pubs via walking tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Natural Bridge and World Heritage Springbrook National Park Tour',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Sydney Twilight Tour by Helicopter',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Taronga Zoo Sydney Admissions',
        'Morning Whale Watching Cruise',
        'Ripleys Believe It Or Not Surfers Paradise Tickets',
        'Hop On Hop Off Hobart City Sightseeing Tour'
      ],
      cityHotelStay: [
        {
          cityId: 140,
          cityName: 'Hobart',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 840,
          cityName: 'Airlie Beach',
          hotelIds: null,
          nights: 1
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb2e9decd3d7235f880406',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/uluruaussie.jpg',
      title: 'Memorable family vacations to get the best of Australia',
      destinationString: 'Sydney, Cairns, Gold Coast, Uluru and Melbourne',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 356193.25,
      itineraryCostDisplay: '3,56,193',
      hotelStarRating: 5.0,
      nights: 17,
      slug: 'happy-timeout-with-family-discovering-australias-beauty',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['KID_FRIENDLY', 'ATTRACTION'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Admissions + Round trip transportation to Dreamworld and White Water World',
        'Green Island Reef Cruise with Semi Submarine tour',
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Ocean Road Sunset Tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Tour of Uluru to embrace its cultural side and venturing into Mutitjulu Waterhole ',
        'Informative walking tour amidst nocturnal rainforest arena and exposure to glow worms at the Mt Tamborine National Park',
        'Blue Mountains Scenic Tour & River Cruise'
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 631,
          cityName: 'Uluru',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 5
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378ee2b58ce008e806b31f',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/hotair.jpg',
      title: 'An ideal 13 day holiday itinerary for family outings',
      destinationString: 'Melbourne, Gold Coast, Cairns and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 248185.0,
      itineraryCostDisplay: '2,48,185',
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'a-13-day-holiday-itinerary-for-ideal-family-outings',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Melbourne Hop-on Hop-off Tour + Admission to Melbourne Zoo',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Hot Air Ballooning from the Gold Coast',
        'Great Ocean Road Day Trip Adventure',
        'Exploration of the beautiful Gold Coast Infinity arena - Admissions included',
        'Gold Coast Helicopter Flight and Jet Boat Ride',
        'Rip-roaring Sydney whale-watching cruise and timeout with the natural habitats and up-close encounters',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        "Hartley's Crocodile Adventure Half-Day Tour",
        "Gold Coast Mega Pass - Film World, Sea World Gold Coast, Wet'n'Wild Gold Coast, and Paradise Country"
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5aeaf6c762ab87274517d407',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/636120-4.jpg',
      title: 'Solo special: A classic 11 night trip to Australia',
      destinationString: 'Sydney, Gold Coast and Melbourne',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 231038.5,
      itineraryCostDisplay: '2,31,039',
      hotelStarRating: 3.0,
      nights: 11,
      slug: 'solo-special-classic-11-night-trip-to-australia',
      metadata: {
        title: '',
        description: ''
      },
      bookedString: 'Someone from Chennai booked this 237 days ago',
      themes: ['ADVENTURE'],
      tripType: 'Solo',
      regionName: 'Australia',
      activities: [
        'Ku-ring-gai Chase National Park Day Trip',
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Gold Coast Theme Park Pass : A happy time out at Movie World and other exciting theme worlds',
        'Great Ocean Road Day Trip Adventure',
        'Delicious dinner cruise during sunset at Sydney Harbour exposed to amazing vistas and views around the arena ',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Hop-On Hop-Off Bus Tour in Sydney',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park '
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 4
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5ab5d42c62ab872fa7d091a8',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648820.jpg',
      title: 'A 11 night trip to classic Australia',
      destinationString: 'Sydney, Cairns and Melbourne',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 213589.0,
      itineraryCostDisplay: '2,13,589',
      hotelStarRating: 4.0,
      nights: 11,
      slug: 'a-11-night-trip-to-classic-australia',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ART_AND_CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Barrier Reef Experience',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure'
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 4
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb07c0ecd3d7235f87f435',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/634832-4.jpg',
      title: 'Romance reloaded: Australian honeymoon getaway',
      destinationString: 'Sydney, Melbourne, Cairns and Gold Coast',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 184281.5,
      itineraryCostDisplay: '1,84,282',
      hotelStarRating: 4.5,
      nights: 12,
      slug: 'romance-filled-australian-honeymoon-break',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['NATURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Flecker Botanical Gardens',
        'Green Island Reef Cruise with Semi Submarine tour',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Scenic flight experience at Gold Coast',
        'Blue Mountains Scenic Tour & River Cruise',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b35fc0562ab872750c346b4',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/642691-57.jpg',
      title: "Art lover's holiday: Lose yourself in amazing Australia",
      destinationString: 'Melbourne, Cairns and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 240843.0,
      itineraryCostDisplay: '2,40,843',
      hotelStarRating: 4.0,
      nights: 7,
      slug: 'art-lovers-holiday-lose-yourself-in-amazing-australia',
      metadata: {
        title: '',
        description: ''
      },
      bookedString: 'Someone from Bengaluru booked this 181 days ago',
      themes: ['LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Green Island Reef Cruise with Semi Submarine tour',
        'Great Ocean Road Sunset Tour',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 2
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb7119462ab876e1575be98',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632549-4.jpg',
      title: 'Refresh and rejoice: Tour Australia the stylish way',
      destinationString:
        'Hobart, Melbourne, Brisbane, Gold Coast, Sydney and Adelaide',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 257383.5,
      itineraryCostDisplay: '2,57,384',
      hotelStarRating: 3.5,
      nights: 15,
      slug:
        'rejunavation-time-15-nights-itinerary-to-hobart-melbourne-brisbane-gold-coast-sydney-and-adelaide',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE', 'LEISURE'],
      tripType: 'Friends',
      regionName: 'Australia',
      activities: [
        'Adelaide Hills Tour and Murray River Cruise',
        'A dig into the history of rocks and pubs via walking tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Gold Coast Sightseeing Cruise - Palazzo Versace, Sea World and the Marina Mirage resort complex',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Sydney Twilight Tour by Helicopter',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Taronga Zoo Sydney Admissions',
        'Morning Whale Watching Cruise',
        'Brilliant views from the wheel of Brisbane exposed to the best arenas and vistas of Brisbane',
        'Hop On Hop Off Hobart City Sightseeing Tour'
      ],
      cityHotelStay: [
        {
          cityId: 140,
          cityName: 'Hobart',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 115,
          cityName: 'Brisbane',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 259,
          cityName: 'Adelaide',
          hotelIds: null,
          nights: 2
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e6a8ecd3d7235f879266',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/bridgeclimb.jpg',
      title:
        'Get the best of all worlds with your family in the Australian lands',
      destinationString: 'Cairns, Sydney and Melbourne',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 199461.0,
      itineraryCostDisplay: '1,99,461',
      hotelStarRating: 0.0,
      nights: 9,
      slug: 'family-delights-live-it-up-at-the-adventurous-australian-lands',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        ' Good views of Opera House during dinner cruise in Sydney showboat',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney Harbour Bridge Climb - Sampler'
      ],
      cityHotelStay: [
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: false,
      transferIncluded: true,
      visaIncluded: false,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378e95b58ce008e806b295',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632762-57.jpg',
      title: 'The best ever Australia honeymoon itinerary for romantics',
      destinationString: 'Sydney, Hamilton Island, Melbourne and Gold Coast',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 221765.5,
      itineraryCostDisplay: '2,21,766',
      hotelStarRating: 3.5,
      nights: 10,
      slug: 'the-best-ever-australia-honeymoon-itinerary-for-romantics',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'KID_FRIENDLY'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Great Ocean Road Sunset Tour',
        'Eureka Skydeck 88',
        'Melbourne City and Williamstown Ferry Cruise',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Hot Air Ballooning from the Gold Coast',
        'Informative walking tour amidst nocturnal rainforest arena and exposure to glow worms at the Mt Tamborine National Park',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 283,
          cityName: 'Hamilton Island',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378e69b58ce008e806b24b',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/647862-4.jpg',
      title: 'Romance and fun: An utterly captivating Australian itinerary',
      destinationString: 'Melbourne, Sydney and Gold Coast',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 173899.5,
      itineraryCostDisplay: '1,73,900',
      hotelStarRating: 4.0,
      nights: 10,
      slug: 'the-exciting-11-day-australia-honeymoon-itinerary',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'A bit of self exploration around Queen Victoria Market, Federation Square and other places',
        'Scenic ride on the Melbourne Star Observation Wheel with brilliant views of Melbourne ',
        'Highlights of Melbourne Cruise',
        'Sydney Tower Restaurant Buffet',
        'Natural Bridge and World Heritage Springbrook National Park Tour',
        'Currumbin Wildlife Sanctuary',
        'Scenic helicopter flight with Sydney views lasting for a lifetime',
        'Yarra Valley Balloon Flight at Sunrise',
        'Sydney Tower Eye'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9b875ecd3d7235f8776eb',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/penguins_99177-1600x1200.jpg',
      title: 'Celebrate friendship: An exciting Australian adventure',
      destinationString: 'Melbourne, Cairns, Gold Coast and Sydney',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 264455.5,
      itineraryCostDisplay: '2,64,456',
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'celebrate-friendship-an-exciting-australian-adventure',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Hot Air Ballooning from the Gold Coast',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Bungy jumping from 165 ft distance at Cairns',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Big Cat Green Island with Semi Submarine',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Gold Coast 3 Day Theme Park Pass',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e454ecd3d7235f87914a',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648930-4.jpg',
      title: 'Discover the adventurous side of Australia with your better half',
      destinationString: 'Cairns, Sydney and Melbourne',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 203324.5,
      itineraryCostDisplay: '2,03,325',
      hotelStarRating: 4.0,
      nights: 9,
      slug: 'discover-the-adventurous-side-of-australia-with-your-better-half',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        ' Good views of Opera House during dinner cruise in Sydney showboat',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney Harbour Bridge Climb - Sampler'
      ],
      cityHotelStay: [
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e825ecd3d7235f879378',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/643368-57.jpg',
      title: 'Best of Australian adventure for all age groups',
      destinationString: 'Cairns and Gold Coast',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 160550.5,
      itineraryCostDisplay: '1,60,551',
      hotelStarRating: 4.0,
      nights: 6,
      slug: 'best-of-australian-adventure',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE', 'KID_FRIENDLY'],
      regionName: 'Australia',
      activities: [
        'Admissions for Dreamworld and WhiteWater World',
        'Natural Bridge and World Heritage Springbrook National Park Tour',
        'Currumbin Wildlife Sanctuary',
        'Big Cat Green Island with Semi Submarine',
        "Hartley's Crocodile Adventure Half-Day Tour",
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park'
      ],
      cityHotelStay: [
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b518ad262ab8740da52086f',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/645918-4.jpg',
      title: 'An awesome 12 day Australia itinerary for honeymooners',
      destinationString: 'Melbourne, Gold Coast, Cairns and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 174412.0,
      itineraryCostDisplay: '1,74,412',
      hotelStarRating: 4.0,
      nights: 11,
      slug: 'the-perfect-12-day-australia-itinerary-for-the-adventure-lovers',
      metadata: {
        title: '',
        description: ''
      },
      bookedString: 'Someone from Bengaluru booked this 160 days ago',
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Great Barrier Reef Experience',
        'Sydney Harbour Tall Ship Twilight Dinner Cruise',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Car hire for Great Ocean Road'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e808ecd3d7235f87936f',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/wormcave.jpg',
      title: 'The perfect Australian honeymoon itinerary to fall in love with',
      destinationString:
        'Melbourne, Apollo Bay, Melbourne, Cairns, Port Douglas, Gold Coast and Sydney',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 170534.5,
      itineraryCostDisplay: '1,70,535',
      hotelStarRating: 4.0,
      nights: 15,
      slug: 'the-perfect-australian-honeymoon-itinerary-to-fall-in-love-with',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Eureka Skydeck 88',
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Great Barrier Reef Experience',
        'Gold Coast glow worm tour exposed to the ever beautiful glow worms and other natural works',
        'Kuranda Scenic Railway Up and Skyrail Rainforest Cableway Down'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 793,
          cityName: 'Apollo Bay',
          hotelIds: null,
          nights: 1
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 1
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 779,
          cityName: 'Port Douglas',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5ab8e05862ab87717b213ea0',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/642868-57.jpg',
      title:
        'Your perfect 6 night itinerary to Australia with family fantastic',
      destinationString: 'Sydney and Gold Coast',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 151934.0,
      itineraryCostDisplay: '1,51,934',
      hotelStarRating: 4.0,
      nights: 6,
      slug: 'a-6-night-trip-to-classic-australia',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ART_AND_CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast Theme Park Pass : A happy time out at Movie World and other exciting theme worlds',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb6243462ab876e15756dae',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632762-57.jpg',
      title:
        ' Australian tales: Your best pick for culinary, wildlife and nature must visits',
      destinationString: 'Perth, Uluru, Sydney and Hobart',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 188723.0,
      itineraryCostDisplay: '1,88,723',
      hotelStarRating: 3.0,
      nights: 11,
      slug:
        'venture-out-of-the-ordinary-with-the-perfect-11-day-australian-itinerary',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      activities: [
        'Port Arthur, Richmond and Tasman Peninsula Day Trip from Hobart',
        'Tour of Uluru to embrace its cultural side and venturing into Mutitjulu Waterhole ',
        'Hunter Valley Wine and Cheese Tasting Tour',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Mountain, National Park & Waterfalls Full-Day Tour',
        'Rottnest Island Ferry Transfers',
        'Peel Zoo Entry'
      ],
      cityHotelStay: [
        {
          cityId: 168,
          cityName: 'Perth',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 631,
          cityName: 'Uluru',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 140,
          cityName: 'Hobart',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a8a6be562ab8744fad2220f',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/tandem-skydive-home.jpg',
      title: 'Your best itinerary for reefs, scenic flight and more actions',
      destinationString: 'Gold Coast, Hamilton Island and Sydney',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 268463.0,
      itineraryCostDisplay: '2,68,463',
      hotelStarRating: 4.0,
      nights: 10,
      slug:
        'tantalizing-10-night-itinerary-to-gold-coast-hamilton-island-sydney',
      metadata: {
        title:
          'Book Tantalizing 10 nights 11 days itinerary to Australia for Gold Coast, Hamilton Island & Sydney!',
        description:
          'Book a tantalizing 10N/11D Australian holiday itinerary to Gold Coast, Hamilton Island and Sydney. Customize your Australia itinerary, add/remove activities, places and hotels. Book today at the best price!'
      },
      themes: ['ATTRACTION'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Sydney Opera House Guided Backstage Tour',
        'Great Barrier Reef Adventures from Hamilton Islands',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Currumbin Wildlife Sanctuary',
        'Scenic flight experience at Gold Coast',
        'Blue Mountains & Jenolan Caves Day Tour',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Wollongong Tandem Skydiving',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 283,
          cityName: 'Hamilton Island',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 4
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb1e2becd3d7235f87fecd',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648749-4.jpg',
      title: "Experience Australia's wilderness with your family",
      destinationString: 'Melbourne, Cairns, Adelaide and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 206754.0,
      itineraryCostDisplay: '2,06,754',
      hotelStarRating: 0.0,
      nights: 11,
      slug: 'experience-australias-wilderness-with-your-family',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Happy day out at the Kangaroo Island with a fun tour amidst natural highlights ',
        'Eureka Skydeck 88',
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Scenic Hot Air Balloon Flight',
        'Melbourne cricket ground tour - Admissions',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Blue Mountains Scenic Tour & River Cruise',
        'Sydney Harbour Highlights Cruise',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        'Car hire for Great Ocean Road',
        'Cairns 7,000ft Tandem Skydive'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 259,
          cityName: 'Adelaide',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: false,
      transferIncluded: true,
      visaIncluded: false,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb6eeaa62ab876e1575a3ec',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/611239.jpg',
      title: '13 night Australian wildlife itinerary for exciting travels',
      destinationString:
        'Melbourne, Cairns, Port Douglas, Gold Coast and Adelaide',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 284425.0,
      itineraryCostDisplay: '2,84,425',
      hotelStarRating: 4.5,
      nights: 13,
      slug: 'wildlife-infested-13-night-australian-itinerary-for-happy-travels',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      activities: [
        'Visit the 2,500 rare animals and lush green locations at Adelaide Zoo - Admission',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Learn about Atherton Tablelands Wildlife Tour amidst tropical rainforest',
        'Savannah Walkabout Australian Animals Eco Tour',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Cairns Sunset Cruise along Trinity Inlet exposed to mesmerising views of sea and land arenas',
        'Kuranda Scenic Railway Up and Skyrail Rainforest Cableway Down'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 779,
          cityName: 'Port Douglas',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 259,
          cityName: 'Adelaide',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a8826f662ab8744fad19bb7',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648573-4.jpg',
      title: 'Australian hearts: Perfect itinerary for nature lovers',
      destinationString: 'Melbourne, Hamilton Island and Sydney',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 202710.0,
      itineraryCostDisplay: '2,02,710',
      hotelStarRating: 4.0,
      nights: 10,
      slug: 'romantic-10-nights-itinerary-to-melbourne-hamilton-island-sydney',
      metadata: {
        title:
          'Book Romantic 11 Days & 10 Nights Honeymoon Itinerary to Australia Online!',
        description:
          'Customise this romantic 11 days & 10 nights honeymoon itinerary to Australia including Melbourne, Hamilton Island and Sydney. Book an Australia Honeymoon Package now as a wonderful wedding gift. Get the best price.'
      },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'A bit of self exploration around Queen Victoria Market, Federation Square and other places',
        'Melbourne City and Williamstown Ferry Cruise',
        'Great Barrier Reef Adventures from Hamilton Islands',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Scenic helicopter flight with Sydney views lasting for a lifetime',
        'Sydney Historic Pub Crawl Walking Tour',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 283,
          cityName: 'Hamilton Island',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bc9e8f5ecd3d7235f879401',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648751-4.jpg',
      title: 'Explore the best of Australia with your soulmate',
      destinationString: 'Gold Coast and Melbourne',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 126168.0,
      itineraryCostDisplay: '1,26,168',
      hotelStarRating: 3.0,
      nights: 7,
      slug: 'the-ultimate-australian-adventure-itinerary',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Grand Barossa Valley Day Tour',
        'Happy day out at the Kangaroo Island with a fun tour amidst natural highlights ',
        'Eureka Skydeck 88',
        'Sydney Harbour Jet Boat Thrill Ride: 30 Minutes',
        'Melbourne scenic helicopter tour with views of St. Kilda beach and Eureka Tower',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney City Sights and Bondi Beach Afternoon Tour'
      ],
      cityHotelStay: [
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 4
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb70e1d62ab876e1575bb9b',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632548-4.jpg',
      title:
        "Happy Oz memories: Australia's ultimate adventure and leisure itinerary",
      destinationString:
        'Hobart, Melbourne, Brisbane, Gold Coast, Sydney and Adelaide',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 257651.5,
      itineraryCostDisplay: '2,57,652',
      hotelStarRating: 3.5,
      nights: 15,
      slug:
        'make-happy-memories-15-nights-itinerary-to-hobart-melbourne-brisbane-gold-coast-sydney-and-adelaide',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      activities: [
        'Adelaide Hills Tour and Murray River Cruise',
        'A dig into the history of rocks and pubs via walking tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Gold Coast Sightseeing Cruise - Palazzo Versace, Sea World and the Marina Mirage resort complex',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Sydney Twilight Tour by Helicopter',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Taronga Zoo Sydney Admissions',
        'Morning Whale Watching Cruise',
        'Brilliant views from the wheel of Brisbane exposed to the best arenas and vistas of Brisbane',
        'Hop On Hop Off Hobart City Sightseeing Tour'
      ],
      cityHotelStay: [
        {
          cityId: 140,
          cityName: 'Hobart',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 115,
          cityName: 'Brisbane',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 259,
          cityName: 'Adelaide',
          hotelIds: null,
          nights: 2
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb2cccecd3d7235f880372',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/645302-4.jpg',
      title: 'Classic Australian itinerary to explore with family',
      destinationString: 'Melbourne, Gold Coast, Cairns and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 243058.5,
      itineraryCostDisplay: '2,43,059',
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'classic-australian-itinerary-to-explore-with-family',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'KID_FRIENDLY'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Admissions for Dreamworld and WhiteWater World',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Great Barrier Reef Experience',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park '
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b03eb9262ab873c5565ea38',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/cityImages/100/melbourne-1.jpg',
      title: 'Australian itinerary to explore, rejuvenate and relax',
      destinationString: 'Melbourne, Cairns, Gold Coast and Sydney',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 224129.5,
      itineraryCostDisplay: '2,24,130',
      hotelStarRating: 4.0,
      nights: 11,
      slug: 'an-epic-11-night-australia-itinerary-for-the-rejuvenating',
      metadata: {
        title: '',
        description: ''
      },
      bookedString: 'Someone from Delhi booked this 219 days ago',
      themes: ['ART_AND_CULTURE'],
      tripType: 'Friends',
      regionName: 'Australia',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Whale watching cruise experience from Circular Quay whilst sailing across Sydney Harbour and Opera House ',
        'Great Ocean Road Day Trip Adventure',
        'Big Cat Green Island with Semi Submarine',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a8bf21562ab8744fad28eb4',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/645354-4.jpg',
      title:
        "A relaxing 10 night itinerary to unravel Australia's charming side",
      destinationString: 'Melbourne, Cairns and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 199960.5,
      itineraryCostDisplay: '1,99,961',
      hotelStarRating: 4.0,
      nights: 10,
      slug: 'unforgettable-10-night-itinerary-to-melbourne-cairns-and-sydney',
      metadata: {
        title:
          'Unforgettable 11 Days 10 Nights Australian itinerary to Melbourne, Cairns & Sydney - Book Now!',
        description:
          'Book unforgettable 11 Days 10 Nights Australian itinerary to Melbourne, Cairns & Sydney. Enjoy the Australian culture, places, activities and hotels to make your honeymoon most memorable.'
      },
      themes: ['LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'A bit of self exploration around Queen Victoria Market, Federation Square and other places',
        'Melbourne City and Williamstown Ferry Cruise',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Melbourne cricket ground tour - Admissions',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Aboriginal Cultural Tjapukai by Night',
        'Sydney Twilight Tour by Helicopter',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb3052ecd3d7235f88046e',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/643370-57.jpg',
      title: 'Leisure vacation to Australia with family',
      destinationString: 'Sydney, Gold Coast, Cairns and Melbourne',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 211764.0,
      itineraryCostDisplay: '2,11,764',
      hotelStarRating: 4.5,
      nights: 13,
      slug: 'leisure-vacation-to-australia-with-family',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['KID_FRIENDLY'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Green Island Reef Cruise with Semi Submarine tour',
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Blue Mountains Scenic Tour & River Cruise',
        'Gold Coast 3 Day Theme Park Pass with transfers',
        'Car hire for Great Ocean Road'
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb70c3f62ab876e1575baab',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/643901-57.jpg',
      title: 'Magical 11 nights itinerary to the amazing parts of Australia',
      destinationString: 'Melbourne, Cairns, Adelaide and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 206753.5,
      itineraryCostDisplay: '2,06,754',
      hotelStarRating: 4.5,
      nights: 11,
      slug:
        'magical-11-nights-itinerary-to-melbourne-cairns-adelaide-and-sydney',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Happy day out at the Kangaroo Island with a fun tour amidst natural highlights ',
        'Eureka Skydeck 88',
        'Car hire for Philip Island and heading to a unique experience at Nature Park with penguins ',
        'Scenic Hot Air Balloon Flight',
        'Melbourne cricket ground tour - Admissions',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Blue Mountains Scenic Tour & River Cruise',
        'Sydney Harbour Highlights Cruise',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        'Car hire for Great Ocean Road',
        'Cairns 7,000ft Tandem Skydive'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 259,
          cityName: 'Adelaide',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378eb6b58ce008e806b2cd',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/646098-4.jpg',
      title: 'Your perfect Australia vacation itinerary for family vacations',
      destinationString: 'Sydney and Gold Coast',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 185752.0,
      itineraryCostDisplay: '1,85,752',
      hotelStarRating: 4.0,
      nights: 9,
      slug:
        'the-perfect-australia-vacation-itinerary-for-epic-family-vacations',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Informative walking tour amidst nocturnal rainforest arena and exposure to glow worms at the Mt Tamborine National Park',
        'Hop-On Hop-Off Bus Tour in Sydney',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        "Gold Coast Mega Pass - Film World, Sea World Gold Coast, Wet'n'Wild Gold Coast, and Paradise Country"
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 5
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5ae331b262ab872f3608fca6',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648920-4.jpg',
      title: 'Nature, adventure and other wonders of Australia',
      destinationString: 'Sydney, Cairns, Gold Coast and Melbourne',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 316449.5,
      itineraryCostDisplay: '3,16,450',
      hotelStarRating: 4.0,
      nights: 16,
      slug: 'a-16-night-trip-to-classic-australia',
      metadata: {
        title: '',
        description: ''
      },
      bookedString: 'Someone from Delhi booked this 243 days ago',
      themes: ['KID_FRIENDLY'],
      regionName: 'Australia',
      activities: [
        'Getting the best of Wet N Wild world with admissions and round trip transportation',
        'Phillip Island Nature Park and Wildlife Seals Cruise',
        'Enjoy Dolphin spotting at Port Stephens & Sandboarding Tour',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Great Barrier Reef Experience',
        'Great Ocean Road Day Trip Adventure',
        'Cairns Horse Riding and ATV quad bike riding tour from Cairns through rainforest and sugarcane fields',
        'Savannah Walkabout Australian Animals Eco Tour',
        'Moonlit Sanctuary Wildlife Conservation Park Evening Tour',
        'Tandem Skydive Experience',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Glide effortlessly or embark on any adventure activities like skiing and wake-boarding at Gold Coast Wake Park. ',
        'Sydney BridgeClimb - Evening',
        'Gold Coast Jet Ski Safari'
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 5
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 4
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378eb4b58ce008e806b2c9',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/621152-4.jpg',
      title: 'An impressive family itinerary for a cool Australian vacation',
      destinationString: 'Gold Coast, Cairns, Sydney and Melbourne',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 230857.0,
      itineraryCostDisplay: '2,30,857',
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'an-impressive-family-itinerary-for-a-cool-australian-vacation',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Time out with family whilst making memories at Sea World - Admissions',
        'Mount Tamborine Day Trip from the Gold Coast Including Skywalk',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure',
        'Phillip Island: Penguins, Koalas and Kangaroos Day Tour',
        'Adventure infested Big Cat Green Island Cruise tour from Cairns with buffet lunch ',
        'Hop-On Hop-Off Bus Tour in Sydney',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide'
      ],
      cityHotelStay: [
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bb6f08662ab876e1575a54e',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/634441-4.jpg',
      title: 'Get dazzled with the 14 nights Australian Outback itinerary',
      destinationString:
        'Cairns, Gold Coast, Byron Bay, Sydney, Leura, Sydney and Hobart',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 232627.0,
      itineraryCostDisplay: '2,32,627',
      hotelStarRating: 4.0,
      nights: 14,
      slug:
        'get-dazzled-with-the-14-nights-australian-outback-itinerary-get-dazzled-with-the-14-nights-australian-outback-itinerary',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'A dig into the history of rocks and pubs via walking tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Hot Air Ballooning from the Gold Coast',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Australian Outback Spectacular show',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Big Cat Green Island with Semi Submarine and Buffet Lunch',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park ',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 841,
          cityName: 'Byron Bay',
          hotelIds: null,
          nights: 1
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 831,
          cityName: 'Leura',
          hotelIds: null,
          nights: 1
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 1
        },
        {
          cityId: 140,
          cityName: 'Hobart',
          hotelIds: null,
          nights: 2
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bd95228ecd3d728f8aeaa6e',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648733-4.jpg',
      title:
        'Enjoy the scenic and wild-side of Australia with family fantastic',
      destinationString: 'Brisbane, Cairns, Adelaide and Gold Coast',
      departureCity: 'Ahmedabad',
      departureAirport: 'AMD',
      itineraryCost: 222572.25,
      itineraryCostDisplay: '2,22,572',
      hotelStarRating: 4.0,
      nights: 8,
      slug: 'enjoy-the-scenic-and-wild-side-of-australia-with-family-fantastic',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['LEISURE', 'KID_FRIENDLY'],
      regionName: 'Australia',
      activities: [
        'Happy day out at the Kangaroo Island with a fun tour amidst natural highlights ',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Cairns Jet Boat Ride',
        'Cairns by Night Walking Tour including Cairns Wildlife Dome and Cairns Night Markets',
        'Brisbane City Sightseeing Afternoon Tour',
        'Brilliant views from the wheel of Brisbane exposed to the best arenas and vistas of Brisbane'
      ],
      cityHotelStay: [
        {
          cityId: 115,
          cityName: 'Brisbane',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 259,
          cityName: 'Adelaide',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 1
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bd01546ecd3d777c3b2b9be',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/647406-4.jpg',
      title: 'Romance filled Australian honeymoon break',
      destinationString: 'Sydney, Melbourne, Cairns and Gold Coast',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 184282.0,
      itineraryCostDisplay: '1,84,282',
      hotelStarRating: 0.0,
      nights: 12,
      slug: 'romance-filled-australian-honeymoon-break',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['LEISURE'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Flecker Botanical Gardens',
        'Green Island Reef Cruise with Semi Submarine tour',
        'Eureka Skydeck 88',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Scenic flight experience at Gold Coast',
        'Blue Mountains Scenic Tour & River Cruise',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World"
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: false,
      transferIncluded: false,
      visaIncluded: false,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5ab7529762ab877535412fb5',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/643370-57.jpg',
      title: 'A 8 night trip to the adventurous side of Australia with family',
      destinationString: 'Cairns and Melbourne',
      departureCity: 'Mumbai',
      departureAirport: 'BOM',
      itineraryCost: 140725.5,
      itineraryCostDisplay: '1,40,726',
      hotelStarRating: 4.0,
      nights: 8,
      slug: 'a-8-night-trip-to-classic-australia',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ART_AND_CULTURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Barrier Reef Experience',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure'
      ],
      cityHotelStay: [
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 4
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b56ff6862ab874b9bdff70b',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/646438-4.jpg',
      title: 'Celebrate love in the Australian lands',
      destinationString: 'Sydney, Gold Coast and Melbourne',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 160122.5,
      itineraryCostDisplay: '1,60,123',
      hotelStarRating: 4.0,
      nights: 7,
      slug: 'an-ideal-7-night-australia-itinerary-for-a-honeymoon-getaway',
      metadata: {
        title: '',
        description: ''
      },
      bookedString: 'Someone from Delhi booked this 155 days ago',
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Delicious dinner cruise during sunset at Sydney Harbour exposed to amazing vistas and views around the arena ',
        "Super Pass: Film World, Sea World & Wet'n'Wild Water World",
        'Morning Whale Watching Cruise',
        'Car hire for Great Ocean Road'
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 2
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5b81615262ab875a6cef81ea',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/632545-4.jpg',
      title:
        'Kindling the romantic side of you : Your perfect Australia itinerary',
      destinationString: 'Brisbane, Gold Coast, Melbourne and Sydney',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 202238.0,
      itineraryCostDisplay: '2,02,238',
      hotelStarRating: 4.0,
      nights: 8,
      slug: 'kindling-the-lovely-in-you-a-perfect-australia-itinerary',
      metadata: {
        title: '',
        description: ''
      },
      bookedString: 'Someone from Delhi booked this 123 days ago',
      themes: ['ATTRACTION', 'KID_FRIENDLY'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        ' Good views of Opera House during dinner cruise in Sydney showboat',
        'Gold Coast 3 Day Theme Park Pass'
      ],
      cityHotelStay: [
        {
          cityId: 115,
          cityName: 'Brisbane',
          hotelIds: null,
          nights: 1
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 2
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378e88b58ce008e806b27f',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/648812-4.jpg',
      title: ' An 8 day Australia itinerary for memorable family vacations',
      destinationString: 'Gold Coast and Sydney',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 141114.0,
      itineraryCostDisplay: '1,41,114',
      hotelStarRating: 3.5,
      nights: 7,
      slug: 'for-epic-family-vacations-an-8-day-australia-itinerary',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['LEISURE', 'KID_FRIENDLY'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Blue Mountains Scenic Tour & River Cruise',
        "Gold Coast Mega Pass - Film World, Sea World Gold Coast, Wet'n'Wild Gold Coast, and Paradise Country"
      ],
      cityHotelStay: [
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 4
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5a378e6ab58ce008e806b24c',
      type: 'RECENTLY_BOOKED',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/flecker2.jpg',
      title: 'The 13 day Australia family adventure vacation',
      destinationString: 'Melbourne, Cairns, Gold Coast and Sydney',
      departureCity: 'Chennai',
      departureAirport: 'MAA',
      itineraryCost: 180900.5,
      itineraryCostDisplay: '1,80,901',
      hotelStarRating: 4.0,
      nights: 12,
      slug: 'the-13-day-australia-family-adventure-vacation',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'LEISURE'],
      tripType: 'Family',
      regionName: 'Australia',
      activities: [
        ' A bit of Cairns tour with visits to Flecker Botanical Garden and other top places',
        'Time out with family whilst making memories at Sea World - Admissions',
        'Fascinating time-out with penguins at Phillip Island Visitor Information Centre',
        'Great Ocean Road Sunset Tour',
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Currumbin Wildlife Sanctuary',
        'Exploration of the beautiful Gold Coast Infinity arena - Admissions included',
        'Big Cat Green Island with Semi Submarine',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park '
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: false,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcabab1ecd3d7235f87c640',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/645920-4.jpg',
      title: 'Adventure bound Australian venture',
      destinationString: 'Sydney, Cairns and Gold Coast',
      departureCity: 'Delhi',
      departureAirport: 'DEL',
      itineraryCost: 218913.5,
      itineraryCostDisplay: '2,18,914',
      hotelStarRating: 4.0,
      nights: 9,
      slug: 'adventure-bound-australian-venture',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE'],
      regionName: 'Australia',
      activities: [
        'Jet Boat Ride from Main Beach',
        'Bungy jumping from 165 ft distance at Cairns',
        'Great Barrier Reef Experience',
        'Sydney Harbour Jet Boat Thrill Ride: 30 Minutes',
        'Byron Bay Tandem Skydiving',
        'Sydney Harbour Bridge Climb - Sampler'
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcaca38ecd3d7235f87d2a6',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/5bc9e5c3ecd3d7235f8791cd/640x640/jetboat.jpg',
      title: 'Australian Double Dhamaka: Honeymoon & adventure at one shot',
      destinationString: 'Sydney, Cairns and Gold Coast',
      departureCity: 'Outside India',
      departureAirport: '$$$',
      itineraryCost: 112050.0,
      itineraryCostDisplay: '1,12,050',
      hotelStarRating: 0.0,
      nights: 9,
      slug: 'adrenaline-pumped-up-australian-delights',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ADVENTURE', 'BEACH'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Jet Boat Ride from Main Beach',
        'Bungy jumping from 165 ft distance at Cairns',
        'Great Barrier Reef Experience',
        'Sydney Harbour Jet Boat Thrill Ride: 30 Minutes',
        'Byron Bay Tandem Skydiving',
        'Sydney Harbour Bridge Climb - Sampler'
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: false,
      hotelsIncluded: false,
      transferIncluded: true,
      visaIncluded: false,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5c04eb1ba56bab12adc2a6d2',
      type: 'ON_SALE',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/eureka.jpg',
      title: 'Exciting 7 nights in Melbourne, Sydney and Goldcoast',
      destinationString: 'Melbourne, Sydney and Gold Coast',
      departureCity: 'Outside India',
      departureAirport: '$$$',
      itineraryCost: 98903.0,
      itineraryCostDisplay: '98,903',
      hotelStarRating: 0.0,
      nights: 7,
      slug: 'exciting-7-nights-in-melbourne-sydney-and-goldcoast',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION'],
      regionName: 'Australia',
      activities: [
        'A happy timeout whilst self exploring the Hyde Park and other fancy places in Sydney at leisure',
        'Eureka Skydeck 88',
        'Car Hire at Gold Coast - 24 hours',
        'Melbourne cricket ground tour - Admissions',
        'Sydney Tower Eye',
        'Car Hire at Melbourne - 24 hours'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 2
        }
      ],
      flightsIncluded: false,
      hotelsIncluded: false,
      visaIncluded: false,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5c0a01d7a56bab6a7cbcb584',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/egypt.jpg',
      title: 'Experience a whirlwind trip to Australia for 6 nights',
      destinationString: 'Melbourne, Sydney and Gold Coast',
      departureCity: 'Outside India',
      departureAirport: '$$$',
      itineraryCost: 95749.0,
      itineraryCostDisplay: '95,749',
      hotelStarRating: 3.0,
      nights: 6,
      slug: '6-nights-trail-to-adventurous-australia',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION', 'LEISURE'],
      regionName: 'Australia',
      activities: [
        'Eureka Skydeck 88',
        'Melbourne City and Williamstown Ferry Cruise',
        'Gold Coast SkyPoint Observation Deck - Admission Ticket',
        'Exploration of the beautiful Gold Coast Infinity arena - Admissions included',
        'Yarra Valley Balloon Flight at Sunrise',
        'Sydney Opera House Tour with live commentary on the wonders of the building and constructions by an expert guide',
        'Morning Whale Watching Cruise'
      ],
      cityHotelStay: [
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 2
        },
        {
          cityId: 103,
          cityName: 'Gold Coast',
          hotelIds: null,
          nights: 2
        }
      ],
      flightsIncluded: false,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: false,
      visaType: 'NORMAL'
    },
    {
      campaignItineraryId: '5bcb059becd3d7235f87f35c',
      type: 'POPULAR',
      image:
        'https://d3lf10b5gahyby.cloudfront.net/campaignitinerary/ALREADY_EXISTING/640x640/634441-4.jpg',
      title: 'Blissfully yours: Romantic Australian vacation',
      destinationString: 'Sydney, Cairns and Melbourne',
      departureCity: 'Bengaluru',
      departureAirport: 'BLR',
      itineraryCost: 162574.5,
      itineraryCostDisplay: '1,62,575',
      hotelStarRating: 4.0,
      nights: 9,
      slug: 'blissfully-yours-romantic-australian-vacation',
      metadata: {
        title: '',
        description: ''
      },
      themes: ['ATTRACTION'],
      tripType: 'Honeymoon',
      regionName: 'Australia',
      activities: [
        'Sydney Attractions Pass: Sea Life Aquarium, Sydney Tower Eye, Wildlife Zoo and Madame Tussaud',
        'Kuranda Scenic Railway Day Trip with Rainforestation Nature Park',
        'Great Ocean Road Day Trip Adventure',
        "Enrichment to the heart & soul at Yarra Valley Wine and Winery Tour to the best wineries under expert's assistance",
        'Big Cat Green Island with Semi Submarine',
        'Enriching Blue mountains trip to Sydney Olympic Park, Featherdale Wildlife Park '
      ],
      cityHotelStay: [
        {
          cityId: 104,
          cityName: 'Sydney',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 101,
          cityName: 'Cairns',
          hotelIds: null,
          nights: 3
        },
        {
          cityId: 100,
          cityName: 'Melbourne',
          hotelIds: null,
          nights: 3
        }
      ],
      flightsIncluded: true,
      hotelsIncluded: true,
      transferIncluded: true,
      visaIncluded: true,
      visaType: 'NORMAL'
    }
  ],
  testimonials: [
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Australia',
      fName: 'Nikisha Jain',
      mName: '',
      lName: '',
      cityOfDeparture: 'Mumbai',
      dateOfDeparture: 1501632000000,
      destination: 'Melbourne',
      ttype: 'Honeymoon',
      review:
        'Had a lovely trip to australia....Pickurtrail were quick and helpful most of the times....Well planned and executed....Had a beautiful vacation....Thank you....',
      fbLink: 'https://www.facebook.com/nikijjain/posts/10214040664000756:0',
      profileImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/221/fbProfile/800xh/cover.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/16098/others1.jpg',
      itineraryId: '59533c9c62ab872110ac8d45',
      journalLinks: [
        'https://blog.pickyourtrail.com/a-couples-guide-to-the-perfect-australian-vacation/'
      ],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/221/other/800xh/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/221/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/221/other/800xh/others4.jpg'
      ],
      testimonialId: 221,
      shortReview:
        'Pickyourtrail team was quick and helpful throughout the trip, with their conciege assistance!',
      shortestReview: 'Every bit of our tour was well planned and executed.',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'New Zealand + Australia',
      fName: 'Tanveer Fatima',
      mName: '',
      lName: '',
      cityOfDeparture: 'Mumbai',
      dateOfDeparture: 1518912000000,
      destination: 'Sydney',
      ttype: 'Solo',
      review:
        'I was referred to PYT by my nephew. I ve to mention i had an awesome trip to Australia. It was a great experience where i had a hassle free vacation,thanks to d well planned accomodation & sightseeing organised by PYT. Special mention for Mr. Krish who managed everything perfectly. Worth d money!',
      fbLink:
        'https://www.facebook.com/tanveer.fatima.7/posts/10214491831142430:0',
      profileImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/fbProfile/800xh/profile.jpg',
      coverImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/fbCover/800xh/20180304_095644.jpg',
      itineraryId: '5a2b92b94065d117076a2d3e',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180304_103138.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180304_131548.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180304_132031.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180321_072045.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180325_183559.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180325_190036.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180326_121610.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/20180326_121655.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/cover.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/others1.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/56/other/800xh/others2.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/25065/others3.jpg'
      ],
      testimonialId: 56,
      shortReview:
        'Was referred to PYT by my nephew. Had an amazing trip for real. Thanks guys',
      shortestReview:
        'Special cheers to the teams who managed my Australia trip perfectly end to end!',
      type: 'Solo'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Europe',
      fName: 'Gaurav Prabhu',
      mName: '',
      lName: '',
      cityOfDeparture: 'Mumbai',
      dateOfDeparture: 1519862400000,
      destination: 'Prague',
      ttype: 'Honeymoon',
      review:
        'Prague- Vienna-Budapest trip review\nWe were discussing our honeymoon in the month of August just when our wedding date was finalized and we zeroed on Prague- Vienna- Budapest as we both wanted a historic but serene destination. While our research was on we came across Pick your trail. The fact that you can customize your travel as per your plan was the cynosure of their portal for us cause that was our prerogative. We decided to go with them. The interaction we had with their executives for visa, itenery and during the trip was very helpful and to the point. They suggested we add Bratislava in Slovakia to our 9 day trip turned out to be a blessing in disguise as it is a beautiful capital city. All the day and night trips planned in all the cities were interesting and the guides were also very friendly. We loved the fact that we could interact with people from other countries during our trip in Budapest. The highlights of the trip were the Cesky Krumlov walking trip while in Prague, the inside visit to Schonbrun palace in Vienna was breathtaking and Danube evening River Cruise in Budapest. \nComing to the hotels selected by them, all the three were well located and easily accessible from the nearest metro/subway station which made travelling easier for us. Special mention to the hotel in Budapest, the Burg hotel. The hotel was right outside a beautiful tourist location called St. Matthias church. This was an incing on the cake as the location was truly mesmerizing at all times of the day.To sum it up we were extremely happy with the planning and execution of Pick your trail. Appreciate the fact that they are open to suggestions and feedback (special thanks to Shashikant , Lony and Sunil from Pickyourtrail team ). We look forward to some more trips with them. Highly recommended for people who love to explore new places with their help.',
      fbLink: 'https://www.facebook.com/prgaurav/posts/10213644932109232:0',
      profileImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/fbProfile/800xh/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/19381/cover.jpg',
      itineraryId: '59aa54444065d16cc4c0730c',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/others1.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/19381/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/others4.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284382.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284385.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284386.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284388.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284391.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284392.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284393%20%281%29.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/58/other/800xh/photo6127281184804284394.jpg'
      ],
      testimonialId: 58,
      shortReview:
        'The interaction we had with their executives was very helpful and to the point.',
      shortestReview:
        'Great team with so much destination knowledge! Thanks PYT!',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'New Zealand',
      fName: 'Abilash Ramanathan V',
      mName: '',
      lName: '',
      cityOfDeparture: 'Chennai',
      dateOfDeparture: 1518307200000,
      destination: 'Auckland',
      ttype: 'Honeymoon',
      review:
        'Our New-zealand trio with them is awesome to de core!!!!!.. The best place to keep you guided through the tour 24/7. It’s awesome to take Care the passengers all the way and make them stop worrying and they will take care of things and what u need. Pleasure being a customer with Pickyourtrail...\n\nThanks guys and your doing a great job and keep it up. Was a nice honeymoon and a peaceful trip ever. Love the way you take and guide with the customer through calls and support them. Packages are very open to suggestions and free to call out.\n\nEven through midnights and their work schedule they support the customer without hesitation with no time schedule and help them through their queries. I LOVE IT SERIOUSLY.',
      fbLink:
        'https://www.facebook.com/abilashramanathan.v/posts/2079876365362046:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/21137/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/21137/cover.jpg',
      itineraryId: '59d89dc34065d12b84bfa539',
      journalLinks: [],
      testimonialId: 60,
      shortReview:
        'Thanks for planning my NZ trip with such perfection. Had a peaceful trip!',
      shortestReview:
        "PYT's work schedule and support all day long is amazing!",
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Bali',
      fName: 'Naren Mohandoss',
      mName: '',
      lName: '',
      cityOfDeparture: 'Chennai',
      dateOfDeparture: 1509840000000,
      destination: 'Kuta',
      ttype: 'Honeymoon',
      review:
        'One of the best trip I have ever went on through an agencies. Team took an keen interest in making sure I reach each and every destinations of mine on time. I would get a message about my itinerary and on my flight timings. The guides where so polite and humble. Overall it was an safest trip. I would recommend them blindly.',
      fbLink:
        'https://www.facebook.com/naren.mohandoss/posts/10215397091143467:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/22028/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/22028/cover.jpg',
      itineraryId: '59e4c5c04065d15cd166ea34',
      journalLinks: [],
      testimonialPhotos: [
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/22028/others1.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/22028/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/others4.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218059.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218060.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218062.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218063.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218064.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218066.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/63/other/800xh/photo6062363939536218067.jpg'
      ],
      testimonialId: 63,
      shortReview:
        'Customized vacation planning done at the best possible manner. Kudos guys!',
      shortestReview:
        'It was a great trip. I would recommend PYT blindly to all',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Bali',
      fName: 'Kuzhali Karthikeyan',
      mName: '',
      lName: '',
      cityOfDeparture: 'Chennai',
      dateOfDeparture: 1509926400000,
      destination: 'Kuta',
      ttype: 'Honeymoon',
      review:
        'It was a memorable trip to both of us and pick your trial just made everything easy :) Adharsh being a known person to me understood my needs and crafted the itenary just the way I expected!!! Shailesh who constantly kept in touch with us in our entire trip thru telegram and updates us on the daily schedule :) thanks a lot team for giving us wonderful experience overall ?',
      fbLink: 'https://www.facebook.com/KuzhaliSS/posts/1640654812717642:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/20563/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/20563/cover.jpg',
      itineraryId: '59e4bb2f4065d15cd166e523',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/0ba73d2f-8e97-4758-8186-a33a2254db98.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/2f02577e-3e76-442a-b468-9502aa63b3aa.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/45be5716-bea5-4e5b-8f12-c9d4d559ff35.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/64df0fcc-c80b-4613-942c-9297daa385c2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/6ba730a3-5b38-4a75-8a1d-3b2215425140.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/94910ecc-aedf-475a-9c8d-7d0e171df00e.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/dd.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/ddd0a6eb-4772-461b-a254-a7c3fec101ce.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/others1.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/65/other/800xh/others4.jpg'
      ],
      testimonialId: 65,
      shortReview:
        'Itineraries crafted with perfection and maximum support provided! Good job PYT!',
      shortestReview:
        'Thanks a lot team for giving us wonderful experience overall ',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Europe',
      fName: 'Vandana Sekhar',
      mName: '',
      lName: '',
      cityOfDeparture: 'Outside India',
      dateOfDeparture: 1507334400000,
      destination: 'Paris',
      ttype: 'Honeymoon',
      review:
        'We planned our first Anniversary celebration to Amesterdam and Paris with Pick Your Tail. Since this was our first time to Europe we had a lot of doubts and difficulties on how to go about things but Pick your Trail helped us in every way possible. From forming the complete itenary by Agny according to our requirement to providing complete support during our trip there and helping us whenever we had an issue by Lony. We will definitely be looking forward to plan our next trip with them',
      fbLink:
        'https://www.facebook.com/vandana.sekhar.33/posts/10154736266751268:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/cover.jpg',
      itineraryId: '59899a8762ab8766242841c7',
      journalLinks: [],
      testimonialPhotos: [
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/others1.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/67/other/800xh/others3.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18209/others4.jpg'
      ],
      testimonialId: 67,
      shortReview:
        'Extensive support during travel adhering to our queries throughout the vacation!',
      shortestReview: 'Good support and great planning guys. Thanks PYT team!',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Europe',
      fName: 'Harikrishnan Ravindran',
      mName: '',
      lName: '',
      cityOfDeparture: 'Bengaluru',
      dateOfDeparture: 1508371200000,
      destination: 'Paris',
      ttype: 'Family',
      review:
        "Recently made a 10 day Paris and Italy vacation with family with the help of Pickyourtrail.The team support and service was fantastic right from the initial planning stages with lot of useful inputs which really helped optimise our trail. They have a superb website with almost all information that one would need while planning a vacation readily available with multiple options based on your interests, budget etc. User interface of the website is just too good.There wasn't even a spot of bother when it came to execution and all the arrangements made all through the 10 days were 100% hassle or tension free.\nThe 24X7 concierge service during the trail is another attraction where help or suggestions will be available for you at short notice and you feel the virtual presence of a guide, in case of queries.You are doing a great job guys. Keep making trails memorable. All the Best! ?",
      fbLink:
        'https://www.facebook.com/harikrishnan.ravindran.9/posts/10159488410220032:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18179/profile.jpg',
      coverImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18179/cover.jpg',
      itineraryId: '59859b9862ab8707112ad0fc',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/69/other/800xh/others1.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/69/other/800xh/others2.jpg'
      ],
      testimonialId: 69,
      shortReview:
        'The support and services were fantastic right from the initial stages with useful inputs ',
      shortestReview:
        'Super work by the team in organising my trip! Kudos PYT!',
      type: 'Family'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Bali',
      fName: 'Akshi Pandita',
      mName: '',
      lName: '',
      cityOfDeparture: 'Delhi',
      dateOfDeparture: 1507939200000,
      destination: 'Kuta',
      ttype: 'Honeymoon',
      review: 'Stephy is extremely courteous ?? kudos to the entire team',
      fbLink: 'https://www.facebook.com/akshi.pandita/posts/1666385180080413:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/17958/profile.jpg',
      coverImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/72/fbCover/800xh/others1.jpg',
      itineraryId: '597e02c962ab873134a863d3',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/72/other/800xh/cover.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/72/other/800xh/others2.jpg'
      ],
      testimonialId: 72,
      shortReview:
        'Wonderful support and brilliant services offered. Great work team!',
      shortestReview: 'Courteous staffs helping us throughout the trip. Kudos!',
      type: 'Honeymoon'
    },
    {
      timeOfReview: 0,
      star: 5.0,
      region: 'Europe',
      fName: 'Sreekhanth Vankineni',
      mName: '',
      lName: '',
      cityOfDeparture: 'Mumbai',
      dateOfDeparture: 1506038400000,
      destination: 'Lucerne',
      ttype: 'Honeymoon',
      review:
        'We jus got back from our honeymoon trip to switzerland and italy. Our experience with Pickyourtrail was totally amazing. Special thanks to Agni, Sanjay and Jaideep. Their meticulous planning, precise timings and attention to every small detail in our itinerary ensured that we had an amazing trip without any hassle. We would definitely choose them for our future trips. Thank you for everything.',
      fbLink:
        'https://www.facebook.com/srikanth.vankineni/posts/1540537426007574:0',
      profileImage:
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18258/profile.jpg',
      coverImage:
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/fbCover/800xh/cover.jpg',
      itineraryId: '59847f604065d139a6ff289b',
      journalLinks: [],
      testimonialPhotos: [
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170923_142051.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170923_214947.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170925_175952.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170925_180854.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170925_191439.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170926_100056.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170927_112051.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170927_124533.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170927_124708.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170927_142256.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170928_110807.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170930_095103.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170930_142817.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20170930_142830.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_113235.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18258/20171002_113838.mp4',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_114721.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_115640.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_123827.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_125634.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/20171002_125833.jpg',
        'https://pyt-testimonialimages.s3.ap-south-1.amazonaws.com/18258/20171003_204540.mp4',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others1.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others2.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others3.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others4.jpg',
        'https://d3lf10b5gahyby.cloudfront.net/testimonials/78/other/800xh/others5.jpg'
      ],
      testimonialId: 78,
      shortReview:
        'An amazing trip due to the constant support and services offered by the PYT team!',
      shortestReview: 'Every bit of our vacay was delightful!',
      type: 'Honeymoon'
    }
  ],
  campaignDetails: {
    key: 'packages',
    bannerText: "Book fab vacations with India's most trusted planner",
    image:
      'https://d3lf10b5gahyby.cloudfront.net/packages/banners/holidays/package3.jpg',
    seoDetails: {
      _id: '5ac76c63914130449465d5f3',
      seoId: 'PACKAGES_DESTINATION',
      metaTitle: 'Holiday Tour Packages, Travel Packages to Top Destinations!',
      metaDescription:
        'Book a customized holiday tour package. Explore the best of vacations, be it your honeymoon or family holiday. The tailor-made holiday packages give you the freedom to select activities, hotels, flights, places from various options.',
      h1Title: 'Book Holiday Packages',
      seoContent:
        '<h3>Holiday packages - your calling!</h3>\n<p>Almost every other day, we are all tempted to break the monotony and mundanity of life and head off on a vacation. While wanting to go on a holiday is a desire shared by all, where to head to and for what vary substantially. So if you’ve decided to go for a vacation - now to the most important part - where? Some of you, to escape your hectic lifestyle, choose quiet, calm and peaceful places like alpine valleys/villages against a beautiful backdrop and landscape or isolated beach islands - where you can bask while reading your favourite book facing the calm waters of the ocean/sea to cool off. Or, you could be one of those folks who look for adventure, enthusiasm and fun during their holiday. Perhaps, your interest lies in architecture, history art and hence you might want to spend your holiday observing, admiring and educating yourself with the different cultures of the world. With any other travel organisation, you either get to choose one or the other packages. Well, Pickyourtrail isn’t any other travel planner. Our holiday packages are themed in special categories that would suit you perfectly.</p>\n\n<h3>Pick the theme of your choice</h3>\n<p>For you love birds, our travel packages are themed to bring in more romance and sparkles. Be it a honeymoon or just another trip, our <a href="https://pickyourtrail.com/honeymoon-packages">honeymoon packages</a> will make sure your holiday is nothing short of a fairytale. Similarly, we offer other themed packages that cater to <a href="https://pickyourtrail.com/family-packages/">family vacations</a>, <a href="https://pickyourtrail.com/beach-packages/">beach holidays</a>, packages crafted for adventure enthusiasts, art and leisure lovers, etc. Our tour packages are extremely customer-oriented and in fact all the itineraries are crafted solely based on your preferences, interest and convenience. The most important benefit you get by booking tour packages with us is that - once you have decided the theme you like, there’s still ample customisation you can do. By no means are you restricted to stick to only those activities pertaining to your theme. On the other hand, every detail on your itinerary can be edited by you - thus giving you the truly personalised holiday packages!</p>\n\n<h3>Pick Pickyourtrail</h3>\n<p>The destinations are wide and myriad. From celebrating love in the snowy Alps of Switzerland to skydiving, hiking and bungee jumping with your squad in New Zealand to surfing, scuba diving and experiencing buzzing nightlife with friends to exploring world cultures and architecture with family - there’s something for every traveller that Pickyourtrail’s holiday packages offer! All you have to do is let us know your interests and preferences and we’ll make sure your holiday is nothing short of a perfect getaway!</p>',
      pageUrl: 'https://pickyourtrail.com/packages',
      addMetaNoFollow: false,
      h1TitleDisplay: 'Customise Holiday Tour Packages!'
    },
    paid: false
  }
};

export default getPackages;
