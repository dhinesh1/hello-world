import React from 'react';
import getVacation from '../__fixtures__/getVacationResponse';
import getPackages from '../__fixtures__/getPackagesResponse';
import getMaldivesHotel from '../__fixtures__/getMaldivesResponse';
import getSeychellesHotel from '../__fixtures__/getSeychelleseResponse';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import {configureStoreTest} from '../store/configureStore';
import configureMockStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';
const store = configureStoreTest(window.REDUX_STATE || {});
const middlewares = [thunk];

export const getMockStore = () => {
  return configureMockStore(middlewares);
};

export const getService = (succeeds = true) => {
  return body => () =>
    new Promise((resolve, reject) => {
      //setTimeout(() => (succeeds ? resolve(body) : reject(body)), 1);
      succeeds ? resolve(body) : reject(body);
    });
};

export const getVacationsProps = () => {
  const history = createMemoryHistory();
  return {
    match: {
      isExact: true,
      hasError: true,
      params: null,
      path: '/*',
      url: '/vacations/australia',
      locations: {
        pathname: ''
      }
    },
    actions: {},
    packages: getVacation,
    history: history
  };
};

export const getPackagesProps = () => {
  const history = createMemoryHistory();
  return {
    match: {
      isExact: true,
      hasError: true,
      params: null,
      path: '/*',
      url: '/packages',
      locations: {
        pathname: ''
      }
    },
    actions: {},
    packages: getPackages,
    history: history
  };
};

// export const getPackagesProps = () => {
//   const history = createMemoryHistory();
//   return {
//     match: {
//       isExact: true,
//       hasError: true,
//       params: { destination: 'australia' },
//       path: '/packages/:destination',
//       url: '/packages/australia',
//       locations: {
//         pathname: ''
//       }
//     },
//     actions: {},
//     packages: getPackages,
//     history: history
//   };
// };

export const getMaldivesProps = () => {
  const history = createMemoryHistory();
  return {
    actions: {},
    hotelDetails: getMaldivesHotel,
    history: history
  };
};
export const getSeychellesProps = () => {
  const history = createMemoryHistory();
  return {
    actions: {},
    hotelDetails: getSeychellesHotel,
    history: history
  };
};

export const CustomProvider = ({ state, children }) => {
  let insternalState = state ? configureStoreTest(state) : store;
  return <Provider store={insternalState}>{children}</Provider>;
};

export const getEventParams = () => {
  return {
    target: {
      tagName: '',
      classList: '',
      closest: function(){

      }
    },
    preventDefault: function() {
      //Function of the event
    }
  };
};
