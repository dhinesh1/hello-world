export const getVacations = ({}, service) => dispatch => {
  // note default service value; this is our async call
  return service({})
    .then(({ type, response }) => {
      if (type === 'FETCH_VACATIONS') {
        dispatch({
          type: type,
          payload: response
        });
      } else {
        dispatch({ type: 'FETCH_VACATIONS_ERROR' });
      }
    })
    .catch(() => dispatch({ type: 'FETCH_VACATIONS_ERROR' }));
};

export const getPackage = ({}, service) => dispatch => {
  // note default service value; this is our async call
  return service({})
    .then(({ type, response }) => {
      if (type === 'FETCH_PACKAGES') {
        dispatch({
          type: type,
          payload: response
        });
      } else {
        dispatch({ type: 'FETCH_PACKAGES_ERROR' });
      }
    })
    .catch(() => dispatch({ type: 'FETCH_PACKAGES_ERROR' }));
};

export const getMalSezHotel = ({}, service) => dispatch => {
  // note default service value; this is our async call
  return service({})
    .then(({ type, response }) => {
      if (type === 'FETCH_MALSEZ_HOTELS') {
        dispatch({
          type: type,
          payload: response
        });
      } else {
        dispatch({ type: 'FETCH_MALSEZ_HOTELS_ERROR' });
      }
    })
    .catch(() => dispatch({ type: 'FETCH_MALSEZ_HOTELS_ERROR' }));
};
