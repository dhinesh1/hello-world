import React from 'react';
import Lottie from 'react-lottie';

import logClientError from '../helpers/logClientError';
import { LoadingBars } from '../helpers/loaderHelper';
import { AppConfig } from '../app-config';
const D3 = AppConfig.images_cdn_url_s3;

/**
 * Wrapper of the lottie control
 */
export default class LottieControl extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isStopped: false,
      isPaused: false,
      animationData: null
    };
  }

  componentDidMount(){
    /**
     * Moved animations data to S3 - to move it our of the JS bundle and load it async
     * The initial data for the animation will be null - once we got the data we will update the state with new data
     * For some reason if weren't able to get the data from remote we will load the data from the local file in catch()
     */
    const homeChatAnimationURL = `${D3}animations/Landing_chat.json`;
    fetch(homeChatAnimationURL)
      .then(response => response.json())
      .then(resData => {
        this.setState({animationData: resData});
      }).catch(err => {
        // Log the error in sentry to analyze it further
        logClientError("Animation data fetch from remote failed!", {
          url: homeChatAnimationURL
        });
        
        // // Fallback - This will ensure the user has the animation loaded even if something went wrong in reading data from remote
        // // This will not affect the bundle size as this will be handled at run-time
        // const localAnimationData = require('./source/Chat_temp_test.json');

        // this.setState({
        //   animationData: localAnimationData
        // })
      });
  }

  render() {
    /**
     * Reading animation data from the local state of this component
     */
    let {animationData} = this.state;

    /**
     * Default options of the Lottie controls
     */
    const defaultOptions = {
      loop: true,
      autoplay: true,
      animationData: animationData,           // local state data
      rendererSettings: {
        preserveAspectRatio: 'xMidYMid slice'
      }
    };

    /**
     * Will return loading bar as a placeholder until we get load the data from remote / local on fall-back
     */
    if(!animationData){
      return <div className="animation-placeholder vertical-center">
        <LoadingBars />
      </div>;
    }
    
    /**
     * Return the element of the lottie
     */
    return (
      <React.Fragment>
        <Lottie
          options={defaultOptions}
          isStopped={this.state.isStopped}
          isPaused={this.state.isPaused}
        />
      </React.Fragment>
    );  
  }
}
