import React from 'react';
import Loadable from 'react-loadable';
import Loader from './../common_components/Loader';

/** 
 * Async components
*/

// Home page loadable component
export const HomeLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "home" */ './../pages/landing/Landing'),
  loading: () => <Loader />
});

// Packages page
export const PackagesLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "packages" */ './../pages/packageV3/Packages'),
  loading: () => <Loader />
});

// Voyager components
export const VoyagerLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "voyager" */ './../voyager/Voyager'),
  loading: () => <Loader />
});

export const SemLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "sem" */ './../pages/sem/Sem'),
  loading: () => <Loader />
});

export const TestimonialsComponentLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "testimonials" */ './../pages/testimonials/Testimonials'),
  loading: () => <Loader />
});

export const SiteMapLoadable = Loadable({
  loader: () => import(/* webpackChunkName: "sitemap" */ '../pages/Sitemap'),
  loading: () => <Loader />
});

// india travel page
export const IndiaTravelTrendsLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "india-travel" */ './../pages/IndiaTravelTrends'),
  loading: () => <Loader />
});

// Static pages
export const AboutUsLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "static" */ './../pages/about/AboutUs'),
  loading: () => <Loader />
});
export const ContactLoadable = Loadable({
  loader: () => import(/* webpackChunkName: "static" */ './../pages/Contact'),
  loading: () => <Loader />
});
export const TermsAndConditionsLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "static" */ './../pages/TermsAndConditions'),
  loading: () => <Loader />
});
export const PrivacyPolicyLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "static" */ './../pages/PrivacyPolicy'),
  loading: () => <Loader />
});
export const CancellationPolicyLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "static" */ './../pages/CancellationPolicy'),
  loading: () => <Loader />
});
export const CareersLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "static" */ './../pages/careers/Careers'),
  loading: () => <Loader />
});
export const CareerDetailsLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "static" */ './../pages/careers/components/JobDetailsModal'),
  loading: () => <Loader />
});

export const FaqLoadable = Loadable({
  loader: () => import(/* webpackChunkName: "static" */ './../pages/Faq'),
  loading: () => <Loader />
});

// postcard
export const PostCardLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "post-card" */ './../pages/postcard/Postcard'),
  loading: () => <Loader />
});
export const PostcardSuccessLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "post-card" */ './../pages/postcard/postcardSuccess'),
  loading: () => <Loader />
});

// Profile screens
export const YourVacationsHomeLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "profile" */ './../pages/your_vacations/YourVacationsHome'),
  loading: () => <Loader />
});
export const BookedTripDetailsLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "profile" */ './../pages/booked_itinerary/BookedTripDetails'),
  loading: () => <Loader />
});
export const YourAccountLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "profile" */ './../pages/your_accounts/YourAccounts'),
  loading: () => <Loader />
});
export const PreferencesUnsubscribePageLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "unsubscribe" */ './../pages/your_accounts/PreferencesUnsubscribePage'),
  loading: () => <Loader />
});
export const SavedItinerariesLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "profile" */ './../pages/saved_itineraries/SavedItineraries'),
  loading: () => <Loader />
});

// Agents
export const AgentLoginLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "agents" */ './../pages/AgentLogin'),
  loading: () => <Loader />
});
export const AgentDashboardLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "agents" */ './../pages/agent/agent_dashboard'),
  loading: () => <Loader />
});

//PDG flow
export const SearchModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "pdg" */ './../pages/landing/modals/searchModal'),
  loading: () => <Loader />
});

export const MalSezHotelsLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "pdg" */ './../pages/pdg/mlesezLanding'),
  loading: () => <Loader />
});

export const PDGDurationSelectionLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "pdg" */ './../pages/pdg/PDGDurationSelection'),
  loading: () => <Loader />
});
export const PDGMonthSelectionLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "pdg" */ './../pages/pdg/PDGMonthSelection'),
  loading: () => <Loader />
});
export const PDGInterestSelectionLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "pdg" */ './../pages/pdg/PDGInterestSelection'),
  loading: () => <Loader />
});
export const PDGCitySelectionLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "pdg" */ './../pages/pdg/PDGCitySelection'),
  loading: () => <Loader />
});

// Itinerary Page
export const ItineraryPageWrapperLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary" */ './../pages/itinerary/Itinerary'),
  loading: () => <Loader />
});
export const EditTripLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary" */ './../pages/itinerary/edit_trip'),
  loading: () => <Loader />
});
export const MultiModeTransferModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary" */ './../pages/itinerary/multi_mode_transfer_modal'),
  loading: () => <Loader />
});

// Costing page
export const CostingScreenLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/costing_screen'),
  loading: () => <Loader />
});
export const FlightDetailsModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/flight_details_modal'),
  loading: () => <Loader />
});
export const AlternateFlightsModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/alternate_flights_modal'),
  loading: () => <Loader />
});
export const ChangeVisaModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/change_visa_modal'),
  loading: () => <Loader />
});
export const ChangeItineraryInsuranceLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/change_itinerary_insurance'),
  loading: () => <Loader />
});
export const TrainDetailsModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/train_details_modal'),
  loading: () => <Loader />
});
export const AlternateTrainsModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/alternate_trains_modal'),
  loading: () => <Loader />
});
export const AlternateBusesModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/alternate_buses_modal'),
  loading: () => <Loader />
});
export const AlternateFerriesModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "inclusions" */ './../pages/itinerary/alternate_ferries_modal'),
  loading: () => <Loader />
});

// Common modals for both itinerary and costing/inclusions screen
export const GetCostModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/get_cost_modal'),
  loading: () => <Loader />
});
export const RequestCallbackModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/request_callback_wrapper'),
  loading: () => <Loader />
});

export const HotelDetailsModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/hotel_details_modal'),
  loading: () => <Loader />
});
export const AlternateHotelsModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/alternate_hotels_modal'),
  loading: () => <Loader />
});
export const AlternateHotelRoomsLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/alternate_hotel_rooms_modal'),
  loading: () => <Loader />
});

export const ActivityDetailsModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/activity_details_modal'),
  loading: () => <Loader />
});
export const AlternateActivitiesModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/alternate_activities_modal'),
  loading: () => <Loader />
});

export const RCDetailsModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/rental_car_details_modal'),
  loading: () => <Loader />
});
export const ChangeRentalCarInsuranceLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/change_rental_car_insurance'),
  loading: () => <Loader />
});
export const AlternateRentalCarsLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/alternate_rental_cars_modal'),
  loading: () => <Loader />
});

export const RateMatchModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/rateMatchModal'),
  loading: () => <Loader />
});
export const EmailQuoteModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/emailQuoteModal'),
  loading: () => <Loader />
});
export const ShareItineraryModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../pages/itinerary/shareItineraryModal'),
  loading: () => <Loader />
});

// Delay screen
export const CostingDelayScreenLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "itinerary-inclusions-modal" */ './../common_components/CostingDelayLoading'),
  loading: () => <Loader />
});

// Booking Review screen
export const BookingPassengersLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/BookingPassengers'),
  loading: () => <Loader />
});
export const SurnameModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/components/surnameModal'),
  loading: () => <Loader />
});

// Booking Review screen
export const BookingReviewLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/booking_review'),
  loading: () => <Loader />
});
export const FlightInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/flight_info_modal'),
  loading: () => <Loader />
});
export const HotelInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/hotel_info_modal'),
  loading: () => <Loader />
});
export const ActivityInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/activity_info_modal'),
  loading: () => <Loader />
});
export const VisaInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/visa_info_modal'),
  loading: () => <Loader />
});
export const InsuranceInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/insurance_info_modal'),
  loading: () => <Loader />
});
export const TransferInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/transfer_info_modal'),
  loading: () => <Loader />
});
export const PassInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/pass_info_modal'),
  loading: () => <Loader />
});
export const TrainInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/trainInfo_modal'),
  loading: () => <Loader />
});
export const FerryInfoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/ferry_info_modal'),
  loading: () => <Loader />
});
export const ApplyPromoModalLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "booking-screens" */ './../pages/booking/booking_review/modals/apply_promo_modal'),
  loading: () => <Loader />
});

// Payment pages
export const MakePaymentLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "payment" */ '../pages/MakePayment'),
  loading: () => <Loader />
});
export const PaymentSuccessLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "payment" */ './../pages/payment/PaymentSuccess'),
  loading: () => <Loader />
});

export const PaymentProcessingLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "payment" */ './../pages/payment/PaymentProcessing'),
  loading: () => <Loader />
});

export const PaymentFailureLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "payment" */ './../pages/payment/PaymentFailure'),
  loading: () => <Loader />
});

// Itinerary PDF v1
export const ItineraryPDFv1Loadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "pdf" */ './../pages/pdfv1/Itinerary_pdfv1'),
  loading: () => <Loader />
});

// Itinerary PDF
export const ItineraryPDFLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "pdf" */ './../pages/pdf/Itinerary_pdf'),
  loading: () => <Loader />
});

// Magic Itinerary
export const MagicItineraryLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "magic-itinerary" */ './../pages/itinerary/MagicItinerary'),
  loading: () => <Loader />
});

// Assign user sample itinerary
export const AssignUserLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "magic-itinerary" */ './../pages/itinerary/AssignUser'),
  loading: () => <Loader />
});

// Cred loyality
export const CredLoyalityLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "cred-itinerary" */ './../pages/CredLoyality'),
  loading: () => <Loader />
});

// Cred loyality
export const CredLoyalityTCLoadable = Loadable({
  loader: () =>
    import(/* webpackChunkName: "cred-itinerary" */ './../pages/CredLoyality/TermsAndConditions'),
  loading: () => <Loader />
});
