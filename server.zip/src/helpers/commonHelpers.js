import React from 'react';
import _ from 'lodash';

export function renderList(array, Component) {
  return array.map((a, i) => {
    return <Component {...a} key={i} />;
  });
}

export function getStringFromArray(array, separator, lastSeparator = ' & ') {
  let str = '';
  array.map((element, i) => {
    if (i === 0) {
      str = `${element}`;
    } else if (i === array.length - 1) {
      str = `${str}${lastSeparator}${element}`;
    } else {
      str = `${str}${separator}${element}`;
    }

    return null;
  });
  return str;
}

export function adultsChildrenString(adultsCount, childCount) {
  let text = ``;
  if (adultsCount > 0) {
    if (adultsCount === 1) {
      text = `${adultsCount} adult`;
    } else {
      text = `${adultsCount} adults`;
    }
  }
  if (childCount > 0) {
    if (childCount === 1) {
      text = text + `, ${childCount} child`;
    } else {
      text = text + `, ${childCount} children`;
    }
  }
  return text;
}

export function redirector(url, target) {
  window.open(url, target);
}

export function getWeatherIcon(iconName) {
  switch (iconName) {
    case 'clear-day':
      return 'wi-day-sunny';
    case 'partly-cloudy-night':
      return 'wi-night-alt-cloudy';
    case 'partly-cloudy-day':
      return 'wi-day-cloudy';
    case 'clear-night':
      return 'wi-night-clear';
    case 'rain':
      return 'wi-rain';
    case 'snow':
      return 'wi-snow';
    case 'sleet':
      return 'wi-sleet';
    case 'wind':
      return 'wi-cloudy-windy';
    case 'fog':
      return 'wi-fog';
    case 'cloudy':
      return 'wi-night-alt-cloudy';
    // case 'cloudy':
    //   return 'wi-day-cloudy';
    case 'hail':
      return 'wi-day-hail';
    case 'thunderstorm':
      return 'wi-day-thunderstorm';
    case 'tornado':
      return 'wi-tornado';
    default:
  }
}

export function getKeyValuefromUrlString(url, key) {
  let strings = url.split('?');
  let keyValuePair = strings[strings.length - 1];
  let searchVals = keyValuePair.split('=');
  if (searchVals[0] === key) {
    return searchVals[1];
  } else {
    return null;
  }
}

export function arrayToLi(matchingInterests) {
  let forDisplay = matchingInterests.slice(0, 3);
  let restultHtml = forDisplay.map((interest, i) => {
    return <li key={`interest-li-${i}`}>{_.startCase(_.toLower(interest))}</li>;
  });
  {
    /*
  if (matchingInterests.length > 3) {
    restultHtml.push(
      <li key={`interest-li-last`}>+{matchingInterests.length - 3}</li>
    );
  }*/
  }
  return restultHtml;
}

export function getImage(fileName, scenerio, pixelDensity) {
  let cdnBaseUrl = 'https://d3lf10b5gahyby.cloudfront.net/';
  if (pixelDensity !== undefined && pixelDensity > 1) {
    //RETINA
    switch (scenerio) {
      case 'CITY_SELECTION':
        return `${cdnBaseUrl}city/640x640/${fileName}`;
      case 'CITY_SEARCH_SUGGESTION':
        return `${cdnBaseUrl}city/180x180/${fileName}`;
      case 'ITINERARY_CITY_HEADER':
      case 'ITINERARY_CITY_HEADER_OVERVIEW':
        return `${cdnBaseUrl}city/960xh/${fileName}`;
      case 'ADD_CITY_MODAL':
        return `${cdnBaseUrl}city/180x180/${fileName}`;
      case 'OVERVIEW':
        return `${cdnBaseUrl}city/1200xh/${fileName}`;
      default:
        break;
    }
  } else {
    switch (
      scenerio //DESKTOP
    ) {
      case 'CITY_SELECTION':
        return `${cdnBaseUrl}city/320x320/${fileName}`;
      case 'CITY_SEARCH_SUGGESTION':
        return `${cdnBaseUrl}city/90x90/${fileName}`;
      case 'ITINERARY_CITY_HEADER':
      case 'ITINERARY_CITY_HEADER_OVERVIEW':
        return `${cdnBaseUrl}city/960xh/${fileName}`;
      case 'ADD_CITY_MODAL':
        return `${cdnBaseUrl}city/180x180/${fileName}`;
      case 'OVERVIEW':
        return `${cdnBaseUrl}city/1200xh/${fileName}`;
      default:
        break;
    }
  }
}

export function getPersonalizationMeterClass(noOfPersonalizations) {
  if (noOfPersonalizations >= 0 && noOfPersonalizations <= 20) {
    return 'meter_ico_1';
  } else if (noOfPersonalizations > 20 && noOfPersonalizations <= 40) {
    return 'meter_ico_2';
  } else if (noOfPersonalizations > 40 && noOfPersonalizations <= 60) {
    return 'meter_ico_3';
  } else {
    return 'meter_ico_4';
  }
}
