const timeoutDuration = 60000;

const networkRequest = (apiUrl, method = 'GET', body = false) => {
  const headers = new Headers({
    'Content-Type': 'application/json'
  });

  const requestDetails = {
    method,
    headers,
    mode: 'cors',
    credentials: 'include'
  };

  if (method !== 'GET' && !body) throw Error('Missing Request Body');

  if (method !== 'GET') requestDetails.body = JSON.stringify(body);

  function handleErrors(response) {
    if (response.ok) {
      return response.json();
    } else {
      throw Error(response.statusText);
    }
  }

  const request = new Promise((resolve, reject) => {
    fetch(apiUrl, requestDetails)
      .then(handleErrors)
      .then(resolve)
      .catch(reject);
  });

  const timeout = new Promise((request, reject) => {
    setTimeout(reject, timeoutDuration, `Request timed out!`);
  });

  return new Promise((resolve, reject) => {
    Promise.race([request, timeout])
      .then(resolve)
      .catch(reject);
  });
};

export default networkRequest;
