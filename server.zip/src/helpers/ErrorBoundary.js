import React from 'react';
import ErrorPage from '../pages/ErrorPage';
import logClientError from './logClientError';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);

    this.state = { hasError: false };
  }

  componentDidCatch(error, info) {
    // Display fallback UI
    this.setState({ hasError: true });

    // console.log('error: ', error);
    // console.log('error info: ', info);

    // You can also log the error to an error reporting service
    // logErrorToMyService(error, info);
    logClientError(error, info);
  }

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return <ErrorPage status={500} />;
    }
    return this.props.children;
  }
}
