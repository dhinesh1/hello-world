import { checkIndexOf, getPackageKeyFromPathname } from './utilsHelper';

/**
 * List of constants used to form Itinerary and costing paths
 */
const ITINERARY_VIEW = 'view';
const INCLUSIONS_VIEW = 'inclusions';
const GET_COST = 'get-cost';
const UPDATE_COST = 'update-cost';
const EDIT_TRIP = 'edit-trip';
const LOGIN = 'login';
const SIGNUP = 'signup';
const SHARE_ITINERARY = 'share-itinerary';
const CBR = 'request-callback';
const HOTEL_DETAILS = 'hotel-details';
const HOTEL_ALTERNATES = 'alternate-hotels';
const HOTEL_ALTERNATES_DETAILS = 'alternate-hotel-details';
const HOTEL_ALTERNATE_ROOMS = 'alternate-hotels/alternate-rooms';
const ACTIVITY_DETAILS = 'activity-details';
const ACTIVITY_ALTERNATES = 'alternate-activities';
const ACTIVITY_ALTERNATES_DETAILS = 'alternate-activities-details';
const FLIGHT_DETAILS = 'flight-details';
const FLIGHT_ALTERNATES = 'alternate-flights';
const TRAIN_DETAILS = 'train-details';
const TRAIN_ALTERNATES = 'alternate-trains';
const BUS_ALTERNATES = 'alternate-buses';
const FERRY_ALTERNATES = 'alternate-ferries';
const RENTAL_CAR_DETAILS = 'rental-car-details';
const RENTAL_CAR_ALTERNATES = 'alternate-rental-cars';
const CHANGE_RENTAL_CAR_INSURANCE = 'change-rc-insurance';
const ALTERNATE_TRANSFER_MODE = 'alternate-travel-mode';
const RATE_MATCH = 'rate-match';
const COSTING_IN_PROGRESS = 'calculating-cost';
const EMAIL_QUOTE = 'email-quote';
const CHANGE_INSURANCE = 'change-insurance';
const CHANGE_VISA = 'change-visa';
const RATE_MATCH_HOTEL_ROOM = 'rate-match/hotel-room';
const RATE_MATCH_ACTIVITY = 'rate-match/activity';
const RATE_MATCH_RENTAL_CAR = 'rate-match/rental-car';
const RATE_MATCH_FLIGHT = 'rate-match/flight';
const RATE_MATCH_TRAIN = 'rate-match/train';
const RATE_MATCH_TOTAL_COST = 'rate-match/total-cost';
const ENABLE_TOTEM = 'enable-totem';

/**
 * PLACEHOLDER CONST
 */
const PH_ITINERARY_ID = ':itineraryId';
const PH_HOTEL_KEY = ':hotelKey';
const PH_HOTEL_CODE = ':hotelCode';
const PH_HOTEL_ROOM_KEY = ':hotelRoomKey';
const PH_ACTIVITY_KEY = ':activityKey';
const PH_ACTIVITY_CODE = ':activityId';
const PH_CALLED_FROM_KEY = ':called_from';
const PH_RC_KEY = ':rcKey';
const PH_FLIGHT_KEY = ':flightKey';
const PH_TRAIN_KEY = ':trainKey';
const PH_TRANSFER_KEY = ':transferKey';
const PH_FERRY_KEY = ':ferryKey';
const PH_TOTEM_ID_KEY = ':dayIdentifier';
const PH_ROOM_TYPE_ID = ':roomTypeId';
const PH_SEARCH_REGION =':searchRegion';
const PH_CUSTOMIZE ='customize';

const ITINERARY_BASE = `/${PH_CUSTOMIZE}/${PH_SEARCH_REGION}/${ITINERARY_VIEW}`;
/**
 * List of Itinerary page routes
 */
// customize/idn/view/ID
const ITINERARY_VIEW_ROUTE = `${ITINERARY_BASE}/${PH_ITINERARY_ID}`;
// customize/idn/view/edit-trip/ID
const EDIT_TRIP_ROUTE = `${ITINERARY_BASE}/${EDIT_TRIP}/${PH_ITINERARY_ID}`;
// customize/idn/view/get-cost/ID
const GET_COST_ROUTE = `${ITINERARY_BASE}/${GET_COST}/${PH_ITINERARY_ID}`;
// customize/idn/view/get-cost/ID
const UPDATE_COST_ROUTE = `${ITINERARY_BASE}/${UPDATE_COST}/${PH_ITINERARY_ID}`;

const ENABLE_TOTEM_ROUTE = `${ITINERARY_BASE}/${ENABLE_TOTEM}/${PH_TOTEM_ID_KEY}/${PH_ITINERARY_ID}`; // customize/idn/view/calculating-cost/ID
const COSTING_IN_PROGRESS_ROUTE = `${ITINERARY_BASE}/${COSTING_IN_PROGRESS}/${PH_ITINERARY_ID}`; // customize/idn/view/calculating-cost/ID
const SHARE_ITINERARY_ROUTE = `${ITINERARY_BASE}/${SHARE_ITINERARY}/${PH_ITINERARY_ID}`; // customize/idn/view/share-itinerary/ID
const LOGIN_ROUTE = `${ITINERARY_BASE}/${LOGIN}/${PH_ITINERARY_ID}`; // customize/idn/view/login/ID
const CBR_ROUTE = `${ITINERARY_BASE}/${CBR}/${PH_ITINERARY_ID}`; // customize/idn/view/request-callback/ID
const SIGNUP_ROUTE = `${ITINERARY_BASE}/${SIGNUP}/${PH_ITINERARY_ID}`; // customize/idn/view/signup/ID
const HOTEL_DETAILS_ROUTE = `${ITINERARY_BASE}/${HOTEL_DETAILS}/${PH_HOTEL_KEY}/${PH_ITINERARY_ID}`;
const HOTEL_ALTERNATES_ROUTE = `${ITINERARY_BASE}/${HOTEL_ALTERNATES}/${PH_HOTEL_KEY}/${PH_ITINERARY_ID}`;
const HOTEL_ALTERNATES_DETAILS_ROUTE = `${ITINERARY_BASE}/${HOTEL_ALTERNATES}/${PH_HOTEL_KEY}/${PH_ITINERARY_ID}/details/${PH_HOTEL_CODE}`;
const HOTEL_ALTERNATE_ROOMS_ROUTE = `${ITINERARY_BASE}/${HOTEL_ALTERNATE_ROOMS}/${PH_HOTEL_KEY}/${PH_HOTEL_ROOM_KEY}/${PH_ITINERARY_ID}`;
const ACTIVITY_DETAILS_ROUTE = `${ITINERARY_BASE}/${ACTIVITY_DETAILS}/${PH_ACTIVITY_KEY}/${PH_ITINERARY_ID}`;
const ACTIVITY_ALTERNATES_ROUTE = `${ITINERARY_BASE}/${ACTIVITY_ALTERNATES}/${PH_ACTIVITY_KEY}/${PH_ITINERARY_ID}`;
const ACTIVITY_ALTERNATES_DETAILS_ROUTE = `${ITINERARY_BASE}/${ACTIVITY_ALTERNATES}/${PH_ACTIVITY_KEY}/${PH_ITINERARY_ID}/details/${PH_ACTIVITY_CODE}`;
const ALTERNATE_TRANSFER_MODE_ROUTE = `${ITINERARY_BASE}/${ALTERNATE_TRANSFER_MODE}/:currentMode/:prevCityKey/:nextCityKey/${PH_ITINERARY_ID}`;
const RATE_MATCH_ACTIVITY_ROUTE = `${ITINERARY_BASE}/${RATE_MATCH_ACTIVITY}/${PH_ACTIVITY_KEY}/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`;
const RATE_MATCH_HOTEL_ROOM_ROUTE = `${ITINERARY_BASE}/${RATE_MATCH_HOTEL_ROOM}/${PH_HOTEL_KEY}/${PH_ROOM_TYPE_ID}/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`;
const RATE_MATCH_TOTAL_ROUTE = `${ITINERARY_BASE}/${RATE_MATCH_TOTAL_COST}/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`;

const INCLUSIONS_BASE = `/${PH_CUSTOMIZE}/${PH_SEARCH_REGION}/${INCLUSIONS_VIEW}`;

// inclusions page routes
const inclusionsRoute = {
  // INCLUSIONS_PAGE: "/customize/:searchRegion/inclusions/:itineraryId",
  INCLUSIONS_PAGE: `${INCLUSIONS_BASE}/${PH_ITINERARY_ID}`,
  // UPDATE_COST: "/customize/:searchRegion/inclusions/update-cost/:itineraryId",
  UPDATE_COST: `${INCLUSIONS_BASE}/${UPDATE_COST}/${PH_ITINERARY_ID}`,
  // EMAIL_QUOTE: "/customize/:searchRegion/inclusions/email-quote/:itineraryId",
  EMAIL_QUOTE: `${INCLUSIONS_BASE}/${EMAIL_QUOTE}/${PH_ITINERARY_ID}`,
  // SHARE_ITINERARY: "/customize/:searchRegion/inclusions/share-itinerary/:itineraryId",
  SHARE_ITINERARY: `${INCLUSIONS_BASE}/${SHARE_ITINERARY}/${PH_ITINERARY_ID}`,
  // LOGIN: "/customize/:searchRegion/inclusions/login/:itineraryId"
  LOGIN: `${INCLUSIONS_BASE}/${LOGIN}/${PH_ITINERARY_ID}`,
  // REQUEST_CALLBACK: "/customize/:searchRegion/inclusions/request-callback/:itineraryId",
  REQUEST_CALLBACK: `${INCLUSIONS_BASE}/${CBR}/${PH_ITINERARY_ID}`,
  // COSTING_DELAY: "/customize/:searchRegion/inclusions/calculating-cost/:itineraryId"
  COSTING_DELAY: `${INCLUSIONS_BASE}/calculating-cost/${PH_ITINERARY_ID}`,
  // FLIGHT_DETAILS: "/customize/:searchRegion/inclusions/flight-details/:flightKey/:itineraryId"
  FLIGHT_DETAILS: `${INCLUSIONS_BASE}/${FLIGHT_DETAILS}/${PH_FLIGHT_KEY}/${PH_ITINERARY_ID}`,
  // ALTERNATE_FLIGHTS: "/customize/:searchRegion/inclusions/alternate-flights/:flightKey/:itineraryId"
  ALTERNATE_FLIGHTS: `${INCLUSIONS_BASE}/${FLIGHT_ALTERNATES}/${PH_FLIGHT_KEY}/${PH_ITINERARY_ID}`,
  // HOTEL_DETAILS: "/customize/:searchRegion/inclusions/hotel-details/:hotelKey/:itineraryId"
  HOTEL_DETAILS: `${INCLUSIONS_BASE}/${HOTEL_DETAILS}/${PH_HOTEL_KEY}/${PH_ITINERARY_ID}`,
  // ALTERNATE_HOTEL: "/customize/:searchRegion/inclusions/alternate-hotels/:hotelKey/:itineraryId"
  ALTERNATE_HOTEL: `${INCLUSIONS_BASE}/${HOTEL_ALTERNATES}/${PH_HOTEL_KEY}/${PH_ITINERARY_ID}`,
  // ALTERNATE_HOTEL_DETAILS: "/customize/:searchRegion/inclusions/alternate-hotel/details/:hotelKey/:hotelCode/:itineraryId"
  ALTERNATE_HOTEL_DETAILS: `${INCLUSIONS_BASE}/${HOTEL_ALTERNATES}/${PH_HOTEL_KEY}/${PH_ITINERARY_ID}/details/${PH_HOTEL_CODE}`,
  // ALTERNATE_ROOM: "/customize/:searchRegion/inclusions/alternate-hotels/alternate-rooms/:hotelKey/:hotelRoomKey/:itineraryId"
  ALTERNATE_ROOM: `${INCLUSIONS_BASE}/${HOTEL_ALTERNATE_ROOMS}/${PH_HOTEL_KEY}/${PH_HOTEL_ROOM_KEY}/${PH_ITINERARY_ID}`,
  // ACTIVITY_DETAILS: "/customize/:searchRegion/inclusions/activity-details/:activityKey/:itineraryId"
  ACTIVITY_DETAILS: `${INCLUSIONS_BASE}/activity-details/${PH_ACTIVITY_KEY}/${PH_ITINERARY_ID}`,
  // ALTERNATE_ACTIVITY: "/customize/:searchRegion/inclusions/alternate-activities/:activityKey/:itineraryId"
  ALTERNATE_ACTIVITY: `${INCLUSIONS_BASE}/alternate-activities/${PH_ACTIVITY_KEY}/${PH_ITINERARY_ID}`,
  // ALTERNATE_ACTIVITY: "/customize/:searchRegion/inclusions/alternate-activities/:activityKey/:itineraryId"
  ALTERNATE_ACTIVITY_DETAILS: `${INCLUSIONS_BASE}/alternate-activities/${PH_ACTIVITY_KEY}/${PH_ITINERARY_ID}/details/${PH_ACTIVITY_CODE}`,
  // CHANGE_INSURANCE: "/customize/:searchRegion/inclusions/change-insurance/:itineraryId"
  CHANGE_INSURANCE: `${INCLUSIONS_BASE}/${CHANGE_INSURANCE}/${PH_ITINERARY_ID}`,
  // CHANGE_VISA: "/customize/:searchRegion/inclusions/change-visa/:visaKey/:itineraryId"
  CHANGE_VISA: `${INCLUSIONS_BASE}/${CHANGE_VISA}/:visaKey/${PH_ITINERARY_ID}`,
  // TRAIN_DETAILS: "/customize/:searchRegion/inclusions/train-details/:trainKey/:itineraryId"
  TRAIN_DETAILS: `${INCLUSIONS_BASE}/${TRAIN_DETAILS}/${PH_TRAIN_KEY}/${PH_ITINERARY_ID}`,
  // TRAIN_ALTERNATE: "/customize/:searchRegion/inclusions/alternate-trains/:trainKey/:itineraryId"
  TRAIN_ALTERNATE: `${INCLUSIONS_BASE}/${TRAIN_ALTERNATES}/${PH_TRAIN_KEY}/${PH_ITINERARY_ID}`,
  // RATE_MATCH_ACTIVITY: "/customize/:searchRegion/inclusions/rate-match/activity/:activityKey/:called_from/:itineraryId"
  RATE_MATCH_ACTIVITY: `${INCLUSIONS_BASE}/${RATE_MATCH_ACTIVITY}/${PH_ACTIVITY_KEY}/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`,
  // RATE_MATCH_FLIGHT: "/customize/:searchRegion/inclusions/rate-match/flight/:flightKey/:called_from/:itineraryId"
  RATE_MATCH_FLIGHT: `${INCLUSIONS_BASE}/${RATE_MATCH_FLIGHT}/${PH_FLIGHT_KEY}/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`,
  // RATE_MATCH_RENTAL_CAR: "/customize/:searchRegion/inclusions/rate-match/rental-car/:rcKey/:called_from/:itineraryId"
  RATE_MATCH_RENTAL_CAR: `${INCLUSIONS_BASE}/${RATE_MATCH_RENTAL_CAR}/:rentalCarKey/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`,
  // RATE_MATCH_TRAIN: "/customize/:searchRegion/inclusions/rate-match/train/:trainKey/:called_from/:itineraryId"
  RATE_MATCH_TRAIN: `${INCLUSIONS_BASE}/${RATE_MATCH_TRAIN}/${PH_TRAIN_KEY}/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`,
  // RATE_MATCH_HOTEL_ROOM: "/customize/:searchRegion/inclusions/rate-match/hotel-room/:hotelKey/:roomTypeId/:called_from/:itineraryId"
  RATE_MATCH_HOTEL_ROOM: `${INCLUSIONS_BASE}/${RATE_MATCH_HOTEL_ROOM}/${PH_HOTEL_KEY}/${PH_ROOM_TYPE_ID}/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`,
  // RATE_MATCH_TOTAL_COST: "/customize/:searchRegion/inclusions/rate-match/total-cost/:called_from/:itineraryId"
  RATE_MATCH_TOTAL_COST: `${INCLUSIONS_BASE}/${RATE_MATCH_TOTAL_COST}/${PH_CALLED_FROM_KEY}/${PH_ITINERARY_ID}`,
  // RENTAL_CAR_DETAILS: "/customize/:searchRegion/inclusions/rental-car-details/:rcKey/:itineraryId"
  RENTAL_CAR_DETAILS: `${INCLUSIONS_BASE}/${RENTAL_CAR_DETAILS}/${PH_RC_KEY}/${PH_ITINERARY_ID}`,
  // CHANGE_RENTAL_CAR_INSURANCE: "/customize/:searchRegion/inclusions/change-rc-insurance/:rcKey/:itineraryId"
  CHANGE_RENTAL_CAR_INSURANCE: `${INCLUSIONS_BASE}/${CHANGE_RENTAL_CAR_INSURANCE}/${PH_RC_KEY}/${PH_ITINERARY_ID}`,
  // ALTERNATE_RENTAL_CAR: "/customize/:searchRegion/inclusions/alternate-rental-cars/:rcKey/:itineraryId"
  ALTERNATE_RENTAL_CAR: `${INCLUSIONS_BASE}/${RENTAL_CAR_ALTERNATES}/${PH_RC_KEY}/${PH_ITINERARY_ID}`,
  // BUS_ALTERNATE: "/customize/:searchRegion/inclusions/alternate-buses/:transferKey/:itineraryId"
  BUS_ALTERNATE: `${INCLUSIONS_BASE}/${BUS_ALTERNATES}/${PH_TRANSFER_KEY}/${PH_ITINERARY_ID}`,
  // FERRY_ALTERNATE: "/customize/:searchRegion/inclusions/alternate-buses/:transferKey/:itineraryId"
  FERRY_ALTERNATE: `${INCLUSIONS_BASE}/${FERRY_ALTERNATES}/${PH_FERRY_KEY}/${PH_ITINERARY_ID}`
};

const routingPageType = { inclusion: INCLUSIONS_VIEW, itinerary: ITINERARY_VIEW };

const getGetCostingHelperRoute = ({
  pathname = '',
  itineraryId = '',
  target = 'login'
}) => {
  const isItineraryPage = checkIndexOf(
    pathname,
    ['/view/', '/inclusions/']
  );
  const key = getPackageKeyFromPathname(pathname);

  let loc = '/' + key;
  if (!isItineraryPage) {
    loc = `/${key}/get-cost/${itineraryId}`;
  }

  return loc + '/' + target;
};

const itineraryModalsRouteHelper = ({
  itineraryId = '',
  regionCode = null,
  parentPage = ITINERARY_VIEW,
  target = null,
  location,
  customParams
}) => {
  if (location) {
    parentPage = getPageName(location);
  }
  let loc = `/${PH_CUSTOMIZE}/${regionCode}/${parentPage}`;

  if (target && target !== HOTEL_ALTERNATES_DETAILS && target !== ACTIVITY_ALTERNATES_DETAILS) {
    loc = `${loc}/${target}`;
  }

  switch (target) {
    case ACTIVITY_DETAILS:
    case ACTIVITY_ALTERNATES:
      loc = `${loc}/${customParams.activityKey}`;
      break;
    case ACTIVITY_ALTERNATES_DETAILS:
      loc = `${loc}/${ACTIVITY_ALTERNATES}/${customParams.activityKey}/${itineraryId}/details/${customParams.activityCode}`;
      break;
    case ENABLE_TOTEM:
      loc = `${loc}/${customParams.dayIdentifier}`;
      break;
    case ALTERNATE_TRANSFER_MODE:
      loc = `${loc}/${customParams.transferMode}/${customParams.prevCityKey}/${customParams.cityKey}`;
      break;
    case HOTEL_DETAILS:
    case HOTEL_ALTERNATES:
      loc = `${loc}/${customParams.hotelKey}`;
      break;
    case HOTEL_ALTERNATE_ROOMS:
      loc = `${loc}/${customParams.hotelKey}/${customParams.hotelRoomKey}`;
      break;
    case HOTEL_ALTERNATES_DETAILS:
      loc = `${loc}/${HOTEL_ALTERNATES}/${customParams.hotelKey}/${itineraryId}/details/${customParams.hotelCode}`;
      break;
    case FLIGHT_DETAILS:
    case FLIGHT_ALTERNATES:
      loc = `${loc}/${customParams.flightKey}`;
      break;
    case RENTAL_CAR_DETAILS:
    case RENTAL_CAR_ALTERNATES:
    case CHANGE_RENTAL_CAR_INSURANCE:
      loc = `${loc}/${customParams.rcKey}`;
      break;
    case TRAIN_DETAILS:
    case TRAIN_ALTERNATES:
      loc = `${loc}/${customParams.trainKey}`;
      break;
    case BUS_ALTERNATES:
      loc = `${loc}/${customParams.transferKey}`;
      break;
    case FERRY_ALTERNATES:
      loc = `${loc}/${customParams.ferryKey}`;
      break;
    case CHANGE_VISA:
      loc = `${loc}/${customParams.visaKey}`;
      break;
    case RATE_MATCH_ACTIVITY:
      loc = `${loc}/${customParams.activityKey}/${customParams.called_from}`;
      break;
    case RATE_MATCH_RENTAL_CAR:
      loc = `${loc}/${customParams.rcKey}/${customParams.called_from}`;
      break;
    case RATE_MATCH_HOTEL_ROOM:
      loc = `${loc}/${customParams.hotelKey}/${customParams.roomTypeId}/${
        customParams.called_from
      }`;
      break;
    case RATE_MATCH_FLIGHT:
      loc = `${loc}/${customParams.flightKey}/${customParams.called_from}`;
      break;
    case RATE_MATCH_TRAIN:
      loc = `${loc}/${customParams.trainKey}/${customParams.called_from}`;
      break;
    case RATE_MATCH_TOTAL_COST:
      loc = `${loc}/${customParams.called_from}`;
      break;
    case UPDATE_COST:
    case GET_COST:
    case LOGIN:
    case EMAIL_QUOTE:
    case SHARE_ITINERARY:
    case CHANGE_INSURANCE:
    case CBR:
    default:
      loc = `${loc}`;
  }

  if(target !== HOTEL_ALTERNATES_DETAILS && target !== ACTIVITY_ALTERNATES_DETAILS)
    return loc + '/' + itineraryId;
  else
    return loc;
};

const getPageName = location => {
  if (location.pathname.indexOf(INCLUSIONS_VIEW) > -1) {
    return INCLUSIONS_VIEW;
  }
  return ITINERARY_VIEW;
};

const ITINERARY_ROUTES = {
  ITINERARY_VIEW_ROUTE,
  EDIT_TRIP_ROUTE,
  GET_COST_ROUTE,
  UPDATE_COST_ROUTE,
  COSTING_IN_PROGRESS_ROUTE,
  SHARE_ITINERARY_ROUTE,
  LOGIN_ROUTE,
  CBR_ROUTE,
  SIGNUP_ROUTE,
  HOTEL_DETAILS_ROUTE,
  HOTEL_ALTERNATES_ROUTE,
  HOTEL_ALTERNATES_DETAILS_ROUTE,
  HOTEL_ALTERNATE_ROOMS_ROUTE,
  ACTIVITY_DETAILS_ROUTE,
  ACTIVITY_ALTERNATES_ROUTE,
  ACTIVITY_ALTERNATES_DETAILS_ROUTE,
  ALTERNATE_TRANSFER_MODE_ROUTE,
  RATE_MATCH_ACTIVITY_ROUTE,
  RATE_MATCH_HOTEL_ROOM_ROUTE,
  RATE_MATCH_TOTAL_ROUTE,
  ENABLE_TOTEM_ROUTE
};

export {
  PH_ITINERARY_ID,
  ITINERARY_VIEW,
  INCLUSIONS_VIEW,
  GET_COST,
  UPDATE_COST,
  EDIT_TRIP,
  LOGIN,
  SIGNUP,
  SHARE_ITINERARY,
  CBR,
  ENABLE_TOTEM,
  HOTEL_DETAILS,
  HOTEL_ALTERNATES,
  HOTEL_ALTERNATE_ROOMS,
  HOTEL_ALTERNATES_DETAILS,
  ACTIVITY_DETAILS,
  ACTIVITY_ALTERNATES,
  ALTERNATE_TRANSFER_MODE,
  ACTIVITY_ALTERNATES_DETAILS,
  FLIGHT_DETAILS,
  FLIGHT_ALTERNATES,
  TRAIN_DETAILS,
  TRAIN_ALTERNATES,
  BUS_ALTERNATES,
  FERRY_ALTERNATES,
  RENTAL_CAR_DETAILS,
  RENTAL_CAR_ALTERNATES,
  CHANGE_RENTAL_CAR_INSURANCE,
  RATE_MATCH,
  EMAIL_QUOTE,
  CHANGE_INSURANCE,
  CHANGE_VISA,
  RATE_MATCH_HOTEL_ROOM,
  RATE_MATCH_ACTIVITY,
  RATE_MATCH_RENTAL_CAR,
  RATE_MATCH_FLIGHT,
  RATE_MATCH_TRAIN,
  RATE_MATCH_TOTAL_COST,
  COSTING_IN_PROGRESS,
  getGetCostingHelperRoute,
  itineraryModalsRouteHelper,
  ITINERARY_ROUTES,
  inclusionsRoute,
  routingPageType
};
