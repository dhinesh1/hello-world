import moment from 'moment';

export const GetDatesBetween = function( fromDate = moment(), toDate, format = 'MM-DD-YYYY' ) {
    let $scope = {};
    $scope.dateArr = []; //Array where rest of the dates will be stored
    $scope.prevDate = moment(fromDate,format);//15 days back date from today(This is the from date)
    $scope.nextDate = moment(toDate,format);//Date after 15 days from today (This is the end date)

    //extracting date from objects in MM-DD-YYYY format
    $scope.prevDate = moment($scope.prevDate._d).format('MM-DD-YYYY');
    $scope.nextDate = moment($scope.nextDate._d).format('MM-DD-YYYY');

    //creating JS date objects
    var start = new Date($scope.prevDate);
    var end = new Date($scope.nextDate);

    //Logic for getting rest of the dates between two dates("FromDate" to "EndDate")
    while(start <= end){
      $scope.dateArr.push(moment(start));
      
      var newDate = start.setDate(start.getDate() + 1);
      start = new Date(newDate);  
    }

    // console.log('Dates:- ');
    // console.log($scope.dateArr);
    return $scope.dateArr;
}