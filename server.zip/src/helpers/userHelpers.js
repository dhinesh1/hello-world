export function getGroupTypeTextByTripType(type) {
  if (type === 'Solo' || type === 'Unknown') {
    return ``;
  }

  if (type === 'Honeymoon') {
    return `for ${type}`;
  } else if (type === 'Couple') {
    return `as a ${type}`;
  } else {
    return `with ${type}`;
  }
}
