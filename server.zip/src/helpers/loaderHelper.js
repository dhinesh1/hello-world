import React from 'react';

export function CircleLoader() {
  return <div className="loading-rounded color-primary lg" />;
}

export function LoadingBars() {
  return (
    <div className="center-block text-center loading-bars">
      <span className="bar1" />
      <span className="bar2" />
      <span className="bar3" />
      <span className="bar4" />
    </div>
  );
}
