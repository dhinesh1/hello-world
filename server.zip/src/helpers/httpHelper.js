import axios from 'axios/index';
axios.defaults.withCredentials = true;

export function triggerSimpleAjax(
  url,
  type = 'POST',
  req_data,
  onSuccess,
  onFailure
) {
  let headers = {
    'Content-Type': 'application/json'
    // 'Content-Type': 'text/plain'
  };

  // console.log('********************************** API Starts here **********************************');
  // console.time('API' + url);
  // console.log('URL: ', url);
  // console.log('Req Object: ', req_data);

  if (type !== 'GET') {
    const axiosMethod = type.toLowerCase();
    axios[axiosMethod](url, req_data)
      .then(function (response) {
        onSuccess(response.data);
      })
      .catch(error => {
        onFailure && onFailure(error);
      });
  } else {
    axios
      .get(url, {
        headers: headers,
        data: { a: 'b' }
      })
      .then(function(response) {
        // console.timeEnd('API' + url);
        // console.log('********************************** API Ends here - GET - success **********************************');

        onSuccess(response.data);
      })
      .catch(function(error) {
        // console.log(error);
        // console.timeEnd('API' + url);
        // console.log('********************************** API Ends here - GET - success **********************************');

        if (typeof onFailure === 'function') onFailure(error);
      });
  }
}
