export function getColorClassByGroupType(type) {
  let gt = type === 'Honeymoon' ? `Couple` : type;

  switch (gt) {
    case 'Family':
      return 'yellow';
    case 'Couple':
      return 'green';
    case 'Friends':
      return 'red';
    case 'Solo':
      return 'red';
    default:
      return 'yellow';
  }
}
