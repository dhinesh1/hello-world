import { AppConfig } from '../app-config';

const { images_cdn_misc_url } = AppConfig;

export const teamInfo = [
  {
    name: 'Abhilash',
    aka: 'Data Digger',

    thumb: `${images_cdn_misc_url}employee-photos/childhood/abilash.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/abilash.jpg`,
    active: true,
    desc: `Our business analyst Abilash loves playing around with numbers and data. Singing and dancing to the groove excites him.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Switzerland</h4>To relax by Switzerland's bucolic countryside, ancient castles, clear turquoise lakes and breathtaking mountain peaks`
  },
  {
    name: 'Agni',
    aka: 'Keep Calm and Sell',
    thumb: 'https://dig82prjykzgf.cloudfront.net/agni-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/agni-new.jpg',
    active: true,
    desc:
      "A conversation with Agni is bound to get you packing your bags. He loves travel as much as creating itineraries. His bucket list is a long one, with S.E Asia being ticked off already.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Argentina</h4>Hike the mountains of El Calafate and explore the Perrito Moreno glacier. Laze around the Mendoza vineyards. In that specific order."
  },
  {
    name: 'Aishwarya',
    aka: 'Data Jaan',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/aishwarya.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/aishwarya.jpg`,
    active: true,
    desc: `Food, Comedy and Friendships can easily make her happy. Singer with Passion- Staunch interest in Fashion. Also, she follows Kenny Sebastian's life more than he himself will ever be able to.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Berlin</h4>From longboarding to trying out Brammibal's Donuts from her ultimate foodie bucket list- Berlin's been her dream destination.`
  },
  {
    name: 'Ajit',
    aka: 'Customer’s Santa',
    thumb: 'https://dig82prjykzgf.cloudfront.net/ajit-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/ajit-new.jpg',
    active: true,
    desc:
      "When he’s not listening to happy customer stories, Ajit turns to his geek-avatar - source codes and tech work! Oh and we didn’t know till now, he loves street food. His pet phrase - Respect Bro!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Sweden</h4>Catch the Northern lights at Abisko National Park. Stay at the ice-hotel at Kiruna. Gorge on crispy waffles with cloudberries."
  },
  {
    name: 'Akbar',
    aka: 'Super Coder',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/akbar.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/akbar.jpg`,
    active: true,
    desc: `A friendly chap, high on enthusiasm - like always. Thanks to his dancing skills - we have a master to follow during cultural events. A FDFS movie addict and is always on the look for something innovative.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: London</h4>London has been Akbar's go-to place since his childhood days- especially a click in front of the Big Ben. `
  },
  {
    name: 'Akshaya',
    aka: 'Content Coiner',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/akshaya.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/akshaya.jpg`,
    active: true,
    desc: `Mostly welcomed with " What? you follow football" banters, Akshaya is our coiner of words. With utmost addiction to football and IPL - don't be surprised if she's in depression when CSK or Liverpool lose a match or two. <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Iceland</h4>Gawking at the Northern Lights whilst singing Owl City's Vanilla Twilight, is her version of a paradise.`
  },
  {
    name: 'Amitabh',
    aka: 'Sales Bhachan',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/amitabh.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/amitabh.jpg`,
    active: true,
    desc: `A big time foodie who loves exploring different flavours and cuisines. Wired to the phone almost always, and hit him up if you are looking for Island destinations!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Norway</h4>Chasing Northern Lights and unicorns in Norway!`
  },
  {
    name: 'Anand',
    aka: 'Pixel Pusher',
    thumb: 'https://dig82prjykzgf.cloudfront.net/anandnair-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/anandnair-new.jpg',
    active: true,
    desc:
      "This guy hasn't given up his love for white space and black dots even after growing up. Loves long drives, frugal vacations and until recently- junk food.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Barcelona</h4>Marvel two of world's most beautiful things: Gaudi's architecture and Messi's Camp Nou."
  },
  {
    name: 'Aparna',
    aka: 'Coding Enthusiast',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/aparna.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/aparna.jpg`,
    active: true,
    desc: `Passionate about coding and cooking. Super hyperactive and talkative, and she's got the flair to sing. Loves to party and to embark on long rides<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Tahiti</h4>Tripping all the islands. - specifically Bora Bora in French Polynesia`
  },
  {
    name: 'Aravinth',
    aka: 'Backend Baba',
    thumb: 'https://dig82prjykzgf.cloudfront.net/aravinth-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/aravinth-new.jpg',
    active: true,
    desc:
      "Earphones on, sometimes even shades, Baba balances his Mac, codes and music skillfully. He loves the mountains and his next trip is to Ladakh on his trusted Royal Enfield.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Czech Republic</h4>While most people can’t pronounce it, the Renaissance town of Cesky Krumlov is on Baba’s bucket list. After taking in the panoramic views here, head to the thermal spring town Karlovy Vary."
  },
  {
    name: 'Arishya Banu',
    aka: 'Head of Happiness',
    thumb: `${images_cdn_misc_url}arishya-child.jpeg`,
    largeImage: `${images_cdn_misc_url}arishya.jpg`,
    active: true,
    desc:
      "A self-proclaimed 'cutie',  she loves lames jokes as much as people. Perhaps a bit more. Definitely explains her extremely patient demeanour. Goes gaga over fashion, shopping, and - wait, did we mention lame jokes?<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Norway</h4>Will swoon over glacial lakes, alpine villages, and towering snow-capped mountains. All about the scenery, she wants to free fall from Kjerag cliff."
  },
  {
    name: 'Arvind Ganesh',
    aka: 'Harmony Believer',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/arvind.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/arvind.jpg`,
    active: true,
    desc: `Arvind aka AG is our enthusiast from Customer Happiness team. Playing football and binge watching serials is how AG rolls. With Neo Noir thriller films being his favourite, you are bound to have interesting coffee breaks with him!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Liverpool</h4>Singing the ' You'll Never Walk Alone' song whilst standing in the KOP end`
  },
  {
    name: 'Ashraf',
    aka: 'Subtle Operator',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/ashraf.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/ashraf.jpg`,
    active: true,
    desc: `Ashraf calls himself an ambivert but we can assure you, the minute you see him he'll flash his adorable smile! Loves road tripping and long drives.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: New Zealand</h4>From Wellington to Lake Wanaka, Ashraf wants to leave no stone un-turned in NZ`
  },
  {
    name: 'Balaji Palanisamy',
    aka: 'Code Addict',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/balaji.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/balaji.jpg`,
    active: true,
    desc: `A huge fan of anime with Naruto, Dragonball, One piece being his favs. Master of carrom during his free time and coder by the day!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Tokya</h4>Get the best of Tokya before the age of 30! `
  },
  {
    name: 'Basith',
    aka: 'Pixel Nino',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/basith.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/basith.jpg`,
    active: true,
    desc: `An ardent Atletico Madrid lover and will trade souls for Biriyani and photography. Your go-to guy for designs!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Madrid</h4>To feel the buzzing atmosphere created by the fans inside Estadio Metropolitano.`
  },
  {
    name: 'Bhumika',
    aka: 'Lady Boss',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/bhumika.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/bhumika.jpg`,
    active: true,
    desc: `An integral member of the no-drama league. When she's not gulping mugs of coffee, you can find her dreaming about travelling, particularly the country hopping kind<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Switzerland</h4>"The pastures, glaciers and Alpine villages of Switzerland call out to me". Trailing along the hikes of Grindelwald, Lauterbrunnen and Zermatt whenever Chennai gets too hot to handle is what she desires the most!`
  },
  {
    name: 'Chandru',
    aka: 'Perfect Planner',
    thumb: 'https://dig82prjykzgf.cloudfront.net/chandru-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/chandru-new.jpg',
    active: true,
    desc:
      "Meet our reliable in-house destination geek. Up close he’s a man of many interests. Music for one, catch him humming under his breath often!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: South Africa</h4>Bush walk in Kruger National Park and catch a match at the Wanderers Stadium."
  },
  {
    name: 'Dani Akash',
    aka: 'Javascript Jedi',
    thumb: `${images_cdn_misc_url}dani-child.jpg`,
    largeImage: `${images_cdn_misc_url}dani.jpg`,
    active: true,
    desc:
      "Coding for mobiles and servers is love and life. Fights sleep with 10 hours of Manga reading. Sleep is truly for the weak, it appears.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Tokyo</h4>Enraptured by the ultra-modern skyscrapers and the ravishing Imperial Palace (these buildings we tell you!), he has loved from afar too long. Sightsee by the day, ramen and yakisoba pan by the night."
  },
  {
    name: 'Deepak',
    aka: 'Wordsworth',
    thumb: `${images_cdn_misc_url}deepak-childnew.JPG`,
    largeImage: `${images_cdn_misc_url}deepak.jpg`,
    active: true,
    desc:
      "Oldsoul, an ardent Batman and F.R.I.E.N.D.S fan, and a Biryani lover. On normal days, you could find him downloading movies to watch during the weekend. Come weekend, you will find him asleep on his bed.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Amalfi Coast</h4>Soak in the stunning scenery of the Amalfi coast, dive into the turquoise waters, and enjoy a hot wood-burnt pizza with a cold beer!"
  },
  {
    name: 'Dinesh',
    aka: 'SEO Singam',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/dinesh.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/dinesh.jpg`,
    active: true,
    desc: `"SPIRIT GUIDE" for spirits in bottles. Claims food is his life-long bae. Has his best interests in Marketing and psychology<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: New Zealand</h4>Tour New-Zealand inside out and finally relax by the Bay of Islands after trying out some adventure activities.`
  },
  {
    name: 'Divya Jain',
    aka: 'SEO DJ',
    thumb: `${images_cdn_misc_url}divya-childnew.jpeg`,
    largeImage: `${images_cdn_misc_url}divya-jain.jpg`,
    active: true,
    desc:
      "Love gaming Google search with new tactics. DJ is a grand goal setter and has set herself some tough ones. On the days you see her break into dance, know that one of those goals are met. She love chocolates, Punjabi food (only veg though), books, shopping, the rest of her list was too long!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Italy</h4>DJ loves to quote Bertrand Russel on her favourite destination. 'Italy, spring and first love all together should suffice to make the gloomiest person happy'"
  },
  {
    name: 'Divyatha',
    aka: 'Diya of Coding',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/divyatha.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/divyatha.jpg`,
    active: true,
    desc: `Curious learner, ambivert by character, constantly pumped up to read on new innovations. A go-getter by attitude and is passionate about doing arts and crafts.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Australia</h4>A view from the Eureka Skydeck during sunset.`
  },
  {
    name: 'Dwaraka',
    aka: 'Blizzard of Sales',
    thumb: 'https://dig82prjykzgf.cloudfront.net/dwaraka-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/dwaraka-new.jpg',
    active: true,
    desc:
      "Biryani is love, Zara (the brand) is lovelier. She’s the busy bee for whom the traveller comes first and lunch comes next.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: New Zealand</h4>A three day road trip from Queenstown to Milford Sound - with pit-stops to awe at the rolling hills of course."
  },
  {
    name: 'Farheen',
    aka: 'Sales Diva',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/farheen.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/farheen.jpg`,
    active: true,
    desc: `Our champ takes her cups of coffee and GOT way too serious! Apart from binge watching series, Farheen also loves to explore vacation savvy places!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Istanbul</h4>To visit the historical monuments, museums and tombs of Istanbul`
  },
  {
    name: 'Giri',
    aka: 'H of Happiness',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/giri.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/giri.jpg`,
    active: true,
    desc: `Empathy is something that comes naturally to Giri and we bet his love for music will beat yours! <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: France</h4>Getting his own village set up along the paddy fields of France and to sing his hearts out!`
  },
  {
    name: 'Gopal',
    aka: 'Data Pundit',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/gopal.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/gopal.jpg`,
    active: true,
    desc: `Gopal aka cyborg is the king of data. Data digging comes with ease for him. Hard worker by the day and hard party star by the night! He just can't keep mum when it comes to bikes!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Paris</h4>Wander the streets of Paris and get an iconic photograph clicked in front of Eiffel tower!`
  },
  {
    name: 'Harish Krishna',
    aka: 'Dynamite Seller',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/harish.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/harish.jpg`,
    active: true,
    desc: `An amateur artist who loves to get high on good food and music.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Northern lights</h4>Sipping a cup of chai under Northern lights`
  },
  {
    name: 'Henna',
    aka: `Customer's delight`,
    thumb: `${images_cdn_misc_url}employee-photos/childhood/henna.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/henna.jpg`,
    active: true,
    desc: `Henna claims almost all the times her head is stuck in the clouds. For those of you wondering why, she has EDM constantly blaring but her heart is filled with nature-love. Psychedelic and soft-spoken define her the best<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Italy</h4>Eating pizza on a rainy day, snuggled up in a warm blanket in Italy- that's Henna's kind of trip`
  },
  {
    name: 'Jaideep',
    aka: 'Enthu Planner',
    thumb: 'https://dig82prjykzgf.cloudfront.net/jai-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/jai-new.jpg',
    active: true,
    desc:
      "Always on the lookout for some adventure and food on his trusty bike.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Switzerland</h4>Catch mind-boggling views on the way cable-car ride to Mount Titlis, maybe yell out to hear an echo. Take the ride atop Schynige Platte to awe at the alpine garden on the top."
  },
  {
    name: 'Jash N Bavishi',
    aka: 'High-spirited Eskimo',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/jashbavishi.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/jashbavishi.jpg`,
    active: true,
    desc: `Jash and good food go hand-in-hand. The walls in the CH and lunch room have more Jash tales to share, believe us!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Europe</h4>A Europe tour to witness the magic of cathedrals, canals and untold history!`
  },
  {
    name: 'Jeyaram',
    aka: 'Money & Muscle',
    thumb: `${images_cdn_misc_url}Jeyaram-child.jpg`,
    largeImage: `${images_cdn_misc_url}jeyaram.jpg`,
    active: true,
    desc:
      "This chocoholic's day begins with pumping iron at the gym to the soundtrack of ARR crooning away. Wants to country hop to all the places with best chocolates.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Switzerland</h4>His chocolate dream brings him here first. And in the downtime, he will pick up skiboards and go trailing down the alps here."
  },
  {
    name: 'Jothi',
    aka: 'Frontend Fighter',
    thumb: 'https://dig82prjykzgf.cloudfront.net/jothi-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/jothi-new.jpg',
    active: true,
    desc:
      "JoSan, as we call him is our UI-UX developer. He has an obvious love for coding and a secret soft spot for photography.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Japan</h4>Take a boat ride through Japan’s famed cherry blossoms, drive down to Lake Ashi and take some frame worthy photographs."
  },
  {
    name: 'Kaushik',
    aka: 'Cool Planner',
    thumb: 'https://dig82prjykzgf.cloudfront.net/kaushik-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/kaushik-new.jpg',
    active: true,
    desc:
      "Our man with a plan and the contacts to get you (almost) anywhere in the world.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Amsterdam</h4>Bike around De Pijp and make pit-stops at bars and street food stalls. And, of course, gorge up on some poffertjes."
  },
  {
    name: 'Komal',
    aka: 'Inter*seller*',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/komal.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/komal.jpg`,
    active: true,
    desc: `She loves the simple things in life. Dogs, music, movies and beaches make her go Eeee. Long walks witnessing the beautiful sunsets with a hot cup of coffee is her idea of chilling<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Thailand</h4>Dipping her toes in the emerald beaches of Koh Samui with some wine and good music`
  },
  {
    name: 'Krishnamoorthy',
    aka: 'Empathy King',
    thumb: 'https://dig82prjykzgf.cloudfront.net/krish-child.png',
    largeImage: `${images_cdn_misc_url}employee-photos/krish.jpg`,
    active: true,
    desc:
      "Meet our in-house DJ. A phone in one hand and fingers on the keyboard, Krish is our go-to when it comes to Bali hotels and flights. When not orchestrating holidays, he unwinds with music.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Spain</h4>Go crazy on a tapas adventure in the streets of  Barcelona and shake it all off while skiing at the Sierra Nevada mountains."
  },
  {
    name: 'Lubna',
    aka: 'The Trainer',
    thumb: 'https://dig82prjykzgf.cloudfront.net/lubna-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/lubna-new.jpg',
    active: true,
    desc:
      "The Hummingbird at work, gets high on A R Rahman numbers and training folks! Has explored the hills of India from Kodai to Kashmir and now longs to explore the world.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Turkey</h4>Soak in the Istanbul Music Festival, fly high in the balloons of Cappadocia and enjoy some Turkish coffee."
  },
  {
    name: 'Mani Shankar',
    aka: 'Artistic Coder',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/mani.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/mani.jpg`,
    active: true,
    desc: `You can't not feel the positive vibes which radiate when Manishankar is around. Learning from experience and having them implemented in his life is what Mani does on an everyday basis.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Bali</h4>To relax by the villas and spas of Bali and to embark on a road-trip from Nusa Dua`
  },
  {
    name: 'Meyyappan',
    aka: 'Smiley Operator',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/meyyappan.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/meyyappan.jpg`,
    active: true,
    desc: `With a good load of passion towards sports, technology, and entertainment, Meyyapan will surprise you with his GK!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Russia</h4>To embark on an epic ride in the Trans siberian railways`
  },
  {
    name: 'Nandakumar',
    aka: 'Strategy Guru',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/nandakumar.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/nandakumar.jpg`,
    active: true,
    desc: `Other than spreadsheets and strategies, the magical word "Biryani" excites Nanda and the ECR beach is his happy place<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Bora Bora</h4>Sipping his favourite wine whilst chilling amidst the sand-fringed islets and turquoise lagoons in Bora Bora`
  },
  {
    name: 'Narayanan',
    aka: 'Mad Over Marketing',
    thumb: `${images_cdn_misc_url}nh-child.jpg`,
    largeImage: `${images_cdn_misc_url}nh.jpg`,
    active: true,
    desc:
      "Say 'hello' to NH. The guy who knows everything about every thing - food, cars, deals, and what not . Pheww! Take notes when he is talking. You might just discover the secret behind the Bermuda Triangle. <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Eastern Europe</h4>Learn the rich history & culture of Czech Republic, trace my way through the picture-perfect coastal towns in Croatia, and be awestruck by the grandeur of Hungary."
  },
  {
    name: 'Narendrakumar',
    aka: 'Test Ninja',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/narendrakumar.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/narendrakumar.jpg`,
    active: true,
    desc: `Ninja is our tester who is almost always busy doing one thing or the other. Photography, MMA take up most of his time and when he's not latched on to that - you can find him playing some of the best melancholic tunes.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Canada</h4>To get the best of Moraine Lake, Alberta in Canada`
  },
  {
    name: 'Naveen',
    aka: 'Team PHP',
    thumb: 'https://dig82prjykzgf.cloudfront.net/naveen-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/naveen-new.jpg',
    active: true,
    desc:
      "With an air of one who knows his job, he makes codes and conversation with the same ease.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Sweden</h4>Live the outdoor man’s life while camping at the Tyresta national park and brushing up campfire cooking skills."
  },
  {
    name: 'Pavan',
    aka: 'Passionate Programmer',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/pavan.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/pavan.jpg`,
    active: true,
    desc: `Big time biker and an AR Rahman addict.  Loves drama and romance and believes a lot in magic, thanks to ' The Boy Who Lived' - Harry Potter :) <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Australia</h4>His dream is to chill out at a secluded island and observe the wildlife while climbing Mawson peak with the active volcano Big Ben`
  },
  {
    name: 'Pradeep',
    aka: 'Team PHP',
    thumb: 'https://dig82prjykzgf.cloudfront.net/pradeep-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/pradeep-new.jpg',
    active: true,
    desc:
      "Loves his space as much as his codes. A man of few words, he is easily recognizable with nose buried in laptop, typing away.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Philippines</h4>Catch sunrise at the White beach in Boracay and an afternoon spent sunbathing with a glass of Halo-Halo in hand."
  },
  {
    name: 'Prashanth',
    aka: 'Excel King',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/prashanth.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/prashanth.jpg`,
    active: true,
    desc: `Sports, food and music - is his way of life. A big fan of the Arsenal football club - Chelsea fans, you need to be weary of him! <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Norway</h4>To drive on the Nurburgring and get some hiking done at Trolltunga in Norway`
  },
  {
    name: 'Raj',
    aka: 'Power Supply',
    thumb: 'https://dig82prjykzgf.cloudfront.net/raj-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/raj-new.jpg',
    active: true,
    desc:
      "Passionate about biryani, fitness and sports, Raj is probably the fittest among us all. Still unbeaten at the many tug-of-wars we’ve had so far at work!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Australia</h4>This outdoorsy guy is going to beat the Aussies at hiking the bushland! Watch out kangaroos, Raj might be faster than you!"
  },
  {
    name: 'Raj Kumar',
    aka: 'Coding Raja',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/rajkumar.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/rajkumar.jpg`,
    active: true,
    desc: `Raj is our super cool guy with a staunch interest in coding and bike riding. A nature lover by heart, Raj plays violin during his free time<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Haarlem</h4>A ride by the canals of Amsterdam and checking out the gorgeous cathedrals and buildings of Haarlem.`
  },
  {
    name: 'Rohitha',
    aka: 'Social Media rockstar',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/rohitha.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/rohitha.jpg`,
    active: true,
    desc: `Basically, our champ Rohitha is drunk with life and claims to be the ' NO 1 MSD fan' on the face of the earth. In everything that she does, she seeks for some kind of adventure. Be it eating Biryani on a hot Chennai day, moving mountains for a cricket match or watching LZ concerts - she's always game for heart-racing events. Proud owner of two doggos and always claims that even a hundred of them would still not be enough.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: United Kingdom</h4>All of the United Kingdom. Scotland for Harry Potter. Countryside for Austen and Blyton. Cities for Dickens and London for Lord's.`
  },
  {
    name: 'Samantha',
    aka: 'Product Super Star',
    thumb: `${images_cdn_misc_url}samantha-childnew.jpg`,
    largeImage: `${images_cdn_misc_url}samantha.jpg`,
    active: true,
    desc:
      "Foodie on the prowl to discover quaint and largely unknown food joints around the city, she whips out the Thalaivar's dialogues with the much ease. Her latest achievement? Solving a 1000 piece puzzle in 2 days. Savvy, we say!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Serengeti, Africa</h4>Ever since she heard she could watch animals migrate, Serengeti sparked the wildest of her imaginations."
  },
  {
    name: 'Sanjay',
    aka: 'Process Pujari',
    thumb: 'https://dig82prjykzgf.cloudfront.net/sanjay-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/sanjay-new.jpg',
    active: true,
    desc:
      "He’s our cricket star and a fitness freak! His first tick off the bucket list? Bungee jumping in Dubai.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: New Zealand</h4>Catch the Southern Lights at Lake Tekapo, soak in the beauty of Milford Sound and probably settle down with the Maoris!"
  },
  {
    name: 'Sannan Hamza',
    aka: 'Happy Enthusiast',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/sannan.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/sannan.jpg`,
    active: true,
    desc: `Doing justice to his team ' Customer Happiness', Sannan's someone who gets hyped when the people around him are filled with energy.  You can find him sleeping on football pitches than his own bed because, this lad loves the game of football more than anything else in this world! <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: New Zealand</h4>Explore the beautiful Kiwi land on road and experience the downfall from a cliff( Nevis swing)`
  },
  {
    name: 'Sasikumar',
    aka: 'Innovation Seeker',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/sasikumar.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/sasikumar.jpg`,
    active: true,
    desc: `You can always find him observing the intricate details of nature around him.  A complete travel freak who loves to go on long rides in his bike.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Maldives</h4>To relax by the island beaches of Maldives`
  },
  {
    name: 'Saurabh',
    aka: 'Mulai full ah Moolah',
    thumb: 'https://dig82prjykzgf.cloudfront.net/saurabh-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/saurabh-new.jpg',
    active: true,
    desc:
      "His lunch boxes are as fascinating as are the itineraries he crafts for our travellers. Saurabh is the Punjabhi who loves Bhangra as much as Bise Bela bath.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Australia</h4>Queenstown for adventure, a ride through the 75 Mile beach and barbeque Aussie style!"
  },
  {
    name: 'Shreoshe',
    aka: 'Quora Queen',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/shreoshe.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/shreoshe.jpg`,
    active: true,
    desc: `Loves cooking and binge-watching movies. Love shopping? Well, she's your buddy then. Ardent animal lover since her childhood, and has 14 cats and 6 dogs at home. A pet hostel for stray dogs has been her all time dream!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Venice</h4>To ride a Vaporetto through the Grand Canal, take an Italian cooking class, learn lace making, shop as much as she can and enjoy the local delicacies`
  },
  {
    name: 'Shukla',
    aka: 'Data Sekar',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/shukla.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/shukla.jpg`,
    active: true,
    desc: `Passionate enough to play or talk about his favourite sports all day long. Hopping on bikes to travel to new places and find new food joints excites him to the fullest!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: South America</h4>Plans to roam the nook and corner of India and South America. `
  },
  {
    name: 'Srini',
    aka: `Operation's Srini Mama`,
    thumb: `${images_cdn_misc_url}employee-photos/childhood/srini.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/srini.jpg`,
    active: true,
    desc: `Srini is super passionate about the Himalayan mountains ranges, adventure sports and Indian movies. His plan is to climb Mt Everest before he turns 26. He's also the fitness freak who lost his heart to the game of badminton!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: New Zealand</h4>To try out the daring adventure activities at New Zealand`
  },
  {
    name: 'Sruthi',
    aka: 'Stalk, Sell, Repeat.',
    thumb: 'https://dig82prjykzgf.cloudfront.net/sruthi-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/sruthi-new.jpg',
    active: true,
    desc:
      "This Diva has an envious collection of earrings and loves a mystery. Bali and Maldives are among her favourite vacation spots.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Peru</h4>The mysterious ruins at Machu Pichu, wander through the beautiful Sacred Valley and take a deep breath of Inca culture."
  },
  {
    name: 'Suhail Mohamed',
    aka: 'Captain Coder',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/suhail-child.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/suhail.jpg`,
    active: true,
    desc: `Suhail is our front-end enthusiast who takes deep interest in problem solving. During his free time, he spends his time exploring wild-life photography. To try out MMA and oh looks like you need to be a bit weary of him. Ha!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Cairo</h4>To check out the iconic pyramids and Great Sphinx at Cairo`
  },
  {
    name: 'Sunil',
    aka: 'Stellar Planner',
    thumb: 'https://dig82prjykzgf.cloudfront.net/sunil-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/sunil-new.jpg',
    active: true,
    desc:
      "Fitness, animals and movies is that order is what this guy loves. When he’s not fixing up our travellers itinerary, he dreams of travelling the world - one destination a year.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: South Africa</h4>Go hiking on a wildlife safari in the forests, hoping to chance upon a wild animal or two."
  },
  {
    name: 'Sureshkumar Vengadassamy',
    aka: 'The Silent Planner',
    thumb: `${images_cdn_misc_url}sureshkumar-childnew.jpg`,
    largeImage: `${images_cdn_misc_url}suresh.jpg`,
    active: true,
    desc:
      "A run-of-the-mill cricket enthusiast who is swayed as much India's 6s as he is by the tunes of maestro ARR. Life goal? Explore the unexplored. Fits our bill perfectly!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: France</h4>Swoons over architecture so Paris is right up his list. Once aboard the Eiffel Tower his day will climax by the Seine for dinner. Aah, the thing of fairytales!"
  },
  {
    name: 'Tanmayee',
    aka: 'Sales Supernova',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/tanmayee.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/tanmayee.jpg`,
    active: true,
    desc: `Tanmayee is our silent slayer of sales. Playing with numbers and getting NZ deals done in a jiffy is what she's amazing at. You can befriend her immediately if you have a spicy lunch and absolutely no side-dish!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Europe</h4>Wander the snow filled lanes of Europe and swallow the beauty the golden lights have to offer during Christmas`
  },
  {
    name: 'Varshaa',
    aka: 'Silent Calculator',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/varshaa.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/varsha.jpg`,
    active: true,
    desc: `Varsha is passionate about anything and everything related to music. Shopping and learning something new every day keeps her spirits high!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Europe</h4>A complete Europe tour - with some intense digging done in Paris and Switzerland`
  },
  {
    name: 'Vatsan',
    aka: 'Persistent Pitcher',
    thumb: 'https://dig82prjykzgf.cloudfront.net/vatsan-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/vatsan-new.jpg',
    active: true,
    desc:
      "Vatsan is our very own football star. He gets his goals right on the football field, just as well as he gets traveller dreams executed.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Croatia</h4>Try Croatian-style pizza while being set to explore Zardar’s many secrets. Stroll by the Sea Organ for an evening rendezvous."
  },
  {
    name: 'Vignesh',
    aka: 'Heavy Planner',
    thumb: 'https://dig82prjykzgf.cloudfront.net/vignesh-child.png',
    largeImage: 'https://dig82prjykzgf.cloudfront.net/vignesh-new.jpg',
    active: true,
    desc:
      "Loves mapping trails and cataloging a destination’s best as much as taking long drives in his car.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Las Vegas</h4>Trying his luck at the casinos and spending nights of late-night parties."
  },
  {
    name: 'Vinoth',
    aka: 'Energetic Warrior',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/vinoth.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/vinoth.jpg`,
    active: true,
    desc: `A self-motivated, and a disciplined soul. Always on the watch, to up his skillset. Self-learning and real-time experiences are what he enjoys the most! <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Iceland</h4>To sit and chill by the Blue lagoons in Iceland.`
  },
  {
    name: 'Yashwanth',
    aka: 'Magical Seller',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/yashwanth.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/yashwanth.jpg`,
    active: true,
    desc: `Potter head, Marvel fanatic - you guessed it, prefers fantasy over reality. Loves out of the world experiences - has already ticked off skydiving. Next on the list - scuba and bungee. If you want a dream vacation to sweep you away from actuality, here's your guy.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: The Himalayas</h4>The Himalayas - The naked beauty of India's own mountain range fascinates him. Would love to do a long trek, meditate on the mountains and be one with nature.`
  },
  {
    name: 'Yuvasri',
    aka: 'SEO Photon',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/yuvasri.jpg`,
    largeImage: `${images_cdn_misc_url}employee-photos/yuvasri.jpg`,
    active: true,
    desc: `An energized parti(y)cle who spends her time finding quirky methods in the game with Google. Keen on learning new things and has the humour level of Charlie Chaplin!  <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Ladakh</h4>Her life time goal is to trek at the Chadar Hills in Ladakh`
  },
  {
    name: 'Ben',
    aka: 'Big Ben',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/`,
    largeImage: `${images_cdn_misc_url}employee-photos/`,
    active: false,
    desc: `Ben's addiction deals with bikes, modified cars and playing football. The wanderlust in him can never be satisfied, paving him the way for varied explorations<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Amsterdam</h4>Chilling by the canals of Amsterdam and listening to street music`
  },
  {
    name: 'Sahal',
    aka: 'Sahalakala vallavan',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/`,
    largeImage: `${images_cdn_misc_url}employee-photos/sahal.jpg`,
    active: false,
    desc: `Football, food and dance define Sahal the best. Crazy about road trips and skateboards on the other hand, Sahal's plan to trip Butan and Leh Ladakh never fails to fascinate us!<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Iceland</h4>Snow, lights and ambience - Iceland is Sahal's way to gooo!`
  },
  {
    name: 'Renu Devi',
    aka: 'Visa Queen',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/`,
    largeImage: `${images_cdn_misc_url}employee-photos/renudevi.jpg`,
    active: false,
    desc: `Believing truly in the concept of YOLO, Renu's dream is to travel, trek and ride around the world.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Iceland</h4>Enjoying the melodramatic setting of Iceland and relaxing by the national parks of Vatnajökull and Snæfellsjökull`
  },
  {
    name: 'Karthick',
    aka: 'Fervid Tester',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/`,
    largeImage: `${images_cdn_misc_url}employee-photos/karthick.jpg`,
    active: false,
    desc: `Loves to be fit and enjoy life as it comes.  Highly passionate about building automation robots which breaks the code and builds the quality.<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: </h4>A short trip to Europe and getting the best of his with his better half. `
  },
  {
    name: 'Senthilkumar',
    aka: 'Enigma of UI',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/`,
    largeImage: `${images_cdn_misc_url}employee-photos/senthilkumar.jpg`,
    active: false,
    desc: `Ardent lover of markups. Passionate in converting designs to UI. Coimbatorian. Proud fan of Kamalhassan<h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: </h4>To leave no stones unturned in United Kingdom. `
  },
  {
    name: 'Srishti',
    aka: 'Sales Chutki',
    thumb: `${images_cdn_misc_url}employee-photos/childhood/`,
    largeImage: `${images_cdn_misc_url}employee-photos/srishti.jpg`,
    active: false,
    desc: `Srishti spends most of her time dancing and playing table tennis. When she's not doing that- you can find her in movie theatres munching on her favourite Caramel Popcorn! <h4 style='margin-top: 25px; padding-bottom: 10px;'>Dream Destination: Paris</h4>What started just as a second language during schooling, the French language left a love dent inside Srishti's heart and now, she cannot wait to get the best of Paris and Nice.`
  }
];
