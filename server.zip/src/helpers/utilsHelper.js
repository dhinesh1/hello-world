import React from 'react';
import _ from 'lodash';
import moment from 'moment';
import { AppConfig } from '../app-config';
import { isValidNumber } from 'libphonenumber-js';
import { parsePhoneNumberFromString as parseMobile } from 'libphonenumber-js/mobile';
const IMGIX_BASE = AppConfig.imgix_base;
const IMGIX_TESTIMONIAL_BASE = AppConfig.imgIX_testimonial_base;
const S3_baseUrl = AppConfig.images_cdn_url_s3;

export const scrollToTop = (st, scrollDuration) => {
  let scrollStep = -window.scrollY / (scrollDuration / 15),
    scrollInterval = setInterval(function() {
      if (window.scrollY >= st) {
        window.scrollBy(0, scrollStep);
      } else clearInterval(scrollInterval);
    }, 15);
};
export const scrollToDown = (st, scrollDuration) => {
  let scrollStep = Math.abs(window.scrollY - st) / (scrollDuration / 15),
    scrollInterval = setInterval(function() {
      if (window.scrollY <= st) {
        window.scrollBy(0, scrollStep);
      } else clearInterval(scrollInterval);
    }, 15);
};

export const  getMealType = mealType => {
  if (mealType) {
    if (mealType.includes('HB')) {
      return 'Breakfast & Dinner';
    } else if (mealType.includes('FB')) {
      return 'Breakfast, Lunch & Dinner';
    } else if (mealType.includes('BB')) {
      return 'Bed & Breakfast';
    } else if (mealType.includes('AI')) {
      return 'Breakfast, Lunch, Dinner & Unlimited Alcohol/Beverages';
    } else {
      return mealType;
    }
  }
};

export const getConnectionDuration = duration => {
  let durHours = Math.floor(duration / 60);
  let durMinutes = duration % 60;

  if (durHours !== 0 && durMinutes !== 0)
    return (
      <span>
        {durHours}h {durMinutes}m
      </span>
    );
  else if (durHours !== 0 && durMinutes === 0) return <span>{durHours}h</span>;
  else if (durHours === 0 && durMinutes !== 0)
    return <span>{durMinutes}m</span>;
};

export const scrollToTopInElement = (ele, st, scrollDuration) => {
  let scrollStep = -ele.scrollY / (scrollDuration / 15),
    scrollInterval = setInterval(function() {
      if (ele.scrollY >= st) {
        ele.scrollBy(0, scrollStep);
      } else clearInterval(scrollInterval);
    }, 15);
};

export const animate = ({ duration, execute, timing, end }) => {
  let start = performance.now();
  requestAnimationFrame(function animate(time) {
    let currentTime = time - start;
    let timeFraction = (time - start) / duration;
    if (timeFraction > 1) timeFraction = 1;
    let progress = timing(currentTime);
    execute(progress);
    if (timeFraction < 1) {
      requestAnimationFrame(animate);
    } else {
      if (end) {
        end();
      }
    }
  });
};

/**
 * This function will use to open the new location with out using link / anchor tag.
 * By default, target is '_blank' based on our requirement will change as well
 * @param {*} href
 * @param {*} target
 */
export function openNewLink(href, target = '_blank') {
  Object.assign(document.createElement('a'), {
    target: target,
    href,
  }).click();
 }

/**
 * validate the mobile number
 * @param {*} mobileNumber
 */
export function isValidMobileNumber(mobileNumber) {
  return isValidNumber(mobileNumber) && parseMobile(mobileNumber).isValid();
}

export function checkIndexOf(
  value = '',
  compareStrings = [],
  initValue = 0,
  isEqual = false,
  isReverse = false
) {
  if (isEqual) {
    return compareStrings.some(compareString => {
      return isReverse
        ? compareString.indexOf(value) === initValue
        : value.indexOf(compareString) === initValue;
    });
  } else {
    return compareStrings.some(compareString => {
      return isReverse
        ? compareString.indexOf(value) > initValue
        : value.indexOf(compareString) > initValue;
    });
  }
}

export function fixPDGHeader() {
  let TitleSection = document.querySelector('.search-input-container');
  let optionsWrapper = document.querySelector('.search-options-wrapper');

  let scroll = Math.max(
    window.pageYOffset,
    document.documentElement.scrollTop,
    document.body.scrollTop
  );

  let tEl = document.querySelector('.search-container');
  if (tEl.classList.contains('landing-search')) {
    scroll = tEl.scrollTop;
  }

  if (TitleSection) {
    if (scroll > 114) {
      TitleSection.classList.add('fix-top');
      optionsWrapper && optionsWrapper.classList.add('fix-top-adjust');
    } else {
      TitleSection.classList.remove('fix-top');
      optionsWrapper && optionsWrapper.classList.remove('fix-top-adjust');
    }
  }
}

export function fixPDGCitiesHeader() {
  let dW = window.innerWidth;
  // let tEl = document.querySelector('.search-container');
  let TitleSection = document.querySelector('.tab-links-container');
  let optionsWrapper = document.querySelector('.search-options-wrapper');
  let scroll = Math.max(
    window.pageYOffset,
    document.documentElement.scrollTop,
    document.body.scrollTop
  );

  if (TitleSection) {
    if (dW > 767) {
      if (scroll > 175) {
        TitleSection.classList.add('fix-top');
        optionsWrapper && optionsWrapper.classList.add('fix-top-adjust-2');
      } else {
        TitleSection.classList.remove('fix-top');
        optionsWrapper && optionsWrapper.classList.remove('fix-top-adjust-2');
      }
    } else {
      if (scroll > 10) {
        TitleSection.classList.add('fix-top');
        optionsWrapper && optionsWrapper.classList.add('fix-top-adjust-2');
      } else {
        TitleSection.classList.remove('fix-top');
        optionsWrapper && optionsWrapper.classList.remove('fix-top-adjust-2');
      }
    }
  }
}
export function getAllItineraryCities(itineraryInfo = {
  itinerary: {}
}) {
  let allCitiesKeys = itineraryInfo.itinerary.allCityKeys;
  let all_cities = [];
  _.forEach(allCitiesKeys, function (cityKey, num) {
    let cityKeyRef = itineraryInfo.iterCityByKey[cityKey];
    all_cities.push(itineraryInfo.cityById[cityKeyRef.cityId].cityName);
  });

  if (all_cities.length > 1) {
    let lastCityName = all_cities.splice(-1);
    return _.join(all_cities, ', ') + ' and ' + lastCityName;
  } else {
    return _.join(all_cities, ', ');
  }
}

/**
 * It's used to get the title of the itinerary title.
 * @param {*} itineraryInfo
 */
export function getItineraryTitle(itineraryInfo = {}) {
  const itinerary = itineraryInfo.itinerary
  const title = itinerary.title;
  let itineraryTitle = title
    ? title
    : itinerary.special
      ? `${itinerary.nights} ${itinerary.nights > 1 ? 'nights' : 'night'} ${
      itinerary.specialTitle
      } Trail across ${getAllItineraryCities(itineraryInfo)}`
      : itinerary.campaign
        ? itinerary.specialTitle
        : `${itinerary.nights}${' '}
     ${
        itinerary.nights > 1 ? 'nights' : 'night'
        } in${' '}${getAllItineraryCities(itineraryInfo)}`;
  return itineraryTitle;
}

export function renderList(array = [], Component) {
  return array.map((a, i) => {
    return <Component {...a} key={i} />;
  });
}

export function fixItineraryHeader(
  targetPage = 'itinerary',
  isFromPackages = false
) {
  let tEl = document.querySelector('.itinerary-header');
  let cWEl = document.querySelector('.content-wrap');
  let titleSec = document.querySelector('.itinerary-header-name');
  let secTitleSec = document.querySelector('.itinerary-secodary-hdr');

  let navEl = document.querySelector('.navbar-outer');
  let navElHt = (navEl && navEl.clientHeight) || 0;

  let bcEl = document.querySelector('.breadcrumb-container');
  let bcElH = (bcEl && bcEl.clientHeight) || 0;
  if (bcEl && !isFaqMobile()) {
    bcEl.classList.add('sticky');

    cWEl.classList.add('with-breadcrumb');
  } else if (cWEl) {
    cWEl.classList.remove('with-breadcrumb');
  }

  let targetContainer = document.querySelector('section.itinerary');
  if (targetPage === 'costing') {
    targetContainer = document.querySelector('.costing-tab');
  }

  if (secTitleSec && !isFaqMobile()) {
    targetContainer = secTitleSec;
  }
  let titleSecHeight = titleSec && titleSec.clientHeight;

  if (tEl) {
    let scroll = window.pageYOffset;
    let targetSc = titleSecHeight + 6;

    if (isFromPackages && isFaqMobile()) {
      targetSc += bcEl ? bcEl.clientHeight : 0;
    }

    if (scroll > targetSc) {
      // 12 for padding
      tEl.classList.add('sticky');
      targetContainer.style.marginTop = tEl.clientHeight + 'px';
      tEl.style.top = navElHt + bcElH - targetSc + 'px';
    } else {
      tEl.classList.remove('sticky');
      tEl.style.top = isFromPackages ? 40 : 0;
      targetContainer.style.marginTop = 0;
    }
  }
}

/*
 * add zero to numbers less than 10,Eg: 2 -> 02
 */
export function getAllCities(cities) {
  //let all_cities = _.map(this.props.itineraryDetail.iterCities, 'cityName');
  let all_cities = _.map(cities, 'cityName');
  if (all_cities.length > 1) {
    let lastCityName = all_cities.splice(-1);
    return _.join(all_cities, ', ') + ' and ' + lastCityName;
  } else {
    return _.join(all_cities, ', ');
  }
}

export function isEmptyObject(obj) {
  return Object.keys(obj).length === 0;
}

export function onceModalOverOpened() {
  let bdClass = 'over-modal';
  let backDropEle = document.querySelector('.modal-backdrop');
  if (backDropEle.className.indexOf(bdClass) === -1)
    backDropEle.className += ' ' + bdClass;
}

export function onceModalOverClosed() {
  let backDropEle = document.querySelector('.modal-backdrop');
  backDropEle.className = backDropEle.className.replace('over-modal', '');
}

export function onceModalOpened() {
  let bdClass = 'in';
  let backDropEle = document.querySelector('.modal-backdrop');
  if (backDropEle && backDropEle.className.indexOf(bdClass) === -1)
    backDropEle.className += ' ' + bdClass;

  let slClass = 'scroll-locked';
  if (document.body.className.indexOf(slClass) === -1)
    document.body.className += ' ' + slClass;
}
/**
 * Fuction to convert the minutes to string
 * @param {*} minutes
 */
export function minutesToStr(minutes) {
  let hours = leftPad(Math.floor(Math.abs(minutes) / 60));
  let mins = leftPad(Math.abs(minutes) % 60);

  return hours + ' hrs ' + mins + ' min';
}

/**
 * add zero to numbers less than 10,Eg: 2 -> 02
 * @param {*} number
 */
export function leftPad(number) {
  return (number < 10 && number >= 0 ? '0' : '') + number;
}

/**
 * Function to sort the dataSource, by default it sort the data in ascending order.
 * @param  {Object} data
 * @param  {string} fields
 * @param  {boolean} isDescending
 * @returns Object
 */
export function sort(data, fields, isDescending = true) {
  let sortData = data;
  sortData.sort((a, b) => {
    let first = 0;
    let second = 0;
    for (let i = 0; i < fields.length; i++) {
      first += a[fields[i]];
      second += b[fields[i]];
    }
    if ((!isDescending && first < second) || (isDescending && first > second)) {
      return -1;
    } else if (first === second) {
      return 0;
    }
    return 1;
  });
  return sortData;
}

export function getRandomValue(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

export function getNumberToWord(num) {
  let a = [
    '',
    'one ',
    'two ',
    'three ',
    'four ',
    'five ',
    'six ',
    'seven ',
    'eight ',
    'nine ',
    'ten ',
    'eleven ',
    'twelve ',
    'thirteen ',
    'fourteen ',
    'fifteen ',
    'sixteen ',
    'seventeen ',
    'eighteen ',
    'nineteen '
  ];
  let b = [
    '',
    '',
    'twenty',
    'thirty',
    'forty',
    'fifty',
    'sixty',
    'seventy',
    'eighty',
    'ninety'
  ];
  let n;
  if ((num = num.toString()).length > 9) return 'overflow';
  n = ('000000000' + num)
    .substr(-9)
    .match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
  if (!n) return;
  var str = '';
  str +=
    n[1] != 0
      ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore '
      : '';
  str +=
    n[2] != 0
      ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh '
      : '';
  str +=
    n[3] != 0
      ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand '
      : '';
  str +=
    n[4] != 0
      ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred '
      : '';
  str +=
    n[5] != 0
      ? (str != '' ? 'and ' : '') +
        (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]])
      : '';
  return str;
}

export function onceModalClosed() {
  let backDropEle = document.querySelector('.modal-backdrop');
  backDropEle.className = backDropEle.className.replace('in', '');
  backDropEle.className = backDropEle.className.replace('over-modal', '');

  document.body.className = document.body.className.replace(
    'scroll-locked',
    ''
  );
  document.getElementsByTagName('body')[0].classList.remove('modal-open');
}

export function hideChatDesktop() {
  let bdClass = 'crisp-icon-hide';
  document.body.className += ' ' + bdClass;
}

export function hideChatHead() {
  let bdClass = 'crisp-hidden-xs';
  document.body.className += ' ' + bdClass;
}

export function resetChatHead() {
  document.body.className = document.body.className.replace(
    'crisp-hidden-xs',
    ''
  );
}

export function arrayToDisplayText(array, delimiter, lastDelimiter) {
  delimiter = delimiter ? delimiter : `,`;
  lastDelimiter = lastDelimiter ? lastDelimiter : `&`;
  let text = '';

  let d = ',';
  if (array && array.length > 0) {
    let l = array.length;
    array.map((a, i) => {
      if (i === l - 2) {
        d = lastDelimiter;
      } else if (i === l - 1 || l === 1) {
        d = ``;
      } else {
        d = delimiter;
      }

      return (text = text + ', ' + a + d);
    });
    return text;
  } else {
    return null;
  }
}

export function adultsChildrenString(adultsCount, childCount) {
  let text = ``;
  if (adultsCount > 0) {
    if (adultsCount === 1) {
      text = `${adultsCount} adult`;
    } else {
      text = `${adultsCount} adults`;
    }
  }
  if (childCount > 0) {
    if (childCount === 1) {
      text = text + `, ${childCount} child`;
    } else {
      text = text + `, ${childCount} children`;
    }
  }
  return text;
}

export function redirector(url, target) {
  window.open(url, target);
}

export function getWeatherIcon(iconName) {
  switch (iconName) {
    case 'clear-day':
      return 'wi-day-sunny';
    case 'partly-cloudy-night':
      return 'wi-night-alt-cloudy';
    case 'partly-cloudy-day':
      return 'wi-day-cloudy';
    case 'clear-night':
      return 'wi-night-clear';
    case 'rain':
      return 'wi-rain';
    case 'snow':
      return 'wi-snow';
    case 'sleet':
      return 'wi-sleet';
    case 'wind':
      return 'wi-cloudy-windy';
    case 'fog':
      return 'wi-fog';
    case 'cloudy':
      return 'wi-night-alt-cloudy';
    // case 'cloudy':
    //   return 'wi-day-cloudy';
    //   break;
    case 'hail':
      return 'wi-day-hail';
    case 'thunderstorm':
      return 'wi-day-thunderstorm';
    case 'tornado':
      return 'wi-tornado';
    default:
  }
}

export function getKeyValuefromUrlString(url, key) {
  let strings = url.split('?');
  let keyValuePair = strings[strings.length - 1];
  let searchVals = keyValuePair.split('=');
  if (searchVals[0] === key) {
    return searchVals[1];
  } else {
    return null;
  }
}

export function encodeCostingKeyForURL(key) {
  return key.replace(/###/g, '-');
}

export function decodeCostingKeyFromURL(key) {
  return key.replace(/-/g, '###');
}

export function encodeActivityKeyForURL(key) {
  return key.replace(/#/g, '-');
}

export function decodeActivityKeyFromURL(key) {
  return key.replace(/-/g, '#');
}

export const FaqsSec = {
  Faqs: 'Faqs',
  Changestoitinerary: 'Changestoitinerary',
  Beforebooking: 'Beforebooking',
  Afterbooking: 'Afterbooking',
  Duringtravel: 'Duringtravel'
};

export const CostedItineraryScroll = {
  FlightsandHotels: 'all-flight-hotel-panels',
  Flights: 'all-flight-panels',
  Hotels: 'all-hotel-panels',
  Transfers: 'all-transfer-panels',
  VisaInsurance: 'all-visa-panels',
  Activities: 'all-activity-panels',
  PassPanels: 'all-pass-panels'
};

export function openChatWidget() {
  // let $crisp = window.$crisp;
  // $crisp.push(['do', 'chat:open']);
}

export function generateItineraryObject(itineraryObj) {
  console.time('generateItineraryObject');

  let itinerary = itineraryObj.itinerary;

  let iterCityKeys = itinerary.allCityKeys,
    iterCityByKey = itineraryObj.iterCityByKey,
    iterCityById = itineraryObj.cityById,
    iterDayKey = itineraryObj.iterDayByKey,
    iterSlotKey = itineraryObj.iterSlotByKey,
    iterActivities = itineraryObj.activityById,
    iterCostingActivities = itineraryObj.activityCostings,
    IterCostingFerry = itineraryObj.ferryCostings,
    iterCostingFlights = itineraryObj.flightCostings,
    iterCostingHotels = itineraryObj.hotelCostings,
    iterCostingTrains = itineraryObj.trainCostings,
    iterCostingTransfers = itineraryObj.transferCostings,
    iterCostingRentalCars = itineraryObj.rentalCarCostings,
    itineraryCostingConfiguration = itineraryObj.itineraryCostingConfiguration;

  //International Departure
  itineraryObj.departSlotDetail = iterSlotKey[itinerary.departSlot];
  itineraryObj.itineraryCostingConfiguration = itineraryCostingConfiguration;

  let iterCities = [];
  _.forEach(iterCityKeys, function(cityKey, num) {
    let is_last_city = num === iterCityKeys.length - 1;
    let cityKeyRef = iterCityByKey[cityKey];

    let iterCity = {};
    iterCity = cityKeyRef;
    iterCity.cityKey = cityKey;
    iterCity.is_last_city = is_last_city;
    let city = iterCityById[iterCity.cityId];
    _.assign(iterCity, city);

    iterCity.hotelInCity = {};
    if (
      itinerary.costed &&
      !itinerary.staleCost &&
      iterCity.hotelRefKey !== ''
    ) {
      iterCity.hotelInCity =
        iterCostingHotels &&
        iterCostingHotels.hotelCostingById[iterCity.hotelRefKey];
    }

    // city arrival information
    let cityArrivalTransfer = iterCity.transferSlot;
    let cityArrivalTransferDetails = iterSlotKey[cityArrivalTransfer];

    let day_ref = _.findKey(iterDayKey, function(days) {
      return (
        days.allSlotKeys &&
        _.indexOf(days.allSlotKeys, cityArrivalTransfer) !== -1
      );
    });

    let iterDay = {};
    if (day_ref) {
      let dayRef = iterDayKey[day_ref];
      iterDay = dayRef;
      iterDay.month = dayRef.mon;
      iterDay.dayIdentifier = day_ref;
    }
    // _.assign(cityArrivalTransferDetails, { dayRef: iterDay });
    iterCity.transferSlotDetails = cityArrivalTransferDetails;

    if (itinerary.costed && !itinerary.staleCost) {
      let slot_detail = '';
      switch (cityArrivalTransferDetails.type) {
        case 'INTERNATIONAL_ARRIVE':
          slot_detail = cityArrivalTransferDetails.arrivalSlotDetail;
          {
            let flightCostingInfo =
              iterCostingFlights &&
              iterCostingFlights.flightCostingById[
                slot_detail.flightCostingKey
              ];
            iterCity.transferSlotDetails.costingInfo = flightCostingInfo;
          }
          break;
        case 'INTERCITY_TRANSFER':
          slot_detail =
            cityArrivalTransferDetails.intercityTransferSlotDetailVO;
          // let transferCostingIdenfier = slot_detail.transferCostingIdenfier;
          {
            let transferCostingIdenfier =
              slot_detail.directTransferDetail.transferCostingIdenfier;

            let transferCostingInfo = {};
            switch (slot_detail.directTransferDetail.transferMode) {
              case 'TRAIN':
                transferCostingInfo =
                  iterCostingTrains &&
                  iterCostingTrains.trainCostingById[transferCostingIdenfier];
                break;
              case 'FERRY':
                transferCostingInfo =
                  IterCostingFerry &&
                  IterCostingFerry.ferryCostingById[transferCostingIdenfier];
                break;
              case 'RENTALCAR':
                transferCostingInfo =
                  iterCostingRentalCars &&
                  iterCostingRentalCars.rentalCostingById[
                    transferCostingIdenfier
                  ];
                break;
              case 'FLIGHT':
                transferCostingInfo =
                  iterCostingFlights &&
                  iterCostingFlights.flightCostingById[transferCostingIdenfier];

                if (transferCostingInfo) {
                  transferCostingInfo.duration =
                    transferCostingInfo &&
                    _.sumBy(_.map(transferCostingInfo.trips, 'duration'));
                  transferCostingInfo.totalCost = transferCostingInfo.price;
                }
                break;
              default:
                transferCostingInfo =
                  iterCostingTransfers &&
                  iterCostingTransfers.transferCostingById[
                    transferCostingIdenfier
                  ];
            }
            iterCity.transferSlotDetails.costingInfo = transferCostingInfo;
          }
          break;
        default:
          break;
      }
    }

    let allDayKeys = cityKeyRef.allDayKeys,
      cityDays = [];
    allDayKeys.forEach(dayKey => {
      let dayRef = iterDayKey[dayKey];
      let iterDay = {};
      iterDay = dayRef;
      iterDay.month = dayRef.mon;
      iterDay.dayIdentifier = dayKey;

      let allSlotKeys = dayRef.allSlotKeys,
        daySlots = [];
      allSlotKeys.forEach(slotKey => {
        let slotRef = iterSlotKey[slotKey],
          iterSlot = {};
        iterSlot.cityId = iterCity.cityId;
        iterSlot.cityKey = iterCity.cityKey;
        // _.assign(iterSlot, iterDay);

        iterSlot.slotIdentifier = slotKey;
        switch (slotRef.type) {
          case 'ACTIVITY_WITH_TRANSFER':
          case 'ACTIVITY':
            {
              let activityDetailIdentifier =
                slotRef.activitySlotDetail.activityId;

              if (activityDetailIdentifier) {
                let activityInfo = iterActivities[activityDetailIdentifier];

                if (itinerary.costed && !itinerary.staleCost) {
                  let activityCostingRef =
                    slotRef.activitySlotDetail.activityCostingIdentifier;
                  activityInfo.costingInfo =
                    iterCostingActivities &&
                    iterCostingActivities.activityCostingById[
                      activityCostingRef
                    ];
                }
                _.assign(slotRef.activitySlotDetail, activityInfo);
              }
            }
            break;
          default:
            break;
        }
        _.assign(iterSlot, slotRef);

        daySlots.push(iterSlot);
      });
      iterDay.slots = daySlots;

      cityDays.push(iterDay);
    });
    iterCity.days = cityDays;

    iterCities.push(iterCity);
  });
  console.timeEnd('generateItineraryObject');

  return iterCities;
}

export function searchStringInArray(str, strArray) {
  for (let j = 0; j < strArray.length; j++) {
    if (strArray[j].toLowerCase().match(str)) return j;
  }
  return -1;
}

export function isElementInViewport(el) {
  let rect = el
    ? el.getBoundingClientRect()
    : { top: 0, left: 0, bottom: 0, right: 0 };

  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <=
      (window.innerHeight ||
        document.documentElement.clientHeight) /*or $(window).height() */ &&
    rect.right <=
      (window.innerWidth ||
        document.documentElement.clientWidth) /*or $(window).width() */
  );
}

export function countdown(elementId, minutes, callback) {
  let seconds = 60;
  let mins = minutes;
  let callback_bk = callback;
  clearInterval(window.counterInterval);

  function tick() {
    let counter = document.getElementById(elementId);

    if (!counter) {
      return false;
    }

    let current_minutes = mins - 1;
    seconds--;
    if (current_minutes < minutes / 2) {
      counter.classList.remove('white');
      // counter.classList.add('text-danger');
    }
    counter.innerHTML =
      (current_minutes < 10 ? '0' : '') +
      current_minutes.toString() +
      ':' +
      (seconds < 10 ? '0' : '') +
      String(seconds);
    if (seconds > 0) {
      window.counterInterval = setTimeout(() => {
        tick(elementId);
      }, 1000);
    } else {
      if (mins > 1) {
        // countdown(mins-1);   never reach “00″ issue solved:Contributed by Victor Streithorst
        window.counterInterval = setTimeout(() => {
          countdown(elementId, mins - 1, callback_bk);
        }, 1000);
      } else {
        callback_bk && callback_bk();
      }
    }
  }

  tick(elementId);
}

export function is_server() {
  return !(typeof window !== 'undefined' && window.document);
}

export function isMobile() {
  if (!is_server()) {
    return window.innerWidth <= 991;
  }
}

export function isMobileWeb(){
  if (!is_server()) {
    return window.innerWidth < 490;
  }
}

export function getUserDeviceInfo(){
  let user_device = 'WEB';
  if(isFaqMobile() && !isMobileWeb()){
    user_device = 'TABLET_WEB';
  }else if(isMobileWeb()){
    user_device = 'MOBILE_WEB';
  }
  return user_device;
}

export function isValidName(str) {
  return !/[^a-zA-Z ]/.test(str);
}

export function getExactDate(target) {
  let date = moment(target, 'DD/MMM/YYYY').format('YYYY-MM-DD');
  return new Date(date);
}

export function isNullorUndefined(value) {
  return value === undefined || value === null;
}

export function isFaqMobile() {
  if (!is_server()) {
    return window.innerWidth <= 767;
  }
}

export function hideChatIconOnMobile() {
  if (!is_server()) {
    let bodyEl = document.querySelector('body');
    bodyEl.classList.add('crisp-hidden-xs');
  }
}

export function showChatIconOnMobile() {
  if (!is_server()) {
    let bodyEl = document.querySelector('body');
    bodyEl.classList.remove('crisp-hidden-xs');
  }
}

export function clearAllTimeouts() {
  let id = window.setTimeout(function() {}, 0);
  while (id--) {
    window.clearTimeout(id); // will do nothing if no timeout with id is present
  }
}

export function getOffset(el) {
  if (!is_server()) {
    const rect = el.getBoundingClientRect();
    return {
      left: rect.left + window.scrollX,
      top: rect.top + window.scrollY
    };
  } else return null;
}

export function getBookedDateString(bookedOn) {
  let hoursSinceBooking = moment().diff(moment(bookedOn), 'hours');
  let daysSinceBooking = moment().diff(moment(bookedOn), 'days');
  let currentTimeinHour = parseInt(moment().format('H'));
  if (hoursSinceBooking - currentTimeinHour <= 24 || daysSinceBooking === 1) {
    return `BOOKED YESTERDAY`;
  } else if (hoursSinceBooking - currentTimeinHour > 24) {
    return `BOOKED ${daysSinceBooking}D AGO`;
  } else {
    return `BOOKED TODAY`;
  }
}

export function openOffCanvasMenu() {
  let body = document.querySelector('body');
  let offCanvasBG = document.querySelector('.offcanvas-bg');
  let offCanvasMenu = document.querySelector('.offcanvas-menu');

  body.classList.add('scroll-locked');
  offCanvasBG.classList.add('in');
  if (offCanvasMenu) {
    offCanvasMenu.classList.add('open-menu');
  }
}

export function closeOffCanvasMenu() {
  window.scroll(0, 0);
  let body = document.querySelector('body');
  let offCanvasBG = document.querySelector('.offcanvas-bg');
  let offCanvasMenu = document.querySelector('.offcanvas-menu');

  body.classList.remove('scroll-locked');
  offCanvasBG.classList.remove('in');
  offCanvasMenu.classList.remove('open-menu');
}

export function getFileNameFromUrl(url) {
  if (url) {
    if (url.includes('/')) {
      return url.substring(url.lastIndexOf('/') + 1);
    } else {
      return url;
    }
  } else {
    return false;
  }
}

export function getPathnameFromUrl(url) {
  if (url) {
    if (url.includes('/')) {
      let chuncks = url.split('/');

      switch (chuncks.length) {
        case 8:
          return `${chuncks[3]}/${chuncks[4]}/${chuncks[5]}/${chuncks[6]}`;
        case 7:
          return `${chuncks[3]}/${chuncks[4]}/${chuncks[5]}`;
        case 6:
          return `${chuncks[3]}/${chuncks[4]}`;
        case 5:
          return `${chuncks[3]}`;
        default:
      }
    } else {
      return url;
    }
  } else {
    return false;
  }
}

export function removeQueryString() {
  if(window) {
    // remove url query string without reloading the page
    const uri = window.location.toString();
    const clean_uri = uri.substring(0, uri.indexOf("?"));
    window.history.replaceState({}, document.title, clean_uri);
  }
}

export function getQueryStringValue(queryString, key) {
  return decodeURIComponent(
    queryString.replace(
      new RegExp(
        '^(?:.*[&\\?]' +
          encodeURIComponent(key).replace(/[.+*]/g, '\\$&') +
          '(?:\\=([^&]*))?)?.*$',
        'i'
      ),
      '$1'
    )
  );
}

export function getPackageKeyFromPathname(pathname) {
  let key = pathname;

  // Remove the first slash ("/") from the pathname - which always be part of the pathname
  if (key.charAt(0) === '/') {
    key = key.substr(1);
  }

  // Remove the search query from the pathname
  key = key.split("?")[0];

  let removeOtherRoutes = [
    'get-cost',
    'request-callback',
    'login',
    'signup',
    'costing-delay'
  ];

  // Split the pathname into parts to loop through and remove modal URLs
  let pArr = key.split('/');
  removeOtherRoutes.map(v => {
    if (pArr.indexOf(v) !== -1) {
      pArr = pArr.splice(0, pArr.indexOf(v));

      key = pArr.join('/');
    }
    return false;
  });

  return key;
}

/**
 * @desc This will take the S3 URL and gives us the appropriate imgIX URL
 * @param {string} src - actual URL of the image - usually it would be S3 URL
 * @param {string} imgFactor - Image query parameters for imgIX e.g: w=600&h=200 which will produce the image with 600px width and 200px height.
 * @returns {*}
 * @exports
 *
 * @example src = "https://d3lf10b5gahyby.cloudfront.net/cityImages/75/singapore-1.jpg" & imgFactor="w=600"
 * STEP #1: imgPath = d3lf10b5gahyby.cloudfront.net/cityImages/75/singapore-1.jpg
 * STEP #2: origin = d3lf10b5gahyby.cloudfront.net
 * STEP #3: case 'd3lf10b5gahyby.cloudfront.net' will match so, imgPath = //pyt-images.imgix.net/images/cityImages/75/singapore-1.jpg
 * STEP #4: imgFactor is there and imgPath has pyt-images.imgix.net so final returned URL will be //pyt-images.imgix.net/images/cityImages/75/singapore-1.jpg?w=600
 */
export function getImgIXUrl(src, imgFactor) {
  // Check if src is valid (not undefined | false ) then proceed
  if (src) {
    let imgPath = src.replace(/^(https?:|)\/\//, ''); // Will remove the (http/https://) from the source and assign that to new variable imgPath = d3lf10b5gahyby.cloudfront.net/cityImages/75/singapore-1.jpg
    let origin = imgPath.split('/')[0]; // this will split at [/] and return the first portion of the URL @origin name

    // Compare the origin to identify the respective imgIX url for the particular bucket.
    // IMGIX_TESTIMONIAL_BASE is //pyt-testimonial.imgix.net setup against //pyt-testimonialimages.s3.ap-south-1.amazonaws.com bucket
    // IMGIX_BASE is //pyt-images.imgix.net setup against //s3.ap-south-1.amazonaws.com/oceanjar-new
    switch (origin) {
      case 'pyt-testimonialimages.s3.ap-south-1.amazonaws.com':
        imgPath = imgPath.replace(origin, IMGIX_TESTIMONIAL_BASE);
        break;
      case 'd3lf10b5gahyby.cloudfront.net': // is a cloudfront URL for the //s3.ap-south-1.amazonaws.com/oceanjar-new/images this bucket. So we have to add /images to imgIX URL to point to the proper bucket
        imgPath = imgPath.replace(origin, IMGIX_BASE + '/images');
        break;
      case 's3.ap-south-1.amazonaws.com': // is the basic bucket URL
        imgPath = imgPath.replace(origin, IMGIX_BASE);
        if (imgPath.includes('/oceanjar-new')) {
          // to check if the imgPath has /oceanjar-new text. return {true} if it has otherwise {false}
          imgPath = imgPath.replace('/oceanjar-new', ''); // if we are replacing this to imgIX we have to make sure we have removed the /oceanjan-new bucket name from the URL.
        }
        break;
      default:
        imgPath = src; // if nothing matches re-assign src to imgPath
    }

    let dpr = 1;
    if (!is_server()) {
      // check the pixel ratio
      const pixelDensity = window.devicePixelRatio;
      if ((pixelDensity !== undefined && pixelDensity > 1) || isMobile()) {
        dpr = 2; //retina
      }
    }

    // Check and add the imgFactor to the final URL
    if (
      imgFactor &&
      (imgPath.indexOf(IMGIX_BASE) !== -1 ||
        imgPath.indexOf(IMGIX_TESTIMONIAL_BASE) !== -1) // imgFactor should there & path should contain imgIX (either base or testimonial) URL
    ) {
      if (imgFactor === 'isTeamSlide') {
        imgFactor = 'w=240';
        dpr = 2;
      }
      return `${imgPath}?${imgFactor}&dpr=${dpr}`;
    }
    return `${imgPath}`; // Just return just the imgPath otherwise
  }
}

export function getAirlineLogo(airlineCode = 'no-image') {
  return {
    name: airlineCode,
    url: getImgIXUrl(S3_baseUrl + `web_app/itinerary/airline-logos/square/${airlineCode.trim()}.jpg`),
    default: getImgIXUrl(S3_baseUrl + `web_app/itinerary/airline-logos/square/default-logo.jpg`)
  };
}

/**
 * Check if any hotel in the given CRED itinerary has `status="SOLD_OUT"`
 * return status=true if found "SOLD_OUT"
 * return status=false in other cases
 * @param {object} itineraryInfo - this object gets destructured to get couponVO & hotelCostings data
 * Handle all null checks before using these objects
 */
export function isHotelSoldOutCRED({ couponVO, hotelCostings }) {
  if (
    typeof couponVO === "object" &&
    typeof hotelCostings === "object" &&
    couponVO.couponPartner === "CRED"
  ) {
    const { hotelCostingById } = hotelCostings;
    if(typeof hotelCostingById === "object") {
      for(let id in hotelCostingById) {
        const data = hotelCostingById[id] || {};
        if(typeof data.status === "string" && data.status === "SOLD_OUT") {
          return {
            status: true,
            message: data.name ? data : { name: 'The hotel' }
          }
        }
      }
    }
  }

  return {
    status: false
  }
}

/**
 * Check if the string contains only alphabets and spaces.
 * return false if the string contains any symbols/numbers/empty-strings
 * @param {string} text
 */
export function isAlphabetsOnly(text) {
  if(typeof text === 'string' && text.replace(/ /g, '').length) {
    return /^[a-zA-Z\s]*$/.test(text);
  }
  return false;
}
