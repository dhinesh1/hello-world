import React from 'react';
import { Redirect, Route } from 'react-router-dom';

export const Status = ({ code, children }) => (
  <Route
    render={({ staticContext }) => {
      if (staticContext) staticContext.status = code;

      return children;
    }}
  />
);

export const RedirectWithStatus = ({ to, status }) => (
  <Route
    render={({ staticContext }) => {
      // there is no `staticContext` on the client, so
      // we need to guard against that here
      if (staticContext) staticContext.status = status;

      return <Redirect to={to} />;
    }}
  />
);
