import _ from 'lodash';

//Getting lead source starts
export function getSourceNameByUrl(url) {
  const domain = url
    .replace('http://', '')
    .replace('https://', '')
    .replace('www.', '')
    .split(/[/?#]/)[0];
  const sourceMappings = [
    { url: 'google.com', source: 'Search', type: 'Organic' },
    { url: 'google.co.in', source: 'Search', type: 'Organic' },
    { url: 'bing.com', source: 'Search', type: 'Organic' },
    { url: 'search.yahoo.com', source: 'Search', type: 'Organic' },
    { url: 'in.yahoo.com', source: 'Search', type: 'Organic' },
    { url: 'yahoo.com', source: 'Search', type: 'Organic' },
    { url: 'ask.com', source: 'Search', type: 'Organic' },
    { url: 'baidu.com', source: 'Search', type: 'Organic' },
    {
      url: 'com.google.android.googlequicksearchbox',
      source: 'Search',
      type: 'Organic'
    },
    { url: 'googleweblight.com', source: 'Search', type: 'Organic' },
    { url: 'com.google.android.gm', source: 'Search', type: 'Organic' },
    { url: 'in.search.yahoo.com', source: 'Search', type: 'Organic' },
    { url: 'int.search.tb.ask.com', source: 'Search', type: 'Organic' },
    { url: 'cn.bing.com', source: 'Search', type: 'Organic' },
    { url: 'myactivity.google.com', source: 'Search', type: 'Organic' },
    { url: 'search.mysearch.com', source: 'Search', type: 'Organic' },
    { url: 'facebook.com', source: 'Facebook', type: 'Social' },
    { url: 'm.facebook.com', source: 'Facebook', type: 'Social' },
    { url: 'l.facebook.com', source: 'Facebook', type: 'Social' },
    { url: 'lm.facebook.com', source: 'Facebook', type: 'Social' },
    { url: 'l.instagram.com', source: 'Instagram', type: 'Social' },
    { url: 'instagram.com', source: 'Instagram', type: 'Social' },
    { url: 't.co', source: 'Twitter', type: 'Social' },
    { url: 'twitter.com', source: 'Twitter', type: 'Social' },
    { url: 'narayananh.tweetd.com', source: 'Twitter', type: 'Social' },
    { url: 'linkedin.com', source: 'Linkedin', type: 'Social' },
    { url: 'com.linkedin.android', source: 'Linkedin', type: 'Social' },
    { url: 'lnkd.in', source: 'Linkedin', type: 'Social' },
    { url: 'in.pinterest.com', source: 'Pinterest', type: 'Social' },
    { url: 'pinterest.com', source: 'Pinterest', type: 'Social' },
    { url: 'quora.com', source: 'Quora', type: 'Social' },
    { url: 'auto_email', source: 'Email', type: 'Email' },
    { url: 'email_sign', source: 'Email', type: 'Email' },
    { url: 'mail.google.com', source: 'Email', type: 'Email' },
    { url: 'outlook.live.com', source: 'Email', type: 'Email' },
    { url: 'founder_email', source: 'Email', type: 'Email' },
    { url: 'mail.yahoo.com', source: 'Email', type: 'Email' },
    { url: 'niner', source: 'Email', type: 'Email' },
    { url: 'drip', source: 'Email', type: 'Email' },
    { url: 'rediffmail.com', source: 'Email', type: 'Email' },
    { url: 'mg.mail.yahoo.com', source: 'Email', type: 'Email' },
    { url: 'us-mg5.mail.yahoo.com', source: 'Email', type: 'Email' },
    { url: 'mail.zoho.com', source: 'Email', type: 'Email' },
    { url: 'newsletter', source: 'Email', type: 'Email' },
    { url: 'diwali_email', source: 'Email', type: 'Email' },
    { url: 'email.makharafi.net', source: 'Email', type: 'Email' },
    { url: 'f4mail.rediff.com', source: 'Email', type: 'Email' },
    { url: 'f4mobile.rediff.com', source: 'Email', type: 'Email' },
    { url: 'testtxncdn.payubiz.in', source: 'Misc', type: 'Misc' },
    { url: 'worknhire.com', source: 'Misc', type: 'Misc' },
    { url: 'go.crisp.chat', source: 'Misc', type: 'Misc' },
    { url: 'blog.com', source: 'Misc', type: 'Misc' },
    { url: 'crayond.com', source: 'Misc', type: 'Misc' },
    { url: 'expatriates.com', source: 'Misc', type: 'Misc' },
    { url: 'Blog', source: 'Misc', type: 'Misc' },
    { url: 'timesjobs.com', source: 'Misc', type: 'Misc' },
    { url: 'soreeager-askhorn.com', source: 'Misc', type: 'Misc' },
    { url: 'newzealand.com', source: 'Misc', type: 'Misc' },
    { url: 'com.slack', source: 'Misc', type: 'Misc' },
    { url: 'duckduckgo.com', source: 'Misc', type: 'Misc' },
    { url: 'medium.com', source: 'Misc', type: 'Misc' },
    { url: 'travelcurated.com', source: 'Misc', type: 'Misc' },
    { url: 'genextstudents.com', source: 'Misc', type: 'Misc' },
    { url: 'ecosia.org', source: 'Misc', type: 'Misc' },
    { url: 'eto.my.salesforce.com', source: 'Misc', type: 'Misc' },
    { url: 'incomekey.net', source: 'Misc', type: 'Misc' },
    { url: 'mastcareers.com', source: 'Misc', type: 'Misc' },
    { url: 'travhq.com', source: 'Misc', type: 'Misc' },
    { url: 'm.timesjobs.com', source: 'Misc', type: 'Misc' },
    { url: 'socialsamosa.com', source: 'Misc', type: 'Misc' },
    { url: 'web.whatsapp.com', source: 'Misc', type: 'Misc' },
    { url: 'bigfday', source: 'Misc', type: 'Misc' },
    { url: 'james.blog1989.com', source: 'Misc', type: 'Misc' },
    { url: 'productlocus.com', source: 'Misc', type: 'Misc' },
    { url: 'reddit.com', source: 'Misc', type: 'Misc' },
    { url: 'searchguide.level3.com', source: 'Misc', type: 'Misc' },
    { url: 'web.telegram.org', source: 'Misc', type: 'Misc' },
    { url: 'alternativeto.net', source: 'Misc', type: 'Misc' },
    { url: 'app.gotomeeting.com', source: 'Misc', type: 'Misc' },
    { url: 'asianentrepreneur.org', source: 'Misc', type: 'Misc' },
    { url: 'bigfday.com', source: 'Misc', type: 'Misc' },
    { url: 'Blog.com', source: 'Misc', type: 'Misc' },
    { url: 'brokenlinkcheck.com', source: 'Misc', type: 'Misc' },
    { url: 'indexchecking.com', source: 'Misc', type: 'Misc' },
    { url: 'madrasmade.net', source: 'Misc', type: 'Misc' },
    { url: 'skcript.com', source: 'Misc', type: 'Misc' },
    { url: 'thelma.blog1989.com', source: 'Misc', type: 'Misc' },
    { url: 'urlopener.com', source: 'Misc', type: 'Misc' },
    { url: 'vitrag24.wordpress.com', source: 'Misc', type: 'Misc' },
    { url: 'xml-sitemaps.com', source: 'Misc', type: 'Misc' },
    { url: 'ap4.salesforce.com', source: 'Misc', type: 'Misc' },
    { url: 'app.crayon.co', source: 'Misc', type: 'Misc' },
    { url: 'getpocket.com', source: 'Misc', type: 'Misc' },
    { url: 'glassdoor.co.in', source: 'Misc', type: 'Misc' },
    { url: 'icrumz.com', source: 'Misc', type: 'Misc' },
    { url: 'letsintern.com', source: 'Misc', type: 'Misc' },
    { url: 'my.exportersindia.com', source: 'Misc', type: 'Misc' },
    { url: 'na88.salesforce.com', source: 'Misc', type: 'Misc' },
    { url: 'popxo', source: 'Misc', type: 'Misc' },
    { url: 'rapidlinkr.com', source: 'Misc', type: 'Misc' },
    { url: 'reports.worldig.com', source: 'Misc', type: 'Misc' },
    { url: 'results.searchlock.com', source: 'Misc', type: 'Misc' },
    { url: 'shantanu.blog1989.com', source: 'Misc', type: 'Misc' },
    { url: 'sharpr.com', source: 'Misc', type: 'Misc' },
    { url: 'sheroes.com', source: 'Misc', type: 'Misc' },
    { url: 'techinasia.com', source: 'Misc', type: 'Misc' },
    { url: 'tripoto.com', source: 'Misc', type: 'Misc' },
    { url: 'vfs-france.co.in', source: 'Misc', type: 'Misc' },
    { url: 'tamil.yourstory.com', source: 'Misc', type: 'Misc' },
    {
      url: 'agents.pickyourtrail.com',
      source: 'Network Sites',
      type: 'Network Sites'
    },
    {
      url: 'visa.pickyourtrail.com',
      source: 'Network Sites',
      type: 'Network Sites'
    },
    {
      url: 'blog.pickyourtrail.com',
      source: 'Network Sites',
      type: 'Network Sites'
    },
    {
      url: 'staging.pickyourtrail.com',
      source: 'Network Sites',
      type: 'Network Sites'
    },
    {
      url: 'sample.pickyourtrail.com',
      source: 'Network Sites',
      type: 'Network Sites'
    },
    {
      url: 'longweekend.co.in',
      source: 'Network Sites',
      type: 'Network Sites'
    },
    {
      url: 'plato.pickyourtrail.com',
      source: 'Network Sites',
      type: 'Network Sites'
    },
    {
      url: 'help.pickyourtrail.com',
      source: 'Network Sites',
      type: 'Network Sites'
    }
  ];

  for (let i = 0; i < sourceMappings.length; i++) {
    if (sourceMappings[i].url === domain) {
      return sourceMappings[i];
    }
  }
}

export function checkIfLeadSourceDataAlreadyCaptured() {
  return !!(localStorage && localStorage.getItem('leadSource'));
}

export function storeLSData(lsd, device) {
  if (!checkIfLeadSourceDataAlreadyCaptured() && localStorage) {
    const lead_data = {
      url: '',
      source: '',
      type: '',
      deviceType: '',
      searchKeyWords: '',
      campaign: ''
    };
    lead_data.url = lsd.url;
    lead_data.source = lsd.source;
    lead_data.type = lsd.type;
    lead_data.deviceType = device;
    localStorage.setItem('leadSource', JSON.stringify(lead_data));
  }
}

export function getDeviceType() {
  const w = window.innerWidth;
  if (w < 768) {
    return 'Mobile';
  } else if (w >= 768 && w <= 1024) {
    return 'Tablet';
  } else {
    return 'Desktop';
  }
}

export function identifyLeadSource() {
  const ls = {
    url: '',
    source: '',
    type: '',
    deviceType: '',
    prodType: ''
  };

  ls.url = document.referrer;
  storeLSData(ls, getDeviceType());

  // if (ref) {
  //   ls_actual = getSourceNameByUrl(ref);
  //   if (!ls_actual) {
  //     ls_actual = ls;
  //     ls_actual.url = ref;
  //   }
  //   storeLSData(ls_actual, getDeviceType());
  // } else {
  //   storeLSData(ls, getDeviceType());
  // }
}

export function updateItinerarySourcePage(source) {
  let itineraryCreatedSourceLocal =
    localStorage && localStorage.getItem('itineraryCreatedSource');

  if (!itineraryCreatedSourceLocal) {
    itineraryCreatedSourceLocal = [];
  } else {
    itineraryCreatedSourceLocal = JSON.parse(itineraryCreatedSourceLocal);
  }

  itineraryCreatedSourceLocal.push(source);
  if (source) {
    localStorage.setItem(
      'itineraryCreatedSource',
      JSON.stringify(itineraryCreatedSourceLocal)
    );
  }
}

/**
 * @author Jothisankar <jothi@pickyourtrail.com>
 * @param history
 * @param lastLocation
 * @param itineraryId
 * @description Will be served as global method to fetch/create leadSource object for lead/user tracking.
 */
export function getLeadSource({ history = {}, lastLocation, itineraryId, isCBR = false }) {
  let leadSource = {};

  if (checkIfLeadSourceDataAlreadyCaptured() && localStorage && sessionStorage) {
    leadSource = JSON.parse(localStorage.getItem('leadSource'));

    // CPID
    leadSource.cpid = sessionStorage.getItem('campaignId');
    leadSource.landingPage = sessionStorage.getItem('source');

    if (lastLocation) {
      leadSource.lastRoute = lastLocation.pathname;
    }
    let pathName = history.location && history.location.pathname;
    if (
      pathName.split('/')[1].indexOf('vacations') >= 0 ||
      pathName.indexOf('packages') > 0
    ) {
      // Adding condition to differentiate CBR with GCM - default value for this false
      leadSource.prodType = isCBR ? 'CBR' : 'PACKAGES';

      if (history.location.search.indexOf('&autocbr') > 0) {
        leadSource.prodType = 'EXIT_INTENT_CBR';
      }
    } else if (pathName.split('/')[1] === 'holidays') {
      leadSource.prodType = 'CBR';
    } else if (history.location.pathname.indexOf('/customize/') >= 0) {
      leadSource.prodType = 'PDG';
    } else if (
      window.location.href.split('/request-callback')[0] ===
      window.location.origin
    ) {
      leadSource.prodType = 'HOME_PAGE_CBR';
      leadSource.url = window.location.origin;
    } else {
      let itineraryCreatedSourceLocal = localStorage.getItem(
        'itineraryCreatedSource'
      );

      if (itineraryCreatedSourceLocal) {
        let itinerarySourceObj = JSON.parse(itineraryCreatedSourceLocal);

        let current_itin_obj = _.find(itinerarySourceObj, function(obj) {
          return obj && obj.itineraryId === itineraryId;
        });

        if (current_itin_obj) {
          leadSource.prodType = current_itin_obj.page;
        }
      }
      if (!leadSource.prodType || leadSource.prodType === '') {
        leadSource.prodType = 'RECENTLY_BOOKED';
      }
    }
  }

  return leadSource;
}
