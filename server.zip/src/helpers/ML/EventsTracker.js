import { store } from '../../store/configureStore';
import { INCLUSIONS_VIEW, ITINERARY_VIEW } from '../routesHelper';
/**
 * List of Events that are tracked as defined constants to use in places needed
 */
const EVENT_LOGO_CLICKED = 'PYT Logo Clicked';
const EVENT_POSTCARD = 'Postcard';
const EVENT_START_PLANNING = "Started PDG";
const EVENT_RECENTLY_BOOKED = 'Recently Booked';
const EVENT_CBR = 'Call Requested';
const EVENT_PAGE_VISITED = 'Page Viewed';
const EVENT_PACKAGE_SELECTED = 'Package Selected';
const EVENT_PACKAGE_FILTERED = 'Package Filtered';
const EVENT_PDG_DESTINATION_SELECTED = 'Destination Selected';
const EVENT_PDG_MONTH_SELECTED = 'Month Selected';
const EVENT_PDG_DURATION_SELECTED = 'No-of days Selected';
const EVENT_PDG_THEMES_SELECTED = 'Themes Selected';
const EVENT_PDG_CHOOSE_CITIES = 'Customize Cities';
const EVENT_PDG_ITINERARY_CREATED = 'Itinerary Created';
const EVENT_PDG_CITY_ADDED = 'City Added';
const EVENT_PDG_CITY_REMOVED = 'City Removed';
const EVENT_ITINERARY_MODIFIED = 'Itinerary Modified';
const EVENT_ITINERARY_COSTED = 'Itinerary Costed';
const EVENT_ITINERARY_COSTING_SUBMITTED = 'Itinerary Costing submitted';
const EVENT_INCLUSIONS_MODIFIED = 'Inclusions Modified';
const EVENT_QUOTE_REQUESTED = 'Quote Requested';
const EVENT_BOOKING_INITIATED = 'Booking Initiated';
const EVENT_PAX_FILLED = 'Pax Details filled';
const EVENT_COST_REVIEWED = 'Cost Reviewed';
const EVENT_PAYMENT_INITIATED = 'Payment Initiated';
const EVENT_PAYMENT_SUCCESS = 'Payment Success';
const EVENT_PAYMENT_FAILED = 'Payment Failed';
const EVENT_BOOKING_COMPLETED = 'Booking completed';
const EVENT_BOOKING_TIMED_OUT = 'Booking Timed out';
const EVENT_COUPON_APPLIED = 'Coupon Applied';
const EVENT_COUPON_REMOVED = 'Coupon Removed';
const EVENT_LOGOUT = 'User Logout';

const EVENT_CHAT_REQUESTED = 'Chat Requested';
const EVENT_CANCELLATION_POLICY = 'Cancellation Policy Viewed';
const EVENT_YOUR_VACATIONS = 'Your Vacations Viewed';
const EVENT_BLOG_VIEWED = 'Blog Viewed';
const EVENT_TESTIMONIAL_VIEWED = 'Testimonial Viewed';

// UI button events to track interaction types
const EVENT_ADD = 'Add';
const EVENT_EDIT = 'Edit';
const EVENT_CHANGE = 'Change';
const EVENT_REMOVE = 'Remove';
const EVENT_PACKAGES_EDIT = 'Packages Edit';

// UI position/place of the events tracked/occurred
const EVENT_POSITION_HEADER = 'Header';
const EVENT_POSITION_FOOTER = 'Footer';

// User Profile events
const USER_LOGIN = 'Login';
const USER_SIGNUP = 'Signup';
const USER_LOGIN_GETCOST = 'Login - Get Cost';
const USER_SIGNUP_GETCOST = 'Signup - Get Cost';

// page call names
const PAGE_PACKAGES = 'Packages Page';
const PAGE_PDG = 'PDG Customize Page';
const PAGE_TESTIMONIALS = 'Testimonials Page';
const PAGE_CAREERS = 'Careers';
const PAGE_ABOUT = 'About Us';
const PAGE_CONTACT = 'Contact';
const PAGE_FAQ = 'FAQ';
const PAGE_TERMS = 'T&C';
const PAGE_PRIVACY = 'Privacy Policy';
const PAGE_CANCELLATION = 'Cancellation Policy';

// Quora Pixel events
const EVENT_GENERATE_LEAD = 'GenerateLead';

/**
 * Segment Event Tracker
 * @param {string} eventName - event name
 * @param {object} props - list of attributes need to be captured on particular event
 */
const trackEvent = (eventName, props = {}) => {
  if (window.analytics) {
    //check if props is object, change it to valid object if it is not one.
    props = (typeof props === "object" && !Array.isArray(props)) ? props : { props };
    let eventProps = {};
    try {
      const storeData = store.getState();
      const itineraryInfo = storeData.app.itineraryInfo;
      
      switch (eventName) {
        case EVENT_START_PLANNING:
          props = {
            ...props,
            element_name: props.element_name || 'btn_pdg_create_itinerary_packages'
          }
          break;
        case EVENT_PDG_DESTINATION_SELECTED:
          props = {
            ...props,
            element_type: 'dropdown',
            element_name: 'dd_pdg_destination'
          }
          break;
        case EVENT_PDG_MONTH_SELECTED:
          props = {
            ...props,
            element_type: 'dropdown',
            element_name: 'dd_pdg_month'
          }
          break;
        case EVENT_PDG_DURATION_SELECTED:
          props = {
            ...props,
            element_type: 'dropdown',
            element_name: 'dd_pdg_duration'
          }
          break;
        case EVENT_PDG_THEMES_SELECTED:
          props = {
            ...props,
            element_type: 'dropdown',
            element_name: 'dd_pdg_themes'
          }
          break;
        case EVENT_PDG_CHOOSE_CITIES:
          props = {
            ...props,
            element_type: 'dropdown',
            element_name: 'dd_pdg_choose_cities'
          }
          break;
        case EVENT_ITINERARY_COSTING_SUBMITTED:
          props = {
            ...props,
            element_type: 'button',
            element_name: 'btn_gcm_get_cost'
          }
          break;
        case EVENT_CANCELLATION_POLICY:
          props = {
            ...props,
            element_type: 'button',
            element_name: 'btn_cancellation_policy_top_bar'
          }
          break;
        case EVENT_PAX_FILLED: {
          let pax_details = [];
          props.pax_details.forEach(room => {
            room.forEach(item => {
              const { type, birthDay, firstName, lastName, salutation } = item;
              pax_details.push({
                type, firstName, lastName, salutation,
                birthday: new Date(birthDay)
              })
            });
          });
          props = {
            ...props,
            pax_details,
            element_type: 'button',
            element_name: 'btn_make_payment_booking_travellers'
          }
        }
          break;
        case EVENT_COST_REVIEWED:
          props = {
            ...props,
            element_type: 'button',
            element_name: 'btn_review_costs_live_cost'
          }
          break;
        case EVENT_PAYMENT_INITIATED:
          props = {
            ...props,
            element_type: 'button',
            element_name: 'btn_pay_now'
          }
          break;
        case EVENT_PACKAGE_SELECTED:
          props = {
            ...props,
            element_type: 'card',
            element_name: 'card_package'
          }
          break;
        case EVENT_CBR: {
          /**
           * Pass different element names based on the page they triggered the Callback request
           * |----------------------------------------------|------------------------------------------------------------------------|
           * | element_name                                 | scenario where it is triggered                                         |
           * |----------------------------------------------|------------------------------------------------------------------------|
           * |btn_call_back_request_homepage                | homepage                                                               |
           * |btn_call_back_request_itinerary               | Itinerary View Page                                                    |
           * |btn_call_back_request_inclusions              | Itinerary Inclusions Page                                              |
           * |btn_call_back_request_paid_campaign_exitpp    | Any paid campaign pages on exit intend(moving cursor out from viewport)|
           * |btn_call_back_request_paid_campaign_floating  | submitting form from bottom floating button on paid campaign pages     |
           * |btn_call_back_request_packages__exitpp        | Any packages page on exit intend(moving cursor out from viewport)      |
           * |btn_call_back_request_packages__floating      | submitting form from bottom floating button on any packages page       |
           * |----------------------------------------------|------------------------------------------------------------------------|
           */
          let ename = 'btn_call_back_request_homepage';
          if(typeof props.pageURL === 'string') {
            if(props.pageURL.includes(`/${ITINERARY_VIEW}/`))
              ename = 'btn_call_back_request_itinerary';
            else if(props.pageURL.includes(`/${INCLUSIONS_VIEW}/`))
              ename = 'btn_call_back_request_inclusions';
            else {
              const { packages = {} } = storeData;
              const { content } = packages;
              let isPaid = null, exit_intend = null;
              // check paid flag from packages object to identify the packages page type
              if(content && typeof content === "object" && Object.keys(content).length) {
                const { campaignDetails={} } = content;
                isPaid = campaignDetails.paid;
              }
              // check autocbr query parameter to identify how the CBR is triggered on packages
              if(props.pageURL.includes('&autocbr')) {
                exit_intend = true;
              }
              if(isPaid) {
                ename = `btn_call_back_request_paid_campaign_${exit_intend ? 'exitpp' : 'floating'}`;
              } else {
                ename = `btn_call_back_request_packages_${exit_intend ? 'exitpp' : 'floating'}`;
              }
            } 
          }
          props = {
            ...props,
            element_type: 'button',
            element_name: ename
          }
        }
          break;
        case EVENT_PDG_ITINERARY_CREATED: 
          props = {
            ...props,
            city: storeData.app.selectedCityNames,
            destination: storeData.app.regionDetails.regionName,
            element_type: 'button',
            element_name: 'btn_build_itinerary'
          }
          break;
        case EVENT_PAYMENT_SUCCESS: {
          const { payment={} } = storeData;
          const { paymentProcessing={} } = payment;
          props = {
            ...props,
            amount: paymentProcessing.amount
          }
        }
          break;
        case EVENT_PAYMENT_FAILED: {
          const { payment={} } = storeData;
          const { paymentProcessing={} } = payment;
          props = {
            ...props,
            amount: paymentProcessing.amount
          }
        }
          break;
        case EVENT_BOOKING_INITIATED: {
          const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
          const {
            itinerary = {},
            cityById = {},
            allFlightCostingRefs = [],
            allHotelCostingRefs = [],
            allTransferCostingRefs = [],
            allTrainCostingRefs = [],
            allFerryCostingRefs = [],
            allVisaCostingRefs = [],
            allRentalCostingRefs = [],
            insuranceCosting={},
            activityCostings={},
            costingConfiguration = {},
            paymentSchedule = {}
          } = itineraryInfo.itineraryDetails;
          const activities = Object.keys(activityCostings.activityCostingById || {}).map(key => {
            const item = activityCostings.activityCostingById[key];
            return `${item.activityName} - ${item.cityText}`;
          });
          const cities = Object.keys(cityById).map(key => {
            const item = cityById[key];
            return item.cityName;
          });
          props = {
            ...props,
            total_flights: allFlightCostingRefs.length,
            total_hotels: allHotelCostingRefs.length,
            total_transfers: allTransferCostingRefs.length,
            total_trains: allTrainCostingRefs.length,
            total_ferry: allFerryCostingRefs.length,
            total_rentals: allRentalCostingRefs.length,
            activities,
            cities,
            visa_included: allVisaCostingRefs.length ? true : false,
            insurance_included: (typeof insuranceCosting.insuranceCostingById === "object" && insuranceCosting.insuranceCostingById.required) ? true : false,
            adult_count: itineraryInfo.adult_count,
            child_count: itineraryInfo.child_count,
            total_cost: parseInt((paymentSchedule.itineraryTotalCost+'').replace(/,/g, '')),
            month: costingConfiguration.departureDate ? months[new Date(costingConfiguration.departureDate).getMonth()] : '',
            departure_date: costingConfiguration.departureDate ? new Date(costingConfiguration.departureDate) : '',
            departure_city: costingConfiguration.departureCity,
            is_agent: itinerary.agent || false,
            discounted_price: itinerary.discountedPrice || 0,
            destination: itinerary.countries.map((country) => country.name),
            element_type: 'button',
            element_name: 'btn_book_your_trip_top_bar'
          }
        }
          break;
        default:
          break;
      }
      /**
       * Check property keys for array type values in any key.
       * Convert arrays to comma separated values and assign it to same key. 
       * Also add '{attrName}_array' key to store the actual array values
       * And add '{attrName}_count' key to store the array size
       */
      for(let key in props) {
        const attr = props[key];
        if(Array.isArray(attr)) {
          eventProps[`${key}_array`] = attr;
          eventProps[`${key}_count`] = attr.length;
          /**
           * If array contains reference types(Objects/arrays) convert them accordingly.
           * Check on first index of the array to find the type of values the array contains
           */
          eventProps[key] = (typeof attr[0] === "object") ? JSON.stringify(attr) : attr.join();
        } else {
          eventProps[key] = attr;
        }
      }
    } catch(e) {
      eventProps = props;
    }
    (typeof eventName === "string") && window.analytics.track(eventName, eventProps);
  }
};

/**
 * Segment User Tracker
 * @param {string} eventType
 * @param {object} props - list of attributes need to be captured on user signup/login
 */
const trackProfile = (eventType, props = {}) => {
  if (window.analytics) {
    const isLogin = [USER_LOGIN, USER_LOGIN_GETCOST].includes(eventType);
    const isSignup = [USER_SIGNUP, USER_SIGNUP_GETCOST].includes(eventType);

    isLogin && trackEvent(EVENT_GENERATE_LEAD);

    if(isLogin || isSignup) {
      const { mobileNumber, name, email } = props;
      const attrs = {
        signup: isSignup,
        name,
        email,
        phone: mobileNumber
      };
      if(sessionStorage && sessionStorage.getItem('campaignId')) {
        attrs.cpid = sessionStorage.getItem('campaignId');
      }
      trackEvent(eventType, attrs);
      if(isSignup && sessionStorage && sessionStorage.getItem('USER_HASH_DATA')) {
        attrs.unsubscribe_hash = sessionStorage.getItem('USER_HASH_DATA');

        sessionStorage.removeItem('USER_HASH_DATA');
      }
      window.analytics.identify(mobileNumber, attrs)
    }
  }
};

/**
 * Segment Page call Tracker
 * @param {string} pageName
 * @param {object} props - list of attributes need to be captured on page calls
 */
const trackPage = (pageName, props={}) => {
  if(window.analytics) {
    //check if props is object, change it to valid object if it is not one.
    props = (typeof props === "object" && !Array.isArray(props)) ? props : { props };
    window.analytics.page(pageName, props);
  }
}

export {
  EVENT_LOGO_CLICKED,
  EVENT_POSTCARD,
  EVENT_CBR,
  EVENT_START_PLANNING,
  EVENT_RECENTLY_BOOKED,
  EVENT_PAGE_VISITED,
  EVENT_PACKAGE_SELECTED,
  EVENT_PACKAGE_FILTERED,
  EVENT_PDG_DESTINATION_SELECTED,
  EVENT_PDG_MONTH_SELECTED,
  EVENT_PDG_DURATION_SELECTED,
  EVENT_PDG_THEMES_SELECTED,
  EVENT_PDG_CHOOSE_CITIES,
  EVENT_PDG_ITINERARY_CREATED,
  EVENT_PDG_CITY_ADDED,
  EVENT_PDG_CITY_REMOVED,
  EVENT_ITINERARY_MODIFIED,
  EVENT_ITINERARY_COSTED,
  EVENT_ITINERARY_COSTING_SUBMITTED,
  EVENT_INCLUSIONS_MODIFIED,
  EVENT_QUOTE_REQUESTED,
  EVENT_BOOKING_INITIATED,
  EVENT_PAX_FILLED,
  EVENT_COST_REVIEWED,
  EVENT_PAYMENT_INITIATED,
  EVENT_PAYMENT_SUCCESS,
  EVENT_PAYMENT_FAILED,
  EVENT_BOOKING_TIMED_OUT,
  EVENT_BOOKING_COMPLETED,
  EVENT_COUPON_APPLIED,
  EVENT_COUPON_REMOVED,
  EVENT_LOGOUT,
  EVENT_CHAT_REQUESTED,
  EVENT_CANCELLATION_POLICY,
  EVENT_YOUR_VACATIONS,
  EVENT_BLOG_VIEWED,
  EVENT_TESTIMONIAL_VIEWED,
  EVENT_ADD,
  EVENT_EDIT,
  EVENT_CHANGE,
  EVENT_REMOVE,
  EVENT_PACKAGES_EDIT,
  EVENT_POSITION_HEADER,
  EVENT_POSITION_FOOTER,
  USER_LOGIN,
  USER_SIGNUP,
  USER_LOGIN_GETCOST,
  USER_SIGNUP_GETCOST,
  PAGE_PACKAGES,
  PAGE_PDG,
  PAGE_TESTIMONIALS,
  PAGE_CAREERS,
  PAGE_ABOUT,
  PAGE_CONTACT,
  PAGE_FAQ,
  PAGE_TERMS,
  PAGE_PRIVACY,
  PAGE_CANCELLATION,
  EVENT_GENERATE_LEAD,
  trackEvent,
  trackProfile,
  trackPage
};
