import _ from 'lodash';
export const regionObjects = [
  {
    regionname: 'France',
    regionCode: 'fra',
    id: '58984db40254014d372c24a3',
    countryIds: [12],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'You would need 4 nights to enjoy France',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText: 'Ideal to explore up to 3 cities in a short span of time.',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 15,
        displayText: 'Get ready to explore France!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar - May, Sept - Oct',
        minTemp: 9.0,
        maxTemp: 17.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun - Aug',
        minTemp: 15.0,
        maxTemp: 24.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Feb',
        minTemp: 4.0,
        maxTemp: 9.0
      },
      { type: 'Bastille Day', bestMonths: 'Jul', minTemp: 15.0, maxTemp: 24.0 }
    ],
    europe: false,
    defaultSalesOwner: 'dwaraka@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'Merci.',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Visit the Eiffel Tower, Lido Show.',
    campaign: false,
    averageAmountIncrease: '75,250',
    relatedRegionCodes: ['che', 'ity', 'esp'],
    relatedArticlesIds: ['1', '2', '3', '4', '5'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Spain',
    regionCode: 'esp',
    id: '58984db50254014d372c24a4',
    countryIds: [13],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 9,
        displayText: 'A good trip to Spain needs atleast 4 nights',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Ideal for visitng 2 cities in close proximity',
        recommended: true
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText:
          'Visit the key highlights of Spain located across 4 cities',
        recommended: false
      },
      {
        minDays: 15,
        maxDays: 20,
        displayText: 'Get ready to explore Spain! ',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun, Sept - Nov',
        minTemp: 9.0,
        maxTemp: 22.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan - Mar,Jul - Aug',
        minTemp: 2.0,
        maxTemp: 13.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Dec',
        minTemp: 14.0,
        maxTemp: 31.0
      },
      { type: 'Tomatina', bestMonths: 'Aug', minTemp: 2.0, maxTemp: 13.0 }
    ],
    europe: false,
    defaultSalesOwner: 'dwaraka@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: 'Gracias.',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Explore the Sagrada Familia,Flamenco Show.',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['eur', 'fra', 'nld'],
    relatedArticlesIds: ['6', '7', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'europe_taxi']
  },
  {
    regionname: 'Czech Republic',
    regionCode: 'cze',
    id: '58984db60254014d372c24a5',
    countryIds: [17],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: '4 nights would give you a quick trip to Czech',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Visit a couple of neighbouring cities',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Ideal for visiting the highlights of Czech',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Pack your bags for a complete Czech vacation',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - May,Sept - Oct',
        minTemp: 7.0,
        maxTemp: 16.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun - Aug',
        minTemp: 12.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Mar',
        minTemp: -2.0,
        maxTemp: 5.0
      },
      {
        type: 'Walpurgis Night',
        bestMonths: 'Apr',
        minTemp: 7.0,
        maxTemp: 16.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'dwaraka@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: 'Dekuji',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Prague Castle visit,Cruise on Vltava River.',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['aus', 'hun', 'eur'],
    relatedArticlesIds: ['4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Seychelles',
    regionCode: 'sez',
    id: '59ccf64505f42b07367d4763',
    countryIds: [32],
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [{ minTemp: 0.0, maxTemp: 0.0 }, { minTemp: 0.0, maxTemp: 0.0 }],
    europe: false,
    defaultSalesOwner: 'dwaraka@pickyourtrail.com',
    defaultAccountOwner: 'suresh@pickyourtrail.com',
    thankYouText: 'Mersi pou ou led',
    rank: 0,
    offline: false,
    campaign: true,
    averageAmountIncrease: '85,000',
    relatedRegionCodes: ['mle', 'idn', 'tha'],
    relatedArticlesIds: ['8', '9', '10', '4'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'yelp']
  },
  {
    regionname: 'Sri Lanka',
    regionCode: 'lka',
    id: '58cf8e1301f28dbebea45862',
    visaCost: 0.0,
    recommended: false,
    europe: false,
    defaultSalesOwner: 'dwaraka@pickyourtrail.com',
    defaultAccountOwner: 'raj@pickyourtrail.com',
    rank: 1000,
    offline: true,
    campaign: false,
    averageAmountIncrease: '35,600',
    relatedRegionCodes: ['', '', ''],
    appIds: ['', '', '', '']
  },
  {
    regionname: 'Netherlands',
    regionCode: 'nld',
    id: '58984db80254014d372c24a6',
    countryIds: [18],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'It takes 4 nights for a vacation to the Netherlands',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Ideal for visiting the neighbouring cities',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Explore upto 4 cities of the Netherlands',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'The Netherlands are calling you! ',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar - May, Sept - Nov',
        minTemp: 7.0,
        maxTemp: 13.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun - Aug',
        minTemp: 12.0,
        maxTemp: 20.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Dec - Feb',
        minTemp: 2.0,
        maxTemp: 6.0
      },
      {
        type: 'Rotterdam Summer Carnival',
        bestMonths: 'Jul',
        minTemp: 12.0,
        maxTemp: 20.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'Dank je',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Zaanse Schans explorations,Canal Cruise.',
    campaign: false,
    averageAmountIncrease: '83,000',
    relatedRegionCodes: ['cze', 'deu', 'bel'],
    relatedArticlesIds: ['4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Switzerland',
    regionCode: 'che',
    id: '58984db90254014d372c24a7',
    countryIds: [21],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'A good Swiss vacation needs atleast 4 nights',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Visit a couple of neighbouring cities',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Perfect if you want to cover the Swiss Alps',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Get ready to be awed by Switzerland!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun,Sept',
        minTemp: 7.0,
        maxTemp: 19.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 13.0,
        maxTemp: 24.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Mar',
        minTemp: -2.0,
        maxTemp: 7.0
      },
      {
        type: 'Prätti-Ziller Folk Music Fest',
        bestMonths: 'Jun',
        minTemp: 7.0,
        maxTemp: 19.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: 'Grazie',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Visit the Alps,Cheese tasting at Gruyere.',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['fra', 'ity', 'vie'],
    relatedArticlesIds: ['11', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'europe_taxi']
  },
  {
    regionname: 'Greece',
    regionCode: 'grc',
    id: '58984dba0254014d372c24a8',
    countryIds: [11],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 9,
        displayText: 'Good for a quick trip including the Pantheon ',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Cover a couple of Greek islands',
        recommended: true
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'Athens, Santorini, and a lot more of Greece',
        recommended: false
      },
      {
        minDays: 15,
        maxDays: 20,
        displayText: 'Get ready to explore Greece',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'May - Jun,Sept - Nov',
        minTemp: 17.0,
        maxTemp: 25.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 24.0,
        maxTemp: 33.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Dec - Apr',
        minTemp: 9.0,
        maxTemp: 16.0
      },
      {
        type: 'Saint\u0027s day of the Virgin Mary',
        bestMonths: 'Aug',
        minTemp: 24.0,
        maxTemp: 33.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'dwaraka@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'Efcharisto.',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Visit the Akrotiri,Trip to Meteora.',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['tur', 'ity', 'eur'],
    relatedArticlesIds: ['12', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Croatia',
    regionCode: 'hrv',
    id: '58984dbb0254014d372c24a9',
    countryIds: [14],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'This would be a quick trip to Croatia',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Cover a couple of neighbouring cities',
        recommended: true
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Explore more than 4 cities of Croatia',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Awesome Croatia is waiting for you!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'May - Jun,Sept - Oct',
        minTemp: 10.0,
        maxTemp: 20.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 15.0,
        maxTemp: 27.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Apr',
        minTemp: -3.0,
        maxTemp: 9.0
      },
      {
        type: 'Electric Elephant',
        bestMonths: 'Jul',
        minTemp: 15.0,
        maxTemp: 27.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: 'Hvala ti',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Plitvice Waterfalls, Game of Thrones Location',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['eur', 'hun', 'vie'],
    relatedArticlesIds: ['4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'europe_taxi']
  },
  {
    regionname: 'Hungary',
    regionCode: 'hun',
    id: '58984dbb0254014d372c24aa',
    countryIds: [15],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Cover the highlights of Hungary',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Explore a couple of neighbouring cities',
        recommended: true
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Get to know upto 4 cities of Hungary',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Get packing to explore Hungary',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun,Sept - Oct',
        minTemp: 10.0,
        maxTemp: 20.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 16.0,
        maxTemp: 26.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Mar',
        minTemp: -2.0,
        maxTemp: 6.0
      },
      {
        type: 'Szeged Open-Air Festival',
        bestMonths: 'Jul',
        minTemp: 16.0,
        maxTemp: 26.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'kaushik@pickyourtrail.com',
    thankYouText: 'Koszonom',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Visit the Chain Bridge, Danube River Cruise',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['vie', 'hrv', 'eur'],
    relatedArticlesIds: ['13', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Germany',
    regionCode: 'deu',
    id: '58984dbc0254014d372c24ab',
    countryIds: [19],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'A quick trip to the capital of Germany',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Explore a couple of neighbouring cities',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Beer tasting and the highlights of Germany await you',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Ready to have a German adventure?',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - May,Sept - Oct',
        minTemp: 7.0,
        maxTemp: 16.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun - Aug',
        minTemp: 13.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Mar',
        minTemp: -2.0,
        maxTemp: 5.0
      },
      { type: 'Oktoberfest', bestMonths: 'Oct', minTemp: 7.0, maxTemp: 16.0 }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'Vielen Dank',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Visit the Berlin Wall,Enjoy the Bavarian Beer',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['deu', 'nld', 'che'],
    relatedArticlesIds: ['14', '15', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'europe_taxi']
  },
  {
    regionname: 'United Kingdom',
    regionCode: 'gbr',
    id: '58984dbc0254014d372c24ac',
    countryIds: [20],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 9,
        displayText: 'A vacation to the UK needs at least 4 nights',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Look around a couple of neighbouring cities',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'Explore castles and more across 4 cities of the UK',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 20,
        displayText: 'Your UK adventure is just a flight away!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun,Sept - Dec',
        minTemp: 9.0,
        maxTemp: 15.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 14.0,
        maxTemp: 22.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Mar',
        minTemp: 4.0,
        maxTemp: 8.0
      },
      {
        type: '2017 ICC Champions Trophy',
        bestMonths: 'Jun',
        minTemp: 9.0,
        maxTemp: 15.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: 'Thank you.',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Explore London Eye, Cruise at River Thames',
    campaign: false,
    averageAmountIncrease: '85,200',
    relatedRegionCodes: ['esp', 'fra', 'deu'],
    relatedArticlesIds: ['4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Belgium',
    regionCode: 'bel',
    id: '58984dbd0254014d372c24ad',
    countryIds: [22],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText:
          'It usually takes 4 nights to cover the highlights in Belgium',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Visit a couple of neighbouring cities',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText:
          'Bridges, castles, chocolates and more await you across 4 cities',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Pack your bags for the perfect vacation',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr,Sept -  Dec ',
        minTemp: 7.0,
        maxTemp: 12.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan - Mar,May - Jun',
        minTemp: 5.0,
        maxTemp: 17.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jul - Aug',
        minTemp: 13.0,
        maxTemp: 23.0
      },
      {
        type: 'Zythos Beer Festival',
        bestMonths: 'Apr',
        minTemp: 7.0,
        maxTemp: 12.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: 'Dank je',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Grand Palace visit, Belgian Beer discovery',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['nld', 'fra', 'deu'],
    relatedArticlesIds: ['4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'europe_taxi']
  },
  {
    regionname: 'Turkey',
    regionCode: 'tur',
    id: '58984dbe0254014d372c24ae',
    countryIds: [23],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 9,
        displayText: 'Turkey needs 4 nights of exploration',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Some charming neighbouring cities can be covered',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'Include the Cappadocia caves in your 4 city plan',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 20,
        displayText: 'Your Turkish adventure awaits you!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun,Sept - Nov',
        minTemp: 13.0,
        maxTemp: 23.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Dec - Mar',
        minTemp: 5.0,
        maxTemp: 10.0
      },
      {
        type: 'Istanbul Music Festival',
        bestMonths: 'Jun',
        minTemp: 13.0,
        maxTemp: 23.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: 'Tesekkur ederim',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Fly in a Hot Air Ballon, Shop at Grand Bazaar',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['grc', 'ity', 'eur'],
    relatedArticlesIds: ['16', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Australia',
    regionCode: 'aus',
    id: '58984dbe0254014d372c24af',
    countryIds: [1],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 9,
        displayText: 'The Land of Oz is vast and needs 4-6 nights!',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Cover a couple of neighbouring cities',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'Over 4 cities and your fill of kangaroo spotting',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 20,
        displayText: 'The perfect Aussie vacation is a flight away!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Sept',
        minTemp: 11.0,
        maxTemp: 20.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 26.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Oct - Nov, Feb - Mar',
        minTemp: 17.0,
        maxTemp: 25.0
      },
      {
        type: 'Sydney Festival',
        bestMonths: 'Jan',
        minTemp: 19.0,
        maxTemp: 26.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'kaushik@pickyourtrail.com',
    defaultAccountOwner: 'sunil@pickyourtrail.com',
    thankYouText: 'Thank you.',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Great Ocean Road Drive, Play with Pengiuns',
    campaign: false,
    averageAmountIncrease: '87,599',
    relatedRegionCodes: ['nz', 'anz', 'mly'],
    relatedArticlesIds: ['17', '18', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'gocatch']
  },
  {
    regionname: 'Bali',
    regionCode: 'idn',
    id: '58984dbf0254014d372c24b0',
    countryIds: [2],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'A quick Indonesian tour to cover its temples',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Visit a couple of neighbouring cities',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText: 'Explore temples, paddy fields and more at leisure',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 15,
        displayText: 'That is sure to be the perfect Indonesian vacation!',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun,Oct - Dec',
        minTemp: 26.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Mar',
        minTemp: 25.0,
        maxTemp: 30.0
      },
      {
        type: 'Bali Arts Festival',
        bestMonths: 'Jun',
        minTemp: 26.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'santosh@pickyourtrail.com',
    thankYouText: 'Terima kasih',
    rank: 1,
    offline: false,
    activityPlaceholderText: 'Sunrise from Mt Batur, Sunset at Uluwatu',
    campaign: false,
    averageAmountIncrease: '42,350',
    relatedRegionCodes: ['tha', 'sin', 'mly'],
    relatedArticlesIds: ['19', '20', '21', '22', '23'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'blue_bird']
  },
  {
    regionname: 'Hong Kong',
    regionCode: 'hkg',
    id: '58984dbf0254014d372c24b1',
    countryIds: [3],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Ideal for a quick trip to Hong Kong',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Street food tours, Ferry rides, Museums and more',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText: 'Victoria Harbour to Peak tram rides, Hong Kong awaits',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 15,
        displayText: 'Get packing for the most fantastic vacation!',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar - May, Sept - Oct',
        minTemp: 9.0,
        maxTemp: 17.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun - Aug',
        minTemp: 15.0,
        maxTemp: 24.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Feb',
        minTemp: 4.0,
        maxTemp: 9.0
      },
      { type: 'Bastille Day', bestMonths: 'Jul', minTemp: 15.0, maxTemp: 24.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Xiexie',
    rank: 100,
    offline: true,
    activityPlaceholderText: 'Tram at Victoria Peak,Fun at Disneyland.',
    campaign: false,
    averageAmountIncrease: '62,200',
    relatedRegionCodes: ['sin', 'tha', 'mly'],
    relatedArticlesIds: ['24', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'grab_taxi']
  },
  {
    regionname: 'Singapore',
    regionCode: 'sin',
    id: '58984dc00254014d372c24b3',
    countryIds: [5],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'A Singapore vacation requires 2 nights',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Cover the important highlights of Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText: 'Gardens by the Bay, heritage trails and more.',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 15,
        displayText: 'Pack your bags, Singapore is waiting for you!',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Oct',
        minTemp: 25.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan - Mar',
        minTemp: 24.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Dec',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Singapore Grand Prix',
        bestMonths: 'Sept',
        minTemp: 25.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Nandri',
    rank: 10,
    offline: false,
    activityPlaceholderText: 'Sentosa, Bird Park, Universal Studios',
    campaign: false,
    averageAmountIncrease: '50,099',
    relatedRegionCodes: ['mly', 'idn', 'tha'],
    relatedArticlesIds: ['25', '26', '24', '4', '7'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'grab_taxi']
  },
  {
    regionname: 'Thailand',
    regionCode: 'tha',
    id: '58984dc10254014d372c24b4',
    countryIds: [6],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'It usually takes 2 - 3 nights to explore Bangkok',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Visit a couple of neighbouring cities ',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText: 'Cover up to 3-4 cities, explore temples and more',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 15,
        displayText: 'Have you packed your bags to Thailand yet?',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Oct - Nov,Feb - May',
        minTemp: 24.0,
        maxTemp: 34.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec-Jan',
        minTemp: 21.0,
        maxTemp: 32.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun-Sept',
        minTemp: 25.0,
        maxTemp: 33.0
      },
      {
        type: 'Chiang Mai Flower Festival.',
        bestMonths: 'Feb',
        minTemp: 24.0,
        maxTemp: 34.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Khx khxbkhun',
    rank: 60,
    offline: false,
    activityPlaceholderText: 'Explore James Bond Island, Siam Niramit Show.',
    campaign: false,
    averageAmountIncrease: '51,500',
    relatedRegionCodes: ['vie', 'tha_sin', 'idn'],
    relatedArticlesIds: ['27', '28', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'grab_taxi']
  },
  {
    regionname: 'Australia & New Zealand',
    regionCode: 'anz',
    id: '59dfbd85bb7ae2a508491dcf',
    countryIds: [1, 8],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Perfect for short-term vacationing in ANZ.',
        recommended: false
      },
      {
        minDays: 11,
        maxDays: 13,
        displayText:
          'Ideal to learn the interesting culture of ANZ \u0026 blend in with the locals. ',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText:
          'Explore Twelve Apostles, Yarra River, Fiordland National Park, Waitomo Caves, and more',
        recommended: true
      },
      {
        minDays: 16,
        maxDays: 18,
        displayText: 'To be completely blown away by the beauty of ANZ.',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'May,Sept-Oct',
        minTemp: 22.0,
        maxTemp: 15.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan,Apr,Dec',
        minTemp: 23.0,
        maxTemp: 17.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Feb,Dec',
        minTemp: 16.0,
        maxTemp: 10.0
      },
      {
        type: 'Pasifika Festival',
        bestMonths: 'March',
        minTemp: 22.0,
        maxTemp: 15.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'saurabh@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    thankYouText: 'Mauruuru',
    rank: 201,
    offline: false,
    activityPlaceholderText: 'Great Ocean Road, Waitomo Glowworm Caves',
    campaign: false,
    averageAmountIncrease: '1,25,150',
    relatedRegionCodes: ['idn_sin', 'mys_sin', 'aus'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'gocatch']
  },
  {
    regionname: 'Nepal',
    regionCode: 'npl',
    id: '58cf8e1301f28dbebea45861',
    visaCost: 0.0,
    recommended: false,
    europe: false,
    defaultSalesOwner: 'adharsh@pickyourtrail.com',
    defaultAccountOwner: 'adharsh@pickyourtrail.com',
    rank: 1000,
    offline: true,
    campaign: false,
    averageAmountIncrease: '45,000',
    relatedRegionCodes: ['', '', ''],
    appIds: ['', '', '', '']
  },
  {
    regionname: 'Malaysia',
    regionCode: 'mly',
    id: '58984dc10254014d372c24b5',
    countryIds: [7],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Good for a quick exploration of the capital city',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Go island hopping in Langkawi and more',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText: 'Cultural tours, island hopping and a lot in store',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 15,
        displayText: 'Malaysia awaits you! ',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr-Sept',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec-Mar',
        minTemp: 23.0,
        maxTemp: 33.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Oct - Nov',
        minTemp: 22.0,
        maxTemp: 31.0
      },
      {
        type: 'Thaipusam in Batu Caves',
        bestMonths: 'Feb',
        minTemp: 23.0,
        maxTemp: 33.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Terima kasih',
    rank: 20,
    offline: false,
    activityPlaceholderText: 'Vist Petronas Twin Towers, Caves',
    campaign: false,
    averageAmountIncrease: '57,099',
    relatedRegionCodes: ['tha', 'sin', 'idn'],
    relatedArticlesIds: ['4', '7', '5', '32', '33'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'grab_taxi']
  },
  {
    regionname: 'New Zealand',
    regionCode: 'nz',
    id: '58984dc20254014d372c24b6',
    countryIds: [8],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 9,
        displayText: 'Ideal for a quick New Zealand trip',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Mountains, lakes and a couple of cities to explore',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'Explore the Hobbiton and Waitomo caves among others',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 20,
        displayText: 'Your New Zealand adventure is a flight away!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar - May,Nov',
        minTemp: 13.0,
        maxTemp: 20.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Feb',
        minTemp: 17.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Sept - Oct',
        minTemp: 11.0,
        maxTemp: 17.0
      },
      {
        type: 'Pasifika Festival',
        bestMonths: 'Mar',
        minTemp: 13.0,
        maxTemp: 20.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'saurabh@pickyourtrail.com',
    defaultAccountOwner: 'kaushik@pickyourtrail.com',
    thankYouText: 'Mauruuru koe',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Waitomo Glowworm Caves, Milford Sound Cruise',
    campaign: false,
    averageAmountIncrease: '92,750',
    relatedRegionCodes: ['aus', 'idn_sin', 'tha'],
    relatedArticlesIds: ['34', '35', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'cabchooze']
  },
  {
    regionname: 'Italy',
    regionCode: 'ity',
    id: '58984dc30254014d372c24b7',
    countryIds: [9],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Good for a quick exploration of Italy ',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Explore the Vatican and the Italian Riveria ',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Cover up to 4 cities to include Amalfi and Cinque Terre',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Your Italian sojourn is not far away!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar-Jun,Sept-Nov',
        minTemp: 12.0,
        maxTemp: 22.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul-Aug',
        minTemp: 11.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Dec-Feb',
        minTemp: 3.0,
        maxTemp: 14.0
      },
      {
        type: 'Game of the Bridge',
        bestMonths: 'Jun',
        minTemp: 12.0,
        maxTemp: 22.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'Grazie',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Cinque terre, Venice Islands, Vatican',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['fra', 'grc', 'tur'],
    relatedArticlesIds: ['36', '37', '38', '39', '4'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Iceland',
    regionCode: 'ice',
    id: '58984dc30254014d372c24b8',
    countryIds: [10],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Perfect for a quick tour of Iceland',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Cover the Golden Circle and the glaciers',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText:
          'Travel across more than 4 places, include whale watching and more',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 15,
        displayText: 'Your Iceland vacation is a flight away!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'May-Jun',
        minTemp: 5.0,
        maxTemp: 10.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul-Sept',
        minTemp: 7.0,
        maxTemp: 12.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan-Apr,Oct-Dec',
        minTemp: -2.0,
        maxTemp: 4.0
      },
      {
        type: 'Westman Islands Camping Festival',
        bestMonths: 'Aug',
        minTemp: 7.0,
        maxTemp: 12.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: 'pakka per fyrir',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Northern Lights, Glacier Walking',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['fra', 'eur', 'esp'],
    relatedArticlesIds: ['7', '5', '4', '40'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'europe_taxi']
  },
  {
    regionname: 'Europe',
    regionCode: 'eur',
    id: '58984dc40254014d372c24b9',
    countryIds: [
      9,
      11,
      12,
      13,
      14,
      15,
      16,
      17,
      18,
      19,
      20,
      21,
      22,
      23,
      25,
      30,
      34,
      36,
      38,
      10
    ],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 9,
        displayText: '5 - 8 nights is ideal for a quick Europe trip',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Try a combination of neighbouring countries',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'You could exlore 2 - 3 countries',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 20,
        displayText: 'Plan away, Europe is waiting for you!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - May, Sept - Oct',
        minTemp: 9.0,
        maxTemp: 17.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun - Aug',
        minTemp: 15.0,
        maxTemp: 24.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Dec',
        minTemp: 4.0,
        maxTemp: 9.0
      },
      {
        type: 'Northern Lights',
        bestMonths: 'Dec - Mar',
        minTemp: 15.0,
        maxTemp: 18.0
      }
    ],
    europe: true,
    defaultSalesOwner: 'dwaraka@pickyourtrail.com',
    defaultAccountOwner: 'chandru@pickyourtrail.com',
    thankYouText: 'Thank you',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Spot the Northern lights',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedArticlesIds: ['41', '42', '4', '7'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Austria',
    regionCode: 'vie',
    id: '58984dc40254014d372c24ba',
    countryIds: [16],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'A good Austrian vacation needs atleast 4 nights',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText:
          'Visit the key highlights of Austria located across 4 cities',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 15,
        displayText: 'Austria, here we come! ',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - May, Sept - Nov',
        minTemp: 6.0,
        maxTemp: 15.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun - Aug',
        minTemp: 13.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Dec - Mar',
        minTemp: -3.0,
        maxTemp: 4.0
      },
      {
        type: 'Salzburg International Festival',
        bestMonths: 'Jul',
        minTemp: 13.0,
        maxTemp: 23.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'kaushik@pickyourtrail.com',
    thankYouText: 'Vielen Dank',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Opera concerts, bavarian alps',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['deu', 'ity', 'eur'],
    relatedArticlesIds: ['43', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'europe_taxi']
  },
  {
    regionname: 'Thailand + Malaysia',
    regionCode: 'tha_mys',
    id: '589ad3c00e5b6cf0d1e8423a',
    countryIds: [6, 7],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Thailand and Malaysia',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Thailand and Malaysia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov, Apr - May',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      { type: 'Peak Season', bestMonths: 'Dec', minTemp: 21.0, maxTemp: 31.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      {
        type: 'Songkran Thai New Year Water Festival ',
        bestMonths: 'Apr',
        minTemp: 24.0,
        maxTemp: 32.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Terima kasih',
    rank: 63,
    offline: false,
    activityPlaceholderText:
      'Explore James Bond Island,Vist Petronas Twin Towers',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['tha_hkg', 'tha_vnm', 'mly']
  },
  {
    regionname: 'Thailand + Singapore',
    regionCode: 'tha_sin',
    id: '589ad3c10e5b6cf0d1e8423c',
    countryIds: [6, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Thailand and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Thailand and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Feb, Jul - Sept',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      { type: 'Peak Season', bestMonths: 'Dec', minTemp: 21.0, maxTemp: 31.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Nov',
        minTemp: 24.0,
        maxTemp: 30.0
      },
      {
        type: 'Chinese New Year ',
        bestMonths: 'Jan',
        minTemp: 23.0,
        maxTemp: 32.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Terima kasih',
    rank: 61,
    offline: false,
    activityPlaceholderText: 'Explore James Bond Island,Sentosa',
    campaign: false,
    averageAmountIncrease: '73,259',
    relatedRegionCodes: ['tha_idn', 'tha_mys', 'sin']
  },
  {
    regionname: 'Thailand + Hong Kong',
    regionCode: 'tha_hkg',
    id: '589ad3c20e5b6cf0d1e8423d',
    countryIds: [6, 3],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Thailand and Hong Kong',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Thailand and Hong Kong',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar - May',
        minTemp: 23.0,
        maxTemp: 30.0
      },
      { type: 'Peak Season', bestMonths: 'Dec', minTemp: 17.0, maxTemp: 25.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Jul - Sept',
        minTemp: 26.0,
        maxTemp: 32.0
      },
      {
        type: 'Songkran Thai New Year Water Festival ',
        bestMonths: 'Apr',
        minTemp: 23.0,
        maxTemp: 30.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Khx khxbkhun',
    rank: 64,
    offline: true,
    activityPlaceholderText: 'Explore James Bond Island,Tram at Victoria Peak',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['tha_idn', 'tha_sin', 'tha']
  },
  {
    regionname: 'Malaysia + Bali',
    regionCode: 'mys_idn',
    id: '589ad3c40e5b6cf0d1e8423f',
    countryIds: [7, 2],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'You would need 7 - 8 Nights to enjoy Malaysia and Bali',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Malaysia and Bali',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 22.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 23.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      {
        type: 'Tadau Kaamatan',
        bestMonths: 'May',
        minTemp: 22.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    thankYouText: 'Terima kasih',
    rank: 22,
    offline: false,
    activityPlaceholderText: 'Vist Petronas Twin Towers,Sunrise from Mt Batur',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn', 'mys_tha', 'mys_khm']
  },
  {
    regionname: 'Malaysia + Singapore',
    regionCode: 'mys_sin',
    id: '589ad3c40e5b6cf0d1e84240',
    countryIds: [7, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Malaysia and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Malaysia and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'May - Aug',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      { type: 'Peak Season', bestMonths: 'Dec', minTemp: 23.0, maxTemp: 29.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Nov',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Singapore National Day',
        bestMonths: 'Aug',
        minTemp: 24.0,
        maxTemp: 32.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Terima kasih',
    rank: 21,
    offline: false,
    activityPlaceholderText: 'Vist Petronas Twin Towers,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_hkg', 'mys_idn', 'sin']
  },
  {
    regionname: 'Malaysia + Hong Kong',
    regionCode: 'mys_hkg',
    id: '589ad3c40e5b6cf0d1e84241',
    countryIds: [7, 3],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText:
          'You would need 7 - 8 Nights to enjoy Malaysia and Hong Kong',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Malaysia and Hong Kong',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar - May',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      { type: 'Peak Season', bestMonths: 'Dec', minTemp: 23.0, maxTemp: 31.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Aug',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      {
        type: 'Tai Kok Tsui Temple Fair',
        bestMonths: 'Mar',
        minTemp: 22.0,
        maxTemp: 30.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Xiexie',
    rank: 26,
    offline: true,
    activityPlaceholderText: 'Vist Petronas Twin Towers,Tram at Victoria Peak',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_sin', 'mys_idn', 'mly']
  },
  {
    regionname: 'Bali + Thailand',
    regionCode: 'idn_tha',
    id: '589ad3c50e5b6cf0d1e84242',
    countryIds: [2, 6],
    numberOfNights: [
      {
        minDays: 5,
        maxDays: 7,
        displayText: 'Bali and Thailand in a week would be a tight squeeze',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText:
          'Perfect for checking out two cities across these countries',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities across countries',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Bali and Thailand',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 25.0,
        maxTemp: 33.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - feb',
        minTemp: 22.0,
        maxTemp: 32.0
      },
      {
        type: 'Bali Kite festival',
        bestMonths: 'Jul',
        minTemp: 24.0,
        maxTemp: 32.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    thankYouText: 'Khx khxbkhun',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Sunrise from Mt Batur,Explore James Bond Island',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn_sin', 'tha', 'idn_mys']
  },
  {
    regionname: 'Bali + Singapore',
    regionCode: 'idn_sin',
    id: '589ad3c60e5b6cf0d1e84244',
    countryIds: [2, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText: 'You would need 6 - 7 Nights to enjoy Bali and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Bali and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 25.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 23.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb',
        minTemp: 22.0,
        maxTemp: 29.0
      },
      {
        type: 'Makepung Buffalo Race',
        bestMonths: 'Jul',
        minTemp: 23.0,
        maxTemp: 30.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    thankYouText: 'Terima kasih',
    rank: 2,
    offline: false,
    activityPlaceholderText: 'Sunrise from Mt Batur,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn_tha', 'idn_mys', 'sin']
  },
  {
    regionname: 'Bali + Hong Kong',
    regionCode: 'idn_hkg',
    id: '589ad3c70e5b6cf0d1e84245',
    countryIds: [2, 3],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'You would need 7 - 8 Nights to enjoy Bali and Hong Kong',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Bali and Hong Kong',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar - May',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 24.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan -Feb, Jun',
        minTemp: 22.0,
        maxTemp: 27.0
      },
      {
        type: 'Tai Kok Tsui Temple Fair',
        bestMonths: 'Mar',
        minTemp: 23.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    thankYouText: 'Xiexie',
    rank: 4,
    offline: true,
    activityPlaceholderText: 'Sunrise from Mt Batur,Tram at Victoria Peak',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn', 'idn_tha', 'idn_mys']
  },
  {
    regionname: 'Singapore + Hong Kong',
    regionCode: 'sin_hkg',
    id: '589ad3c90e5b6cf0d1e84249',
    countryIds: [5, 3],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText:
          'You would need 7 - 8 Nights to enjoy Singapore and Hong Kong',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Singapore and Hong Kong',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Mar - Apr, Sept - Oct',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun - Aug',
        minTemp: 26.0,
        maxTemp: 31.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Dec',
        minTemp: 19.0,
        maxTemp: 24.0
      },
      {
        type: 'Grand Prix Season',
        bestMonths: 'Sept',
        minTemp: 23.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Xiexie',
    rank: 13,
    offline: true,
    activityPlaceholderText: 'Tram at Victoria Peak,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_idn', 'sin', 'sin_tha']
  },
  {
    regionname: 'Laos + Thailand',
    regionCode: 'lao_tha',
    id: '589f2f8aceaa64aa2b4ef802',
    countryIds: [26, 6],
    numberOfNights: [
      {
        minDays: 5,
        maxDays: 6,
        displayText: 'You would need 4 - 5 Nights to enjoy Laos and Thailand',
        recommended: false
      },
      {
        minDays: 7,
        maxDays: 8,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Get ready to Explore Laos and Thailand',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov - Feb',
        minTemp: 20.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan,Aug',
        minTemp: 21.0,
        maxTemp: 32.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jul - Sept',
        minTemp: 25.0,
        maxTemp: 33.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 24.0,
        maxTemp: 34.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Khx khxbkhun',
    rank: 41,
    offline: false,
    activityPlaceholderText: 'Wat Si Saket,Explore James Bond Island',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao', 'lao_khm', 'lao_vnm']
  },
  {
    regionname: 'Laos + Cambodia',
    regionCode: 'lao_khm',
    id: '589f2f8aceaa64aa2b4ef803',
    countryIds: [26, 28],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 7,
        displayText: 'You would need 5 - 6 Nights to enjoy Laos and Cambodia',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Laos and Cambodia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb,Nov',
        minTemp: 18.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan,Aug,Dec',
        minTemp: 20.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Mar-May',
        minTemp: 26.0,
        maxTemp: 34.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 24.0,
        maxTemp: 34.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Arkoun',
    rank: 42,
    offline: false,
    activityPlaceholderText: 'Wat Si Saket,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_vnm_khm', 'khm', 'lao_tha']
  },
  {
    regionname: 'Laos + Vietnam',
    regionCode: 'lao_vnm',
    id: '589f2f8aceaa64aa2b4ef804',
    countryIds: [26, 27],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 7,
        displayText: 'You would need 5 - 6 Nights to enjoy Laos and Vietnam',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Laos and Vietnam',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb-Apr,Dec',
        minTemp: 20.0,
        maxTemp: 30.0
      },
      { type: 'Peak Season', bestMonths: 'Jan', minTemp: 18.0, maxTemp: 28.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Mar - Aug',
        minTemp: 24.0,
        maxTemp: 33.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 17.0,
        maxTemp: 25.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Cam on ban',
    rank: 43,
    offline: false,
    activityPlaceholderText: 'Wat Si Saket,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_tha', 'vnm', 'lao_tha_vnm']
  },
  {
    regionname: 'Thailand + Vietnam',
    regionCode: 'tha_vnm',
    id: '589f2f8aceaa64aa2b4ef805',
    countryIds: [6, 27],
    numberOfNights: [
      {
        minDays: 5,
        maxDays: 6,
        displayText:
          'You would need 4 - 5 Nights to enjoy Thailand and Vietnam',
        recommended: false
      },
      {
        minDays: 7,
        maxDays: 8,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Get ready to Explore Thailand and Vietnam',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Apr',
        minTemp: 21.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 18.0,
        maxTemp: 25.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 26.0,
        maxTemp: 32.0
      },
      {
        type: 'Vietnam Lunar New Year',
        bestMonths: 'Feb',
        minTemp: 21.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Cam on ban',
    rank: 65,
    offline: false,
    activityPlaceholderText: 'Explore James Bond Island,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['tha_mys', 'vnm', 'tha_khm']
  },
  {
    regionname: 'Thailand + Cambodia',
    regionCode: 'tha_khm',
    id: '589f2f8aceaa64aa2b4ef806',
    countryIds: [6, 28],
    numberOfNights: [
      {
        minDays: 5,
        maxDays: 6,
        displayText:
          'You would need 4 - 5 Nights to enjoy Thailand and Cambodia',
        recommended: false
      },
      {
        minDays: 7,
        maxDays: 8,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Get ready to Explore Thailand and Cambodia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Feb',
        minTemp: 23.0,
        maxTemp: 33.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Nov - Dec',
        minTemp: 23.0,
        maxTemp: 31.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Apr - Jun',
        minTemp: 26.0,
        maxTemp: 33.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 23.0, maxTemp: 33.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Arkoun',
    rank: 66,
    offline: false,
    activityPlaceholderText: 'Explore James Bond Island,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['tha_vnm', 'tha_idn', 'khm']
  },
  {
    regionname: 'Vietnam + Cambodia',
    regionCode: 'vnm_khm',
    id: '589f2f8aceaa64aa2b4ef807',
    countryIds: [27, 28],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 7,
        displayText:
          'You would need 5 - 6 Nights to enjoy Vietnam and Cambodia',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Vietnam and Cambodia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov,Feb-Mar',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 25.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 25.0,
        maxTemp: 31.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 23.0, maxTemp: 33.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Arkoun',
    rank: 31,
    offline: false,
    activityPlaceholderText: 'Explore Cu Chi Tunnels,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['vnm_mys', 'vnm_sin', 'vnm']
  },
  {
    regionname: 'Vietnam + Malaysia',
    regionCode: 'vnm_mys',
    id: '589f2f8aceaa64aa2b4ef808',
    countryIds: [27, 7],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Vietnam and Malaysia',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Vietnam and Malaysia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 21.625,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 15.0,
        maxTemp: 21.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Aug',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      {
        type: 'Vietnam Lunar New Year',
        bestMonths: 'Feb',
        minTemp: 21.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Cam on ban',
    rank: 33,
    offline: false,
    activityPlaceholderText: 'Explore Cu Chi Tunnels,Vist Petronas Twin Towers',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['vnm_idn', 'vnm_sin', 'mly']
  },
  {
    regionname: 'Vietnam + Bali',
    regionCode: 'vnm_idn',
    id: '589f2f8aceaa64aa2b4ef809',
    countryIds: [27, 2],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'You would need 7 - 8 Nights to enjoy Vietnam and Bali',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Vietnam and Bali',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 21.625,
        maxTemp: 28.0
      },
      { type: 'Peak Season', bestMonths: 'Sept', minTemp: 23.0, maxTemp: 29.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb, Jun - Aug',
        minTemp: 25.0,
        maxTemp: 30.0
      },
      {
        type: 'Vietnam Lunar New Year',
        bestMonths: 'Feb',
        minTemp: 21.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Cam on ban',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Explore Cu Chi Tunnels,Sunrise from Mt Batur',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['vnm_khm', 'vnm_lao', 'vnm']
  },
  {
    regionname: 'Vietnam + Singapore',
    regionCode: 'vnm_sin',
    id: '589f2f8aceaa64aa2b4ef80a',
    countryIds: [27, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Vietnam and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Vietnam and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Apr',
        minTemp: 20.0,
        maxTemp: 25.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Sept - Oct',
        minTemp: 25.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Dec, Jun - Aug',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      {
        type: 'Chinese New Year',
        bestMonths: 'Jan',
        minTemp: 20.0,
        maxTemp: 25.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Cam on ban',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Explore Cu Chi Tunnels,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['vnm_mys', 'vnm_tha', 'sin']
  },
  {
    regionname: 'Vietnam + Hong Kong',
    regionCode: 'vnm_hkg',
    id: '589f2f8aceaa64aa2b4ef80b',
    countryIds: [27, 3],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Vietnam and Hong Kong',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Vietnam and Hong Kong',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 18.0,
        maxTemp: 23.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 14.0,
        maxTemp: 20.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Aug',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      { type: 'Yuen Siu', bestMonths: 'Feb', minTemp: 18.0, maxTemp: 23.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Cam on ban',
    rank: 35,
    offline: true,
    activityPlaceholderText: 'Explore Cu Chi Tunnels,Tram at Victoria Peak',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['vnm_idn', 'vnm_sin', 'vnm']
  },
  {
    regionname: 'Cambodia + Malaysia',
    regionCode: 'khm_mys',
    id: '589f2f8aceaa64aa2b4ef80c',
    countryIds: [28, 7],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Cambodia and Malaysia',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Cambodia and Malaysia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jun - Nov',
        minTemp: 24.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Apr - May',
        minTemp: 25.0,
        maxTemp: 33.0
      },
      { type: 'Hari Merdeka', bestMonths: 'Aug', minTemp: 24.0, maxTemp: 31.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Arkoun',
    rank: 52,
    offline: false,
    activityPlaceholderText: 'Visit Angkor Wat,Vist Petronas Twin Towers',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['khm_sin', 'khm_idn', 'khm']
  },
  {
    regionname: 'Cambodia + Bali',
    regionCode: 'khm_idn',
    id: '589f2f8aceaa64aa2b4ef80d',
    countryIds: [28, 2],
    numberOfNights: [
      {
        minDays: 5,
        maxDays: 7,
        displayText: 'You would need 7 - 8 Nights to enjoy Cambodia and Bali',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Cambodia and Bali',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun,Oct - Dec',
        minTemp: 26.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Mar',
        minTemp: 25.0,
        maxTemp: 30.0
      },
      {
        type: 'Tanah Lot Temple Piodalan Anniversary',
        bestMonths: 'Jun',
        minTemp: 26.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Arkoun',
    rank: 54,
    offline: false,
    activityPlaceholderText: 'Visit Angkor Wat,Sunrise from Mt Batur',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['khm_lao', 'khm_vnm', 'khm']
  },
  {
    regionname: 'Cambodia + Singapore',
    regionCode: 'khm_sin',
    id: '589f2f8aceaa64aa2b4ef80e',
    countryIds: [28, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Cambodia and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Cambodia and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jun - Sept',
        minTemp: 25.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 22.0,
        maxTemp: 29.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov,Apr - May',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      {
        type: 'Pchum Ben Day',
        bestMonths: 'Sept',
        minTemp: 25.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Arkoun',
    rank: 55,
    offline: false,
    activityPlaceholderText: 'Visit Angkor Wat,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['khm_mys', 'sin', 'khm_tha_lao']
  },
  {
    regionname: 'Cambodia + Hong Kong',
    regionCode: 'khm_hkg',
    id: '589f2f8aceaa64aa2b4ef80f',
    countryIds: [28, 3],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Cambodia and Hong Kong',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Cambodia and Hong Kong',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 22.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 22.0,
        maxTemp: 29.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 26.0,
        maxTemp: 32.0
      },
      {
        type: 'Songkran Thai New Year Water Festival ',
        bestMonths: 'Apr',
        minTemp: 22.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Arkoun',
    rank: 56,
    offline: true,
    activityPlaceholderText: 'Visit Angkor Wat,Tram at Victoria Peak',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['khm', 'khm_idn', 'khm_sin']
  },
  {
    regionname: 'Singapore + Philippines',
    regionCode: 'php_sin',
    id: '589f2f8aceaa64aa2b4ef810',
    countryIds: [29, 5],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText:
          'You would need 7 - 8 Nights to enjoy Philippines and Singapore',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Philippines and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Apr',
        minTemp: 22.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'May - Jun',
        minTemp: 25.0,
        maxTemp: 33.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jul - Sept',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      {
        type: 'Sinulog Festival',
        bestMonths: 'Jan',
        minTemp: 22.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'Salamat',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Cruise to Cebu Island,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100'
  },
  {
    regionname: 'Philippines + Hong Kong',
    regionCode: 'php_hkg',
    id: '589f2f8aceaa64aa2b4ef811',
    countryIds: [29, 3],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText:
          'You would need 6 - 7 Nights to enjoy Philippines and Hong Kong',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Philippines and Hong Kong',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Apr',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Nov - Dec',
        minTemp: 18.0,
        maxTemp: 24.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Sept',
        minTemp: 25.0,
        maxTemp: 34.0
      },
      {
        type: 'Sinulog Festival',
        bestMonths: 'Jan',
        minTemp: 23.0,
        maxTemp: 32.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'Salamat',
    rank: 100,
    offline: true,
    activityPlaceholderText: 'Cruise to Cebu Island,Tram at Victoria Peak',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['vnm', 'php_sin', 'idn']
  },
  {
    regionname: 'Laos + Vietnam + Cambodia',
    regionCode: 'lao_vnm_khm',
    id: '589f2f8aceaa64aa2b4ef812',
    countryIds: [26, 28, 27],
    numberOfNights: [
      {
        minDays: 9,
        maxDays: 10,
        displayText:
          'You would need 8 - 9 Nights to enjoy Laos,Vietnam and Cambodia',
        recommended: false
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov, feb - Mar',
        minTemp: 20.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Apr - Aug',
        minTemp: 24.0,
        maxTemp: 34.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 20.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 74,
    thankYouText: 'Cam on ban',
    rank: 44,
    offline: false,
    activityPlaceholderText:
      'Wat Si Saket,Explore Cu Chi Tunnels,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_tha_vnm', 'vnm_khm', 'lao']
  },
  {
    regionname: 'Laos + Thailand + Vietnam',
    regionCode: 'lao_tha_vnm',
    id: '589f2f8aceaa64aa2b4ef813',
    countryIds: [26, 27, 6],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Laos,Vietnam and Thailand',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 22.0,
        maxTemp: 30.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 6,
    thankYouText: 'Cam on ban',
    rank: 100,
    offline: false,
    activityPlaceholderText:
      'Wat Si Saket,Explore James Bond Island,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_vnm_khm', 'khm_vnm', 'tha']
  },
  {
    regionname: 'Thailand + Cambodia + Vietnam',
    regionCode: 'tha_khm_vnm',
    id: '589f2f8aceaa64aa2b4ef814',
    countryIds: [6, 27, 28],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Vietnam,Cambodia and Thailand',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 22.0, maxTemp: 30.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 74,
    thankYouText: 'Cam on ban',
    rank: 67,
    offline: false,
    activityPlaceholderText:
      'Explore James Bond Island,Visit Angkor Wat,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['tha_sin', 'tha_mys', 'khm']
  },
  {
    regionname: 'Thailand + Cambodia + Malaysia',
    regionCode: 'tha_khm_mys',
    id: '589f2f8aceaa64aa2b4ef815',
    countryIds: [6, 7, 28],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Malaysia,Cambodia and Thailand',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 22.0, maxTemp: 30.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 74,
    preferredExit: 39,
    thankYouText: 'Cam on ban',
    rank: 100,
    offline: false,
    activityPlaceholderText:
      'Explore James Bond Island,Visit Angkor Wat,Vist Petronas Twin Towers',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['tha_vnm', 'tha_sin_mys', 'mly']
  },
  {
    regionname: 'Vietnam + Cambodia + Malaysia',
    regionCode: 'vnm_khm_mys',
    id: '589f2f8aceaa64aa2b4ef816',
    countryIds: [27, 7, 28],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Malaysia,Cambodia and Vietnam',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 22.0, maxTemp: 30.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 39,
    thankYouText: 'Cam on ban',
    rank: 100,
    offline: false,
    activityPlaceholderText:
      'Explore Cu Chi Tunnels,Visit Angkor Wat,Vist Petronas Twin Towers',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mly', 'vnm_khm_tha', 'vnm_khm_lao']
  },
  {
    regionname: 'Cambodia + Thailand + Laos',
    regionCode: 'khm_tha_lao',
    id: '589f2f8aceaa64aa2b4ef817',
    countryIds: [28, 26, 6],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Laos,Cambodia and Thailand',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb,Nov',
        minTemp: 19.0,
        maxTemp: 27.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 20.0,
        maxTemp: 26.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 19.0, maxTemp: 27.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 74,
    preferredExit: 6,
    thankYouText: 'Arkoun',
    rank: 100,
    offline: false,
    activityPlaceholderText:
      'Explore Cu Chi Tunnels,Explore James Bond Island,Wat Si Saket',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao', 'lao_vnm', 'khm_vnm']
  },
  {
    regionname: 'Malaysia + Thailand + Laos',
    regionCode: 'mys_tha_lao',
    id: '589f2f8aceaa64aa2b4ef818',
    countryIds: [7, 26, 6],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Laos,Malaysia and Thailand',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 23.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 6,
    preferredExit: 39,
    thankYouText: 'Xiexie',
    rank: 100,
    offline: false,
    activityPlaceholderText:
      'Vist Petronas Twin Towers,Explore James Bond Island,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_khm', 'mly', 'tha_khm_vnm']
  },
  {
    regionname: 'Malaysia + Thailand + Vietnam',
    regionCode: 'mys_tha_vnm',
    id: '589f2f8aceaa64aa2b4ef819',
    countryIds: [7, 27, 6],
    numberOfNights: [
      {
        minDays: 11,
        maxDays: 12,
        displayText:
          'You would need 10 - 11 Nights to enjoy Vietnam ,Malaysia and Thailand',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 17,
        maxDays: 18,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Aug',
        minTemp: 21.0,
        maxTemp: 30.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 23.0, maxTemp: 29.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 6,
    preferredExit: 39,
    thankYouText: 'Xiexie',
    rank: 100,
    offline: false,
    activityPlaceholderText:
      'Vist Petronas Twin Towers,Explore James Bond Island,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_khm', 'khm_mys', 'tha']
  },
  {
    regionname: 'Singapore + Malaysia + Thailand',
    regionCode: 'sin_mys_tha',
    id: '589f2f8aceaa64aa2b4ef81a',
    countryIds: [5, 6, 7],
    numberOfNights: [
      {
        minDays: 11,
        maxDays: 12,
        displayText:
          'You would need 10 - 11 Nights to enjoy Singapore ,Malaysia and Thailand',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 17,
        maxDays: 18,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 19.0,
        maxTemp: 28.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 23.0,
        maxTemp: 32.0
      },
      {
        type: 'Tadau Kaamatan',
        bestMonths: 'May',
        minTemp: 23.0,
        maxTemp: 29.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 39,
    thankYouText: 'Khx khxbkhun',
    rank: 17,
    offline: false,
    activityPlaceholderText:
      'Sentosa,Vist Petronas Twin Towers,Explore James Bond Island',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin', 'mys_vnm', 'tha_khm']
  },
  {
    regionname: 'Malaysia + Singapore + Bali',
    regionCode: 'mys_sin_idn',
    id: '589f2f8aceaa64aa2b4ef81b',
    countryIds: [7, 2, 5],
    numberOfNights: [
      {
        minDays: 11,
        maxDays: 12,
        displayText:
          'You would need 10 - 11 Nights to enjoy Singapore ,Malaysia and Bali',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 17,
        maxDays: 18,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Oct',
        minTemp: 25.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan - Mar',
        minTemp: 24.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Dec',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Tanah Lot Temple Piodalan Anniversary',
        bestMonths: 'Sept',
        minTemp: 25.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 41,
    thankYouText: 'Khx khxbkhun',
    rank: 27,
    offline: false,
    activityPlaceholderText:
      'Sentosa,Vist Petronas Twin Towers,Sunrise from Mt Batur',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn_tha', 'sin_vnm', 'sin']
  },
  {
    regionname: 'Singapore + Malaysia + Cambodia',
    regionCode: 'sin_mys_khm',
    id: '589f2f8aceaa64aa2b4ef81c',
    countryIds: [5, 28, 7],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Singapore,Malaysia and Cambodia',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jun - Sept',
        minTemp: 24.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Apr - May',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      {
        type: 'Singapore National Day',
        bestMonths: 'Aug',
        minTemp: 24.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 39,
    thankYouText: 'Arkoun',
    rank: 100,
    offline: false,
    activityPlaceholderText:
      'Sentosa,Vist Petronas Twin Towers,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_tha', 'khm_vnm', 'khm']
  },
  {
    regionname: 'Singapore +  Macau + Hong Kong',
    regionCode: 'sin_mac_hkg',
    id: '589f2f8aceaa64aa2b4ef81d',
    countryIds: [5, 3, 4],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Singapore,Macau and Hong Kong',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Sept - Nov',
        minTemp: 24.0,
        maxTemp: 30.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Aug',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      {
        type: 'Tai Kok Tsui Temple Fair',
        bestMonths: 'Mar',
        minTemp: 22.0,
        maxTemp: 30.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 31,
    thankYouText: 'Xiexie',
    rank: 100,
    offline: true,
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_idn', 'sin_tha', 'sin']
  },
  {
    regionname: 'Laos',
    regionCode: 'lao',
    id: '58b3dbb6c7b11019b05f1028',
    countryIds: [26],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Good for a quick trip to Laos',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Ideal for visiting the neighbouring cities',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Explore Kuang Si Falls,Buddha Park,Pak Ou Caves and more',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Pack your bags for the perfect vacation',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov,Feb',
        minTemp: 19.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan,Aug,Dec',
        minTemp: 17.0,
        maxTemp: 29.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Mar - May',
        minTemp: 22.0,
        maxTemp: 33.0
      },
      {
        type: 'Chinese New Year',
        bestMonths: 'Feb',
        minTemp: 19.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 40,
    offline: false,
    activityPlaceholderText: 'Wat Si Saket,Cruise at the Mekong River.',
    campaign: false,
    averageAmountIncrease: '52,500',
    relatedRegionCodes: ['tha', 'vnm', 'khm'],
    relatedArticlesIds: ['7', '5', '4'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'grab_taxi']
  },
  {
    regionname: 'Cambodia',
    regionCode: 'khm',
    id: '58b3dbb6c7b11019b05f1029',
    countryIds: [28],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Good for a quick trip to Cambodia',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Ideal for visiting the neighbouring cities',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText:
          'Explore Phnom Kulen,Reclining Buddha,Silver Pagoda and more',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Pack your bags for the perfect vacation',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov,Feb',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 22.0,
        maxTemp: 31.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Apr - May',
        minTemp: 26.0,
        maxTemp: 35.0
      },
      {
        type: 'Chinese New Year',
        bestMonths: 'Feb',
        minTemp: 24.0,
        maxTemp: 32.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 50,
    offline: false,
    activityPlaceholderText: 'Visit Angkor Wat,Reclining Buddha',
    campaign: false,
    averageAmountIncrease: '53,075',
    relatedRegionCodes: ['vnm', 'mly', 'tha'],
    relatedArticlesIds: ['7', '5', '4', '44'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'grab_taxi']
  },
  {
    regionname: 'Vietnam',
    regionCode: 'vnm',
    id: '58b3dbb6c7b11019b05f102a',
    countryIds: [27],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Good for a quick trip to Vietnam',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Ideal for visiting the neighbouring cities',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText:
          'Explore Cu Chi Tunnels,Thu Bon River,Mekong Cruise and More',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Pack your bags for the perfect vacation',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 18.0,
        maxTemp: 22.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Oct - Nov',
        minTemp: 20.0,
        maxTemp: 26.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Aug',
        minTemp: 26.0,
        maxTemp: 32.0
      },
      {
        type: 'Lunar New Year',
        bestMonths: 'Feb',
        minTemp: 18.0,
        maxTemp: 22.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 30,
    offline: false,
    activityPlaceholderText: 'Explore Cu Chi Tunnels,Mekong Delta Cruise',
    campaign: false,
    averageAmountIncrease: '49,100',
    relatedRegionCodes: ['tha', 'php', 'lao'],
    relatedArticlesIds: ['7', '5', '4', '45'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'grab_taxi']
  },
  {
    regionname: 'Philippines',
    regionCode: 'php',
    id: '58b3dbbdc7b11019b05f102b',
    countryIds: [29],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'Good for a quick trip to Philippines',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Ideal for visiting the neighbouring cities',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Explore Pagsanjan Falls,Mount Pinatubo and More',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Pack your bags for the perfect vacation',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Feb',
        minTemp: 21.0,
        maxTemp: 30.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Nov - Dec',
        minTemp: 22.0,
        maxTemp: 31.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Sept',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      {
        type: 'Panagbenga Flower Festival',
        bestMonths: 'Feb',
        minTemp: 21.0,
        maxTemp: 30.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Cruise to Cebu Island, island hopping',
    campaign: false,
    averageAmountIncrease: '45,100',
    relatedRegionCodes: ['hkg', 'vnm', 'idn'],
    relatedArticlesIds: ['7', '5', '4'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'grab_taxi']
  },
  {
    regionname: 'Singapore +  Bali + Hong Kong',
    regionCode: 'sin_idn_hkg',
    id: '58b932ff412070e9b66b7790',
    countryIds: [5, 2, 3],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'That would be too quick a trip for 3 countries! ',
        recommended: false
      },
      {
        minDays: 11,
        maxDays: 13,
        displayText: 'Perfect for exploring 2 cities across 3 countries',
        recommended: true
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'You can ideally explore 4 cities across 3 countries.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 18,
        displayText: 'Get ready to explore Singapore,Bali and Hong Kong',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Oct',
        minTemp: 25.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan - Mar',
        minTemp: 24.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Dec',
        minTemp: 23.0,
        maxTemp: 29.0
      },
      {
        type: 'Tanah Lot Temple Piodalan Anniversary',
        bestMonths: 'Sept',
        minTemp: 25.0,
        maxTemp: 31.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 31,
    rank: 100,
    offline: true,
    activityPlaceholderText: 'Sentosa,Sunset at Uluwatu,Fun at Disneyland',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn', 'sin_mys_tha', 'sin_idn_tha']
  },
  {
    regionname: 'Singapore + Bali + Thailand',
    regionCode: 'sin_idn_tha',
    id: '58b98f6e333d62ba8c868109',
    countryIds: [5, 2, 6],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'That\u0027s a tight squeeze for three countries! ',
        recommended: false
      },
      {
        minDays: 11,
        maxDays: 13,
        displayText: 'Perfect for exploring 2 cities across 3 countries',
        recommended: true
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'You can ideally explore 4 cities across 3 countries.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 18,
        displayText:
          'You are now set to fully experience Singapore, Bali and Thailand!',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 25.0,
        maxTemp: 31.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 23.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb',
        minTemp: 22.0,
        maxTemp: 29.0
      },
      {
        type: 'Makepung Buffalo Race',
        bestMonths: 'Jul',
        minTemp: 23.0,
        maxTemp: 30.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 6,
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Sentosa,Sunset at Uluwatu,Siam Niramit Show',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_mys_tha', 'tha', 'sin_mys_khm']
  },
  {
    regionname: 'Bali + Malaysia',
    regionCode: 'idn_mys',
    id: '58c7f1491afb61d35ddcffd2',
    countryIds: [7, 2],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'You would need 7 - 8 Nights to enjoy Malaysia and Bali',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Malaysia and Bali',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 29.0,
        maxTemp: 22.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 30.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb',
        minTemp: 32.0,
        maxTemp: 25.0
      },
      {
        type: 'Tadau Kaamatan',
        bestMonths: 'May',
        minTemp: 29.0,
        maxTemp: 22.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    rank: 3,
    offline: false,
    activityPlaceholderText: 'Sunrise from Mt Batur,Caves',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn_sin', 'mly', 'idn_vnm']
  },
  {
    regionname: 'Bali + Cambodia',
    regionCode: 'idn_khm',
    id: '58c7f1491afb61d35ddcffd3',
    countryIds: [28, 2],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'You would need 7 - 8 Nights to enjoy Cambodia and Bali',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Cambodia and Bali',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jun,Nov',
        minTemp: 30.0,
        maxTemp: 24.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan, Jul - Sept',
        minTemp: 29.0,
        maxTemp: 22.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Feb,Apr-May',
        minTemp: 32.0,
        maxTemp: 25.0
      },
      {
        type: 'Tanah Lot Temple ?Piodalan? Anniversary',
        bestMonths: 'Nov',
        minTemp: 30.0,
        maxTemp: 24.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 5,
    offline: false,
    activityPlaceholderText: 'Sunrise from Mt Batur,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn_tha', 'idn_sin', 'khm']
  },
  {
    regionname: 'Bali + Vietnam',
    regionCode: 'idn_vnm',
    id: '58c7f14a1afb61d35ddcffd4',
    countryIds: [27, 2],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'You would need 7 - 8 Nights to enjoy Vietnam and Bali',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Get ready to Explore Vietnam and Bali',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 28.0,
        maxTemp: 21.625
      },
      { type: 'Peak Season', bestMonths: 'Sept', minTemp: 29.0, maxTemp: 23.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb, Jun - Aug',
        minTemp: 30.0,
        maxTemp: 25.0
      },
      {
        type: 'Vietnam Lunar New Year',
        bestMonths: 'Feb',
        minTemp: 29.0,
        maxTemp: 21.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 6,
    offline: false,
    activityPlaceholderText: 'Sunrise from Mt Batur,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['idn_mys_sin', 'vnm_mys', 'vnm']
  },
  {
    regionname: 'Bali + Malaysia + Singapore',
    regionCode: 'idn_mys_sin',
    id: '58c7f14b1afb61d35ddcffd5',
    countryIds: [7, 2, 5],
    numberOfNights: [
      {
        minDays: 11,
        maxDays: 12,
        displayText:
          'You would need 10 - 11 Nights to enjoy Singapore ,Malaysia and Bali',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 17,
        maxDays: 18,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 30.0,
        maxTemp: 24.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 30.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb',
        minTemp: 31.0,
        maxTemp: 25.0
      },
      {
        type: 'Tanah Lot Temple ?Piodalan? Anniversary',
        bestMonths: 'Nov',
        minTemp: 29.0,
        maxTemp: 22.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 41,
    rank: 7,
    offline: false,
    activityPlaceholderText: 'Sunset at Uluwatu,Caves,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_tha', 'mys_khm', 'sin']
  },
  {
    regionname: 'Singapore + Bali',
    regionCode: 'sin_idn',
    id: '58c7f14c1afb61d35ddcffd6',
    countryIds: [2, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText: 'You would need 6 - 7 Nights to enjoy Bali and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Bali and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 31.0,
        maxTemp: 25.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 30.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb',
        minTemp: 29.0,
        maxTemp: 22.0
      },
      {
        type: 'Makepung Buffalo Race',
        bestMonths: 'Jul',
        minTemp: 30.0,
        maxTemp: 23.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    rank: 11,
    offline: false,
    activityPlaceholderText: 'Sentosa,Sunrise from Mt Batur',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_tha', 'sin_mys', 'sin']
  },
  {
    regionname: 'Singapore + Thailand',
    regionCode: 'sin_tha',
    id: '58c7f14d1afb61d35ddcffd7',
    countryIds: [6, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Thailand and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Thailand and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Feb, Jul - Sept',
        minTemp: 32.0,
        maxTemp: 23.0
      },
      { type: 'Peak Season', bestMonths: 'Dec', minTemp: 31.0, maxTemp: 21.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Nov',
        minTemp: 30.0,
        maxTemp: 24.0
      },
      {
        type: 'Chinese New Year ',
        bestMonths: 'Jan',
        minTemp: 32.0,
        maxTemp: 23.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 12,
    offline: false,
    activityPlaceholderText: 'Sentosa,Explore James Bond Island',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_mys', 'sin_idn', 'tha']
  },
  {
    regionname: 'Singapore + Cambodia',
    regionCode: 'sin_khm',
    id: '58c7f14e1afb61d35ddcffd8',
    countryIds: [28, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Cambodia and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Cambodia and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jun - Sept',
        minTemp: 31.0,
        maxTemp: 25.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 29.0,
        maxTemp: 22.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov,Apr - May',
        minTemp: 32.0,
        maxTemp: 25.0
      },
      {
        type: 'Pchum Ben Day',
        bestMonths: 'Sept',
        minTemp: 31.0,
        maxTemp: 25.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 14,
    offline: false,
    activityPlaceholderText: 'Sentosa,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_idn', 'sin_tha', 'khm']
  },
  {
    regionname: 'Singapore + Vietnam',
    regionCode: 'sin_vnm',
    id: '58c7f14f1afb61d35ddcffd9',
    countryIds: [27, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Vietnam and Singapore',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Vietnam and Singapore',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Apr',
        minTemp: 25.0,
        maxTemp: 20.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Sept - Oct',
        minTemp: 30.0,
        maxTemp: 25.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov - Dec, Jun - Aug',
        minTemp: 32.0,
        maxTemp: 25.0
      },
      {
        type: 'Chinese New Year',
        bestMonths: 'Jan',
        minTemp: 25.0,
        maxTemp: 20.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 15,
    offline: false,
    activityPlaceholderText: 'Sentosa,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_mys', 'sin_khm', 'vnm']
  },
  {
    regionname: 'Singapore + Malaysia + Bali',
    regionCode: 'sin_mys_idn',
    id: '58c7f1501afb61d35ddcffda',
    countryIds: [7, 2, 5],
    numberOfNights: [
      {
        minDays: 11,
        maxDays: 12,
        displayText:
          'You would need 10 - 11 Nights to enjoy Singapore ,Malaysia and Bali',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 17,
        maxDays: 18,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 30.0,
        maxTemp: 24.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 30.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Feb',
        minTemp: 31.0,
        maxTemp: 25.0
      },
      {
        type: 'Tanah Lot Temple ?Piodalan? Anniversary',
        bestMonths: 'Nov',
        minTemp: 29.0,
        maxTemp: 22.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 41,
    rank: 16,
    offline: false,
    activityPlaceholderText: 'Sentosa,Caves,Sunrise from Mt Batur',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_idn_tha', 'sin_mys_tha', 'sin']
  },
  {
    regionname: 'Malaysia + Vietnam',
    regionCode: 'mys_vnm',
    id: '58c7f1511afb61d35ddcffdb',
    countryIds: [27, 7],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Vietnam and Malaysia',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Vietnam and Malaysia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 29.0,
        maxTemp: 21.625
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 21.0,
        maxTemp: 15.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Aug',
        minTemp: 32.0,
        maxTemp: 25.0
      },
      {
        type: 'Vietnam Lunar New Year',
        bestMonths: 'Feb',
        minTemp: 29.0,
        maxTemp: 21.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 23,
    offline: false,
    activityPlaceholderText: 'Vist Petronas Twin Towers,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_khm', 'mys_tha', 'mly']
  },
  {
    regionname: 'Malaysia + Thailand',
    regionCode: 'mys_tha',
    id: '58c7f1521afb61d35ddcffdc',
    countryIds: [6, 7],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Thailand and Malaysia',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Thailand and Malaysia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov, Apr - May',
        minTemp: 32.0,
        maxTemp: 24.0
      },
      { type: 'Peak Season', bestMonths: 'Dec', minTemp: 31.0, maxTemp: 21.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 32.0,
        maxTemp: 24.0
      },
      {
        type: 'Songkran Thai New Year Water Festival ',
        bestMonths: 'Apr',
        minTemp: 32.0,
        maxTemp: 24.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 24,
    offline: false,
    activityPlaceholderText:
      'Vist Petronas Twin Towers,Explore James Bond Island',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_sin', 'mys_idn', 'mly']
  },
  {
    regionname: 'Malaysia + Cambodia',
    regionCode: 'mys_khm',
    id: '58c7f1521afb61d35ddcffdd',
    countryIds: [28, 7],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Cambodia and Malaysia',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Cambodia and Malaysia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jun - Nov',
        minTemp: 31.0,
        maxTemp: 24.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 30.0,
        maxTemp: 22.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Apr - May',
        minTemp: 33.0,
        maxTemp: 25.0
      },
      { type: 'Hari Merdeka', bestMonths: 'Aug', minTemp: 31.0, maxTemp: 24.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 25,
    offline: false,
    activityPlaceholderText: 'Vist Petronas Twin Towers,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_vnm', 'lao_khm', 'khm']
  },
  {
    regionname: 'Malaysia + Vietnam + Cambodia',
    regionCode: 'mys_vnm_khm',
    id: '58c7f1531afb61d35ddcffde',
    countryIds: [27, 7, 28],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Malaysia,Cambodia and Vietnam',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 30.0,
        maxTemp: 22.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 28.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 32.0,
        maxTemp: 23.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 30.0, maxTemp: 22.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 39,
    rank: 28,
    offline: false,
    activityPlaceholderText:
      'Vist Petronas Twin Towers,Explore Cu Chi Tunnels,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_idn', 'vnm_khm_tha', 'vnm']
  },
  {
    regionname: 'China',
    regionCode: 'chn',
    id: '58cf8e1301f28dbebea45864',
    visaCost: 0.0,
    recommended: false,
    europe: false,
    defaultSalesOwner: 'adharsh@pickyourtrail.com',
    defaultAccountOwner: 'chandru@pickyourtrail.com',
    rank: 1000,
    offline: true,
    campaign: false,
    averageAmountIncrease: '84,000'
  },
  {
    regionname: 'Japan',
    regionCode: 'jpn',
    id: '58cf8e1301f28dbebea45865',
    visaCost: 0.0,
    recommended: false,
    europe: false,
    defaultSalesOwner: 'adharsh@pickyourtrail.com',
    defaultAccountOwner: 'chandru@pickyourtrail.com',
    rank: 1000,
    offline: true,
    campaign: false,
    averageAmountIncrease: '75,600'
  },
  {
    regionname: 'Korea',
    regionCode: 'kor',
    id: '58cf8e1301f28dbebea45866',
    visaCost: 0.0,
    recommended: false,
    europe: false,
    defaultSalesOwner: 'adharsh@pickyourtrail.com',
    defaultAccountOwner: 'chandru@pickyourtrail.com',
    rank: 1000,
    offline: true,
    campaign: false,
    averageAmountIncrease: '64,500'
  },
  {
    regionname: 'United States of America',
    regionCode: 'usa',
    id: '590c1c4fc929923db52f2a59',
    visaCost: 0.0,
    recommended: false,
    europe: false,
    rank: 1000,
    offline: true,
    campaign: false
  },
  {
    regionname: 'Malaysia + Thailand + Singapore',
    regionCode: 'mys_tha_sin',
    id: '58c7f1541afb61d35ddcffdf',
    countryIds: [5, 6, 7],
    numberOfNights: [
      {
        minDays: 11,
        maxDays: 12,
        displayText:
          'You would need 10 - 11 Nights to enjoy Singapore ,Malaysia and Thailand',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 17,
        maxDays: 18,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 29.0,
        maxTemp: 23.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 28.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 32.0,
        maxTemp: 23.0
      },
      {
        type: 'Tadau Kaamatan',
        bestMonths: 'May',
        minTemp: 29.0,
        maxTemp: 23.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 39,
    rank: 29,
    offline: false,
    activityPlaceholderText:
      'Vist Petronas Twin Towers,Explore James Bond Island,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_tha_vnm', 'tha_khm', 'sin']
  },
  {
    regionname: 'Vietnam + Thailand',
    regionCode: 'vnm_tha',
    id: '58c7f1551afb61d35ddcffe0',
    countryIds: [6, 27],
    numberOfNights: [
      {
        minDays: 5,
        maxDays: 6,
        displayText:
          'You would need 4 - 5 Nights to enjoy Thailand and Vietnam',
        recommended: false
      },
      {
        minDays: 7,
        maxDays: 8,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Get ready to Explore Thailand and Vietnam',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Jan - Apr',
        minTemp: 29.0,
        maxTemp: 21.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 25.0,
        maxTemp: 18.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 32.0,
        maxTemp: 26.0
      },
      {
        type: 'Vietnam Lunar New Year',
        bestMonths: 'Feb',
        minTemp: 29.0,
        maxTemp: 21.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 32,
    offline: false,
    activityPlaceholderText: 'Explore Cu Chi Tunnels,Explore James Bond Island',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['vnm_idn', 'vnm_sin', 'vnm']
  },
  {
    regionname: 'Vietnam + Laos',
    regionCode: 'vnm_lao',
    id: '58c7f1561afb61d35ddcffe1',
    countryIds: [26, 27],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 7,
        displayText: 'You would need 5 - 6 Nights to enjoy Laos and Vietnam',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Laos and Vietnam',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb-Apr,Dec',
        minTemp: 30.0,
        maxTemp: 20.0
      },
      { type: 'Peak Season', bestMonths: 'Jan', minTemp: 28.0, maxTemp: 18.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Mar - Aug',
        minTemp: 33.0,
        maxTemp: 24.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 25.0,
        maxTemp: 17.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 34,
    offline: false,
    activityPlaceholderText: 'Explore Cu Chi Tunnels,Wat Si Saket',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_vnm_khm', 'vnm_sin', 'lao']
  },
  {
    regionname: 'Vietnam + Cambodia + Thailand',
    regionCode: 'vnm_khm_tha',
    id: '58c7f1571afb61d35ddcffe2',
    countryIds: [6, 27, 28],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Vietnam,Cambodia and Thailand',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 30.0,
        maxTemp: 22.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 28.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 32.0,
        maxTemp: 23.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 30.0, maxTemp: 22.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 74,
    rank: 36,
    offline: false,
    activityPlaceholderText:
      'Explore Cu Chi Tunnels,Visit Angkor Wat,Explore James Bond Island',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_vnm', 'tha_sin', 'khm']
  },
  {
    regionname: 'Vietnam + Cambodia + Laos',
    regionCode: 'vnm_khm_lao',
    id: '58c7f1581afb61d35ddcffe3',
    countryIds: [26, 28, 27],
    numberOfNights: [
      {
        minDays: 9,
        maxDays: 10,
        displayText:
          'You would need 8 - 9 Nights to enjoy Laos,Vietnam and Cambodia',
        recommended: false
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov, feb - Mar',
        minTemp: 29.0,
        maxTemp: 20.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 28.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Apr - Aug',
        minTemp: 34.0,
        maxTemp: 24.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 29.0,
        maxTemp: 20.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 74,
    rank: 37,
    offline: false,
    activityPlaceholderText:
      'Explore Cu Chi Tunnels,Visit Angkor Wat,Wat Si Saket',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['lao_tha', 'khm_mys', 'lao']
  },
  {
    regionname: 'Cambodia + Vietnam',
    regionCode: 'khm_vnm',
    id: '58c7f1591afb61d35ddcffe4',
    countryIds: [27, 28],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 7,
        displayText:
          'You would need 5 - 6 Nights to enjoy Vietnam and Cambodia',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Vietnam and Cambodia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov,Feb-Mar',
        minTemp: 32.0,
        maxTemp: 23.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 25.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 31.0,
        maxTemp: 25.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 33.0, maxTemp: 23.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 51,
    offline: false,
    activityPlaceholderText: 'Visit Angkor Wat,Explore Cu Chi Tunnels',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['khm_idn', 'khm_sin', 'vnm']
  },
  {
    regionname: 'Cambodia + Laos',
    regionCode: 'khm_lao',
    id: '58c7f15a1afb61d35ddcffe5',
    countryIds: [26, 28],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 7,
        displayText: 'You would need 5 - 6 Nights to enjoy Laos and Cambodia',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 9,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 10,
        maxDays: 11,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Laos and Cambodia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb,Nov',
        minTemp: 31.0,
        maxTemp: 18.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan,Aug,Dec',
        minTemp: 30.0,
        maxTemp: 20.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Mar-May',
        minTemp: 34.0,
        maxTemp: 26.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 34.0,
        maxTemp: 24.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    rank: 53,
    offline: false,
    activityPlaceholderText: 'Visit Angkor Wat,Wat Si Saket',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['khm_mys', 'khm_sin', 'lao']
  },
  {
    regionname: 'Cambodia + Vietnam + Thailand',
    regionCode: 'khm_vnm_tha',
    id: '58c7f15b1afb61d35ddcffe6',
    countryIds: [6, 27, 28],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Vietnam,Cambodia and Thailand',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 30.0,
        maxTemp: 22.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 28.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 32.0,
        maxTemp: 23.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 30.0, maxTemp: 22.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 74,
    rank: 57,
    offline: false,
    activityPlaceholderText:
      'Visit Angkor Wat,Explore Cu Chi Tunnels,Explore James Bond Island',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['khm_tha_lao', 'khm_vnm_lao', 'vnm']
  },
  {
    regionname: 'Cambodia + Vietnam + Laos',
    regionCode: 'khm_vnm_lao',
    id: '58c7f15c1afb61d35ddcffe7',
    countryIds: [26, 28, 27],
    numberOfNights: [
      {
        minDays: 9,
        maxDays: 10,
        displayText:
          'You would need 8 - 9 Nights to enjoy Laos,Vietnam and Cambodia',
        recommended: false
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Nov, feb - Mar',
        minTemp: 29.0,
        maxTemp: 20.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 28.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Apr - Aug',
        minTemp: 34.0,
        maxTemp: 24.0
      },
      {
        type: 'The Wat Phu festival',
        bestMonths: 'Feb',
        minTemp: 29.0,
        maxTemp: 20.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 74,
    rank: 58,
    offline: false,
    activityPlaceholderText:
      'Visit Angkor Wat,Explore Cu Chi Tunnels,Wat Si Saket',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['khm_tha_lao', 'khm_mys', 'lao']
  },
  {
    regionname: 'Cambodia + Malaysia + Vietnam',
    regionCode: 'khm_mys_vnm',
    id: '58c7f15d1afb61d35ddcffe8',
    countryIds: [27, 7, 28],
    numberOfNights: [
      {
        minDays: 10,
        maxDays: 11,
        displayText:
          'You would need 9 - 10 Nights to enjoy Malaysia,Cambodia and Vietnam',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: false
      },
      {
        minDays: 14,
        maxDays: 15,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: true
      },
      {
        minDays: 16,
        maxDays: 17,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - Apr',
        minTemp: 30.0,
        maxTemp: 22.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 28.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'May - Aug',
        minTemp: 32.0,
        maxTemp: 23.0
      },
      { type: 'Meak Bochea', bestMonths: 'Feb', minTemp: 30.0, maxTemp: 22.0 }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 440,
    preferredExit: 39,
    rank: 59,
    offline: false,
    activityPlaceholderText:
      'Explore Cu Chi Tunnels,Vist Petronas Twin Towers,Visit Angkor Wat',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['mys_tha_lao', 'khm_sin', 'mly']
  },
  {
    regionname: 'Thailand + Singapore + Malaysia',
    regionCode: 'tha_sin_mys',
    id: '58c7f15e1afb61d35ddcffea',
    countryIds: [5, 6, 7],
    numberOfNights: [
      {
        minDays: 11,
        maxDays: 12,
        displayText:
          'You would need 10 - 11 Nights to enjoy Singapore ,Malaysia and Thailand',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 16,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 17,
        maxDays: 18,
        displayText: 'Get ready to Explore South East Region',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Feb - May',
        minTemp: 29.0,
        maxTemp: 23.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 28.0,
        maxTemp: 19.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Sept',
        minTemp: 32.0,
        maxTemp: 23.0
      },
      {
        type: 'Tadau Kaamatan',
        bestMonths: 'May',
        minTemp: 29.0,
        maxTemp: 23.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 39,
    rank: 68,
    offline: false,
    activityPlaceholderText:
      'Explore James Bond Island,Sentosa,Vist Petronas Twin Towers',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['tha_khm_vnm', 'tha_khm_mys', 'sin']
  },
  {
    regionname: 'Singapore + Malaysia + Hong Kong',
    regionCode: 'sin_mys_hkg',
    id: '58c7f15f1afb61d35ddcffeb',
    countryIds: [5, 7, 3],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'That\u0027s a tight squeeze for three countries! ',
        recommended: false
      },
      {
        minDays: 11,
        maxDays: 13,
        displayText: 'Perfect for exploring 2 cities across 3 countries',
        recommended: true
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'You can ideally explore 4 cities across 3 countries.',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 18,
        displayText:
          'You are now set to fully experience Singapore, Bali and Thailand!',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Sept - Nov',
        minTemp: 24.0,
        maxTemp: 30.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun - Aug',
        minTemp: 25.0,
        maxTemp: 32.0
      },
      {
        type: 'Tai Kok Tsui Temple Fair',
        bestMonths: 'Mar',
        minTemp: 22.0,
        maxTemp: 30.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'dwaraka@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    preferredEntry: 75,
    preferredExit: 31,
    rank: 18,
    offline: true,
    activityPlaceholderText:
      'Vist Petronas Twin Towers,Explore James Bond Island,Waitomo Glowworm Caves',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_idn_tha', 'sin_mys_khm', 'hkg']
  },
  {
    regionname: 'UK',
    regionCode: 'gbr',
    id: '58dfc0c8e4323da3ed96e8bf',
    countryIds: [20],
    numberOfNights: [
      {
        minDays: 6,
        maxDays: 9,
        displayText: 'A vacation to the UK needs at least 4 nights',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: 'Look around a couple of neighbouring cities',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'Explore castles and more across 4 cities of the UK',
        recommended: true
      },
      {
        minDays: 15,
        maxDays: 20,
        displayText: 'Your UK adventure is just a flight away!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun,Sept - Dec',
        minTemp: 9.0,
        maxTemp: 15.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Aug',
        minTemp: 14.0,
        maxTemp: 22.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - Mar',
        minTemp: 4.0,
        maxTemp: 8.0
      },
      {
        type: '2017 ICC Champions Trophy',
        bestMonths: 'Jun',
        minTemp: 9.0,
        maxTemp: 15.0
      }
    ],
    europe: false,
    thankYouText: 'Thank you.',
    rank: 100,
    offline: false,
    campaign: false
  },
  {
    regionname: 'Singapore + Malaysia',
    regionCode: 'sin_mys',
    id: '590acfafe25c1be42abf2cd5',
    countryIds: [7, 5],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 8,
        displayText:
          'You would need 6 - 7 Nights to enjoy Singapore and Malaysia',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText: 'Perfect for visiting sister cities in close proximity',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Ideal to explore up to 4 cities.',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 14,
        displayText: 'Get ready to Explore Singapore and Malaysia',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'May - Aug',
        minTemp: 24.0,
        maxTemp: 32.0
      },
      { type: 'Peak Season', bestMonths: 'Dec', minTemp: 23.0, maxTemp: 29.0 },
      {
        type: 'Least Visited',
        bestMonths: 'Nov',
        minTemp: 22.0,
        maxTemp: 30.0
      },
      {
        type: 'Singapore National Day',
        bestMonths: 'Aug',
        minTemp: 24.0,
        maxTemp: 32.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'vatsan@pickyourtrail.com',
    defaultAccountOwner: 'vignesh@pickyourtrail.com',
    thankYouText: 'Terima kasih',
    rank: 13,
    offline: false,
    activityPlaceholderText: 'Vist Petronas Twin Towers,Sentosa',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['sin_idn', 'sin_tha', 'mly']
  },
  {
    regionname: 'Portugal',
    regionCode: 'prt',
    id: '597b0879963fe49d49abea80',
    countryIds: [30],
    numberOfNights: [
      {
        minDays: 4,
        maxDays: 5,
        displayText: 'Perfect for a quick tour of Portugal',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText: 'Visit a couple of neighbouring cities ',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 10,
        displayText:
          'Ideal duration to experience the most beautiful churches and beaches',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 13,
        displayText: 'Get packing for the most fantastic vacation!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr-May,Sep-Oct',
        minTemp: 15.0,
        maxTemp: 25.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jun-Aug',
        minTemp: 15.0,
        maxTemp: 30.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Nov-Jan',
        minTemp: 7.0,
        maxTemp: 14.0
      },
      { type: 'Carnaval', bestMonths: 'Feb-Mar', minTemp: 8.0, maxTemp: 17.0 }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'kaushik@pickyourtrail.com',
    thankYouText: 'Obrigado',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Cathedral Cove,Jeronimos Monastery',
    campaign: false,
    averageAmountIncrease: '73,250',
    relatedRegionCodes: ['fra', 'gbr', 'esp'],
    relatedArticlesIds: ['46', '4', '7', '5'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'europe_taxi']
  },
  {
    regionname: 'Thailand + Bali',
    regionCode: 'tha_idn',
    id: '599ab0d6974f2876a8801d94',
    countryIds: [6, 2],
    numberOfNights: [
      {
        minDays: 5,
        maxDays: 7,
        displayText:
          'A good trip to Thailand and Bali needs atleast 7 - 8 Nights',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Ideal for visitng 2 cities in each destination',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 12,
        displayText: 'Visit the key highlights of Thailand and Bali',
        recommended: false
      },
      {
        minDays: 12,
        maxDays: 13,
        displayText: 'Get ready to Explore Thailand and Bali',
        recommended: false
      }
    ],
    conciergeCost: 1500.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Jun',
        minTemp: 33.0,
        maxTemp: 25.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jul - Sept',
        minTemp: 32.0,
        maxTemp: 24.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jan - feb',
        minTemp: 32.0,
        maxTemp: 22.0
      },
      {
        type: 'Bali Kite festival',
        bestMonths: 'Jul',
        minTemp: 32.0,
        maxTemp: 24.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'stephy@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    rank: 62,
    offline: false,
    activityPlaceholderText: 'Explore James Bond Island,Sunrise from Mt Batur',
    campaign: false,
    averageAmountIncrease: '75,100',
    relatedRegionCodes: ['tha_sin', 'tha_mys', 'tha']
  },
  {
    regionname: 'United Arab Emirates',
    regionCode: 'dxb',
    id: '59b169bb16a3e5465e23719b',
    countryIds: [31],
    numberOfNights: [
      {
        minDays: 0,
        maxDays: 4,
        displayText: 'Ideal to get the essence of Dubai',
        recommended: true
      },
      {
        minDays: 4,
        maxDays: 6,
        displayText:
          'Experience Burj Khalifa, Wild Wadi Water Park, Ski Dubai, and More',
        recommended: false
      },
      {
        minDays: 6,
        maxDays: 8,
        displayText:
          'Get away to Palm Jumeirah and go on thrift shopping in the malls',
        recommended: false
      },
      {
        minDays: 8,
        maxDays: 11,
        displayText: 'Explore Dubai to the fullest',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Sept - Nov, Feb -May',
        minTemp: 23.0,
        maxTemp: 34.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Dec - Jan',
        minTemp: 15.0,
        maxTemp: 25.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jun -Aug',
        minTemp: 28.0,
        maxTemp: 39.0
      },
      {
        type: 'Dubai Shopping Festival',
        bestMonths: 'Dubai Shopping Festival',
        minTemp: 23.0,
        maxTemp: 34.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'subramanian@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    thankYouText: 'Shukraan',
    rank: 1000,
    offline: false,
    activityPlaceholderText: 'Burj Khalifa, Dhow Cruise',
    campaign: false,
    averageAmountIncrease: '49,100',
    relatedRegionCodes: ['grc', 'tur', 'ity'],
    relatedArticlesIds: ['47', '48', '49', '50', '51'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'careem']
  },
  {
    regionname: 'Australia + New Zealand',
    regionCode: 'anz',
    id: '59dfbd86bb7ae2a508491dd0',
    countryIds: [1, 8],
    numberOfNights: [
      {
        minDays: 8,
        maxDays: 10,
        displayText: 'Perfect for short-term vacationing in ANZ.',
        recommended: false
      },
      {
        minDays: 11,
        maxDays: 13,
        displayText:
          'Ideal to learn the interesting culture of ANZ \u0026 blend in with the locals. ',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText:
          'Explore Twelve Apostles, Yarra River, Fiordland National Park, Waitomo Caves, and more',
        recommended: true
      },
      {
        minDays: 16,
        maxDays: 18,
        displayText: 'To be completely blown away by the beauty of ANZ.',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'May,Sept-Oct',
        minTemp: 22.0,
        maxTemp: 15.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Jan,Apr,Dec',
        minTemp: 23.0,
        maxTemp: 17.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Feb,Dec',
        minTemp: 16.0,
        maxTemp: 10.0
      },
      {
        type: 'Pasifika Festival',
        bestMonths: 'March',
        minTemp: 22.0,
        maxTemp: 15.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'saurabh@pickyourtrail.com',
    defaultAccountOwner: 'krish@pickyourtrail.com',
    thankYouText: 'Mauruuru',
    rank: 201,
    offline: false,
    activityPlaceholderText: 'Great Ocean Road, Waitomo Glowworm Caves',
    campaign: false
  },
  {
    regionname: 'Africa',
    regionCode: 'zaf',
    id: '5a0c19d73fef30139da964b1',
    countryIds: [35],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 9,
        displayText: 'Bare minimum to understand South Africa better',
        recommended: false
      },
      {
        minDays: 10,
        maxDays: 12,
        displayText: ' Ideal to give you a glimpse into the African culture',
        recommended: true
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'Safaris, star-studded desert skies, and Sceneries',
        recommended: false
      },
      {
        minDays: 16,
        maxDays: 19,
        displayText: 'To revel in the beauty of South Africa',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 2000.0,
    paymentGatewayChargesPercentage: '0.02',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Apr - Oct',
        minTemp: 19.0,
        maxTemp: 9.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Nov - Jan',
        minTemp: 24.0,
        maxTemp: 14.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Feb - Mar',
        minTemp: 25.0,
        maxTemp: 15.0
      },
      {
        type: 'Hermanus whale festival',
        bestMonths: 'Sept',
        minTemp: 19.0,
        maxTemp: 9.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'Ngiyabonga',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Kruger National Park, Table Mountain',
    campaign: false,
    relatedRegionCodes: ['sez', 'aus', 'nz'],
    relatedArticlesIds: ['52', '53', '54', '4', '7'],
    appIds: ['telegram', 'splitwise', 'google_translate', 'taxify']
  },
  {
    regionname: 'Maldives',
    regionCode: 'mle',
    id: '59ccf64505f42b07367d4762',
    countryIds: [33],
    conciergeCost: 0.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      { bestMonths: 'throughout the year', minTemp: 0.0, maxTemp: 0.0 }
    ],
    europe: false,
    defaultSalesOwner: 'subramanian@pickyourtrail.com',
    defaultAccountOwner: 'suresh@pickyourtrail.com',
    thankYouText: 'Shukuriyyaa',
    rank: 0,
    offline: false,
    activityPlaceholderText: 'At leisue',
    campaign: true,
    averageAmountIncrease: '65,000',
    relatedRegionCodes: ['sez', 'idn', 'tha'],
    relatedArticlesIds: ['4', '7', '29', '30', '31'],
    appIds: ['telegram', 'splitwise', 'duolingo', 'yelp']
  },
  {
    regionname: 'Bhutan',
    regionCode: 'btn',
    id: '58cf8e1301f28dbebea45863',
    visaCost: 0.0,
    recommended: false,
    europe: false,
    defaultSalesOwner: 'adharsh@pickyourtrail.com',
    defaultAccountOwner: 'adharsh@pickyourtrail.com',
    rank: 1000,
    offline: true,
    campaign: false,
    averageAmountIncrease: '35,400',
    relatedRegionCodes: ['', '', ''],
    appIds: ['', '', '', '']
  },
  {
    regionname: 'Mauritius',
    regionCode: 'mus',
    id: '590c1c4ec929923db52f2a55',
    visaCost: 0.0,
    recommended: false,
    europe: false,
    rank: 1000,
    offline: true,
    campaign: false,
    averageAmountIncrease: '65,600',
    relatedRegionCodes: ['', '', ''],
    appIds: ['telegram', 'splitwise', 'duolingo', 'yelp']
  },
  {
    regionname: 'Sweden',
    regionCode: 'swe',
    id: '5aa8e22d3fef300bc559471e',
    countryIds: [38],
    numberOfNights: [
      {
        minDays: 3,
        maxDays: 5,
        displayText: 'This would be a quick trip to Sweden',
        recommended: false
      },
      {
        minDays: 5,
        maxDays: 7,
        displayText: 'Cover a couple of neighbouring cities',
        recommended: true
      },
      {
        minDays: 7,
        maxDays: 9,
        displayText: 'Explore more than 4 cities of Sweden',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText: 'Awesome Sweden is waiting for you!',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 0.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'AMADEUS',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'may-sep',
        minTemp: 10.0,
        maxTemp: 15.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'jun-jul',
        minTemp: 13.0,
        maxTemp: 17.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'feb',
        minTemp: -22.0,
        maxTemp: -3.0
      },
      {
        type: 'Midsummer\u0027s Eve',
        bestMonths: 'jun',
        minTemp: 13.0,
        maxTemp: 17.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'lony@pickyourtrail.com',
    thankYouText: ' tack',
    rank: 100,
    offline: false,
    activityPlaceholderText: 'Sunset Wildlife Safari from Stockholm',
    campaign: false
  },
  {
    regionname: 'Morocco',
    regionCode: 'MAR',
    id: '5adf279162ab874d85f0384d',
    countryIds: [136, 30, 13, 12],
    numberOfNights: [
      {
        minDays: 7,
        maxDays: 9,
        displayText: 'This would be a quick trip to Morocco',
        recommended: false
      },
      {
        minDays: 9,
        maxDays: 11,
        displayText: 'Cover a couple of neighboring cities',
        recommended: true
      },
      {
        minDays: 11,
        maxDays: 13,
        displayText: 'Explore more than 4 cities of Morocco',
        recommended: false
      },
      {
        minDays: 13,
        maxDays: 15,
        displayText: 'Awesome Morocco is waiting for you',
        recommended: false
      }
    ],
    conciergeCost: 3000.0,
    visaCost: 2000.0,
    paymentGatewayChargesPercentage: '0.020',
    internationalFlightsAPI: 'TBO',
    recommended: false,
    tourTypes: [
      {
        type: 'Best time to go',
        bestMonths: 'Oct-Mar',
        minTemp: 18.0,
        maxTemp: 25.0
      },
      {
        type: 'Peak Season',
        bestMonths: 'Mar-May',
        minTemp: 20.0,
        maxTemp: 23.0
      },
      {
        type: 'Least Visited',
        bestMonths: 'Jul-Aug',
        minTemp: 27.0,
        maxTemp: 38.0
      },
      {
        type: 'Gnaoua and Sacred World Music festivals',
        bestMonths: 'Apr-May',
        minTemp: 21.0,
        maxTemp: 26.0
      }
    ],
    europe: false,
    defaultSalesOwner: 'agni@pickyourtrail.com',
    defaultAccountOwner: 'jai@pickyourtrail.com',
    thankYouText: 'shukraan',
    rank: 56,
    offline: false,
    activityPlaceholderText:
      'Atlas Mountains and Three Valleys: Private Guided Day Trip from Marrakech',
    campaign: false
  }
];

export function getRegionByCode(code) {
  return _.find(regionObjects, { regionCode: _.toLower(code) });
}
