import * as Sentry from '@sentry/browser';
import { AppConfig } from '../app-config';
import { is_server } from './utilsHelper';

Sentry.init({
  dsn: AppConfig.SENTRY_DNS_KEY,
  environment:
    !is_server() && window.location.hostname === 'localhost'
      ? 'local'
      : process.env.REACT_APP_NODE_ENV
});

const logClientError = (error, extraInfo) => {
  if (!extraInfo) extraInfo = {};

  Sentry.configureScope(scope => {
    Object.keys(extraInfo).forEach(key => {
      scope.setExtra(key, extraInfo[key]);
    });
  });

  Sentry.captureException(error);
};

export default logClientError;
