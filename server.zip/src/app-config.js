const NODE_ENV = process.env.REACT_APP_NODE_ENV;
const ENABLE_CONTACT_NUMBER = process.env.REACT_APP_ENABLE_CONTACT;
let API_URL;
let SOCKET_URL;

switch (NODE_ENV) {
  case 'local':
    SOCKET_URL = 'http://localhost:8090/';
    API_URL = 'http://localhost:8080/api/';
    break;

  case 'development':
    SOCKET_URL = 'https://dev.longweekend.co.in/';
    API_URL = 'https://dev.longweekend.co.in/api/';
    break;

  case 'nalanda':
    SOCKET_URL = 'https://nalanda.longweekend.co.in/';
    API_URL = 'https://nalanda.longweekend.co.in/api/';
    break;

  case 'uat':
    API_URL = 'https://uat.pickyourtrail.com/api/';
    SOCKET_URL = 'https://uat.pickyourtrail.com/';
    break;

  case 'staging':
    API_URL = 'https://staging.pickyourtrail.com/api/';
    SOCKET_URL = 'https://staging.pickyourtrail.com/';
    break;

  case 'production':
    API_URL = 'https://pickyourtrail.com/api/';
    SOCKET_URL = 'https://pickyourtrail.com/';
    break;

  default:
    console.error('No Environment Variables found!');
    API_URL = 'https://staging.pickyourtrail.com/api/';
    SOCKET_URL = '//localhost:9092/';
    break;
}

export const AppConfig = {
  api_url: API_URL,
  MapboxAccessToken:
    'pk.eyJ1IjoicGlja3lvdXJ0cmFpbCIsImEiOiJjajQzMTVzNXMwbW8wMzJxcTB5c2E0YmMzIn0.my7KPj7RArbSluK19U2cug',
  airline_cdn: '//d3lf10b5gahyby.cloudfront.net/airline_logos/',
  images_cdn_url: '//dig82prjykzgf.cloudfront.net/',
  images_cdn_url_s3: '//d3lf10b5gahyby.cloudfront.net/',
  images_cdn_misc_url: '//d3lf10b5gahyby.cloudfront.net/misc/',
  imgix_base: '//pyt-images.imgix.net',
  imgIX_testimonial_base: '//pyt-testimonial.imgix.net',
  images_cdn_icons_url: '//d3lf10b5gahyby.cloudfront.net/icons/',
  booking_state_alert:
    'The itinerary has already been booked. Cant make any further changes.',
  invalid_image_url:
    'https://d3lf10b5gahyby.cloudfront.net/activity/bc712282-268b-4e89-bd7e-505d026955b8.jpg',
  socket_url: SOCKET_URL,
  user_type_agent: 'AGENT',
  user_type_admin: 'ADMIN',
  website_contact_number: '9360991166',
  SENTRY_DNS_KEY: 'https://b0135048b5f54f998bb37c61deec4ede@sentry.io/1285610',
  enable_Contact_Number: parseInt(ENABLE_CONTACT_NUMBER),
  europe_extra_cc_emails: [
    'Pooja.rani@traveltriangle.com',
    'Shubham.sharma@traveltriangle.com',
    'Shilpa.verdhan@traveltriangle.com',
    'subhranshu.bose@traveltriangle.com',
    'Sagar.sharma@traveltriangle.com',
    'sonali@traveltriangle.com'
  ],
  aus_nz_extra_cc_emails: [
    'aakash.mehta@traveltriangle.com',
    'ashish.joshi@traveltriangle.com',
    'jatin.kumar@traveltriangle.com'
  ]
};
